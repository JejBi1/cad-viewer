from .rdxf import *

__doc__ = rdxf.__doc__
if hasattr(rdxf, "__all__"):
    __all__ = rdxf.__all__