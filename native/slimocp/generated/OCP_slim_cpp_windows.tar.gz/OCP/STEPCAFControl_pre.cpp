
// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;


// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <XSControl_WorkSession.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <XSControl_WorkSession.hxx>
#include <TDataStd_NamedData.hxx>
#include <TDocStd_Document.hxx>
#include <XCAFDoc_ShapeTool.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <XSControl_WorkSession.hxx>
#include <TDocStd_Document.hxx>

// module includes
#include <STEPCAFControl_ActorWrite.hxx>
#include <STEPCAFControl_Controller.hxx>
#include <STEPCAFControl_ExternFile.hxx>
#include <STEPCAFControl_GDTProperty.hxx>
#include <STEPCAFControl_Reader.hxx>
#include <STEPCAFControl_Writer.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module
        #include <istream>
        #include <ostream>

        using std::basic_ostream;
        using std::basic_istream;
        using std::char_traits;

        #include <DE_ConfigurationContext.hxx>
        #include <XCAFDoc_ShapeTool.hxx>
        #include <XSAlgo_ShapeProcessor.hxx>
        

// Module definiiton
void register_STEPCAFControl_enums(py::module &main_module) {


py::module m = main_module.def_submodule("STEPCAFControl", R"#()#");

// add namespaces as submodules

// user-defined inclusion per module in the body

// enums

//Python trampoline classes

// pre-register typdefs+classes (topologically sorted)
    py::class_<STEPCAFControl_GDTProperty , shared_ptr<STEPCAFControl_GDTProperty>  >(
      m,
      "STEPCAFControl_GDTProperty",R"#(This class provides tools for access (read) the GDT properties.)#"
    );
    py::class_<STEPCAFControl_Reader , shared_ptr<STEPCAFControl_Reader>  >(
      m,
      "STEPCAFControl_Reader",R"#(Provides a tool to read STEP file and put it into DECAF document. Besides transfer of shapes (including assemblies) provided by STEPControl, supports also colors and part names)#"
    );
    py::class_<STEPCAFControl_Writer , shared_ptr<STEPCAFControl_Writer>  >(
      m,
      "STEPCAFControl_Writer",R"#(Provides a tool to write DECAF document to the STEP file. Besides transfer of shapes (including assemblies) provided by STEPControl, supports also colors and part names)#"
    );
    py::class_<STEPCAFControl_ActorWrite ,opencascade::handle<STEPCAFControl_ActorWrite>  >(
      m,
      "STEPCAFControl_ActorWrite",R"#(Extends ActorWrite from STEPControl by analysis of whether shape is assembly (based on information from DECAF))#"
    );
    py::class_<STEPCAFControl_Controller ,opencascade::handle<STEPCAFControl_Controller>  >(
      m,
      "STEPCAFControl_Controller",R"#(Extends Controller from STEPControl in order to provide ActorWrite adapted for writing assemblies from DECAF Note that ActorRead from STEPControl is used for reading (inherited automatically))#"
    );
    py::class_<STEPCAFControl_ExternFile ,opencascade::handle<STEPCAFControl_ExternFile>  , Standard_Transient >(
      m,
      "STEPCAFControl_ExternFile",R"#(Auxiliary class serving as container for data resulting from translation of external file)#"
    );

// preregister user-defined template specializations

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
