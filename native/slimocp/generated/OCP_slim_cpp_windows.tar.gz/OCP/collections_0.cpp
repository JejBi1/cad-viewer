
// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;


// Standard Handle
#include <Standard_Handle.hxx>

// collection specific top preinclusion
#include <BRepExtrema_ProximityDistTool.hxx>
#include <gp_XYZ.hxx>

class OpenGl_ShaderProgram;


// template related includes
#include <gp_Pnt.hxx>
#include <TCollection_AsciiString.hxx>
#include <AIS_MouseGesture.hxx>
#include <gp_Dir.hxx>
#include <Graphic3d_ShaderObject.hxx>
#include <Graphic3d_GraphicDriverFactory.hxx>
#include <Graphic3d_Group.hxx>
#include <BRep_PointRepresentation.hxx>
#include <Aspect_TrackedDevicePose.hxx>
#include <Graphic3d_Layer.hxx>
#include <STEPCAFControl_ExternFile.hxx>
#include <Standard_GUID.hxx>
#include <SelectMgr_Filter.hxx>
#include <V3d_View.hxx>
#include <Graphic3d_CView.hxx>
#include <Graphic3d_Buffer.hxx>
#include <BOPAlgo_CheckResult.hxx>
#include <Extrema_POnCurv.hxx>
#include <Font_SystemFont.hxx>
#include <TopExp_Explorer.hxx>
#include <AIS_Animation.hxx>
#include <Message_MetricType.hxx>
#include <Poly_Triangle.hxx>
#include <TDF_AttributeDelta.hxx>
#include <Graphic3d_ShaderAttribute.hxx>
#include <BRep_CurveRepresentation.hxx>
#include <Bnd_Range.hxx>
#include <TopTools_ShapeMapHasher.hxx>
#include <OpenGl_Texture.hxx>
#include <Standard_Transient.hxx>
#include <TDocStd_ApplicationDelta.hxx>
#include <Extrema_POnSurf.hxx>
#include <PrsMgr_PresentableObject.hxx>
#include <PCDM_Reference.hxx>
#include <OpenGl_VertexBuffer.hxx>
#include <TCollection_HAsciiString.hxx>
#include <Bnd_Box.hxx>
#include <Poly_Triangulation.hxx>
#include <gp_Pnt2d.hxx>
#include <Aspect_XRAction.hxx>
#include <IFSelect_Selection.hxx>
#include <Graphic3d_Aspects.hxx>
#include <PrsMgr_Presentation.hxx>
#include <XCAFPrs_Style.hxx>
#include <TCollection_HExtendedString.hxx>
#include <Graphic3d_FrameStatsData.hxx>
#include <TDF_Attribute.hxx>
#include <gp_Vec.hxx>
#include <TDocStd_Document.hxx>
#include <TDF_Delta.hxx>
#include <AIS_SelectionScheme.hxx>
#include <XCAFDoc_VisMaterial.hxx>
#include <OpenGl_GlTypes.hxx>
#include <Standard_Dump.hxx>
#include <SelectMgr_SensitiveEntity.hxx>
#include <BRepExtrema_SolutionElem.hxx>
#include <TopoDS_Iterator.hxx>
#include <Graphic3d_CLight.hxx>
#include <Graphic3d_Structure.hxx>
#include <OpenGl_GlTypes.hxx>
#include <TDF_Label.hxx>
#include <Storage_Root.hxx>
#include <OpenGl_ShaderProgram.hxx>
#include <SelectMgr_EntityOwner.hxx>
#include <TopoDS_Shape.hxx>
#include <BRepMesh_DiscretAlgoFactory.hxx>
#include <CDM_MetaData.hxx>
#include <Quantity_Color.hxx>
#include <SelectMgr_Selection.hxx>
#include <AIS_InteractiveObject.hxx>
#include <AIS_ColoredDrawer.hxx>
#include <Aspect_Touch.hxx>
#include <TCollection_ExtendedString.hxx>
#include <TColStd_PackedMapOfInteger.hxx>
#include <Message_Alert.hxx>
#include <AIS_GlobalStatus.hxx>
#include <Graphic3d_ShaderVariable.hxx>
#include <Graphic3d_ZLayerId.hxx>
#include <Message_Printer.hxx>
#include <PCDM_Document.hxx>
#include <DE_ConfigurationNode.hxx>
#include <Standard_Persistent.hxx>

#include "NCollection_tmpl.hxx"


// user-defined pre
#include "OCP_specific.inc"

// collection specific preinclusion


// Module definiiton
void register_collections_0(py::module &m) {

    // register typdefs
    register_template_NCollection_Array1<Aspect_TrackedDevicePose>(m,"Array1_Aspect_TrackedDevicePose");
    register_template_NCollection_Array1<Bnd_Box>(m,"Array1_Bnd_Box");
    register_template_NCollection_Array1<Graphic3d_Attribute>(m,"Array1_Graphic3d_Attribute");
    register_template_NCollection_Array1<Graphic3d_FrameStatsData>(m,"Array1_Graphic3d_FrameStatsData");
    register_template_NCollection_Array1<Poly_Triangle>(m,"Array1_Poly_Triangle");
    register_template_NCollection_Array1<Quantity_Color>(m,"Array1_Quantity_Color");
    register_template_NCollection_Array1<handle<SelectMgr_EntityOwner>>(m,"Array1_SelectMgr_EntityOwner");
    register_template_NCollection_Array1<handle<Standard_Persistent>>(m,"Array1_Standard_Persistent");
    register_template_NCollection_Array1<TCollection_ExtendedString>(m,"Array1_TCollection_ExtendedString");
    register_template_NCollection_Array1<TDF_Label>(m,"Array1_TDF_Label");
    register_template_NCollection_Array1<NCollection_Vec3<double>>(m,"Array1_Vec3_double");
    register_template_NCollection_Array1<NCollection_Vec3<float>>(m,"Array1_Vec3_float");
    register_template_NCollection_Array1<bool>(m,"Array1_bool");
    register_template_NCollection_Array1<double>(m,"Array1_double");
    register_template_NCollection_Array1<float>(m,"Array1_float");
    register_template_NCollection_Array1<gp_Dir>(m,"Array1_gp_Dir");
    register_template_NCollection_Array1<gp_Pnt>(m,"Array1_gp_Pnt");
    register_template_NCollection_Array1<gp_Pnt2d>(m,"Array1_gp_Pnt2d");
    register_template_NCollection_Array1<gp_Vec>(m,"Array1_gp_Vec");
    register_template_NCollection_Array1<int>(m,"Array1_int");
    register_template_NCollection_Array1<uint8_t>(m,"Array1_uint8_t");
    register_template_NCollection_DataMap<opencascade::handle<AIS_InteractiveObject>,opencascade::handle<AIS_GlobalStatus>>(m,"DataMap_AIS_InteractiveObject_AIS_GlobalStatus");
    register_template_NCollection_DataMap<handle<Graphic3d_Aspects>,handle<Graphic3d_Aspects>>(m,"DataMap_Graphic3d_Aspects_Graphic3d_Aspects");
    register_template_NCollection_DataMap<Graphic3d_ZLayerId,handle<Graphic3d_Layer>>(m,"DataMap_Graphic3d_ZLayerId_Graphic3d_Layer");
    register_template_NCollection_DataMap<handle<SelectMgr_EntityOwner>,int>(m,"DataMap_SelectMgr_EntityOwner_int");
    register_template_NCollection_DataMap<TCollection_AsciiString,NCollection_IndexedDataMap<TCollection_AsciiString,handle<DE_ConfigurationNode>>>(m,"DataMap_TCollection_AsciiString_IndexedDataMap_TCollection_AsciiString_DE_ConfigurationNode");
    register_template_NCollection_DataMap<TCollection_AsciiString,handle<STEPCAFControl_ExternFile>>(m,"DataMap_TCollection_AsciiString_STEPCAFControl_ExternFile");
    register_template_NCollection_DataMap<TCollection_AsciiString,handle<Standard_Transient>>(m,"DataMap_TCollection_AsciiString_Standard_Transient");
    register_template_NCollection_DataMap<TCollection_AsciiString,TCollection_AsciiString>(m,"DataMap_TCollection_AsciiString_TCollection_AsciiString");
    register_template_NCollection_DataMap<TCollection_ExtendedString,handle<CDM_MetaData>>(m,"DataMap_TCollection_ExtendedString_CDM_MetaData");
    register_template_NCollection_DataMap<TCollection_ExtendedString,handle<NCollection_HArray1<double>>>(m,"DataMap_TCollection_ExtendedString_NCollection_HArray1");
    register_template_NCollection_DataMap<TCollection_ExtendedString,TCollection_ExtendedString>(m,"DataMap_TCollection_ExtendedString_TCollection_ExtendedString");
    register_template_NCollection_DataMap<TCollection_ExtendedString,double>(m,"DataMap_TCollection_ExtendedString_double");
    register_template_NCollection_DataMap<TCollection_ExtendedString,int>(m,"DataMap_TCollection_ExtendedString_int");
    register_template_NCollection_DataMap<TCollection_ExtendedString,uint8_t>(m,"DataMap_TCollection_ExtendedString_uint8_t");
    register_template_NCollection_DataMap<handle<TDF_Attribute>,handle<TDF_Attribute>>(m,"DataMap_TDF_Attribute_TDF_Attribute");
    register_template_NCollection_DataMap<TDF_Label,TDF_Label>(m,"DataMap_TDF_Label_TDF_Label");
    register_template_NCollection_DataMap<TDF_Label,int>(m,"DataMap_TDF_Label_int");
    register_template_NCollection_DataMap<TopoDS_Shape,handle<AIS_ColoredDrawer>,TopTools_ShapeMapHasher>(m,"DataMap_TopoDS_Shape_AIS_ColoredDrawer_TopTools_ShapeMapHasher");
    register_template_NCollection_DataMap<TopoDS_Shape,Bnd_Box,TopTools_ShapeMapHasher>(m,"DataMap_TopoDS_Shape_Bnd_Box_TopTools_ShapeMapHasher");
    register_template_NCollection_DataMap<TopoDS_Shape,NCollection_List<TopoDS_Shape>,TopTools_ShapeMapHasher>(m,"DataMap_TopoDS_Shape_List_TopoDS_Shape_TopTools_ShapeMapHasher");
    register_template_NCollection_DataMap<TopoDS_Shape,TDF_Label,TopTools_ShapeMapHasher>(m,"DataMap_TopoDS_Shape_TDF_Label_TopTools_ShapeMapHasher");
    register_template_NCollection_DataMap<TopoDS_Shape,TopoDS_Shape,TopTools_ShapeMapHasher>(m,"DataMap_TopoDS_Shape_TopoDS_Shape_TopTools_ShapeMapHasher");
    register_template_NCollection_DataMap<handle<XCAFDoc_VisMaterial>,handle<XCAFDoc_VisMaterial>>(m,"DataMap_XCAFDoc_VisMaterial_XCAFDoc_VisMaterial");
    register_template_NCollection_DataMap<int,TColStd_PackedMapOfInteger>(m,"DataMap_int_TColStd_PackedMapOfInteger");
    register_template_NCollection_DynamicArray<GLuint>(m,"DynamicArray_GLuint");
    register_template_NCollection_DynamicArray<handle<OpenGl_VertexBuffer>>(m,"DynamicArray_OpenGl_VertexBuffer");
    register_template_NCollection_DynamicArray<handle<SelectMgr_SensitiveEntity>>(m,"DynamicArray_SelectMgr_SensitiveEntity");
    register_template_NCollection_DynamicArray<handle<Standard_Transient>>(m,"DynamicArray_Standard_Transient");
    register_template_NCollection_DynamicArray<TopoDS_Shape>(m,"DynamicArray_TopoDS_Shape");
    register_template_NCollection_DynamicArray<NCollection_Vec2<float>>(m,"DynamicArray_Vec2_float");
    register_template_NCollection_DynamicArray<NCollection_Vec4<double>>(m,"DynamicArray_Vec4_double");
    register_template_NCollection_DynamicArray<float>(m,"DynamicArray_float");
    register_template_NCollection_DynamicArray<int>(m,"DynamicArray_int");
    register_template_NCollection_IndexedDataMap<TCollection_AsciiString,Standard_DumpValue>(m,"IndexedDataMap_TCollection_AsciiString_Standard_DumpValue");
    register_template_NCollection_IndexedDataMap<TCollection_AsciiString,TCollection_AsciiString>(m,"IndexedDataMap_TCollection_AsciiString_TCollection_AsciiString");
    register_template_NCollection_IndexedDataMap<TCollection_AsciiString,int>(m,"IndexedDataMap_TCollection_AsciiString_int");
    register_template_NCollection_IndexedDataMap<TDF_Label,TopoDS_Shape>(m,"IndexedDataMap_TDF_Label_TopoDS_Shape");
    register_template_NCollection_IndexedDataMap<TopoDS_Shape,NCollection_List<TopoDS_Shape>,TopTools_ShapeMapHasher>(m,"IndexedDataMap_TopoDS_Shape_List_TopoDS_Shape_TopTools_ShapeMapHasher");
    register_template_NCollection_IndexedDataMap<TopoDS_Shape,XCAFPrs_Style,TopTools_ShapeMapHasher>(m,"IndexedDataMap_TopoDS_Shape_XCAFPrs_Style_TopTools_ShapeMapHasher");
    register_template_NCollection_IndexedDataMap<TopoDS_Shape,double,TopTools_ShapeMapHasher>(m,"IndexedDataMap_TopoDS_Shape_double_TopTools_ShapeMapHasher");
    register_template_NCollection_IndexedDataMap<size_t,Aspect_Touch>(m,"IndexedDataMap_size_t_Aspect_Touch");
    register_template_NCollection_IndexedMap<Message_MetricType>(m,"IndexedMap_Message_MetricType");
    register_template_NCollection_IndexedMap<handle<SelectMgr_SensitiveEntity>>(m,"IndexedMap_SelectMgr_SensitiveEntity");
    register_template_NCollection_IndexedMap<handle<TDF_Attribute>>(m,"IndexedMap_TDF_Attribute");
    register_template_NCollection_IndexedMap<TDF_Label>(m,"IndexedMap_TDF_Label");
    register_template_NCollection_IndexedMap<TopoDS_Shape,TopTools_ShapeMapHasher>(m,"IndexedMap_TopoDS_Shape_TopTools_ShapeMapHasher");
    register_template_NCollection_LinearVector<GLuint64>(m,"LinearVector_GLuint64");
    register_template_NCollection_List<handle<AIS_InteractiveObject>>(m,"List_AIS_InteractiveObject");
    register_template_NCollection_List<BOPAlgo_CheckResult>(m,"List_BOPAlgo_CheckResult");
    register_template_NCollection_List<handle<BRepMesh_DiscretAlgoFactory>>(m,"List_BRepMesh_DiscretAlgoFactory");
    register_template_NCollection_List<handle<BRep_CurveRepresentation>>(m,"List_BRep_CurveRepresentation");
    register_template_NCollection_List<handle<BRep_PointRepresentation>>(m,"List_BRep_PointRepresentation");
    register_template_NCollection_List<Bnd_Range>(m,"List_Bnd_Range");
    register_template_NCollection_List<handle<Font_SystemFont>>(m,"List_Font_SystemFont");
    register_template_NCollection_List<opencascade::handle<Graphic3d_CLight>>(m,"List_Graphic3d_CLight");
    register_template_NCollection_List<handle<Graphic3d_GraphicDriverFactory>>(m,"List_Graphic3d_GraphicDriverFactory");
    register_template_NCollection_List<handle<Graphic3d_Layer>>(m,"List_Graphic3d_Layer");
    register_template_NCollection_List<NCollection_List<TopoDS_Shape>>(m,"List_List_TopoDS_Shape");
    register_template_NCollection_List<handle<Message_Alert>>(m,"List_Message_Alert");
    register_template_NCollection_List<handle<NCollection_HSequence<gp_Pnt>>>(m,"List_NCollection_HSequence");
    register_template_NCollection_List<Poly_Triangle>(m,"List_Poly_Triangle");
    register_template_NCollection_List<handle<Poly_Triangulation>>(m,"List_Poly_Triangulation");
    register_template_NCollection_List<handle<PrsMgr_PresentableObject>>(m,"List_PrsMgr_PresentableObject");
    register_template_NCollection_List<handle<SelectMgr_EntityOwner>>(m,"List_SelectMgr_EntityOwner");
    register_template_NCollection_List<handle<SelectMgr_Filter>>(m,"List_SelectMgr_Filter");
    register_template_NCollection_List<Standard_GUID>(m,"List_Standard_GUID");
    register_template_NCollection_List<TCollection_AsciiString>(m,"List_TCollection_AsciiString");

}

// user-defined post
