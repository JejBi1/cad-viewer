
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TopoDS_Shape.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TopTools_LocationSet.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <TopTools.hxx>
#include <TopTools_FormatVersion.hxx>
#include <TopTools_LocationSet.hxx>
#include <TopTools_LocationSetPtr.hxx>
#include <TopTools_ShapeMapHasher.hxx>
#include <TopTools_ShapeSet.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module
        #include  "NCollection_tmpl.hxx"
        #include  <Bnd_Box.hxx>
        

// Module definiiton
void register_TopTools(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("TopTools"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes

// classes

    // Class TopTools from ./opencascade/TopTools.hxx
    klass = m.attr("TopTools");

    // default constructor
    register_default_constructor<TopTools , shared_ptr<TopTools>>(m,"TopTools");

    // nested enums

    static_cast<py::class_<TopTools , shared_ptr<TopTools>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Dump_s",
                    (void (*)(  const TopoDS_Shape & ,  Standard_OStream &  ) ) static_cast<void (*)(  const TopoDS_Shape & ,  Standard_OStream &  ) >(&TopTools::Dump),
                    R"#(A set of Shapes. Can be dump, wrote or read. Dumps the topological structure of <Sh> on the stream <S>.)#"  , py::arg("Sh"),  py::arg("S")
          )
        .def_static("Dummy_s",
                    (void (*)(  const int  ) ) static_cast<void (*)(  const int  ) >(&TopTools::Dummy),
                    R"#(This is to bypass an extraction bug. It will force the inclusion of int.hxx itself including Standard_OStream.hxx at the correct position.)#"  , py::arg("I")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class TopTools_LocationSet from ./opencascade/TopTools_LocationSet.hxx
    klass = m.attr("TopTools_LocationSet");


    // nested enums

    static_cast<py::class_<TopTools_LocationSet , shared_ptr<TopTools_LocationSet>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Clear",
             (void (TopTools_LocationSet::*)() ) static_cast<void (TopTools_LocationSet::*)() >(&TopTools_LocationSet::Clear),
             R"#(Clears the content of the set.)#" 
          )
        .def("Add",
             (int (TopTools_LocationSet::*)(  const TopLoc_Location &  ) ) static_cast<int (TopTools_LocationSet::*)(  const TopLoc_Location &  ) >(&TopTools_LocationSet::Add),
             R"#(Incorporate a new Location in the set and returns its index.)#"  , py::arg("L")
          )
        .def("Location",
             ( const TopLoc_Location & (TopTools_LocationSet::*)(  const int  ) const) static_cast< const TopLoc_Location & (TopTools_LocationSet::*)(  const int  ) const>(&TopTools_LocationSet::Location),
             R"#(Returns the location of index <I>.)#"  , py::arg("I")
          )
        .def("Index",
             (int (TopTools_LocationSet::*)(  const TopLoc_Location &  ) const) static_cast<int (TopTools_LocationSet::*)(  const TopLoc_Location &  ) const>(&TopTools_LocationSet::Index),
             R"#(Returns the index of <L>.)#"  , py::arg("L")
          )
        .def("Dump",
             (void (TopTools_LocationSet::*)( Standard_OStream &  ) const) static_cast<void (TopTools_LocationSet::*)( Standard_OStream &  ) const>(&TopTools_LocationSet::Dump),
             R"#(Dumps the content of me on the stream <OS>.)#"  , py::arg("OS")
          )
        .def("Write",
             (void (TopTools_LocationSet::*)( Standard_OStream & ,   const Message_ProgressRange &  ) const) static_cast<void (TopTools_LocationSet::*)( Standard_OStream & ,   const Message_ProgressRange &  ) const>(&TopTools_LocationSet::Write),
             R"#(Writes the content of me on the stream <OS> in a format that can be read back by Read.)#"  , py::arg("OS"),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def("Read",
             (void (TopTools_LocationSet::*)( Standard_IStream & ,   const Message_ProgressRange &  ) ) static_cast<void (TopTools_LocationSet::*)( Standard_IStream & ,   const Message_ProgressRange &  ) >(&TopTools_LocationSet::Read),
             R"#(Reads the content of me from the stream <IS>. me is first cleared.)#"  , py::arg("IS"),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class TopTools_ShapeMapHasher from ./opencascade/TopTools_ShapeMapHasher.hxx
    klass = m.attr("TopTools_ShapeMapHasher");

    // default constructor
    register_default_constructor<TopTools_ShapeMapHasher , shared_ptr<TopTools_ShapeMapHasher>>(m,"TopTools_ShapeMapHasher");

    // nested enums

    static_cast<py::class_<TopTools_ShapeMapHasher , shared_ptr<TopTools_ShapeMapHasher>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
        .def("__call__",
             (size_t (TopTools_ShapeMapHasher::*)(  const TopoDS_Shape &  ) const) static_cast<size_t (TopTools_ShapeMapHasher::*)(  const TopoDS_Shape &  ) const>(&TopTools_ShapeMapHasher::operator()),
             py::is_operator(),
             R"#()#"  , py::arg("theShape")
          )
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class TopTools_ShapeSet from ./opencascade/TopTools_ShapeSet.hxx
    klass = m.attr("TopTools_ShapeSet");


    // nested enums

    static_cast<py::class_<TopTools_ShapeSet , shared_ptr<TopTools_ShapeSet>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetFormatNb",
             (void (TopTools_ShapeSet::*)(  const int  ) ) static_cast<void (TopTools_ShapeSet::*)(  const int  ) >(&TopTools_ShapeSet::SetFormatNb),
             R"#(Sets the TopTools_FormatVersion)#"  , py::arg("theFormatNb")
          )
        .def("FormatNb",
             (int (TopTools_ShapeSet::*)() const) static_cast<int (TopTools_ShapeSet::*)() const>(&TopTools_ShapeSet::FormatNb),
             R"#(Returns the TopTools_FormatVersion)#" 
          )
        .def("Clear",
             (void (TopTools_ShapeSet::*)() ) static_cast<void (TopTools_ShapeSet::*)() >(&TopTools_ShapeSet::Clear),
             R"#(Clears the content of the set. This method can be redefined.)#" 
          )
        .def("Add",
             (int (TopTools_ShapeSet::*)(  const TopoDS_Shape &  ) ) static_cast<int (TopTools_ShapeSet::*)(  const TopoDS_Shape &  ) >(&TopTools_ShapeSet::Add),
             R"#(Stores <S> and its sub-shape. Returns the index of <S>. The method AddGeometry is called on each sub-shape.)#"  , py::arg("S")
          )
        .def("Shape",
             ( const TopoDS_Shape & (TopTools_ShapeSet::*)(  const int  ) const) static_cast< const TopoDS_Shape & (TopTools_ShapeSet::*)(  const int  ) const>(&TopTools_ShapeSet::Shape),
             R"#(Returns the sub-shape of index <I>.)#"  , py::arg("I")
          )
        .def("Index",
             (int (TopTools_ShapeSet::*)(  const TopoDS_Shape &  ) const) static_cast<int (TopTools_ShapeSet::*)(  const TopoDS_Shape &  ) const>(&TopTools_ShapeSet::Index),
             R"#(Returns the index of <S>.)#"  , py::arg("S")
          )
        .def("DumpExtent",
             (Standard_OStream & (TopTools_ShapeSet::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TopTools_ShapeSet::*)( Standard_OStream &  ) const>(&TopTools_ShapeSet::DumpExtent),
             R"#(Dumps the number of objects in me on the stream <OS>. (Number of shapes of each type))#"  , py::arg("OS")
          )
        .def("DumpExtent",
             (void (TopTools_ShapeSet::*)( TCollection_AsciiString &  ) const) static_cast<void (TopTools_ShapeSet::*)( TCollection_AsciiString &  ) const>(&TopTools_ShapeSet::DumpExtent),
             R"#(Dumps the number of objects in me in the string S (Number of shapes of each type))#"  , py::arg("S")
          )
        .def("Dump",
             (void (TopTools_ShapeSet::*)( Standard_OStream &  ) const) static_cast<void (TopTools_ShapeSet::*)( Standard_OStream &  ) const>(&TopTools_ShapeSet::Dump),
             R"#(Dumps the content of me on the stream <OS>.)#"  , py::arg("OS")
          )
        .def("Write",
             (void (TopTools_ShapeSet::*)( Standard_OStream & ,   const Message_ProgressRange &  ) ) static_cast<void (TopTools_ShapeSet::*)( Standard_OStream & ,   const Message_ProgressRange &  ) >(&TopTools_ShapeSet::Write),
             R"#(Writes the content of me on the stream <OS> in a format that can be read back by Read.)#"  , py::arg("OS"),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def("Read",
             (void (TopTools_ShapeSet::*)( Standard_IStream & ,   const Message_ProgressRange &  ) ) static_cast<void (TopTools_ShapeSet::*)( Standard_IStream & ,   const Message_ProgressRange &  ) >(&TopTools_ShapeSet::Read),
             R"#(Reads the content of me from the stream <IS>. me is first cleared.)#"  , py::arg("IS"),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def("Dump",
             (void (TopTools_ShapeSet::*)(  const TopoDS_Shape & ,  Standard_OStream &  ) const) static_cast<void (TopTools_ShapeSet::*)(  const TopoDS_Shape & ,  Standard_OStream &  ) const>(&TopTools_ShapeSet::Dump),
             R"#(Dumps on <OS> the shape <S>. Dumps the orientation, the index of the TShape and the index of the Location.)#"  , py::arg("S"),  py::arg("OS")
          )
        .def("Write",
             (void (TopTools_ShapeSet::*)(  const TopoDS_Shape & ,  Standard_OStream &  ) const) static_cast<void (TopTools_ShapeSet::*)(  const TopoDS_Shape & ,  Standard_OStream &  ) const>(&TopTools_ShapeSet::Write),
             R"#(Writes on <OS> the shape <S>. Writes the orientation, the index of the TShape and the index of the Location.)#"  , py::arg("S"),  py::arg("OS")
          )
        .def("Read",
             (void (TopTools_ShapeSet::*)( TopoDS_Shape & ,  Standard_IStream &  ) const) static_cast<void (TopTools_ShapeSet::*)( TopoDS_Shape & ,  Standard_IStream &  ) const>(&TopTools_ShapeSet::Read),
             R"#(Reads from <IS> a shape and returns it in S.)#"  , py::arg("S"),  py::arg("IS")
          )
        .def("AddGeometry",
             (void (TopTools_ShapeSet::*)(  const TopoDS_Shape &  ) ) static_cast<void (TopTools_ShapeSet::*)(  const TopoDS_Shape &  ) >(&TopTools_ShapeSet::AddGeometry),
             R"#(Stores the geometry of <S>.)#"  , py::arg("S")
          )
        .def("DumpGeometry",
             (void (TopTools_ShapeSet::*)( Standard_OStream &  ) const) static_cast<void (TopTools_ShapeSet::*)( Standard_OStream &  ) const>(&TopTools_ShapeSet::DumpGeometry),
             R"#(Dumps the geometry of me on the stream <OS>.)#"  , py::arg("OS")
          )
        .def("WriteGeometry",
             (void (TopTools_ShapeSet::*)( Standard_OStream & ,   const Message_ProgressRange &  ) ) static_cast<void (TopTools_ShapeSet::*)( Standard_OStream & ,   const Message_ProgressRange &  ) >(&TopTools_ShapeSet::WriteGeometry),
             R"#(Writes the geometry of me on the stream <OS> in a format that can be read back by Read.)#"  , py::arg("OS"),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def("ReadGeometry",
             (void (TopTools_ShapeSet::*)( Standard_IStream & ,   const Message_ProgressRange &  ) ) static_cast<void (TopTools_ShapeSet::*)( Standard_IStream & ,   const Message_ProgressRange &  ) >(&TopTools_ShapeSet::ReadGeometry),
             R"#(Reads the geometry of me from the stream <IS>.)#"  , py::arg("IS"),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def("DumpGeometry",
             (void (TopTools_ShapeSet::*)(  const TopoDS_Shape & ,  Standard_OStream &  ) const) static_cast<void (TopTools_ShapeSet::*)(  const TopoDS_Shape & ,  Standard_OStream &  ) const>(&TopTools_ShapeSet::DumpGeometry),
             R"#(Dumps the geometry of <S> on the stream <OS>.)#"  , py::arg("S"),  py::arg("OS")
          )
        .def("WriteGeometry",
             (void (TopTools_ShapeSet::*)(  const TopoDS_Shape & ,  Standard_OStream &  ) const) static_cast<void (TopTools_ShapeSet::*)(  const TopoDS_Shape & ,  Standard_OStream &  ) const>(&TopTools_ShapeSet::WriteGeometry),
             R"#(Writes the geometry of <S> on the stream <OS> in a format that can be read back by Read.)#"  , py::arg("S"),  py::arg("OS")
          )
        .def("ReadGeometry",
             (void (TopTools_ShapeSet::*)(  const TopAbs_ShapeEnum ,  Standard_IStream & ,  TopoDS_Shape &  ) ) static_cast<void (TopTools_ShapeSet::*)(  const TopAbs_ShapeEnum ,  Standard_IStream & ,  TopoDS_Shape &  ) >(&TopTools_ShapeSet::ReadGeometry),
             R"#(Reads the geometry of a shape of type <T> from the stream <IS> and returns it in <S>.)#"  , py::arg("T"),  py::arg("IS"),  py::arg("S")
          )
        .def("AddShapes",
             (void (TopTools_ShapeSet::*)( TopoDS_Shape & ,   const TopoDS_Shape &  ) ) static_cast<void (TopTools_ShapeSet::*)( TopoDS_Shape & ,   const TopoDS_Shape &  ) >(&TopTools_ShapeSet::AddShapes),
             R"#(Inserts the shape <S2> in the shape <S1>. This method must be redefined to use the correct builder.)#"  , py::arg("S1"),  py::arg("S2")
          )
        .def("Check",
             (void (TopTools_ShapeSet::*)(  const TopAbs_ShapeEnum ,  TopoDS_Shape &  ) ) static_cast<void (TopTools_ShapeSet::*)(  const TopAbs_ShapeEnum ,  TopoDS_Shape &  ) >(&TopTools_ShapeSet::Check),
             R"#(This method is called after each new completed shape. <T> is the type. <S> is the shape. In this class it does nothing, but it gives the opportunity in derived classes to perform extra treatment on shapes.)#"  , py::arg("T"),  py::arg("S")
          )
        .def("NbShapes",
             (int (TopTools_ShapeSet::*)() const) static_cast<int (TopTools_ShapeSet::*)() const>(&TopTools_ShapeSet::NbShapes),
             R"#(Returns number of shapes read from file.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Locations",
             ( const TopTools_LocationSet & (TopTools_ShapeSet::*)() const) static_cast< const TopTools_LocationSet & (TopTools_ShapeSet::*)() const>(&TopTools_ShapeSet::Locations),
             R"#()#"
             
         )
       .def("ChangeLocations",
             (TopTools_LocationSet & (TopTools_ShapeSet::*)() ) static_cast<TopTools_LocationSet & (TopTools_ShapeSet::*)() >(&TopTools_ShapeSet::ChangeLocations),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
;

// functions

// ./opencascade/TopTools.hxx
// ./opencascade/TopTools_FormatVersion.hxx
// ./opencascade/TopTools_LocationSet.hxx
// ./opencascade/TopTools_LocationSetPtr.hxx
// ./opencascade/TopTools_ShapeMapHasher.hxx
// ./opencascade/TopTools_ShapeSet.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
