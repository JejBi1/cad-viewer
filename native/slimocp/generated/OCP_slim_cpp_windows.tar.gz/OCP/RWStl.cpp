
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Message_ProgressRange.hxx>

// module includes
#include <RWStl.hxx>
#include <RWStl_Reader.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module
        #include <DE_ConfigurationContext.hxx>
        #include <NCollection_Buffer.hxx>
        #include <TDocStd_Document.hxx>
        #include <XSControl_WorkSession.hxx>
        #include <TopoDS_Shape.hxx>

// Module definiiton
void register_RWStl(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("RWStl"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes
    class Py_RWStl_Reader : public RWStl_Reader{
    public:
        using RWStl_Reader::RWStl_Reader;


        // public pure virtual
        int AddNode( const gp_XYZ & thePnt) override { using return_type = int;
    PYBIND11_OVERLOAD_PURE(return_type,RWStl_Reader,AddNode,thePnt) };
        void AddTriangle(int theN1,int theN2,int theN3) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,RWStl_Reader,AddTriangle,theN1,theN2,theN3) };


        // protected pure virtual


        // private pure virtual

    };

// classes

    // Class RWStl from ./opencascade/RWStl.hxx
    klass = m.attr("RWStl");

    // default constructor
    register_default_constructor<RWStl , shared_ptr<RWStl>>(m,"RWStl");

    // nested enums

    static_cast<py::class_<RWStl , shared_ptr<RWStl>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("WriteBinary_s",
                    (bool (*)(  const handle<Poly_Triangulation> & ,   const OSD_Path & ,   const Message_ProgressRange &  ) ) static_cast<bool (*)(  const handle<Poly_Triangulation> & ,   const OSD_Path & ,   const Message_ProgressRange &  ) >(&RWStl::WriteBinary),
                    R"#(Write triangulation to binary STL file. binary format of an STL file. Returns false if the cannot be opened;)#"  , py::arg("theMesh"),  py::arg("thePath"),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def_static("WriteBinary_s",
                    (bool (*)(  const handle<Poly_Triangulation> & ,  Standard_OStream & ,   const Message_ProgressRange &  ) ) static_cast<bool (*)(  const handle<Poly_Triangulation> & ,  Standard_OStream & ,   const Message_ProgressRange &  ) >(&RWStl::WriteBinary),
                    R"#(Write triangulation to binary STL stream.)#"  , py::arg("theMesh"),  py::arg("theStream"),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def_static("WriteAscii_s",
                    (bool (*)(  const handle<Poly_Triangulation> & ,   const OSD_Path & ,   const Message_ProgressRange &  ) ) static_cast<bool (*)(  const handle<Poly_Triangulation> & ,   const OSD_Path & ,   const Message_ProgressRange &  ) >(&RWStl::WriteAscii),
                    R"#(write the meshing in a file following the Ascii format of an STL file. Returns false if the cannot be opened;)#"  , py::arg("theMesh"),  py::arg("thePath"),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def_static("WriteAscii_s",
                    (bool (*)(  const handle<Poly_Triangulation> & ,  Standard_OStream & ,   const Message_ProgressRange &  ) ) static_cast<bool (*)(  const handle<Poly_Triangulation> & ,  Standard_OStream & ,   const Message_ProgressRange &  ) >(&RWStl::WriteAscii),
                    R"#(Write triangulation to ASCII STL stream.)#"  , py::arg("theMesh"),  py::arg("theStream"),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def_static("ReadFile_s",
                    (handle<Poly_Triangulation> (*)(  const OSD_Path & ,   const Message_ProgressRange &  ) ) static_cast<handle<Poly_Triangulation> (*)(  const OSD_Path & ,   const Message_ProgressRange &  ) >(&RWStl::ReadFile),
                    R"#(Read specified STL file and returns its content as triangulation. In case of error, returns Null handle.)#"  , py::arg("theFile"),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def_static("ReadFile_s",
                    (handle<Poly_Triangulation> (*)(  const char * const  ,   const Message_ProgressRange &  ) ) static_cast<handle<Poly_Triangulation> (*)(  const char * const  ,   const Message_ProgressRange &  ) >(&RWStl::ReadFile),
                    R"#(Read specified STL file and returns its content as triangulation. In case of error, returns Null handle.)#"  , py::arg("theFile"),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def_static("ReadFile_s",
                    (handle<Poly_Triangulation> (*)(  const char * const  ,   const double ,   const Message_ProgressRange &  ) ) static_cast<handle<Poly_Triangulation> (*)(  const char * const  ,   const double ,   const Message_ProgressRange &  ) >(&RWStl::ReadFile),
                    R"#(Read specified STL file and returns its content as triangulation.)#"  , py::arg("theFile"),  py::arg("theMergeAngle"),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def_static("ReadFile_s",
                    (void (*)(  const char * const  ,   const double ,  NCollection_Sequence<handle<Poly_Triangulation>> & ,   const Message_ProgressRange &  ) ) static_cast<void (*)(  const char * const  ,   const double ,  NCollection_Sequence<handle<Poly_Triangulation>> & ,   const Message_ProgressRange &  ) >(&RWStl::ReadFile),
                    R"#(Read specified STL file and fills triangulation list for multi-domain case.)#"  , py::arg("theFile"),  py::arg("theMergeAngle"),  py::arg("theTriangList"),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def_static("ReadBinary_s",
                    (handle<Poly_Triangulation> (*)(  const OSD_Path & ,   const Message_ProgressRange &  ) ) static_cast<handle<Poly_Triangulation> (*)(  const OSD_Path & ,   const Message_ProgressRange &  ) >(&RWStl::ReadBinary),
                    R"#(Read triangulation from a binary STL file In case of error, returns Null handle.)#"  , py::arg("thePath"),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def_static("ReadAscii_s",
                    (handle<Poly_Triangulation> (*)(  const OSD_Path & ,   const Message_ProgressRange &  ) ) static_cast<handle<Poly_Triangulation> (*)(  const OSD_Path & ,   const Message_ProgressRange &  ) >(&RWStl::ReadAscii),
                    R"#(Read triangulation from an Ascii STL file In case of error, returns Null handle.)#"  , py::arg("thePath"),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def_static("ReadBinaryStream_s",
                    (handle<Poly_Triangulation> (*)( Standard_IStream & ,   const double ,   const Message_ProgressRange &  ) ) static_cast<handle<Poly_Triangulation> (*)( Standard_IStream & ,   const double ,   const Message_ProgressRange &  ) >(&RWStl::ReadBinaryStream),
                    R"#(Read triangulation from binary STL stream In case of error, returns Null handle.)#"  , py::arg("theStream"),  py::arg("theMergeAngle")=static_cast< const double>(M_PI / 2.0),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def_static("ReadAsciiStream_s",
                    (handle<Poly_Triangulation> (*)( Standard_IStream & ,   const double ,   const Message_ProgressRange &  ) ) static_cast<handle<Poly_Triangulation> (*)( Standard_IStream & ,   const double ,   const Message_ProgressRange &  ) >(&RWStl::ReadAsciiStream),
                    R"#(Read triangulation from ASCII STL stream In case of error, returns Null handle.)#"  , py::arg("theStream"),  py::arg("theMergeAngle")=static_cast< const double>(M_PI / 2.0),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def_static("ReadStream_s",
                    (handle<Poly_Triangulation> (*)( Standard_IStream & ,   const double ,   const Message_ProgressRange &  ) ) static_cast<handle<Poly_Triangulation> (*)( Standard_IStream & ,   const double ,   const Message_ProgressRange &  ) >(&RWStl::ReadStream),
                    R"#(Read STL data from stream (auto-detects ASCII vs Binary) In case of error, returns Null handle.)#"  , py::arg("theStream"),  py::arg("theMergeAngle")=static_cast< const double>(M_PI / 2.0),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class RWStl_Reader from ./opencascade/RWStl_Reader.hxx
    klass = m.attr("RWStl_Reader");


    // nested enums

    static_cast<py::class_<RWStl_Reader ,opencascade::handle<RWStl_Reader> ,Py_RWStl_Reader , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Read",
             (bool (RWStl_Reader::*)(  const char * ,   const Message_ProgressRange &  ) ) static_cast<bool (RWStl_Reader::*)(  const char * ,   const Message_ProgressRange &  ) >(&RWStl_Reader::Read),
             R"#(Reads data from STL file (either binary or Ascii). This function supports reading multi-domain STL files formed by concatenation of several "plain" files. The mesh nodes are not merged between domains. Unicode paths can be given in UTF-8 encoding. Format is recognized automatically by analysis of the file header. Returns true if success, false on error or user break.)#"  , py::arg("theFile"),  py::arg("theProgress")
          )
        .def("IsAscii",
             (bool (RWStl_Reader::*)( Standard_IStream & ,   const bool  ) ) static_cast<bool (RWStl_Reader::*)( Standard_IStream & ,   const bool  ) >(&RWStl_Reader::IsAscii),
             R"#(Guess whether the stream is an Ascii STL file, by analysis of the first bytes (~200). If the stream does not support seekg() then the parameter isSeekgAvailable should be passed as 'false', in this case the function attempts to put back the read symbols to the stream which thus must support ungetc(). Returns true if the stream seems to contain Ascii STL.)#"  , py::arg("theStream"),  py::arg("isSeekgAvailable")
          )
        .def("ReadBinary",
             (bool (RWStl_Reader::*)( Standard_IStream & ,   const Message_ProgressRange &  ) ) static_cast<bool (RWStl_Reader::*)( Standard_IStream & ,   const Message_ProgressRange &  ) >(&RWStl_Reader::ReadBinary),
             R"#(Reads STL data from binary stream. The stream must be opened in binary mode. Stops after reading the number of triangles recorded in the file header. Returns true if success, false on error or user break.)#"  , py::arg("theStream"),  py::arg("theProgress")
          )
        .def("AddNode",
             (int (RWStl_Reader::*)(  const gp_XYZ &  ) ) static_cast<int (RWStl_Reader::*)(  const gp_XYZ &  ) >(&RWStl_Reader::AddNode),
             R"#(Callback function to be implemented in descendant. Should create new node with specified coordinates in the target model, and return its ID as integer.)#"  , py::arg("thePnt")
          )
        .def("AddTriangle",
             (void (RWStl_Reader::*)( int ,  int ,  int  ) ) static_cast<void (RWStl_Reader::*)( int ,  int ,  int  ) >(&RWStl_Reader::AddTriangle),
             R"#(Callback function to be implemented in descendant. Should create new triangle built on specified nodes in the target model.)#"  , py::arg("theN1"),  py::arg("theN2"),  py::arg("theN3")
          )
        .def("AddSolid",
             (void (RWStl_Reader::*)() ) static_cast<void (RWStl_Reader::*)() >(&RWStl_Reader::AddSolid),
             R"#(Callback function to be implemented in descendant. Should create a new triangulation for a solid in multi-domain case.)#" 
          )
        .def("MergeAngle",
             (double (RWStl_Reader::*)() const) static_cast<double (RWStl_Reader::*)() const>(&RWStl_Reader::MergeAngle),
             R"#(Return merge tolerance; M_PI/2 by default - all nodes are merged regardless angle between triangles.)#" 
          )
        .def("SetMergeAngle",
             (void (RWStl_Reader::*)( double  ) ) static_cast<void (RWStl_Reader::*)( double  ) >(&RWStl_Reader::SetMergeAngle),
             R"#(Set merge angle in radians. Specify something like M_PI/4 (45 degrees) to avoid merge nodes between triangles at sharp corners.)#"  , py::arg("theAngleRad")
          )
        .def("MergeTolerance",
             (double (RWStl_Reader::*)() const) static_cast<double (RWStl_Reader::*)() const>(&RWStl_Reader::MergeTolerance),
             R"#(Return linear merge tolerance; 0.0 by default (only 3D points with exactly matching coordinates are merged).)#" 
          )
        .def("SetMergeTolerance",
             (void (RWStl_Reader::*)( double  ) ) static_cast<void (RWStl_Reader::*)( double  ) >(&RWStl_Reader::SetMergeTolerance),
             R"#(Set linear merge tolerance.)#"  , py::arg("theTolerance")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&RWStl_Reader::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&RWStl_Reader::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (RWStl_Reader::*)() const) static_cast< const handle<Standard_Type> & (RWStl_Reader::*)() const>(&RWStl_Reader::DynamicType),
             R"#()#"
             
         )
;

// functions

// ./opencascade/RWStl.hxx
// ./opencascade/RWStl_Reader.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
