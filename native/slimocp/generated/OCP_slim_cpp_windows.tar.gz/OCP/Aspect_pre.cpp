
// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;


// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Aspect_DisplayConnection.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Aspect_ScrollDelta.hxx>
#include <WNT_HIDSpaceMouse.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_ArrayOfTriangles.hxx>
#include <Image_Texture.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <Aspect_AspectFillAreaDefinitionError.hxx>
#include <Aspect_AspectLineDefinitionError.hxx>
#include <Aspect_AspectMarkerDefinitionError.hxx>
#include <Aspect_Background.hxx>
#include <Aspect_CircularGrid.hxx>
#include <Aspect_ColorSpace.hxx>
#include <Aspect_Display.hxx>
#include <Aspect_DisplayConnection.hxx>
#include <Aspect_DisplayConnectionDefinitionError.hxx>
#include <Aspect_Drawable.hxx>
#include <Aspect_Eye.hxx>
#include <Aspect_FBConfig.hxx>
#include <Aspect_FillMethod.hxx>
#include <Aspect_FrustumLRBT.hxx>
#include <Aspect_GenId.hxx>
#include <Aspect_GradientBackground.hxx>
#include <Aspect_GradientFillMethod.hxx>
#include <Aspect_GraphicDeviceDefinitionError.hxx>
#include <Aspect_GraphicsLibrary.hxx>
#include <Aspect_Grid.hxx>
#include <Aspect_GridDrawMode.hxx>
#include <Aspect_GridParams.hxx>
#include <Aspect_GridType.hxx>
#include <Aspect_Handle.hxx>
#include <Aspect_HatchStyle.hxx>
#include <Aspect_IdentDefinitionError.hxx>
#include <Aspect_InteriorStyle.hxx>
#include <Aspect_NeutralWindow.hxx>
#include <Aspect_OpenVRSession.hxx>
#include <Aspect_PolygonOffsetMode.hxx>
#include <Aspect_RectangularGrid.hxx>
#include <Aspect_RenderingContext.hxx>
#include <Aspect_ScrollDelta.hxx>
#include <Aspect_SkydomeBackground.hxx>
#include <Aspect_Touch.hxx>
#include <Aspect_TrackedDevicePose.hxx>
#include <Aspect_TypeOfColorScaleData.hxx>
#include <Aspect_TypeOfColorScaleOrientation.hxx>
#include <Aspect_TypeOfColorScalePosition.hxx>
#include <Aspect_TypeOfDeflection.hxx>
#include <Aspect_TypeOfDisplayText.hxx>
#include <Aspect_TypeOfFacingModel.hxx>
#include <Aspect_TypeOfHighlightMethod.hxx>
#include <Aspect_TypeOfLine.hxx>
#include <Aspect_TypeOfMarker.hxx>
#include <Aspect_TypeOfResize.hxx>
#include <Aspect_TypeOfStyleText.hxx>
#include <Aspect_TypeOfTriedronPosition.hxx>
#include <Aspect_Units.hxx>
#include <Aspect_VKey.hxx>
#include <Aspect_VKeyFlags.hxx>
#include <Aspect_WidthOfLine.hxx>
#include <Aspect_Window.hxx>
#include <Aspect_WindowDefinitionError.hxx>
#include <Aspect_WindowError.hxx>
#include <Aspect_WindowInputListener.hxx>
#include <Aspect_XAtom.hxx>
#include <Aspect_XRAction.hxx>
#include <Aspect_XRActionSet.hxx>
#include <Aspect_XRActionType.hxx>
#include <Aspect_XRAnalogActionData.hxx>
#include <Aspect_XRDigitalActionData.hxx>
#include <Aspect_XRGenericAction.hxx>
#include <Aspect_XRHapticActionData.hxx>
#include <Aspect_XRPoseActionData.hxx>
#include <Aspect_XRSession.hxx>
#include <Aspect_XRTrackedDeviceRole.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module
struct __GLXFBConfigRec {};
struct Aspect_XVisualInfo {};
#include <WNT_HIDSpaceMouse.hxx>


// Module definiiton
void register_Aspect_enums(py::module &main_module) {


py::module m = main_module.def_submodule("Aspect", R"#()#");

// add namespaces as submodules

// user-defined inclusion per module in the body

// enums
    py::enum_<Aspect_XRGenericAction>(m, "Aspect_XRGenericAction",R"#(Generic XR action.)#")
        .value("Aspect_XRGenericAction_IsHeadsetOn",Aspect_XRGenericAction::Aspect_XRGenericAction_IsHeadsetOn)
        .value("Aspect_XRGenericAction_InputAppMenu",Aspect_XRGenericAction::Aspect_XRGenericAction_InputAppMenu)
        .value("Aspect_XRGenericAction_InputSysMenu",Aspect_XRGenericAction::Aspect_XRGenericAction_InputSysMenu)
        .value("Aspect_XRGenericAction_InputTriggerPull",Aspect_XRGenericAction::Aspect_XRGenericAction_InputTriggerPull)
        .value("Aspect_XRGenericAction_InputTriggerClick",Aspect_XRGenericAction::Aspect_XRGenericAction_InputTriggerClick)
        .value("Aspect_XRGenericAction_InputGripClick",Aspect_XRGenericAction::Aspect_XRGenericAction_InputGripClick)
        .value("Aspect_XRGenericAction_InputTrackPadPosition",Aspect_XRGenericAction::Aspect_XRGenericAction_InputTrackPadPosition)
        .value("Aspect_XRGenericAction_InputTrackPadTouch",Aspect_XRGenericAction::Aspect_XRGenericAction_InputTrackPadTouch)
        .value("Aspect_XRGenericAction_InputTrackPadClick",Aspect_XRGenericAction::Aspect_XRGenericAction_InputTrackPadClick)
        .value("Aspect_XRGenericAction_InputThumbstickPosition",Aspect_XRGenericAction::Aspect_XRGenericAction_InputThumbstickPosition)
        .value("Aspect_XRGenericAction_InputThumbstickTouch",Aspect_XRGenericAction::Aspect_XRGenericAction_InputThumbstickTouch)
        .value("Aspect_XRGenericAction_InputThumbstickClick",Aspect_XRGenericAction::Aspect_XRGenericAction_InputThumbstickClick)
        .value("Aspect_XRGenericAction_InputPoseBase",Aspect_XRGenericAction::Aspect_XRGenericAction_InputPoseBase)
        .value("Aspect_XRGenericAction_InputPoseFront",Aspect_XRGenericAction::Aspect_XRGenericAction_InputPoseFront)
        .value("Aspect_XRGenericAction_InputPoseHandGrip",Aspect_XRGenericAction::Aspect_XRGenericAction_InputPoseHandGrip)
        .value("Aspect_XRGenericAction_InputPoseFingerTip",Aspect_XRGenericAction::Aspect_XRGenericAction_InputPoseFingerTip)
        .value("Aspect_XRGenericAction_OutputHaptic",Aspect_XRGenericAction::Aspect_XRGenericAction_OutputHaptic).export_values();
    m.attr("Aspect_XRGenericAction_NB") = py::cast(int(Aspect_XRGenericAction_NB));
    py::enum_<Aspect_GraphicsLibrary>(m, "Aspect_GraphicsLibrary",R"#(Graphics API enumeration.)#")
        .value("Aspect_GraphicsLibrary_OpenGL",Aspect_GraphicsLibrary::Aspect_GraphicsLibrary_OpenGL)
        .value("Aspect_GraphicsLibrary_OpenGLES",Aspect_GraphicsLibrary::Aspect_GraphicsLibrary_OpenGLES).export_values();
    py::enum_<Aspect_TypeOfDeflection>(m, "Aspect_TypeOfDeflection",R"#(Defines if the maximal chordial deflection used when drawing an object is absolute or relative to the size of the object.)#")
        .value("Aspect_TOD_RELATIVE",Aspect_TypeOfDeflection::Aspect_TOD_RELATIVE)
        .value("Aspect_TOD_ABSOLUTE",Aspect_TypeOfDeflection::Aspect_TOD_ABSOLUTE).export_values();
    py::enum_<Aspect_TypeOfColorScalePosition>(m, "Aspect_TypeOfColorScalePosition",R"#(Defines the type of position for color scale labels)#")
        .value("Aspect_TOCSP_NONE",Aspect_TypeOfColorScalePosition::Aspect_TOCSP_NONE)
        .value("Aspect_TOCSP_LEFT",Aspect_TypeOfColorScalePosition::Aspect_TOCSP_LEFT)
        .value("Aspect_TOCSP_RIGHT",Aspect_TypeOfColorScalePosition::Aspect_TOCSP_RIGHT)
        .value("Aspect_TOCSP_CENTER",Aspect_TypeOfColorScalePosition::Aspect_TOCSP_CENTER).export_values();
    py::enum_<Aspect_FillMethod>(m, "Aspect_FillMethod",R"#(Defines the fill methods to write bitmaps in a window.)#")
        .value("Aspect_FM_NONE",Aspect_FillMethod::Aspect_FM_NONE)
        .value("Aspect_FM_CENTERED",Aspect_FillMethod::Aspect_FM_CENTERED)
        .value("Aspect_FM_TILED",Aspect_FillMethod::Aspect_FM_TILED)
        .value("Aspect_FM_STRETCH",Aspect_FillMethod::Aspect_FM_STRETCH).export_values();
    py::enum_<Aspect_InteriorStyle>(m, "Aspect_InteriorStyle",R"#(Interior types for primitive faces.)#")
        .value("Aspect_IS_EMPTY",Aspect_InteriorStyle::Aspect_IS_EMPTY)
        .value("Aspect_IS_SOLID",Aspect_InteriorStyle::Aspect_IS_SOLID)
        .value("Aspect_IS_HATCH",Aspect_InteriorStyle::Aspect_IS_HATCH)
        .value("Aspect_IS_HIDDENLINE",Aspect_InteriorStyle::Aspect_IS_HIDDENLINE)
        .value("Aspect_IS_POINT",Aspect_InteriorStyle::Aspect_IS_POINT)
        .value("Aspect_IS_HOLLOW",Aspect_InteriorStyle::Aspect_IS_HOLLOW).export_values();
    m.attr("Aspect_VKeyFlags_NONE") = py::cast(int(Aspect_VKeyFlags_NONE));
    m.attr("Aspect_VKeyFlags_SHIFT") = py::cast(int(Aspect_VKeyFlags_SHIFT));
    m.attr("Aspect_VKeyFlags_CTRL") = py::cast(int(Aspect_VKeyFlags_CTRL));
    m.attr("Aspect_VKeyFlags_ALT") = py::cast(int(Aspect_VKeyFlags_ALT));
    m.attr("Aspect_VKeyFlags_MENU") = py::cast(int(Aspect_VKeyFlags_MENU));
    m.attr("Aspect_VKeyFlags_META") = py::cast(int(Aspect_VKeyFlags_META));
    m.attr("Aspect_VKeyFlags_ALL") = py::cast(int(Aspect_VKeyFlags_ALL));
    m.attr("Aspect_VKeyMouse_NONE") = py::cast(int(Aspect_VKeyMouse_NONE));
    m.attr("Aspect_VKeyMouse_LeftButton") = py::cast(int(Aspect_VKeyMouse_LeftButton));
    m.attr("Aspect_VKeyMouse_MiddleButton") = py::cast(int(Aspect_VKeyMouse_MiddleButton));
    m.attr("Aspect_VKeyMouse_RightButton") = py::cast(int(Aspect_VKeyMouse_RightButton));
    m.attr("Aspect_VKeyMouse_MainButtons") = py::cast(int(Aspect_VKeyMouse_MainButtons));
    py::enum_<Aspect_GridType>(m, "Aspect_GridType",R"#(Defines the grid type : Rectangular or Circular.)#")
        .value("Aspect_GT_Rectangular",Aspect_GridType::Aspect_GT_Rectangular)
        .value("Aspect_GT_Circular",Aspect_GridType::Aspect_GT_Circular).export_values();
    py::enum_<Aspect_PolygonOffsetMode>(m, "Aspect_PolygonOffsetMode",R"#()#")
        .value("Aspect_POM_Off",Aspect_PolygonOffsetMode::Aspect_POM_Off)
        .value("Aspect_POM_Fill",Aspect_PolygonOffsetMode::Aspect_POM_Fill)
        .value("Aspect_POM_Line",Aspect_PolygonOffsetMode::Aspect_POM_Line)
        .value("Aspect_POM_Point",Aspect_PolygonOffsetMode::Aspect_POM_Point)
        .value("Aspect_POM_All",Aspect_PolygonOffsetMode::Aspect_POM_All)
        .value("Aspect_POM_None",Aspect_PolygonOffsetMode::Aspect_POM_None)
        .value("Aspect_POM_Mask",Aspect_PolygonOffsetMode::Aspect_POM_Mask).export_values();
    py::enum_<Aspect_VKeyBasic>(m, "Aspect_VKeyBasic",R"#(Enumeration defining virtual keys irrelevant to current keyboard layout for simplified hot-keys management logic.)#")
        .value("Aspect_VKey_UNKNOWN",Aspect_VKeyBasic::Aspect_VKey_UNKNOWN)
        .value("Aspect_VKey_A",Aspect_VKeyBasic::Aspect_VKey_A)
        .value("Aspect_VKey_B",Aspect_VKeyBasic::Aspect_VKey_B)
        .value("Aspect_VKey_C",Aspect_VKeyBasic::Aspect_VKey_C)
        .value("Aspect_VKey_D",Aspect_VKeyBasic::Aspect_VKey_D)
        .value("Aspect_VKey_E",Aspect_VKeyBasic::Aspect_VKey_E)
        .value("Aspect_VKey_F",Aspect_VKeyBasic::Aspect_VKey_F)
        .value("Aspect_VKey_G",Aspect_VKeyBasic::Aspect_VKey_G)
        .value("Aspect_VKey_H",Aspect_VKeyBasic::Aspect_VKey_H)
        .value("Aspect_VKey_I",Aspect_VKeyBasic::Aspect_VKey_I)
        .value("Aspect_VKey_J",Aspect_VKeyBasic::Aspect_VKey_J)
        .value("Aspect_VKey_K",Aspect_VKeyBasic::Aspect_VKey_K)
        .value("Aspect_VKey_L",Aspect_VKeyBasic::Aspect_VKey_L)
        .value("Aspect_VKey_M",Aspect_VKeyBasic::Aspect_VKey_M)
        .value("Aspect_VKey_N",Aspect_VKeyBasic::Aspect_VKey_N)
        .value("Aspect_VKey_O",Aspect_VKeyBasic::Aspect_VKey_O)
        .value("Aspect_VKey_P",Aspect_VKeyBasic::Aspect_VKey_P)
        .value("Aspect_VKey_Q",Aspect_VKeyBasic::Aspect_VKey_Q)
        .value("Aspect_VKey_R",Aspect_VKeyBasic::Aspect_VKey_R)
        .value("Aspect_VKey_S",Aspect_VKeyBasic::Aspect_VKey_S)
        .value("Aspect_VKey_T",Aspect_VKeyBasic::Aspect_VKey_T)
        .value("Aspect_VKey_U",Aspect_VKeyBasic::Aspect_VKey_U)
        .value("Aspect_VKey_V",Aspect_VKeyBasic::Aspect_VKey_V)
        .value("Aspect_VKey_W",Aspect_VKeyBasic::Aspect_VKey_W)
        .value("Aspect_VKey_X",Aspect_VKeyBasic::Aspect_VKey_X)
        .value("Aspect_VKey_Y",Aspect_VKeyBasic::Aspect_VKey_Y)
        .value("Aspect_VKey_Z",Aspect_VKeyBasic::Aspect_VKey_Z)
        .value("Aspect_VKey_0",Aspect_VKeyBasic::Aspect_VKey_0)
        .value("Aspect_VKey_1",Aspect_VKeyBasic::Aspect_VKey_1)
        .value("Aspect_VKey_2",Aspect_VKeyBasic::Aspect_VKey_2)
        .value("Aspect_VKey_3",Aspect_VKeyBasic::Aspect_VKey_3)
        .value("Aspect_VKey_4",Aspect_VKeyBasic::Aspect_VKey_4)
        .value("Aspect_VKey_5",Aspect_VKeyBasic::Aspect_VKey_5)
        .value("Aspect_VKey_6",Aspect_VKeyBasic::Aspect_VKey_6)
        .value("Aspect_VKey_7",Aspect_VKeyBasic::Aspect_VKey_7)
        .value("Aspect_VKey_8",Aspect_VKeyBasic::Aspect_VKey_8)
        .value("Aspect_VKey_9",Aspect_VKeyBasic::Aspect_VKey_9)
        .value("Aspect_VKey_F1",Aspect_VKeyBasic::Aspect_VKey_F1)
        .value("Aspect_VKey_F2",Aspect_VKeyBasic::Aspect_VKey_F2)
        .value("Aspect_VKey_F3",Aspect_VKeyBasic::Aspect_VKey_F3)
        .value("Aspect_VKey_F4",Aspect_VKeyBasic::Aspect_VKey_F4)
        .value("Aspect_VKey_F5",Aspect_VKeyBasic::Aspect_VKey_F5)
        .value("Aspect_VKey_F6",Aspect_VKeyBasic::Aspect_VKey_F6)
        .value("Aspect_VKey_F7",Aspect_VKeyBasic::Aspect_VKey_F7)
        .value("Aspect_VKey_F8",Aspect_VKeyBasic::Aspect_VKey_F8)
        .value("Aspect_VKey_F9",Aspect_VKeyBasic::Aspect_VKey_F9)
        .value("Aspect_VKey_F10",Aspect_VKeyBasic::Aspect_VKey_F10)
        .value("Aspect_VKey_F11",Aspect_VKeyBasic::Aspect_VKey_F11)
        .value("Aspect_VKey_F12",Aspect_VKeyBasic::Aspect_VKey_F12)
        .value("Aspect_VKey_Up",Aspect_VKeyBasic::Aspect_VKey_Up)
        .value("Aspect_VKey_Down",Aspect_VKeyBasic::Aspect_VKey_Down)
        .value("Aspect_VKey_Left",Aspect_VKeyBasic::Aspect_VKey_Left)
        .value("Aspect_VKey_Right",Aspect_VKeyBasic::Aspect_VKey_Right)
        .value("Aspect_VKey_Plus",Aspect_VKeyBasic::Aspect_VKey_Plus)
        .value("Aspect_VKey_Minus",Aspect_VKeyBasic::Aspect_VKey_Minus)
        .value("Aspect_VKey_Equal",Aspect_VKeyBasic::Aspect_VKey_Equal)
        .value("Aspect_VKey_PageUp",Aspect_VKeyBasic::Aspect_VKey_PageUp)
        .value("Aspect_VKey_PageDown",Aspect_VKeyBasic::Aspect_VKey_PageDown)
        .value("Aspect_VKey_Home",Aspect_VKeyBasic::Aspect_VKey_Home)
        .value("Aspect_VKey_End",Aspect_VKeyBasic::Aspect_VKey_End)
        .value("Aspect_VKey_Escape",Aspect_VKeyBasic::Aspect_VKey_Escape)
        .value("Aspect_VKey_Back",Aspect_VKeyBasic::Aspect_VKey_Back)
        .value("Aspect_VKey_Enter",Aspect_VKeyBasic::Aspect_VKey_Enter)
        .value("Aspect_VKey_Backspace",Aspect_VKeyBasic::Aspect_VKey_Backspace)
        .value("Aspect_VKey_Space",Aspect_VKeyBasic::Aspect_VKey_Space)
        .value("Aspect_VKey_Delete",Aspect_VKeyBasic::Aspect_VKey_Delete)
        .value("Aspect_VKey_Tilde",Aspect_VKeyBasic::Aspect_VKey_Tilde)
        .value("Aspect_VKey_Tab",Aspect_VKeyBasic::Aspect_VKey_Tab)
        .value("Aspect_VKey_Comma",Aspect_VKeyBasic::Aspect_VKey_Comma)
        .value("Aspect_VKey_Period",Aspect_VKeyBasic::Aspect_VKey_Period)
        .value("Aspect_VKey_Semicolon",Aspect_VKeyBasic::Aspect_VKey_Semicolon)
        .value("Aspect_VKey_Slash",Aspect_VKeyBasic::Aspect_VKey_Slash)
        .value("Aspect_VKey_BracketLeft",Aspect_VKeyBasic::Aspect_VKey_BracketLeft)
        .value("Aspect_VKey_Backslash",Aspect_VKeyBasic::Aspect_VKey_Backslash)
        .value("Aspect_VKey_BracketRight",Aspect_VKeyBasic::Aspect_VKey_BracketRight)
        .value("Aspect_VKey_Apostrophe",Aspect_VKeyBasic::Aspect_VKey_Apostrophe)
        .value("Aspect_VKey_Numlock",Aspect_VKeyBasic::Aspect_VKey_Numlock)
        .value("Aspect_VKey_Scroll",Aspect_VKeyBasic::Aspect_VKey_Scroll)
        .value("Aspect_VKey_Numpad0",Aspect_VKeyBasic::Aspect_VKey_Numpad0)
        .value("Aspect_VKey_Numpad1",Aspect_VKeyBasic::Aspect_VKey_Numpad1)
        .value("Aspect_VKey_Numpad2",Aspect_VKeyBasic::Aspect_VKey_Numpad2)
        .value("Aspect_VKey_Numpad3",Aspect_VKeyBasic::Aspect_VKey_Numpad3)
        .value("Aspect_VKey_Numpad4",Aspect_VKeyBasic::Aspect_VKey_Numpad4)
        .value("Aspect_VKey_Numpad5",Aspect_VKeyBasic::Aspect_VKey_Numpad5)
        .value("Aspect_VKey_Numpad6",Aspect_VKeyBasic::Aspect_VKey_Numpad6)
        .value("Aspect_VKey_Numpad7",Aspect_VKeyBasic::Aspect_VKey_Numpad7)
        .value("Aspect_VKey_Numpad8",Aspect_VKeyBasic::Aspect_VKey_Numpad8)
        .value("Aspect_VKey_Numpad9",Aspect_VKeyBasic::Aspect_VKey_Numpad9)
        .value("Aspect_VKey_NumpadMultiply",Aspect_VKeyBasic::Aspect_VKey_NumpadMultiply)
        .value("Aspect_VKey_NumpadAdd",Aspect_VKeyBasic::Aspect_VKey_NumpadAdd)
        .value("Aspect_VKey_NumpadSubtract",Aspect_VKeyBasic::Aspect_VKey_NumpadSubtract)
        .value("Aspect_VKey_NumpadDivide",Aspect_VKeyBasic::Aspect_VKey_NumpadDivide)
        .value("Aspect_VKey_MediaNextTrack",Aspect_VKeyBasic::Aspect_VKey_MediaNextTrack)
        .value("Aspect_VKey_MediaPreviousTrack",Aspect_VKeyBasic::Aspect_VKey_MediaPreviousTrack)
        .value("Aspect_VKey_MediaStop",Aspect_VKeyBasic::Aspect_VKey_MediaStop)
        .value("Aspect_VKey_MediaPlayPause",Aspect_VKeyBasic::Aspect_VKey_MediaPlayPause)
        .value("Aspect_VKey_VolumeMute",Aspect_VKeyBasic::Aspect_VKey_VolumeMute)
        .value("Aspect_VKey_VolumeDown",Aspect_VKeyBasic::Aspect_VKey_VolumeDown)
        .value("Aspect_VKey_VolumeUp",Aspect_VKeyBasic::Aspect_VKey_VolumeUp)
        .value("Aspect_VKey_BrowserBack",Aspect_VKeyBasic::Aspect_VKey_BrowserBack)
        .value("Aspect_VKey_BrowserForward",Aspect_VKeyBasic::Aspect_VKey_BrowserForward)
        .value("Aspect_VKey_BrowserRefresh",Aspect_VKeyBasic::Aspect_VKey_BrowserRefresh)
        .value("Aspect_VKey_BrowserStop",Aspect_VKeyBasic::Aspect_VKey_BrowserStop)
        .value("Aspect_VKey_BrowserSearch",Aspect_VKeyBasic::Aspect_VKey_BrowserSearch)
        .value("Aspect_VKey_BrowserFavorites",Aspect_VKeyBasic::Aspect_VKey_BrowserFavorites)
        .value("Aspect_VKey_BrowserHome",Aspect_VKeyBasic::Aspect_VKey_BrowserHome)
        .value("Aspect_VKey_ViewTop",Aspect_VKeyBasic::Aspect_VKey_ViewTop)
        .value("Aspect_VKey_ViewBottom",Aspect_VKeyBasic::Aspect_VKey_ViewBottom)
        .value("Aspect_VKey_ViewLeft",Aspect_VKeyBasic::Aspect_VKey_ViewLeft)
        .value("Aspect_VKey_ViewRight",Aspect_VKeyBasic::Aspect_VKey_ViewRight)
        .value("Aspect_VKey_ViewFront",Aspect_VKeyBasic::Aspect_VKey_ViewFront)
        .value("Aspect_VKey_ViewBack",Aspect_VKeyBasic::Aspect_VKey_ViewBack)
        .value("Aspect_VKey_ViewAxoLeftProj",Aspect_VKeyBasic::Aspect_VKey_ViewAxoLeftProj)
        .value("Aspect_VKey_ViewAxoRightProj",Aspect_VKeyBasic::Aspect_VKey_ViewAxoRightProj)
        .value("Aspect_VKey_ViewFitAll",Aspect_VKeyBasic::Aspect_VKey_ViewFitAll)
        .value("Aspect_VKey_ViewRoll90CW",Aspect_VKeyBasic::Aspect_VKey_ViewRoll90CW)
        .value("Aspect_VKey_ViewRoll90CCW",Aspect_VKeyBasic::Aspect_VKey_ViewRoll90CCW)
        .value("Aspect_VKey_ViewSwitchRotate",Aspect_VKeyBasic::Aspect_VKey_ViewSwitchRotate)
        .value("Aspect_VKey_Shift",Aspect_VKeyBasic::Aspect_VKey_Shift)
        .value("Aspect_VKey_Control",Aspect_VKeyBasic::Aspect_VKey_Control)
        .value("Aspect_VKey_Alt",Aspect_VKeyBasic::Aspect_VKey_Alt)
        .value("Aspect_VKey_Menu",Aspect_VKeyBasic::Aspect_VKey_Menu)
        .value("Aspect_VKey_Meta",Aspect_VKeyBasic::Aspect_VKey_Meta)
        .value("Aspect_VKey_NavInteract",Aspect_VKeyBasic::Aspect_VKey_NavInteract)
        .value("Aspect_VKey_NavForward",Aspect_VKeyBasic::Aspect_VKey_NavForward)
        .value("Aspect_VKey_NavBackward",Aspect_VKeyBasic::Aspect_VKey_NavBackward)
        .value("Aspect_VKey_NavSlideLeft",Aspect_VKeyBasic::Aspect_VKey_NavSlideLeft)
        .value("Aspect_VKey_NavSlideRight",Aspect_VKeyBasic::Aspect_VKey_NavSlideRight)
        .value("Aspect_VKey_NavSlideUp",Aspect_VKeyBasic::Aspect_VKey_NavSlideUp)
        .value("Aspect_VKey_NavSlideDown",Aspect_VKeyBasic::Aspect_VKey_NavSlideDown)
        .value("Aspect_VKey_NavRollCCW",Aspect_VKeyBasic::Aspect_VKey_NavRollCCW)
        .value("Aspect_VKey_NavRollCW",Aspect_VKeyBasic::Aspect_VKey_NavRollCW)
        .value("Aspect_VKey_NavLookLeft",Aspect_VKeyBasic::Aspect_VKey_NavLookLeft)
        .value("Aspect_VKey_NavLookRight",Aspect_VKeyBasic::Aspect_VKey_NavLookRight)
        .value("Aspect_VKey_NavLookUp",Aspect_VKeyBasic::Aspect_VKey_NavLookUp)
        .value("Aspect_VKey_NavLookDown",Aspect_VKeyBasic::Aspect_VKey_NavLookDown)
        .value("Aspect_VKey_NavCrouch",Aspect_VKeyBasic::Aspect_VKey_NavCrouch)
        .value("Aspect_VKey_NavJump",Aspect_VKeyBasic::Aspect_VKey_NavJump)
        .value("Aspect_VKey_NavThrustForward",Aspect_VKeyBasic::Aspect_VKey_NavThrustForward)
        .value("Aspect_VKey_NavThrustBackward",Aspect_VKeyBasic::Aspect_VKey_NavThrustBackward)
        .value("Aspect_VKey_NavThrustStop",Aspect_VKeyBasic::Aspect_VKey_NavThrustStop)
        .value("Aspect_VKey_NavSpeedIncrease",Aspect_VKeyBasic::Aspect_VKey_NavSpeedIncrease)
        .value("Aspect_VKey_NavSpeedDecrease",Aspect_VKeyBasic::Aspect_VKey_NavSpeedDecrease).export_values();
    m.attr("Aspect_VKey_Lower") = py::cast(int(Aspect_VKey_Lower));
    m.attr("Aspect_VKey_ModifiersLower") = py::cast(int(Aspect_VKey_ModifiersLower));
    m.attr("Aspect_VKey_ModifiersUpper") = py::cast(int(Aspect_VKey_ModifiersUpper));
    m.attr("Aspect_VKey_NavigationKeysLower") = py::cast(int(Aspect_VKey_NavigationKeysLower));
    m.attr("Aspect_VKey_NavigationKeysUpper") = py::cast(int(Aspect_VKey_NavigationKeysUpper));
    m.attr("Aspect_VKey_Upper") = py::cast(int(Aspect_VKey_Upper));
    m.attr("Aspect_VKey_NB") = py::cast(int(Aspect_VKey_NB));
    m.attr("Aspect_VKey_MAX") = py::cast(int(Aspect_VKey_MAX));
    py::enum_<Aspect_TypeOfFacingModel>(m, "Aspect_TypeOfFacingModel",R"#()#")
        .value("Aspect_TOFM_BOTH_SIDE",Aspect_TypeOfFacingModel::Aspect_TOFM_BOTH_SIDE)
        .value("Aspect_TOFM_BACK_SIDE",Aspect_TypeOfFacingModel::Aspect_TOFM_BACK_SIDE)
        .value("Aspect_TOFM_FRONT_SIDE",Aspect_TypeOfFacingModel::Aspect_TOFM_FRONT_SIDE).export_values();
    py::enum_<Aspect_XRActionType>(m, "Aspect_XRActionType",R"#(XR action type.)#")
        .value("Aspect_XRActionType_InputDigital",Aspect_XRActionType::Aspect_XRActionType_InputDigital)
        .value("Aspect_XRActionType_InputAnalog",Aspect_XRActionType::Aspect_XRActionType_InputAnalog)
        .value("Aspect_XRActionType_InputPose",Aspect_XRActionType::Aspect_XRActionType_InputPose)
        .value("Aspect_XRActionType_InputSkeletal",Aspect_XRActionType::Aspect_XRActionType_InputSkeletal)
        .value("Aspect_XRActionType_OutputHaptic",Aspect_XRActionType::Aspect_XRActionType_OutputHaptic).export_values();
    py::enum_<Aspect_WidthOfLine>(m, "Aspect_WidthOfLine",R"#(Definition of line types)#")
        .value("Aspect_WOL_THIN",Aspect_WidthOfLine::Aspect_WOL_THIN)
        .value("Aspect_WOL_MEDIUM",Aspect_WidthOfLine::Aspect_WOL_MEDIUM)
        .value("Aspect_WOL_THICK",Aspect_WidthOfLine::Aspect_WOL_THICK)
        .value("Aspect_WOL_VERYTHICK",Aspect_WidthOfLine::Aspect_WOL_VERYTHICK)
        .value("Aspect_WOL_USERDEFINED",Aspect_WidthOfLine::Aspect_WOL_USERDEFINED).export_values();
    py::enum_<Aspect_XRTrackedDeviceRole>(m, "Aspect_XRTrackedDeviceRole",R"#(Predefined tracked devices.)#")
        .value("Aspect_XRTrackedDeviceRole_Head",Aspect_XRTrackedDeviceRole::Aspect_XRTrackedDeviceRole_Head)
        .value("Aspect_XRTrackedDeviceRole_LeftHand",Aspect_XRTrackedDeviceRole::Aspect_XRTrackedDeviceRole_LeftHand)
        .value("Aspect_XRTrackedDeviceRole_RightHand",Aspect_XRTrackedDeviceRole::Aspect_XRTrackedDeviceRole_RightHand)
        .value("Aspect_XRTrackedDeviceRole_Other",Aspect_XRTrackedDeviceRole::Aspect_XRTrackedDeviceRole_Other).export_values();
    m.attr("Aspect_XRTrackedDeviceRole_NB") = py::cast(int(Aspect_XRTrackedDeviceRole_NB));
    py::enum_<Aspect_TypeOfResize>(m, "Aspect_TypeOfResize",R"#(Defines the type of Resize Window method applied by the user.)#")
        .value("Aspect_TOR_UNKNOWN",Aspect_TypeOfResize::Aspect_TOR_UNKNOWN)
        .value("Aspect_TOR_NO_BORDER",Aspect_TypeOfResize::Aspect_TOR_NO_BORDER)
        .value("Aspect_TOR_TOP_BORDER",Aspect_TypeOfResize::Aspect_TOR_TOP_BORDER)
        .value("Aspect_TOR_RIGHT_BORDER",Aspect_TypeOfResize::Aspect_TOR_RIGHT_BORDER)
        .value("Aspect_TOR_BOTTOM_BORDER",Aspect_TypeOfResize::Aspect_TOR_BOTTOM_BORDER)
        .value("Aspect_TOR_LEFT_BORDER",Aspect_TypeOfResize::Aspect_TOR_LEFT_BORDER)
        .value("Aspect_TOR_TOP_AND_RIGHT_BORDER",Aspect_TypeOfResize::Aspect_TOR_TOP_AND_RIGHT_BORDER)
        .value("Aspect_TOR_RIGHT_AND_BOTTOM_BORDER",Aspect_TypeOfResize::Aspect_TOR_RIGHT_AND_BOTTOM_BORDER)
        .value("Aspect_TOR_BOTTOM_AND_LEFT_BORDER",Aspect_TypeOfResize::Aspect_TOR_BOTTOM_AND_LEFT_BORDER)
        .value("Aspect_TOR_LEFT_AND_TOP_BORDER",Aspect_TypeOfResize::Aspect_TOR_LEFT_AND_TOP_BORDER).export_values();
    py::enum_<Aspect_ColorSpace>(m, "Aspect_ColorSpace",R"#(Texture color spaces accepted by XR composer.)#")
        .value("Aspect_ColorSpace_sRGB",Aspect_ColorSpace::Aspect_ColorSpace_sRGB)
        .value("Aspect_ColorSpace_Linear",Aspect_ColorSpace::Aspect_ColorSpace_Linear).export_values();
    py::enum_<Aspect_XAtom>(m, "Aspect_XAtom",R"#(Defines custom identifiers(atoms) for X window custom named properties)#")
        .value("Aspect_XA_DELETE_WINDOW",Aspect_XAtom::Aspect_XA_DELETE_WINDOW).export_values();
    py::enum_<Aspect_TypeOfStyleText>(m, "Aspect_TypeOfStyleText",R"#(Define the style of the text.)#")
        .value("Aspect_TOST_NORMAL",Aspect_TypeOfStyleText::Aspect_TOST_NORMAL)
        .value("Aspect_TOST_ANNOTATION",Aspect_TypeOfStyleText::Aspect_TOST_ANNOTATION).export_values();
    py::enum_<Aspect_TypeOfDisplayText>(m, "Aspect_TypeOfDisplayText",R"#(Define the display type of the text.)#")
        .value("Aspect_TODT_NORMAL",Aspect_TypeOfDisplayText::Aspect_TODT_NORMAL)
        .value("Aspect_TODT_SUBTITLE",Aspect_TypeOfDisplayText::Aspect_TODT_SUBTITLE)
        .value("Aspect_TODT_DEKALE",Aspect_TypeOfDisplayText::Aspect_TODT_DEKALE)
        .value("Aspect_TODT_BLEND",Aspect_TypeOfDisplayText::Aspect_TODT_BLEND)
        .value("Aspect_TODT_DIMENSION",Aspect_TypeOfDisplayText::Aspect_TODT_DIMENSION)
        .value("Aspect_TODT_SHADOW",Aspect_TypeOfDisplayText::Aspect_TODT_SHADOW).export_values();
    py::enum_<Aspect_TypeOfColorScaleData>(m, "Aspect_TypeOfColorScaleData",R"#(Defines the using type of colors and labels)#")
        .value("Aspect_TOCSD_AUTO",Aspect_TypeOfColorScaleData::Aspect_TOCSD_AUTO)
        .value("Aspect_TOCSD_USER",Aspect_TypeOfColorScaleData::Aspect_TOCSD_USER).export_values();
    py::enum_<Aspect_HatchStyle>(m, "Aspect_HatchStyle",R"#(Definition of all available hatch styles.)#")
        .value("Aspect_HS_SOLID",Aspect_HatchStyle::Aspect_HS_SOLID)
        .value("Aspect_HS_HORIZONTAL",Aspect_HatchStyle::Aspect_HS_HORIZONTAL)
        .value("Aspect_HS_HORIZONTAL_WIDE",Aspect_HatchStyle::Aspect_HS_HORIZONTAL_WIDE)
        .value("Aspect_HS_VERTICAL",Aspect_HatchStyle::Aspect_HS_VERTICAL)
        .value("Aspect_HS_VERTICAL_WIDE",Aspect_HatchStyle::Aspect_HS_VERTICAL_WIDE)
        .value("Aspect_HS_DIAGONAL_45",Aspect_HatchStyle::Aspect_HS_DIAGONAL_45)
        .value("Aspect_HS_DIAGONAL_45_WIDE",Aspect_HatchStyle::Aspect_HS_DIAGONAL_45_WIDE)
        .value("Aspect_HS_DIAGONAL_135",Aspect_HatchStyle::Aspect_HS_DIAGONAL_135)
        .value("Aspect_HS_DIAGONAL_135_WIDE",Aspect_HatchStyle::Aspect_HS_DIAGONAL_135_WIDE)
        .value("Aspect_HS_GRID",Aspect_HatchStyle::Aspect_HS_GRID)
        .value("Aspect_HS_GRID_WIDE",Aspect_HatchStyle::Aspect_HS_GRID_WIDE)
        .value("Aspect_HS_GRID_DIAGONAL",Aspect_HatchStyle::Aspect_HS_GRID_DIAGONAL)
        .value("Aspect_HS_GRID_DIAGONAL_WIDE",Aspect_HatchStyle::Aspect_HS_GRID_DIAGONAL_WIDE)
        .value("Aspect_HS_NB",Aspect_HatchStyle::Aspect_HS_NB).export_values();
    py::enum_<Aspect_TypeOfLine>(m, "Aspect_TypeOfLine",R"#(Definition of line types)#")
        .value("Aspect_TOL_EMPTY",Aspect_TypeOfLine::Aspect_TOL_EMPTY)
        .value("Aspect_TOL_SOLID",Aspect_TypeOfLine::Aspect_TOL_SOLID)
        .value("Aspect_TOL_DASH",Aspect_TypeOfLine::Aspect_TOL_DASH)
        .value("Aspect_TOL_DOT",Aspect_TypeOfLine::Aspect_TOL_DOT)
        .value("Aspect_TOL_DOTDASH",Aspect_TypeOfLine::Aspect_TOL_DOTDASH)
        .value("Aspect_TOL_USERDEFINED",Aspect_TypeOfLine::Aspect_TOL_USERDEFINED).export_values();
    py::enum_<Aspect_TypeOfHighlightMethod>(m, "Aspect_TypeOfHighlightMethod",R"#(Definition of a highlight method)#")
        .value("Aspect_TOHM_COLOR",Aspect_TypeOfHighlightMethod::Aspect_TOHM_COLOR)
        .value("Aspect_TOHM_BOUNDBOX",Aspect_TypeOfHighlightMethod::Aspect_TOHM_BOUNDBOX).export_values();
    py::enum_<Aspect_GridDrawMode>(m, "Aspect_GridDrawMode",R"#(Defines the grid draw mode. The grid may be drawn by using lines or points.)#")
        .value("Aspect_GDM_Lines",Aspect_GridDrawMode::Aspect_GDM_Lines)
        .value("Aspect_GDM_Points",Aspect_GridDrawMode::Aspect_GDM_Points)
        .value("Aspect_GDM_None",Aspect_GridDrawMode::Aspect_GDM_None).export_values();
    py::enum_<Aspect_TypeOfTriedronPosition>(m, "Aspect_TypeOfTriedronPosition",R"#(Definition of the Trihedron position in the views. It is defined as a bitmask to simplify handling vertical and horizontal alignment independently.)#")
        .value("Aspect_TOTP_CENTER",Aspect_TypeOfTriedronPosition::Aspect_TOTP_CENTER)
        .value("Aspect_TOTP_TOP",Aspect_TypeOfTriedronPosition::Aspect_TOTP_TOP)
        .value("Aspect_TOTP_BOTTOM",Aspect_TypeOfTriedronPosition::Aspect_TOTP_BOTTOM)
        .value("Aspect_TOTP_LEFT",Aspect_TypeOfTriedronPosition::Aspect_TOTP_LEFT)
        .value("Aspect_TOTP_RIGHT",Aspect_TypeOfTriedronPosition::Aspect_TOTP_RIGHT)
        .value("Aspect_TOTP_LEFT_LOWER",Aspect_TypeOfTriedronPosition::Aspect_TOTP_LEFT_LOWER)
        .value("Aspect_TOTP_LEFT_UPPER",Aspect_TypeOfTriedronPosition::Aspect_TOTP_LEFT_UPPER)
        .value("Aspect_TOTP_RIGHT_LOWER",Aspect_TypeOfTriedronPosition::Aspect_TOTP_RIGHT_LOWER)
        .value("Aspect_TOTP_RIGHT_UPPER",Aspect_TypeOfTriedronPosition::Aspect_TOTP_RIGHT_UPPER).export_values();
    py::enum_<Aspect_GradientFillMethod>(m, "Aspect_GradientFillMethod",R"#(Defines the fill methods to write gradient background in a window.)#")
        .value("Aspect_GradientFillMethod_None",Aspect_GradientFillMethod::Aspect_GradientFillMethod_None)
        .value("Aspect_GradientFillMethod_Horizontal",Aspect_GradientFillMethod::Aspect_GradientFillMethod_Horizontal)
        .value("Aspect_GradientFillMethod_Vertical",Aspect_GradientFillMethod::Aspect_GradientFillMethod_Vertical)
        .value("Aspect_GradientFillMethod_Diagonal1",Aspect_GradientFillMethod::Aspect_GradientFillMethod_Diagonal1)
        .value("Aspect_GradientFillMethod_Diagonal2",Aspect_GradientFillMethod::Aspect_GradientFillMethod_Diagonal2)
        .value("Aspect_GradientFillMethod_Corner1",Aspect_GradientFillMethod::Aspect_GradientFillMethod_Corner1)
        .value("Aspect_GradientFillMethod_Corner2",Aspect_GradientFillMethod::Aspect_GradientFillMethod_Corner2)
        .value("Aspect_GradientFillMethod_Corner3",Aspect_GradientFillMethod::Aspect_GradientFillMethod_Corner3)
        .value("Aspect_GradientFillMethod_Corner4",Aspect_GradientFillMethod::Aspect_GradientFillMethod_Corner4)
        .value("Aspect_GradientFillMethod_Elliptical",Aspect_GradientFillMethod::Aspect_GradientFillMethod_Elliptical)
        .value("Aspect_GFM_NONE",Aspect_GradientFillMethod::Aspect_GFM_NONE)
        .value("Aspect_GFM_HOR",Aspect_GradientFillMethod::Aspect_GFM_HOR)
        .value("Aspect_GFM_VER",Aspect_GradientFillMethod::Aspect_GFM_VER)
        .value("Aspect_GFM_DIAG1",Aspect_GradientFillMethod::Aspect_GFM_DIAG1)
        .value("Aspect_GFM_DIAG2",Aspect_GradientFillMethod::Aspect_GFM_DIAG2)
        .value("Aspect_GFM_CORNER1",Aspect_GradientFillMethod::Aspect_GFM_CORNER1)
        .value("Aspect_GFM_CORNER2",Aspect_GradientFillMethod::Aspect_GFM_CORNER2)
        .value("Aspect_GFM_CORNER3",Aspect_GradientFillMethod::Aspect_GFM_CORNER3)
        .value("Aspect_GFM_CORNER4",Aspect_GradientFillMethod::Aspect_GFM_CORNER4).export_values();
    py::enum_<Aspect_TypeOfColorScaleOrientation>(m, "Aspect_TypeOfColorScaleOrientation",R"#(Defines the type of color scale orientation)#")
        .value("Aspect_TOCSO_NONE",Aspect_TypeOfColorScaleOrientation::Aspect_TOCSO_NONE)
        .value("Aspect_TOCSO_LEFT",Aspect_TypeOfColorScaleOrientation::Aspect_TOCSO_LEFT)
        .value("Aspect_TOCSO_RIGHT",Aspect_TypeOfColorScaleOrientation::Aspect_TOCSO_RIGHT)
        .value("Aspect_TOCSO_CENTER",Aspect_TypeOfColorScaleOrientation::Aspect_TOCSO_CENTER).export_values();
    py::enum_<Aspect_TypeOfMarker>(m, "Aspect_TypeOfMarker",R"#(Definition of types of markers)#")
        .value("Aspect_TOM_EMPTY",Aspect_TypeOfMarker::Aspect_TOM_EMPTY)
        .value("Aspect_TOM_POINT",Aspect_TypeOfMarker::Aspect_TOM_POINT)
        .value("Aspect_TOM_PLUS",Aspect_TypeOfMarker::Aspect_TOM_PLUS)
        .value("Aspect_TOM_STAR",Aspect_TypeOfMarker::Aspect_TOM_STAR)
        .value("Aspect_TOM_X",Aspect_TypeOfMarker::Aspect_TOM_X)
        .value("Aspect_TOM_O",Aspect_TypeOfMarker::Aspect_TOM_O)
        .value("Aspect_TOM_O_POINT",Aspect_TypeOfMarker::Aspect_TOM_O_POINT)
        .value("Aspect_TOM_O_PLUS",Aspect_TypeOfMarker::Aspect_TOM_O_PLUS)
        .value("Aspect_TOM_O_STAR",Aspect_TypeOfMarker::Aspect_TOM_O_STAR)
        .value("Aspect_TOM_O_X",Aspect_TypeOfMarker::Aspect_TOM_O_X)
        .value("Aspect_TOM_RING1",Aspect_TypeOfMarker::Aspect_TOM_RING1)
        .value("Aspect_TOM_RING2",Aspect_TypeOfMarker::Aspect_TOM_RING2)
        .value("Aspect_TOM_RING3",Aspect_TypeOfMarker::Aspect_TOM_RING3)
        .value("Aspect_TOM_BALL",Aspect_TypeOfMarker::Aspect_TOM_BALL)
        .value("Aspect_TOM_USERDEFINED",Aspect_TypeOfMarker::Aspect_TOM_USERDEFINED).export_values();
    py::enum_<Aspect_Eye>(m, "Aspect_Eye",R"#(Camera eye index within stereoscopic pair.)#")
        .value("Aspect_Eye_Left",Aspect_Eye::Aspect_Eye_Left)
        .value("Aspect_Eye_Right",Aspect_Eye::Aspect_Eye_Right).export_values();

//Python trampoline classes
    class Py_Aspect_Grid : public Aspect_Grid{
    public:
        using Aspect_Grid::Aspect_Grid;


        // public pure virtual
        void Display() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Grid,Display,) };
        void Erase() const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Grid,Erase,) };
        bool IsDisplayed() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Grid,IsDisplayed,) };
        void Init() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Grid,Init,) };
        void Compute( const double X, const double Y,double & gridX,double & gridY) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Grid,Compute,X,Y,gridX,gridY) };


        // protected pure virtual
        void UpdateDisplay() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Grid,UpdateDisplay,) };


        // private pure virtual

    };
    class Py_Aspect_Window : public Aspect_Window{
    public:
        using Aspect_Window::Aspect_Window;


        // public pure virtual
        bool IsMapped() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Window,IsMapped,) };
        void Map() const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Window,Map,) };
        void Unmap() const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Window,Unmap,) };
        Aspect_TypeOfResize DoResize() override { using return_type = Aspect_TypeOfResize;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Window,DoResize,) };
        bool DoMapping() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Window,DoMapping,) };
        double Ratio() const  override { using return_type = double;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Window,Ratio,) };
        Aspect_Drawable NativeHandle() const  override { using return_type = Aspect_Drawable;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Window,NativeHandle,) };
        Aspect_Drawable NativeParentHandle() const  override { using return_type = Aspect_Drawable;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Window,NativeParentHandle,) };
        void Position(int & X1,int & Y1,int & X2,int & Y2) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Window,Position,X1,Y1,X2,Y2) };
        void Size(int & Width,int & Height) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Window,Size,Width,Height) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_Aspect_WindowInputListener : public Aspect_WindowInputListener{
    public:
        using Aspect_WindowInputListener::Aspect_WindowInputListener;


        // public pure virtual
        void ProcessExpose() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_WindowInputListener,ProcessExpose,) };
        void ProcessConfigure(bool theIsResized) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_WindowInputListener,ProcessConfigure,theIsResized) };
        void ProcessInput() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_WindowInputListener,ProcessInput,) };
        void ProcessFocus(bool theIsActivated) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_WindowInputListener,ProcessFocus,theIsActivated) };
        void ProcessClose() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_WindowInputListener,ProcessClose,) };
        void KeyDown(Aspect_VKey theKey,double theTime,double thePressure) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_WindowInputListener,KeyDown,theKey,theTime,thePressure) };
        void KeyUp(Aspect_VKey theKey,double theTime) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_WindowInputListener,KeyUp,theKey,theTime) };
        void KeyFromAxis(Aspect_VKey theNegative,Aspect_VKey thePositive,double theTime,double thePressure) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_WindowInputListener,KeyFromAxis,theNegative,thePositive,theTime,thePressure) };
        bool UpdateMouseScroll( const Aspect_ScrollDelta & theDelta) override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_WindowInputListener,UpdateMouseScroll,theDelta) };
        bool UpdateMouseButtons( const NCollection_Vec2<int> & thePoint,Aspect_VKeyMouse theButtons,Aspect_VKeyFlags theModifiers,bool theIsEmulated) override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_WindowInputListener,UpdateMouseButtons,thePoint,theButtons,theModifiers,theIsEmulated) };
        bool UpdateMousePosition( const NCollection_Vec2<int> & thePoint,Aspect_VKeyMouse theButtons,Aspect_VKeyFlags theModifiers,bool theIsEmulated) override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_WindowInputListener,UpdateMousePosition,thePoint,theButtons,theModifiers,theIsEmulated) };
        bool Update3dMouse( const WNT_HIDSpaceMouse & theEvent) override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_WindowInputListener,Update3dMouse,theEvent) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_Aspect_XRSession : public Aspect_XRSession{
    public:
        using Aspect_XRSession::Aspect_XRSession;


        // public pure virtual
        bool IsOpen() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,IsOpen,) };
        bool Open() override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,Open,) };
        void Close() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,Close,) };
        bool WaitPoses() override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,WaitPoses,) };
        NCollection_Vec2<int> RecommendedViewport() const  override { using return_type = NCollection_Vec2<int>;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,RecommendedViewport,) };
        NCollection_Mat4<double> EyeToHeadTransform(Aspect_Eye theEye) const  override { using return_type = NCollection_Mat4<double>;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,EyeToHeadTransform,theEye) };
        NCollection_Mat4<double> ProjectionMatrix(Aspect_Eye theEye,double theZNear,double theZFar) const  override { using return_type = NCollection_Mat4<double>;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,ProjectionMatrix,theEye,theZNear,theZFar) };
        bool HasProjectionFrustums() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,HasProjectionFrustums,) };
        void ProcessEvents() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,ProcessEvents,) };
        bool SubmitEye(void * theTexture,Aspect_GraphicsLibrary theGraphicsLib,Aspect_ColorSpace theColorSpace,Aspect_Eye theEye) override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,SubmitEye,theTexture,theGraphicsLib,theColorSpace,theEye) };
        int NamedTrackedDevice(Aspect_XRTrackedDeviceRole theDevice) const  override { using return_type = int;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,NamedTrackedDevice,theDevice) };
        Aspect_XRDigitalActionData GetDigitalActionData( const handle<Aspect_XRAction> & theAction) const  override { using return_type = Aspect_XRDigitalActionData;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,GetDigitalActionData,theAction) };
        Aspect_XRAnalogActionData GetAnalogActionData( const handle<Aspect_XRAction> & theAction) const  override { using return_type = Aspect_XRAnalogActionData;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,GetAnalogActionData,theAction) };
        Aspect_XRPoseActionData GetPoseActionDataForNextFrame( const handle<Aspect_XRAction> & theAction) const  override { using return_type = Aspect_XRPoseActionData;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,GetPoseActionDataForNextFrame,theAction) };
        TCollection_AsciiString GetString(Aspect_XRSession::InfoString theInfo) const  override { using return_type = TCollection_AsciiString;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,GetString,theInfo) };


        // protected pure virtual
        handle<Graphic3d_ArrayOfTriangles> loadRenderModel(int theDevice,bool theToApplyUnitFactor,handle<Image_Texture> & theTexture) override { using return_type = handle<Graphic3d_ArrayOfTriangles>;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,loadRenderModel,theDevice,theToApplyUnitFactor,theTexture) };
        void triggerHapticVibrationAction( const handle<Aspect_XRAction> & theAction, const Aspect_XRHapticActionData & theParams) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,triggerHapticVibrationAction,theAction,theParams) };


        // private pure virtual

    };
    class Py_Aspect_CircularGrid : public Aspect_CircularGrid{
    public:
        using Aspect_CircularGrid::Aspect_CircularGrid;


        // public pure virtual

        void Display() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Grid,Display,) };
        void Erase() const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Grid,Erase,) };
        bool IsDisplayed() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Grid,IsDisplayed,) };

        // protected pure virtual

        void UpdateDisplay() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Grid,UpdateDisplay,) };

        // private pure virtual

    };
    class Py_Aspect_RectangularGrid : public Aspect_RectangularGrid{
    public:
        using Aspect_RectangularGrid::Aspect_RectangularGrid;


        // public pure virtual

        void Display() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Grid,Display,) };
        void Erase() const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Grid,Erase,) };
        bool IsDisplayed() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Grid,IsDisplayed,) };

        // protected pure virtual

        void UpdateDisplay() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Grid,UpdateDisplay,) };

        // private pure virtual

    };

// pre-register typdefs+classes (topologically sorted)
    py::class_<Aspect_Background , shared_ptr<Aspect_Background>  >(
      m,
      "Aspect_Background",R"#(This class allows the definition of a window background.)#"
    );
    py::class_<Aspect_GenId , shared_ptr<Aspect_GenId>  >(
      m,
      "Aspect_GenId",R"#(This class permits the creation and control of integer identifiers.)#"
    );
    py::class_<Aspect_GridParams , shared_ptr<Aspect_GridParams>  >(
      m,
      "Aspect_GridParams",R"#(Grid appearance for V3d_View::GridDisplay: color, scale, bounds, arc, draw mode, background and adaptive flags.)#"
    );
    py::class_<Aspect_ScrollDelta , shared_ptr<Aspect_ScrollDelta>  >(
      m,
      "Aspect_ScrollDelta",R"#(Parameters for mouse scroll action.)#"
    );
    py::class_<Aspect_SkydomeBackground , shared_ptr<Aspect_SkydomeBackground>  >(
      m,
      "Aspect_SkydomeBackground",R"#(This class allows the definition of a window skydome background.)#"
    );
    py::class_<Aspect_Touch , shared_ptr<Aspect_Touch>  >(
      m,
      "Aspect_Touch",R"#(Structure holding touch position - original and current location.)#"
    );
    py::class_<Aspect_TrackedDevicePose , shared_ptr<Aspect_TrackedDevicePose>  >(
      m,
      "Aspect_TrackedDevicePose",R"#(Describes a single pose for a tracked object (for XR).)#"
    );
    py::class_<Aspect_WindowInputListener , shared_ptr<Aspect_WindowInputListener> ,Py_Aspect_WindowInputListener >(
      m,
      "Aspect_WindowInputListener",R"#(Defines a listener for window input events.)#"
    );
    py::class_<Aspect_XRAnalogActionData , shared_ptr<Aspect_XRAnalogActionData>  >(
      m,
      "Aspect_XRAnalogActionData",R"#(Analog input XR action data.)#"
    );
    py::class_<Aspect_XRDigitalActionData , shared_ptr<Aspect_XRDigitalActionData>  >(
      m,
      "Aspect_XRDigitalActionData",R"#(Digital input XR action data.)#"
    );
    py::class_<Aspect_XRHapticActionData , shared_ptr<Aspect_XRHapticActionData>  >(
      m,
      "Aspect_XRHapticActionData",R"#(Haptic output XR action data.)#"
    );
    py::class_<Aspect_XRPoseActionData , shared_ptr<Aspect_XRPoseActionData>  >(
      m,
      "Aspect_XRPoseActionData",R"#(Pose input XR action data.)#"
    );
    py::class_<Aspect_DisplayConnection ,opencascade::handle<Aspect_DisplayConnection>  , Standard_Transient >(
      m,
      "Aspect_DisplayConnection",R"#(This class creates and provides connection with X server. Raises exception if can not connect to X server. On Windows and Mac OS X (in case when Cocoa used) platforms this class does nothing. WARNING: Do not close display connection manually!)#"
    );
    py::class_<Aspect_GradientBackground , shared_ptr<Aspect_GradientBackground>  , Aspect_Background >(
      m,
      "Aspect_GradientBackground",R"#(This class allows the definition of a window gradient background.)#"
    );
    py::class_<Aspect_Grid ,opencascade::handle<Aspect_Grid> ,Py_Aspect_Grid , Standard_Transient >(
      m,
      "Aspect_Grid",R"#()#"
    );
    py::class_<Aspect_Window ,opencascade::handle<Aspect_Window> ,Py_Aspect_Window , Standard_Transient >(
      m,
      "Aspect_Window",R"#(Defines a window.)#"
    );
    py::class_<Aspect_XRAction ,opencascade::handle<Aspect_XRAction>  , Standard_Transient >(
      m,
      "Aspect_XRAction",R"#(XR action definition.)#"
    );
    py::class_<Aspect_XRActionSet ,opencascade::handle<Aspect_XRActionSet>  , Standard_Transient >(
      m,
      "Aspect_XRActionSet",R"#(XR action set.)#"
    );
    py::class_<Aspect_XRSession ,opencascade::handle<Aspect_XRSession> ,Py_Aspect_XRSession , Standard_Transient >(
      m,
      "Aspect_XRSession",R"#(Extended Reality (XR) Session interface.)#"
    );
    py::class_<Aspect_CircularGrid ,opencascade::handle<Aspect_CircularGrid> ,Py_Aspect_CircularGrid , Aspect_Grid >(
      m,
      "Aspect_CircularGrid",R"#()#"
    );
    py::class_<Aspect_NeutralWindow ,opencascade::handle<Aspect_NeutralWindow>  , Aspect_Window >(
      m,
      "Aspect_NeutralWindow",R"#(Defines a platform-neutral window. This class is intended to be used in context when window management (including OpenGL context creation) is performed on application side (e.g. using external framework).)#"
    );
    py::class_<Aspect_OpenVRSession ,opencascade::handle<Aspect_OpenVRSession>  , Aspect_XRSession >(
      m,
      "Aspect_OpenVRSession",R"#(OpenVR wrapper implementing Aspect_XRSession interface.)#"
    );
    py::class_<Aspect_RectangularGrid ,opencascade::handle<Aspect_RectangularGrid> ,Py_Aspect_RectangularGrid , Aspect_Grid >(
      m,
      "Aspect_RectangularGrid",R"#()#"
    );

// preregister user-defined template specializations

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
