
// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;


// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_DeltaOnModification.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDataStd_TreeNode.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_GUID.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDataStd_ByteArray.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDataStd_ExtStringArray.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDataStd_IntegerArray.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TColStd_HPackedMapOfInteger.hxx>
#include <TDataStd_IntPackedMap.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDataStd_RealArray.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <Standard_GUID.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_GUID.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_DeltaOnModification.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_GUID.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_DeltaOnModification.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_DeltaOnModification.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDataStd_HDataMapOfStringInteger.hxx>
#include <TDataStd_HDataMapOfStringReal.hxx>
#include <TDataStd_HDataMapOfStringString.hxx>
#include <TDataStd_HDataMapOfStringByte.hxx>
#include <TDataStd_HDataMapOfStringHArray1OfInteger.hxx>
#include <TDataStd_HDataMapOfStringHArray1OfReal.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <Standard_GUID.hxx>
#include <TDataStd_Real.hxx>
#include <TDataStd_Integer.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDataStd_TreeNode.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_DeltaOnModification.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_DataSet.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_DataSet.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_GUID.hxx>
#include <TDF_Label.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_AttributeDelta.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_DataSet.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_DataSet.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_GUID.hxx>
#include <TDF_Label.hxx>
#include <TCollection_ExtendedString.hxx>
#include <TDataStd_Real.hxx>
#include <TDataStd_Expression.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_DataSet.hxx>

// module includes
#include <TDataStd.hxx>
#include <TDataStd_AsciiString.hxx>
#include <TDataStd_BooleanArray.hxx>
#include <TDataStd_BooleanList.hxx>
#include <TDataStd_ByteArray.hxx>
#include <TDataStd_ChildNodeIterator.hxx>
#include <TDataStd_Comment.hxx>
#include <TDataStd_Current.hxx>
#include <TDataStd_DeltaOnModificationOfByteArray.hxx>
#include <TDataStd_DeltaOnModificationOfExtStringArray.hxx>
#include <TDataStd_DeltaOnModificationOfIntArray.hxx>
#include <TDataStd_DeltaOnModificationOfIntPackedMap.hxx>
#include <TDataStd_DeltaOnModificationOfRealArray.hxx>
#include <TDataStd_Directory.hxx>
#include <TDataStd_Expression.hxx>
#include <TDataStd_ExtStringArray.hxx>
#include <TDataStd_ExtStringList.hxx>
#include <TDataStd_GenericEmpty.hxx>
#include <TDataStd_GenericExtString.hxx>
#include <TDataStd_HDataMapOfStringByte.hxx>
#include <TDataStd_HDataMapOfStringHArray1OfInteger.hxx>
#include <TDataStd_HDataMapOfStringHArray1OfReal.hxx>
#include <TDataStd_HDataMapOfStringInteger.hxx>
#include <TDataStd_HDataMapOfStringReal.hxx>
#include <TDataStd_HDataMapOfStringString.hxx>
#include <TDataStd_Integer.hxx>
#include <TDataStd_IntegerArray.hxx>
#include <TDataStd_IntegerList.hxx>
#include <TDataStd_IntPackedMap.hxx>
#include <TDataStd_Name.hxx>
#include <TDataStd_NamedData.hxx>
#include <TDataStd_NoteBook.hxx>
#include <TDataStd_PtrTreeNode.hxx>
#include <TDataStd_Real.hxx>
#include <TDataStd_RealArray.hxx>
#include <TDataStd_RealEnum.hxx>
#include <TDataStd_RealList.hxx>
#include <TDataStd_ReferenceArray.hxx>
#include <TDataStd_ReferenceList.hxx>
#include <TDataStd_Relation.hxx>
#include <TDataStd_Tick.hxx>
#include <TDataStd_TreeNode.hxx>
#include <TDataStd_UAttribute.hxx>
#include <TDataStd_Variable.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_TDataStd_enums(py::module &main_module) {


py::module m = main_module.def_submodule("TDataStd", R"#()#");

// add namespaces as submodules

// user-defined inclusion per module in the body

// enums
    py::enum_<TDataStd_RealEnum>(m, "TDataStd_RealEnum",R"#(The terms of this enumeration define the semantics of a real number value.)#")
        .value("TDataStd_SCALAR",TDataStd_RealEnum::TDataStd_SCALAR)
        .value("TDataStd_LENGTH",TDataStd_RealEnum::TDataStd_LENGTH)
        .value("TDataStd_ANGULAR",TDataStd_RealEnum::TDataStd_ANGULAR).export_values();

//Python trampoline classes
    class Py_TDataStd_GenericEmpty : public TDataStd_GenericEmpty{
    public:
        using TDataStd_GenericEmpty::TDataStd_GenericEmpty;


        // public pure virtual

         const Standard_GUID & ID() const  override { using return_type =  const Standard_GUID &;
    PYBIND11_OVERLOAD_PURE(return_type,TDF_Attribute,ID,) };
        handle<TDF_Attribute> NewEmpty() const  override { using return_type = handle<TDF_Attribute>;
    PYBIND11_OVERLOAD_PURE(return_type,TDF_Attribute,NewEmpty,) };

        // protected pure virtual


        // private pure virtual

    };
    class Py_TDataStd_GenericExtString : public TDataStd_GenericExtString{
    public:
        using TDataStd_GenericExtString::TDataStd_GenericExtString;


        // public pure virtual

        handle<TDF_Attribute> NewEmpty() const  override { using return_type = handle<TDF_Attribute>;
    PYBIND11_OVERLOAD_PURE(return_type,TDF_Attribute,NewEmpty,) };

        // protected pure virtual


        // private pure virtual

    };

// pre-register typdefs+classes (topologically sorted)
    py::class_<TDataStd , shared_ptr<TDataStd>  >(
      m,
      "TDataStd",R"#(This package defines standard attributes for modelling. These allow you to create and modify labels and attributes for many basic data types. Standard topological and visualization attributes have also been created. To find an attribute attached to a specific label, you use the GUID of the type of attribute you are looking for. To do this, first find this information using the method GetID as follows: Standard_GUID anID = MyAttributeClass::GetID(); Then, use the method Find for the label as follows: bool HasAttribute = aLabel.Find(anID,anAttribute); Note For information on the relations between this component of OCAF and the others, refer to the OCAF User's Guide.)#"
    );
    py::class_<TDataStd_ChildNodeIterator , shared_ptr<TDataStd_ChildNodeIterator>  >(
      m,
      "TDataStd_ChildNodeIterator",R"#(Iterates on the ChildStepren step of a step, at the first level only. It is possible to ask the iterator to explore all the sub step levels of the given one, with the option "allLevels".)#"
    );
    py::class_<TDataStd_AsciiString ,opencascade::handle<TDataStd_AsciiString>  , TDF_Attribute >(
      m,
      "TDataStd_AsciiString",R"#(Used to define an AsciiString attribute containing a TCollection_AsciiString)#"
    );
    py::class_<TDataStd_BooleanArray ,opencascade::handle<TDataStd_BooleanArray>  , TDF_Attribute >(
      m,
      "TDataStd_BooleanArray",R"#(An array of boolean values.)#"
    );
    py::class_<TDataStd_BooleanList ,opencascade::handle<TDataStd_BooleanList>  , TDF_Attribute >(
      m,
      "TDataStd_BooleanList",R"#(Contains a list of bolleans.)#"
    );
    py::class_<TDataStd_ByteArray ,opencascade::handle<TDataStd_ByteArray>  , TDF_Attribute >(
      m,
      "TDataStd_ByteArray",R"#(An array of Byte (unsigned char) values.)#"
    );
    py::class_<TDataStd_Current ,opencascade::handle<TDataStd_Current>  , TDF_Attribute >(
      m,
      "TDataStd_Current",R"#(this attribute, located at root label, manage an access to a current label.)#"
    );
    py::class_<TDataStd_DeltaOnModificationOfByteArray ,opencascade::handle<TDataStd_DeltaOnModificationOfByteArray>  , TDF_DeltaOnModification >(
      m,
      "TDataStd_DeltaOnModificationOfByteArray",R"#(This class provides default services for an AttributeDelta on a MODIFICATION action.)#"
    );
    py::class_<TDataStd_DeltaOnModificationOfExtStringArray ,opencascade::handle<TDataStd_DeltaOnModificationOfExtStringArray>  , TDF_DeltaOnModification >(
      m,
      "TDataStd_DeltaOnModificationOfExtStringArray",R"#(This class provides default services for an AttributeDelta on a MODIFICATION action.)#"
    );
    py::class_<TDataStd_DeltaOnModificationOfIntArray ,opencascade::handle<TDataStd_DeltaOnModificationOfIntArray>  , TDF_DeltaOnModification >(
      m,
      "TDataStd_DeltaOnModificationOfIntArray",R"#(This class provides default services for an AttributeDelta on a MODIFICATION action.)#"
    );
    py::class_<TDataStd_DeltaOnModificationOfIntPackedMap ,opencascade::handle<TDataStd_DeltaOnModificationOfIntPackedMap>  , TDF_DeltaOnModification >(
      m,
      "TDataStd_DeltaOnModificationOfIntPackedMap",R"#(This class provides default services for an AttributeDelta on a MODIFICATION action.)#"
    );
    py::class_<TDataStd_DeltaOnModificationOfRealArray ,opencascade::handle<TDataStd_DeltaOnModificationOfRealArray>  , TDF_DeltaOnModification >(
      m,
      "TDataStd_DeltaOnModificationOfRealArray",R"#(This class provides default services for an AttributeDelta on a MODIFICATION action)#"
    );
    py::class_<TDataStd_Expression ,opencascade::handle<TDataStd_Expression>  , TDF_Attribute >(
      m,
      "TDataStd_Expression",R"#(Expression attribute. ====================)#"
    );
    py::class_<TDataStd_ExtStringArray ,opencascade::handle<TDataStd_ExtStringArray>  , TDF_Attribute >(
      m,
      "TDataStd_ExtStringArray",R"#(ExtStringArray Attribute. Handles an array of UNICODE strings (represented by the TCollection_ExtendedString class).)#"
    );
    py::class_<TDataStd_ExtStringList ,opencascade::handle<TDataStd_ExtStringList>  , TDF_Attribute >(
      m,
      "TDataStd_ExtStringList",R"#(Contains a list of ExtendedString.)#"
    );
    py::class_<TDataStd_GenericEmpty ,opencascade::handle<TDataStd_GenericEmpty> ,Py_TDataStd_GenericEmpty , TDF_Attribute >(
      m,
      "TDataStd_GenericEmpty",R"#(An ancestor attribute for all attributes which have no fields. If an attribute inherits this one it should not have drivers for persistence.)#"
    );
    py::class_<TDataStd_GenericExtString ,opencascade::handle<TDataStd_GenericExtString> ,Py_TDataStd_GenericExtString , TDF_Attribute >(
      m,
      "TDataStd_GenericExtString",R"#(An ancestor attribute for all attributes which have TCollection_ExtendedString field. If an attribute inherits this one it should not have drivers for persistence. Also this attribute provides functionality to have on the same label same attributes with different IDs.)#"
    );
    py::class_<TDataStd_HDataMapOfStringByte ,opencascade::handle<TDataStd_HDataMapOfStringByte>  , Standard_Transient >(
      m,
      "TDataStd_HDataMapOfStringByte",R"#(Extension of NCollection_DataMap<TCollection_ExtendedString, uint8_t> class to be manipulated by handle.)#"
    );
    py::class_<TDataStd_HDataMapOfStringHArray1OfInteger ,opencascade::handle<TDataStd_HDataMapOfStringHArray1OfInteger>  , Standard_Transient >(
      m,
      "TDataStd_HDataMapOfStringHArray1OfInteger",R"#(Extension of NCollection_DataMap<TCollection_ExtendedString, occ::handle<NCollection_HArray1<int>>> class to be manipulated by handle.)#"
    );
    py::class_<TDataStd_HDataMapOfStringHArray1OfReal ,opencascade::handle<TDataStd_HDataMapOfStringHArray1OfReal>  , Standard_Transient >(
      m,
      "TDataStd_HDataMapOfStringHArray1OfReal",R"#(Extension of NCollection_DataMap<TCollection_ExtendedString, occ::handle<NCollection_HArray1<double>>> class to be manipulated by handle.)#"
    );
    py::class_<TDataStd_HDataMapOfStringInteger ,opencascade::handle<TDataStd_HDataMapOfStringInteger>  , Standard_Transient >(
      m,
      "TDataStd_HDataMapOfStringInteger",R"#(Extension of NCollection_DataMap<TCollection_ExtendedString, int> class to be manipulated by handle.)#"
    );
    py::class_<TDataStd_HDataMapOfStringReal ,opencascade::handle<TDataStd_HDataMapOfStringReal>  , Standard_Transient >(
      m,
      "TDataStd_HDataMapOfStringReal",R"#(Extension of NCollection_DataMap<TCollection_ExtendedString, double> class to be manipulated by handle.)#"
    );
    py::class_<TDataStd_HDataMapOfStringString ,opencascade::handle<TDataStd_HDataMapOfStringString>  , Standard_Transient >(
      m,
      "TDataStd_HDataMapOfStringString",R"#(Extension of NCollection_DataMap<TCollection_ExtendedString, TCollection_ExtendedString> class to be manipulated by handle.)#"
    );
    py::class_<TDataStd_IntPackedMap ,opencascade::handle<TDataStd_IntPackedMap>  , TDF_Attribute >(
      m,
      "TDataStd_IntPackedMap",R"#(Attribute for storing TColStd_PackedMapOfInteger)#"
    );
    py::class_<TDataStd_Integer ,opencascade::handle<TDataStd_Integer>  , TDF_Attribute >(
      m,
      "TDataStd_Integer",R"#(The basis to define an integer attribute.)#"
    );
    py::class_<TDataStd_IntegerArray ,opencascade::handle<TDataStd_IntegerArray>  , TDF_Attribute >(
      m,
      "TDataStd_IntegerArray",R"#(Contains an array of integers.)#"
    );
    py::class_<TDataStd_IntegerList ,opencascade::handle<TDataStd_IntegerList>  , TDF_Attribute >(
      m,
      "TDataStd_IntegerList",R"#(Contains a list of integers.)#"
    );
    py::class_<TDataStd_NamedData ,opencascade::handle<TDataStd_NamedData>  , TDF_Attribute >(
      m,
      "TDataStd_NamedData",R"#(Contains a named data.)#"
    );
    py::class_<TDataStd_Real ,opencascade::handle<TDataStd_Real>  , TDF_Attribute >(
      m,
      "TDataStd_Real",R"#(The basis to define a real number attribute.)#"
    );
    py::class_<TDataStd_RealArray ,opencascade::handle<TDataStd_RealArray>  , TDF_Attribute >(
      m,
      "TDataStd_RealArray",R"#(A framework for an attribute composed of a real number array.)#"
    );
    py::class_<TDataStd_RealList ,opencascade::handle<TDataStd_RealList>  , TDF_Attribute >(
      m,
      "TDataStd_RealList",R"#(Contains a list of doubles.)#"
    );
    py::class_<TDataStd_ReferenceArray ,opencascade::handle<TDataStd_ReferenceArray>  , TDF_Attribute >(
      m,
      "TDataStd_ReferenceArray",R"#(Contains an array of references to the labels.)#"
    );
    py::class_<TDataStd_ReferenceList ,opencascade::handle<TDataStd_ReferenceList>  , TDF_Attribute >(
      m,
      "TDataStd_ReferenceList",R"#(Contains a list of references.)#"
    );
    py::class_<TDataStd_TreeNode ,opencascade::handle<TDataStd_TreeNode>  , TDF_Attribute >(
      m,
      "TDataStd_TreeNode",R"#(Allows you to define an explicit tree of labels which you can also edit. Without this class, the data structure cannot be fully edited. This service is required if for presentation purposes, you want to create an application with a tree which allows you to organize and link data as a function of application features.)#"
    );
    py::class_<TDataStd_UAttribute ,opencascade::handle<TDataStd_UAttribute>  , TDF_Attribute >(
      m,
      "TDataStd_UAttribute",R"#()#"
    );
    py::class_<TDataStd_Variable ,opencascade::handle<TDataStd_Variable>  , TDF_Attribute >(
      m,
      "TDataStd_Variable",R"#(Variable attribute. ==================)#"
    );
    py::class_<TDataStd_Comment ,opencascade::handle<TDataStd_Comment>  , TDataStd_GenericExtString >(
      m,
      "TDataStd_Comment",R"#(Comment attribute. may be associated to any label to store user comment.)#"
    );
    py::class_<TDataStd_Directory ,opencascade::handle<TDataStd_Directory>  , TDataStd_GenericEmpty >(
      m,
      "TDataStd_Directory",R"#(Associates a directory in the data framework with a TDataStd_TagSource attribute. You can create a new directory label and add sub-directory or object labels to it,)#"
    );
    py::class_<TDataStd_Name ,opencascade::handle<TDataStd_Name>  , TDataStd_GenericExtString >(
      m,
      "TDataStd_Name",R"#(Used to define a name attribute containing a string which specifies the name.)#"
    );
    py::class_<TDataStd_NoteBook ,opencascade::handle<TDataStd_NoteBook>  , TDataStd_GenericEmpty >(
      m,
      "TDataStd_NoteBook",R"#(NoteBook Object attribute)#"
    );
    py::class_<TDataStd_Relation ,opencascade::handle<TDataStd_Relation>  , TDataStd_Expression >(
      m,
      "TDataStd_Relation",R"#(Relation attribute. ==================)#"
    );
    py::class_<TDataStd_Tick ,opencascade::handle<TDataStd_Tick>  , TDataStd_GenericEmpty >(
      m,
      "TDataStd_Tick",R"#(Defines a boolean attribute. If it exists at a label - true, Otherwise - false.)#"
    );

// preregister user-defined template specializations

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
