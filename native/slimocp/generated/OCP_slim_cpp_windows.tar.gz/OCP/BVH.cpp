
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <BVH_BinaryTree.hxx>
#include <BVH_BinnedBuilder.hxx>
#include <BVH_Box.hxx>
#include <BVH_BoxSet.hxx>
#include <BVH_Builder.hxx>
#include <BVH_Builder3d.hxx>
#include <BVH_BuildQueue.hxx>
#include <BVH_BuildThread.hxx>
#include <BVH_Constants.hxx>
#include <BVH_Distance.hxx>
#include <BVH_DistanceField.hxx>
#include <BVH_Geometry.hxx>
#include <BVH_LinearBuilder.hxx>
#include <BVH_Object.hxx>
#include <BVH_ObjectSet.hxx>
#include <BVH_PairDistance.hxx>
#include <BVH_PrimitiveSet.hxx>
#include <BVH_PrimitiveSet3d.hxx>
#include <BVH_Properties.hxx>
#include <BVH_QuadTree.hxx>
#include <BVH_QueueBuilder.hxx>
#include <BVH_QuickSorter.hxx>
#include <BVH_Ray.hxx>
#include <BVH_Set.hxx>
#include <BVH_Sorter.hxx>
#include <BVH_SpatialMedianBuilder.hxx>
#include <BVH_SweepPlaneBuilder.hxx>
#include <BVH_Tools.hxx>
#include <BVH_Traverse.hxx>
#include <BVH_Tree.hxx>
#include <BVH_Triangulation.hxx>

// template related includes

// ./opencascade/BVH_Builder3d.hxx
#include "BVH_tmpl.hxx"


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_BVH(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("BVH"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes
    class Py_BVH_BuildTool : public BVH_BuildTool{
    public:
        using BVH_BuildTool::BVH_BuildTool;


        // public pure virtual
        void Perform( const int theNode) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,BVH_BuildTool,Perform,theNode) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_BVH_Properties : public BVH_Properties{
    public:
        using BVH_Properties::BVH_Properties;


        // public pure virtual


        // protected pure virtual


        // private pure virtual

    };

// classes

    // Class BVH_BinaryTree from ./opencascade/BVH_Tree.hxx
    klass = m.attr("BVH_BinaryTree");

    // default constructor
    register_default_constructor<BVH_BinaryTree , shared_ptr<BVH_BinaryTree>>(m,"BVH_BinaryTree");

    // nested enums

    static_cast<py::class_<BVH_BinaryTree , shared_ptr<BVH_BinaryTree>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BVH_BuildQueue from ./opencascade/BVH_BuildQueue.hxx
    klass = m.attr("BVH_BuildQueue");


    // nested enums

    static_cast<py::class_<BVH_BuildQueue , shared_ptr<BVH_BuildQueue>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Size",
             (int (BVH_BuildQueue::*)() const) static_cast<int (BVH_BuildQueue::*)() const>(&BVH_BuildQueue::Size),
             R"#(Returns current size of BVH build queue. Uses acquire semantics to synchronize with enqueue/dequeue operations.)#" 
          )
        .def("Enqueue",
             (void (BVH_BuildQueue::*)(  const int  ) ) static_cast<void (BVH_BuildQueue::*)(  const int  ) >(&BVH_BuildQueue::Enqueue),
             R"#(Enqueues new work-item onto BVH build queue.)#"  , py::arg("theWorkItem")
          )
        .def("Fetch",
             (int (BVH_BuildQueue::*)( bool &  ) ) static_cast<int (BVH_BuildQueue::*)( bool &  ) >(&BVH_BuildQueue::Fetch),
             R"#(Fetches first work-item from BVH build queue.)#"  , py::arg("wasBusy")
          )
        .def("HasBusyThreads",
             (bool (BVH_BuildQueue::*)() const) static_cast<bool (BVH_BuildQueue::*)() const>(&BVH_BuildQueue::HasBusyThreads),
             R"#(Checks if there are active build threads. Uses acquire semantics to ensure visibility of thread counter updates. This is critical for termination detection: threads check this after finding an empty queue to determine if they should exit or wait.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BVH_BuildThread from ./opencascade/BVH_BuildThread.hxx
    klass = m.attr("BVH_BuildThread");


    // nested enums

    static_cast<py::class_<BVH_BuildThread ,opencascade::handle<BVH_BuildThread>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init< BVH_BuildTool &,BVH_BuildQueue & >()  , py::arg("theBuildTool"),  py::arg("theBuildQueue") )
    // custom constructors
    // methods
        .def("Run",
             (void (BVH_BuildThread::*)() ) static_cast<void (BVH_BuildThread::*)() >(&BVH_BuildThread::Run),
             R"#(Starts execution of BVH build thread.)#" 
          )
        .def("Wait",
             (void (BVH_BuildThread::*)() ) static_cast<void (BVH_BuildThread::*)() >(&BVH_BuildThread::Wait),
             R"#(Waits till the thread finishes execution.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BVH_BuildThread::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BVH_BuildThread::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BVH_BuildThread::*)() const) static_cast< const handle<Standard_Type> & (BVH_BuildThread::*)() const>(&BVH_BuildThread::DynamicType),
             R"#()#"
             
         )
;

    // Class BVH_BuildTool from ./opencascade/BVH_BuildThread.hxx
    klass = m.attr("BVH_BuildTool");


    // nested enums

    static_cast<py::class_<BVH_BuildTool , shared_ptr<BVH_BuildTool> ,Py_BVH_BuildTool >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("Perform",
             (void (BVH_BuildTool::*)(  const int  ) ) static_cast<void (BVH_BuildTool::*)(  const int  ) >(&BVH_BuildTool::Perform),
             R"#(Performs splitting of the given BVH node.)#"  , py::arg("theNode")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BVH_BuilderTransient from ./opencascade/BVH_Builder.hxx
    klass = m.attr("BVH_BuilderTransient");


    // nested enums

    static_cast<py::class_<BVH_BuilderTransient ,opencascade::handle<BVH_BuilderTransient>  , Standard_Transient >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("MaxTreeDepth",
             (int (BVH_BuilderTransient::*)() const) static_cast<int (BVH_BuilderTransient::*)() const>(&BVH_BuilderTransient::MaxTreeDepth),
             R"#(Returns the maximum depth of constructed BVH.)#" 
          )
        .def("LeafNodeSize",
             (int (BVH_BuilderTransient::*)() const) static_cast<int (BVH_BuilderTransient::*)() const>(&BVH_BuilderTransient::LeafNodeSize),
             R"#(Returns the maximum number of sub-elements in the leaf.)#" 
          )
        .def("IsParallel",
             (bool (BVH_BuilderTransient::*)() const) static_cast<bool (BVH_BuilderTransient::*)() const>(&BVH_BuilderTransient::IsParallel),
             R"#(Returns parallel flag.)#" 
          )
        .def("SetParallel",
             (void (BVH_BuilderTransient::*)(  const bool  ) ) static_cast<void (BVH_BuilderTransient::*)(  const bool  ) >(&BVH_BuilderTransient::SetParallel),
             R"#(Set parallel flag controlling possibility of parallel execution.)#"  , py::arg("isParallel")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BVH_BuilderTransient::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BVH_BuilderTransient::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BVH_BuilderTransient::*)() const) static_cast< const handle<Standard_Type> & (BVH_BuilderTransient::*)() const>(&BVH_BuilderTransient::DynamicType),
             R"#()#"
             
         )
;

    // Class BVH_ObjectTransient from ./opencascade/BVH_Object.hxx
    klass = m.attr("BVH_ObjectTransient");


    // nested enums

    static_cast<py::class_<BVH_ObjectTransient ,opencascade::handle<BVH_ObjectTransient>  , Standard_Transient >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("SetProperties",
             (void (BVH_ObjectTransient::*)(  const handle<BVH_Properties> &  ) ) static_cast<void (BVH_ObjectTransient::*)(  const handle<BVH_Properties> &  ) >(&BVH_ObjectTransient::SetProperties),
             R"#(Sets properties of the geometric object.)#"  , py::arg("theProperties")
          )
        .def("IsDirty",
             (bool (BVH_ObjectTransient::*)() const) static_cast<bool (BVH_ObjectTransient::*)() const>(&BVH_ObjectTransient::IsDirty),
             R"#(Returns TRUE if object state should be updated.)#" 
          )
        .def("MarkDirty",
             (void (BVH_ObjectTransient::*)() ) static_cast<void (BVH_ObjectTransient::*)() >(&BVH_ObjectTransient::MarkDirty),
             R"#(Marks object state as outdated (needs BVH rebuilding).)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BVH_ObjectTransient::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BVH_ObjectTransient::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BVH_ObjectTransient::*)() const) static_cast< const handle<Standard_Type> & (BVH_ObjectTransient::*)() const>(&BVH_ObjectTransient::DynamicType),
             R"#()#"
             
         )
       .def("Properties",
             ( const handle<BVH_Properties> & (BVH_ObjectTransient::*)() const) static_cast< const handle<BVH_Properties> & (BVH_ObjectTransient::*)() const>(&BVH_ObjectTransient::Properties),
             R"#(Returns properties of the geometric object.)#"
             
         )
;

    // Class BVH_Properties from ./opencascade/BVH_Properties.hxx
    klass = m.attr("BVH_Properties");


    // nested enums

    static_cast<py::class_<BVH_Properties ,opencascade::handle<BVH_Properties> ,Py_BVH_Properties , Standard_Transient >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BVH_Properties::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BVH_Properties::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BVH_Properties::*)() const) static_cast< const handle<Standard_Type> & (BVH_Properties::*)() const>(&BVH_Properties::DynamicType),
             R"#()#"
             
         )
;

    // Class BVH_QuadTree from ./opencascade/BVH_Tree.hxx
    klass = m.attr("BVH_QuadTree");

    // default constructor
    register_default_constructor<BVH_QuadTree , shared_ptr<BVH_QuadTree>>(m,"BVH_QuadTree");

    // nested enums

    static_cast<py::class_<BVH_QuadTree , shared_ptr<BVH_QuadTree>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BVH_TreeBaseTransient from ./opencascade/BVH_Tree.hxx
    klass = m.attr("BVH_TreeBaseTransient");


    // nested enums

    static_cast<py::class_<BVH_TreeBaseTransient ,opencascade::handle<BVH_TreeBaseTransient>  , Standard_Transient >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BVH_TreeBaseTransient::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BVH_TreeBaseTransient::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BVH_TreeBaseTransient::*)() const) static_cast< const handle<Standard_Type> & (BVH_TreeBaseTransient::*)() const>(&BVH_TreeBaseTransient::DynamicType),
             R"#()#"
             
         )
;

// functions

// ./opencascade/BVH_BinaryTree.hxx
// ./opencascade/BVH_BinnedBuilder.hxx
// ./opencascade/BVH_Box.hxx
// ./opencascade/BVH_BoxSet.hxx
// ./opencascade/BVH_BuildQueue.hxx
// ./opencascade/BVH_BuildThread.hxx
// ./opencascade/BVH_Builder.hxx
// ./opencascade/BVH_Builder3d.hxx
// ./opencascade/BVH_Constants.hxx
// ./opencascade/BVH_Distance.hxx
// ./opencascade/BVH_DistanceField.hxx
// ./opencascade/BVH_Geometry.hxx
// ./opencascade/BVH_LinearBuilder.hxx
// ./opencascade/BVH_Object.hxx
// ./opencascade/BVH_ObjectSet.hxx
// ./opencascade/BVH_PairDistance.hxx
// ./opencascade/BVH_PrimitiveSet.hxx
// ./opencascade/BVH_PrimitiveSet3d.hxx
// ./opencascade/BVH_Properties.hxx
// ./opencascade/BVH_QuadTree.hxx
// ./opencascade/BVH_QueueBuilder.hxx
// ./opencascade/BVH_QuickSorter.hxx
// ./opencascade/BVH_Ray.hxx
// ./opencascade/BVH_Set.hxx
// ./opencascade/BVH_Sorter.hxx
// ./opencascade/BVH_SpatialMedianBuilder.hxx
// ./opencascade/BVH_SweepPlaneBuilder.hxx
// ./opencascade/BVH_Tools.hxx
// ./opencascade/BVH_Traverse.hxx
// ./opencascade/BVH_Tree.hxx
// ./opencascade/BVH_Triangulation.hxx

// Additional functions


// operators

// register typdefs
    register_template_BVH_Builder<double, 3>(m,"BVH_Builder3d");

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
