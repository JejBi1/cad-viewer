
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom_Curve.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Geom_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom_BSplineCurve.hxx>
#include <Geom_BezierCurve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <GeomAdaptor_Curve.hxx>
#include <Geom_OffsetSurface.hxx>
#include <Geom_BezierSurface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Geom_BezierSurface.hxx>
#include <Geom_BSplineSurface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Geom_BezierSurface.hxx>
#include <Geom_BSplineSurface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Geom_BezierSurface.hxx>
#include <Geom_BSplineSurface.hxx>

// module includes
#include <GeomAdaptor.hxx>
#include <GeomAdaptor_Curve.hxx>
#include <GeomAdaptor_Surface.hxx>
#include <GeomAdaptor_SurfaceOfLinearExtrusion.hxx>
#include <GeomAdaptor_SurfaceOfRevolution.hxx>
#include <GeomAdaptor_TransformedCurve.hxx>
#include <GeomAdaptor_TransformedSurface.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module
#include <Geom_BezierCurve.hxx>
#include <Geom_BSplineCurve.hxx>
#include <Geom_OffsetCurve.hxx>


// Module definiiton
void register_GeomAdaptor(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("GeomAdaptor"));
py::object klass;

// get namespaces as submodules
auto GeomEval_RepCurveDesc = static_cast<py::module>(m.attr("GeomEval_RepCurveDesc"));
auto GeomEval_RepSurfaceDesc = static_cast<py::module>(m.attr("GeomEval_RepSurfaceDesc"));

//Python trampoline classes

// classes

    // Class GeomAdaptor from ./opencascade/GeomAdaptor.hxx
    klass = m.attr("GeomAdaptor");

    // default constructor
    register_default_constructor<GeomAdaptor , shared_ptr<GeomAdaptor>>(m,"GeomAdaptor");

    // nested enums

    static_cast<py::class_<GeomAdaptor , shared_ptr<GeomAdaptor>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("MakeCurve_s",
                    (handle<Geom_Curve> (*)(  const Adaptor3d_Curve &  ) ) static_cast<handle<Geom_Curve> (*)(  const Adaptor3d_Curve &  ) >(&GeomAdaptor::MakeCurve),
                    R"#(Inherited from GHCurve. Provides a curve handled by reference. Build a Geom_Curve using the information from the Curve from Adaptor3d)#"  , py::arg("C")
          )
        .def_static("MakeSurface_s",
                    (handle<Geom_Surface> (*)(  const Adaptor3d_Surface & ,   const bool  ) ) static_cast<handle<Geom_Surface> (*)(  const Adaptor3d_Surface & ,   const bool  ) >(&GeomAdaptor::MakeSurface),
                    R"#(Build a Geom_Surface using the information from the Surface from Adaptor3d)#"  , py::arg("theS"),  py::arg("theTrimFlag")=static_cast< const bool>(true)
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class GeomAdaptor_Curve from ./opencascade/GeomAdaptor_Curve.hxx
    klass = m.attr("GeomAdaptor_Curve");


    // nested enums

    static_cast<py::class_<GeomAdaptor_Curve ,opencascade::handle<GeomAdaptor_Curve>  , Adaptor3d_Curve >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<Geom_Curve> & >()  , py::arg("theCurve") )
        .def(py::init<  const handle<Geom_Curve> &, const double, const double >()  , py::arg("theCurve"),  py::arg("theUFirst"),  py::arg("theULast") )
    // custom constructors
    // methods
        .def("ShallowCopy",
             (handle<Adaptor3d_Curve> (GeomAdaptor_Curve::*)() const) static_cast<handle<Adaptor3d_Curve> (GeomAdaptor_Curve::*)() const>(&GeomAdaptor_Curve::ShallowCopy),
             R"#(Shallow copy of adaptor)#" 
          )
        .def("Reset",
             (void (GeomAdaptor_Curve::*)() ) static_cast<void (GeomAdaptor_Curve::*)() >(&GeomAdaptor_Curve::Reset),
             R"#(Reset currently loaded curve (undone Load()).)#" 
          )
        .def("Load",
             (void (GeomAdaptor_Curve::*)(  const handle<Geom_Curve> &  ) ) static_cast<void (GeomAdaptor_Curve::*)(  const handle<Geom_Curve> &  ) >(&GeomAdaptor_Curve::Load),
             R"#()#"  , py::arg("theCurve")
          )
        .def("Load",
             (void (GeomAdaptor_Curve::*)(  const handle<Geom_Curve> & ,   const double ,   const double  ) ) static_cast<void (GeomAdaptor_Curve::*)(  const handle<Geom_Curve> & ,   const double ,   const double  ) >(&GeomAdaptor_Curve::Load),
             R"#(Standard_ConstructionError is raised if theUFirst > theULast + Precision::PConfusion())#"  , py::arg("theCurve"),  py::arg("theUFirst"),  py::arg("theULast")
          )
        .def("FirstParameter",
             (double (GeomAdaptor_Curve::*)() const) static_cast<double (GeomAdaptor_Curve::*)() const>(&GeomAdaptor_Curve::FirstParameter),
             R"#()#" 
          )
        .def("LastParameter",
             (double (GeomAdaptor_Curve::*)() const) static_cast<double (GeomAdaptor_Curve::*)() const>(&GeomAdaptor_Curve::LastParameter),
             R"#()#" 
          )
        .def("Continuity",
             (GeomAbs_Shape (GeomAdaptor_Curve::*)() const) static_cast<GeomAbs_Shape (GeomAdaptor_Curve::*)() const>(&GeomAdaptor_Curve::Continuity),
             R"#()#" 
          )
        .def("NbIntervals",
             (int (GeomAdaptor_Curve::*)(  const GeomAbs_Shape  ) const) static_cast<int (GeomAdaptor_Curve::*)(  const GeomAbs_Shape  ) const>(&GeomAdaptor_Curve::NbIntervals),
             R"#(Returns the number of intervals for continuity <S>. May be one if Continuity(me) >= <S>)#"  , py::arg("S")
          )
        .def("Intervals",
             (void (GeomAdaptor_Curve::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const) static_cast<void (GeomAdaptor_Curve::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const>(&GeomAdaptor_Curve::Intervals),
             R"#(Stores in <T> the parameters bounding the intervals of continuity <S>.)#"  , py::arg("T"),  py::arg("S")
          )
        .def("Trim",
             (handle<Adaptor3d_Curve> (GeomAdaptor_Curve::*)(  const double ,   const double ,   const double  ) const) static_cast<handle<Adaptor3d_Curve> (GeomAdaptor_Curve::*)(  const double ,   const double ,   const double  ) const>(&GeomAdaptor_Curve::Trim),
             R"#(Returns a curve equivalent of <me> between parameters <First> and <Last>. <Tol> is used to test for 3d points confusion. If <First> >= <Last>)#"  , py::arg("First"),  py::arg("Last"),  py::arg("Tol")
          )
        .def("IsClosed",
             (bool (GeomAdaptor_Curve::*)() const) static_cast<bool (GeomAdaptor_Curve::*)() const>(&GeomAdaptor_Curve::IsClosed),
             R"#()#" 
          )
        .def("IsPeriodic",
             (bool (GeomAdaptor_Curve::*)() const) static_cast<bool (GeomAdaptor_Curve::*)() const>(&GeomAdaptor_Curve::IsPeriodic),
             R"#()#" 
          )
        .def("Period",
             (double (GeomAdaptor_Curve::*)() const) static_cast<double (GeomAdaptor_Curve::*)() const>(&GeomAdaptor_Curve::Period),
             R"#()#" 
          )
        .def("Resolution",
             (double (GeomAdaptor_Curve::*)(  const double  ) const) static_cast<double (GeomAdaptor_Curve::*)(  const double  ) const>(&GeomAdaptor_Curve::Resolution),
             R"#(returns the parametric resolution)#"  , py::arg("R3d")
          )
        .def("GetType",
             (GeomAbs_CurveType (GeomAdaptor_Curve::*)() const) static_cast<GeomAbs_CurveType (GeomAdaptor_Curve::*)() const>(&GeomAdaptor_Curve::GetType),
             R"#()#" 
          )
        .def("Line",
             (gp_Lin (GeomAdaptor_Curve::*)() const) static_cast<gp_Lin (GeomAdaptor_Curve::*)() const>(&GeomAdaptor_Curve::Line),
             R"#()#" 
          )
        .def("Circle",
             (gp_Circ (GeomAdaptor_Curve::*)() const) static_cast<gp_Circ (GeomAdaptor_Curve::*)() const>(&GeomAdaptor_Curve::Circle),
             R"#()#" 
          )
        .def("Ellipse",
             (gp_Elips (GeomAdaptor_Curve::*)() const) static_cast<gp_Elips (GeomAdaptor_Curve::*)() const>(&GeomAdaptor_Curve::Ellipse),
             R"#()#" 
          )
        .def("Hyperbola",
             (gp_Hypr (GeomAdaptor_Curve::*)() const) static_cast<gp_Hypr (GeomAdaptor_Curve::*)() const>(&GeomAdaptor_Curve::Hyperbola),
             R"#()#" 
          )
        .def("Parabola",
             (gp_Parab (GeomAdaptor_Curve::*)() const) static_cast<gp_Parab (GeomAdaptor_Curve::*)() const>(&GeomAdaptor_Curve::Parabola),
             R"#()#" 
          )
        .def("Degree",
             (int (GeomAdaptor_Curve::*)() const) static_cast<int (GeomAdaptor_Curve::*)() const>(&GeomAdaptor_Curve::Degree),
             R"#(this should NEVER make a copy of the underlying curve to read the relevant information)#" 
          )
        .def("IsRational",
             (bool (GeomAdaptor_Curve::*)() const) static_cast<bool (GeomAdaptor_Curve::*)() const>(&GeomAdaptor_Curve::IsRational),
             R"#(this should NEVER make a copy of the underlying curve to read the relevant information)#" 
          )
        .def("NbPoles",
             (int (GeomAdaptor_Curve::*)() const) static_cast<int (GeomAdaptor_Curve::*)() const>(&GeomAdaptor_Curve::NbPoles),
             R"#(this should NEVER make a copy of the underlying curve to read the relevant information)#" 
          )
        .def("NbKnots",
             (int (GeomAdaptor_Curve::*)() const) static_cast<int (GeomAdaptor_Curve::*)() const>(&GeomAdaptor_Curve::NbKnots),
             R"#(this should NEVER make a copy of the underlying curve to read the relevant information)#" 
          )
        .def("Bezier",
             (handle<Geom_BezierCurve> (GeomAdaptor_Curve::*)() const) static_cast<handle<Geom_BezierCurve> (GeomAdaptor_Curve::*)() const>(&GeomAdaptor_Curve::Bezier),
             R"#(this will NOT make a copy of the Bezier Curve : If you want to modify the Curve please make a copy yourself Also it will NOT trim the surface to myFirst/Last.)#" 
          )
        .def("BSpline",
             (handle<Geom_BSplineCurve> (GeomAdaptor_Curve::*)() const) static_cast<handle<Geom_BSplineCurve> (GeomAdaptor_Curve::*)() const>(&GeomAdaptor_Curve::BSpline),
             R"#(this will NOT make a copy of the BSpline Curve : If you want to modify the Curve please make a copy yourself Also it will NOT trim the surface to myFirst/Last.)#" 
          )
        .def("OffsetCurve",
             (handle<Geom_OffsetCurve> (GeomAdaptor_Curve::*)() const) static_cast<handle<Geom_OffsetCurve> (GeomAdaptor_Curve::*)() const>(&GeomAdaptor_Curve::OffsetCurve),
             R"#()#" 
          )
        .def("EvalD0",
             (gp_Pnt (GeomAdaptor_Curve::*)(  const double  ) const) static_cast<gp_Pnt (GeomAdaptor_Curve::*)(  const double  ) const>(&GeomAdaptor_Curve::EvalD0),
             R"#(Point evaluation. Raises an exception on failure.)#"  , py::arg("theU")
          )
        .def("EvalD1",
             (Geom_Curve::ResD1 (GeomAdaptor_Curve::*)(  const double  ) const) static_cast<Geom_Curve::ResD1 (GeomAdaptor_Curve::*)(  const double  ) const>(&GeomAdaptor_Curve::EvalD1),
             R"#(D1 evaluation. Raises an exception on failure.)#"  , py::arg("theU")
          )
        .def("EvalD2",
             (Geom_Curve::ResD2 (GeomAdaptor_Curve::*)(  const double  ) const) static_cast<Geom_Curve::ResD2 (GeomAdaptor_Curve::*)(  const double  ) const>(&GeomAdaptor_Curve::EvalD2),
             R"#(D2 evaluation. Raises an exception on failure.)#"  , py::arg("theU")
          )
        .def("EvalD3",
             (Geom_Curve::ResD3 (GeomAdaptor_Curve::*)(  const double  ) const) static_cast<Geom_Curve::ResD3 (GeomAdaptor_Curve::*)(  const double  ) const>(&GeomAdaptor_Curve::EvalD3),
             R"#(D3 evaluation. Raises an exception on failure.)#"  , py::arg("theU")
          )
        .def("EvalDN",
             (gp_Vec (GeomAdaptor_Curve::*)(  const double ,   const int  ) const) static_cast<gp_Vec (GeomAdaptor_Curve::*)(  const double ,   const int  ) const>(&GeomAdaptor_Curve::EvalDN),
             R"#(DN evaluation. Raises an exception on failure.)#"  , py::arg("theU"),  py::arg("theN")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&GeomAdaptor_Curve::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&GeomAdaptor_Curve::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (GeomAdaptor_Curve::*)() const) static_cast< const handle<Standard_Type> & (GeomAdaptor_Curve::*)() const>(&GeomAdaptor_Curve::DynamicType),
             R"#()#"
             
         )
       .def("Curve",
             ( const handle<Geom_Curve> & (GeomAdaptor_Curve::*)() const) static_cast< const handle<Geom_Curve> & (GeomAdaptor_Curve::*)() const>(&GeomAdaptor_Curve::Curve),
             R"#(Provides a curve inherited from Hcurve from Adaptor. This is inherited to provide easy to use constructors.)#"
             
         )
;

    // Class GeomAdaptor_Surface from ./opencascade/GeomAdaptor_Surface.hxx
    klass = m.attr("GeomAdaptor_Surface");


    // nested enums

    static_cast<py::class_<GeomAdaptor_Surface ,opencascade::handle<GeomAdaptor_Surface>  , Adaptor3d_Surface >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<Geom_Surface> & >()  , py::arg("theSurf") )
        .def(py::init<  const handle<Geom_Surface> &, const double, const double, const double, const double, const double, const double >()  , py::arg("theSurf"),  py::arg("theUFirst"),  py::arg("theULast"),  py::arg("theVFirst"),  py::arg("theVLast"),  py::arg("theTolU")=static_cast< const double>(0.0),  py::arg("theTolV")=static_cast< const double>(0.0) )
    // custom constructors
    // methods
        .def("ShallowCopy",
             (handle<Adaptor3d_Surface> (GeomAdaptor_Surface::*)() const) static_cast<handle<Adaptor3d_Surface> (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::ShallowCopy),
             R"#(Shallow copy of adaptor)#" 
          )
        .def("Load",
             (void (GeomAdaptor_Surface::*)(  const handle<Geom_Surface> &  ) ) static_cast<void (GeomAdaptor_Surface::*)(  const handle<Geom_Surface> &  ) >(&GeomAdaptor_Surface::Load),
             R"#()#"  , py::arg("theSurf")
          )
        .def("Load",
             (void (GeomAdaptor_Surface::*)(  const handle<Geom_Surface> & ,   const double ,   const double ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<void (GeomAdaptor_Surface::*)(  const handle<Geom_Surface> & ,   const double ,   const double ,   const double ,   const double ,   const double ,   const double  ) >(&GeomAdaptor_Surface::Load),
             R"#(Standard_ConstructionError is raised if theUFirst>theULast or theVFirst>theVLast)#"  , py::arg("theSurf"),  py::arg("theUFirst"),  py::arg("theULast"),  py::arg("theVFirst"),  py::arg("theVLast"),  py::arg("theTolU")=static_cast< const double>(0.0),  py::arg("theTolV")=static_cast< const double>(0.0)
          )
        .def("FirstUParameter",
             (double (GeomAdaptor_Surface::*)() const) static_cast<double (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::FirstUParameter),
             R"#()#" 
          )
        .def("LastUParameter",
             (double (GeomAdaptor_Surface::*)() const) static_cast<double (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::LastUParameter),
             R"#()#" 
          )
        .def("FirstVParameter",
             (double (GeomAdaptor_Surface::*)() const) static_cast<double (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::FirstVParameter),
             R"#()#" 
          )
        .def("LastVParameter",
             (double (GeomAdaptor_Surface::*)() const) static_cast<double (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::LastVParameter),
             R"#()#" 
          )
        .def("ToleranceU",
             (double (GeomAdaptor_Surface::*)() const) static_cast<double (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::ToleranceU),
             R"#(Returns tolerance in U direction.)#" 
          )
        .def("ToleranceV",
             (double (GeomAdaptor_Surface::*)() const) static_cast<double (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::ToleranceV),
             R"#(Returns tolerance in V direction.)#" 
          )
        .def("UContinuity",
             (GeomAbs_Shape (GeomAdaptor_Surface::*)() const) static_cast<GeomAbs_Shape (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::UContinuity),
             R"#()#" 
          )
        .def("VContinuity",
             (GeomAbs_Shape (GeomAdaptor_Surface::*)() const) static_cast<GeomAbs_Shape (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::VContinuity),
             R"#()#" 
          )
        .def("NbUIntervals",
             (int (GeomAdaptor_Surface::*)(  const GeomAbs_Shape  ) const) static_cast<int (GeomAdaptor_Surface::*)(  const GeomAbs_Shape  ) const>(&GeomAdaptor_Surface::NbUIntervals),
             R"#(Returns the number of U intervals for continuity <S>. May be one if UContinuity(me) >= <S>)#"  , py::arg("S")
          )
        .def("NbVIntervals",
             (int (GeomAdaptor_Surface::*)(  const GeomAbs_Shape  ) const) static_cast<int (GeomAdaptor_Surface::*)(  const GeomAbs_Shape  ) const>(&GeomAdaptor_Surface::NbVIntervals),
             R"#(Returns the number of V intervals for continuity <S>. May be one if VContinuity(me) >= <S>)#"  , py::arg("S")
          )
        .def("UIntervals",
             (void (GeomAdaptor_Surface::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const) static_cast<void (GeomAdaptor_Surface::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const>(&GeomAdaptor_Surface::UIntervals),
             R"#(Returns the intervals with the requested continuity in the U direction.)#"  , py::arg("T"),  py::arg("S")
          )
        .def("VIntervals",
             (void (GeomAdaptor_Surface::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const) static_cast<void (GeomAdaptor_Surface::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const>(&GeomAdaptor_Surface::VIntervals),
             R"#(Returns the intervals with the requested continuity in the V direction.)#"  , py::arg("T"),  py::arg("S")
          )
        .def("UTrim",
             (handle<Adaptor3d_Surface> (GeomAdaptor_Surface::*)(  const double ,   const double ,   const double  ) const) static_cast<handle<Adaptor3d_Surface> (GeomAdaptor_Surface::*)(  const double ,   const double ,   const double  ) const>(&GeomAdaptor_Surface::UTrim),
             R"#(Returns a surface trimmed in the U direction equivalent of <me> between parameters <First> and <Last>. <Tol> is used to test for 3d points confusion. If <First> >= <Last>)#"  , py::arg("First"),  py::arg("Last"),  py::arg("Tol")
          )
        .def("VTrim",
             (handle<Adaptor3d_Surface> (GeomAdaptor_Surface::*)(  const double ,   const double ,   const double  ) const) static_cast<handle<Adaptor3d_Surface> (GeomAdaptor_Surface::*)(  const double ,   const double ,   const double  ) const>(&GeomAdaptor_Surface::VTrim),
             R"#(Returns a surface trimmed in the V direction between parameters <First> and <Last>. <Tol> is used to test for 3d points confusion. If <First> >= <Last>)#"  , py::arg("First"),  py::arg("Last"),  py::arg("Tol")
          )
        .def("IsUClosed",
             (bool (GeomAdaptor_Surface::*)() const) static_cast<bool (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::IsUClosed),
             R"#()#" 
          )
        .def("IsVClosed",
             (bool (GeomAdaptor_Surface::*)() const) static_cast<bool (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::IsVClosed),
             R"#()#" 
          )
        .def("IsUPeriodic",
             (bool (GeomAdaptor_Surface::*)() const) static_cast<bool (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::IsUPeriodic),
             R"#()#" 
          )
        .def("UPeriod",
             (double (GeomAdaptor_Surface::*)() const) static_cast<double (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::UPeriod),
             R"#()#" 
          )
        .def("IsVPeriodic",
             (bool (GeomAdaptor_Surface::*)() const) static_cast<bool (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::IsVPeriodic),
             R"#()#" 
          )
        .def("VPeriod",
             (double (GeomAdaptor_Surface::*)() const) static_cast<double (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::VPeriod),
             R"#()#" 
          )
        .def("EvalD0",
             (gp_Pnt (GeomAdaptor_Surface::*)(  const double ,   const double  ) const) static_cast<gp_Pnt (GeomAdaptor_Surface::*)(  const double ,   const double  ) const>(&GeomAdaptor_Surface::EvalD0),
             R"#(Point evaluation. Raises an exception on failure.)#"  , py::arg("theU"),  py::arg("theV")
          )
        .def("EvalD1",
             (Geom_Surface::ResD1 (GeomAdaptor_Surface::*)(  const double ,   const double  ) const) static_cast<Geom_Surface::ResD1 (GeomAdaptor_Surface::*)(  const double ,   const double  ) const>(&GeomAdaptor_Surface::EvalD1),
             R"#(D1 evaluation. Raises an exception on failure.)#"  , py::arg("theU"),  py::arg("theV")
          )
        .def("EvalD2",
             (Geom_Surface::ResD2 (GeomAdaptor_Surface::*)(  const double ,   const double  ) const) static_cast<Geom_Surface::ResD2 (GeomAdaptor_Surface::*)(  const double ,   const double  ) const>(&GeomAdaptor_Surface::EvalD2),
             R"#(D2 evaluation. Raises an exception on failure.)#"  , py::arg("theU"),  py::arg("theV")
          )
        .def("EvalD3",
             (Geom_Surface::ResD3 (GeomAdaptor_Surface::*)(  const double ,   const double  ) const) static_cast<Geom_Surface::ResD3 (GeomAdaptor_Surface::*)(  const double ,   const double  ) const>(&GeomAdaptor_Surface::EvalD3),
             R"#(D3 evaluation. Raises an exception on failure.)#"  , py::arg("theU"),  py::arg("theV")
          )
        .def("EvalDN",
             (gp_Vec (GeomAdaptor_Surface::*)(  const double ,   const double ,   const int ,   const int  ) const) static_cast<gp_Vec (GeomAdaptor_Surface::*)(  const double ,   const double ,   const int ,   const int  ) const>(&GeomAdaptor_Surface::EvalDN),
             R"#(DN evaluation. Raises an exception on failure.)#"  , py::arg("theU"),  py::arg("theV"),  py::arg("theNu"),  py::arg("theNv")
          )
        .def("UResolution",
             (double (GeomAdaptor_Surface::*)(  const double  ) const) static_cast<double (GeomAdaptor_Surface::*)(  const double  ) const>(&GeomAdaptor_Surface::UResolution),
             R"#(Returns the parametric U resolution corresponding to the real space resolution <R3d>.)#"  , py::arg("R3d")
          )
        .def("VResolution",
             (double (GeomAdaptor_Surface::*)(  const double  ) const) static_cast<double (GeomAdaptor_Surface::*)(  const double  ) const>(&GeomAdaptor_Surface::VResolution),
             R"#(Returns the parametric V resolution corresponding to the real space resolution <R3d>.)#"  , py::arg("R3d")
          )
        .def("GetType",
             (GeomAbs_SurfaceType (GeomAdaptor_Surface::*)() const) static_cast<GeomAbs_SurfaceType (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::GetType),
             R"#(Returns the type of the surface: Plane, Cylinder, Cone, Sphere, Torus, BezierSurface, BSplineSurface, SurfaceOfRevolution, SurfaceOfExtrusion, OtherSurface)#" 
          )
        .def("Plane",
             (gp_Pln (GeomAdaptor_Surface::*)() const) static_cast<gp_Pln (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::Plane),
             R"#()#" 
          )
        .def("Cylinder",
             (gp_Cylinder (GeomAdaptor_Surface::*)() const) static_cast<gp_Cylinder (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::Cylinder),
             R"#()#" 
          )
        .def("Cone",
             (gp_Cone (GeomAdaptor_Surface::*)() const) static_cast<gp_Cone (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::Cone),
             R"#()#" 
          )
        .def("Sphere",
             (gp_Sphere (GeomAdaptor_Surface::*)() const) static_cast<gp_Sphere (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::Sphere),
             R"#()#" 
          )
        .def("Torus",
             (gp_Torus (GeomAdaptor_Surface::*)() const) static_cast<gp_Torus (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::Torus),
             R"#()#" 
          )
        .def("UDegree",
             (int (GeomAdaptor_Surface::*)() const) static_cast<int (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::UDegree),
             R"#()#" 
          )
        .def("NbUPoles",
             (int (GeomAdaptor_Surface::*)() const) static_cast<int (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::NbUPoles),
             R"#()#" 
          )
        .def("VDegree",
             (int (GeomAdaptor_Surface::*)() const) static_cast<int (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::VDegree),
             R"#()#" 
          )
        .def("NbVPoles",
             (int (GeomAdaptor_Surface::*)() const) static_cast<int (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::NbVPoles),
             R"#()#" 
          )
        .def("NbUKnots",
             (int (GeomAdaptor_Surface::*)() const) static_cast<int (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::NbUKnots),
             R"#()#" 
          )
        .def("NbVKnots",
             (int (GeomAdaptor_Surface::*)() const) static_cast<int (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::NbVKnots),
             R"#()#" 
          )
        .def("IsURational",
             (bool (GeomAdaptor_Surface::*)() const) static_cast<bool (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::IsURational),
             R"#()#" 
          )
        .def("IsVRational",
             (bool (GeomAdaptor_Surface::*)() const) static_cast<bool (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::IsVRational),
             R"#()#" 
          )
        .def("Bezier",
             (handle<Geom_BezierSurface> (GeomAdaptor_Surface::*)() const) static_cast<handle<Geom_BezierSurface> (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::Bezier),
             R"#(This will NOT make a copy of the Bezier Surface : If you want to modify the Surface please make a copy yourself Also it will NOT trim the surface to myU/VFirst/Last.)#" 
          )
        .def("BSpline",
             (handle<Geom_BSplineSurface> (GeomAdaptor_Surface::*)() const) static_cast<handle<Geom_BSplineSurface> (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::BSpline),
             R"#(This will NOT make a copy of the BSpline Surface : If you want to modify the Surface please make a copy yourself Also it will NOT trim the surface to myU/VFirst/Last.)#" 
          )
        .def("AxeOfRevolution",
             (gp_Ax1 (GeomAdaptor_Surface::*)() const) static_cast<gp_Ax1 (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::AxeOfRevolution),
             R"#()#" 
          )
        .def("Direction",
             (gp_Dir (GeomAdaptor_Surface::*)() const) static_cast<gp_Dir (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::Direction),
             R"#()#" 
          )
        .def("BasisCurve",
             (handle<Adaptor3d_Curve> (GeomAdaptor_Surface::*)() const) static_cast<handle<Adaptor3d_Curve> (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::BasisCurve),
             R"#()#" 
          )
        .def("BasisSurface",
             (handle<Adaptor3d_Surface> (GeomAdaptor_Surface::*)() const) static_cast<handle<Adaptor3d_Surface> (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::BasisSurface),
             R"#()#" 
          )
        .def("OffsetValue",
             (double (GeomAdaptor_Surface::*)() const) static_cast<double (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::OffsetValue),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
        .def("Bounds",
             []( GeomAdaptor_Surface &self   ){
                 double  theU1;
                double  theU2;
                double  theV1;
                double  theV2;

                 self.Bounds(theU1,theU2,theV1,theV2);
                 return std::make_tuple(theU1,theU2,theV1,theV2); },
             R"#(Returns the parametric bounds of the surface.)#" 
          )
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&GeomAdaptor_Surface::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&GeomAdaptor_Surface::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (GeomAdaptor_Surface::*)() const) static_cast< const handle<Standard_Type> & (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::DynamicType),
             R"#()#"
             
         )
       .def("Surface",
             ( const handle<Geom_Surface> & (GeomAdaptor_Surface::*)() const) static_cast< const handle<Geom_Surface> & (GeomAdaptor_Surface::*)() const>(&GeomAdaptor_Surface::Surface),
             R"#()#"
             
         )
;

    // Class GeomAdaptor_TransformedCurve from ./opencascade/GeomAdaptor_TransformedCurve.hxx
    klass = m.attr("GeomAdaptor_TransformedCurve");


    // nested enums

    static_cast<py::class_<GeomAdaptor_TransformedCurve ,opencascade::handle<GeomAdaptor_TransformedCurve>  , Adaptor3d_Curve >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<Geom_Curve> &, const double, const double, const gp_Trsf & >()  , py::arg("theCurve"),  py::arg("theFirst"),  py::arg("theLast"),  py::arg("theTrsf") )
        .def(py::init<  const handle<Geom_Curve> &, const gp_Trsf & >()  , py::arg("theCurve"),  py::arg("theTrsf") )
    // custom constructors
    // methods
        .def("ShallowCopy",
             (handle<Adaptor3d_Curve> (GeomAdaptor_TransformedCurve::*)() const) static_cast<handle<Adaptor3d_Curve> (GeomAdaptor_TransformedCurve::*)() const>(&GeomAdaptor_TransformedCurve::ShallowCopy),
             R"#(Shallow copy of adaptor.)#" 
          )
        .def("Load",
             (void (GeomAdaptor_TransformedCurve::*)(  const handle<Geom_Curve> &  ) ) static_cast<void (GeomAdaptor_TransformedCurve::*)(  const handle<Geom_Curve> &  ) >(&GeomAdaptor_TransformedCurve::Load),
             R"#(Loads the curve geometry.)#"  , py::arg("theCurve")
          )
        .def("Load",
             (void (GeomAdaptor_TransformedCurve::*)(  const handle<Geom_Curve> & ,   const double ,   const double  ) ) static_cast<void (GeomAdaptor_TransformedCurve::*)(  const handle<Geom_Curve> & ,   const double ,   const double  ) >(&GeomAdaptor_TransformedCurve::Load),
             R"#(Loads the curve geometry with parameter bounds.)#"  , py::arg("theCurve"),  py::arg("theFirst"),  py::arg("theLast")
          )
        .def("LoadCurveOnSurface",
             (void (GeomAdaptor_TransformedCurve::*)(  const handle<Adaptor3d_CurveOnSurface> &  ) ) static_cast<void (GeomAdaptor_TransformedCurve::*)(  const handle<Adaptor3d_CurveOnSurface> &  ) >(&GeomAdaptor_TransformedCurve::LoadCurveOnSurface),
             R"#(Sets the curve on surface adaptor.)#"  , py::arg("theConSurf")
          )
        .def("SetTrsf",
             (void (GeomAdaptor_TransformedCurve::*)(  const gp_Trsf &  ) ) static_cast<void (GeomAdaptor_TransformedCurve::*)(  const gp_Trsf &  ) >(&GeomAdaptor_TransformedCurve::SetTrsf),
             R"#(Sets the transformation.)#"  , py::arg("theTrsf")
          )
        .def("Is3DCurve",
             (bool (GeomAdaptor_TransformedCurve::*)() const) static_cast<bool (GeomAdaptor_TransformedCurve::*)() const>(&GeomAdaptor_TransformedCurve::Is3DCurve),
             R"#(Returns true if the geometry is a 3D curve (not curve on surface).)#" 
          )
        .def("IsCurveOnSurface",
             (bool (GeomAdaptor_TransformedCurve::*)() const) static_cast<bool (GeomAdaptor_TransformedCurve::*)() const>(&GeomAdaptor_TransformedCurve::IsCurveOnSurface),
             R"#(Returns true if the geometry is a curve on surface.)#" 
          )
        .def("FirstParameter",
             (double (GeomAdaptor_TransformedCurve::*)() const) static_cast<double (GeomAdaptor_TransformedCurve::*)() const>(&GeomAdaptor_TransformedCurve::FirstParameter),
             R"#()#" 
          )
        .def("LastParameter",
             (double (GeomAdaptor_TransformedCurve::*)() const) static_cast<double (GeomAdaptor_TransformedCurve::*)() const>(&GeomAdaptor_TransformedCurve::LastParameter),
             R"#()#" 
          )
        .def("Continuity",
             (GeomAbs_Shape (GeomAdaptor_TransformedCurve::*)() const) static_cast<GeomAbs_Shape (GeomAdaptor_TransformedCurve::*)() const>(&GeomAdaptor_TransformedCurve::Continuity),
             R"#()#" 
          )
        .def("NbIntervals",
             (int (GeomAdaptor_TransformedCurve::*)(  const GeomAbs_Shape  ) const) static_cast<int (GeomAdaptor_TransformedCurve::*)(  const GeomAbs_Shape  ) const>(&GeomAdaptor_TransformedCurve::NbIntervals),
             R"#()#"  , py::arg("theS")
          )
        .def("Intervals",
             (void (GeomAdaptor_TransformedCurve::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const) static_cast<void (GeomAdaptor_TransformedCurve::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const>(&GeomAdaptor_TransformedCurve::Intervals),
             R"#()#"  , py::arg("theT"),  py::arg("theS")
          )
        .def("Trim",
             (handle<Adaptor3d_Curve> (GeomAdaptor_TransformedCurve::*)(  const double ,   const double ,   const double  ) const) static_cast<handle<Adaptor3d_Curve> (GeomAdaptor_TransformedCurve::*)(  const double ,   const double ,   const double  ) const>(&GeomAdaptor_TransformedCurve::Trim),
             R"#()#"  , py::arg("theFirst"),  py::arg("theLast"),  py::arg("theTol")
          )
        .def("IsClosed",
             (bool (GeomAdaptor_TransformedCurve::*)() const) static_cast<bool (GeomAdaptor_TransformedCurve::*)() const>(&GeomAdaptor_TransformedCurve::IsClosed),
             R"#()#" 
          )
        .def("IsPeriodic",
             (bool (GeomAdaptor_TransformedCurve::*)() const) static_cast<bool (GeomAdaptor_TransformedCurve::*)() const>(&GeomAdaptor_TransformedCurve::IsPeriodic),
             R"#()#" 
          )
        .def("Period",
             (double (GeomAdaptor_TransformedCurve::*)() const) static_cast<double (GeomAdaptor_TransformedCurve::*)() const>(&GeomAdaptor_TransformedCurve::Period),
             R"#()#" 
          )
        .def("EvalD0",
             (gp_Pnt (GeomAdaptor_TransformedCurve::*)(  const double  ) const) static_cast<gp_Pnt (GeomAdaptor_TransformedCurve::*)(  const double  ) const>(&GeomAdaptor_TransformedCurve::EvalD0),
             R"#(Point evaluation. Applies transformation after evaluation.)#"  , py::arg("theU")
          )
        .def("EvalD1",
             (Geom_Curve::ResD1 (GeomAdaptor_TransformedCurve::*)(  const double  ) const) static_cast<Geom_Curve::ResD1 (GeomAdaptor_TransformedCurve::*)(  const double  ) const>(&GeomAdaptor_TransformedCurve::EvalD1),
             R"#(D1 evaluation. Applies transformation after evaluation.)#"  , py::arg("theU")
          )
        .def("EvalD2",
             (Geom_Curve::ResD2 (GeomAdaptor_TransformedCurve::*)(  const double  ) const) static_cast<Geom_Curve::ResD2 (GeomAdaptor_TransformedCurve::*)(  const double  ) const>(&GeomAdaptor_TransformedCurve::EvalD2),
             R"#(D2 evaluation. Applies transformation after evaluation.)#"  , py::arg("theU")
          )
        .def("EvalD3",
             (Geom_Curve::ResD3 (GeomAdaptor_TransformedCurve::*)(  const double  ) const) static_cast<Geom_Curve::ResD3 (GeomAdaptor_TransformedCurve::*)(  const double  ) const>(&GeomAdaptor_TransformedCurve::EvalD3),
             R"#(D3 evaluation. Applies transformation after evaluation.)#"  , py::arg("theU")
          )
        .def("EvalDN",
             (gp_Vec (GeomAdaptor_TransformedCurve::*)(  const double ,   const int  ) const) static_cast<gp_Vec (GeomAdaptor_TransformedCurve::*)(  const double ,   const int  ) const>(&GeomAdaptor_TransformedCurve::EvalDN),
             R"#(DN evaluation. Applies transformation after evaluation.)#"  , py::arg("theU"),  py::arg("theN")
          )
        .def("Resolution",
             (double (GeomAdaptor_TransformedCurve::*)(  const double  ) const) static_cast<double (GeomAdaptor_TransformedCurve::*)(  const double  ) const>(&GeomAdaptor_TransformedCurve::Resolution),
             R"#()#"  , py::arg("theR3d")
          )
        .def("GetType",
             (GeomAbs_CurveType (GeomAdaptor_TransformedCurve::*)() const) static_cast<GeomAbs_CurveType (GeomAdaptor_TransformedCurve::*)() const>(&GeomAdaptor_TransformedCurve::GetType),
             R"#()#" 
          )
        .def("Line",
             (gp_Lin (GeomAdaptor_TransformedCurve::*)() const) static_cast<gp_Lin (GeomAdaptor_TransformedCurve::*)() const>(&GeomAdaptor_TransformedCurve::Line),
             R"#()#" 
          )
        .def("Circle",
             (gp_Circ (GeomAdaptor_TransformedCurve::*)() const) static_cast<gp_Circ (GeomAdaptor_TransformedCurve::*)() const>(&GeomAdaptor_TransformedCurve::Circle),
             R"#()#" 
          )
        .def("Ellipse",
             (gp_Elips (GeomAdaptor_TransformedCurve::*)() const) static_cast<gp_Elips (GeomAdaptor_TransformedCurve::*)() const>(&GeomAdaptor_TransformedCurve::Ellipse),
             R"#()#" 
          )
        .def("Hyperbola",
             (gp_Hypr (GeomAdaptor_TransformedCurve::*)() const) static_cast<gp_Hypr (GeomAdaptor_TransformedCurve::*)() const>(&GeomAdaptor_TransformedCurve::Hyperbola),
             R"#()#" 
          )
        .def("Parabola",
             (gp_Parab (GeomAdaptor_TransformedCurve::*)() const) static_cast<gp_Parab (GeomAdaptor_TransformedCurve::*)() const>(&GeomAdaptor_TransformedCurve::Parabola),
             R"#()#" 
          )
        .def("Degree",
             (int (GeomAdaptor_TransformedCurve::*)() const) static_cast<int (GeomAdaptor_TransformedCurve::*)() const>(&GeomAdaptor_TransformedCurve::Degree),
             R"#()#" 
          )
        .def("IsRational",
             (bool (GeomAdaptor_TransformedCurve::*)() const) static_cast<bool (GeomAdaptor_TransformedCurve::*)() const>(&GeomAdaptor_TransformedCurve::IsRational),
             R"#()#" 
          )
        .def("NbPoles",
             (int (GeomAdaptor_TransformedCurve::*)() const) static_cast<int (GeomAdaptor_TransformedCurve::*)() const>(&GeomAdaptor_TransformedCurve::NbPoles),
             R"#()#" 
          )
        .def("NbKnots",
             (int (GeomAdaptor_TransformedCurve::*)() const) static_cast<int (GeomAdaptor_TransformedCurve::*)() const>(&GeomAdaptor_TransformedCurve::NbKnots),
             R"#()#" 
          )
        .def("Bezier",
             (handle<Geom_BezierCurve> (GeomAdaptor_TransformedCurve::*)() const) static_cast<handle<Geom_BezierCurve> (GeomAdaptor_TransformedCurve::*)() const>(&GeomAdaptor_TransformedCurve::Bezier),
             R"#()#" 
          )
        .def("BSpline",
             (handle<Geom_BSplineCurve> (GeomAdaptor_TransformedCurve::*)() const) static_cast<handle<Geom_BSplineCurve> (GeomAdaptor_TransformedCurve::*)() const>(&GeomAdaptor_TransformedCurve::BSpline),
             R"#()#" 
          )
        .def("OffsetCurve",
             (handle<Geom_OffsetCurve> (GeomAdaptor_TransformedCurve::*)() const) static_cast<handle<Geom_OffsetCurve> (GeomAdaptor_TransformedCurve::*)() const>(&GeomAdaptor_TransformedCurve::OffsetCurve),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&GeomAdaptor_TransformedCurve::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&GeomAdaptor_TransformedCurve::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (GeomAdaptor_TransformedCurve::*)() const) static_cast< const handle<Standard_Type> & (GeomAdaptor_TransformedCurve::*)() const>(&GeomAdaptor_TransformedCurve::DynamicType),
             R"#()#"
             
         )
       .def("Trsf",
             ( const gp_Trsf & (GeomAdaptor_TransformedCurve::*)() const) static_cast< const gp_Trsf & (GeomAdaptor_TransformedCurve::*)() const>(&GeomAdaptor_TransformedCurve::Trsf),
             R"#(Returns the transformation.)#"
             
         )
       .def("Curve",
             ( const GeomAdaptor_Curve & (GeomAdaptor_TransformedCurve::*)() const) static_cast< const GeomAdaptor_Curve & (GeomAdaptor_TransformedCurve::*)() const>(&GeomAdaptor_TransformedCurve::Curve),
             R"#(Returns the underlying GeomAdaptor_Curve.)#"
             
         )
       .def("ChangeCurve",
             (GeomAdaptor_Curve & (GeomAdaptor_TransformedCurve::*)() ) static_cast<GeomAdaptor_Curve & (GeomAdaptor_TransformedCurve::*)() >(&GeomAdaptor_TransformedCurve::ChangeCurve),
             R"#(Returns the underlying GeomAdaptor_Curve for modification.)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("CurveOnSurface",
             ( const Adaptor3d_CurveOnSurface & (GeomAdaptor_TransformedCurve::*)() const) static_cast< const Adaptor3d_CurveOnSurface & (GeomAdaptor_TransformedCurve::*)() const>(&GeomAdaptor_TransformedCurve::CurveOnSurface),
             R"#(Returns the CurveOnSurface adaptor.)#"
             
         )
       .def("GeomCurve",
             ( const handle<Geom_Curve> & (GeomAdaptor_TransformedCurve::*)() const) static_cast< const handle<Geom_Curve> & (GeomAdaptor_TransformedCurve::*)() const>(&GeomAdaptor_TransformedCurve::GeomCurve),
             R"#(Returns the underlying Geom_Curve.)#"
             
         )
;

    // Class GeomAdaptor_TransformedSurface from ./opencascade/GeomAdaptor_TransformedSurface.hxx
    klass = m.attr("GeomAdaptor_TransformedSurface");


    // nested enums

    static_cast<py::class_<GeomAdaptor_TransformedSurface ,opencascade::handle<GeomAdaptor_TransformedSurface>  , Adaptor3d_Surface >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<Geom_Surface> &, const double, const double, const double, const double, const gp_Trsf &, const double, const double >()  , py::arg("theSurface"),  py::arg("theUFirst"),  py::arg("theULast"),  py::arg("theVFirst"),  py::arg("theVLast"),  py::arg("theTrsf"),  py::arg("theTolU")=static_cast< const double>(0.0),  py::arg("theTolV")=static_cast< const double>(0.0) )
        .def(py::init<  const handle<Geom_Surface> &, const gp_Trsf & >()  , py::arg("theSurface"),  py::arg("theTrsf") )
    // custom constructors
    // methods
        .def("ShallowCopy",
             (handle<Adaptor3d_Surface> (GeomAdaptor_TransformedSurface::*)() const) static_cast<handle<Adaptor3d_Surface> (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::ShallowCopy),
             R"#(Shallow copy of adaptor.)#" 
          )
        .def("Load",
             (void (GeomAdaptor_TransformedSurface::*)(  const handle<Geom_Surface> & ,   const gp_Trsf &  ) ) static_cast<void (GeomAdaptor_TransformedSurface::*)(  const handle<Geom_Surface> & ,   const gp_Trsf &  ) >(&GeomAdaptor_TransformedSurface::Load),
             R"#(Loads the surface geometry.)#"  , py::arg("theSurface"),  py::arg("theTrsf")
          )
        .def("Load",
             (void (GeomAdaptor_TransformedSurface::*)(  const handle<Geom_Surface> & ,   const double ,   const double ,   const double ,   const double ,   const gp_Trsf & ,   const double ,   const double  ) ) static_cast<void (GeomAdaptor_TransformedSurface::*)(  const handle<Geom_Surface> & ,   const double ,   const double ,   const double ,   const double ,   const gp_Trsf & ,   const double ,   const double  ) >(&GeomAdaptor_TransformedSurface::Load),
             R"#(Loads the surface geometry with parameter bounds.)#"  , py::arg("theSurface"),  py::arg("theUFirst"),  py::arg("theULast"),  py::arg("theVFirst"),  py::arg("theVLast"),  py::arg("theTrsf"),  py::arg("theTolU")=static_cast< const double>(0.0),  py::arg("theTolV")=static_cast< const double>(0.0)
          )
        .def("SetTrsf",
             (void (GeomAdaptor_TransformedSurface::*)(  const gp_Trsf &  ) ) static_cast<void (GeomAdaptor_TransformedSurface::*)(  const gp_Trsf &  ) >(&GeomAdaptor_TransformedSurface::SetTrsf),
             R"#(Sets the transformation.)#"  , py::arg("theTrsf")
          )
        .def("HasTrsf",
             (bool (GeomAdaptor_TransformedSurface::*)() const) static_cast<bool (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::HasTrsf),
             R"#(Returns true if non-identity transformation is applied.)#" 
          )
        .def("FirstUParameter",
             (double (GeomAdaptor_TransformedSurface::*)() const) static_cast<double (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::FirstUParameter),
             R"#()#" 
          )
        .def("LastUParameter",
             (double (GeomAdaptor_TransformedSurface::*)() const) static_cast<double (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::LastUParameter),
             R"#()#" 
          )
        .def("FirstVParameter",
             (double (GeomAdaptor_TransformedSurface::*)() const) static_cast<double (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::FirstVParameter),
             R"#()#" 
          )
        .def("LastVParameter",
             (double (GeomAdaptor_TransformedSurface::*)() const) static_cast<double (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::LastVParameter),
             R"#()#" 
          )
        .def("UContinuity",
             (GeomAbs_Shape (GeomAdaptor_TransformedSurface::*)() const) static_cast<GeomAbs_Shape (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::UContinuity),
             R"#()#" 
          )
        .def("VContinuity",
             (GeomAbs_Shape (GeomAdaptor_TransformedSurface::*)() const) static_cast<GeomAbs_Shape (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::VContinuity),
             R"#()#" 
          )
        .def("NbUIntervals",
             (int (GeomAdaptor_TransformedSurface::*)(  const GeomAbs_Shape  ) const) static_cast<int (GeomAdaptor_TransformedSurface::*)(  const GeomAbs_Shape  ) const>(&GeomAdaptor_TransformedSurface::NbUIntervals),
             R"#()#"  , py::arg("theS")
          )
        .def("NbVIntervals",
             (int (GeomAdaptor_TransformedSurface::*)(  const GeomAbs_Shape  ) const) static_cast<int (GeomAdaptor_TransformedSurface::*)(  const GeomAbs_Shape  ) const>(&GeomAdaptor_TransformedSurface::NbVIntervals),
             R"#()#"  , py::arg("theS")
          )
        .def("UIntervals",
             (void (GeomAdaptor_TransformedSurface::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const) static_cast<void (GeomAdaptor_TransformedSurface::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const>(&GeomAdaptor_TransformedSurface::UIntervals),
             R"#()#"  , py::arg("theT"),  py::arg("theS")
          )
        .def("VIntervals",
             (void (GeomAdaptor_TransformedSurface::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const) static_cast<void (GeomAdaptor_TransformedSurface::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const>(&GeomAdaptor_TransformedSurface::VIntervals),
             R"#()#"  , py::arg("theT"),  py::arg("theS")
          )
        .def("UTrim",
             (handle<Adaptor3d_Surface> (GeomAdaptor_TransformedSurface::*)(  const double ,   const double ,   const double  ) const) static_cast<handle<Adaptor3d_Surface> (GeomAdaptor_TransformedSurface::*)(  const double ,   const double ,   const double  ) const>(&GeomAdaptor_TransformedSurface::UTrim),
             R"#()#"  , py::arg("theFirst"),  py::arg("theLast"),  py::arg("theTol")
          )
        .def("VTrim",
             (handle<Adaptor3d_Surface> (GeomAdaptor_TransformedSurface::*)(  const double ,   const double ,   const double  ) const) static_cast<handle<Adaptor3d_Surface> (GeomAdaptor_TransformedSurface::*)(  const double ,   const double ,   const double  ) const>(&GeomAdaptor_TransformedSurface::VTrim),
             R"#()#"  , py::arg("theFirst"),  py::arg("theLast"),  py::arg("theTol")
          )
        .def("IsUClosed",
             (bool (GeomAdaptor_TransformedSurface::*)() const) static_cast<bool (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::IsUClosed),
             R"#()#" 
          )
        .def("IsVClosed",
             (bool (GeomAdaptor_TransformedSurface::*)() const) static_cast<bool (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::IsVClosed),
             R"#()#" 
          )
        .def("IsUPeriodic",
             (bool (GeomAdaptor_TransformedSurface::*)() const) static_cast<bool (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::IsUPeriodic),
             R"#()#" 
          )
        .def("UPeriod",
             (double (GeomAdaptor_TransformedSurface::*)() const) static_cast<double (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::UPeriod),
             R"#()#" 
          )
        .def("IsVPeriodic",
             (bool (GeomAdaptor_TransformedSurface::*)() const) static_cast<bool (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::IsVPeriodic),
             R"#()#" 
          )
        .def("VPeriod",
             (double (GeomAdaptor_TransformedSurface::*)() const) static_cast<double (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::VPeriod),
             R"#()#" 
          )
        .def("ToleranceU",
             (double (GeomAdaptor_TransformedSurface::*)() const) static_cast<double (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::ToleranceU),
             R"#(Returns tolerance in U direction.)#" 
          )
        .def("ToleranceV",
             (double (GeomAdaptor_TransformedSurface::*)() const) static_cast<double (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::ToleranceV),
             R"#(Returns tolerance in V direction.)#" 
          )
        .def("EvalD0",
             (gp_Pnt (GeomAdaptor_TransformedSurface::*)(  const double ,   const double  ) const) static_cast<gp_Pnt (GeomAdaptor_TransformedSurface::*)(  const double ,   const double  ) const>(&GeomAdaptor_TransformedSurface::EvalD0),
             R"#(Point evaluation. Applies transformation after evaluation.)#"  , py::arg("theU"),  py::arg("theV")
          )
        .def("EvalD1",
             (Geom_Surface::ResD1 (GeomAdaptor_TransformedSurface::*)(  const double ,   const double  ) const) static_cast<Geom_Surface::ResD1 (GeomAdaptor_TransformedSurface::*)(  const double ,   const double  ) const>(&GeomAdaptor_TransformedSurface::EvalD1),
             R"#(D1 evaluation. Applies transformation after evaluation.)#"  , py::arg("theU"),  py::arg("theV")
          )
        .def("EvalD2",
             (Geom_Surface::ResD2 (GeomAdaptor_TransformedSurface::*)(  const double ,   const double  ) const) static_cast<Geom_Surface::ResD2 (GeomAdaptor_TransformedSurface::*)(  const double ,   const double  ) const>(&GeomAdaptor_TransformedSurface::EvalD2),
             R"#(D2 evaluation. Applies transformation after evaluation.)#"  , py::arg("theU"),  py::arg("theV")
          )
        .def("EvalD3",
             (Geom_Surface::ResD3 (GeomAdaptor_TransformedSurface::*)(  const double ,   const double  ) const) static_cast<Geom_Surface::ResD3 (GeomAdaptor_TransformedSurface::*)(  const double ,   const double  ) const>(&GeomAdaptor_TransformedSurface::EvalD3),
             R"#(D3 evaluation. Applies transformation after evaluation.)#"  , py::arg("theU"),  py::arg("theV")
          )
        .def("EvalDN",
             (gp_Vec (GeomAdaptor_TransformedSurface::*)(  const double ,   const double ,   const int ,   const int  ) const) static_cast<gp_Vec (GeomAdaptor_TransformedSurface::*)(  const double ,   const double ,   const int ,   const int  ) const>(&GeomAdaptor_TransformedSurface::EvalDN),
             R"#(DN evaluation. Applies transformation after evaluation.)#"  , py::arg("theU"),  py::arg("theV"),  py::arg("theNu"),  py::arg("theNv")
          )
        .def("UResolution",
             (double (GeomAdaptor_TransformedSurface::*)(  const double  ) const) static_cast<double (GeomAdaptor_TransformedSurface::*)(  const double  ) const>(&GeomAdaptor_TransformedSurface::UResolution),
             R"#()#"  , py::arg("theR3d")
          )
        .def("VResolution",
             (double (GeomAdaptor_TransformedSurface::*)(  const double  ) const) static_cast<double (GeomAdaptor_TransformedSurface::*)(  const double  ) const>(&GeomAdaptor_TransformedSurface::VResolution),
             R"#()#"  , py::arg("theR3d")
          )
        .def("GetType",
             (GeomAbs_SurfaceType (GeomAdaptor_TransformedSurface::*)() const) static_cast<GeomAbs_SurfaceType (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::GetType),
             R"#()#" 
          )
        .def("Plane",
             (gp_Pln (GeomAdaptor_TransformedSurface::*)() const) static_cast<gp_Pln (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::Plane),
             R"#()#" 
          )
        .def("Cylinder",
             (gp_Cylinder (GeomAdaptor_TransformedSurface::*)() const) static_cast<gp_Cylinder (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::Cylinder),
             R"#()#" 
          )
        .def("Cone",
             (gp_Cone (GeomAdaptor_TransformedSurface::*)() const) static_cast<gp_Cone (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::Cone),
             R"#()#" 
          )
        .def("Sphere",
             (gp_Sphere (GeomAdaptor_TransformedSurface::*)() const) static_cast<gp_Sphere (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::Sphere),
             R"#()#" 
          )
        .def("Torus",
             (gp_Torus (GeomAdaptor_TransformedSurface::*)() const) static_cast<gp_Torus (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::Torus),
             R"#()#" 
          )
        .def("UDegree",
             (int (GeomAdaptor_TransformedSurface::*)() const) static_cast<int (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::UDegree),
             R"#()#" 
          )
        .def("NbUPoles",
             (int (GeomAdaptor_TransformedSurface::*)() const) static_cast<int (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::NbUPoles),
             R"#()#" 
          )
        .def("VDegree",
             (int (GeomAdaptor_TransformedSurface::*)() const) static_cast<int (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::VDegree),
             R"#()#" 
          )
        .def("NbVPoles",
             (int (GeomAdaptor_TransformedSurface::*)() const) static_cast<int (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::NbVPoles),
             R"#()#" 
          )
        .def("NbUKnots",
             (int (GeomAdaptor_TransformedSurface::*)() const) static_cast<int (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::NbUKnots),
             R"#()#" 
          )
        .def("NbVKnots",
             (int (GeomAdaptor_TransformedSurface::*)() const) static_cast<int (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::NbVKnots),
             R"#()#" 
          )
        .def("IsURational",
             (bool (GeomAdaptor_TransformedSurface::*)() const) static_cast<bool (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::IsURational),
             R"#()#" 
          )
        .def("IsVRational",
             (bool (GeomAdaptor_TransformedSurface::*)() const) static_cast<bool (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::IsVRational),
             R"#()#" 
          )
        .def("Bezier",
             (handle<Geom_BezierSurface> (GeomAdaptor_TransformedSurface::*)() const) static_cast<handle<Geom_BezierSurface> (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::Bezier),
             R"#()#" 
          )
        .def("BSpline",
             (handle<Geom_BSplineSurface> (GeomAdaptor_TransformedSurface::*)() const) static_cast<handle<Geom_BSplineSurface> (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::BSpline),
             R"#()#" 
          )
        .def("AxeOfRevolution",
             (gp_Ax1 (GeomAdaptor_TransformedSurface::*)() const) static_cast<gp_Ax1 (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::AxeOfRevolution),
             R"#()#" 
          )
        .def("Direction",
             (gp_Dir (GeomAdaptor_TransformedSurface::*)() const) static_cast<gp_Dir (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::Direction),
             R"#()#" 
          )
        .def("BasisCurve",
             (handle<Adaptor3d_Curve> (GeomAdaptor_TransformedSurface::*)() const) static_cast<handle<Adaptor3d_Curve> (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::BasisCurve),
             R"#()#" 
          )
        .def("BasisSurface",
             (handle<Adaptor3d_Surface> (GeomAdaptor_TransformedSurface::*)() const) static_cast<handle<Adaptor3d_Surface> (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::BasisSurface),
             R"#()#" 
          )
        .def("OffsetValue",
             (double (GeomAdaptor_TransformedSurface::*)() const) static_cast<double (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::OffsetValue),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&GeomAdaptor_TransformedSurface::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&GeomAdaptor_TransformedSurface::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (GeomAdaptor_TransformedSurface::*)() const) static_cast< const handle<Standard_Type> & (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::DynamicType),
             R"#()#"
             
         )
       .def("Trsf",
             ( const gp_Trsf & (GeomAdaptor_TransformedSurface::*)() const) static_cast< const gp_Trsf & (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::Trsf),
             R"#(Returns the transformation.)#"
             
         )
       .def("Surface",
             ( const GeomAdaptor_Surface & (GeomAdaptor_TransformedSurface::*)() const) static_cast< const GeomAdaptor_Surface & (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::Surface),
             R"#(Returns the underlying GeomAdaptor_Surface.)#"
             
         )
       .def("AdaptorSurfaceOriginal",
             ( const GeomAdaptor_Surface & (GeomAdaptor_TransformedSurface::*)() const) static_cast< const GeomAdaptor_Surface & (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::AdaptorSurfaceOriginal),
             R"#(Returns the underlying original GeomAdaptor_Surface without transformation applied.)#"
             
         )
       .def("AdaptorSurfaceTransformed",
             ( const GeomAdaptor_Surface & (GeomAdaptor_TransformedSurface::*)() const) static_cast< const GeomAdaptor_Surface & (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::AdaptorSurfaceTransformed),
             R"#(Returns an adaptor for the transformed surface state. Uses the original adaptor for identity transformation to preserve existing trimming.)#"
             
         )
       .def("GeomSurfaceOriginal",
             ( const handle<Geom_Surface> & (GeomAdaptor_TransformedSurface::*)() const) static_cast< const handle<Geom_Surface> & (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::GeomSurfaceOriginal),
             R"#(Returns the underlying original Geom_Surface without transformation applied.)#"
             
         )
       .def("GeomSurfaceTransformed",
             ( const handle<Geom_Surface> & (GeomAdaptor_TransformedSurface::*)() const) static_cast< const handle<Geom_Surface> & (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::GeomSurfaceTransformed),
             R"#(Returns the transformed Geom_Surface cached for current state.)#"
             
         )
       .def("GeomSurface",
             ( const handle<Geom_Surface> & (GeomAdaptor_TransformedSurface::*)() const) static_cast< const handle<Geom_Surface> & (GeomAdaptor_TransformedSurface::*)() const>(&GeomAdaptor_TransformedSurface::GeomSurface),
             R"#(Returns the underlying Geom_Surface.)#"
             
         )
;

    // Class GeomAdaptor_SurfaceOfLinearExtrusion from ./opencascade/GeomAdaptor_SurfaceOfLinearExtrusion.hxx
    klass = m.attr("GeomAdaptor_SurfaceOfLinearExtrusion");


    // nested enums

    static_cast<py::class_<GeomAdaptor_SurfaceOfLinearExtrusion ,opencascade::handle<GeomAdaptor_SurfaceOfLinearExtrusion>  , GeomAdaptor_Surface >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<Adaptor3d_Curve> & >()  , py::arg("C") )
        .def(py::init<  const handle<Adaptor3d_Curve> &, const gp_Dir & >()  , py::arg("C"),  py::arg("V") )
    // custom constructors
    // methods
        .def("ShallowCopy",
             (handle<Adaptor3d_Surface> (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const) static_cast<handle<Adaptor3d_Surface> (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const>(&GeomAdaptor_SurfaceOfLinearExtrusion::ShallowCopy),
             R"#(Shallow copy of adaptor)#" 
          )
        .def("Load",
             (void (GeomAdaptor_SurfaceOfLinearExtrusion::*)(  const handle<Adaptor3d_Curve> &  ) ) static_cast<void (GeomAdaptor_SurfaceOfLinearExtrusion::*)(  const handle<Adaptor3d_Curve> &  ) >(&GeomAdaptor_SurfaceOfLinearExtrusion::Load),
             R"#(Changes the Curve)#"  , py::arg("C")
          )
        .def("Load",
             (void (GeomAdaptor_SurfaceOfLinearExtrusion::*)(  const gp_Dir &  ) ) static_cast<void (GeomAdaptor_SurfaceOfLinearExtrusion::*)(  const gp_Dir &  ) >(&GeomAdaptor_SurfaceOfLinearExtrusion::Load),
             R"#(Changes the Direction)#"  , py::arg("V")
          )
        .def("FirstUParameter",
             (double (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const) static_cast<double (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const>(&GeomAdaptor_SurfaceOfLinearExtrusion::FirstUParameter),
             R"#()#" 
          )
        .def("LastUParameter",
             (double (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const) static_cast<double (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const>(&GeomAdaptor_SurfaceOfLinearExtrusion::LastUParameter),
             R"#()#" 
          )
        .def("FirstVParameter",
             (double (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const) static_cast<double (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const>(&GeomAdaptor_SurfaceOfLinearExtrusion::FirstVParameter),
             R"#()#" 
          )
        .def("LastVParameter",
             (double (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const) static_cast<double (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const>(&GeomAdaptor_SurfaceOfLinearExtrusion::LastVParameter),
             R"#()#" 
          )
        .def("UContinuity",
             (GeomAbs_Shape (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const) static_cast<GeomAbs_Shape (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const>(&GeomAdaptor_SurfaceOfLinearExtrusion::UContinuity),
             R"#()#" 
          )
        .def("VContinuity",
             (GeomAbs_Shape (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const) static_cast<GeomAbs_Shape (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const>(&GeomAdaptor_SurfaceOfLinearExtrusion::VContinuity),
             R"#(Return CN.)#" 
          )
        .def("NbUIntervals",
             (int (GeomAdaptor_SurfaceOfLinearExtrusion::*)(  const GeomAbs_Shape  ) const) static_cast<int (GeomAdaptor_SurfaceOfLinearExtrusion::*)(  const GeomAbs_Shape  ) const>(&GeomAdaptor_SurfaceOfLinearExtrusion::NbUIntervals),
             R"#(Returns the number of U intervals for continuity <S>. May be one if UContinuity(me) >= <S>)#"  , py::arg("S")
          )
        .def("NbVIntervals",
             (int (GeomAdaptor_SurfaceOfLinearExtrusion::*)(  const GeomAbs_Shape  ) const) static_cast<int (GeomAdaptor_SurfaceOfLinearExtrusion::*)(  const GeomAbs_Shape  ) const>(&GeomAdaptor_SurfaceOfLinearExtrusion::NbVIntervals),
             R"#(Returns the number of V intervals for continuity <S>. May be one if VContinuity(me) >= <S>)#"  , py::arg("S")
          )
        .def("UIntervals",
             (void (GeomAdaptor_SurfaceOfLinearExtrusion::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const) static_cast<void (GeomAdaptor_SurfaceOfLinearExtrusion::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const>(&GeomAdaptor_SurfaceOfLinearExtrusion::UIntervals),
             R"#(Returns the intervals with the requested continuity in the U direction.)#"  , py::arg("T"),  py::arg("S")
          )
        .def("VIntervals",
             (void (GeomAdaptor_SurfaceOfLinearExtrusion::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const) static_cast<void (GeomAdaptor_SurfaceOfLinearExtrusion::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const>(&GeomAdaptor_SurfaceOfLinearExtrusion::VIntervals),
             R"#(Returns the intervals with the requested continuity in the V direction.)#"  , py::arg("T"),  py::arg("S")
          )
        .def("UTrim",
             (handle<Adaptor3d_Surface> (GeomAdaptor_SurfaceOfLinearExtrusion::*)(  const double ,   const double ,   const double  ) const) static_cast<handle<Adaptor3d_Surface> (GeomAdaptor_SurfaceOfLinearExtrusion::*)(  const double ,   const double ,   const double  ) const>(&GeomAdaptor_SurfaceOfLinearExtrusion::UTrim),
             R"#(Returns a surface trimmed in the U direction equivalent of <me> between parameters <First> and <Last>. <Tol> is used to test for 3d points confusion. If <First> >= <Last>)#"  , py::arg("First"),  py::arg("Last"),  py::arg("Tol")
          )
        .def("VTrim",
             (handle<Adaptor3d_Surface> (GeomAdaptor_SurfaceOfLinearExtrusion::*)(  const double ,   const double ,   const double  ) const) static_cast<handle<Adaptor3d_Surface> (GeomAdaptor_SurfaceOfLinearExtrusion::*)(  const double ,   const double ,   const double  ) const>(&GeomAdaptor_SurfaceOfLinearExtrusion::VTrim),
             R"#(Returns a surface trimmed in the V direction between parameters <First> and <Last>. <Tol> is used to test for 3d points confusion. If <First> >= <Last>)#"  , py::arg("First"),  py::arg("Last"),  py::arg("Tol")
          )
        .def("IsUClosed",
             (bool (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const) static_cast<bool (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const>(&GeomAdaptor_SurfaceOfLinearExtrusion::IsUClosed),
             R"#()#" 
          )
        .def("IsVClosed",
             (bool (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const) static_cast<bool (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const>(&GeomAdaptor_SurfaceOfLinearExtrusion::IsVClosed),
             R"#()#" 
          )
        .def("IsUPeriodic",
             (bool (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const) static_cast<bool (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const>(&GeomAdaptor_SurfaceOfLinearExtrusion::IsUPeriodic),
             R"#()#" 
          )
        .def("UPeriod",
             (double (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const) static_cast<double (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const>(&GeomAdaptor_SurfaceOfLinearExtrusion::UPeriod),
             R"#()#" 
          )
        .def("IsVPeriodic",
             (bool (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const) static_cast<bool (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const>(&GeomAdaptor_SurfaceOfLinearExtrusion::IsVPeriodic),
             R"#()#" 
          )
        .def("VPeriod",
             (double (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const) static_cast<double (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const>(&GeomAdaptor_SurfaceOfLinearExtrusion::VPeriod),
             R"#()#" 
          )
        .def("UResolution",
             (double (GeomAdaptor_SurfaceOfLinearExtrusion::*)(  const double  ) const) static_cast<double (GeomAdaptor_SurfaceOfLinearExtrusion::*)(  const double  ) const>(&GeomAdaptor_SurfaceOfLinearExtrusion::UResolution),
             R"#(Returns the parametric U resolution corresponding to the real space resolution <R3d>.)#"  , py::arg("R3d")
          )
        .def("VResolution",
             (double (GeomAdaptor_SurfaceOfLinearExtrusion::*)(  const double  ) const) static_cast<double (GeomAdaptor_SurfaceOfLinearExtrusion::*)(  const double  ) const>(&GeomAdaptor_SurfaceOfLinearExtrusion::VResolution),
             R"#(Returns the parametric V resolution corresponding to the real space resolution <R3d>.)#"  , py::arg("R3d")
          )
        .def("GetType",
             (GeomAbs_SurfaceType (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const) static_cast<GeomAbs_SurfaceType (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const>(&GeomAdaptor_SurfaceOfLinearExtrusion::GetType),
             R"#(Returns the type of the surface: Plane, Cylinder, Cone, Sphere, Torus, BezierSurface, BSplineSurface, SurfaceOfRevolution, SurfaceOfExtrusion, OtherSurface)#" 
          )
        .def("Plane",
             (gp_Pln (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const) static_cast<gp_Pln (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const>(&GeomAdaptor_SurfaceOfLinearExtrusion::Plane),
             R"#()#" 
          )
        .def("Cylinder",
             (gp_Cylinder (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const) static_cast<gp_Cylinder (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const>(&GeomAdaptor_SurfaceOfLinearExtrusion::Cylinder),
             R"#()#" 
          )
        .def("Cone",
             (gp_Cone (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const) static_cast<gp_Cone (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const>(&GeomAdaptor_SurfaceOfLinearExtrusion::Cone),
             R"#()#" 
          )
        .def("Sphere",
             (gp_Sphere (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const) static_cast<gp_Sphere (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const>(&GeomAdaptor_SurfaceOfLinearExtrusion::Sphere),
             R"#()#" 
          )
        .def("Torus",
             (gp_Torus (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const) static_cast<gp_Torus (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const>(&GeomAdaptor_SurfaceOfLinearExtrusion::Torus),
             R"#()#" 
          )
        .def("UDegree",
             (int (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const) static_cast<int (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const>(&GeomAdaptor_SurfaceOfLinearExtrusion::UDegree),
             R"#()#" 
          )
        .def("NbUPoles",
             (int (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const) static_cast<int (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const>(&GeomAdaptor_SurfaceOfLinearExtrusion::NbUPoles),
             R"#()#" 
          )
        .def("IsURational",
             (bool (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const) static_cast<bool (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const>(&GeomAdaptor_SurfaceOfLinearExtrusion::IsURational),
             R"#()#" 
          )
        .def("IsVRational",
             (bool (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const) static_cast<bool (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const>(&GeomAdaptor_SurfaceOfLinearExtrusion::IsVRational),
             R"#()#" 
          )
        .def("Bezier",
             (handle<Geom_BezierSurface> (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const) static_cast<handle<Geom_BezierSurface> (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const>(&GeomAdaptor_SurfaceOfLinearExtrusion::Bezier),
             R"#()#" 
          )
        .def("BSpline",
             (handle<Geom_BSplineSurface> (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const) static_cast<handle<Geom_BSplineSurface> (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const>(&GeomAdaptor_SurfaceOfLinearExtrusion::BSpline),
             R"#()#" 
          )
        .def("AxeOfRevolution",
             (gp_Ax1 (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const) static_cast<gp_Ax1 (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const>(&GeomAdaptor_SurfaceOfLinearExtrusion::AxeOfRevolution),
             R"#()#" 
          )
        .def("Direction",
             (gp_Dir (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const) static_cast<gp_Dir (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const>(&GeomAdaptor_SurfaceOfLinearExtrusion::Direction),
             R"#()#" 
          )
        .def("BasisCurve",
             (handle<Adaptor3d_Curve> (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const) static_cast<handle<Adaptor3d_Curve> (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const>(&GeomAdaptor_SurfaceOfLinearExtrusion::BasisCurve),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&GeomAdaptor_SurfaceOfLinearExtrusion::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&GeomAdaptor_SurfaceOfLinearExtrusion::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const) static_cast< const handle<Standard_Type> & (GeomAdaptor_SurfaceOfLinearExtrusion::*)() const>(&GeomAdaptor_SurfaceOfLinearExtrusion::DynamicType),
             R"#()#"
             
         )
;

    // Class GeomAdaptor_SurfaceOfRevolution from ./opencascade/GeomAdaptor_SurfaceOfRevolution.hxx
    klass = m.attr("GeomAdaptor_SurfaceOfRevolution");


    // nested enums

    static_cast<py::class_<GeomAdaptor_SurfaceOfRevolution ,opencascade::handle<GeomAdaptor_SurfaceOfRevolution>  , GeomAdaptor_Surface >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<Adaptor3d_Curve> & >()  , py::arg("C") )
        .def(py::init<  const handle<Adaptor3d_Curve> &, const gp_Ax1 & >()  , py::arg("C"),  py::arg("V") )
    // custom constructors
    // methods
        .def("ShallowCopy",
             (handle<Adaptor3d_Surface> (GeomAdaptor_SurfaceOfRevolution::*)() const) static_cast<handle<Adaptor3d_Surface> (GeomAdaptor_SurfaceOfRevolution::*)() const>(&GeomAdaptor_SurfaceOfRevolution::ShallowCopy),
             R"#(Shallow copy of adaptor)#" 
          )
        .def("Load",
             (void (GeomAdaptor_SurfaceOfRevolution::*)(  const handle<Adaptor3d_Curve> &  ) ) static_cast<void (GeomAdaptor_SurfaceOfRevolution::*)(  const handle<Adaptor3d_Curve> &  ) >(&GeomAdaptor_SurfaceOfRevolution::Load),
             R"#(Changes the Curve)#"  , py::arg("C")
          )
        .def("Load",
             (void (GeomAdaptor_SurfaceOfRevolution::*)(  const gp_Ax1 &  ) ) static_cast<void (GeomAdaptor_SurfaceOfRevolution::*)(  const gp_Ax1 &  ) >(&GeomAdaptor_SurfaceOfRevolution::Load),
             R"#(Changes the Direction)#"  , py::arg("V")
          )
        .def("AxeOfRevolution",
             (gp_Ax1 (GeomAdaptor_SurfaceOfRevolution::*)() const) static_cast<gp_Ax1 (GeomAdaptor_SurfaceOfRevolution::*)() const>(&GeomAdaptor_SurfaceOfRevolution::AxeOfRevolution),
             R"#()#" 
          )
        .def("FirstUParameter",
             (double (GeomAdaptor_SurfaceOfRevolution::*)() const) static_cast<double (GeomAdaptor_SurfaceOfRevolution::*)() const>(&GeomAdaptor_SurfaceOfRevolution::FirstUParameter),
             R"#()#" 
          )
        .def("LastUParameter",
             (double (GeomAdaptor_SurfaceOfRevolution::*)() const) static_cast<double (GeomAdaptor_SurfaceOfRevolution::*)() const>(&GeomAdaptor_SurfaceOfRevolution::LastUParameter),
             R"#()#" 
          )
        .def("FirstVParameter",
             (double (GeomAdaptor_SurfaceOfRevolution::*)() const) static_cast<double (GeomAdaptor_SurfaceOfRevolution::*)() const>(&GeomAdaptor_SurfaceOfRevolution::FirstVParameter),
             R"#()#" 
          )
        .def("LastVParameter",
             (double (GeomAdaptor_SurfaceOfRevolution::*)() const) static_cast<double (GeomAdaptor_SurfaceOfRevolution::*)() const>(&GeomAdaptor_SurfaceOfRevolution::LastVParameter),
             R"#()#" 
          )
        .def("UContinuity",
             (GeomAbs_Shape (GeomAdaptor_SurfaceOfRevolution::*)() const) static_cast<GeomAbs_Shape (GeomAdaptor_SurfaceOfRevolution::*)() const>(&GeomAdaptor_SurfaceOfRevolution::UContinuity),
             R"#()#" 
          )
        .def("VContinuity",
             (GeomAbs_Shape (GeomAdaptor_SurfaceOfRevolution::*)() const) static_cast<GeomAbs_Shape (GeomAdaptor_SurfaceOfRevolution::*)() const>(&GeomAdaptor_SurfaceOfRevolution::VContinuity),
             R"#(Return CN.)#" 
          )
        .def("NbUIntervals",
             (int (GeomAdaptor_SurfaceOfRevolution::*)(  const GeomAbs_Shape  ) const) static_cast<int (GeomAdaptor_SurfaceOfRevolution::*)(  const GeomAbs_Shape  ) const>(&GeomAdaptor_SurfaceOfRevolution::NbUIntervals),
             R"#(Returns the number of U intervals for continuity <S>. May be one if UContinuity(me) >= <S>)#"  , py::arg("S")
          )
        .def("NbVIntervals",
             (int (GeomAdaptor_SurfaceOfRevolution::*)(  const GeomAbs_Shape  ) const) static_cast<int (GeomAdaptor_SurfaceOfRevolution::*)(  const GeomAbs_Shape  ) const>(&GeomAdaptor_SurfaceOfRevolution::NbVIntervals),
             R"#(Returns the number of V intervals for continuity <S>. May be one if VContinuity(me) >= <S>)#"  , py::arg("S")
          )
        .def("UIntervals",
             (void (GeomAdaptor_SurfaceOfRevolution::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const) static_cast<void (GeomAdaptor_SurfaceOfRevolution::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const>(&GeomAdaptor_SurfaceOfRevolution::UIntervals),
             R"#(Returns the intervals with the requested continuity in the U direction.)#"  , py::arg("T"),  py::arg("S")
          )
        .def("VIntervals",
             (void (GeomAdaptor_SurfaceOfRevolution::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const) static_cast<void (GeomAdaptor_SurfaceOfRevolution::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const>(&GeomAdaptor_SurfaceOfRevolution::VIntervals),
             R"#(Returns the intervals with the requested continuity in the V direction.)#"  , py::arg("T"),  py::arg("S")
          )
        .def("UTrim",
             (handle<Adaptor3d_Surface> (GeomAdaptor_SurfaceOfRevolution::*)(  const double ,   const double ,   const double  ) const) static_cast<handle<Adaptor3d_Surface> (GeomAdaptor_SurfaceOfRevolution::*)(  const double ,   const double ,   const double  ) const>(&GeomAdaptor_SurfaceOfRevolution::UTrim),
             R"#(Returns a surface trimmed in the U direction equivalent of <me> between parameters <First> and <Last>. <Tol> is used to test for 3d points confusion. If <First> >= <Last>)#"  , py::arg("First"),  py::arg("Last"),  py::arg("Tol")
          )
        .def("VTrim",
             (handle<Adaptor3d_Surface> (GeomAdaptor_SurfaceOfRevolution::*)(  const double ,   const double ,   const double  ) const) static_cast<handle<Adaptor3d_Surface> (GeomAdaptor_SurfaceOfRevolution::*)(  const double ,   const double ,   const double  ) const>(&GeomAdaptor_SurfaceOfRevolution::VTrim),
             R"#(Returns a surface trimmed in the V direction between parameters <First> and <Last>. <Tol> is used to test for 3d points confusion. If <First> >= <Last>)#"  , py::arg("First"),  py::arg("Last"),  py::arg("Tol")
          )
        .def("IsUClosed",
             (bool (GeomAdaptor_SurfaceOfRevolution::*)() const) static_cast<bool (GeomAdaptor_SurfaceOfRevolution::*)() const>(&GeomAdaptor_SurfaceOfRevolution::IsUClosed),
             R"#()#" 
          )
        .def("IsVClosed",
             (bool (GeomAdaptor_SurfaceOfRevolution::*)() const) static_cast<bool (GeomAdaptor_SurfaceOfRevolution::*)() const>(&GeomAdaptor_SurfaceOfRevolution::IsVClosed),
             R"#()#" 
          )
        .def("IsUPeriodic",
             (bool (GeomAdaptor_SurfaceOfRevolution::*)() const) static_cast<bool (GeomAdaptor_SurfaceOfRevolution::*)() const>(&GeomAdaptor_SurfaceOfRevolution::IsUPeriodic),
             R"#()#" 
          )
        .def("UPeriod",
             (double (GeomAdaptor_SurfaceOfRevolution::*)() const) static_cast<double (GeomAdaptor_SurfaceOfRevolution::*)() const>(&GeomAdaptor_SurfaceOfRevolution::UPeriod),
             R"#()#" 
          )
        .def("IsVPeriodic",
             (bool (GeomAdaptor_SurfaceOfRevolution::*)() const) static_cast<bool (GeomAdaptor_SurfaceOfRevolution::*)() const>(&GeomAdaptor_SurfaceOfRevolution::IsVPeriodic),
             R"#()#" 
          )
        .def("VPeriod",
             (double (GeomAdaptor_SurfaceOfRevolution::*)() const) static_cast<double (GeomAdaptor_SurfaceOfRevolution::*)() const>(&GeomAdaptor_SurfaceOfRevolution::VPeriod),
             R"#()#" 
          )
        .def("UResolution",
             (double (GeomAdaptor_SurfaceOfRevolution::*)(  const double  ) const) static_cast<double (GeomAdaptor_SurfaceOfRevolution::*)(  const double  ) const>(&GeomAdaptor_SurfaceOfRevolution::UResolution),
             R"#(Returns the parametric U resolution corresponding to the real space resolution <R3d>.)#"  , py::arg("R3d")
          )
        .def("VResolution",
             (double (GeomAdaptor_SurfaceOfRevolution::*)(  const double  ) const) static_cast<double (GeomAdaptor_SurfaceOfRevolution::*)(  const double  ) const>(&GeomAdaptor_SurfaceOfRevolution::VResolution),
             R"#(Returns the parametric V resolution corresponding to the real space resolution <R3d>.)#"  , py::arg("R3d")
          )
        .def("GetType",
             (GeomAbs_SurfaceType (GeomAdaptor_SurfaceOfRevolution::*)() const) static_cast<GeomAbs_SurfaceType (GeomAdaptor_SurfaceOfRevolution::*)() const>(&GeomAdaptor_SurfaceOfRevolution::GetType),
             R"#(Returns the type of the surface: Plane, Cylinder, Cone, Sphere, Torus, BezierSurface, BSplineSurface, SurfaceOfRevolution, SurfaceOfExtrusion, OtherSurface)#" 
          )
        .def("Plane",
             (gp_Pln (GeomAdaptor_SurfaceOfRevolution::*)() const) static_cast<gp_Pln (GeomAdaptor_SurfaceOfRevolution::*)() const>(&GeomAdaptor_SurfaceOfRevolution::Plane),
             R"#()#" 
          )
        .def("Cylinder",
             (gp_Cylinder (GeomAdaptor_SurfaceOfRevolution::*)() const) static_cast<gp_Cylinder (GeomAdaptor_SurfaceOfRevolution::*)() const>(&GeomAdaptor_SurfaceOfRevolution::Cylinder),
             R"#()#" 
          )
        .def("Cone",
             (gp_Cone (GeomAdaptor_SurfaceOfRevolution::*)() const) static_cast<gp_Cone (GeomAdaptor_SurfaceOfRevolution::*)() const>(&GeomAdaptor_SurfaceOfRevolution::Cone),
             R"#(Apex of the Cone = Cone.Position().Location() ==> ReferenceRadius = 0.)#" 
          )
        .def("Sphere",
             (gp_Sphere (GeomAdaptor_SurfaceOfRevolution::*)() const) static_cast<gp_Sphere (GeomAdaptor_SurfaceOfRevolution::*)() const>(&GeomAdaptor_SurfaceOfRevolution::Sphere),
             R"#()#" 
          )
        .def("Torus",
             (gp_Torus (GeomAdaptor_SurfaceOfRevolution::*)() const) static_cast<gp_Torus (GeomAdaptor_SurfaceOfRevolution::*)() const>(&GeomAdaptor_SurfaceOfRevolution::Torus),
             R"#()#" 
          )
        .def("VDegree",
             (int (GeomAdaptor_SurfaceOfRevolution::*)() const) static_cast<int (GeomAdaptor_SurfaceOfRevolution::*)() const>(&GeomAdaptor_SurfaceOfRevolution::VDegree),
             R"#()#" 
          )
        .def("NbVPoles",
             (int (GeomAdaptor_SurfaceOfRevolution::*)() const) static_cast<int (GeomAdaptor_SurfaceOfRevolution::*)() const>(&GeomAdaptor_SurfaceOfRevolution::NbVPoles),
             R"#()#" 
          )
        .def("NbVKnots",
             (int (GeomAdaptor_SurfaceOfRevolution::*)() const) static_cast<int (GeomAdaptor_SurfaceOfRevolution::*)() const>(&GeomAdaptor_SurfaceOfRevolution::NbVKnots),
             R"#()#" 
          )
        .def("IsURational",
             (bool (GeomAdaptor_SurfaceOfRevolution::*)() const) static_cast<bool (GeomAdaptor_SurfaceOfRevolution::*)() const>(&GeomAdaptor_SurfaceOfRevolution::IsURational),
             R"#()#" 
          )
        .def("IsVRational",
             (bool (GeomAdaptor_SurfaceOfRevolution::*)() const) static_cast<bool (GeomAdaptor_SurfaceOfRevolution::*)() const>(&GeomAdaptor_SurfaceOfRevolution::IsVRational),
             R"#()#" 
          )
        .def("Bezier",
             (handle<Geom_BezierSurface> (GeomAdaptor_SurfaceOfRevolution::*)() const) static_cast<handle<Geom_BezierSurface> (GeomAdaptor_SurfaceOfRevolution::*)() const>(&GeomAdaptor_SurfaceOfRevolution::Bezier),
             R"#()#" 
          )
        .def("BSpline",
             (handle<Geom_BSplineSurface> (GeomAdaptor_SurfaceOfRevolution::*)() const) static_cast<handle<Geom_BSplineSurface> (GeomAdaptor_SurfaceOfRevolution::*)() const>(&GeomAdaptor_SurfaceOfRevolution::BSpline),
             R"#()#" 
          )
        .def("BasisCurve",
             (handle<Adaptor3d_Curve> (GeomAdaptor_SurfaceOfRevolution::*)() const) static_cast<handle<Adaptor3d_Curve> (GeomAdaptor_SurfaceOfRevolution::*)() const>(&GeomAdaptor_SurfaceOfRevolution::BasisCurve),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&GeomAdaptor_SurfaceOfRevolution::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&GeomAdaptor_SurfaceOfRevolution::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (GeomAdaptor_SurfaceOfRevolution::*)() const) static_cast< const handle<Standard_Type> & (GeomAdaptor_SurfaceOfRevolution::*)() const>(&GeomAdaptor_SurfaceOfRevolution::DynamicType),
             R"#()#"
             
         )
       .def("Axis",
             ( const gp_Ax3 & (GeomAdaptor_SurfaceOfRevolution::*)() const) static_cast< const gp_Ax3 & (GeomAdaptor_SurfaceOfRevolution::*)() const>(&GeomAdaptor_SurfaceOfRevolution::Axis),
             R"#()#"
             
         )
;

// functions
auto mGeomEval_RepCurveDesc = static_cast<py::module>(m.attr("GeomEval_RepCurveDesc"));
auto mGeomEval_RepSurfaceDesc = static_cast<py::module>(m.attr("GeomEval_RepSurfaceDesc"));

// ./opencascade/GeomAdaptor.hxx
// ./opencascade/GeomAdaptor_Curve.hxx
// ./opencascade/GeomAdaptor_Surface.hxx
// ./opencascade/GeomAdaptor_SurfaceOfLinearExtrusion.hxx
// ./opencascade/GeomAdaptor_SurfaceOfRevolution.hxx
// ./opencascade/GeomAdaptor_TransformedCurve.hxx
// ./opencascade/GeomAdaptor_TransformedSurface.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
