
// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;


// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TopoDS_Shape.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TopTools_LocationSet.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <TopTools.hxx>
#include <TopTools_FormatVersion.hxx>
#include <TopTools_LocationSet.hxx>
#include <TopTools_LocationSetPtr.hxx>
#include <TopTools_ShapeMapHasher.hxx>
#include <TopTools_ShapeSet.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module
        #include  "NCollection_tmpl.hxx"
        #include  <Bnd_Box.hxx>
        

// Module definiiton
void register_TopTools_enums(py::module &main_module) {


py::module m = main_module.def_submodule("TopTools", R"#()#");

// add namespaces as submodules

// user-defined inclusion per module in the body

// enums
    py::enum_<TopTools_FormatVersion>(m, "TopTools_FormatVersion",R"#(Defined TopTools format version)#")
        .value("TopTools_FormatVersion_VERSION_1",TopTools_FormatVersion::TopTools_FormatVersion_VERSION_1)
        .value("TopTools_FormatVersion_VERSION_2",TopTools_FormatVersion::TopTools_FormatVersion_VERSION_2)
        .value("TopTools_FormatVersion_VERSION_3",TopTools_FormatVersion::TopTools_FormatVersion_VERSION_3)
        .value("TopTools_FormatVersion_CURRENT",TopTools_FormatVersion::TopTools_FormatVersion_CURRENT).export_values();
    m.attr("TopTools_FormatVersion_LOWER") = py::cast(int(TopTools_FormatVersion_LOWER));
    m.attr("TopTools_FormatVersion_UPPER") = py::cast(int(TopTools_FormatVersion_UPPER));

//Python trampoline classes

// pre-register typdefs+classes (topologically sorted)
    py::class_<TopTools , shared_ptr<TopTools>  >(
      m,
      "TopTools",R"#(The TopTools package provides utilities for the topological data structure.)#"
    );
    py::class_<TopTools_LocationSet , shared_ptr<TopTools_LocationSet>  >(
      m,
      "TopTools_LocationSet",R"#(The class LocationSet stores a set of location in a relocatable state.)#"
    );
    py::class_<TopTools_ShapeMapHasher , shared_ptr<TopTools_ShapeMapHasher>  >(
      m,
      "TopTools_ShapeMapHasher",R"#(Hash tool, used for generating maps of shapes in topology.)#"
    );
    py::class_<TopTools_ShapeSet , shared_ptr<TopTools_ShapeSet>  >(
      m,
      "TopTools_ShapeSet",R"#(A ShapeSets contains a Shape and all its sub-shapes and locations. It can be dump, write and read.)#"
    );

// preregister user-defined template specializations

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
