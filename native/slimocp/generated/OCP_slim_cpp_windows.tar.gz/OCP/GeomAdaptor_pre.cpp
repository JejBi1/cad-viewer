
// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;


// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom_Curve.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Geom_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom_BSplineCurve.hxx>
#include <Geom_BezierCurve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <GeomAdaptor_Curve.hxx>
#include <Geom_OffsetSurface.hxx>
#include <Geom_BezierSurface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Geom_BezierSurface.hxx>
#include <Geom_BSplineSurface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Geom_BezierSurface.hxx>
#include <Geom_BSplineSurface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Geom_BezierSurface.hxx>
#include <Geom_BSplineSurface.hxx>

// module includes
#include <GeomAdaptor.hxx>
#include <GeomAdaptor_Curve.hxx>
#include <GeomAdaptor_Surface.hxx>
#include <GeomAdaptor_SurfaceOfLinearExtrusion.hxx>
#include <GeomAdaptor_SurfaceOfRevolution.hxx>
#include <GeomAdaptor_TransformedCurve.hxx>
#include <GeomAdaptor_TransformedSurface.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module
#include <Geom_BezierCurve.hxx>
#include <Geom_BSplineCurve.hxx>
#include <Geom_OffsetCurve.hxx>


// Module definiiton
void register_GeomAdaptor_enums(py::module &main_module) {


py::module m = main_module.def_submodule("GeomAdaptor", R"#()#");

// add namespaces as submodules
auto GeomEval_RepCurveDesc = m.def_submodule("GeomEval_RepCurveDesc");
auto GeomEval_RepSurfaceDesc = m.def_submodule("GeomEval_RepSurfaceDesc");

// user-defined inclusion per module in the body

// enums

//Python trampoline classes

// pre-register typdefs+classes (topologically sorted)
    py::class_<GeomAdaptor , shared_ptr<GeomAdaptor>  >(
      m,
      "GeomAdaptor",R"#(this package contains the geometric definition of curve and surface necessary to use algorithms.)#"
    );
    py::class_<GeomAdaptor_Curve ,opencascade::handle<GeomAdaptor_Curve>  , Adaptor3d_Curve >(
      m,
      "GeomAdaptor_Curve",R"#(This class provides an interface between the services provided by any curve from the package Geom and those required of the curve by algorithms which use it. Creation of the loaded curve the curve is C1 by piece.)#"
    );
    py::class_<GeomAdaptor_Surface ,opencascade::handle<GeomAdaptor_Surface>  , Adaptor3d_Surface >(
      m,
      "GeomAdaptor_Surface",R"#(An interface between the services provided by any surface from the package Geom and those required of the surface by algorithms which use it. Creation of the loaded surface the surface is C1 by piece)#"
    );
    py::class_<GeomAdaptor_TransformedCurve ,opencascade::handle<GeomAdaptor_TransformedCurve>  , Adaptor3d_Curve >(
      m,
      "GeomAdaptor_TransformedCurve",R"#(An adaptor for curves with an applied transformation.)#"
    );
    py::class_<GeomAdaptor_TransformedSurface ,opencascade::handle<GeomAdaptor_TransformedSurface>  , Adaptor3d_Surface >(
      m,
      "GeomAdaptor_TransformedSurface",R"#(An adaptor for surfaces with an applied transformation.)#"
    );
    py::class_<GeomAdaptor_SurfaceOfLinearExtrusion ,opencascade::handle<GeomAdaptor_SurfaceOfLinearExtrusion>  , GeomAdaptor_Surface >(
      m,
      "GeomAdaptor_SurfaceOfLinearExtrusion",R"#(Generalised cylinder. This surface is obtained by sweeping a curve in a given direction. The parametrization range for the parameter U is defined with referenced the curve. The parametrization range for the parameter V is ]-infinite,+infinite[ The position of the curve gives the origin for the parameter V. The continuity of the surface is CN in the V direction.)#"
    );
    py::class_<GeomAdaptor_SurfaceOfRevolution ,opencascade::handle<GeomAdaptor_SurfaceOfRevolution>  , GeomAdaptor_Surface >(
      m,
      "GeomAdaptor_SurfaceOfRevolution",R"#(This class defines a complete surface of revolution. The surface is obtained by rotating a curve a complete revolution about an axis. The curve and the axis must be in the same plane. If the curve and the axis are not in the same plane it is always possible to be in the previous case after a cylindrical projection of the curve in a referenced plane. For a complete surface of revolution the parametric range is 0 <= U <= 2*PI The parametric range for V is defined with the revolved curve. The origin of the U parametrization is given by the position of the revolved curve (reference). The direction of the revolution axis defines the positive sense of rotation (trigonometric sense) corresponding to the increasing of the parametric value U. The derivatives are always defined for the u direction. For the v direction the definition of the derivatives depends on the degree of continuity of the referenced curve.)#"
    );

// preregister user-defined template specializations

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
