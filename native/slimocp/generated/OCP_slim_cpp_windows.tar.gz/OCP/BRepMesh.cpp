
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Circ2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IMeshTools_Parameters.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IMeshTools_Parameters.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepMesh_DiscretRoot.hxx>
#include <TopoDS_Shape.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IMeshTools_CurveTessellator.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BRepAdaptor_Curve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom_Curve.hxx>
#include <Geom2d_Curve.hxx>
#include <Poly_Polygon3D.hxx>
#include <TopoDS_Face.hxx>
#include <TopoDS_Edge.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TopoDS_Face.hxx>
#include <TopoDS_Edge.hxx>
#include <TopoDS_Wire.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <BRepMesh_Circle.hxx>
#include <BRepMesh_CircleInspector.hxx>
#include <BRepMesh_CircleTool.hxx>
#include <BRepMesh_Classifier.hxx>
#include <BRepMesh_Context.hxx>
#include <BRepMesh_CurveTessellator.hxx>
#include <BRepMesh_DataStructureOfDelaun.hxx>
#include <BRepMesh_Deflection.hxx>
#include <BRepMesh_DegreeOfFreedom.hxx>
#include <BRepMesh_DelabellaBaseMeshAlgo.hxx>
#include <BRepMesh_DelabellaMeshAlgoFactory.hxx>
#include <BRepMesh_Delaun.hxx>
#include <BRepMesh_DiscretAlgoFactory.hxx>
#include <BRepMesh_DiscretFactory.hxx>
#include <BRepMesh_DiscretRoot.hxx>
#include <BRepMesh_Edge.hxx>
#include <BRepMesh_EdgeDiscret.hxx>
#include <BRepMesh_EdgeParameterProvider.hxx>
#include <BRepMesh_EdgeTessellationExtractor.hxx>
#include <BRepMesh_ExtrusionRangeSplitter.hxx>
#include <BRepMesh_FaceChecker.hxx>
#include <BRepMesh_FaceDiscret.hxx>
#include <BRepMesh_FastDiscret.hxx>
#include <BRepMesh_GeomTool.hxx>
#include <BRepMesh_IncrementalMesh.hxx>
#include <BRepMesh_IncrementalMeshFactory.hxx>
#include <BRepMesh_MeshAlgoFactory.hxx>
#include <BRepMesh_MeshTool.hxx>
#include <BRepMesh_ModelBuilder.hxx>
#include <BRepMesh_ModelHealer.hxx>
#include <BRepMesh_ModelPostProcessor.hxx>
#include <BRepMesh_ModelPreProcessor.hxx>
#include <BRepMesh_OrientedEdge.hxx>
#include <BRepMesh_PairOfIndex.hxx>
#include <BRepMesh_SelectorOfDataStructureOfDelaun.hxx>
#include <BRepMesh_ShapeTool.hxx>
#include <BRepMesh_ShapeVisitor.hxx>
#include <BRepMesh_Triangle.hxx>
#include <BRepMesh_Triangulator.hxx>
#include <BRepMesh_UndefinedRangeSplitter.hxx>
#include <BRepMesh_Vertex.hxx>
#include <BRepMesh_VertexInspector.hxx>
#include <BRepMesh_VertexTool.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module
#include <IMeshData_Wire.hxx>

// Module definiiton
void register_BRepMesh(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("BRepMesh"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes
    class Py_BRepMesh_DiscretAlgoFactory : public BRepMesh_DiscretAlgoFactory{
    public:
        using BRepMesh_DiscretAlgoFactory::BRepMesh_DiscretAlgoFactory;


        // public pure virtual
        handle<BRepMesh_DiscretRoot> CreateAlgorithm( const TopoDS_Shape & theShape,double theLinDeflection,double theAngDeflection) override { using return_type = handle<BRepMesh_DiscretRoot>;
    PYBIND11_OVERLOAD_PURE(return_type,BRepMesh_DiscretAlgoFactory,CreateAlgorithm,theShape,theLinDeflection,theAngDeflection) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_BRepMesh_DiscretRoot : public BRepMesh_DiscretRoot{
    public:
        using BRepMesh_DiscretRoot::BRepMesh_DiscretRoot;


        // public pure virtual
        void Perform( const Message_ProgressRange & theRange) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,BRepMesh_DiscretRoot,Perform,theRange) };


        // protected pure virtual


        // private pure virtual

    };

// classes

    // Class BRepMesh_Circle from ./opencascade/BRepMesh_Circle.hxx
    klass = m.attr("BRepMesh_Circle");


    // nested enums

    static_cast<py::class_<BRepMesh_Circle , shared_ptr<BRepMesh_Circle>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const gp_XY &, const double >()  , py::arg("theLocation"),  py::arg("theRadius") )
    // custom constructors
    // methods
        .def("SetLocation",
             (void (BRepMesh_Circle::*)(  const gp_XY &  ) ) static_cast<void (BRepMesh_Circle::*)(  const gp_XY &  ) >(&BRepMesh_Circle::SetLocation),
             R"#(Sets location of a circle.)#"  , py::arg("theLocation")
          )
        .def("SetRadius",
             (void (BRepMesh_Circle::*)(  const double  ) ) static_cast<void (BRepMesh_Circle::*)(  const double  ) >(&BRepMesh_Circle::SetRadius),
             R"#(Sets radius of a circle.)#"  , py::arg("theRadius")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Location",
             ( const gp_XY & (BRepMesh_Circle::*)() const) static_cast< const gp_XY & (BRepMesh_Circle::*)() const>(&BRepMesh_Circle::Location),
             R"#(Returns location of a circle.)#"
             
         )
       .def("Radius",
             ( const double & (BRepMesh_Circle::*)() const) static_cast< const double & (BRepMesh_Circle::*)() const>(&BRepMesh_Circle::Radius),
             R"#(Returns radius of a circle.)#"
             
         )
;

    // Class BRepMesh_CircleInspector from ./opencascade/BRepMesh_CircleInspector.hxx
    klass = m.attr("BRepMesh_CircleInspector");


    // nested enums

    static_cast<py::class_<BRepMesh_CircleInspector , shared_ptr<BRepMesh_CircleInspector>  >>(klass)
    // constructors
        .def(py::init<  const double, const int, const handle<NCollection_IncAllocator> & >()  , py::arg("theTolerance"),  py::arg("theReservedSize"),  py::arg("theAllocator") )
    // custom constructors
    // methods
        .def("Bind",
             (void (BRepMesh_CircleInspector::*)(  const int ,   const BRepMesh_Circle &  ) ) static_cast<void (BRepMesh_CircleInspector::*)(  const int ,   const BRepMesh_Circle &  ) >(&BRepMesh_CircleInspector::Bind),
             R"#(Adds the circle to vector of circles at the given position.)#"  , py::arg("theIndex"),  py::arg("theCircle")
          )
        .def("Circle",
             (BRepMesh_Circle & (BRepMesh_CircleInspector::*)(  const int  ) ) static_cast<BRepMesh_Circle & (BRepMesh_CircleInspector::*)(  const int  ) >(&BRepMesh_CircleInspector::Circle),
             R"#(Returns circle with the given index.)#"  , py::arg("theIndex")
          )
        .def("SetPoint",
             (void (BRepMesh_CircleInspector::*)(  const gp_XY &  ) ) static_cast<void (BRepMesh_CircleInspector::*)(  const gp_XY &  ) >(&BRepMesh_CircleInspector::SetPoint),
             R"#(Set reference point to be checked.)#"  , py::arg("thePoint")
          )
        .def("Inspect",
             (NCollection_CellFilter_Action (BRepMesh_CircleInspector::*)(  const int  ) ) static_cast<NCollection_CellFilter_Action (BRepMesh_CircleInspector::*)(  const int  ) >(&BRepMesh_CircleInspector::Inspect),
             R"#(Performs inspection of a circle with the given index.)#"  , py::arg("theTargetIndex")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Coord_s",
                    (double (*)( int ,   const typename BRepMesh_CircleInspector::Point &  ) ) static_cast<double (*)( int ,   const typename BRepMesh_CircleInspector::Point &  ) >(&BRepMesh_CircleInspector::Coord),
                    R"#()#"  , py::arg("i"),  py::arg("thePnt")
          )
        .def_static("Shift_s",
                    (typename BRepMesh_CircleInspector::Point (*)(  const typename BRepMesh_CircleInspector::Point & ,  double  ) ) static_cast<typename BRepMesh_CircleInspector::Point (*)(  const typename BRepMesh_CircleInspector::Point & ,  double  ) >(&BRepMesh_CircleInspector::Shift),
                    R"#()#"  , py::arg("thePnt"),  py::arg("theTol")
          )
        .def_static("IsEqual_s",
                    (bool (*)(  const int ,   const int  ) ) static_cast<bool (*)(  const int ,   const int  ) >(&BRepMesh_CircleInspector::IsEqual),
                    R"#(Checks indices for equality.)#"  , py::arg("theIndex"),  py::arg("theTargetIndex")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BRepMesh_CircleTool from ./opencascade/BRepMesh_CircleTool.hxx
    klass = m.attr("BRepMesh_CircleTool");


    // nested enums

    static_cast<py::class_<BRepMesh_CircleTool , shared_ptr<BRepMesh_CircleTool>  >>(klass)
    // constructors
        .def(py::init<  const int, const handle<NCollection_IncAllocator> & >()  , py::arg("theReservedSize"),  py::arg("theAllocator") )
        .def(py::init<  const handle<NCollection_IncAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
        .def("Init",
             (void (BRepMesh_CircleTool::*)(  const int  ) ) static_cast<void (BRepMesh_CircleTool::*)(  const int  ) >(&BRepMesh_CircleTool::Init),
             R"#(Initializes the tool.)#"  , py::arg("arg0")
          )
        .def("SetCellSize",
             (void (BRepMesh_CircleTool::*)(  const double  ) ) static_cast<void (BRepMesh_CircleTool::*)(  const double  ) >(&BRepMesh_CircleTool::SetCellSize),
             R"#(Sets new size for cell filter.)#"  , py::arg("theSize")
          )
        .def("SetCellSize",
             (void (BRepMesh_CircleTool::*)(  const double ,   const double  ) ) static_cast<void (BRepMesh_CircleTool::*)(  const double ,   const double  ) >(&BRepMesh_CircleTool::SetCellSize),
             R"#(Sets new size for cell filter.)#"  , py::arg("theSizeX"),  py::arg("theSizeY")
          )
        .def("SetMinMaxSize",
             (void (BRepMesh_CircleTool::*)(  const gp_XY & ,   const gp_XY &  ) ) static_cast<void (BRepMesh_CircleTool::*)(  const gp_XY & ,   const gp_XY &  ) >(&BRepMesh_CircleTool::SetMinMaxSize),
             R"#(Sets limits of inspection area.)#"  , py::arg("theMin"),  py::arg("theMax")
          )
        .def("IsEmpty",
             (bool (BRepMesh_CircleTool::*)() const) static_cast<bool (BRepMesh_CircleTool::*)() const>(&BRepMesh_CircleTool::IsEmpty),
             R"#(Returns true if cell filter contains no circle.)#" 
          )
        .def("Bind",
             (void (BRepMesh_CircleTool::*)(  const int ,   const gp_Circ2d &  ) ) static_cast<void (BRepMesh_CircleTool::*)(  const int ,   const gp_Circ2d &  ) >(&BRepMesh_CircleTool::Bind),
             R"#(Binds the circle to the tool.)#"  , py::arg("theIndex"),  py::arg("theCircle")
          )
        .def("Bind",
             (bool (BRepMesh_CircleTool::*)(  const int ,   const gp_XY & ,   const gp_XY & ,   const gp_XY &  ) ) static_cast<bool (BRepMesh_CircleTool::*)(  const int ,   const gp_XY & ,   const gp_XY & ,   const gp_XY &  ) >(&BRepMesh_CircleTool::Bind),
             R"#(Computes circle on three points and bind it to the tool.)#"  , py::arg("theIndex"),  py::arg("thePoint1"),  py::arg("thePoint2"),  py::arg("thePoint3")
          )
        .def("MocBind",
             (void (BRepMesh_CircleTool::*)(  const int  ) ) static_cast<void (BRepMesh_CircleTool::*)(  const int  ) >(&BRepMesh_CircleTool::MocBind),
             R"#(Binds implicit zero circle.)#"  , py::arg("theIndex")
          )
        .def("Delete",
             (void (BRepMesh_CircleTool::*)(  const int  ) ) static_cast<void (BRepMesh_CircleTool::*)(  const int  ) >(&BRepMesh_CircleTool::Delete),
             R"#(Deletes a circle from the tool.)#"  , py::arg("theIndex")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("MakeCircle_s",
                    (bool (*)(  const gp_XY & ,   const gp_XY & ,   const gp_XY & ,  gp_XY & ,  double &  ) ) static_cast<bool (*)(  const gp_XY & ,   const gp_XY & ,   const gp_XY & ,  gp_XY & ,  double &  ) >(&BRepMesh_CircleTool::MakeCircle),
                    R"#(Computes circle on three points.)#"  , py::arg("thePoint1"),  py::arg("thePoint2"),  py::arg("thePoint3"),  py::arg("theLocation"),  py::arg("theRadius")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BRepMesh_Classifier from ./opencascade/BRepMesh_Classifier.hxx
    klass = m.attr("BRepMesh_Classifier");


    // nested enums

    static_cast<py::class_<BRepMesh_Classifier ,opencascade::handle<BRepMesh_Classifier>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Perform",
             (TopAbs_State (BRepMesh_Classifier::*)(  const gp_Pnt2d &  ) const) static_cast<TopAbs_State (BRepMesh_Classifier::*)(  const gp_Pnt2d &  ) const>(&BRepMesh_Classifier::Perform),
             R"#(Performs classification of the given point regarding to face internals.)#"  , py::arg("thePoint")
          )
        .def("RegisterWire",
             (void (BRepMesh_Classifier::*)(  const NCollection_Sequence< const gp_Pnt2d *> & ,   const std::pair<double, double> & ,   const std::pair<double, double> & ,   const std::pair<double, double> &  ) ) static_cast<void (BRepMesh_Classifier::*)(  const NCollection_Sequence< const gp_Pnt2d *> & ,   const std::pair<double, double> & ,   const std::pair<double, double> & ,   const std::pair<double, double> &  ) >(&BRepMesh_Classifier::RegisterWire),
             R"#(Registers wire specified by sequence of points for further classification of points.)#"  , py::arg("theWire"),  py::arg("theTolUV"),  py::arg("theRangeU"),  py::arg("theRangeV")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepMesh_Classifier::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepMesh_Classifier::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepMesh_Classifier::*)() const) static_cast< const handle<Standard_Type> & (BRepMesh_Classifier::*)() const>(&BRepMesh_Classifier::DynamicType),
             R"#()#"
             
         )
;

    // Class BRepMesh_CurveTessellator from ./opencascade/BRepMesh_CurveTessellator.hxx
    klass = m.attr("BRepMesh_CurveTessellator");


    // nested enums

    static_cast<py::class_<BRepMesh_CurveTessellator ,opencascade::handle<BRepMesh_CurveTessellator>  , IMeshTools_CurveTessellator >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("PointsNb",
             (int (BRepMesh_CurveTessellator::*)() const) static_cast<int (BRepMesh_CurveTessellator::*)() const>(&BRepMesh_CurveTessellator::PointsNb),
             R"#(Returns number of tessellation points.)#" 
          )
        .def("Value",
             (bool (BRepMesh_CurveTessellator::*)(  const int ,  gp_Pnt & ,  double &  ) const) static_cast<bool (BRepMesh_CurveTessellator::*)(  const int ,  gp_Pnt & ,  double &  ) const>(&BRepMesh_CurveTessellator::Value),
             R"#(Returns parameters of solution with the given index.)#"  , py::arg("theIndex"),  py::arg("thePoint"),  py::arg("theParameter")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepMesh_CurveTessellator::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepMesh_CurveTessellator::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepMesh_CurveTessellator::*)() const) static_cast< const handle<Standard_Type> & (BRepMesh_CurveTessellator::*)() const>(&BRepMesh_CurveTessellator::DynamicType),
             R"#()#"
             
         )
;

    // Class BRepMesh_DataStructureOfDelaun from ./opencascade/BRepMesh_DataStructureOfDelaun.hxx
    klass = m.attr("BRepMesh_DataStructureOfDelaun");


    // nested enums

    static_cast<py::class_<BRepMesh_DataStructureOfDelaun ,opencascade::handle<BRepMesh_DataStructureOfDelaun>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const handle<NCollection_IncAllocator> &, const int >()  , py::arg("theAllocator"),  py::arg("theReservedNodeSize")=static_cast< const int>(100) )
    // custom constructors
    // methods
        .def("NbNodes",
             (int (BRepMesh_DataStructureOfDelaun::*)() const) static_cast<int (BRepMesh_DataStructureOfDelaun::*)() const>(&BRepMesh_DataStructureOfDelaun::NbNodes),
             R"#(Returns number of nodes.)#" 
          )
        .def("AddNode",
             (int (BRepMesh_DataStructureOfDelaun::*)(  const BRepMesh_Vertex & ,   const bool  ) ) static_cast<int (BRepMesh_DataStructureOfDelaun::*)(  const BRepMesh_Vertex & ,   const bool  ) >(&BRepMesh_DataStructureOfDelaun::AddNode),
             R"#(Adds node to the mesh if it is not already in the mesh.)#"  , py::arg("theNode"),  py::arg("isForceAdd")=static_cast< const bool>(false)
          )
        .def("IndexOf",
             (int (BRepMesh_DataStructureOfDelaun::*)(  const BRepMesh_Vertex &  ) ) static_cast<int (BRepMesh_DataStructureOfDelaun::*)(  const BRepMesh_Vertex &  ) >(&BRepMesh_DataStructureOfDelaun::IndexOf),
             R"#(Finds the index of the given node.)#"  , py::arg("theNode")
          )
        .def("GetNode",
             ( const BRepMesh_Vertex & (BRepMesh_DataStructureOfDelaun::*)(  const int  ) ) static_cast< const BRepMesh_Vertex & (BRepMesh_DataStructureOfDelaun::*)(  const int  ) >(&BRepMesh_DataStructureOfDelaun::GetNode),
             R"#(Get node by the index.)#"  , py::arg("theIndex")
          )
        .def("SubstituteNode",
             (bool (BRepMesh_DataStructureOfDelaun::*)(  const int ,   const BRepMesh_Vertex &  ) ) static_cast<bool (BRepMesh_DataStructureOfDelaun::*)(  const int ,   const BRepMesh_Vertex &  ) >(&BRepMesh_DataStructureOfDelaun::SubstituteNode),
             R"#(Substitutes the node with the given index by new one.)#"  , py::arg("theIndex"),  py::arg("theNewNode")
          )
        .def("RemoveNode",
             (void (BRepMesh_DataStructureOfDelaun::*)(  const int ,   const bool  ) ) static_cast<void (BRepMesh_DataStructureOfDelaun::*)(  const int ,   const bool  ) >(&BRepMesh_DataStructureOfDelaun::RemoveNode),
             R"#(Removes node from the mesh in case if it has no connected links and its type is Free.)#"  , py::arg("theIndex"),  py::arg("isForce")=static_cast< const bool>(false)
          )
        .def("NbLinks",
             (int (BRepMesh_DataStructureOfDelaun::*)() const) static_cast<int (BRepMesh_DataStructureOfDelaun::*)() const>(&BRepMesh_DataStructureOfDelaun::NbLinks),
             R"#(Returns number of links.)#" 
          )
        .def("AddLink",
             (int (BRepMesh_DataStructureOfDelaun::*)(  const BRepMesh_Edge &  ) ) static_cast<int (BRepMesh_DataStructureOfDelaun::*)(  const BRepMesh_Edge &  ) >(&BRepMesh_DataStructureOfDelaun::AddLink),
             R"#(Adds link to the mesh if it is not already in the mesh.)#"  , py::arg("theLink")
          )
        .def("IndexOf",
             (int (BRepMesh_DataStructureOfDelaun::*)(  const BRepMesh_Edge &  ) const) static_cast<int (BRepMesh_DataStructureOfDelaun::*)(  const BRepMesh_Edge &  ) const>(&BRepMesh_DataStructureOfDelaun::IndexOf),
             R"#(Finds the index of the given link.)#"  , py::arg("theLink")
          )
        .def("GetLink",
             ( const BRepMesh_Edge & (BRepMesh_DataStructureOfDelaun::*)(  const int  ) ) static_cast< const BRepMesh_Edge & (BRepMesh_DataStructureOfDelaun::*)(  const int  ) >(&BRepMesh_DataStructureOfDelaun::GetLink),
             R"#(Get link by the index.)#"  , py::arg("theIndex")
          )
        .def("SubstituteLink",
             (bool (BRepMesh_DataStructureOfDelaun::*)(  const int ,   const BRepMesh_Edge &  ) ) static_cast<bool (BRepMesh_DataStructureOfDelaun::*)(  const int ,   const BRepMesh_Edge &  ) >(&BRepMesh_DataStructureOfDelaun::SubstituteLink),
             R"#(Substitutes the link with the given index by new one.)#"  , py::arg("theIndex"),  py::arg("theNewLink")
          )
        .def("RemoveLink",
             (void (BRepMesh_DataStructureOfDelaun::*)(  const int ,   const bool  ) ) static_cast<void (BRepMesh_DataStructureOfDelaun::*)(  const int ,   const bool  ) >(&BRepMesh_DataStructureOfDelaun::RemoveLink),
             R"#(Removes link from the mesh in case if it has no connected elements and its type is Free.)#"  , py::arg("theIndex"),  py::arg("isForce")=static_cast< const bool>(false)
          )
        .def("ElementsConnectedTo",
             ( const BRepMesh_PairOfIndex & (BRepMesh_DataStructureOfDelaun::*)(  const int  ) const) static_cast< const BRepMesh_PairOfIndex & (BRepMesh_DataStructureOfDelaun::*)(  const int  ) const>(&BRepMesh_DataStructureOfDelaun::ElementsConnectedTo),
             R"#(Returns indices of elements connected to the link with the given index.)#"  , py::arg("theLinkIndex")
          )
        .def("NbElements",
             (int (BRepMesh_DataStructureOfDelaun::*)() const) static_cast<int (BRepMesh_DataStructureOfDelaun::*)() const>(&BRepMesh_DataStructureOfDelaun::NbElements),
             R"#(Returns number of links.)#" 
          )
        .def("AddElement",
             (int (BRepMesh_DataStructureOfDelaun::*)(  const BRepMesh_Triangle &  ) ) static_cast<int (BRepMesh_DataStructureOfDelaun::*)(  const BRepMesh_Triangle &  ) >(&BRepMesh_DataStructureOfDelaun::AddElement),
             R"#(Adds element to the mesh if it is not already in the mesh.)#"  , py::arg("theElement")
          )
        .def("GetElement",
             ( const BRepMesh_Triangle & (BRepMesh_DataStructureOfDelaun::*)(  const int  ) ) static_cast< const BRepMesh_Triangle & (BRepMesh_DataStructureOfDelaun::*)(  const int  ) >(&BRepMesh_DataStructureOfDelaun::GetElement),
             R"#(Get element by the index.)#"  , py::arg("theIndex")
          )
        .def("SubstituteElement",
             (bool (BRepMesh_DataStructureOfDelaun::*)(  const int ,   const BRepMesh_Triangle &  ) ) static_cast<bool (BRepMesh_DataStructureOfDelaun::*)(  const int ,   const BRepMesh_Triangle &  ) >(&BRepMesh_DataStructureOfDelaun::SubstituteElement),
             R"#(Substitutes the element with the given index by new one.)#"  , py::arg("theIndex"),  py::arg("theNewElement")
          )
        .def("RemoveElement",
             (void (BRepMesh_DataStructureOfDelaun::*)(  const int  ) ) static_cast<void (BRepMesh_DataStructureOfDelaun::*)(  const int  ) >(&BRepMesh_DataStructureOfDelaun::RemoveElement),
             R"#(Removes element from the mesh.)#"  , py::arg("theIndex")
          )
        .def("Dump",
             (void (BRepMesh_DataStructureOfDelaun::*)(  const char *  ) ) static_cast<void (BRepMesh_DataStructureOfDelaun::*)(  const char *  ) >(&BRepMesh_DataStructureOfDelaun::Dump),
             R"#()#"  , py::arg("theFileNameStr")
          )
        .def("ClearDomain",
             (void (BRepMesh_DataStructureOfDelaun::*)() ) static_cast<void (BRepMesh_DataStructureOfDelaun::*)() >(&BRepMesh_DataStructureOfDelaun::ClearDomain),
             R"#(Removes all elements.)#" 
          )
        .def("ClearDeleted",
             (void (BRepMesh_DataStructureOfDelaun::*)() ) static_cast<void (BRepMesh_DataStructureOfDelaun::*)() >(&BRepMesh_DataStructureOfDelaun::ClearDeleted),
             R"#(Substitutes deleted items by the last one from corresponding map to have only non-deleted elements, links or nodes in the structure.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepMesh_DataStructureOfDelaun::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepMesh_DataStructureOfDelaun::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
        .def("__call__",
             ( const BRepMesh_Vertex & (BRepMesh_DataStructureOfDelaun::*)(  const int  ) ) static_cast< const BRepMesh_Vertex & (BRepMesh_DataStructureOfDelaun::*)(  const int  ) >(&BRepMesh_DataStructureOfDelaun::operator()),
             py::is_operator(),
             R"#(Alias for GetNode.)#"  , py::arg("theIndex")
          )
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Allocator",
             ( const handle<NCollection_IncAllocator> & (BRepMesh_DataStructureOfDelaun::*)() const) static_cast< const handle<NCollection_IncAllocator> & (BRepMesh_DataStructureOfDelaun::*)() const>(&BRepMesh_DataStructureOfDelaun::Allocator),
             R"#(Returns memory allocator used by the structure.)#"
             
         )
       .def("Data",
             ( const handle<BRepMesh_VertexTool> & (BRepMesh_DataStructureOfDelaun::*)() ) static_cast< const handle<BRepMesh_VertexTool> & (BRepMesh_DataStructureOfDelaun::*)() >(&BRepMesh_DataStructureOfDelaun::Data),
             R"#(Gives the data structure for initialization of cell size and tolerance.)#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepMesh_DataStructureOfDelaun::*)() const) static_cast< const handle<Standard_Type> & (BRepMesh_DataStructureOfDelaun::*)() const>(&BRepMesh_DataStructureOfDelaun::DynamicType),
             R"#()#"
             
         )
;

    // Class BRepMesh_Deflection from ./opencascade/BRepMesh_Deflection.hxx
    klass = m.attr("BRepMesh_Deflection");

    // default constructor
    register_default_constructor<BRepMesh_Deflection ,opencascade::handle<BRepMesh_Deflection>>(m,"BRepMesh_Deflection");

    // nested enums

    static_cast<py::class_<BRepMesh_Deflection ,opencascade::handle<BRepMesh_Deflection>  , Standard_Transient >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("ComputeAbsoluteDeflection_s",
                    (double (*)(  const TopoDS_Shape & ,   const double ,   const double  ) ) static_cast<double (*)(  const TopoDS_Shape & ,   const double ,   const double  ) >(&BRepMesh_Deflection::ComputeAbsoluteDeflection),
                    R"#(Returns absolute deflection for theShape with respect to the relative deflection and theMaxShapeSize.)#"  , py::arg("theShape"),  py::arg("theRelativeDeflection"),  py::arg("theMaxShapeSize")
          )
        .def_static("IsConsistent_s",
                    (bool (*)(  const double ,   const double ,   const bool ,   const double  ) ) static_cast<bool (*)(  const double ,   const double ,   const bool ,   const double  ) >(&BRepMesh_Deflection::IsConsistent),
                    R"#(Checks if the deflection of current polygonal representation is consistent with the required deflection.)#"  , py::arg("theCurrent"),  py::arg("theRequired"),  py::arg("theAllowDecrease"),  py::arg("theRatio")=static_cast< const double>(0.1)
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepMesh_Deflection::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepMesh_Deflection::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepMesh_Deflection::*)() const) static_cast< const handle<Standard_Type> & (BRepMesh_Deflection::*)() const>(&BRepMesh_Deflection::DynamicType),
             R"#()#"
             
         )
;

    // Class BRepMesh_DelabellaBaseMeshAlgo from ./opencascade/BRepMesh_DelabellaBaseMeshAlgo.hxx
    klass = m.attr("BRepMesh_DelabellaBaseMeshAlgo");


    // nested enums

    static_cast<py::class_<BRepMesh_DelabellaBaseMeshAlgo ,opencascade::handle<BRepMesh_DelabellaBaseMeshAlgo>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepMesh_DelabellaBaseMeshAlgo::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepMesh_DelabellaBaseMeshAlgo::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepMesh_DelabellaBaseMeshAlgo::*)() const) static_cast< const handle<Standard_Type> & (BRepMesh_DelabellaBaseMeshAlgo::*)() const>(&BRepMesh_DelabellaBaseMeshAlgo::DynamicType),
             R"#()#"
             
         )
;

    // Class BRepMesh_DelabellaMeshAlgoFactory from ./opencascade/BRepMesh_DelabellaMeshAlgoFactory.hxx
    klass = m.attr("BRepMesh_DelabellaMeshAlgoFactory");


    // nested enums

    static_cast<py::class_<BRepMesh_DelabellaMeshAlgoFactory ,opencascade::handle<BRepMesh_DelabellaMeshAlgoFactory>  , IMeshTools_MeshAlgoFactory >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("GetAlgo",
             (handle<IMeshTools_MeshAlgo> (BRepMesh_DelabellaMeshAlgoFactory::*)(  const GeomAbs_SurfaceType ,   const IMeshTools_Parameters &  ) const) static_cast<handle<IMeshTools_MeshAlgo> (BRepMesh_DelabellaMeshAlgoFactory::*)(  const GeomAbs_SurfaceType ,   const IMeshTools_Parameters &  ) const>(&BRepMesh_DelabellaMeshAlgoFactory::GetAlgo),
             R"#(Creates instance of meshing algorithm for the given type of surface.)#"  , py::arg("theSurfaceType"),  py::arg("theParameters")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepMesh_DelabellaMeshAlgoFactory::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepMesh_DelabellaMeshAlgoFactory::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepMesh_DelabellaMeshAlgoFactory::*)() const) static_cast< const handle<Standard_Type> & (BRepMesh_DelabellaMeshAlgoFactory::*)() const>(&BRepMesh_DelabellaMeshAlgoFactory::DynamicType),
             R"#()#"
             
         )
;

    // Class BRepMesh_DiscretAlgoFactory from ./opencascade/BRepMesh_DiscretAlgoFactory.hxx
    klass = m.attr("BRepMesh_DiscretAlgoFactory");


    // nested enums

    static_cast<py::class_<BRepMesh_DiscretAlgoFactory ,opencascade::handle<BRepMesh_DiscretAlgoFactory> ,Py_BRepMesh_DiscretAlgoFactory , Standard_Transient >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("CreateAlgorithm",
             (handle<BRepMesh_DiscretRoot> (BRepMesh_DiscretAlgoFactory::*)(  const TopoDS_Shape & ,  double ,  double  ) ) static_cast<handle<BRepMesh_DiscretRoot> (BRepMesh_DiscretAlgoFactory::*)(  const TopoDS_Shape & ,  double ,  double  ) >(&BRepMesh_DiscretAlgoFactory::CreateAlgorithm),
             R"#(Creates a new meshing algorithm instance.)#"  , py::arg("theShape"),  py::arg("theLinDeflection"),  py::arg("theAngDeflection")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepMesh_DiscretAlgoFactory::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepMesh_DiscretAlgoFactory::get_type_descriptor),
                    R"#()#" 
          )
        .def_static("RegisterFactory_s",
                    (void (*)(  const handle<BRepMesh_DiscretAlgoFactory> & ,  bool  ) ) static_cast<void (*)(  const handle<BRepMesh_DiscretAlgoFactory> & ,  bool  ) >(&BRepMesh_DiscretAlgoFactory::RegisterFactory),
                    R"#(Registers a factory in the global registry.)#"  , py::arg("theFactory"),  py::arg("theIsPreferred")=static_cast<bool>(false)
          )
        .def_static("UnregisterFactory_s",
                    (void (*)(  const TCollection_AsciiString &  ) ) static_cast<void (*)(  const TCollection_AsciiString &  ) >(&BRepMesh_DiscretAlgoFactory::UnregisterFactory),
                    R"#(Unregisters a factory by name.)#"  , py::arg("theName")
          )
        .def_static("DefaultFactory_s",
                    (handle<BRepMesh_DiscretAlgoFactory> (*)() ) static_cast<handle<BRepMesh_DiscretAlgoFactory> (*)() >(&BRepMesh_DiscretAlgoFactory::DefaultFactory),
                    R"#(Returns the default (first registered) factory, or NULL if none registered.)#" 
          )
        .def_static("FindFactory_s",
                    (handle<BRepMesh_DiscretAlgoFactory> (*)(  const TCollection_AsciiString &  ) ) static_cast<handle<BRepMesh_DiscretAlgoFactory> (*)(  const TCollection_AsciiString &  ) >(&BRepMesh_DiscretAlgoFactory::FindFactory),
                    R"#(Finds a factory by name.)#"  , py::arg("theName")
          )
        .def_static("Factories_s",
                    ( const NCollection_List<handle<BRepMesh_DiscretAlgoFactory>> & (*)() ) static_cast< const NCollection_List<handle<BRepMesh_DiscretAlgoFactory>> & (*)() >(&BRepMesh_DiscretAlgoFactory::Factories),
                    R"#(Returns the global list of registered factories.)#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepMesh_DiscretAlgoFactory::*)() const) static_cast< const handle<Standard_Type> & (BRepMesh_DiscretAlgoFactory::*)() const>(&BRepMesh_DiscretAlgoFactory::DynamicType),
             R"#()#"
             
         )
       .def("Name",
             ( const TCollection_AsciiString & (BRepMesh_DiscretAlgoFactory::*)() const) static_cast< const TCollection_AsciiString & (BRepMesh_DiscretAlgoFactory::*)() const>(&BRepMesh_DiscretAlgoFactory::Name),
             R"#(Returns the factory name.)#"
             
         )
;

    // Class BRepMesh_DiscretFactory from ./opencascade/BRepMesh_DiscretFactory.hxx
    klass = m.attr("BRepMesh_DiscretFactory");


    // nested enums

    static_cast<py::class_<BRepMesh_DiscretFactory , shared_ptr<BRepMesh_DiscretFactory>  >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("SetDefaultName",
             (bool (BRepMesh_DiscretFactory::*)(  const TCollection_AsciiString &  ) ) static_cast<bool (BRepMesh_DiscretFactory::*)(  const TCollection_AsciiString &  ) >(&BRepMesh_DiscretFactory::SetDefaultName),
             R"#(Setup meshing algorithm by name. Returns TRUE if requested algorithm is available. On fail Factory will continue to use previous algorithm.)#"  , py::arg("theName")
          )
        .def("Discret",
             (handle<BRepMesh_DiscretRoot> (BRepMesh_DiscretFactory::*)(  const TopoDS_Shape & ,  double ,  double  ) ) static_cast<handle<BRepMesh_DiscretRoot> (BRepMesh_DiscretFactory::*)(  const TopoDS_Shape & ,  double ,  double  ) >(&BRepMesh_DiscretFactory::Discret),
             R"#(Returns triangulation algorithm instance.)#"  , py::arg("theShape"),  py::arg("theLinDeflection"),  py::arg("theAngDeflection")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Get_s",
                    (BRepMesh_DiscretFactory & (*)() ) static_cast<BRepMesh_DiscretFactory & (*)() >(&BRepMesh_DiscretFactory::Get),
                    R"#(Returns the global factory instance.)#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DefaultName",
             ( const TCollection_AsciiString & (BRepMesh_DiscretFactory::*)() const) static_cast< const TCollection_AsciiString & (BRepMesh_DiscretFactory::*)() const>(&BRepMesh_DiscretFactory::DefaultName),
             R"#(Returns name of current meshing algorithm.)#"
             
         )
;

    // Class BRepMesh_DiscretRoot from ./opencascade/BRepMesh_DiscretRoot.hxx
    klass = m.attr("BRepMesh_DiscretRoot");


    // nested enums

    static_cast<py::class_<BRepMesh_DiscretRoot ,opencascade::handle<BRepMesh_DiscretRoot> ,Py_BRepMesh_DiscretRoot , Standard_Transient >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("SetShape",
             (void (BRepMesh_DiscretRoot::*)(  const TopoDS_Shape &  ) ) static_cast<void (BRepMesh_DiscretRoot::*)(  const TopoDS_Shape &  ) >(&BRepMesh_DiscretRoot::SetShape),
             R"#(Set the shape to triangulate.)#"  , py::arg("theShape")
          )
        .def("IsDone",
             (bool (BRepMesh_DiscretRoot::*)() const) static_cast<bool (BRepMesh_DiscretRoot::*)() const>(&BRepMesh_DiscretRoot::IsDone),
             R"#(Returns true if triangualtion was performed and has success.)#" 
          )
        .def("Perform",
             (void (BRepMesh_DiscretRoot::*)(  const Message_ProgressRange &  ) ) static_cast<void (BRepMesh_DiscretRoot::*)(  const Message_ProgressRange &  ) >(&BRepMesh_DiscretRoot::Perform),
             R"#(Compute triangulation for set shape.)#"  , py::arg("theRange")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepMesh_DiscretRoot::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepMesh_DiscretRoot::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Shape",
             ( const TopoDS_Shape & (BRepMesh_DiscretRoot::*)() const) static_cast< const TopoDS_Shape & (BRepMesh_DiscretRoot::*)() const>(&BRepMesh_DiscretRoot::Shape),
             R"#()#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepMesh_DiscretRoot::*)() const) static_cast< const handle<Standard_Type> & (BRepMesh_DiscretRoot::*)() const>(&BRepMesh_DiscretRoot::DynamicType),
             R"#()#"
             
         )
;

    // Class BRepMesh_EdgeDiscret from ./opencascade/BRepMesh_EdgeDiscret.hxx
    klass = m.attr("BRepMesh_EdgeDiscret");


    // nested enums

    static_cast<py::class_<BRepMesh_EdgeDiscret ,opencascade::handle<BRepMesh_EdgeDiscret>  , IMeshTools_ModelAlgo >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepMesh_EdgeDiscret::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepMesh_EdgeDiscret::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepMesh_EdgeDiscret::*)() const) static_cast< const handle<Standard_Type> & (BRepMesh_EdgeDiscret::*)() const>(&BRepMesh_EdgeDiscret::DynamicType),
             R"#()#"
             
         )
;

    // Class BRepMesh_EdgeTessellationExtractor from ./opencascade/BRepMesh_EdgeTessellationExtractor.hxx
    klass = m.attr("BRepMesh_EdgeTessellationExtractor");

    // default constructor
    register_default_constructor<BRepMesh_EdgeTessellationExtractor ,opencascade::handle<BRepMesh_EdgeTessellationExtractor>>(m,"BRepMesh_EdgeTessellationExtractor");

    // nested enums

    static_cast<py::class_<BRepMesh_EdgeTessellationExtractor ,opencascade::handle<BRepMesh_EdgeTessellationExtractor>  , IMeshTools_CurveTessellator >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("PointsNb",
             (int (BRepMesh_EdgeTessellationExtractor::*)() const) static_cast<int (BRepMesh_EdgeTessellationExtractor::*)() const>(&BRepMesh_EdgeTessellationExtractor::PointsNb),
             R"#(Returns number of tessellation points.)#" 
          )
        .def("Value",
             (bool (BRepMesh_EdgeTessellationExtractor::*)(  const int ,  gp_Pnt & ,  double &  ) const) static_cast<bool (BRepMesh_EdgeTessellationExtractor::*)(  const int ,  gp_Pnt & ,  double &  ) const>(&BRepMesh_EdgeTessellationExtractor::Value),
             R"#(Returns parameters of solution with the given index.)#"  , py::arg("theIndex"),  py::arg("thePoint"),  py::arg("theParameter")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepMesh_EdgeTessellationExtractor::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepMesh_EdgeTessellationExtractor::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepMesh_EdgeTessellationExtractor::*)() const) static_cast< const handle<Standard_Type> & (BRepMesh_EdgeTessellationExtractor::*)() const>(&BRepMesh_EdgeTessellationExtractor::DynamicType),
             R"#()#"
             
         )
;

    // Class BRepMesh_ExtrusionRangeSplitter from ./opencascade/BRepMesh_ExtrusionRangeSplitter.hxx
    klass = m.attr("BRepMesh_ExtrusionRangeSplitter");


    // nested enums

    static_cast<py::class_<BRepMesh_ExtrusionRangeSplitter , shared_ptr<BRepMesh_ExtrusionRangeSplitter>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BRepMesh_FaceChecker from ./opencascade/BRepMesh_FaceChecker.hxx
    klass = m.attr("BRepMesh_FaceChecker");


    // nested enums

    static_cast<py::class_<BRepMesh_FaceChecker ,opencascade::handle<BRepMesh_FaceChecker>  , Standard_Transient >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("Perform",
             (bool (BRepMesh_FaceChecker::*)() ) static_cast<bool (BRepMesh_FaceChecker::*)() >(&BRepMesh_FaceChecker::Perform),
             R"#(Performs check wires of the face for intersections.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepMesh_FaceChecker::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepMesh_FaceChecker::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepMesh_FaceChecker::*)() const) static_cast< const handle<Standard_Type> & (BRepMesh_FaceChecker::*)() const>(&BRepMesh_FaceChecker::DynamicType),
             R"#()#"
             
         )
;

    // Class BRepMesh_FaceDiscret from ./opencascade/BRepMesh_FaceDiscret.hxx
    klass = m.attr("BRepMesh_FaceDiscret");


    // nested enums

    static_cast<py::class_<BRepMesh_FaceDiscret ,opencascade::handle<BRepMesh_FaceDiscret>  , IMeshTools_ModelAlgo >>(klass)
    // constructors
        .def(py::init<  const handle<IMeshTools_MeshAlgoFactory> & >()  , py::arg("theAlgoFactory") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepMesh_FaceDiscret::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepMesh_FaceDiscret::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepMesh_FaceDiscret::*)() const) static_cast< const handle<Standard_Type> & (BRepMesh_FaceDiscret::*)() const>(&BRepMesh_FaceDiscret::DynamicType),
             R"#()#"
             
         )
;

    // Class BRepMesh_FastDiscret from ./opencascade/BRepMesh_FastDiscret.hxx
    klass = m.attr("BRepMesh_FastDiscret");

    // default constructor
    register_default_constructor<BRepMesh_FastDiscret , shared_ptr<BRepMesh_FastDiscret>>(m,"BRepMesh_FastDiscret");

    // nested enums

    static_cast<py::class_<BRepMesh_FastDiscret , shared_ptr<BRepMesh_FastDiscret>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BRepMesh_GeomTool from ./opencascade/BRepMesh_GeomTool.hxx
    klass = m.attr("BRepMesh_GeomTool");


    // nested enums
        py::enum_<BRepMesh_GeomTool::IntFlag>(klass, "IntFlag_e", R"#(Enumerates states of segments intersection check.)#")
            .value("NoIntersection", BRepMesh_GeomTool::IntFlag::NoIntersection)
            .value("Cross", BRepMesh_GeomTool::IntFlag::Cross)
            .value("EndPointTouch", BRepMesh_GeomTool::IntFlag::EndPointTouch)
            .value("PointOnSegment", BRepMesh_GeomTool::IntFlag::PointOnSegment)
            .value("Glued", BRepMesh_GeomTool::IntFlag::Glued)
            .value("Same", BRepMesh_GeomTool::IntFlag::Same);

    static_cast<py::class_<BRepMesh_GeomTool , shared_ptr<BRepMesh_GeomTool>  >>(klass)
    // constructors
        .def(py::init<  const BRepAdaptor_Curve &, const double, const double, const double, const double, const int, const double >()  , py::arg("theCurve"),  py::arg("theFirstParam"),  py::arg("theLastParam"),  py::arg("theLinDeflection"),  py::arg("theAngDeflection"),  py::arg("theMinPointsNb")=static_cast< const int>(2),  py::arg("theMinSize")=static_cast< const double>(Precision :: Confusion ( )) )
        .def(py::init<  const handle<BRepAdaptor_Surface> &, const GeomAbs_IsoType, const double, const double, const double, const double, const double, const int, const double >()  , py::arg("theSurface"),  py::arg("theIsoType"),  py::arg("theParamIso"),  py::arg("theFirstParam"),  py::arg("theLastParam"),  py::arg("theLinDeflection"),  py::arg("theAngDeflection"),  py::arg("theMinPointsNb")=static_cast< const int>(2),  py::arg("theMinSize")=static_cast< const double>(Precision :: Confusion ( )) )
    // custom constructors
    // methods
        .def("AddPoint",
             (int (BRepMesh_GeomTool::*)(  const gp_Pnt & ,   const double ,   const bool  ) ) static_cast<int (BRepMesh_GeomTool::*)(  const gp_Pnt & ,   const double ,   const bool  ) >(&BRepMesh_GeomTool::AddPoint),
             R"#(Adds point to already calculated points (or replaces existing).)#"  , py::arg("thePoint"),  py::arg("theParam"),  py::arg("theIsReplace")=static_cast< const bool>(true)
          )
        .def("NbPoints",
             (int (BRepMesh_GeomTool::*)() const) static_cast<int (BRepMesh_GeomTool::*)() const>(&BRepMesh_GeomTool::NbPoints),
             R"#(Returns number of discretization points.)#" 
          )
        .def("Value",
             (bool (BRepMesh_GeomTool::*)(  const int ,   const double ,  double & ,  gp_Pnt & ,  gp_Pnt2d &  ) const) static_cast<bool (BRepMesh_GeomTool::*)(  const int ,   const double ,  double & ,  gp_Pnt & ,  gp_Pnt2d &  ) const>(&BRepMesh_GeomTool::Value),
             R"#(Gets parameters of discretization point with the given index.)#"  , py::arg("theIndex"),  py::arg("theIsoParam"),  py::arg("theParam"),  py::arg("thePoint"),  py::arg("theUV")
          )
        .def("Value",
             (bool (BRepMesh_GeomTool::*)(  const int ,   const handle<BRepAdaptor_Surface> & ,  double & ,  gp_Pnt & ,  gp_Pnt2d &  ) const) static_cast<bool (BRepMesh_GeomTool::*)(  const int ,   const handle<BRepAdaptor_Surface> & ,  double & ,  gp_Pnt & ,  gp_Pnt2d &  ) const>(&BRepMesh_GeomTool::Value),
             R"#(Gets parameters of discretization point with the given index.)#"  , py::arg("theIndex"),  py::arg("theSurface"),  py::arg("theParam"),  py::arg("thePoint"),  py::arg("theUV")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Normal_s",
                    (bool (*)(  const handle<BRepAdaptor_Surface> & ,   const double ,   const double ,  gp_Pnt & ,  gp_Dir &  ) ) static_cast<bool (*)(  const handle<BRepAdaptor_Surface> & ,   const double ,   const double ,  gp_Pnt & ,  gp_Dir &  ) >(&BRepMesh_GeomTool::Normal),
                    R"#(Computes normal to the given surface at the specified position in parametric space.)#"  , py::arg("theSurface"),  py::arg("theParamU"),  py::arg("theParamV"),  py::arg("thePoint"),  py::arg("theNormal")
          )
        .def_static("IntSegSeg_s",
                    (BRepMesh_GeomTool::IntFlag (*)(  const gp_XY & ,   const gp_XY & ,   const gp_XY & ,   const gp_XY & ,   const bool ,   const bool ,  gp_Pnt2d &  ) ) static_cast<BRepMesh_GeomTool::IntFlag (*)(  const gp_XY & ,   const gp_XY & ,   const gp_XY & ,   const gp_XY & ,   const bool ,   const bool ,  gp_Pnt2d &  ) >(&BRepMesh_GeomTool::IntSegSeg),
                    R"#(Checks intersection between the two segments. Checks that intersection point lies within ranges of both segments.)#"  , py::arg("theStartPnt1"),  py::arg("theEndPnt1"),  py::arg("theStartPnt2"),  py::arg("theEndPnt2"),  py::arg("isConsiderEndPointTouch"),  py::arg("isConsiderPointOnSegment"),  py::arg("theIntPnt")
          )
        .def_static("SquareDeflectionOfSegment_s",
                    (double (*)(  const gp_Pnt & ,   const gp_Pnt & ,   const gp_Pnt &  ) ) static_cast<double (*)(  const gp_Pnt & ,   const gp_Pnt & ,   const gp_Pnt &  ) >(&BRepMesh_GeomTool::SquareDeflectionOfSegment),
                    R"#(Compute deflection of the given segment.)#"  , py::arg("theFirstPoint"),  py::arg("theLastPoint"),  py::arg("theMidPoint")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BRepMesh_MeshAlgoFactory from ./opencascade/BRepMesh_MeshAlgoFactory.hxx
    klass = m.attr("BRepMesh_MeshAlgoFactory");


    // nested enums

    static_cast<py::class_<BRepMesh_MeshAlgoFactory ,opencascade::handle<BRepMesh_MeshAlgoFactory>  , IMeshTools_MeshAlgoFactory >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("GetAlgo",
             (handle<IMeshTools_MeshAlgo> (BRepMesh_MeshAlgoFactory::*)(  const GeomAbs_SurfaceType ,   const IMeshTools_Parameters &  ) const) static_cast<handle<IMeshTools_MeshAlgo> (BRepMesh_MeshAlgoFactory::*)(  const GeomAbs_SurfaceType ,   const IMeshTools_Parameters &  ) const>(&BRepMesh_MeshAlgoFactory::GetAlgo),
             R"#(Creates instance of meshing algorithm for the given type of surface.)#"  , py::arg("theSurfaceType"),  py::arg("theParameters")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepMesh_MeshAlgoFactory::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepMesh_MeshAlgoFactory::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepMesh_MeshAlgoFactory::*)() const) static_cast< const handle<Standard_Type> & (BRepMesh_MeshAlgoFactory::*)() const>(&BRepMesh_MeshAlgoFactory::DynamicType),
             R"#()#"
             
         )
;

    // Class BRepMesh_MeshTool from ./opencascade/BRepMesh_MeshTool.hxx
    klass = m.attr("BRepMesh_MeshTool");


    // nested enums

    static_cast<py::class_<BRepMesh_MeshTool ,opencascade::handle<BRepMesh_MeshTool>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const handle<BRepMesh_DataStructureOfDelaun> & >()  , py::arg("theStructure") )
    // custom constructors
    // methods
        .def("AddAndLegalizeTriangle",
             (void (BRepMesh_MeshTool::*)(  const int ,   const int ,   const int  ) ) static_cast<void (BRepMesh_MeshTool::*)(  const int ,   const int ,   const int  ) >(&BRepMesh_MeshTool::AddAndLegalizeTriangle),
             R"#(Adds new triangle with specified nodes to mesh. Legalizes triangle in case if it violates circle criteria.)#"  , py::arg("thePoint1"),  py::arg("thePoint2"),  py::arg("thePoint3")
          )
        .def("Legalize",
             (void (BRepMesh_MeshTool::*)(  const int  ) ) static_cast<void (BRepMesh_MeshTool::*)(  const int  ) >(&BRepMesh_MeshTool::Legalize),
             R"#(Performs legalization of triangles connected to the specified link.)#"  , py::arg("theLinkIndex")
          )
        .def("EraseItemsConnectedTo",
             (void (BRepMesh_MeshTool::*)(  const int  ) ) static_cast<void (BRepMesh_MeshTool::*)(  const int  ) >(&BRepMesh_MeshTool::EraseItemsConnectedTo),
             R"#(Erases all elements connected to the specified artificial node. In addition, erases the artificial node itself.)#"  , py::arg("theNodeIndex")
          )
        .def("CleanFrontierLinks",
             (void (BRepMesh_MeshTool::*)() ) static_cast<void (BRepMesh_MeshTool::*)() >(&BRepMesh_MeshTool::CleanFrontierLinks),
             R"#(Cleans frontier links from triangles to the right.)#" 
          )
        .def("EraseFreeLinks",
             (void (BRepMesh_MeshTool::*)() ) static_cast<void (BRepMesh_MeshTool::*)() >(&BRepMesh_MeshTool::EraseFreeLinks),
             R"#(Erases all links that have no elements connected to them.)#" 
          )
    // methods using call by reference i.s.o. return
        .def("AddLink",
             []( BRepMesh_MeshTool &self ,  const int theFirstNode, const int theLastNode ){
                 int  theLinkIndex;
                bool  theLinkOri;

                 self.AddLink(theFirstNode,theLastNode,theLinkIndex,theLinkOri);
                 return std::make_tuple(theLinkIndex,theLinkOri); },
             R"#(Adds new link to mesh. Updates link index and link orientation parameters.)#"  , py::arg("theFirstNode"),  py::arg("theLastNode")
          )
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepMesh_MeshTool::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepMesh_MeshTool::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("GetStructure",
             ( const handle<BRepMesh_DataStructureOfDelaun> & (BRepMesh_MeshTool::*)() const) static_cast< const handle<BRepMesh_DataStructureOfDelaun> & (BRepMesh_MeshTool::*)() const>(&BRepMesh_MeshTool::GetStructure),
             R"#(Returns data structure manipulated by this tool.)#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepMesh_MeshTool::*)() const) static_cast< const handle<Standard_Type> & (BRepMesh_MeshTool::*)() const>(&BRepMesh_MeshTool::DynamicType),
             R"#()#"
             
         )
;

    // Class BRepMesh_ModelBuilder from ./opencascade/BRepMesh_ModelBuilder.hxx
    klass = m.attr("BRepMesh_ModelBuilder");


    // nested enums

    static_cast<py::class_<BRepMesh_ModelBuilder ,opencascade::handle<BRepMesh_ModelBuilder>  , IMeshTools_ModelBuilder >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepMesh_ModelBuilder::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepMesh_ModelBuilder::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepMesh_ModelBuilder::*)() const) static_cast< const handle<Standard_Type> & (BRepMesh_ModelBuilder::*)() const>(&BRepMesh_ModelBuilder::DynamicType),
             R"#()#"
             
         )
;

    // Class BRepMesh_ModelHealer from ./opencascade/BRepMesh_ModelHealer.hxx
    klass = m.attr("BRepMesh_ModelHealer");


    // nested enums

    static_cast<py::class_<BRepMesh_ModelHealer ,opencascade::handle<BRepMesh_ModelHealer>  , IMeshTools_ModelAlgo >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepMesh_ModelHealer::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepMesh_ModelHealer::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepMesh_ModelHealer::*)() const) static_cast< const handle<Standard_Type> & (BRepMesh_ModelHealer::*)() const>(&BRepMesh_ModelHealer::DynamicType),
             R"#()#"
             
         )
;

    // Class BRepMesh_ModelPostProcessor from ./opencascade/BRepMesh_ModelPostProcessor.hxx
    klass = m.attr("BRepMesh_ModelPostProcessor");


    // nested enums

    static_cast<py::class_<BRepMesh_ModelPostProcessor ,opencascade::handle<BRepMesh_ModelPostProcessor>  , IMeshTools_ModelAlgo >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepMesh_ModelPostProcessor::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepMesh_ModelPostProcessor::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepMesh_ModelPostProcessor::*)() const) static_cast< const handle<Standard_Type> & (BRepMesh_ModelPostProcessor::*)() const>(&BRepMesh_ModelPostProcessor::DynamicType),
             R"#()#"
             
         )
;

    // Class BRepMesh_ModelPreProcessor from ./opencascade/BRepMesh_ModelPreProcessor.hxx
    klass = m.attr("BRepMesh_ModelPreProcessor");


    // nested enums

    static_cast<py::class_<BRepMesh_ModelPreProcessor ,opencascade::handle<BRepMesh_ModelPreProcessor>  , IMeshTools_ModelAlgo >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepMesh_ModelPreProcessor::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepMesh_ModelPreProcessor::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepMesh_ModelPreProcessor::*)() const) static_cast< const handle<Standard_Type> & (BRepMesh_ModelPreProcessor::*)() const>(&BRepMesh_ModelPreProcessor::DynamicType),
             R"#()#"
             
         )
;

    // Class BRepMesh_OrientedEdge from ./opencascade/BRepMesh_OrientedEdge.hxx
    klass = m.attr("BRepMesh_OrientedEdge");


    // nested enums

    static_cast<py::class_<BRepMesh_OrientedEdge , shared_ptr<BRepMesh_OrientedEdge>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const int, const int >()  , py::arg("theFirstNode"),  py::arg("theLastNode") )
    // custom constructors
    // methods
        .def("FirstNode",
             (int (BRepMesh_OrientedEdge::*)() const) static_cast<int (BRepMesh_OrientedEdge::*)() const>(&BRepMesh_OrientedEdge::FirstNode),
             R"#(Returns index of first node of the Link.)#" 
          )
        .def("LastNode",
             (int (BRepMesh_OrientedEdge::*)() const) static_cast<int (BRepMesh_OrientedEdge::*)() const>(&BRepMesh_OrientedEdge::LastNode),
             R"#(Returns index of last node of the Link.)#" 
          )
        .def("IsEqual",
             (bool (BRepMesh_OrientedEdge::*)(  const BRepMesh_OrientedEdge &  ) const) static_cast<bool (BRepMesh_OrientedEdge::*)(  const BRepMesh_OrientedEdge &  ) const>(&BRepMesh_OrientedEdge::IsEqual),
             R"#(Checks this and other edge for equality.)#"  , py::arg("theOther")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BRepMesh_PairOfIndex from ./opencascade/BRepMesh_PairOfIndex.hxx
    klass = m.attr("BRepMesh_PairOfIndex");


    // nested enums

    static_cast<py::class_<BRepMesh_PairOfIndex , shared_ptr<BRepMesh_PairOfIndex>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Clear",
             (void (BRepMesh_PairOfIndex::*)() ) static_cast<void (BRepMesh_PairOfIndex::*)() >(&BRepMesh_PairOfIndex::Clear),
             R"#(Clears indices.)#" 
          )
        .def("Append",
             (void (BRepMesh_PairOfIndex::*)(  const int  ) ) static_cast<void (BRepMesh_PairOfIndex::*)(  const int  ) >(&BRepMesh_PairOfIndex::Append),
             R"#(Appends index to the pair.)#"  , py::arg("theIndex")
          )
        .def("Prepend",
             (void (BRepMesh_PairOfIndex::*)(  const int  ) ) static_cast<void (BRepMesh_PairOfIndex::*)(  const int  ) >(&BRepMesh_PairOfIndex::Prepend),
             R"#(Prepends index to the pair.)#"  , py::arg("theIndex")
          )
        .def("IsEmpty",
             (bool (BRepMesh_PairOfIndex::*)() const) static_cast<bool (BRepMesh_PairOfIndex::*)() const>(&BRepMesh_PairOfIndex::IsEmpty),
             R"#(Returns is pair is empty.)#" 
          )
        .def("Extent",
             (int (BRepMesh_PairOfIndex::*)() const) static_cast<int (BRepMesh_PairOfIndex::*)() const>(&BRepMesh_PairOfIndex::Extent),
             R"#(Returns number of initialized indices.)#" 
          )
        .def("FirstIndex",
             (int (BRepMesh_PairOfIndex::*)() const) static_cast<int (BRepMesh_PairOfIndex::*)() const>(&BRepMesh_PairOfIndex::FirstIndex),
             R"#(Returns first index of pair.)#" 
          )
        .def("LastIndex",
             (int (BRepMesh_PairOfIndex::*)() const) static_cast<int (BRepMesh_PairOfIndex::*)() const>(&BRepMesh_PairOfIndex::LastIndex),
             R"#(Returns last index of pair)#" 
          )
        .def("Index",
             (int (BRepMesh_PairOfIndex::*)(  const int  ) const) static_cast<int (BRepMesh_PairOfIndex::*)(  const int  ) const>(&BRepMesh_PairOfIndex::Index),
             R"#(Returns index corresponding to the given position in the pair.)#"  , py::arg("thePairPos")
          )
        .def("SetIndex",
             (void (BRepMesh_PairOfIndex::*)(  const int ,   const int  ) ) static_cast<void (BRepMesh_PairOfIndex::*)(  const int ,   const int  ) >(&BRepMesh_PairOfIndex::SetIndex),
             R"#(Sets index corresponding to the given position in the pair.)#"  , py::arg("thePairPos"),  py::arg("theIndex")
          )
        .def("RemoveIndex",
             (void (BRepMesh_PairOfIndex::*)(  const int  ) ) static_cast<void (BRepMesh_PairOfIndex::*)(  const int  ) >(&BRepMesh_PairOfIndex::RemoveIndex),
             R"#(Remove index from the given position.)#"  , py::arg("thePairPos")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BRepMesh_SelectorOfDataStructureOfDelaun from ./opencascade/BRepMesh_SelectorOfDataStructureOfDelaun.hxx
    klass = m.attr("BRepMesh_SelectorOfDataStructureOfDelaun");


    // nested enums

    static_cast<py::class_<BRepMesh_SelectorOfDataStructureOfDelaun ,opencascade::handle<BRepMesh_SelectorOfDataStructureOfDelaun>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<BRepMesh_DataStructureOfDelaun> & >()  , py::arg("theMesh") )
    // custom constructors
    // methods
        .def("Initialize",
             (void (BRepMesh_SelectorOfDataStructureOfDelaun::*)(  const handle<BRepMesh_DataStructureOfDelaun> &  ) ) static_cast<void (BRepMesh_SelectorOfDataStructureOfDelaun::*)(  const handle<BRepMesh_DataStructureOfDelaun> &  ) >(&BRepMesh_SelectorOfDataStructureOfDelaun::Initialize),
             R"#(Initializes selector by the mesh.)#"  , py::arg("theMesh")
          )
        .def("NeighboursOf",
             (void (BRepMesh_SelectorOfDataStructureOfDelaun::*)(  const BRepMesh_Vertex &  ) ) static_cast<void (BRepMesh_SelectorOfDataStructureOfDelaun::*)(  const BRepMesh_Vertex &  ) >(&BRepMesh_SelectorOfDataStructureOfDelaun::NeighboursOf),
             R"#(Selects all neighboring elements of the given node.)#"  , py::arg("theNode")
          )
        .def("NeighboursOfNode",
             (void (BRepMesh_SelectorOfDataStructureOfDelaun::*)(  const int  ) ) static_cast<void (BRepMesh_SelectorOfDataStructureOfDelaun::*)(  const int  ) >(&BRepMesh_SelectorOfDataStructureOfDelaun::NeighboursOfNode),
             R"#(Selects all neighboring elements of node with the given index.)#"  , py::arg("theNodeIndex")
          )
        .def("NeighboursOf",
             (void (BRepMesh_SelectorOfDataStructureOfDelaun::*)(  const BRepMesh_Edge &  ) ) static_cast<void (BRepMesh_SelectorOfDataStructureOfDelaun::*)(  const BRepMesh_Edge &  ) >(&BRepMesh_SelectorOfDataStructureOfDelaun::NeighboursOf),
             R"#(Selects all neighboring elements of the given link.)#"  , py::arg("theLink")
          )
        .def("NeighboursOfLink",
             (void (BRepMesh_SelectorOfDataStructureOfDelaun::*)(  const int  ) ) static_cast<void (BRepMesh_SelectorOfDataStructureOfDelaun::*)(  const int  ) >(&BRepMesh_SelectorOfDataStructureOfDelaun::NeighboursOfLink),
             R"#(Selects all neighboring elements of link with the given index.)#"  , py::arg("theLinkIndex")
          )
        .def("NeighboursOf",
             (void (BRepMesh_SelectorOfDataStructureOfDelaun::*)(  const BRepMesh_Triangle &  ) ) static_cast<void (BRepMesh_SelectorOfDataStructureOfDelaun::*)(  const BRepMesh_Triangle &  ) >(&BRepMesh_SelectorOfDataStructureOfDelaun::NeighboursOf),
             R"#(Selects all neighboring elements of the given element.)#"  , py::arg("theElement")
          )
        .def("NeighboursOfElement",
             (void (BRepMesh_SelectorOfDataStructureOfDelaun::*)(  const int  ) ) static_cast<void (BRepMesh_SelectorOfDataStructureOfDelaun::*)(  const int  ) >(&BRepMesh_SelectorOfDataStructureOfDelaun::NeighboursOfElement),
             R"#(Selects all neighboring elements by nodes of the given element.)#"  , py::arg("theElementIndex")
          )
        .def("NeighboursByEdgeOf",
             (void (BRepMesh_SelectorOfDataStructureOfDelaun::*)(  const BRepMesh_Triangle &  ) ) static_cast<void (BRepMesh_SelectorOfDataStructureOfDelaun::*)(  const BRepMesh_Triangle &  ) >(&BRepMesh_SelectorOfDataStructureOfDelaun::NeighboursByEdgeOf),
             R"#(Selects all neighboring elements by links of the given element.)#"  , py::arg("theElement")
          )
        .def("NeighboursOf",
             (void (BRepMesh_SelectorOfDataStructureOfDelaun::*)(  const BRepMesh_SelectorOfDataStructureOfDelaun &  ) ) static_cast<void (BRepMesh_SelectorOfDataStructureOfDelaun::*)(  const BRepMesh_SelectorOfDataStructureOfDelaun &  ) >(&BRepMesh_SelectorOfDataStructureOfDelaun::NeighboursOf),
             R"#(Adds a level of neighbours by edge to the selector.)#"  , py::arg("arg0")
          )
        .def("AddNeighbours",
             (void (BRepMesh_SelectorOfDataStructureOfDelaun::*)() ) static_cast<void (BRepMesh_SelectorOfDataStructureOfDelaun::*)() >(&BRepMesh_SelectorOfDataStructureOfDelaun::AddNeighbours),
             R"#(Adds a level of neighbours by edge the selector.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepMesh_SelectorOfDataStructureOfDelaun::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepMesh_SelectorOfDataStructureOfDelaun::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepMesh_SelectorOfDataStructureOfDelaun::*)() const) static_cast< const handle<Standard_Type> & (BRepMesh_SelectorOfDataStructureOfDelaun::*)() const>(&BRepMesh_SelectorOfDataStructureOfDelaun::DynamicType),
             R"#()#"
             
         )
;

    // Class BRepMesh_ShapeTool from ./opencascade/BRepMesh_ShapeTool.hxx
    klass = m.attr("BRepMesh_ShapeTool");

    // default constructor
    register_default_constructor<BRepMesh_ShapeTool ,opencascade::handle<BRepMesh_ShapeTool>>(m,"BRepMesh_ShapeTool");

    // nested enums

    static_cast<py::class_<BRepMesh_ShapeTool ,opencascade::handle<BRepMesh_ShapeTool>  , Standard_Transient >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("MaxFaceTolerance_s",
                    (double (*)(  const TopoDS_Face &  ) ) static_cast<double (*)(  const TopoDS_Face &  ) >(&BRepMesh_ShapeTool::MaxFaceTolerance),
                    R"#(Returns maximum tolerance of the given face. Considers tolerances of edges and vertices contained in the given face.)#"  , py::arg("theFace")
          )
        .def_static("NullifyFace_s",
                    (void (*)(  const TopoDS_Face &  ) ) static_cast<void (*)(  const TopoDS_Face &  ) >(&BRepMesh_ShapeTool::NullifyFace),
                    R"#(Nullifies triangulation stored in the face.)#"  , py::arg("theFace")
          )
        .def_static("NullifyEdge_s",
                    (void (*)(  const TopoDS_Edge & ,   const handle<Poly_Triangulation> & ,   const TopLoc_Location &  ) ) static_cast<void (*)(  const TopoDS_Edge & ,   const handle<Poly_Triangulation> & ,   const TopLoc_Location &  ) >(&BRepMesh_ShapeTool::NullifyEdge),
                    R"#(Nullifies polygon on triangulation stored in the edge.)#"  , py::arg("theEdge"),  py::arg("theTriangulation"),  py::arg("theLocation")
          )
        .def_static("NullifyEdge_s",
                    (void (*)(  const TopoDS_Edge & ,   const TopLoc_Location &  ) ) static_cast<void (*)(  const TopoDS_Edge & ,   const TopLoc_Location &  ) >(&BRepMesh_ShapeTool::NullifyEdge),
                    R"#(Nullifies 3d polygon stored in the edge.)#"  , py::arg("theEdge"),  py::arg("theLocation")
          )
        .def_static("UpdateEdge_s",
                    (void (*)(  const TopoDS_Edge & ,   const handle<Poly_PolygonOnTriangulation> & ,   const handle<Poly_Triangulation> & ,   const TopLoc_Location &  ) ) static_cast<void (*)(  const TopoDS_Edge & ,   const handle<Poly_PolygonOnTriangulation> & ,   const handle<Poly_Triangulation> & ,   const TopLoc_Location &  ) >(&BRepMesh_ShapeTool::UpdateEdge),
                    R"#(Updates the given edge by the given tessellated representation.)#"  , py::arg("theEdge"),  py::arg("thePolygon"),  py::arg("theTriangulation"),  py::arg("theLocation")
          )
        .def_static("UpdateEdge_s",
                    (void (*)(  const TopoDS_Edge & ,   const handle<Poly_Polygon3D> &  ) ) static_cast<void (*)(  const TopoDS_Edge & ,   const handle<Poly_Polygon3D> &  ) >(&BRepMesh_ShapeTool::UpdateEdge),
                    R"#(Updates the given edge by the given tessellated representation.)#"  , py::arg("theEdge"),  py::arg("thePolygon")
          )
        .def_static("UpdateEdge_s",
                    (void (*)(  const TopoDS_Edge & ,   const handle<Poly_PolygonOnTriangulation> & ,   const handle<Poly_PolygonOnTriangulation> & ,   const handle<Poly_Triangulation> & ,   const TopLoc_Location &  ) ) static_cast<void (*)(  const TopoDS_Edge & ,   const handle<Poly_PolygonOnTriangulation> & ,   const handle<Poly_PolygonOnTriangulation> & ,   const handle<Poly_Triangulation> & ,   const TopLoc_Location &  ) >(&BRepMesh_ShapeTool::UpdateEdge),
                    R"#(Updates the given seam edge by the given tessellated representations.)#"  , py::arg("theEdge"),  py::arg("thePolygon1"),  py::arg("thePolygon2"),  py::arg("theTriangulation"),  py::arg("theLocation")
          )
        .def_static("UseLocation_s",
                    (gp_Pnt (*)(  const gp_Pnt & ,   const TopLoc_Location &  ) ) static_cast<gp_Pnt (*)(  const gp_Pnt & ,   const TopLoc_Location &  ) >(&BRepMesh_ShapeTool::UseLocation),
                    R"#(Applies location to the given point and return result.)#"  , py::arg("thePnt"),  py::arg("theLoc")
          )
        .def_static("UVPoints_s",
                    (bool (*)(  const TopoDS_Edge & ,   const TopoDS_Face & ,  gp_Pnt2d & ,  gp_Pnt2d & ,   const bool  ) ) static_cast<bool (*)(  const TopoDS_Edge & ,   const TopoDS_Face & ,  gp_Pnt2d & ,  gp_Pnt2d & ,   const bool  ) >(&BRepMesh_ShapeTool::UVPoints),
                    R"#(Gets the strict UV locations of the extremities of the edge using pcurve.)#"  , py::arg("theEdge"),  py::arg("theFace"),  py::arg("theFirstPoint2d"),  py::arg("theLastPoint2d"),  py::arg("isConsiderOrientation")=static_cast< const bool>(false)
          )
        .def_static("Range_s",
                    (bool (*)(  const TopoDS_Edge & ,   const TopoDS_Face & ,  handle<Geom2d_Curve> & ,  double & ,  double & ,   const bool  ) ) static_cast<bool (*)(  const TopoDS_Edge & ,   const TopoDS_Face & ,  handle<Geom2d_Curve> & ,  double & ,  double & ,   const bool  ) >(&BRepMesh_ShapeTool::Range),
                    R"#(Gets the parametric range of the given edge on the given face.)#"  , py::arg("theEdge"),  py::arg("theFace"),  py::arg("thePCurve"),  py::arg("theFirstParam"),  py::arg("theLastParam"),  py::arg("isConsiderOrientation")=static_cast< const bool>(false)
          )
        .def_static("Range_s",
                    (bool (*)(  const TopoDS_Edge & ,  handle<Geom_Curve> & ,  double & ,  double & ,   const bool  ) ) static_cast<bool (*)(  const TopoDS_Edge & ,  handle<Geom_Curve> & ,  double & ,  double & ,   const bool  ) >(&BRepMesh_ShapeTool::Range),
                    R"#(Gets the 3d range of the given edge.)#"  , py::arg("theEdge"),  py::arg("theCurve"),  py::arg("theFirstParam"),  py::arg("theLastParam"),  py::arg("isConsiderOrientation")=static_cast< const bool>(false)
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepMesh_ShapeTool::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepMesh_ShapeTool::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
        .def_static("BoxMaxDimension_s",
            []( const Bnd_Box & theBox ){
                double  theMaxDimension;

                BRepMesh_ShapeTool::BoxMaxDimension(theBox,theMaxDimension);
                
return std::make_tuple(theMaxDimension); },
            R"#(Gets the maximum dimension of the given bounding box. If the given bounding box is void leaves the resulting value unchanged.)#"  , py::arg("theBox")
          )
        .def_static("AddInFace_s",
            []( const TopoDS_Face & theFace,Poly_Triangulation& theTriangulation ){
                handle<Poly_Triangulation>  theTriangulation_ptr; theTriangulation_ptr = &theTriangulation;

                BRepMesh_ShapeTool::AddInFace(theFace,theTriangulation_ptr);
                if ( theTriangulation_ptr.get() != &theTriangulation ) copy_if_assignable(theTriangulation, *theTriangulation_ptr);

 },
            R"#(Stores the given triangulation into the given face.)#"  , py::arg("theFace"),  py::arg("theTriangulation")
          )
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepMesh_ShapeTool::*)() const) static_cast< const handle<Standard_Type> & (BRepMesh_ShapeTool::*)() const>(&BRepMesh_ShapeTool::DynamicType),
             R"#()#"
             
         )
;

    // Class BRepMesh_ShapeVisitor from ./opencascade/BRepMesh_ShapeVisitor.hxx
    klass = m.attr("BRepMesh_ShapeVisitor");

    // default constructor
    register_default_constructor<BRepMesh_ShapeVisitor ,opencascade::handle<BRepMesh_ShapeVisitor>>(m,"BRepMesh_ShapeVisitor");

    // nested enums

    static_cast<py::class_<BRepMesh_ShapeVisitor ,opencascade::handle<BRepMesh_ShapeVisitor>  , IMeshTools_ShapeVisitor >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("Visit",
             (void (BRepMesh_ShapeVisitor::*)(  const TopoDS_Face &  ) ) static_cast<void (BRepMesh_ShapeVisitor::*)(  const TopoDS_Face &  ) >(&BRepMesh_ShapeVisitor::Visit),
             R"#(Handles TopoDS_Face object.)#"  , py::arg("theFace")
          )
        .def("Visit",
             (void (BRepMesh_ShapeVisitor::*)(  const TopoDS_Edge &  ) ) static_cast<void (BRepMesh_ShapeVisitor::*)(  const TopoDS_Edge &  ) >(&BRepMesh_ShapeVisitor::Visit),
             R"#(Handles TopoDS_Edge object.)#"  , py::arg("theEdge")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepMesh_ShapeVisitor::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepMesh_ShapeVisitor::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepMesh_ShapeVisitor::*)() const) static_cast< const handle<Standard_Type> & (BRepMesh_ShapeVisitor::*)() const>(&BRepMesh_ShapeVisitor::DynamicType),
             R"#()#"
             
         )
;

    // Class BRepMesh_Triangulator from ./opencascade/BRepMesh_Triangulator.hxx
    klass = m.attr("BRepMesh_Triangulator");


    // nested enums

    static_cast<py::class_<BRepMesh_Triangulator , shared_ptr<BRepMesh_Triangulator>  >>(klass)
    // constructors
        .def(py::init<  const NCollection_DynamicArray<gp_XYZ> &, const NCollection_List<NCollection_Sequence<int>> &, const gp_Dir & >()  , py::arg("theXYZs"),  py::arg("theWires"),  py::arg("theNorm") )
    // custom constructors
    // methods
        .def("Perform",
             (bool (BRepMesh_Triangulator::*)( NCollection_List<Poly_Triangle> &  ) ) static_cast<bool (BRepMesh_Triangulator::*)( NCollection_List<Poly_Triangle> &  ) >(&BRepMesh_Triangulator::Perform),
             R"#(Performs triangulation of source wires and stores triangles the output list.)#"  , py::arg("thePolyTriangles")
          )
        .def("SetMessenger",
             (void (BRepMesh_Triangulator::*)(  const handle<Message_Messenger> &  ) ) static_cast<void (BRepMesh_Triangulator::*)(  const handle<Message_Messenger> &  ) >(&BRepMesh_Triangulator::SetMessenger),
             R"#(Set messenger for output information without this Message::DefaultMessenger() will be used)#"  , py::arg("theMess")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("ToPolyTriangulation_s",
                    (handle<Poly_Triangulation> (*)(  const NCollection_Array1<gp_Pnt> & ,   const NCollection_List<Poly_Triangle> &  ) ) static_cast<handle<Poly_Triangulation> (*)(  const NCollection_Array1<gp_Pnt> & ,   const NCollection_List<Poly_Triangle> &  ) >(&BRepMesh_Triangulator::ToPolyTriangulation),
                    R"#(Performs conversion of the given list of triangles to Poly_Triangulation.)#"  , py::arg("theNodes"),  py::arg("thePolyTriangles")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BRepMesh_UndefinedRangeSplitter from ./opencascade/BRepMesh_UndefinedRangeSplitter.hxx
    klass = m.attr("BRepMesh_UndefinedRangeSplitter");


    // nested enums

    static_cast<py::class_<BRepMesh_UndefinedRangeSplitter , shared_ptr<BRepMesh_UndefinedRangeSplitter>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BRepMesh_Vertex from ./opencascade/BRepMesh_Vertex.hxx
    klass = m.attr("BRepMesh_Vertex");


    // nested enums

    static_cast<py::class_<BRepMesh_Vertex , shared_ptr<BRepMesh_Vertex>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const double, const double, const BRepMesh_DegreeOfFreedom >()  , py::arg("theU"),  py::arg("theV"),  py::arg("theMovability") )
        .def(py::init<  const gp_XY &, const int, const BRepMesh_DegreeOfFreedom >()  , py::arg("theUV"),  py::arg("theLocation3d"),  py::arg("theMovability") )
    // custom constructors
    // methods
        .def("Initialize",
             (void (BRepMesh_Vertex::*)(  const gp_XY & ,   const int ,   const BRepMesh_DegreeOfFreedom  ) ) static_cast<void (BRepMesh_Vertex::*)(  const gp_XY & ,   const int ,   const BRepMesh_DegreeOfFreedom  ) >(&BRepMesh_Vertex::Initialize),
             R"#(Initializes vertex associated with point in 3d space.)#"  , py::arg("theUV"),  py::arg("theLocation3d"),  py::arg("theMovability")
          )
        .def("Location3d",
             (int (BRepMesh_Vertex::*)() const) static_cast<int (BRepMesh_Vertex::*)() const>(&BRepMesh_Vertex::Location3d),
             R"#(Returns index of 3d point associated with the vertex.)#" 
          )
        .def("Movability",
             (BRepMesh_DegreeOfFreedom (BRepMesh_Vertex::*)() const) static_cast<BRepMesh_DegreeOfFreedom (BRepMesh_Vertex::*)() const>(&BRepMesh_Vertex::Movability),
             R"#(Returns movability of the vertex.)#" 
          )
        .def("SetMovability",
             (void (BRepMesh_Vertex::*)(  const BRepMesh_DegreeOfFreedom  ) ) static_cast<void (BRepMesh_Vertex::*)(  const BRepMesh_DegreeOfFreedom  ) >(&BRepMesh_Vertex::SetMovability),
             R"#(Sets movability of the vertex.)#"  , py::arg("theMovability")
          )
        .def("IsEqual",
             (bool (BRepMesh_Vertex::*)(  const BRepMesh_Vertex &  ) const) static_cast<bool (BRepMesh_Vertex::*)(  const BRepMesh_Vertex &  ) const>(&BRepMesh_Vertex::IsEqual),
             R"#(Checks for equality with another vertex.)#"  , py::arg("theOther")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Coord",
             ( const gp_XY & (BRepMesh_Vertex::*)() const) static_cast< const gp_XY & (BRepMesh_Vertex::*)() const>(&BRepMesh_Vertex::Coord),
             R"#(Returns position of the vertex in parametric space.)#"
             
         )
       .def("ChangeCoord",
             (gp_XY & (BRepMesh_Vertex::*)() ) static_cast<gp_XY & (BRepMesh_Vertex::*)() >(&BRepMesh_Vertex::ChangeCoord),
             R"#(Returns position of the vertex in parametric space for modification.)#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class BRepMesh_VertexInspector from ./opencascade/BRepMesh_VertexInspector.hxx
    klass = m.attr("BRepMesh_VertexInspector");


    // nested enums

    static_cast<py::class_<BRepMesh_VertexInspector , shared_ptr<BRepMesh_VertexInspector>  >>(klass)
    // constructors
        .def(py::init<  const handle<NCollection_IncAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
        .def("Add",
             (int (BRepMesh_VertexInspector::*)(  const BRepMesh_Vertex &  ) ) static_cast<int (BRepMesh_VertexInspector::*)(  const BRepMesh_Vertex &  ) >(&BRepMesh_VertexInspector::Add),
             R"#(Registers the given vertex.)#"  , py::arg("theVertex")
          )
        .def("SetTolerance",
             (void (BRepMesh_VertexInspector::*)(  const double  ) ) static_cast<void (BRepMesh_VertexInspector::*)(  const double  ) >(&BRepMesh_VertexInspector::SetTolerance),
             R"#(Sets the tolerance to be used for identification of coincident vertices equal for both dimensions.)#"  , py::arg("theTolerance")
          )
        .def("SetTolerance",
             (void (BRepMesh_VertexInspector::*)(  const double ,   const double  ) ) static_cast<void (BRepMesh_VertexInspector::*)(  const double ,   const double  ) >(&BRepMesh_VertexInspector::SetTolerance),
             R"#(Sets the tolerance to be used for identification of coincident vertices.)#"  , py::arg("theToleranceX"),  py::arg("theToleranceY")
          )
        .def("Clear",
             (void (BRepMesh_VertexInspector::*)() ) static_cast<void (BRepMesh_VertexInspector::*)() >(&BRepMesh_VertexInspector::Clear),
             R"#(Clear inspector's internal data structures.)#" 
          )
        .def("Delete",
             (void (BRepMesh_VertexInspector::*)(  const int  ) ) static_cast<void (BRepMesh_VertexInspector::*)(  const int  ) >(&BRepMesh_VertexInspector::Delete),
             R"#(Deletes vertex with the given index.)#"  , py::arg("theIndex")
          )
        .def("NbVertices",
             (int (BRepMesh_VertexInspector::*)() const) static_cast<int (BRepMesh_VertexInspector::*)() const>(&BRepMesh_VertexInspector::NbVertices),
             R"#(Returns number of registered vertices.)#" 
          )
        .def("GetVertex",
             (BRepMesh_Vertex & (BRepMesh_VertexInspector::*)( int  ) ) static_cast<BRepMesh_Vertex & (BRepMesh_VertexInspector::*)( int  ) >(&BRepMesh_VertexInspector::GetVertex),
             R"#(Returns vertex with the given index.)#"  , py::arg("theIndex")
          )
        .def("SetPoint",
             (void (BRepMesh_VertexInspector::*)(  const gp_XY &  ) ) static_cast<void (BRepMesh_VertexInspector::*)(  const gp_XY &  ) >(&BRepMesh_VertexInspector::SetPoint),
             R"#(Set reference point to be checked.)#"  , py::arg("thePoint")
          )
        .def("GetCoincidentPoint",
             (int (BRepMesh_VertexInspector::*)() const) static_cast<int (BRepMesh_VertexInspector::*)() const>(&BRepMesh_VertexInspector::GetCoincidentPoint),
             R"#(Returns index of point coinciding with regerence one.)#" 
          )
        .def("Inspect",
             (NCollection_CellFilter_Action (BRepMesh_VertexInspector::*)(  const int  ) ) static_cast<NCollection_CellFilter_Action (BRepMesh_VertexInspector::*)(  const int  ) >(&BRepMesh_VertexInspector::Inspect),
             R"#(Performs inspection of a point with the given index.)#"  , py::arg("theTargetIndex")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Coord_s",
                    (double (*)( int ,   const typename BRepMesh_VertexInspector::Point &  ) ) static_cast<double (*)( int ,   const typename BRepMesh_VertexInspector::Point &  ) >(&BRepMesh_VertexInspector::Coord),
                    R"#()#"  , py::arg("i"),  py::arg("thePnt")
          )
        .def_static("Shift_s",
                    (typename BRepMesh_VertexInspector::Point (*)(  const typename BRepMesh_VertexInspector::Point & ,  double  ) ) static_cast<typename BRepMesh_VertexInspector::Point (*)(  const typename BRepMesh_VertexInspector::Point & ,  double  ) >(&BRepMesh_VertexInspector::Shift),
                    R"#()#"  , py::arg("thePnt"),  py::arg("theTol")
          )
        .def_static("IsEqual_s",
                    (bool (*)(  const int ,   const int  ) ) static_cast<bool (*)(  const int ,   const int  ) >(&BRepMesh_VertexInspector::IsEqual),
                    R"#(Checks indices for equality.)#"  , py::arg("theIndex"),  py::arg("theTargetIndex")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BRepMesh_VertexTool from ./opencascade/BRepMesh_VertexTool.hxx
    klass = m.attr("BRepMesh_VertexTool");


    // nested enums

    static_cast<py::class_<BRepMesh_VertexTool ,opencascade::handle<BRepMesh_VertexTool>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const handle<NCollection_IncAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
        .def("SetCellSize",
             (void (BRepMesh_VertexTool::*)(  const double  ) ) static_cast<void (BRepMesh_VertexTool::*)(  const double  ) >(&BRepMesh_VertexTool::SetCellSize),
             R"#(Sets new size of cell for cellfilter equal in both directions.)#"  , py::arg("theSize")
          )
        .def("SetCellSize",
             (void (BRepMesh_VertexTool::*)(  const double ,   const double  ) ) static_cast<void (BRepMesh_VertexTool::*)(  const double ,   const double  ) >(&BRepMesh_VertexTool::SetCellSize),
             R"#(Sets new size of cell for cellfilter.)#"  , py::arg("theSizeX"),  py::arg("theSizeY")
          )
        .def("SetTolerance",
             (void (BRepMesh_VertexTool::*)(  const double  ) ) static_cast<void (BRepMesh_VertexTool::*)(  const double  ) >(&BRepMesh_VertexTool::SetTolerance),
             R"#(Sets the tolerance to be used for identification of coincident vertices equal for both dimensions.)#"  , py::arg("theTolerance")
          )
        .def("SetTolerance",
             (void (BRepMesh_VertexTool::*)(  const double ,   const double  ) ) static_cast<void (BRepMesh_VertexTool::*)(  const double ,   const double  ) >(&BRepMesh_VertexTool::SetTolerance),
             R"#(Sets the tolerance to be used for identification of coincident vertices.)#"  , py::arg("theToleranceX"),  py::arg("theToleranceY")
          )
        .def("Add",
             (int (BRepMesh_VertexTool::*)(  const BRepMesh_Vertex & ,   const bool  ) ) static_cast<int (BRepMesh_VertexTool::*)(  const BRepMesh_Vertex & ,   const bool  ) >(&BRepMesh_VertexTool::Add),
             R"#(Adds vertex with empty data to the tool.)#"  , py::arg("theVertex"),  py::arg("isForceAdd")
          )
        .def("DeleteVertex",
             (void (BRepMesh_VertexTool::*)(  const int  ) ) static_cast<void (BRepMesh_VertexTool::*)(  const int  ) >(&BRepMesh_VertexTool::DeleteVertex),
             R"#(Deletes vertex with the given index from the tool.)#"  , py::arg("theIndex")
          )
        .def("FindKey",
             ( const BRepMesh_Vertex & (BRepMesh_VertexTool::*)(  const int  ) ) static_cast< const BRepMesh_Vertex & (BRepMesh_VertexTool::*)(  const int  ) >(&BRepMesh_VertexTool::FindKey),
             R"#(Returns vertex by the given index.)#"  , py::arg("theIndex")
          )
        .def("FindIndex",
             (int (BRepMesh_VertexTool::*)(  const BRepMesh_Vertex &  ) ) static_cast<int (BRepMesh_VertexTool::*)(  const BRepMesh_Vertex &  ) >(&BRepMesh_VertexTool::FindIndex),
             R"#(Returns index of the given vertex.)#"  , py::arg("theVertex")
          )
        .def("Extent",
             (int (BRepMesh_VertexTool::*)() const) static_cast<int (BRepMesh_VertexTool::*)() const>(&BRepMesh_VertexTool::Extent),
             R"#(Returns a number of vertices.)#" 
          )
        .def("IsEmpty",
             (bool (BRepMesh_VertexTool::*)() const) static_cast<bool (BRepMesh_VertexTool::*)() const>(&BRepMesh_VertexTool::IsEmpty),
             R"#(Returns True when the map contains no keys.)#" 
          )
        .def("Substitute",
             (void (BRepMesh_VertexTool::*)(  const int ,   const BRepMesh_Vertex &  ) ) static_cast<void (BRepMesh_VertexTool::*)(  const int ,   const BRepMesh_Vertex &  ) >(&BRepMesh_VertexTool::Substitute),
             R"#(Substitutes vertex with the given by the given vertex with attributes.)#"  , py::arg("theIndex"),  py::arg("theVertex")
          )
        .def("RemoveLast",
             (void (BRepMesh_VertexTool::*)() ) static_cast<void (BRepMesh_VertexTool::*)() >(&BRepMesh_VertexTool::RemoveLast),
             R"#(Remove last node from the structure.)#" 
          )
    // methods using call by reference i.s.o. return
        .def("GetTolerance",
             []( BRepMesh_VertexTool &self   ){
                 double  theToleranceX;
                double  theToleranceY;

                 self.GetTolerance(theToleranceX,theToleranceY);
                 return std::make_tuple(theToleranceX,theToleranceY); },
             R"#(Gets the tolerance to be used for identification of coincident vertices.)#" 
          )
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepMesh_VertexTool::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepMesh_VertexTool::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepMesh_VertexTool::*)() const) static_cast< const handle<Standard_Type> & (BRepMesh_VertexTool::*)() const>(&BRepMesh_VertexTool::DynamicType),
             R"#()#"
             
         )
;

    // Class BRepMesh_Edge from ./opencascade/BRepMesh_Edge.hxx
    klass = m.attr("BRepMesh_Edge");


    // nested enums

    static_cast<py::class_<BRepMesh_Edge , shared_ptr<BRepMesh_Edge>  , BRepMesh_OrientedEdge >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const int, const int, const BRepMesh_DegreeOfFreedom >()  , py::arg("theFirstNode"),  py::arg("theLastNode"),  py::arg("theMovability") )
    // custom constructors
    // methods
        .def("Movability",
             (BRepMesh_DegreeOfFreedom (BRepMesh_Edge::*)() const) static_cast<BRepMesh_DegreeOfFreedom (BRepMesh_Edge::*)() const>(&BRepMesh_Edge::Movability),
             R"#(Returns movability flag of the Link.)#" 
          )
        .def("SetMovability",
             (void (BRepMesh_Edge::*)(  const BRepMesh_DegreeOfFreedom  ) ) static_cast<void (BRepMesh_Edge::*)(  const BRepMesh_DegreeOfFreedom  ) >(&BRepMesh_Edge::SetMovability),
             R"#(Sets movability flag of the Link.)#"  , py::arg("theMovability")
          )
        .def("IsSameOrientation",
             (bool (BRepMesh_Edge::*)(  const BRepMesh_Edge &  ) const) static_cast<bool (BRepMesh_Edge::*)(  const BRepMesh_Edge &  ) const>(&BRepMesh_Edge::IsSameOrientation),
             R"#(Checks if the given edge and this one have the same orientation.)#"  , py::arg("theOther")
          )
        .def("IsEqual",
             (bool (BRepMesh_Edge::*)(  const BRepMesh_Edge &  ) const) static_cast<bool (BRepMesh_Edge::*)(  const BRepMesh_Edge &  ) const>(&BRepMesh_Edge::IsEqual),
             R"#(Checks for equality with another edge.)#"  , py::arg("theOther")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BRepMesh_IncrementalMesh from ./opencascade/BRepMesh_IncrementalMesh.hxx
    klass = m.attr("BRepMesh_IncrementalMesh");


    // nested enums

    static_cast<py::class_<BRepMesh_IncrementalMesh ,opencascade::handle<BRepMesh_IncrementalMesh>  , BRepMesh_DiscretRoot >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const TopoDS_Shape &, const IMeshTools_Parameters &, const Message_ProgressRange & >()  , py::arg("theShape"),  py::arg("theParameters"),  py::arg("theRange")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( )) )
        .def(py::init<  const TopoDS_Shape &, const double, const bool, const double, const bool >()  , py::arg("theShape"),  py::arg("theLinDeflection"),  py::arg("isRelative")=static_cast< const bool>(false),  py::arg("theAngDeflection")=static_cast< const double>(0.5),  py::arg("isInParallel")=static_cast< const bool>(false) )
    // custom constructors
    // methods
        .def("Perform",
             (void (BRepMesh_IncrementalMesh::*)(  const Message_ProgressRange &  ) ) static_cast<void (BRepMesh_IncrementalMesh::*)(  const Message_ProgressRange &  ) >(&BRepMesh_IncrementalMesh::Perform),
             R"#(Performs meshing of the shape.)#"  , py::arg("theRange")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def("Perform",
             (void (BRepMesh_IncrementalMesh::*)(  const handle<IMeshTools_Context> & ,   const Message_ProgressRange &  ) ) static_cast<void (BRepMesh_IncrementalMesh::*)(  const handle<IMeshTools_Context> & ,   const Message_ProgressRange &  ) >(&BRepMesh_IncrementalMesh::Perform),
             R"#(Performs meshing using custom context;)#"  , py::arg("theContext"),  py::arg("theRange")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def("IsModified",
             (bool (BRepMesh_IncrementalMesh::*)() const) static_cast<bool (BRepMesh_IncrementalMesh::*)() const>(&BRepMesh_IncrementalMesh::IsModified),
             R"#(Returns modified flag.)#" 
          )
        .def("GetStatusFlags",
             (int (BRepMesh_IncrementalMesh::*)() const) static_cast<int (BRepMesh_IncrementalMesh::*)() const>(&BRepMesh_IncrementalMesh::GetStatusFlags),
             R"#(Returns accumulated status flags faced during meshing.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("IsParallelDefault_s",
                    (bool (*)() ) static_cast<bool (*)() >(&BRepMesh_IncrementalMesh::IsParallelDefault),
                    R"#(Returns multi-threading usage flag set by default in Discret() static method (thus applied only to Mesh Factories).)#" 
          )
        .def_static("SetParallelDefault_s",
                    (void (*)(  const bool  ) ) static_cast<void (*)(  const bool  ) >(&BRepMesh_IncrementalMesh::SetParallelDefault),
                    R"#(Setup multi-threading usage flag set by default in Discret() static method (thus applied only to Mesh Factories).)#"  , py::arg("isInParallel")
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepMesh_IncrementalMesh::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepMesh_IncrementalMesh::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Parameters",
             ( const IMeshTools_Parameters & (BRepMesh_IncrementalMesh::*)() const) static_cast< const IMeshTools_Parameters & (BRepMesh_IncrementalMesh::*)() const>(&BRepMesh_IncrementalMesh::Parameters),
             R"#(Returns meshing parameters)#"
             
         )
       .def("ChangeParameters",
             (IMeshTools_Parameters & (BRepMesh_IncrementalMesh::*)() ) static_cast<IMeshTools_Parameters & (BRepMesh_IncrementalMesh::*)() >(&BRepMesh_IncrementalMesh::ChangeParameters),
             R"#(Returns modifiable meshing parameters)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepMesh_IncrementalMesh::*)() const) static_cast< const handle<Standard_Type> & (BRepMesh_IncrementalMesh::*)() const>(&BRepMesh_IncrementalMesh::DynamicType),
             R"#()#"
             
         )
;

    // Class BRepMesh_IncrementalMeshFactory from ./opencascade/BRepMesh_IncrementalMeshFactory.hxx
    klass = m.attr("BRepMesh_IncrementalMeshFactory");


    // nested enums

    static_cast<py::class_<BRepMesh_IncrementalMeshFactory ,opencascade::handle<BRepMesh_IncrementalMeshFactory>  , BRepMesh_DiscretAlgoFactory >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("CreateAlgorithm",
             (handle<BRepMesh_DiscretRoot> (BRepMesh_IncrementalMeshFactory::*)(  const TopoDS_Shape & ,  double ,  double  ) ) static_cast<handle<BRepMesh_DiscretRoot> (BRepMesh_IncrementalMeshFactory::*)(  const TopoDS_Shape & ,  double ,  double  ) >(&BRepMesh_IncrementalMeshFactory::CreateAlgorithm),
             R"#(Creates a new BRepMesh_IncrementalMesh instance.)#"  , py::arg("theShape"),  py::arg("theLinDeflection"),  py::arg("theAngDeflection")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepMesh_IncrementalMeshFactory::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepMesh_IncrementalMeshFactory::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepMesh_IncrementalMeshFactory::*)() const) static_cast< const handle<Standard_Type> & (BRepMesh_IncrementalMeshFactory::*)() const>(&BRepMesh_IncrementalMeshFactory::DynamicType),
             R"#()#"
             
         )
;

// functions

// ./opencascade/BRepMesh_Circle.hxx
// ./opencascade/BRepMesh_CircleInspector.hxx
// ./opencascade/BRepMesh_CircleTool.hxx
// ./opencascade/BRepMesh_Classifier.hxx
// ./opencascade/BRepMesh_Context.hxx
// ./opencascade/BRepMesh_CurveTessellator.hxx
// ./opencascade/BRepMesh_DataStructureOfDelaun.hxx
// ./opencascade/BRepMesh_Deflection.hxx
// ./opencascade/BRepMesh_DegreeOfFreedom.hxx
// ./opencascade/BRepMesh_DelabellaBaseMeshAlgo.hxx
// ./opencascade/BRepMesh_DelabellaMeshAlgoFactory.hxx
// ./opencascade/BRepMesh_Delaun.hxx
// ./opencascade/BRepMesh_DiscretAlgoFactory.hxx
// ./opencascade/BRepMesh_DiscretFactory.hxx
// ./opencascade/BRepMesh_DiscretRoot.hxx
// ./opencascade/BRepMesh_Edge.hxx
// ./opencascade/BRepMesh_EdgeDiscret.hxx
// ./opencascade/BRepMesh_EdgeParameterProvider.hxx
// ./opencascade/BRepMesh_EdgeTessellationExtractor.hxx
// ./opencascade/BRepMesh_ExtrusionRangeSplitter.hxx
// ./opencascade/BRepMesh_FaceChecker.hxx
// ./opencascade/BRepMesh_FaceDiscret.hxx
// ./opencascade/BRepMesh_FastDiscret.hxx
// ./opencascade/BRepMesh_GeomTool.hxx
// ./opencascade/BRepMesh_IncrementalMesh.hxx
// ./opencascade/BRepMesh_IncrementalMeshFactory.hxx
// ./opencascade/BRepMesh_MeshAlgoFactory.hxx
// ./opencascade/BRepMesh_MeshTool.hxx
// ./opencascade/BRepMesh_ModelBuilder.hxx
// ./opencascade/BRepMesh_ModelHealer.hxx
// ./opencascade/BRepMesh_ModelPostProcessor.hxx
// ./opencascade/BRepMesh_ModelPreProcessor.hxx
// ./opencascade/BRepMesh_OrientedEdge.hxx
// ./opencascade/BRepMesh_PairOfIndex.hxx
// ./opencascade/BRepMesh_SelectorOfDataStructureOfDelaun.hxx
// ./opencascade/BRepMesh_ShapeTool.hxx
// ./opencascade/BRepMesh_ShapeVisitor.hxx
// ./opencascade/BRepMesh_Triangle.hxx
// ./opencascade/BRepMesh_Triangulator.hxx
// ./opencascade/BRepMesh_UndefinedRangeSplitter.hxx
// ./opencascade/BRepMesh_Vertex.hxx
// ./opencascade/BRepMesh_VertexInspector.hxx
// ./opencascade/BRepMesh_VertexTool.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
