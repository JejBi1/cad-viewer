
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>

#define WIN32_LEAN_AND_MEAN
#include <windows.h>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Aspect_WindowInputListener.hxx>
#include <WNT_WClass.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <WNT_Window.hxx>

// module includes
#include <WNT_ClassDefinitionError.hxx>
#include <WNT_Dword.hxx>
#include <WNT_HIDSpaceMouse.hxx>
#include <WNT_OrientationType.hxx>
#include <WNT_WClass.hxx>
#include <WNT_Window.hxx>
#include <WNT_WindowPtr.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module
#include <Aspect_DisplayConnection.hxx>
struct __GLXFBConfigRec {};

// Module definiiton
void register_WNT(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("WNT"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes

// classes

    // Class WNT_HIDSpaceMouse from ./opencascade/WNT_HIDSpaceMouse.hxx
    klass = m.attr("WNT_HIDSpaceMouse");


    // nested enums
        klass.attr("VENDOR_ID_LOGITECH") = py::cast(int(WNT_HIDSpaceMouse::VENDOR_ID_LOGITECH));
        klass.attr("VENDOR_ID_3DCONNEXION") = py::cast(int(WNT_HIDSpaceMouse::VENDOR_ID_3DCONNEXION));

    static_cast<py::class_<WNT_HIDSpaceMouse , shared_ptr<WNT_HIDSpaceMouse>  >>(klass)
    // constructors
        .def(py::init< unsigned long, const uint8_t *,size_t >()  , py::arg("theProductId"),  py::arg("theData"),  py::arg("theSize") )
    // custom constructors
    // methods
        .def("RawValueRange",
             (int16_t (WNT_HIDSpaceMouse::*)() const) static_cast<int16_t (WNT_HIDSpaceMouse::*)() const>(&WNT_HIDSpaceMouse::RawValueRange),
             R"#(Return the raw value range.)#" 
          )
        .def("SetRawValueRange",
             (void (WNT_HIDSpaceMouse::*)( int16_t  ) ) static_cast<void (WNT_HIDSpaceMouse::*)( int16_t  ) >(&WNT_HIDSpaceMouse::SetRawValueRange),
             R"#(Set the raw value range.)#"  , py::arg("theRange")
          )
        .def("IsTranslation",
             (bool (WNT_HIDSpaceMouse::*)() const) static_cast<bool (WNT_HIDSpaceMouse::*)() const>(&WNT_HIDSpaceMouse::IsTranslation),
             R"#(Return TRUE if data chunk defines new translation values.)#" 
          )
        .def("Translation",
             (NCollection_Vec3<double> (WNT_HIDSpaceMouse::*)( bool & ,  bool  ) const) static_cast<NCollection_Vec3<double> (WNT_HIDSpaceMouse::*)( bool & ,  bool  ) const>(&WNT_HIDSpaceMouse::Translation),
             R"#(Return new translation values.)#"  , py::arg("theIsIdle"),  py::arg("theIsQuadric")
          )
        .def("IsRotation",
             (bool (WNT_HIDSpaceMouse::*)() const) static_cast<bool (WNT_HIDSpaceMouse::*)() const>(&WNT_HIDSpaceMouse::IsRotation),
             R"#(Return TRUE if data chunk defines new rotation values.)#" 
          )
        .def("Rotation",
             (NCollection_Vec3<double> (WNT_HIDSpaceMouse::*)( bool & ,  bool  ) const) static_cast<NCollection_Vec3<double> (WNT_HIDSpaceMouse::*)( bool & ,  bool  ) const>(&WNT_HIDSpaceMouse::Rotation),
             R"#(Return new rotation values.)#"  , py::arg("theIsIdle"),  py::arg("theIsQuadric")
          )
        .def("IsKeyState",
             (bool (WNT_HIDSpaceMouse::*)() const) static_cast<bool (WNT_HIDSpaceMouse::*)() const>(&WNT_HIDSpaceMouse::IsKeyState),
             R"#(Return TRUE for key state data chunk.)#" 
          )
        .def("KeyState",
             (uint32_t (WNT_HIDSpaceMouse::*)() const) static_cast<uint32_t (WNT_HIDSpaceMouse::*)() const>(&WNT_HIDSpaceMouse::KeyState),
             R"#(Return new keystate.)#" 
          )
        .def("HidToSpaceKey",
             (Aspect_VKey (WNT_HIDSpaceMouse::*)( unsigned short  ) const) static_cast<Aspect_VKey (WNT_HIDSpaceMouse::*)( unsigned short  ) const>(&WNT_HIDSpaceMouse::HidToSpaceKey),
             R"#(Convert key state bit into virtual key.)#"  , py::arg("theKeyBit")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("IsKnownProduct_s",
                    (bool (*)( unsigned long  ) ) static_cast<bool (*)( unsigned long  ) >(&WNT_HIDSpaceMouse::IsKnownProduct),
                    R"#(Return if product id is known by this class.)#"  , py::arg("theProductId")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class WNT_WClass from ./opencascade/WNT_WClass.hxx
    klass = m.attr("WNT_WClass");


    // nested enums

    static_cast<py::class_<WNT_WClass ,opencascade::handle<WNT_WClass>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const TCollection_AsciiString &,void * const , const unsigned int, const int, const int, const Aspect_Handle, const Aspect_Handle, const TCollection_AsciiString & >()  , py::arg("theClassName"),  py::arg("theWndProc"),  py::arg("theStyle"),  py::arg("theClassExtra")=static_cast< const int>(0),  py::arg("theWindowExtra")=static_cast< const int>(0),  py::arg("theCursor")=static_cast< const Aspect_Handle>(NULL),  py::arg("theIcon")=static_cast< const Aspect_Handle>(NULL),  py::arg("theMenuName")=static_cast< const TCollection_AsciiString &>(TCollection_AsciiString :: EmptyString ( )) )
    // custom constructors
    // methods
        .def("WndProc",
             (void * (WNT_WClass::*)() const) static_cast<void * (WNT_WClass::*)() const>(&WNT_WClass::WndProc),
             R"#(Returns address of window procedure.)#" 
          )
        .def("Instance",
             (Aspect_Handle (WNT_WClass::*)() const) static_cast<Aspect_Handle (WNT_WClass::*)() const>(&WNT_WClass::Instance),
             R"#(Returns a program instance handle.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&WNT_WClass::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&WNT_WClass::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (WNT_WClass::*)() const) static_cast< const handle<Standard_Type> & (WNT_WClass::*)() const>(&WNT_WClass::DynamicType),
             R"#()#"
             
         )
       .def("Name",
             ( const TCollection_AsciiString & (WNT_WClass::*)() const) static_cast< const TCollection_AsciiString & (WNT_WClass::*)() const>(&WNT_WClass::Name),
             R"#(Returns a class name.)#"
             
         )
;

    // Class WNT_Window from ./opencascade/WNT_Window.hxx
    klass = m.attr("WNT_Window");


    // nested enums
        py::enum_<WNT_Window::RawInputMask>(klass, "RawInputMask_e", R"#(Raw input flags.)#")
            .value("RawInputMask_Mouse", WNT_Window::RawInputMask::RawInputMask_Mouse)
            .value("RawInputMask_SpaceMouse", WNT_Window::RawInputMask::RawInputMask_SpaceMouse);

    static_cast<py::class_<WNT_Window ,opencascade::handle<WNT_Window>  , Aspect_Window >>(klass)
    // constructors
        .def(py::init<  const Aspect_Handle, const Quantity_NameOfColor >()  , py::arg("theHandle"),  py::arg("theBackColor")=static_cast< const Quantity_NameOfColor>(Quantity_NOC_MATRAGRAY) )
        .def(py::init<  const char * const , const handle<WNT_WClass> &, const WNT_Dword &, const int, const int, const int, const int, const Quantity_NameOfColor, const Aspect_Handle, const Aspect_Handle,void * const  >()  , py::arg("theTitle"),  py::arg("theClass"),  py::arg("theStyle"),  py::arg("thePxLeft"),  py::arg("thePxTop"),  py::arg("thePxWidth"),  py::arg("thePxHeight"),  py::arg("theBackColor")=static_cast< const Quantity_NameOfColor>(Quantity_NOC_MATRAGRAY),  py::arg("theParent")=static_cast< const Aspect_Handle>(0),  py::arg("theMenu")=static_cast< const Aspect_Handle>(0),  py::arg("theClientStruct")=static_cast<void * const >(0) )
    // custom constructors
    // methods
        .def("SetCursor",
             (void (WNT_Window::*)(  const Aspect_Handle  ) const) static_cast<void (WNT_Window::*)(  const Aspect_Handle  ) const>(&WNT_Window::SetCursor),
             R"#(Sets cursor for ENTIRE WINDOW CLASS to which the Window belongs.)#"  , py::arg("theCursor")
          )
        .def("Map",
             (void (WNT_Window::*)() const) static_cast<void (WNT_Window::*)() const>(&WNT_Window::Map),
             R"#(Opens the window <me>.)#" 
          )
        .def("Map",
             (void (WNT_Window::*)(  const int  ) const) static_cast<void (WNT_Window::*)(  const int  ) const>(&WNT_Window::Map),
             R"#(Opens a window according to the map mode. This method is specific to Windows NT.)#"  , py::arg("theMapMode")
          )
        .def("Unmap",
             (void (WNT_Window::*)() const) static_cast<void (WNT_Window::*)() const>(&WNT_Window::Unmap),
             R"#(Closes the window <me>.)#" 
          )
        .def("DoResize",
             (Aspect_TypeOfResize (WNT_Window::*)() ) static_cast<Aspect_TypeOfResize (WNT_Window::*)() >(&WNT_Window::DoResize),
             R"#(Applies the resizing to the window <me>.)#" 
          )
        .def("DoMapping",
             (bool (WNT_Window::*)() const) static_cast<bool (WNT_Window::*)() const>(&WNT_Window::DoMapping),
             R"#(Does nothing on Windows.)#" 
          )
        .def("SetPos",
             (void (WNT_Window::*)(  const int ,   const int ,   const int ,   const int  ) ) static_cast<void (WNT_Window::*)(  const int ,   const int ,   const int ,   const int  ) >(&WNT_Window::SetPos),
             R"#(Changes variables due to window position.)#"  , py::arg("X"),  py::arg("Y"),  py::arg("X1"),  py::arg("Y1")
          )
        .def("IsMapped",
             (bool (WNT_Window::*)() const) static_cast<bool (WNT_Window::*)() const>(&WNT_Window::IsMapped),
             R"#(Returns True if the window <me> is opened and False if the window is closed.)#" 
          )
        .def("Ratio",
             (double (WNT_Window::*)() const) static_cast<double (WNT_Window::*)() const>(&WNT_Window::Ratio),
             R"#(Returns The Window RATIO equal to the physical WIDTH/HEIGHT dimensions.)#" 
          )
        .def("NativeHandle",
             (Aspect_Drawable (WNT_Window::*)() const) static_cast<Aspect_Drawable (WNT_Window::*)() const>(&WNT_Window::NativeHandle),
             R"#(Returns native Window handle (HWND))#" 
          )
        .def("NativeParentHandle",
             (Aspect_Drawable (WNT_Window::*)() const) static_cast<Aspect_Drawable (WNT_Window::*)() const>(&WNT_Window::NativeParentHandle),
             R"#(Returns parent of native Window handle (HWND on Windows).)#" 
          )
        .def("NativeFBConfig",
             (Aspect_FBConfig (WNT_Window::*)() const) static_cast<Aspect_FBConfig (WNT_Window::*)() const>(&WNT_Window::NativeFBConfig),
             R"#(Returns nothing on Windows)#" 
          )
        .def("SetTitle",
             (void (WNT_Window::*)(  const TCollection_AsciiString &  ) ) static_cast<void (WNT_Window::*)(  const TCollection_AsciiString &  ) >(&WNT_Window::SetTitle),
             R"#(Sets window title.)#"  , py::arg("theTitle")
          )
        .def("InvalidateContent",
             (void (WNT_Window::*)(  const handle<Aspect_DisplayConnection> &  ) ) static_cast<void (WNT_Window::*)(  const handle<Aspect_DisplayConnection> &  ) >(&WNT_Window::InvalidateContent),
             R"#(Invalidate entire window content by calling InvalidateRect() WinAPI function, resulting in WM_PAINT event put into window message loop. Method can be called from non-window thread, and system will also automatically aggregate multiple events into single one.)#"  , py::arg("theDisp")=static_cast< const handle<Aspect_DisplayConnection> &>(occ :: handle < Aspect_DisplayConnection > ( ))
          )
        .def("HWindow",
             (Aspect_Handle (WNT_Window::*)() const) static_cast<Aspect_Handle (WNT_Window::*)() const>(&WNT_Window::HWindow),
             R"#(Returns the Windows NT handle of the created window <me>.)#" 
          )
        .def("HParentWindow",
             (Aspect_Handle (WNT_Window::*)() const) static_cast<Aspect_Handle (WNT_Window::*)() const>(&WNT_Window::HParentWindow),
             R"#(Returns the Windows NT handle parent of the created window <me>.)#" 
          )
        .def("RegisterRawInputDevices",
             (int (WNT_Window::*)( unsigned int  ) ) static_cast<int (WNT_Window::*)( unsigned int  ) >(&WNT_Window::RegisterRawInputDevices),
             R"#(RegisterRawInputDevices() wrapper.)#"  , py::arg("theRawDeviceMask")
          )
    // methods using call by reference i.s.o. return
        .def("Position",
             []( WNT_Window &self   ){
                 int  X1;
                int  Y1;
                int  X2;
                int  Y2;

                 self.Position(X1,Y1,X2,Y2);
                 return std::make_tuple(X1,Y1,X2,Y2); },
             R"#(Returns The Window POSITION in PIXEL)#" 
          )
        .def("Size",
             []( WNT_Window &self   ){
                 int  Width;
                int  Height;

                 self.Size(Width,Height);
                 return std::make_tuple(Width,Height); },
             R"#(Returns The Window SIZE in PIXEL)#" 
          )
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&WNT_Window::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&WNT_Window::get_type_descriptor),
                    R"#()#" 
          )
        .def_static("VirtualKeyFromNative_s",
                    (Aspect_VKey (*)( int  ) ) static_cast<Aspect_VKey (*)( int  ) >(&WNT_Window::VirtualKeyFromNative),
                    R"#(Convert WInAPI virtual key (VK_ enumeration) into Aspect_VKey.)#"  , py::arg("theKey")
          )
        .def_static("MouseKeyFlagsFromEvent_s",
                    (Aspect_VKeyFlags (*)( WPARAM  ) ) static_cast<Aspect_VKeyFlags (*)( WPARAM  ) >(&WNT_Window::MouseKeyFlagsFromEvent),
                    R"#(Convert WPARAM from mouse event to key flags.)#"  , py::arg("theKeys")
          )
        .def_static("MouseButtonsFromEvent_s",
                    (Aspect_VKeyMouse (*)( WPARAM  ) ) static_cast<Aspect_VKeyMouse (*)( WPARAM  ) >(&WNT_Window::MouseButtonsFromEvent),
                    R"#(Convert WPARAM from mouse event to mouse buttons bitmask.)#"  , py::arg("theKeys")
          )
        .def_static("MouseKeyFlagsAsync_s",
                    (Aspect_VKeyFlags (*)() ) static_cast<Aspect_VKeyFlags (*)() >(&WNT_Window::MouseKeyFlagsAsync),
                    R"#(Use GetAsyncKeyState() to fetch actual mouse key flags regardless of event loop.)#" 
          )
        .def_static("MouseButtonsAsync_s",
                    (Aspect_VKeyMouse (*)() ) static_cast<Aspect_VKeyMouse (*)() >(&WNT_Window::MouseButtonsAsync),
                    R"#(Use GetAsyncKeyState() to fetch actual mouse buttons state regardless of event loop.)#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (WNT_Window::*)() const) static_cast< const handle<Standard_Type> & (WNT_Window::*)() const>(&WNT_Window::DynamicType),
             R"#()#"
             
         )
;

// functions

// ./opencascade/WNT_ClassDefinitionError.hxx
// ./opencascade/WNT_Dword.hxx
// ./opencascade/WNT_HIDSpaceMouse.hxx
// ./opencascade/WNT_OrientationType.hxx
// ./opencascade/WNT_WClass.hxx
// ./opencascade/WNT_Window.hxx
// ./opencascade/WNT_WindowPtr.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions
register_occ_exception<WNT_ClassDefinitionError>(m, "WNT_ClassDefinitionError");

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
