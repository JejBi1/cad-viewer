
// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;


// Standard Handle
#include <Standard_Handle.hxx>

// collection specific top preinclusion
#include <BRepExtrema_ProximityDistTool.hxx>
#include <gp_XYZ.hxx>

class OpenGl_ShaderProgram;


// template related includes
#include <gp_Pnt.hxx>
#include <TCollection_AsciiString.hxx>
#include <AIS_MouseGesture.hxx>
#include <gp_Dir.hxx>
#include <Graphic3d_ShaderObject.hxx>
#include <Graphic3d_GraphicDriverFactory.hxx>
#include <Graphic3d_Group.hxx>
#include <BRep_PointRepresentation.hxx>
#include <Aspect_TrackedDevicePose.hxx>
#include <Graphic3d_Layer.hxx>
#include <STEPCAFControl_ExternFile.hxx>
#include <Standard_GUID.hxx>
#include <SelectMgr_Filter.hxx>
#include <V3d_View.hxx>
#include <Graphic3d_CView.hxx>
#include <Graphic3d_Buffer.hxx>
#include <BOPAlgo_CheckResult.hxx>
#include <Extrema_POnCurv.hxx>
#include <Font_SystemFont.hxx>
#include <TopExp_Explorer.hxx>
#include <AIS_Animation.hxx>
#include <Message_MetricType.hxx>
#include <Poly_Triangle.hxx>
#include <TDF_AttributeDelta.hxx>
#include <Graphic3d_ShaderAttribute.hxx>
#include <BRep_CurveRepresentation.hxx>
#include <Bnd_Range.hxx>
#include <TopTools_ShapeMapHasher.hxx>
#include <OpenGl_Texture.hxx>
#include <Standard_Transient.hxx>
#include <TDocStd_ApplicationDelta.hxx>
#include <Extrema_POnSurf.hxx>
#include <PrsMgr_PresentableObject.hxx>
#include <PCDM_Reference.hxx>
#include <OpenGl_VertexBuffer.hxx>
#include <TCollection_HAsciiString.hxx>
#include <Bnd_Box.hxx>
#include <Poly_Triangulation.hxx>
#include <gp_Pnt2d.hxx>
#include <Aspect_XRAction.hxx>
#include <IFSelect_Selection.hxx>
#include <Graphic3d_Aspects.hxx>
#include <PrsMgr_Presentation.hxx>
#include <XCAFPrs_Style.hxx>
#include <TCollection_HExtendedString.hxx>
#include <Graphic3d_FrameStatsData.hxx>
#include <TDF_Attribute.hxx>
#include <gp_Vec.hxx>
#include <TDocStd_Document.hxx>
#include <TDF_Delta.hxx>
#include <AIS_SelectionScheme.hxx>
#include <XCAFDoc_VisMaterial.hxx>
#include <OpenGl_GlTypes.hxx>
#include <Standard_Dump.hxx>
#include <SelectMgr_SensitiveEntity.hxx>
#include <BRepExtrema_SolutionElem.hxx>
#include <TopoDS_Iterator.hxx>
#include <Graphic3d_CLight.hxx>
#include <Graphic3d_Structure.hxx>
#include <OpenGl_GlTypes.hxx>
#include <TDF_Label.hxx>
#include <Storage_Root.hxx>
#include <OpenGl_ShaderProgram.hxx>
#include <SelectMgr_EntityOwner.hxx>
#include <TopoDS_Shape.hxx>
#include <BRepMesh_DiscretAlgoFactory.hxx>
#include <CDM_MetaData.hxx>
#include <Quantity_Color.hxx>
#include <SelectMgr_Selection.hxx>
#include <AIS_InteractiveObject.hxx>
#include <AIS_ColoredDrawer.hxx>
#include <Aspect_Touch.hxx>
#include <TCollection_ExtendedString.hxx>
#include <TColStd_PackedMapOfInteger.hxx>
#include <Message_Alert.hxx>
#include <AIS_GlobalStatus.hxx>
#include <Graphic3d_ShaderVariable.hxx>
#include <Graphic3d_ZLayerId.hxx>
#include <Message_Printer.hxx>
#include <PCDM_Document.hxx>
#include <DE_ConfigurationNode.hxx>
#include <Standard_Persistent.hxx>

#include "NCollection_tmpl.hxx"


// user-defined pre
#include "OCP_specific.inc"

// collection specific preinclusion


// Module definiiton
void register_collections_1(py::module &m) {

    // register typdefs
    register_template_NCollection_List<TCollection_ExtendedString>(m,"List_TCollection_ExtendedString");
    register_template_NCollection_List<handle<TDF_Attribute>>(m,"List_TDF_Attribute");
    register_template_NCollection_List<handle<TDF_AttributeDelta>>(m,"List_TDF_AttributeDelta");
    register_template_NCollection_List<handle<TDF_Delta>>(m,"List_TDF_Delta");
    register_template_NCollection_List<TDF_Label>(m,"List_TDF_Label");
    register_template_NCollection_List<TopoDS_Shape>(m,"List_TopoDS_Shape");
    register_template_NCollection_List<opencascade::handle<V3d_View>>(m,"List_V3d_View");
    register_template_NCollection_List<double>(m,"List_double");
    register_template_NCollection_List<int>(m,"List_int");
    register_template_NCollection_List<uint8_t>(m,"List_uint8_t");
    register_template_NCollection_Map<handle<TDF_Attribute>>(m,"Map_TDF_Attribute");
    register_template_NCollection_Map<TDF_Label>(m,"Map_TDF_Label");
    register_template_NCollection_Map<TopoDS_Shape,TopTools_ShapeMapHasher>(m,"Map_TopoDS_Shape_TopTools_ShapeMapHasher");
    register_template_NCollection_Mat3<double>(m,"Mat3_double");
    register_template_NCollection_Mat3<float>(m,"Mat3_float");
    register_template_NCollection_Mat4<double>(m,"Mat4_double");
    register_template_NCollection_Mat4<float>(m,"Mat4_float");
    register_template_NCollection_Sequence<handle<AIS_Animation>>(m,"Sequence_AIS_Animation");
    register_template_NCollection_Sequence<handle<AIS_InteractiveObject>>(m,"Sequence_AIS_InteractiveObject");
    register_template_NCollection_Sequence<BRepExtrema_SolutionElem>(m,"Sequence_BRepExtrema_SolutionElem");
    register_template_NCollection_Sequence<Extrema_POnCurv>(m,"Sequence_Extrema_POnCurv");
    register_template_NCollection_Sequence<Extrema_POnSurf>(m,"Sequence_Extrema_POnSurf");
    register_template_NCollection_Sequence<handle<Font_SystemFont>>(m,"Sequence_Font_SystemFont");
    register_template_NCollection_Sequence<handle<Graphic3d_CView>>(m,"Sequence_Graphic3d_CView");
    register_template_NCollection_Sequence<handle<Graphic3d_Group>>(m,"Sequence_Graphic3d_Group");
    register_template_NCollection_Sequence<handle<Graphic3d_ShaderAttribute>>(m,"Sequence_Graphic3d_ShaderAttribute");
    register_template_NCollection_Sequence<handle<Graphic3d_ShaderObject>>(m,"Sequence_Graphic3d_ShaderObject");
    register_template_NCollection_Sequence<handle<Graphic3d_ShaderVariable>>(m,"Sequence_Graphic3d_ShaderVariable");
    register_template_NCollection_Sequence<handle<IFSelect_Selection>>(m,"Sequence_IFSelect_Selection");
    register_template_NCollection_Sequence<handle<Message_Printer>>(m,"Sequence_Message_Printer");
    register_template_NCollection_Sequence<handle<OpenGl_ShaderProgram>>(m,"Sequence_OpenGl_ShaderProgram");
    register_template_NCollection_Sequence<handle<OpenGl_Texture>>(m,"Sequence_OpenGl_Texture");
    register_template_NCollection_Sequence<handle<PCDM_Document>>(m,"Sequence_PCDM_Document");
    register_template_NCollection_Sequence<PCDM_Reference>(m,"Sequence_PCDM_Reference");
    register_template_NCollection_Sequence<handle<Poly_Triangulation>>(m,"Sequence_Poly_Triangulation");
    register_template_NCollection_Sequence<handle<PrsMgr_Presentation>>(m,"Sequence_PrsMgr_Presentation");
    register_template_NCollection_Sequence<Quantity_Color>(m,"Sequence_Quantity_Color");
    register_template_NCollection_Sequence<handle<SelectMgr_EntityOwner>>(m,"Sequence_SelectMgr_EntityOwner");
    register_template_NCollection_Sequence<handle<SelectMgr_Selection>>(m,"Sequence_SelectMgr_Selection");
    register_template_NCollection_Sequence<handle<Standard_Transient>>(m,"Sequence_Standard_Transient");
    register_template_NCollection_Sequence<handle<Storage_Root>>(m,"Sequence_Storage_Root");
    register_template_NCollection_Sequence<TCollection_AsciiString>(m,"Sequence_TCollection_AsciiString");
    register_template_NCollection_Sequence<TCollection_ExtendedString>(m,"Sequence_TCollection_ExtendedString");
    register_template_NCollection_Sequence<handle<TCollection_HAsciiString>>(m,"Sequence_TCollection_HAsciiString");
    register_template_NCollection_Sequence<handle<TCollection_HExtendedString>>(m,"Sequence_TCollection_HExtendedString");
    register_template_NCollection_Sequence<handle<TDF_Attribute>>(m,"Sequence_TDF_Attribute");
    register_template_NCollection_Sequence<TDF_Label>(m,"Sequence_TDF_Label");
    register_template_NCollection_Sequence<handle<TDocStd_ApplicationDelta>>(m,"Sequence_TDocStd_ApplicationDelta");
    register_template_NCollection_Sequence<handle<TDocStd_Document>>(m,"Sequence_TDocStd_Document");
    register_template_NCollection_Sequence<TopoDS_Shape>(m,"Sequence_TopoDS_Shape");
    register_template_NCollection_Sequence<handle<V3d_View>>(m,"Sequence_V3d_View");
    register_template_NCollection_Sequence<NCollection_Vec2<int>>(m,"Sequence_Vec2_int");
    register_template_NCollection_Sequence<double>(m,"Sequence_double");
    register_template_NCollection_Sequence<gp_Pnt>(m,"Sequence_gp_Pnt");
    register_template_NCollection_Sequence<int>(m,"Sequence_int");
    register_template_NCollection_Vec2<double>(m,"Vec2_double");
    register_template_NCollection_Vec2<float>(m,"Vec2_float");
    register_template_NCollection_Vec2<int>(m,"Vec2_int");
    register_template_NCollection_Vec3<bool>(m,"Vec3_bool");
    register_template_NCollection_Vec3<double>(m,"Vec3_double");
    register_template_NCollection_Vec3<float>(m,"Vec3_float");
    register_template_NCollection_Vec3<int>(m,"Vec3_int");
    register_template_NCollection_Vec4<bool>(m,"Vec4_bool");
    register_template_NCollection_Vec4<double>(m,"Vec4_double");
    register_template_NCollection_Vec4<float>(m,"Vec4_float");
    register_template_NCollection_Vec4<int>(m,"Vec4_int");
    register_template_NCollection_Vec4<uint8_t>(m,"Vec4_uint8_t");
    register_template_NCollection_Array2<double>(m,"Array2_double");
    register_template_NCollection_Array2<gp_Pnt>(m,"Array2_gp_Pnt");
    register_template_NCollection_HArray1<Bnd_Box>(m,"HArray1_Bnd_Box");
    register_template_NCollection_HArray1<Poly_Triangle>(m,"HArray1_Poly_Triangle");
    register_template_NCollection_HArray1<Quantity_Color>(m,"HArray1_Quantity_Color");
    register_template_NCollection_HArray1<handle<Standard_Persistent>>(m,"HArray1_Standard_Persistent");
    register_template_NCollection_HArray1<TCollection_ExtendedString>(m,"HArray1_TCollection_ExtendedString");
    register_template_NCollection_HArray1<TDF_Label>(m,"HArray1_TDF_Label");
    register_template_NCollection_HArray1<bool>(m,"HArray1_bool");
    register_template_NCollection_HArray1<double>(m,"HArray1_double");
    register_template_NCollection_HArray1<float>(m,"HArray1_float");
    register_template_NCollection_HArray1<gp_Dir>(m,"HArray1_gp_Dir");
    register_template_NCollection_HArray1<gp_Pnt>(m,"HArray1_gp_Pnt");
    register_template_NCollection_HArray1<gp_Pnt2d>(m,"HArray1_gp_Pnt2d");
    register_template_NCollection_HArray1<int>(m,"HArray1_int");
    register_template_NCollection_HArray1<uint8_t>(m,"HArray1_uint8_t");
    register_template_NCollection_HSequence<handle<AIS_InteractiveObject>>(m,"HSequence_AIS_InteractiveObject");
    register_template_NCollection_HSequence<handle<Standard_Transient>>(m,"HSequence_Standard_Transient");
    register_template_NCollection_HSequence<handle<Storage_Root>>(m,"HSequence_Storage_Root");
    register_template_NCollection_HSequence<TCollection_AsciiString>(m,"HSequence_TCollection_AsciiString");
    register_template_NCollection_HSequence<TCollection_ExtendedString>(m,"HSequence_TCollection_ExtendedString");
    register_template_NCollection_HSequence<handle<TCollection_HAsciiString>>(m,"HSequence_TCollection_HAsciiString");
    register_template_NCollection_HSequence<handle<TCollection_HExtendedString>>(m,"HSequence_TCollection_HExtendedString");
    register_template_NCollection_HSequence<TopoDS_Shape>(m,"HSequence_TopoDS_Shape");
    register_template_NCollection_HSequence<int>(m,"HSequence_int");

}

// user-defined post
