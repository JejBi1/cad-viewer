
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_DeltaOnModification.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDataStd_TreeNode.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_GUID.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDataStd_ByteArray.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDataStd_ExtStringArray.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDataStd_IntegerArray.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TColStd_HPackedMapOfInteger.hxx>
#include <TDataStd_IntPackedMap.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDataStd_RealArray.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <Standard_GUID.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_GUID.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_DeltaOnModification.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_GUID.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_DeltaOnModification.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_DeltaOnModification.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDataStd_HDataMapOfStringInteger.hxx>
#include <TDataStd_HDataMapOfStringReal.hxx>
#include <TDataStd_HDataMapOfStringString.hxx>
#include <TDataStd_HDataMapOfStringByte.hxx>
#include <TDataStd_HDataMapOfStringHArray1OfInteger.hxx>
#include <TDataStd_HDataMapOfStringHArray1OfReal.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <Standard_GUID.hxx>
#include <TDataStd_Real.hxx>
#include <TDataStd_Integer.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDataStd_TreeNode.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_DeltaOnModification.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_DataSet.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_DataSet.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_GUID.hxx>
#include <TDF_Label.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_AttributeDelta.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_DataSet.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_DataSet.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_GUID.hxx>
#include <TDF_Label.hxx>
#include <TCollection_ExtendedString.hxx>
#include <TDataStd_Real.hxx>
#include <TDataStd_Expression.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_DataSet.hxx>

// module includes
#include <TDataStd.hxx>
#include <TDataStd_AsciiString.hxx>
#include <TDataStd_BooleanArray.hxx>
#include <TDataStd_BooleanList.hxx>
#include <TDataStd_ByteArray.hxx>
#include <TDataStd_ChildNodeIterator.hxx>
#include <TDataStd_Comment.hxx>
#include <TDataStd_Current.hxx>
#include <TDataStd_DeltaOnModificationOfByteArray.hxx>
#include <TDataStd_DeltaOnModificationOfExtStringArray.hxx>
#include <TDataStd_DeltaOnModificationOfIntArray.hxx>
#include <TDataStd_DeltaOnModificationOfIntPackedMap.hxx>
#include <TDataStd_DeltaOnModificationOfRealArray.hxx>
#include <TDataStd_Directory.hxx>
#include <TDataStd_Expression.hxx>
#include <TDataStd_ExtStringArray.hxx>
#include <TDataStd_ExtStringList.hxx>
#include <TDataStd_GenericEmpty.hxx>
#include <TDataStd_GenericExtString.hxx>
#include <TDataStd_HDataMapOfStringByte.hxx>
#include <TDataStd_HDataMapOfStringHArray1OfInteger.hxx>
#include <TDataStd_HDataMapOfStringHArray1OfReal.hxx>
#include <TDataStd_HDataMapOfStringInteger.hxx>
#include <TDataStd_HDataMapOfStringReal.hxx>
#include <TDataStd_HDataMapOfStringString.hxx>
#include <TDataStd_Integer.hxx>
#include <TDataStd_IntegerArray.hxx>
#include <TDataStd_IntegerList.hxx>
#include <TDataStd_IntPackedMap.hxx>
#include <TDataStd_Name.hxx>
#include <TDataStd_NamedData.hxx>
#include <TDataStd_NoteBook.hxx>
#include <TDataStd_PtrTreeNode.hxx>
#include <TDataStd_Real.hxx>
#include <TDataStd_RealArray.hxx>
#include <TDataStd_RealEnum.hxx>
#include <TDataStd_RealList.hxx>
#include <TDataStd_ReferenceArray.hxx>
#include <TDataStd_ReferenceList.hxx>
#include <TDataStd_Relation.hxx>
#include <TDataStd_Tick.hxx>
#include <TDataStd_TreeNode.hxx>
#include <TDataStd_UAttribute.hxx>
#include <TDataStd_Variable.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_TDataStd(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("TDataStd"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes
    class Py_TDataStd_GenericEmpty : public TDataStd_GenericEmpty{
    public:
        using TDataStd_GenericEmpty::TDataStd_GenericEmpty;


        // public pure virtual

         const Standard_GUID & ID() const  override { using return_type =  const Standard_GUID &;
    PYBIND11_OVERLOAD_PURE(return_type,TDF_Attribute,ID,) };
        handle<TDF_Attribute> NewEmpty() const  override { using return_type = handle<TDF_Attribute>;
    PYBIND11_OVERLOAD_PURE(return_type,TDF_Attribute,NewEmpty,) };

        // protected pure virtual


        // private pure virtual

    };
    class Py_TDataStd_GenericExtString : public TDataStd_GenericExtString{
    public:
        using TDataStd_GenericExtString::TDataStd_GenericExtString;


        // public pure virtual

        handle<TDF_Attribute> NewEmpty() const  override { using return_type = handle<TDF_Attribute>;
    PYBIND11_OVERLOAD_PURE(return_type,TDF_Attribute,NewEmpty,) };

        // protected pure virtual


        // private pure virtual

    };

// classes

    // Class TDataStd from ./opencascade/TDataStd.hxx
    klass = m.attr("TDataStd");

    // default constructor
    register_default_constructor<TDataStd , shared_ptr<TDataStd>>(m,"TDataStd");

    // nested enums

    static_cast<py::class_<TDataStd , shared_ptr<TDataStd>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("IDList_s",
                    (void (*)( NCollection_List<Standard_GUID> &  ) ) static_cast<void (*)( NCollection_List<Standard_GUID> &  ) >(&TDataStd::IDList),
                    R"#(Appends to <anIDList> the list of the attributes IDs of this package. CAUTION: <anIDList> is NOT cleared before use.)#"  , py::arg("anIDList")
          )
        .def_static("Print_s",
                    (Standard_OStream & (*)(  const TDataStd_RealEnum ,  Standard_OStream &  ) ) static_cast<Standard_OStream & (*)(  const TDataStd_RealEnum ,  Standard_OStream &  ) >(&TDataStd::Print),
                    R"#(Prints the name of the real dimension <DIM> as a String on the Stream <S> and returns <S>.)#"  , py::arg("DIM"),  py::arg("S")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class TDataStd_AsciiString from ./opencascade/TDataStd_AsciiString.hxx
    klass = m.attr("TDataStd_AsciiString");


    // nested enums

    static_cast<py::class_<TDataStd_AsciiString ,opencascade::handle<TDataStd_AsciiString>  , TDF_Attribute >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Set",
             (void (TDataStd_AsciiString::*)(  const TCollection_AsciiString &  ) ) static_cast<void (TDataStd_AsciiString::*)(  const TCollection_AsciiString &  ) >(&TDataStd_AsciiString::Set),
             R"#()#"  , py::arg("S")
          )
        .def("SetID",
             (void (TDataStd_AsciiString::*)(  const Standard_GUID &  ) ) static_cast<void (TDataStd_AsciiString::*)(  const Standard_GUID &  ) >(&TDataStd_AsciiString::SetID),
             R"#(Sets the explicit user defined GUID to the attribute.)#"  , py::arg("guid")
          )
        .def("SetID",
             (void (TDataStd_AsciiString::*)() ) static_cast<void (TDataStd_AsciiString::*)() >(&TDataStd_AsciiString::SetID),
             R"#(Sets default GUID for the attribute.)#" 
          )
        .def("IsEmpty",
             (bool (TDataStd_AsciiString::*)() const) static_cast<bool (TDataStd_AsciiString::*)() const>(&TDataStd_AsciiString::IsEmpty),
             R"#()#" 
          )
        .def("Restore",
             (void (TDataStd_AsciiString::*)(  const handle<TDF_Attribute> &  ) ) static_cast<void (TDataStd_AsciiString::*)(  const handle<TDF_Attribute> &  ) >(&TDataStd_AsciiString::Restore),
             R"#()#"  , py::arg("with_")
          )
        .def("NewEmpty",
             (handle<TDF_Attribute> (TDataStd_AsciiString::*)() const) static_cast<handle<TDF_Attribute> (TDataStd_AsciiString::*)() const>(&TDataStd_AsciiString::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (void (TDataStd_AsciiString::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const) static_cast<void (TDataStd_AsciiString::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const>(&TDataStd_AsciiString::Paste),
             R"#()#"  , py::arg("into"),  py::arg("RT")
          )
        .def("Dump",
             (Standard_OStream & (TDataStd_AsciiString::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDataStd_AsciiString::*)( Standard_OStream &  ) const>(&TDataStd_AsciiString::Dump),
             R"#()#"  , py::arg("anOS")
          )
        .def("DumpJson",
             (void (TDataStd_AsciiString::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDataStd_AsciiString::*)( Standard_OStream & ,  int  ) const>(&TDataStd_AsciiString::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("GetID_s",
                    ( const Standard_GUID & (*)() ) static_cast< const Standard_GUID & (*)() >(&TDataStd_AsciiString::GetID),
                    R"#(class methods ============= Returns the GUID of the attribute.)#" 
          )
        .def_static("Set_s",
                    (handle<TDataStd_AsciiString> (*)(  const TDF_Label & ,   const TCollection_AsciiString &  ) ) static_cast<handle<TDataStd_AsciiString> (*)(  const TDF_Label & ,   const TCollection_AsciiString &  ) >(&TDataStd_AsciiString::Set),
                    R"#(Finds, or creates an AsciiString attribute and sets the string. the AsciiString attribute is returned. AsciiString methods ===================)#"  , py::arg("label"),  py::arg("string")
          )
        .def_static("Set_s",
                    (handle<TDataStd_AsciiString> (*)(  const TDF_Label & ,   const Standard_GUID & ,   const TCollection_AsciiString &  ) ) static_cast<handle<TDataStd_AsciiString> (*)(  const TDF_Label & ,   const Standard_GUID & ,   const TCollection_AsciiString &  ) >(&TDataStd_AsciiString::Set),
                    R"#(Finds, or creates, an AsciiString attribute with explicit user defined <guid> and sets <string>. The Name attribute is returned.)#"  , py::arg("label"),  py::arg("guid"),  py::arg("string")
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_AsciiString::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_AsciiString::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Get",
             ( const TCollection_AsciiString & (TDataStd_AsciiString::*)() const) static_cast< const TCollection_AsciiString & (TDataStd_AsciiString::*)() const>(&TDataStd_AsciiString::Get),
             R"#()#"
             
         )
       .def("ID",
             ( const Standard_GUID & (TDataStd_AsciiString::*)() const) static_cast< const Standard_GUID & (TDataStd_AsciiString::*)() const>(&TDataStd_AsciiString::ID),
             R"#()#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_AsciiString::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_AsciiString::*)() const>(&TDataStd_AsciiString::DynamicType),
             R"#()#"
             
         )
;

    // Class TDataStd_BooleanArray from ./opencascade/TDataStd_BooleanArray.hxx
    klass = m.attr("TDataStd_BooleanArray");


    // nested enums

    static_cast<py::class_<TDataStd_BooleanArray ,opencascade::handle<TDataStd_BooleanArray>  , TDF_Attribute >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (TDataStd_BooleanArray::*)(  const int ,   const int  ) ) static_cast<void (TDataStd_BooleanArray::*)(  const int ,   const int  ) >(&TDataStd_BooleanArray::Init),
             R"#(Initialize the inner array with bounds from <lower> to <upper>)#"  , py::arg("lower"),  py::arg("upper")
          )
        .def("SetValue",
             (void (TDataStd_BooleanArray::*)(  const int ,   const bool  ) ) static_cast<void (TDataStd_BooleanArray::*)(  const int ,   const bool  ) >(&TDataStd_BooleanArray::SetValue),
             R"#(Sets the <Index>th element of the array to <Value> OutOfRange exception is raised if <Index> doesn't respect Lower and Upper bounds of the internal array.)#"  , py::arg("index"),  py::arg("value")
          )
        .def("SetID",
             (void (TDataStd_BooleanArray::*)(  const Standard_GUID &  ) ) static_cast<void (TDataStd_BooleanArray::*)(  const Standard_GUID &  ) >(&TDataStd_BooleanArray::SetID),
             R"#(Sets the explicit GUID (user defined) for the attribute.)#"  , py::arg("theGuid")
          )
        .def("SetID",
             (void (TDataStd_BooleanArray::*)() ) static_cast<void (TDataStd_BooleanArray::*)() >(&TDataStd_BooleanArray::SetID),
             R"#(Sets default GUID for the attribute.)#" 
          )
        .def("Value",
             (bool (TDataStd_BooleanArray::*)(  const int  ) const) static_cast<bool (TDataStd_BooleanArray::*)(  const int  ) const>(&TDataStd_BooleanArray::Value),
             R"#(Return the value of the <Index>th element of the array.)#"  , py::arg("Index")
          )
        .def("Lower",
             (int (TDataStd_BooleanArray::*)() const) static_cast<int (TDataStd_BooleanArray::*)() const>(&TDataStd_BooleanArray::Lower),
             R"#(Returns the lower boundary of the array.)#" 
          )
        .def("Upper",
             (int (TDataStd_BooleanArray::*)() const) static_cast<int (TDataStd_BooleanArray::*)() const>(&TDataStd_BooleanArray::Upper),
             R"#(Returns the upper boundary of the array.)#" 
          )
        .def("Length",
             (int (TDataStd_BooleanArray::*)() const) static_cast<int (TDataStd_BooleanArray::*)() const>(&TDataStd_BooleanArray::Length),
             R"#(Returns the number of elements in the array.)#" 
          )
        .def("SetInternalArray",
             (void (TDataStd_BooleanArray::*)(  const handle<NCollection_HArray1<uint8_t>> &  ) ) static_cast<void (TDataStd_BooleanArray::*)(  const handle<NCollection_HArray1<uint8_t>> &  ) >(&TDataStd_BooleanArray::SetInternalArray),
             R"#()#"  , py::arg("values")
          )
        .def("Restore",
             (void (TDataStd_BooleanArray::*)(  const handle<TDF_Attribute> &  ) ) static_cast<void (TDataStd_BooleanArray::*)(  const handle<TDF_Attribute> &  ) >(&TDataStd_BooleanArray::Restore),
             R"#()#"  , py::arg("with_")
          )
        .def("NewEmpty",
             (handle<TDF_Attribute> (TDataStd_BooleanArray::*)() const) static_cast<handle<TDF_Attribute> (TDataStd_BooleanArray::*)() const>(&TDataStd_BooleanArray::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (void (TDataStd_BooleanArray::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const) static_cast<void (TDataStd_BooleanArray::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const>(&TDataStd_BooleanArray::Paste),
             R"#()#"  , py::arg("into"),  py::arg("RT")
          )
        .def("Dump",
             (Standard_OStream & (TDataStd_BooleanArray::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDataStd_BooleanArray::*)( Standard_OStream &  ) const>(&TDataStd_BooleanArray::Dump),
             R"#()#"  , py::arg("OS")
          )
        .def("DumpJson",
             (void (TDataStd_BooleanArray::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDataStd_BooleanArray::*)( Standard_OStream & ,  int  ) const>(&TDataStd_BooleanArray::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("GetID_s",
                    ( const Standard_GUID & (*)() ) static_cast< const Standard_GUID & (*)() >(&TDataStd_BooleanArray::GetID),
                    R"#(Static methods ============== Returns an ID for array.)#" 
          )
        .def_static("Set_s",
                    (handle<TDataStd_BooleanArray> (*)(  const TDF_Label & ,   const int ,   const int  ) ) static_cast<handle<TDataStd_BooleanArray> (*)(  const TDF_Label & ,   const int ,   const int  ) >(&TDataStd_BooleanArray::Set),
                    R"#(Finds or creates an attribute with internal boolean array.)#"  , py::arg("label"),  py::arg("lower"),  py::arg("upper")
          )
        .def_static("Set_s",
                    (handle<TDataStd_BooleanArray> (*)(  const TDF_Label & ,   const Standard_GUID & ,   const int ,   const int  ) ) static_cast<handle<TDataStd_BooleanArray> (*)(  const TDF_Label & ,   const Standard_GUID & ,   const int ,   const int  ) >(&TDataStd_BooleanArray::Set),
                    R"#(Finds or creates an attribute with the array using explicit user defined <guid>.)#"  , py::arg("label"),  py::arg("theGuid"),  py::arg("lower"),  py::arg("upper")
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_BooleanArray::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_BooleanArray::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
        .def("__call__",
             (bool (TDataStd_BooleanArray::*)(  const int  ) const) static_cast<bool (TDataStd_BooleanArray::*)(  const int  ) const>(&TDataStd_BooleanArray::operator()),
             py::is_operator(),
             R"#()#"  , py::arg("Index")
          )
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("InternalArray",
             ( const handle<NCollection_HArray1<uint8_t>> & (TDataStd_BooleanArray::*)() const) static_cast< const handle<NCollection_HArray1<uint8_t>> & (TDataStd_BooleanArray::*)() const>(&TDataStd_BooleanArray::InternalArray),
             R"#()#"
             
         )
       .def("ID",
             ( const Standard_GUID & (TDataStd_BooleanArray::*)() const) static_cast< const Standard_GUID & (TDataStd_BooleanArray::*)() const>(&TDataStd_BooleanArray::ID),
             R"#()#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_BooleanArray::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_BooleanArray::*)() const>(&TDataStd_BooleanArray::DynamicType),
             R"#()#"
             
         )
;

    // Class TDataStd_BooleanList from ./opencascade/TDataStd_BooleanList.hxx
    klass = m.attr("TDataStd_BooleanList");


    // nested enums

    static_cast<py::class_<TDataStd_BooleanList ,opencascade::handle<TDataStd_BooleanList>  , TDF_Attribute >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("IsEmpty",
             (bool (TDataStd_BooleanList::*)() const) static_cast<bool (TDataStd_BooleanList::*)() const>(&TDataStd_BooleanList::IsEmpty),
             R"#()#" 
          )
        .def("Extent",
             (int (TDataStd_BooleanList::*)() const) static_cast<int (TDataStd_BooleanList::*)() const>(&TDataStd_BooleanList::Extent),
             R"#()#" 
          )
        .def("Prepend",
             (void (TDataStd_BooleanList::*)(  const bool  ) ) static_cast<void (TDataStd_BooleanList::*)(  const bool  ) >(&TDataStd_BooleanList::Prepend),
             R"#()#"  , py::arg("value")
          )
        .def("Append",
             (void (TDataStd_BooleanList::*)(  const bool  ) ) static_cast<void (TDataStd_BooleanList::*)(  const bool  ) >(&TDataStd_BooleanList::Append),
             R"#()#"  , py::arg("value")
          )
        .def("Clear",
             (void (TDataStd_BooleanList::*)() ) static_cast<void (TDataStd_BooleanList::*)() >(&TDataStd_BooleanList::Clear),
             R"#()#" 
          )
        .def("First",
             (bool (TDataStd_BooleanList::*)() const) static_cast<bool (TDataStd_BooleanList::*)() const>(&TDataStd_BooleanList::First),
             R"#()#" 
          )
        .def("Last",
             (bool (TDataStd_BooleanList::*)() const) static_cast<bool (TDataStd_BooleanList::*)() const>(&TDataStd_BooleanList::Last),
             R"#()#" 
          )
        .def("InsertBefore",
             (bool (TDataStd_BooleanList::*)(  const int ,   const bool  ) ) static_cast<bool (TDataStd_BooleanList::*)(  const int ,   const bool  ) >(&TDataStd_BooleanList::InsertBefore),
             R"#(Inserts the <value> before the <index> position. The indices start with 1 .. Extent().)#"  , py::arg("index"),  py::arg("before_value")
          )
        .def("InsertAfter",
             (bool (TDataStd_BooleanList::*)(  const int ,   const bool  ) ) static_cast<bool (TDataStd_BooleanList::*)(  const int ,   const bool  ) >(&TDataStd_BooleanList::InsertAfter),
             R"#(Inserts the <value> after the <index> position. The indices start with 1 .. Extent().)#"  , py::arg("index"),  py::arg("after_value")
          )
        .def("Remove",
             (bool (TDataStd_BooleanList::*)(  const int  ) ) static_cast<bool (TDataStd_BooleanList::*)(  const int  ) >(&TDataStd_BooleanList::Remove),
             R"#(Removes a value at <index> position.)#"  , py::arg("index")
          )
        .def("SetID",
             (void (TDataStd_BooleanList::*)(  const Standard_GUID &  ) ) static_cast<void (TDataStd_BooleanList::*)(  const Standard_GUID &  ) >(&TDataStd_BooleanList::SetID),
             R"#(Sets the explicit GUID (user defined) for the attribute.)#"  , py::arg("theGuid")
          )
        .def("SetID",
             (void (TDataStd_BooleanList::*)() ) static_cast<void (TDataStd_BooleanList::*)() >(&TDataStd_BooleanList::SetID),
             R"#(Sets default GUID for the attribute.)#" 
          )
        .def("Restore",
             (void (TDataStd_BooleanList::*)(  const handle<TDF_Attribute> &  ) ) static_cast<void (TDataStd_BooleanList::*)(  const handle<TDF_Attribute> &  ) >(&TDataStd_BooleanList::Restore),
             R"#()#"  , py::arg("With")
          )
        .def("NewEmpty",
             (handle<TDF_Attribute> (TDataStd_BooleanList::*)() const) static_cast<handle<TDF_Attribute> (TDataStd_BooleanList::*)() const>(&TDataStd_BooleanList::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (void (TDataStd_BooleanList::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const) static_cast<void (TDataStd_BooleanList::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const>(&TDataStd_BooleanList::Paste),
             R"#()#"  , py::arg("Into"),  py::arg("RT")
          )
        .def("Dump",
             (Standard_OStream & (TDataStd_BooleanList::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDataStd_BooleanList::*)( Standard_OStream &  ) const>(&TDataStd_BooleanList::Dump),
             R"#()#"  , py::arg("anOS")
          )
        .def("DumpJson",
             (void (TDataStd_BooleanList::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDataStd_BooleanList::*)( Standard_OStream & ,  int  ) const>(&TDataStd_BooleanList::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("GetID_s",
                    ( const Standard_GUID & (*)() ) static_cast< const Standard_GUID & (*)() >(&TDataStd_BooleanList::GetID),
                    R"#(Static methods ============== Returns the ID of the list of booleans attribute.)#" 
          )
        .def_static("Set_s",
                    (handle<TDataStd_BooleanList> (*)(  const TDF_Label &  ) ) static_cast<handle<TDataStd_BooleanList> (*)(  const TDF_Label &  ) >(&TDataStd_BooleanList::Set),
                    R"#(Finds or creates a list of boolean values attribute.)#"  , py::arg("label")
          )
        .def_static("Set_s",
                    (handle<TDataStd_BooleanList> (*)(  const TDF_Label & ,   const Standard_GUID &  ) ) static_cast<handle<TDataStd_BooleanList> (*)(  const TDF_Label & ,   const Standard_GUID &  ) >(&TDataStd_BooleanList::Set),
                    R"#(Finds or creates a list of boolean values attribute with explicit user defined <guid>.)#"  , py::arg("label"),  py::arg("theGuid")
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_BooleanList::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_BooleanList::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("List",
             ( const NCollection_List<uint8_t> & (TDataStd_BooleanList::*)() const) static_cast< const NCollection_List<uint8_t> & (TDataStd_BooleanList::*)() const>(&TDataStd_BooleanList::List),
             R"#(1 - means TRUE, 0 - means FALSE.)#"
             
         )
       .def("ID",
             ( const Standard_GUID & (TDataStd_BooleanList::*)() const) static_cast< const Standard_GUID & (TDataStd_BooleanList::*)() const>(&TDataStd_BooleanList::ID),
             R"#()#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_BooleanList::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_BooleanList::*)() const>(&TDataStd_BooleanList::DynamicType),
             R"#()#"
             
         )
;

    // Class TDataStd_ByteArray from ./opencascade/TDataStd_ByteArray.hxx
    klass = m.attr("TDataStd_ByteArray");


    // nested enums

    static_cast<py::class_<TDataStd_ByteArray ,opencascade::handle<TDataStd_ByteArray>  , TDF_Attribute >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (TDataStd_ByteArray::*)(  const int ,   const int  ) ) static_cast<void (TDataStd_ByteArray::*)(  const int ,   const int  ) >(&TDataStd_ByteArray::Init),
             R"#(Initialize the inner array with bounds from <lower> to <upper>)#"  , py::arg("lower"),  py::arg("upper")
          )
        .def("SetValue",
             (void (TDataStd_ByteArray::*)(  const int ,   const uint8_t  ) ) static_cast<void (TDataStd_ByteArray::*)(  const int ,   const uint8_t  ) >(&TDataStd_ByteArray::SetValue),
             R"#(Sets the <Index>th element of the array to <Value> OutOfRange exception is raised if <Index> doesn't respect Lower and Upper bounds of the internal array.)#"  , py::arg("index"),  py::arg("value")
          )
        .def("SetID",
             (void (TDataStd_ByteArray::*)(  const Standard_GUID &  ) ) static_cast<void (TDataStd_ByteArray::*)(  const Standard_GUID &  ) >(&TDataStd_ByteArray::SetID),
             R"#(Sets the explicit GUID (user defined) for the attribute.)#"  , py::arg("theGuid")
          )
        .def("SetID",
             (void (TDataStd_ByteArray::*)() ) static_cast<void (TDataStd_ByteArray::*)() >(&TDataStd_ByteArray::SetID),
             R"#(Sets default GUID for the attribute.)#" 
          )
        .def("Value",
             (uint8_t (TDataStd_ByteArray::*)(  const int  ) const) static_cast<uint8_t (TDataStd_ByteArray::*)(  const int  ) const>(&TDataStd_ByteArray::Value),
             R"#(Return the value of the <Index>th element of the array.)#"  , py::arg("Index")
          )
        .def("Lower",
             (int (TDataStd_ByteArray::*)() const) static_cast<int (TDataStd_ByteArray::*)() const>(&TDataStd_ByteArray::Lower),
             R"#(Returns the lower boundary of the array.)#" 
          )
        .def("Upper",
             (int (TDataStd_ByteArray::*)() const) static_cast<int (TDataStd_ByteArray::*)() const>(&TDataStd_ByteArray::Upper),
             R"#(Returns the upper boundary of the array.)#" 
          )
        .def("Length",
             (int (TDataStd_ByteArray::*)() const) static_cast<int (TDataStd_ByteArray::*)() const>(&TDataStd_ByteArray::Length),
             R"#(Returns the number of elements in the array.)#" 
          )
        .def("ChangeArray",
             (void (TDataStd_ByteArray::*)(  const handle<NCollection_HArray1<uint8_t>> & ,   const bool  ) ) static_cast<void (TDataStd_ByteArray::*)(  const handle<NCollection_HArray1<uint8_t>> & ,   const bool  ) >(&TDataStd_ByteArray::ChangeArray),
             R"#(Sets the inner array <myValue> of the attribute to <newArray>. If value of <newArray> differs from <myValue>, Backup performed and myValue refers to new instance of HArray1OfInteger that holds <newArray> values. If <isCheckItems> equal True each item of <newArray> will be checked with each item of <myValue> for coincidence (to avoid backup).)#"  , py::arg("newArray"),  py::arg("isCheckItems")=static_cast< const bool>(true)
          )
        .def("GetDelta",
             (bool (TDataStd_ByteArray::*)() const) static_cast<bool (TDataStd_ByteArray::*)() const>(&TDataStd_ByteArray::GetDelta),
             R"#()#" 
          )
        .def("SetDelta",
             (void (TDataStd_ByteArray::*)(  const bool  ) ) static_cast<void (TDataStd_ByteArray::*)(  const bool  ) >(&TDataStd_ByteArray::SetDelta),
             R"#(for internal use only!)#"  , py::arg("isDelta")
          )
        .def("Restore",
             (void (TDataStd_ByteArray::*)(  const handle<TDF_Attribute> &  ) ) static_cast<void (TDataStd_ByteArray::*)(  const handle<TDF_Attribute> &  ) >(&TDataStd_ByteArray::Restore),
             R"#()#"  , py::arg("with_")
          )
        .def("NewEmpty",
             (handle<TDF_Attribute> (TDataStd_ByteArray::*)() const) static_cast<handle<TDF_Attribute> (TDataStd_ByteArray::*)() const>(&TDataStd_ByteArray::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (void (TDataStd_ByteArray::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const) static_cast<void (TDataStd_ByteArray::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const>(&TDataStd_ByteArray::Paste),
             R"#()#"  , py::arg("into"),  py::arg("RT")
          )
        .def("Dump",
             (Standard_OStream & (TDataStd_ByteArray::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDataStd_ByteArray::*)( Standard_OStream &  ) const>(&TDataStd_ByteArray::Dump),
             R"#()#"  , py::arg("OS")
          )
        .def("DeltaOnModification",
             (handle<TDF_DeltaOnModification> (TDataStd_ByteArray::*)(  const handle<TDF_Attribute> &  ) const) static_cast<handle<TDF_DeltaOnModification> (TDataStd_ByteArray::*)(  const handle<TDF_Attribute> &  ) const>(&TDataStd_ByteArray::DeltaOnModification),
             R"#(Makes a DeltaOnModification between <me> and <anOldAttribute>.)#"  , py::arg("anOldAttribute")
          )
        .def("DumpJson",
             (void (TDataStd_ByteArray::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDataStd_ByteArray::*)( Standard_OStream & ,  int  ) const>(&TDataStd_ByteArray::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_ByteArray::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_ByteArray::get_type_descriptor),
                    R"#()#" 
          )
        .def_static("GetID_s",
                    ( const Standard_GUID & (*)() ) static_cast< const Standard_GUID & (*)() >(&TDataStd_ByteArray::GetID),
                    R"#(Static methods ============== Returns an ID for array.)#" 
          )
        .def_static("Set_s",
                    (handle<TDataStd_ByteArray> (*)(  const TDF_Label & ,   const int ,   const int ,   const bool  ) ) static_cast<handle<TDataStd_ByteArray> (*)(  const TDF_Label & ,   const int ,   const int ,   const bool  ) >(&TDataStd_ByteArray::Set),
                    R"#(Finds or creates an attribute with the array on the specified label. If <isDelta> == False, DefaultDeltaOnModification is used. If <isDelta> == True, DeltaOnModification of the current attribute is used. If attribute is already set, all input parameters are refused and the found attribute is returned.)#"  , py::arg("label"),  py::arg("lower"),  py::arg("upper"),  py::arg("isDelta")=static_cast< const bool>(false)
          )
        .def_static("Set_s",
                    (handle<TDataStd_ByteArray> (*)(  const TDF_Label & ,   const Standard_GUID & ,   const int ,   const int ,   const bool  ) ) static_cast<handle<TDataStd_ByteArray> (*)(  const TDF_Label & ,   const Standard_GUID & ,   const int ,   const int ,   const bool  ) >(&TDataStd_ByteArray::Set),
                    R"#(Finds or creates an attribute with byte array and explicit user defined <guid> on the specified label.)#"  , py::arg("label"),  py::arg("theGuid"),  py::arg("lower"),  py::arg("upper"),  py::arg("isDelta")=static_cast< const bool>(false)
          )
    // static methods using call by reference i.s.o. return
    // operators
        .def("__call__",
             (uint8_t (TDataStd_ByteArray::*)(  const int  ) const) static_cast<uint8_t (TDataStd_ByteArray::*)(  const int  ) const>(&TDataStd_ByteArray::operator()),
             py::is_operator(),
             R"#()#"  , py::arg("Index")
          )
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_ByteArray::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_ByteArray::*)() const>(&TDataStd_ByteArray::DynamicType),
             R"#()#"
             
         )
       .def("InternalArray",
             ( const handle<NCollection_HArray1<uint8_t>> & (TDataStd_ByteArray::*)() const) static_cast< const handle<NCollection_HArray1<uint8_t>> & (TDataStd_ByteArray::*)() const>(&TDataStd_ByteArray::InternalArray),
             R"#()#"
             
         )
       .def("ID",
             ( const Standard_GUID & (TDataStd_ByteArray::*)() const) static_cast< const Standard_GUID & (TDataStd_ByteArray::*)() const>(&TDataStd_ByteArray::ID),
             R"#()#"
             
         )
;

    // Class TDataStd_ChildNodeIterator from ./opencascade/TDataStd_ChildNodeIterator.hxx
    klass = m.attr("TDataStd_ChildNodeIterator");


    // nested enums

    static_cast<py::class_<TDataStd_ChildNodeIterator , shared_ptr<TDataStd_ChildNodeIterator>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<TDataStd_TreeNode> &, const bool >()  , py::arg("aTreeNode"),  py::arg("allLevels")=static_cast< const bool>(false) )
    // custom constructors
    // methods
        .def("Initialize",
             (void (TDataStd_ChildNodeIterator::*)(  const handle<TDataStd_TreeNode> & ,   const bool  ) ) static_cast<void (TDataStd_ChildNodeIterator::*)(  const handle<TDataStd_TreeNode> & ,   const bool  ) >(&TDataStd_ChildNodeIterator::Initialize),
             R"#(Initializes the iteration on the Children Step of the given Step. If <allLevels> option is set to true, it explores not only the first, but all the sub Step levels.)#"  , py::arg("aTreeNode"),  py::arg("allLevels")=static_cast< const bool>(false)
          )
        .def("More",
             (bool (TDataStd_ChildNodeIterator::*)() const) static_cast<bool (TDataStd_ChildNodeIterator::*)() const>(&TDataStd_ChildNodeIterator::More),
             R"#(Returns True if there is a current Item in the iteration.)#" 
          )
        .def("Next",
             (void (TDataStd_ChildNodeIterator::*)() ) static_cast<void (TDataStd_ChildNodeIterator::*)() >(&TDataStd_ChildNodeIterator::Next),
             R"#(Move to the next Item)#" 
          )
        .def("NextBrother",
             (void (TDataStd_ChildNodeIterator::*)() ) static_cast<void (TDataStd_ChildNodeIterator::*)() >(&TDataStd_ChildNodeIterator::NextBrother),
             R"#(Move to the next Brother. If there is none, go up etc. This method is interesting only with "allLevels" behavior, because it avoids to explore the current Step ChildStepren.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<TDataStd_TreeNode> & (TDataStd_ChildNodeIterator::*)() const) static_cast< const handle<TDataStd_TreeNode> & (TDataStd_ChildNodeIterator::*)() const>(&TDataStd_ChildNodeIterator::Value),
             R"#(Returns the current item; a null Step if there is no one.)#"
             
         )
;

    // Class TDataStd_Current from ./opencascade/TDataStd_Current.hxx
    klass = m.attr("TDataStd_Current");


    // nested enums

    static_cast<py::class_<TDataStd_Current ,opencascade::handle<TDataStd_Current>  , TDF_Attribute >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetLabel",
             (void (TDataStd_Current::*)(  const TDF_Label &  ) ) static_cast<void (TDataStd_Current::*)(  const TDF_Label &  ) >(&TDataStd_Current::SetLabel),
             R"#()#"  , py::arg("current")
          )
        .def("GetLabel",
             (TDF_Label (TDataStd_Current::*)() const) static_cast<TDF_Label (TDataStd_Current::*)() const>(&TDataStd_Current::GetLabel),
             R"#()#" 
          )
        .def("Restore",
             (void (TDataStd_Current::*)(  const handle<TDF_Attribute> &  ) ) static_cast<void (TDataStd_Current::*)(  const handle<TDF_Attribute> &  ) >(&TDataStd_Current::Restore),
             R"#()#"  , py::arg("With")
          )
        .def("NewEmpty",
             (handle<TDF_Attribute> (TDataStd_Current::*)() const) static_cast<handle<TDF_Attribute> (TDataStd_Current::*)() const>(&TDataStd_Current::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (void (TDataStd_Current::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const) static_cast<void (TDataStd_Current::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const>(&TDataStd_Current::Paste),
             R"#()#"  , py::arg("Into"),  py::arg("RT")
          )
        .def("Dump",
             (Standard_OStream & (TDataStd_Current::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDataStd_Current::*)( Standard_OStream &  ) const>(&TDataStd_Current::Dump),
             R"#()#"  , py::arg("anOS")
          )
        .def("DumpJson",
             (void (TDataStd_Current::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDataStd_Current::*)( Standard_OStream & ,  int  ) const>(&TDataStd_Current::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("GetID_s",
                    ( const Standard_GUID & (*)() ) static_cast< const Standard_GUID & (*)() >(&TDataStd_Current::GetID),
                    R"#(class methods =============)#" 
          )
        .def_static("Set_s",
                    (void (*)(  const TDF_Label &  ) ) static_cast<void (*)(  const TDF_Label &  ) >(&TDataStd_Current::Set),
                    R"#(Set <L> as current of <L> Framework.)#"  , py::arg("L")
          )
        .def_static("Get_s",
                    (TDF_Label (*)(  const TDF_Label &  ) ) static_cast<TDF_Label (*)(  const TDF_Label &  ) >(&TDataStd_Current::Get),
                    R"#(returns current of <acces> Framework. raise if (!Has))#"  , py::arg("acces")
          )
        .def_static("Has_s",
                    (bool (*)(  const TDF_Label &  ) ) static_cast<bool (*)(  const TDF_Label &  ) >(&TDataStd_Current::Has),
                    R"#(returns True if a current label is managed in <acces> Framework. class methods =============)#"  , py::arg("acces")
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_Current::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_Current::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("ID",
             ( const Standard_GUID & (TDataStd_Current::*)() const) static_cast< const Standard_GUID & (TDataStd_Current::*)() const>(&TDataStd_Current::ID),
             R"#()#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_Current::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_Current::*)() const>(&TDataStd_Current::DynamicType),
             R"#()#"
             
         )
;

    // Class TDataStd_DeltaOnModificationOfByteArray from ./opencascade/TDataStd_DeltaOnModificationOfByteArray.hxx
    klass = m.attr("TDataStd_DeltaOnModificationOfByteArray");


    // nested enums

    static_cast<py::class_<TDataStd_DeltaOnModificationOfByteArray ,opencascade::handle<TDataStd_DeltaOnModificationOfByteArray>  , TDF_DeltaOnModification >>(klass)
    // constructors
        .def(py::init<  const handle<TDataStd_ByteArray> & >()  , py::arg("Arr") )
    // custom constructors
    // methods
        .def("Apply",
             (void (TDataStd_DeltaOnModificationOfByteArray::*)() ) static_cast<void (TDataStd_DeltaOnModificationOfByteArray::*)() >(&TDataStd_DeltaOnModificationOfByteArray::Apply),
             R"#(Applies the delta to the attribute.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_DeltaOnModificationOfByteArray::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_DeltaOnModificationOfByteArray::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_DeltaOnModificationOfByteArray::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_DeltaOnModificationOfByteArray::*)() const>(&TDataStd_DeltaOnModificationOfByteArray::DynamicType),
             R"#()#"
             
         )
;

    // Class TDataStd_DeltaOnModificationOfExtStringArray from ./opencascade/TDataStd_DeltaOnModificationOfExtStringArray.hxx
    klass = m.attr("TDataStd_DeltaOnModificationOfExtStringArray");


    // nested enums

    static_cast<py::class_<TDataStd_DeltaOnModificationOfExtStringArray ,opencascade::handle<TDataStd_DeltaOnModificationOfExtStringArray>  , TDF_DeltaOnModification >>(klass)
    // constructors
        .def(py::init<  const handle<TDataStd_ExtStringArray> & >()  , py::arg("Arr") )
    // custom constructors
    // methods
        .def("Apply",
             (void (TDataStd_DeltaOnModificationOfExtStringArray::*)() ) static_cast<void (TDataStd_DeltaOnModificationOfExtStringArray::*)() >(&TDataStd_DeltaOnModificationOfExtStringArray::Apply),
             R"#(Applies the delta to the attribute.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_DeltaOnModificationOfExtStringArray::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_DeltaOnModificationOfExtStringArray::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_DeltaOnModificationOfExtStringArray::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_DeltaOnModificationOfExtStringArray::*)() const>(&TDataStd_DeltaOnModificationOfExtStringArray::DynamicType),
             R"#()#"
             
         )
;

    // Class TDataStd_DeltaOnModificationOfIntArray from ./opencascade/TDataStd_DeltaOnModificationOfIntArray.hxx
    klass = m.attr("TDataStd_DeltaOnModificationOfIntArray");


    // nested enums

    static_cast<py::class_<TDataStd_DeltaOnModificationOfIntArray ,opencascade::handle<TDataStd_DeltaOnModificationOfIntArray>  , TDF_DeltaOnModification >>(klass)
    // constructors
        .def(py::init<  const handle<TDataStd_IntegerArray> & >()  , py::arg("Arr") )
    // custom constructors
    // methods
        .def("Apply",
             (void (TDataStd_DeltaOnModificationOfIntArray::*)() ) static_cast<void (TDataStd_DeltaOnModificationOfIntArray::*)() >(&TDataStd_DeltaOnModificationOfIntArray::Apply),
             R"#(Applies the delta to the attribute.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_DeltaOnModificationOfIntArray::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_DeltaOnModificationOfIntArray::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_DeltaOnModificationOfIntArray::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_DeltaOnModificationOfIntArray::*)() const>(&TDataStd_DeltaOnModificationOfIntArray::DynamicType),
             R"#()#"
             
         )
;

    // Class TDataStd_DeltaOnModificationOfIntPackedMap from ./opencascade/TDataStd_DeltaOnModificationOfIntPackedMap.hxx
    klass = m.attr("TDataStd_DeltaOnModificationOfIntPackedMap");


    // nested enums

    static_cast<py::class_<TDataStd_DeltaOnModificationOfIntPackedMap ,opencascade::handle<TDataStd_DeltaOnModificationOfIntPackedMap>  , TDF_DeltaOnModification >>(klass)
    // constructors
        .def(py::init<  const handle<TDataStd_IntPackedMap> & >()  , py::arg("Arr") )
    // custom constructors
    // methods
        .def("Apply",
             (void (TDataStd_DeltaOnModificationOfIntPackedMap::*)() ) static_cast<void (TDataStd_DeltaOnModificationOfIntPackedMap::*)() >(&TDataStd_DeltaOnModificationOfIntPackedMap::Apply),
             R"#(Applies the delta to the attribute.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_DeltaOnModificationOfIntPackedMap::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_DeltaOnModificationOfIntPackedMap::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_DeltaOnModificationOfIntPackedMap::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_DeltaOnModificationOfIntPackedMap::*)() const>(&TDataStd_DeltaOnModificationOfIntPackedMap::DynamicType),
             R"#()#"
             
         )
;

    // Class TDataStd_DeltaOnModificationOfRealArray from ./opencascade/TDataStd_DeltaOnModificationOfRealArray.hxx
    klass = m.attr("TDataStd_DeltaOnModificationOfRealArray");


    // nested enums

    static_cast<py::class_<TDataStd_DeltaOnModificationOfRealArray ,opencascade::handle<TDataStd_DeltaOnModificationOfRealArray>  , TDF_DeltaOnModification >>(klass)
    // constructors
        .def(py::init<  const handle<TDataStd_RealArray> & >()  , py::arg("Arr") )
    // custom constructors
    // methods
        .def("Apply",
             (void (TDataStd_DeltaOnModificationOfRealArray::*)() ) static_cast<void (TDataStd_DeltaOnModificationOfRealArray::*)() >(&TDataStd_DeltaOnModificationOfRealArray::Apply),
             R"#(Applies the delta to the attribute.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_DeltaOnModificationOfRealArray::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_DeltaOnModificationOfRealArray::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_DeltaOnModificationOfRealArray::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_DeltaOnModificationOfRealArray::*)() const>(&TDataStd_DeltaOnModificationOfRealArray::DynamicType),
             R"#()#"
             
         )
;

    // Class TDataStd_Expression from ./opencascade/TDataStd_Expression.hxx
    klass = m.attr("TDataStd_Expression");


    // nested enums

    static_cast<py::class_<TDataStd_Expression ,opencascade::handle<TDataStd_Expression>  , TDF_Attribute >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Name",
             (TCollection_ExtendedString (TDataStd_Expression::*)() const) static_cast<TCollection_ExtendedString (TDataStd_Expression::*)() const>(&TDataStd_Expression::Name),
             R"#(build and return the expression name)#" 
          )
        .def("SetExpression",
             (void (TDataStd_Expression::*)(  const TCollection_ExtendedString &  ) ) static_cast<void (TDataStd_Expression::*)(  const TCollection_ExtendedString &  ) >(&TDataStd_Expression::SetExpression),
             R"#()#"  , py::arg("E")
          )
        .def("Restore",
             (void (TDataStd_Expression::*)(  const handle<TDF_Attribute> &  ) ) static_cast<void (TDataStd_Expression::*)(  const handle<TDF_Attribute> &  ) >(&TDataStd_Expression::Restore),
             R"#()#"  , py::arg("With")
          )
        .def("NewEmpty",
             (handle<TDF_Attribute> (TDataStd_Expression::*)() const) static_cast<handle<TDF_Attribute> (TDataStd_Expression::*)() const>(&TDataStd_Expression::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (void (TDataStd_Expression::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const) static_cast<void (TDataStd_Expression::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const>(&TDataStd_Expression::Paste),
             R"#()#"  , py::arg("Into"),  py::arg("RT")
          )
        .def("Dump",
             (Standard_OStream & (TDataStd_Expression::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDataStd_Expression::*)( Standard_OStream &  ) const>(&TDataStd_Expression::Dump),
             R"#()#"  , py::arg("anOS")
          )
        .def("DumpJson",
             (void (TDataStd_Expression::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDataStd_Expression::*)( Standard_OStream & ,  int  ) const>(&TDataStd_Expression::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("GetID_s",
                    ( const Standard_GUID & (*)() ) static_cast< const Standard_GUID & (*)() >(&TDataStd_Expression::GetID),
                    R"#(class methods =============)#" 
          )
        .def_static("Set_s",
                    (handle<TDataStd_Expression> (*)(  const TDF_Label &  ) ) static_cast<handle<TDataStd_Expression> (*)(  const TDF_Label &  ) >(&TDataStd_Expression::Set),
                    R"#(Find, or create, an Expression attribute. Expressionmethods ============)#"  , py::arg("label")
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_Expression::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_Expression::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("GetExpression",
             ( const TCollection_ExtendedString & (TDataStd_Expression::*)() const) static_cast< const TCollection_ExtendedString & (TDataStd_Expression::*)() const>(&TDataStd_Expression::GetExpression),
             R"#()#"
             
         )
       .def("GetVariables",
             (NCollection_List<handle<TDF_Attribute>> & (TDataStd_Expression::*)() ) static_cast<NCollection_List<handle<TDF_Attribute>> & (TDataStd_Expression::*)() >(&TDataStd_Expression::GetVariables),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("ID",
             ( const Standard_GUID & (TDataStd_Expression::*)() const) static_cast< const Standard_GUID & (TDataStd_Expression::*)() const>(&TDataStd_Expression::ID),
             R"#()#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_Expression::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_Expression::*)() const>(&TDataStd_Expression::DynamicType),
             R"#()#"
             
         )
;

    // Class TDataStd_ExtStringArray from ./opencascade/TDataStd_ExtStringArray.hxx
    klass = m.attr("TDataStd_ExtStringArray");


    // nested enums

    static_cast<py::class_<TDataStd_ExtStringArray ,opencascade::handle<TDataStd_ExtStringArray>  , TDF_Attribute >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (TDataStd_ExtStringArray::*)(  const int ,   const int  ) ) static_cast<void (TDataStd_ExtStringArray::*)(  const int ,   const int  ) >(&TDataStd_ExtStringArray::Init),
             R"#(Initializes the inner array with bounds from <lower> to <upper>)#"  , py::arg("lower"),  py::arg("upper")
          )
        .def("SetValue",
             (void (TDataStd_ExtStringArray::*)(  const int ,   const TCollection_ExtendedString &  ) ) static_cast<void (TDataStd_ExtStringArray::*)(  const int ,   const TCollection_ExtendedString &  ) >(&TDataStd_ExtStringArray::SetValue),
             R"#(Sets the <Index>th element of the array to <Value> OutOfRange exception is raised if <Index> doesn't respect Lower and Upper bounds of the internal array.)#"  , py::arg("Index"),  py::arg("Value")
          )
        .def("SetID",
             (void (TDataStd_ExtStringArray::*)(  const Standard_GUID &  ) ) static_cast<void (TDataStd_ExtStringArray::*)(  const Standard_GUID &  ) >(&TDataStd_ExtStringArray::SetID),
             R"#(Sets the explicit GUID (user defined) for the attribute.)#"  , py::arg("theGuid")
          )
        .def("SetID",
             (void (TDataStd_ExtStringArray::*)() ) static_cast<void (TDataStd_ExtStringArray::*)() >(&TDataStd_ExtStringArray::SetID),
             R"#(Sets default GUID for the attribute.)#" 
          )
        .def("Value",
             ( const TCollection_ExtendedString & (TDataStd_ExtStringArray::*)(  const int  ) const) static_cast< const TCollection_ExtendedString & (TDataStd_ExtStringArray::*)(  const int  ) const>(&TDataStd_ExtStringArray::Value),
             R"#(Returns the value of the <Index>th element of the array)#"  , py::arg("Index")
          )
        .def("Lower",
             (int (TDataStd_ExtStringArray::*)() const) static_cast<int (TDataStd_ExtStringArray::*)() const>(&TDataStd_ExtStringArray::Lower),
             R"#(Return the lower bound.)#" 
          )
        .def("Upper",
             (int (TDataStd_ExtStringArray::*)() const) static_cast<int (TDataStd_ExtStringArray::*)() const>(&TDataStd_ExtStringArray::Upper),
             R"#(Return the upper bound)#" 
          )
        .def("Length",
             (int (TDataStd_ExtStringArray::*)() const) static_cast<int (TDataStd_ExtStringArray::*)() const>(&TDataStd_ExtStringArray::Length),
             R"#(Return the number of elements of <me>.)#" 
          )
        .def("ChangeArray",
             (void (TDataStd_ExtStringArray::*)(  const handle<NCollection_HArray1<TCollection_ExtendedString>> & ,   const bool  ) ) static_cast<void (TDataStd_ExtStringArray::*)(  const handle<NCollection_HArray1<TCollection_ExtendedString>> & ,   const bool  ) >(&TDataStd_ExtStringArray::ChangeArray),
             R"#(Sets the inner array <myValue> of the ExtStringArray attribute to <newArray>. If value of <newArray> differs from <myValue>, Backup performed and myValue refers to new instance of HArray1OfExtendedString that holds <newArray> values If <isCheckItems> equal True each item of <newArray> will be checked with each item of <myValue> for coincidence (to avoid backup).)#"  , py::arg("newArray"),  py::arg("isCheckItems")=static_cast< const bool>(true)
          )
        .def("GetDelta",
             (bool (TDataStd_ExtStringArray::*)() const) static_cast<bool (TDataStd_ExtStringArray::*)() const>(&TDataStd_ExtStringArray::GetDelta),
             R"#()#" 
          )
        .def("SetDelta",
             (void (TDataStd_ExtStringArray::*)(  const bool  ) ) static_cast<void (TDataStd_ExtStringArray::*)(  const bool  ) >(&TDataStd_ExtStringArray::SetDelta),
             R"#(for internal use only!)#"  , py::arg("isDelta")
          )
        .def("Restore",
             (void (TDataStd_ExtStringArray::*)(  const handle<TDF_Attribute> &  ) ) static_cast<void (TDataStd_ExtStringArray::*)(  const handle<TDF_Attribute> &  ) >(&TDataStd_ExtStringArray::Restore),
             R"#()#"  , py::arg("With")
          )
        .def("NewEmpty",
             (handle<TDF_Attribute> (TDataStd_ExtStringArray::*)() const) static_cast<handle<TDF_Attribute> (TDataStd_ExtStringArray::*)() const>(&TDataStd_ExtStringArray::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (void (TDataStd_ExtStringArray::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const) static_cast<void (TDataStd_ExtStringArray::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const>(&TDataStd_ExtStringArray::Paste),
             R"#()#"  , py::arg("Into"),  py::arg("RT")
          )
        .def("Dump",
             (Standard_OStream & (TDataStd_ExtStringArray::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDataStd_ExtStringArray::*)( Standard_OStream &  ) const>(&TDataStd_ExtStringArray::Dump),
             R"#()#"  , py::arg("anOS")
          )
        .def("DeltaOnModification",
             (handle<TDF_DeltaOnModification> (TDataStd_ExtStringArray::*)(  const handle<TDF_Attribute> &  ) const) static_cast<handle<TDF_DeltaOnModification> (TDataStd_ExtStringArray::*)(  const handle<TDF_Attribute> &  ) const>(&TDataStd_ExtStringArray::DeltaOnModification),
             R"#(Makes a DeltaOnModification between <me> and <anOldAttribute>.)#"  , py::arg("anOldAttribute")
          )
        .def("DumpJson",
             (void (TDataStd_ExtStringArray::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDataStd_ExtStringArray::*)( Standard_OStream & ,  int  ) const>(&TDataStd_ExtStringArray::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_ExtStringArray::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_ExtStringArray::get_type_descriptor),
                    R"#()#" 
          )
        .def_static("GetID_s",
                    ( const Standard_GUID & (*)() ) static_cast< const Standard_GUID & (*)() >(&TDataStd_ExtStringArray::GetID),
                    R"#(class methods ============= Returns the GUID for the attribute.)#" 
          )
        .def_static("Set_s",
                    (handle<TDataStd_ExtStringArray> (*)(  const TDF_Label & ,   const int ,   const int ,   const bool  ) ) static_cast<handle<TDataStd_ExtStringArray> (*)(  const TDF_Label & ,   const int ,   const int ,   const bool  ) >(&TDataStd_ExtStringArray::Set),
                    R"#(Finds, or creates, an ExtStringArray attribute with <lower> and <upper> bounds on the specified label. If <isDelta> == False, DefaultDeltaOnModification is used. If <isDelta> == True, DeltaOnModification of the current attribute is used. If attribute is already set, all input parameters are refused and the found attribute is returned.)#"  , py::arg("label"),  py::arg("lower"),  py::arg("upper"),  py::arg("isDelta")=static_cast< const bool>(false)
          )
        .def_static("Set_s",
                    (handle<TDataStd_ExtStringArray> (*)(  const TDF_Label & ,   const Standard_GUID & ,   const int ,   const int ,   const bool  ) ) static_cast<handle<TDataStd_ExtStringArray> (*)(  const TDF_Label & ,   const Standard_GUID & ,   const int ,   const int ,   const bool  ) >(&TDataStd_ExtStringArray::Set),
                    R"#(Finds, or creates, an ExtStringArray attribute with explicit user defined <guid>. The ExtStringArray attribute is returned.)#"  , py::arg("label"),  py::arg("theGuid"),  py::arg("lower"),  py::arg("upper"),  py::arg("isDelta")=static_cast< const bool>(false)
          )
    // static methods using call by reference i.s.o. return
    // operators
        .def("__call__",
             ( const TCollection_ExtendedString & (TDataStd_ExtStringArray::*)(  const int  ) const) static_cast< const TCollection_ExtendedString & (TDataStd_ExtStringArray::*)(  const int  ) const>(&TDataStd_ExtStringArray::operator()),
             py::is_operator(),
             R"#()#"  , py::arg("Index")
          )
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_ExtStringArray::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_ExtStringArray::*)() const>(&TDataStd_ExtStringArray::DynamicType),
             R"#()#"
             
         )
       .def("Array",
             ( const handle<NCollection_HArray1<TCollection_ExtendedString>> & (TDataStd_ExtStringArray::*)() const) static_cast< const handle<NCollection_HArray1<TCollection_ExtendedString>> & (TDataStd_ExtStringArray::*)() const>(&TDataStd_ExtStringArray::Array),
             R"#(Return the inner array of the ExtStringArray attribute)#"
             
         )
       .def("ID",
             ( const Standard_GUID & (TDataStd_ExtStringArray::*)() const) static_cast< const Standard_GUID & (TDataStd_ExtStringArray::*)() const>(&TDataStd_ExtStringArray::ID),
             R"#()#"
             
         )
;

    // Class TDataStd_ExtStringList from ./opencascade/TDataStd_ExtStringList.hxx
    klass = m.attr("TDataStd_ExtStringList");


    // nested enums

    static_cast<py::class_<TDataStd_ExtStringList ,opencascade::handle<TDataStd_ExtStringList>  , TDF_Attribute >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("IsEmpty",
             (bool (TDataStd_ExtStringList::*)() const) static_cast<bool (TDataStd_ExtStringList::*)() const>(&TDataStd_ExtStringList::IsEmpty),
             R"#()#" 
          )
        .def("Extent",
             (int (TDataStd_ExtStringList::*)() const) static_cast<int (TDataStd_ExtStringList::*)() const>(&TDataStd_ExtStringList::Extent),
             R"#()#" 
          )
        .def("Prepend",
             (void (TDataStd_ExtStringList::*)(  const TCollection_ExtendedString &  ) ) static_cast<void (TDataStd_ExtStringList::*)(  const TCollection_ExtendedString &  ) >(&TDataStd_ExtStringList::Prepend),
             R"#()#"  , py::arg("value")
          )
        .def("Append",
             (void (TDataStd_ExtStringList::*)(  const TCollection_ExtendedString &  ) ) static_cast<void (TDataStd_ExtStringList::*)(  const TCollection_ExtendedString &  ) >(&TDataStd_ExtStringList::Append),
             R"#()#"  , py::arg("value")
          )
        .def("SetID",
             (void (TDataStd_ExtStringList::*)(  const Standard_GUID &  ) ) static_cast<void (TDataStd_ExtStringList::*)(  const Standard_GUID &  ) >(&TDataStd_ExtStringList::SetID),
             R"#(Sets the explicit GUID (user defined) for the attribute.)#"  , py::arg("theGuid")
          )
        .def("SetID",
             (void (TDataStd_ExtStringList::*)() ) static_cast<void (TDataStd_ExtStringList::*)() >(&TDataStd_ExtStringList::SetID),
             R"#(Sets default GUID for the attribute.)#" 
          )
        .def("InsertBefore",
             (bool (TDataStd_ExtStringList::*)(  const TCollection_ExtendedString & ,   const TCollection_ExtendedString &  ) ) static_cast<bool (TDataStd_ExtStringList::*)(  const TCollection_ExtendedString & ,   const TCollection_ExtendedString &  ) >(&TDataStd_ExtStringList::InsertBefore),
             R"#(Inserts the <value> before the first meet of <before_value>.)#"  , py::arg("value"),  py::arg("before_value")
          )
        .def("InsertBefore",
             (bool (TDataStd_ExtStringList::*)(  const int ,   const TCollection_ExtendedString &  ) ) static_cast<bool (TDataStd_ExtStringList::*)(  const int ,   const TCollection_ExtendedString &  ) >(&TDataStd_ExtStringList::InsertBefore),
             R"#(Inserts the <value> before the <index> position. The indices start with 1 .. Extent().)#"  , py::arg("index"),  py::arg("before_value")
          )
        .def("InsertAfter",
             (bool (TDataStd_ExtStringList::*)(  const TCollection_ExtendedString & ,   const TCollection_ExtendedString &  ) ) static_cast<bool (TDataStd_ExtStringList::*)(  const TCollection_ExtendedString & ,   const TCollection_ExtendedString &  ) >(&TDataStd_ExtStringList::InsertAfter),
             R"#(Inserts the <value> after the first meet of <after_value>.)#"  , py::arg("value"),  py::arg("after_value")
          )
        .def("InsertAfter",
             (bool (TDataStd_ExtStringList::*)(  const int ,   const TCollection_ExtendedString &  ) ) static_cast<bool (TDataStd_ExtStringList::*)(  const int ,   const TCollection_ExtendedString &  ) >(&TDataStd_ExtStringList::InsertAfter),
             R"#(Inserts the <value> after the <index> position. The indices start with 1 .. Extent().)#"  , py::arg("index"),  py::arg("after_value")
          )
        .def("Remove",
             (bool (TDataStd_ExtStringList::*)(  const TCollection_ExtendedString &  ) ) static_cast<bool (TDataStd_ExtStringList::*)(  const TCollection_ExtendedString &  ) >(&TDataStd_ExtStringList::Remove),
             R"#(Removes the first meet of the <value>.)#"  , py::arg("value")
          )
        .def("Remove",
             (bool (TDataStd_ExtStringList::*)(  const int  ) ) static_cast<bool (TDataStd_ExtStringList::*)(  const int  ) >(&TDataStd_ExtStringList::Remove),
             R"#(Removes a value at <index> position.)#"  , py::arg("index")
          )
        .def("Clear",
             (void (TDataStd_ExtStringList::*)() ) static_cast<void (TDataStd_ExtStringList::*)() >(&TDataStd_ExtStringList::Clear),
             R"#()#" 
          )
        .def("Restore",
             (void (TDataStd_ExtStringList::*)(  const handle<TDF_Attribute> &  ) ) static_cast<void (TDataStd_ExtStringList::*)(  const handle<TDF_Attribute> &  ) >(&TDataStd_ExtStringList::Restore),
             R"#()#"  , py::arg("With")
          )
        .def("NewEmpty",
             (handle<TDF_Attribute> (TDataStd_ExtStringList::*)() const) static_cast<handle<TDF_Attribute> (TDataStd_ExtStringList::*)() const>(&TDataStd_ExtStringList::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (void (TDataStd_ExtStringList::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const) static_cast<void (TDataStd_ExtStringList::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const>(&TDataStd_ExtStringList::Paste),
             R"#()#"  , py::arg("Into"),  py::arg("RT")
          )
        .def("Dump",
             (Standard_OStream & (TDataStd_ExtStringList::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDataStd_ExtStringList::*)( Standard_OStream &  ) const>(&TDataStd_ExtStringList::Dump),
             R"#()#"  , py::arg("anOS")
          )
        .def("DumpJson",
             (void (TDataStd_ExtStringList::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDataStd_ExtStringList::*)( Standard_OStream & ,  int  ) const>(&TDataStd_ExtStringList::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("GetID_s",
                    ( const Standard_GUID & (*)() ) static_cast< const Standard_GUID & (*)() >(&TDataStd_ExtStringList::GetID),
                    R"#(Static methods ============== Returns the ID of the list of strings attribute.)#" 
          )
        .def_static("Set_s",
                    (handle<TDataStd_ExtStringList> (*)(  const TDF_Label &  ) ) static_cast<handle<TDataStd_ExtStringList> (*)(  const TDF_Label &  ) >(&TDataStd_ExtStringList::Set),
                    R"#(Finds or creates a list of string values attribute with explicit user defined <guid>.)#"  , py::arg("label")
          )
        .def_static("Set_s",
                    (handle<TDataStd_ExtStringList> (*)(  const TDF_Label & ,   const Standard_GUID &  ) ) static_cast<handle<TDataStd_ExtStringList> (*)(  const TDF_Label & ,   const Standard_GUID &  ) >(&TDataStd_ExtStringList::Set),
                    R"#(Finds or creates a list of string values attribute.)#"  , py::arg("label"),  py::arg("theGuid")
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_ExtStringList::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_ExtStringList::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("First",
             ( const TCollection_ExtendedString & (TDataStd_ExtStringList::*)() const) static_cast< const TCollection_ExtendedString & (TDataStd_ExtStringList::*)() const>(&TDataStd_ExtStringList::First),
             R"#()#"
             
         )
       .def("Last",
             ( const TCollection_ExtendedString & (TDataStd_ExtStringList::*)() const) static_cast< const TCollection_ExtendedString & (TDataStd_ExtStringList::*)() const>(&TDataStd_ExtStringList::Last),
             R"#()#"
             
         )
       .def("List",
             ( const NCollection_List<TCollection_ExtendedString> & (TDataStd_ExtStringList::*)() const) static_cast< const NCollection_List<TCollection_ExtendedString> & (TDataStd_ExtStringList::*)() const>(&TDataStd_ExtStringList::List),
             R"#()#"
             
         )
       .def("ID",
             ( const Standard_GUID & (TDataStd_ExtStringList::*)() const) static_cast< const Standard_GUID & (TDataStd_ExtStringList::*)() const>(&TDataStd_ExtStringList::ID),
             R"#()#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_ExtStringList::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_ExtStringList::*)() const>(&TDataStd_ExtStringList::DynamicType),
             R"#()#"
             
         )
;

    // Class TDataStd_GenericEmpty from ./opencascade/TDataStd_GenericEmpty.hxx
    klass = m.attr("TDataStd_GenericEmpty");


    // nested enums

    static_cast<py::class_<TDataStd_GenericEmpty ,opencascade::handle<TDataStd_GenericEmpty> ,Py_TDataStd_GenericEmpty , TDF_Attribute >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("Restore",
             (void (TDataStd_GenericEmpty::*)(  const handle<TDF_Attribute> &  ) ) static_cast<void (TDataStd_GenericEmpty::*)(  const handle<TDF_Attribute> &  ) >(&TDataStd_GenericEmpty::Restore),
             R"#()#"  , py::arg("arg0")
          )
        .def("Paste",
             (void (TDataStd_GenericEmpty::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const) static_cast<void (TDataStd_GenericEmpty::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const>(&TDataStd_GenericEmpty::Paste),
             R"#()#"  , py::arg("arg0"),  py::arg("arg1")
          )
        .def("DumpJson",
             (void (TDataStd_GenericEmpty::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDataStd_GenericEmpty::*)( Standard_OStream & ,  int  ) const>(&TDataStd_GenericEmpty::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_GenericEmpty::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_GenericEmpty::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_GenericEmpty::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_GenericEmpty::*)() const>(&TDataStd_GenericEmpty::DynamicType),
             R"#()#"
             
         )
;

    // Class TDataStd_GenericExtString from ./opencascade/TDataStd_GenericExtString.hxx
    klass = m.attr("TDataStd_GenericExtString");


    // nested enums

    static_cast<py::class_<TDataStd_GenericExtString ,opencascade::handle<TDataStd_GenericExtString> ,Py_TDataStd_GenericExtString , TDF_Attribute >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("Set",
             (void (TDataStd_GenericExtString::*)(  const TCollection_ExtendedString &  ) ) static_cast<void (TDataStd_GenericExtString::*)(  const TCollection_ExtendedString &  ) >(&TDataStd_GenericExtString::Set),
             R"#(Sets <S> as name. Raises if <S> is not a valid name.)#"  , py::arg("S")
          )
        .def("SetID",
             (void (TDataStd_GenericExtString::*)(  const Standard_GUID &  ) ) static_cast<void (TDataStd_GenericExtString::*)(  const Standard_GUID &  ) >(&TDataStd_GenericExtString::SetID),
             R"#(Sets the explicit user defined GUID to the attribute.)#"  , py::arg("guid")
          )
        .def("Restore",
             (void (TDataStd_GenericExtString::*)(  const handle<TDF_Attribute> &  ) ) static_cast<void (TDataStd_GenericExtString::*)(  const handle<TDF_Attribute> &  ) >(&TDataStd_GenericExtString::Restore),
             R"#()#"  , py::arg("with_")
          )
        .def("Paste",
             (void (TDataStd_GenericExtString::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const) static_cast<void (TDataStd_GenericExtString::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const>(&TDataStd_GenericExtString::Paste),
             R"#()#"  , py::arg("into"),  py::arg("RT")
          )
        .def("DumpJson",
             (void (TDataStd_GenericExtString::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDataStd_GenericExtString::*)( Standard_OStream & ,  int  ) const>(&TDataStd_GenericExtString::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_GenericExtString::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_GenericExtString::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Get",
             ( const TCollection_ExtendedString & (TDataStd_GenericExtString::*)() const) static_cast< const TCollection_ExtendedString & (TDataStd_GenericExtString::*)() const>(&TDataStd_GenericExtString::Get),
             R"#(Returns the name contained in this name attribute.)#"
             
         )
       .def("ID",
             ( const Standard_GUID & (TDataStd_GenericExtString::*)() const) static_cast< const Standard_GUID & (TDataStd_GenericExtString::*)() const>(&TDataStd_GenericExtString::ID),
             R"#(Returns the ID of the attribute.)#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_GenericExtString::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_GenericExtString::*)() const>(&TDataStd_GenericExtString::DynamicType),
             R"#()#"
             
         )
;

    // Class TDataStd_HDataMapOfStringByte from ./opencascade/TDataStd_HDataMapOfStringByte.hxx
    klass = m.attr("TDataStd_HDataMapOfStringByte");


    // nested enums

    static_cast<py::class_<TDataStd_HDataMapOfStringByte ,opencascade::handle<TDataStd_HDataMapOfStringByte>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const NCollection_DataMap<TCollection_ExtendedString, uint8_t> & >()  , py::arg("theOther") )
        .def(py::init<  const int >()  , py::arg("NbBuckets")=static_cast< const int>(1) )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_HDataMapOfStringByte::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_HDataMapOfStringByte::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_HDataMapOfStringByte::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_HDataMapOfStringByte::*)() const>(&TDataStd_HDataMapOfStringByte::DynamicType),
             R"#()#"
             
         )
       .def("Map",
             ( const NCollection_DataMap<TCollection_ExtendedString, uint8_t> & (TDataStd_HDataMapOfStringByte::*)() const) static_cast< const NCollection_DataMap<TCollection_ExtendedString, uint8_t> & (TDataStd_HDataMapOfStringByte::*)() const>(&TDataStd_HDataMapOfStringByte::Map),
             R"#()#"
             
         )
       .def("ChangeMap",
             (NCollection_DataMap<TCollection_ExtendedString, uint8_t> & (TDataStd_HDataMapOfStringByte::*)() ) static_cast<NCollection_DataMap<TCollection_ExtendedString, uint8_t> & (TDataStd_HDataMapOfStringByte::*)() >(&TDataStd_HDataMapOfStringByte::ChangeMap),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class TDataStd_HDataMapOfStringHArray1OfInteger from ./opencascade/TDataStd_HDataMapOfStringHArray1OfInteger.hxx
    klass = m.attr("TDataStd_HDataMapOfStringHArray1OfInteger");


    // nested enums

    static_cast<py::class_<TDataStd_HDataMapOfStringHArray1OfInteger ,opencascade::handle<TDataStd_HDataMapOfStringHArray1OfInteger>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const NCollection_DataMap<TCollection_ExtendedString, handle<NCollection_HArray1<int>>> & >()  , py::arg("theOther") )
        .def(py::init<  const int >()  , py::arg("NbBuckets")=static_cast< const int>(1) )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_HDataMapOfStringHArray1OfInteger::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_HDataMapOfStringHArray1OfInteger::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_HDataMapOfStringHArray1OfInteger::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_HDataMapOfStringHArray1OfInteger::*)() const>(&TDataStd_HDataMapOfStringHArray1OfInteger::DynamicType),
             R"#()#"
             
         )
       .def("Map",
             ( const NCollection_DataMap<TCollection_ExtendedString, handle<NCollection_HArray1<int>>> & (TDataStd_HDataMapOfStringHArray1OfInteger::*)() const) static_cast< const NCollection_DataMap<TCollection_ExtendedString, handle<NCollection_HArray1<int>>> & (TDataStd_HDataMapOfStringHArray1OfInteger::*)() const>(&TDataStd_HDataMapOfStringHArray1OfInteger::Map),
             R"#()#"
             
         )
       .def("ChangeMap",
             (NCollection_DataMap<TCollection_ExtendedString, handle<NCollection_HArray1<int>>> & (TDataStd_HDataMapOfStringHArray1OfInteger::*)() ) static_cast<NCollection_DataMap<TCollection_ExtendedString, handle<NCollection_HArray1<int>>> & (TDataStd_HDataMapOfStringHArray1OfInteger::*)() >(&TDataStd_HDataMapOfStringHArray1OfInteger::ChangeMap),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class TDataStd_HDataMapOfStringHArray1OfReal from ./opencascade/TDataStd_HDataMapOfStringHArray1OfReal.hxx
    klass = m.attr("TDataStd_HDataMapOfStringHArray1OfReal");


    // nested enums

    static_cast<py::class_<TDataStd_HDataMapOfStringHArray1OfReal ,opencascade::handle<TDataStd_HDataMapOfStringHArray1OfReal>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const NCollection_DataMap<TCollection_ExtendedString, handle<NCollection_HArray1<double>>> & >()  , py::arg("theOther") )
        .def(py::init<  const int >()  , py::arg("NbBuckets")=static_cast< const int>(1) )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_HDataMapOfStringHArray1OfReal::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_HDataMapOfStringHArray1OfReal::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_HDataMapOfStringHArray1OfReal::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_HDataMapOfStringHArray1OfReal::*)() const>(&TDataStd_HDataMapOfStringHArray1OfReal::DynamicType),
             R"#()#"
             
         )
       .def("Map",
             ( const NCollection_DataMap<TCollection_ExtendedString, handle<NCollection_HArray1<double>>> & (TDataStd_HDataMapOfStringHArray1OfReal::*)() const) static_cast< const NCollection_DataMap<TCollection_ExtendedString, handle<NCollection_HArray1<double>>> & (TDataStd_HDataMapOfStringHArray1OfReal::*)() const>(&TDataStd_HDataMapOfStringHArray1OfReal::Map),
             R"#()#"
             
         )
       .def("ChangeMap",
             (NCollection_DataMap<TCollection_ExtendedString, handle<NCollection_HArray1<double>>> & (TDataStd_HDataMapOfStringHArray1OfReal::*)() ) static_cast<NCollection_DataMap<TCollection_ExtendedString, handle<NCollection_HArray1<double>>> & (TDataStd_HDataMapOfStringHArray1OfReal::*)() >(&TDataStd_HDataMapOfStringHArray1OfReal::ChangeMap),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class TDataStd_HDataMapOfStringInteger from ./opencascade/TDataStd_HDataMapOfStringInteger.hxx
    klass = m.attr("TDataStd_HDataMapOfStringInteger");


    // nested enums

    static_cast<py::class_<TDataStd_HDataMapOfStringInteger ,opencascade::handle<TDataStd_HDataMapOfStringInteger>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const NCollection_DataMap<TCollection_ExtendedString, int> & >()  , py::arg("theOther") )
        .def(py::init<  const int >()  , py::arg("NbBuckets")=static_cast< const int>(1) )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_HDataMapOfStringInteger::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_HDataMapOfStringInteger::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_HDataMapOfStringInteger::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_HDataMapOfStringInteger::*)() const>(&TDataStd_HDataMapOfStringInteger::DynamicType),
             R"#()#"
             
         )
       .def("Map",
             ( const NCollection_DataMap<TCollection_ExtendedString, int> & (TDataStd_HDataMapOfStringInteger::*)() const) static_cast< const NCollection_DataMap<TCollection_ExtendedString, int> & (TDataStd_HDataMapOfStringInteger::*)() const>(&TDataStd_HDataMapOfStringInteger::Map),
             R"#()#"
             
         )
       .def("ChangeMap",
             (NCollection_DataMap<TCollection_ExtendedString, int> & (TDataStd_HDataMapOfStringInteger::*)() ) static_cast<NCollection_DataMap<TCollection_ExtendedString, int> & (TDataStd_HDataMapOfStringInteger::*)() >(&TDataStd_HDataMapOfStringInteger::ChangeMap),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class TDataStd_HDataMapOfStringReal from ./opencascade/TDataStd_HDataMapOfStringReal.hxx
    klass = m.attr("TDataStd_HDataMapOfStringReal");


    // nested enums

    static_cast<py::class_<TDataStd_HDataMapOfStringReal ,opencascade::handle<TDataStd_HDataMapOfStringReal>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const NCollection_DataMap<TCollection_ExtendedString, double> & >()  , py::arg("theOther") )
        .def(py::init<  const int >()  , py::arg("NbBuckets")=static_cast< const int>(1) )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_HDataMapOfStringReal::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_HDataMapOfStringReal::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_HDataMapOfStringReal::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_HDataMapOfStringReal::*)() const>(&TDataStd_HDataMapOfStringReal::DynamicType),
             R"#()#"
             
         )
       .def("Map",
             ( const NCollection_DataMap<TCollection_ExtendedString, double> & (TDataStd_HDataMapOfStringReal::*)() const) static_cast< const NCollection_DataMap<TCollection_ExtendedString, double> & (TDataStd_HDataMapOfStringReal::*)() const>(&TDataStd_HDataMapOfStringReal::Map),
             R"#()#"
             
         )
       .def("ChangeMap",
             (NCollection_DataMap<TCollection_ExtendedString, double> & (TDataStd_HDataMapOfStringReal::*)() ) static_cast<NCollection_DataMap<TCollection_ExtendedString, double> & (TDataStd_HDataMapOfStringReal::*)() >(&TDataStd_HDataMapOfStringReal::ChangeMap),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class TDataStd_HDataMapOfStringString from ./opencascade/TDataStd_HDataMapOfStringString.hxx
    klass = m.attr("TDataStd_HDataMapOfStringString");


    // nested enums

    static_cast<py::class_<TDataStd_HDataMapOfStringString ,opencascade::handle<TDataStd_HDataMapOfStringString>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const NCollection_DataMap<TCollection_ExtendedString, TCollection_ExtendedString> & >()  , py::arg("theOther") )
        .def(py::init<  const int >()  , py::arg("NbBuckets")=static_cast< const int>(1) )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_HDataMapOfStringString::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_HDataMapOfStringString::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_HDataMapOfStringString::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_HDataMapOfStringString::*)() const>(&TDataStd_HDataMapOfStringString::DynamicType),
             R"#()#"
             
         )
       .def("Map",
             ( const NCollection_DataMap<TCollection_ExtendedString, TCollection_ExtendedString> & (TDataStd_HDataMapOfStringString::*)() const) static_cast< const NCollection_DataMap<TCollection_ExtendedString, TCollection_ExtendedString> & (TDataStd_HDataMapOfStringString::*)() const>(&TDataStd_HDataMapOfStringString::Map),
             R"#()#"
             
         )
       .def("ChangeMap",
             (NCollection_DataMap<TCollection_ExtendedString, TCollection_ExtendedString> & (TDataStd_HDataMapOfStringString::*)() ) static_cast<NCollection_DataMap<TCollection_ExtendedString, TCollection_ExtendedString> & (TDataStd_HDataMapOfStringString::*)() >(&TDataStd_HDataMapOfStringString::ChangeMap),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class TDataStd_IntPackedMap from ./opencascade/TDataStd_IntPackedMap.hxx
    klass = m.attr("TDataStd_IntPackedMap");


    // nested enums

    static_cast<py::class_<TDataStd_IntPackedMap ,opencascade::handle<TDataStd_IntPackedMap>  , TDF_Attribute >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ChangeMap",
             (bool (TDataStd_IntPackedMap::*)(  const handle<TColStd_HPackedMapOfInteger> &  ) ) static_cast<bool (TDataStd_IntPackedMap::*)(  const handle<TColStd_HPackedMapOfInteger> &  ) >(&TDataStd_IntPackedMap::ChangeMap),
             R"#()#"  , py::arg("theMap")
          )
        .def("ChangeMap",
             (bool (TDataStd_IntPackedMap::*)(  const TColStd_PackedMapOfInteger &  ) ) static_cast<bool (TDataStd_IntPackedMap::*)(  const TColStd_PackedMapOfInteger &  ) >(&TDataStd_IntPackedMap::ChangeMap),
             R"#()#"  , py::arg("theMap")
          )
        .def("Clear",
             (bool (TDataStd_IntPackedMap::*)() ) static_cast<bool (TDataStd_IntPackedMap::*)() >(&TDataStd_IntPackedMap::Clear),
             R"#()#" 
          )
        .def("Add",
             (bool (TDataStd_IntPackedMap::*)(  const int  ) ) static_cast<bool (TDataStd_IntPackedMap::*)(  const int  ) >(&TDataStd_IntPackedMap::Add),
             R"#()#"  , py::arg("theKey")
          )
        .def("Remove",
             (bool (TDataStd_IntPackedMap::*)(  const int  ) ) static_cast<bool (TDataStd_IntPackedMap::*)(  const int  ) >(&TDataStd_IntPackedMap::Remove),
             R"#()#"  , py::arg("theKey")
          )
        .def("Contains",
             (bool (TDataStd_IntPackedMap::*)(  const int  ) const) static_cast<bool (TDataStd_IntPackedMap::*)(  const int  ) const>(&TDataStd_IntPackedMap::Contains),
             R"#()#"  , py::arg("theKey")
          )
        .def("Extent",
             (int (TDataStd_IntPackedMap::*)() const) static_cast<int (TDataStd_IntPackedMap::*)() const>(&TDataStd_IntPackedMap::Extent),
             R"#()#" 
          )
        .def("IsEmpty",
             (bool (TDataStd_IntPackedMap::*)() const) static_cast<bool (TDataStd_IntPackedMap::*)() const>(&TDataStd_IntPackedMap::IsEmpty),
             R"#()#" 
          )
        .def("GetDelta",
             (bool (TDataStd_IntPackedMap::*)() const) static_cast<bool (TDataStd_IntPackedMap::*)() const>(&TDataStd_IntPackedMap::GetDelta),
             R"#()#" 
          )
        .def("SetDelta",
             (void (TDataStd_IntPackedMap::*)(  const bool  ) ) static_cast<void (TDataStd_IntPackedMap::*)(  const bool  ) >(&TDataStd_IntPackedMap::SetDelta),
             R"#(for internal use only!)#"  , py::arg("isDelta")
          )
        .def("Restore",
             (void (TDataStd_IntPackedMap::*)(  const handle<TDF_Attribute> &  ) ) static_cast<void (TDataStd_IntPackedMap::*)(  const handle<TDF_Attribute> &  ) >(&TDataStd_IntPackedMap::Restore),
             R"#()#"  , py::arg("with_")
          )
        .def("NewEmpty",
             (handle<TDF_Attribute> (TDataStd_IntPackedMap::*)() const) static_cast<handle<TDF_Attribute> (TDataStd_IntPackedMap::*)() const>(&TDataStd_IntPackedMap::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (void (TDataStd_IntPackedMap::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const) static_cast<void (TDataStd_IntPackedMap::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const>(&TDataStd_IntPackedMap::Paste),
             R"#()#"  , py::arg("into"),  py::arg("RT")
          )
        .def("Dump",
             (Standard_OStream & (TDataStd_IntPackedMap::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDataStd_IntPackedMap::*)( Standard_OStream &  ) const>(&TDataStd_IntPackedMap::Dump),
             R"#()#"  , py::arg("anOS")
          )
        .def("DeltaOnModification",
             (handle<TDF_DeltaOnModification> (TDataStd_IntPackedMap::*)(  const handle<TDF_Attribute> &  ) const) static_cast<handle<TDF_DeltaOnModification> (TDataStd_IntPackedMap::*)(  const handle<TDF_Attribute> &  ) const>(&TDataStd_IntPackedMap::DeltaOnModification),
             R"#(Makes a DeltaOnModification between <me> and <anOldAttribute>.)#"  , py::arg("anOldAttribute")
          )
        .def("DumpJson",
             (void (TDataStd_IntPackedMap::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDataStd_IntPackedMap::*)( Standard_OStream & ,  int  ) const>(&TDataStd_IntPackedMap::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_IntPackedMap::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_IntPackedMap::get_type_descriptor),
                    R"#()#" 
          )
        .def_static("GetID_s",
                    ( const Standard_GUID & (*)() ) static_cast< const Standard_GUID & (*)() >(&TDataStd_IntPackedMap::GetID),
                    R"#(class methods ============= Returns the GUID of the attribute.)#" 
          )
        .def_static("Set_s",
                    (handle<TDataStd_IntPackedMap> (*)(  const TDF_Label & ,   const bool  ) ) static_cast<handle<TDataStd_IntPackedMap> (*)(  const TDF_Label & ,   const bool  ) >(&TDataStd_IntPackedMap::Set),
                    R"#(Finds or creates an integer map attribute on the given label. If <isDelta> == False, DefaultDeltaOnModification is used. If <isDelta> == True, DeltaOnModification of the current attribute is used. If attribute is already set, input parameter <isDelta> is refused and the found attribute returned. Attribute methods ===================)#"  , py::arg("label"),  py::arg("isDelta")=static_cast< const bool>(false)
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_IntPackedMap::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_IntPackedMap::*)() const>(&TDataStd_IntPackedMap::DynamicType),
             R"#()#"
             
         )
       .def("GetMap",
             ( const TColStd_PackedMapOfInteger & (TDataStd_IntPackedMap::*)() const) static_cast< const TColStd_PackedMapOfInteger & (TDataStd_IntPackedMap::*)() const>(&TDataStd_IntPackedMap::GetMap),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("GetHMap",
             ( const handle<TColStd_HPackedMapOfInteger> & (TDataStd_IntPackedMap::*)() const) static_cast< const handle<TColStd_HPackedMapOfInteger> & (TDataStd_IntPackedMap::*)() const>(&TDataStd_IntPackedMap::GetHMap),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
       .def("ID",
             ( const Standard_GUID & (TDataStd_IntPackedMap::*)() const) static_cast< const Standard_GUID & (TDataStd_IntPackedMap::*)() const>(&TDataStd_IntPackedMap::ID),
             R"#()#"
             
         )
;

    // Class TDataStd_Integer from ./opencascade/TDataStd_Integer.hxx
    klass = m.attr("TDataStd_Integer");


    // nested enums

    static_cast<py::class_<TDataStd_Integer ,opencascade::handle<TDataStd_Integer>  , TDF_Attribute >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Set",
             (void (TDataStd_Integer::*)(  const int  ) ) static_cast<void (TDataStd_Integer::*)(  const int  ) >(&TDataStd_Integer::Set),
             R"#(Integer methods ===============)#"  , py::arg("V")
          )
        .def("SetID",
             (void (TDataStd_Integer::*)(  const Standard_GUID &  ) ) static_cast<void (TDataStd_Integer::*)(  const Standard_GUID &  ) >(&TDataStd_Integer::SetID),
             R"#(Sets the explicit GUID (user defined) for the attribute.)#"  , py::arg("guid")
          )
        .def("SetID",
             (void (TDataStd_Integer::*)() ) static_cast<void (TDataStd_Integer::*)() >(&TDataStd_Integer::SetID),
             R"#(Sets default GUID for the attribute.)#" 
          )
        .def("Get",
             (int (TDataStd_Integer::*)() const) static_cast<int (TDataStd_Integer::*)() const>(&TDataStd_Integer::Get),
             R"#(Returns the integer value contained in the attribute.)#" 
          )
        .def("IsCaptured",
             (bool (TDataStd_Integer::*)() const) static_cast<bool (TDataStd_Integer::*)() const>(&TDataStd_Integer::IsCaptured),
             R"#(Returns True if there is a reference on the same label)#" 
          )
        .def("Restore",
             (void (TDataStd_Integer::*)(  const handle<TDF_Attribute> &  ) ) static_cast<void (TDataStd_Integer::*)(  const handle<TDF_Attribute> &  ) >(&TDataStd_Integer::Restore),
             R"#()#"  , py::arg("With")
          )
        .def("NewEmpty",
             (handle<TDF_Attribute> (TDataStd_Integer::*)() const) static_cast<handle<TDF_Attribute> (TDataStd_Integer::*)() const>(&TDataStd_Integer::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (void (TDataStd_Integer::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const) static_cast<void (TDataStd_Integer::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const>(&TDataStd_Integer::Paste),
             R"#()#"  , py::arg("Into"),  py::arg("RT")
          )
        .def("Dump",
             (Standard_OStream & (TDataStd_Integer::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDataStd_Integer::*)( Standard_OStream &  ) const>(&TDataStd_Integer::Dump),
             R"#()#"  , py::arg("anOS")
          )
        .def("DumpJson",
             (void (TDataStd_Integer::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDataStd_Integer::*)( Standard_OStream & ,  int  ) const>(&TDataStd_Integer::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("GetID_s",
                    ( const Standard_GUID & (*)() ) static_cast< const Standard_GUID & (*)() >(&TDataStd_Integer::GetID),
                    R"#(class methods ============= Returns the GUID for integers.)#" 
          )
        .def_static("Set_s",
                    (handle<TDataStd_Integer> (*)(  const TDF_Label & ,   const int  ) ) static_cast<handle<TDataStd_Integer> (*)(  const TDF_Label & ,   const int  ) >(&TDataStd_Integer::Set),
                    R"#(Finds, or creates, an Integer attribute and sets <value> the Integer attribute is returned.)#"  , py::arg("label"),  py::arg("value")
          )
        .def_static("Set_s",
                    (handle<TDataStd_Integer> (*)(  const TDF_Label & ,   const Standard_GUID & ,   const int  ) ) static_cast<handle<TDataStd_Integer> (*)(  const TDF_Label & ,   const Standard_GUID & ,   const int  ) >(&TDataStd_Integer::Set),
                    R"#(Finds, or creates, an Integer attribute with explicit user defined <guid> and sets <value>. The Integer attribute is returned.)#"  , py::arg("label"),  py::arg("guid"),  py::arg("value")
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_Integer::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_Integer::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("ID",
             ( const Standard_GUID & (TDataStd_Integer::*)() const) static_cast< const Standard_GUID & (TDataStd_Integer::*)() const>(&TDataStd_Integer::ID),
             R"#()#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_Integer::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_Integer::*)() const>(&TDataStd_Integer::DynamicType),
             R"#()#"
             
         )
;

    // Class TDataStd_IntegerArray from ./opencascade/TDataStd_IntegerArray.hxx
    klass = m.attr("TDataStd_IntegerArray");


    // nested enums

    static_cast<py::class_<TDataStd_IntegerArray ,opencascade::handle<TDataStd_IntegerArray>  , TDF_Attribute >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (TDataStd_IntegerArray::*)(  const int ,   const int  ) ) static_cast<void (TDataStd_IntegerArray::*)(  const int ,   const int  ) >(&TDataStd_IntegerArray::Init),
             R"#(Initialize the inner array with bounds from <lower> to <upper>)#"  , py::arg("lower"),  py::arg("upper")
          )
        .def("SetValue",
             (void (TDataStd_IntegerArray::*)(  const int ,   const int  ) ) static_cast<void (TDataStd_IntegerArray::*)(  const int ,   const int  ) >(&TDataStd_IntegerArray::SetValue),
             R"#(Sets the <Index>th element of the array to <Value> OutOfRange exception is raised if <Index> doesn't respect Lower and Upper bounds of the internal array.)#"  , py::arg("Index"),  py::arg("Value")
          )
        .def("SetID",
             (void (TDataStd_IntegerArray::*)(  const Standard_GUID &  ) ) static_cast<void (TDataStd_IntegerArray::*)(  const Standard_GUID &  ) >(&TDataStd_IntegerArray::SetID),
             R"#(Sets the explicit GUID (user defined) for the attribute.)#"  , py::arg("theGuid")
          )
        .def("SetID",
             (void (TDataStd_IntegerArray::*)() ) static_cast<void (TDataStd_IntegerArray::*)() >(&TDataStd_IntegerArray::SetID),
             R"#(Sets default GUID for the attribute.)#" 
          )
        .def("Value",
             (int (TDataStd_IntegerArray::*)(  const int  ) const) static_cast<int (TDataStd_IntegerArray::*)(  const int  ) const>(&TDataStd_IntegerArray::Value),
             R"#(Return the value of the <Index>th element of the array)#"  , py::arg("Index")
          )
        .def("Lower",
             (int (TDataStd_IntegerArray::*)() const) static_cast<int (TDataStd_IntegerArray::*)() const>(&TDataStd_IntegerArray::Lower),
             R"#(Returns the lower boundary of this array of integers.)#" 
          )
        .def("Upper",
             (int (TDataStd_IntegerArray::*)() const) static_cast<int (TDataStd_IntegerArray::*)() const>(&TDataStd_IntegerArray::Upper),
             R"#(Return the upper boundary of this array of integers.)#" 
          )
        .def("Length",
             (int (TDataStd_IntegerArray::*)() const) static_cast<int (TDataStd_IntegerArray::*)() const>(&TDataStd_IntegerArray::Length),
             R"#(Returns the length of this array of integers in terms of the number of elements it contains.)#" 
          )
        .def("ChangeArray",
             (void (TDataStd_IntegerArray::*)(  const handle<NCollection_HArray1<int>> & ,   const bool  ) ) static_cast<void (TDataStd_IntegerArray::*)(  const handle<NCollection_HArray1<int>> & ,   const bool  ) >(&TDataStd_IntegerArray::ChangeArray),
             R"#(Sets the inner array <myValue> of the IntegerArray attribute to <newArray>. If value of <newArray> differs from <myValue>, Backup performed and myValue refers to new instance of HArray1OfInteger that holds <newArray> values If <isCheckItems> equal True each item of <newArray> will be checked with each item of <myValue> for coincidence (to avoid backup).)#"  , py::arg("newArray"),  py::arg("isCheckItems")=static_cast< const bool>(true)
          )
        .def("GetDelta",
             (bool (TDataStd_IntegerArray::*)() const) static_cast<bool (TDataStd_IntegerArray::*)() const>(&TDataStd_IntegerArray::GetDelta),
             R"#()#" 
          )
        .def("SetDelta",
             (void (TDataStd_IntegerArray::*)(  const bool  ) ) static_cast<void (TDataStd_IntegerArray::*)(  const bool  ) >(&TDataStd_IntegerArray::SetDelta),
             R"#(for internal use only!)#"  , py::arg("isDelta")
          )
        .def("Restore",
             (void (TDataStd_IntegerArray::*)(  const handle<TDF_Attribute> &  ) ) static_cast<void (TDataStd_IntegerArray::*)(  const handle<TDF_Attribute> &  ) >(&TDataStd_IntegerArray::Restore),
             R"#()#"  , py::arg("With")
          )
        .def("NewEmpty",
             (handle<TDF_Attribute> (TDataStd_IntegerArray::*)() const) static_cast<handle<TDF_Attribute> (TDataStd_IntegerArray::*)() const>(&TDataStd_IntegerArray::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (void (TDataStd_IntegerArray::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const) static_cast<void (TDataStd_IntegerArray::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const>(&TDataStd_IntegerArray::Paste),
             R"#(Note. Uses inside ChangeArray() method)#"  , py::arg("Into"),  py::arg("RT")
          )
        .def("Dump",
             (Standard_OStream & (TDataStd_IntegerArray::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDataStd_IntegerArray::*)( Standard_OStream &  ) const>(&TDataStd_IntegerArray::Dump),
             R"#()#"  , py::arg("anOS")
          )
        .def("DeltaOnModification",
             (handle<TDF_DeltaOnModification> (TDataStd_IntegerArray::*)(  const handle<TDF_Attribute> &  ) const) static_cast<handle<TDF_DeltaOnModification> (TDataStd_IntegerArray::*)(  const handle<TDF_Attribute> &  ) const>(&TDataStd_IntegerArray::DeltaOnModification),
             R"#(Makes a DeltaOnModification between <me> and <anOldAttribute>.)#"  , py::arg("anOldAttribute")
          )
        .def("DumpJson",
             (void (TDataStd_IntegerArray::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDataStd_IntegerArray::*)( Standard_OStream & ,  int  ) const>(&TDataStd_IntegerArray::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_IntegerArray::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_IntegerArray::get_type_descriptor),
                    R"#()#" 
          )
        .def_static("GetID_s",
                    ( const Standard_GUID & (*)() ) static_cast< const Standard_GUID & (*)() >(&TDataStd_IntegerArray::GetID),
                    R"#(class methods ============= Returns the GUID for arrays of integers.)#" 
          )
        .def_static("Set_s",
                    (handle<TDataStd_IntegerArray> (*)(  const TDF_Label & ,   const int ,   const int ,   const bool  ) ) static_cast<handle<TDataStd_IntegerArray> (*)(  const TDF_Label & ,   const int ,   const int ,   const bool  ) >(&TDataStd_IntegerArray::Set),
                    R"#(Finds or creates on the <label> an integer array attribute with the specified <lower> and <upper> boundaries. If <isDelta> == False, DefaultDeltaOnModification is used. If <isDelta> == True, DeltaOnModification of the current attribute is used. If attribute is already set, all input parameters are refused and the found attribute is returned.)#"  , py::arg("label"),  py::arg("lower"),  py::arg("upper"),  py::arg("isDelta")=static_cast< const bool>(false)
          )
        .def_static("Set_s",
                    (handle<TDataStd_IntegerArray> (*)(  const TDF_Label & ,   const Standard_GUID & ,   const int ,   const int ,   const bool  ) ) static_cast<handle<TDataStd_IntegerArray> (*)(  const TDF_Label & ,   const Standard_GUID & ,   const int ,   const int ,   const bool  ) >(&TDataStd_IntegerArray::Set),
                    R"#(Finds, or creates, an IntegerArray attribute with explicit user defined <guid>. The IntegerArray attribute is returned.)#"  , py::arg("label"),  py::arg("theGuid"),  py::arg("lower"),  py::arg("upper"),  py::arg("isDelta")=static_cast< const bool>(false)
          )
    // static methods using call by reference i.s.o. return
    // operators
        .def("__call__",
             (int (TDataStd_IntegerArray::*)(  const int  ) const) static_cast<int (TDataStd_IntegerArray::*)(  const int  ) const>(&TDataStd_IntegerArray::operator()),
             py::is_operator(),
             R"#()#"  , py::arg("Index")
          )
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_IntegerArray::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_IntegerArray::*)() const>(&TDataStd_IntegerArray::DynamicType),
             R"#()#"
             
         )
       .def("Array",
             ( const handle<NCollection_HArray1<int>> & (TDataStd_IntegerArray::*)() const) static_cast< const handle<NCollection_HArray1<int>> & (TDataStd_IntegerArray::*)() const>(&TDataStd_IntegerArray::Array),
             R"#(Return the inner array of the IntegerArray attribute)#"
             
         )
       .def("ID",
             ( const Standard_GUID & (TDataStd_IntegerArray::*)() const) static_cast< const Standard_GUID & (TDataStd_IntegerArray::*)() const>(&TDataStd_IntegerArray::ID),
             R"#()#"
             
         )
;

    // Class TDataStd_IntegerList from ./opencascade/TDataStd_IntegerList.hxx
    klass = m.attr("TDataStd_IntegerList");


    // nested enums

    static_cast<py::class_<TDataStd_IntegerList ,opencascade::handle<TDataStd_IntegerList>  , TDF_Attribute >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("IsEmpty",
             (bool (TDataStd_IntegerList::*)() const) static_cast<bool (TDataStd_IntegerList::*)() const>(&TDataStd_IntegerList::IsEmpty),
             R"#()#" 
          )
        .def("Extent",
             (int (TDataStd_IntegerList::*)() const) static_cast<int (TDataStd_IntegerList::*)() const>(&TDataStd_IntegerList::Extent),
             R"#()#" 
          )
        .def("Prepend",
             (void (TDataStd_IntegerList::*)(  const int  ) ) static_cast<void (TDataStd_IntegerList::*)(  const int  ) >(&TDataStd_IntegerList::Prepend),
             R"#()#"  , py::arg("value")
          )
        .def("Append",
             (void (TDataStd_IntegerList::*)(  const int  ) ) static_cast<void (TDataStd_IntegerList::*)(  const int  ) >(&TDataStd_IntegerList::Append),
             R"#()#"  , py::arg("value")
          )
        .def("SetID",
             (void (TDataStd_IntegerList::*)(  const Standard_GUID &  ) ) static_cast<void (TDataStd_IntegerList::*)(  const Standard_GUID &  ) >(&TDataStd_IntegerList::SetID),
             R"#(Sets the explicit GUID (user defined) for the attribute.)#"  , py::arg("theGuid")
          )
        .def("SetID",
             (void (TDataStd_IntegerList::*)() ) static_cast<void (TDataStd_IntegerList::*)() >(&TDataStd_IntegerList::SetID),
             R"#(Sets default GUID for the attribute.)#" 
          )
        .def("InsertBefore",
             (bool (TDataStd_IntegerList::*)(  const int ,   const int  ) ) static_cast<bool (TDataStd_IntegerList::*)(  const int ,   const int  ) >(&TDataStd_IntegerList::InsertBefore),
             R"#(Inserts the <value> before the first meet of <before_value>.)#"  , py::arg("value"),  py::arg("before_value")
          )
        .def("InsertBeforeByIndex",
             (bool (TDataStd_IntegerList::*)(  const int ,   const int  ) ) static_cast<bool (TDataStd_IntegerList::*)(  const int ,   const int  ) >(&TDataStd_IntegerList::InsertBeforeByIndex),
             R"#(Inserts the <value> before the <index> position. The indices start with 1 .. Extent().)#"  , py::arg("index"),  py::arg("before_value")
          )
        .def("InsertAfter",
             (bool (TDataStd_IntegerList::*)(  const int ,   const int  ) ) static_cast<bool (TDataStd_IntegerList::*)(  const int ,   const int  ) >(&TDataStd_IntegerList::InsertAfter),
             R"#(Inserts the <value> after the first meet of <after_value>.)#"  , py::arg("value"),  py::arg("after_value")
          )
        .def("InsertAfterByIndex",
             (bool (TDataStd_IntegerList::*)(  const int ,   const int  ) ) static_cast<bool (TDataStd_IntegerList::*)(  const int ,   const int  ) >(&TDataStd_IntegerList::InsertAfterByIndex),
             R"#(Inserts the <value> after the <index> position. The indices start with 1 .. Extent().)#"  , py::arg("index"),  py::arg("after_value")
          )
        .def("Remove",
             (bool (TDataStd_IntegerList::*)(  const int  ) ) static_cast<bool (TDataStd_IntegerList::*)(  const int  ) >(&TDataStd_IntegerList::Remove),
             R"#(Removes the first meet of the <value>.)#"  , py::arg("value")
          )
        .def("RemoveByIndex",
             (bool (TDataStd_IntegerList::*)(  const int  ) ) static_cast<bool (TDataStd_IntegerList::*)(  const int  ) >(&TDataStd_IntegerList::RemoveByIndex),
             R"#(Removes a value at <index> position.)#"  , py::arg("index")
          )
        .def("Clear",
             (void (TDataStd_IntegerList::*)() ) static_cast<void (TDataStd_IntegerList::*)() >(&TDataStd_IntegerList::Clear),
             R"#()#" 
          )
        .def("First",
             (int (TDataStd_IntegerList::*)() const) static_cast<int (TDataStd_IntegerList::*)() const>(&TDataStd_IntegerList::First),
             R"#()#" 
          )
        .def("Last",
             (int (TDataStd_IntegerList::*)() const) static_cast<int (TDataStd_IntegerList::*)() const>(&TDataStd_IntegerList::Last),
             R"#()#" 
          )
        .def("Restore",
             (void (TDataStd_IntegerList::*)(  const handle<TDF_Attribute> &  ) ) static_cast<void (TDataStd_IntegerList::*)(  const handle<TDF_Attribute> &  ) >(&TDataStd_IntegerList::Restore),
             R"#()#"  , py::arg("With")
          )
        .def("NewEmpty",
             (handle<TDF_Attribute> (TDataStd_IntegerList::*)() const) static_cast<handle<TDF_Attribute> (TDataStd_IntegerList::*)() const>(&TDataStd_IntegerList::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (void (TDataStd_IntegerList::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const) static_cast<void (TDataStd_IntegerList::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const>(&TDataStd_IntegerList::Paste),
             R"#()#"  , py::arg("Into"),  py::arg("RT")
          )
        .def("Dump",
             (Standard_OStream & (TDataStd_IntegerList::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDataStd_IntegerList::*)( Standard_OStream &  ) const>(&TDataStd_IntegerList::Dump),
             R"#()#"  , py::arg("anOS")
          )
        .def("DumpJson",
             (void (TDataStd_IntegerList::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDataStd_IntegerList::*)( Standard_OStream & ,  int  ) const>(&TDataStd_IntegerList::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("GetID_s",
                    ( const Standard_GUID & (*)() ) static_cast< const Standard_GUID & (*)() >(&TDataStd_IntegerList::GetID),
                    R"#(Static methods ============== Returns the ID of the list of integer attribute.)#" 
          )
        .def_static("Set_s",
                    (handle<TDataStd_IntegerList> (*)(  const TDF_Label &  ) ) static_cast<handle<TDataStd_IntegerList> (*)(  const TDF_Label &  ) >(&TDataStd_IntegerList::Set),
                    R"#(Finds or creates a list of integer values attribute.)#"  , py::arg("label")
          )
        .def_static("Set_s",
                    (handle<TDataStd_IntegerList> (*)(  const TDF_Label & ,   const Standard_GUID &  ) ) static_cast<handle<TDataStd_IntegerList> (*)(  const TDF_Label & ,   const Standard_GUID &  ) >(&TDataStd_IntegerList::Set),
                    R"#(Finds or creates a list of integer values attribute with explicit user defined <guid>.)#"  , py::arg("label"),  py::arg("theGuid")
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_IntegerList::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_IntegerList::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("List",
             ( const NCollection_List<int> & (TDataStd_IntegerList::*)() const) static_cast< const NCollection_List<int> & (TDataStd_IntegerList::*)() const>(&TDataStd_IntegerList::List),
             R"#()#"
             
         )
       .def("ID",
             ( const Standard_GUID & (TDataStd_IntegerList::*)() const) static_cast< const Standard_GUID & (TDataStd_IntegerList::*)() const>(&TDataStd_IntegerList::ID),
             R"#()#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_IntegerList::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_IntegerList::*)() const>(&TDataStd_IntegerList::DynamicType),
             R"#()#"
             
         )
;

    // Class TDataStd_NamedData from ./opencascade/TDataStd_NamedData.hxx
    klass = m.attr("TDataStd_NamedData");


    // nested enums

    static_cast<py::class_<TDataStd_NamedData ,opencascade::handle<TDataStd_NamedData>  , TDF_Attribute >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("HasIntegers",
             (bool (TDataStd_NamedData::*)() const) static_cast<bool (TDataStd_NamedData::*)() const>(&TDataStd_NamedData::HasIntegers),
             R"#(Returns true if at least one named integer value is kept in the attribute.)#" 
          )
        .def("HasInteger",
             (bool (TDataStd_NamedData::*)(  const TCollection_ExtendedString &  ) const) static_cast<bool (TDataStd_NamedData::*)(  const TCollection_ExtendedString &  ) const>(&TDataStd_NamedData::HasInteger),
             R"#(Returns true if the attribute contains specified by Name integer value.)#"  , py::arg("theName")
          )
        .def("GetInteger",
             (int (TDataStd_NamedData::*)(  const TCollection_ExtendedString &  ) ) static_cast<int (TDataStd_NamedData::*)(  const TCollection_ExtendedString &  ) >(&TDataStd_NamedData::GetInteger),
             R"#(Returns the integer value specified by the Name. It returns 0 if internal map doesn't contain the specified integer (use HasInteger() to check before).)#"  , py::arg("theName")
          )
        .def("SetInteger",
             (void (TDataStd_NamedData::*)(  const TCollection_ExtendedString & ,   const int  ) ) static_cast<void (TDataStd_NamedData::*)(  const TCollection_ExtendedString & ,   const int  ) >(&TDataStd_NamedData::SetInteger),
             R"#(Defines a named integer. If the integer already exists, it changes its value to <theInteger>.)#"  , py::arg("theName"),  py::arg("theInteger")
          )
        .def("ChangeIntegers",
             (void (TDataStd_NamedData::*)(  const NCollection_DataMap<TCollection_ExtendedString, int> &  ) ) static_cast<void (TDataStd_NamedData::*)(  const NCollection_DataMap<TCollection_ExtendedString, int> &  ) >(&TDataStd_NamedData::ChangeIntegers),
             R"#(Replace the container content by new content of the <theIntegers>.)#"  , py::arg("theIntegers")
          )
        .def("HasReals",
             (bool (TDataStd_NamedData::*)() const) static_cast<bool (TDataStd_NamedData::*)() const>(&TDataStd_NamedData::HasReals),
             R"#(Returns true if at least one named real value is kept in the attribute.)#" 
          )
        .def("HasReal",
             (bool (TDataStd_NamedData::*)(  const TCollection_ExtendedString &  ) const) static_cast<bool (TDataStd_NamedData::*)(  const TCollection_ExtendedString &  ) const>(&TDataStd_NamedData::HasReal),
             R"#(Returns true if the attribute contains a real specified by Name.)#"  , py::arg("theName")
          )
        .def("GetReal",
             (double (TDataStd_NamedData::*)(  const TCollection_ExtendedString &  ) ) static_cast<double (TDataStd_NamedData::*)(  const TCollection_ExtendedString &  ) >(&TDataStd_NamedData::GetReal),
             R"#(Returns the named real. It returns 0.0 if there is no such a named real (use HasReal()).)#"  , py::arg("theName")
          )
        .def("SetReal",
             (void (TDataStd_NamedData::*)(  const TCollection_ExtendedString & ,   const double  ) ) static_cast<void (TDataStd_NamedData::*)(  const TCollection_ExtendedString & ,   const double  ) >(&TDataStd_NamedData::SetReal),
             R"#(Defines a named real. If the real already exists, it changes its value to <theReal>.)#"  , py::arg("theName"),  py::arg("theReal")
          )
        .def("ChangeReals",
             (void (TDataStd_NamedData::*)(  const NCollection_DataMap<TCollection_ExtendedString, double> &  ) ) static_cast<void (TDataStd_NamedData::*)(  const NCollection_DataMap<TCollection_ExtendedString, double> &  ) >(&TDataStd_NamedData::ChangeReals),
             R"#(Replace the container content by new content of the <theReals>.)#"  , py::arg("theReals")
          )
        .def("HasStrings",
             (bool (TDataStd_NamedData::*)() const) static_cast<bool (TDataStd_NamedData::*)() const>(&TDataStd_NamedData::HasStrings),
             R"#(Returns true if there are some named strings in the attribute.)#" 
          )
        .def("HasString",
             (bool (TDataStd_NamedData::*)(  const TCollection_ExtendedString &  ) const) static_cast<bool (TDataStd_NamedData::*)(  const TCollection_ExtendedString &  ) const>(&TDataStd_NamedData::HasString),
             R"#(Returns true if the attribute contains this named string.)#"  , py::arg("theName")
          )
        .def("GetString",
             ( const TCollection_ExtendedString & (TDataStd_NamedData::*)(  const TCollection_ExtendedString &  ) ) static_cast< const TCollection_ExtendedString & (TDataStd_NamedData::*)(  const TCollection_ExtendedString &  ) >(&TDataStd_NamedData::GetString),
             R"#(Returns the named string. It returns an empty string if there is no such a named string (use HasString()).)#"  , py::arg("theName")
          )
        .def("SetString",
             (void (TDataStd_NamedData::*)(  const TCollection_ExtendedString & ,   const TCollection_ExtendedString &  ) ) static_cast<void (TDataStd_NamedData::*)(  const TCollection_ExtendedString & ,   const TCollection_ExtendedString &  ) >(&TDataStd_NamedData::SetString),
             R"#(Defines a named string. If the string already exists, it changes its value to <theString>.)#"  , py::arg("theName"),  py::arg("theString")
          )
        .def("ChangeStrings",
             (void (TDataStd_NamedData::*)(  const NCollection_DataMap<TCollection_ExtendedString, TCollection_ExtendedString> &  ) ) static_cast<void (TDataStd_NamedData::*)(  const NCollection_DataMap<TCollection_ExtendedString, TCollection_ExtendedString> &  ) >(&TDataStd_NamedData::ChangeStrings),
             R"#(Replace the container content by new content of the <theStrings>.)#"  , py::arg("theStrings")
          )
        .def("HasBytes",
             (bool (TDataStd_NamedData::*)() const) static_cast<bool (TDataStd_NamedData::*)() const>(&TDataStd_NamedData::HasBytes),
             R"#(Returns true if there are some named bytes in the attribute.)#" 
          )
        .def("HasByte",
             (bool (TDataStd_NamedData::*)(  const TCollection_ExtendedString &  ) const) static_cast<bool (TDataStd_NamedData::*)(  const TCollection_ExtendedString &  ) const>(&TDataStd_NamedData::HasByte),
             R"#(Returns true if the attribute contains this named byte.)#"  , py::arg("theName")
          )
        .def("GetByte",
             (uint8_t (TDataStd_NamedData::*)(  const TCollection_ExtendedString &  ) ) static_cast<uint8_t (TDataStd_NamedData::*)(  const TCollection_ExtendedString &  ) >(&TDataStd_NamedData::GetByte),
             R"#(Returns the named byte. It returns 0 if there is no such a named byte (use HasByte()).)#"  , py::arg("theName")
          )
        .def("SetByte",
             (void (TDataStd_NamedData::*)(  const TCollection_ExtendedString & ,   const uint8_t  ) ) static_cast<void (TDataStd_NamedData::*)(  const TCollection_ExtendedString & ,   const uint8_t  ) >(&TDataStd_NamedData::SetByte),
             R"#(Defines a named byte. If the byte already exists, it changes its value to <theByte>.)#"  , py::arg("theName"),  py::arg("theByte")
          )
        .def("ChangeBytes",
             (void (TDataStd_NamedData::*)(  const NCollection_DataMap<TCollection_ExtendedString, uint8_t> &  ) ) static_cast<void (TDataStd_NamedData::*)(  const NCollection_DataMap<TCollection_ExtendedString, uint8_t> &  ) >(&TDataStd_NamedData::ChangeBytes),
             R"#(Replace the container content by new content of the <theBytes>.)#"  , py::arg("theBytes")
          )
        .def("HasArraysOfIntegers",
             (bool (TDataStd_NamedData::*)() const) static_cast<bool (TDataStd_NamedData::*)() const>(&TDataStd_NamedData::HasArraysOfIntegers),
             R"#(Returns true if there are some named arrays of integer values in the attribute.)#" 
          )
        .def("HasArrayOfIntegers",
             (bool (TDataStd_NamedData::*)(  const TCollection_ExtendedString &  ) const) static_cast<bool (TDataStd_NamedData::*)(  const TCollection_ExtendedString &  ) const>(&TDataStd_NamedData::HasArrayOfIntegers),
             R"#(Returns true if the attribute contains this named array of integer values.)#"  , py::arg("theName")
          )
        .def("GetArrayOfIntegers",
             ( const handle<NCollection_HArray1<int>> & (TDataStd_NamedData::*)(  const TCollection_ExtendedString &  ) ) static_cast< const handle<NCollection_HArray1<int>> & (TDataStd_NamedData::*)(  const TCollection_ExtendedString &  ) >(&TDataStd_NamedData::GetArrayOfIntegers),
             R"#(Returns the named array of integer values. It returns a NULL Handle if there is no such a named array of integers (use HasArrayOfIntegers()).)#"  , py::arg("theName")
          )
        .def("SetArrayOfIntegers",
             (void (TDataStd_NamedData::*)(  const TCollection_ExtendedString & ,   const handle<NCollection_HArray1<int>> &  ) ) static_cast<void (TDataStd_NamedData::*)(  const TCollection_ExtendedString & ,   const handle<NCollection_HArray1<int>> &  ) >(&TDataStd_NamedData::SetArrayOfIntegers),
             R"#(Defines a named array of integer values.)#"  , py::arg("theName"),  py::arg("theArrayOfIntegers")
          )
        .def("ChangeArraysOfIntegers",
             (void (TDataStd_NamedData::*)(  const NCollection_DataMap<TCollection_ExtendedString, handle<NCollection_HArray1<int>>> &  ) ) static_cast<void (TDataStd_NamedData::*)(  const NCollection_DataMap<TCollection_ExtendedString, handle<NCollection_HArray1<int>>> &  ) >(&TDataStd_NamedData::ChangeArraysOfIntegers),
             R"#(Replace the container content by new content of the <theArraysOfIntegers>.)#"  , py::arg("theArraysOfIntegers")
          )
        .def("HasArraysOfReals",
             (bool (TDataStd_NamedData::*)() const) static_cast<bool (TDataStd_NamedData::*)() const>(&TDataStd_NamedData::HasArraysOfReals),
             R"#(Returns true if there are some named arrays of real values in the attribute.)#" 
          )
        .def("HasArrayOfReals",
             (bool (TDataStd_NamedData::*)(  const TCollection_ExtendedString &  ) const) static_cast<bool (TDataStd_NamedData::*)(  const TCollection_ExtendedString &  ) const>(&TDataStd_NamedData::HasArrayOfReals),
             R"#(Returns true if the attribute contains this named array of real values.)#"  , py::arg("theName")
          )
        .def("GetArrayOfReals",
             ( const handle<NCollection_HArray1<double>> & (TDataStd_NamedData::*)(  const TCollection_ExtendedString &  ) ) static_cast< const handle<NCollection_HArray1<double>> & (TDataStd_NamedData::*)(  const TCollection_ExtendedString &  ) >(&TDataStd_NamedData::GetArrayOfReals),
             R"#(Returns the named array of real values. It returns a NULL Handle if there is no such a named array of reals (use HasArrayOfReals()).)#"  , py::arg("theName")
          )
        .def("SetArrayOfReals",
             (void (TDataStd_NamedData::*)(  const TCollection_ExtendedString & ,   const handle<NCollection_HArray1<double>> &  ) ) static_cast<void (TDataStd_NamedData::*)(  const TCollection_ExtendedString & ,   const handle<NCollection_HArray1<double>> &  ) >(&TDataStd_NamedData::SetArrayOfReals),
             R"#(Defines a named array of real values.)#"  , py::arg("theName"),  py::arg("theArrayOfReals")
          )
        .def("ChangeArraysOfReals",
             (void (TDataStd_NamedData::*)(  const NCollection_DataMap<TCollection_ExtendedString, handle<NCollection_HArray1<double>>> &  ) ) static_cast<void (TDataStd_NamedData::*)(  const NCollection_DataMap<TCollection_ExtendedString, handle<NCollection_HArray1<double>>> &  ) >(&TDataStd_NamedData::ChangeArraysOfReals),
             R"#(Replace the container content by new content of the <theArraysOfReals>.)#"  , py::arg("theArraysOfReals")
          )
        .def("Clear",
             (void (TDataStd_NamedData::*)() ) static_cast<void (TDataStd_NamedData::*)() >(&TDataStd_NamedData::Clear),
             R"#(Clear data.)#" 
          )
        .def("HasDeferredData",
             (bool (TDataStd_NamedData::*)() const) static_cast<bool (TDataStd_NamedData::*)() const>(&TDataStd_NamedData::HasDeferredData),
             R"#(Returns TRUE if some data is not loaded from deferred storage and can be loaded using LoadDeferredData().)#" 
          )
        .def("LoadDeferredData",
             (bool (TDataStd_NamedData::*)( bool  ) ) static_cast<bool (TDataStd_NamedData::*)( bool  ) >(&TDataStd_NamedData::LoadDeferredData),
             R"#(Load data from deferred storage, without calling Backup(). As result, the content of the object will be overridden by data from deferred storage (which is normally read-only).)#"  , py::arg("theToKeepDeferred")=static_cast<bool>(false)
          )
        .def("UnloadDeferredData",
             (bool (TDataStd_NamedData::*)() ) static_cast<bool (TDataStd_NamedData::*)() >(&TDataStd_NamedData::UnloadDeferredData),
             R"#(Releases data if object has connected deferred storage, without calling Backup(). WARNING! This operation does not unload modifications to deferred storage (normally it is read-only), so that modifications will be discarded (if any).)#" 
          )
        .def("clear",
             (void (TDataStd_NamedData::*)() ) static_cast<void (TDataStd_NamedData::*)() >(&TDataStd_NamedData::clear),
             R"#(Clear data without calling Backup().)#" 
          )
        .def("setInteger",
             (void (TDataStd_NamedData::*)(  const TCollection_ExtendedString & ,   const int  ) ) static_cast<void (TDataStd_NamedData::*)(  const TCollection_ExtendedString & ,   const int  ) >(&TDataStd_NamedData::setInteger),
             R"#(Defines a named integer (without calling Backup).)#"  , py::arg("theName"),  py::arg("theInteger")
          )
        .def("setReal",
             (void (TDataStd_NamedData::*)(  const TCollection_ExtendedString & ,   const double  ) ) static_cast<void (TDataStd_NamedData::*)(  const TCollection_ExtendedString & ,   const double  ) >(&TDataStd_NamedData::setReal),
             R"#(Defines a named real (without calling Backup).)#"  , py::arg("theName"),  py::arg("theReal")
          )
        .def("setString",
             (void (TDataStd_NamedData::*)(  const TCollection_ExtendedString & ,   const TCollection_ExtendedString &  ) ) static_cast<void (TDataStd_NamedData::*)(  const TCollection_ExtendedString & ,   const TCollection_ExtendedString &  ) >(&TDataStd_NamedData::setString),
             R"#(Defines a named string (without calling Backup).)#"  , py::arg("theName"),  py::arg("theString")
          )
        .def("setByte",
             (void (TDataStd_NamedData::*)(  const TCollection_ExtendedString & ,   const uint8_t  ) ) static_cast<void (TDataStd_NamedData::*)(  const TCollection_ExtendedString & ,   const uint8_t  ) >(&TDataStd_NamedData::setByte),
             R"#(Defines a named byte (without calling Backup).)#"  , py::arg("theName"),  py::arg("theByte")
          )
        .def("setArrayOfIntegers",
             (void (TDataStd_NamedData::*)(  const TCollection_ExtendedString & ,   const handle<NCollection_HArray1<int>> &  ) ) static_cast<void (TDataStd_NamedData::*)(  const TCollection_ExtendedString & ,   const handle<NCollection_HArray1<int>> &  ) >(&TDataStd_NamedData::setArrayOfIntegers),
             R"#(Defines a named array of integer values (without calling Backup).)#"  , py::arg("theName"),  py::arg("theArrayOfIntegers")
          )
        .def("setArrayOfReals",
             (void (TDataStd_NamedData::*)(  const TCollection_ExtendedString & ,   const handle<NCollection_HArray1<double>> &  ) ) static_cast<void (TDataStd_NamedData::*)(  const TCollection_ExtendedString & ,   const handle<NCollection_HArray1<double>> &  ) >(&TDataStd_NamedData::setArrayOfReals),
             R"#(Defines a named array of real values (without calling Backup).)#"  , py::arg("theName"),  py::arg("theArrayOfReals")
          )
        .def("Restore",
             (void (TDataStd_NamedData::*)(  const handle<TDF_Attribute> &  ) ) static_cast<void (TDataStd_NamedData::*)(  const handle<TDF_Attribute> &  ) >(&TDataStd_NamedData::Restore),
             R"#()#"  , py::arg("With")
          )
        .def("NewEmpty",
             (handle<TDF_Attribute> (TDataStd_NamedData::*)() const) static_cast<handle<TDF_Attribute> (TDataStd_NamedData::*)() const>(&TDataStd_NamedData::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (void (TDataStd_NamedData::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const) static_cast<void (TDataStd_NamedData::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const>(&TDataStd_NamedData::Paste),
             R"#()#"  , py::arg("Into"),  py::arg("RT")
          )
        .def("Dump",
             (Standard_OStream & (TDataStd_NamedData::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDataStd_NamedData::*)( Standard_OStream &  ) const>(&TDataStd_NamedData::Dump),
             R"#()#"  , py::arg("anOS")
          )
        .def("DumpJson",
             (void (TDataStd_NamedData::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDataStd_NamedData::*)( Standard_OStream & ,  int  ) const>(&TDataStd_NamedData::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("GetID_s",
                    ( const Standard_GUID & (*)() ) static_cast< const Standard_GUID & (*)() >(&TDataStd_NamedData::GetID),
                    R"#(Returns the ID of the named data attribute.)#" 
          )
        .def_static("Set_s",
                    (handle<TDataStd_NamedData> (*)(  const TDF_Label &  ) ) static_cast<handle<TDataStd_NamedData> (*)(  const TDF_Label &  ) >(&TDataStd_NamedData::Set),
                    R"#(Finds or creates a named data attribute.)#"  , py::arg("label")
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_NamedData::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_NamedData::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("GetIntegersContainer",
             ( const NCollection_DataMap<TCollection_ExtendedString, int> & (TDataStd_NamedData::*)() ) static_cast< const NCollection_DataMap<TCollection_ExtendedString, int> & (TDataStd_NamedData::*)() >(&TDataStd_NamedData::GetIntegersContainer),
             R"#(Returns the internal container of named integers.)#"
             
         )
       .def("GetRealsContainer",
             ( const NCollection_DataMap<TCollection_ExtendedString, double> & (TDataStd_NamedData::*)() ) static_cast< const NCollection_DataMap<TCollection_ExtendedString, double> & (TDataStd_NamedData::*)() >(&TDataStd_NamedData::GetRealsContainer),
             R"#(Returns the internal container of named reals.)#"
             
         )
       .def("GetStringsContainer",
             ( const NCollection_DataMap<TCollection_ExtendedString, TCollection_ExtendedString> & (TDataStd_NamedData::*)() ) static_cast< const NCollection_DataMap<TCollection_ExtendedString, TCollection_ExtendedString> & (TDataStd_NamedData::*)() >(&TDataStd_NamedData::GetStringsContainer),
             R"#(Returns the internal container of named strings.)#"
             
         )
       .def("GetBytesContainer",
             ( const NCollection_DataMap<TCollection_ExtendedString, uint8_t> & (TDataStd_NamedData::*)() ) static_cast< const NCollection_DataMap<TCollection_ExtendedString, uint8_t> & (TDataStd_NamedData::*)() >(&TDataStd_NamedData::GetBytesContainer),
             R"#(Returns the internal container of named bytes.)#"
             
         )
       .def("GetArraysOfIntegersContainer",
             ( const NCollection_DataMap<TCollection_ExtendedString, handle<NCollection_HArray1<int>>> & (TDataStd_NamedData::*)() ) static_cast< const NCollection_DataMap<TCollection_ExtendedString, handle<NCollection_HArray1<int>>> & (TDataStd_NamedData::*)() >(&TDataStd_NamedData::GetArraysOfIntegersContainer),
             R"#(Returns the internal container of named arrays of integer values.)#"
             
         )
       .def("GetArraysOfRealsContainer",
             ( const NCollection_DataMap<TCollection_ExtendedString, handle<NCollection_HArray1<double>>> & (TDataStd_NamedData::*)() ) static_cast< const NCollection_DataMap<TCollection_ExtendedString, handle<NCollection_HArray1<double>>> & (TDataStd_NamedData::*)() >(&TDataStd_NamedData::GetArraysOfRealsContainer),
             R"#(Returns the internal container of named arrays of real values.)#"
             
         )
       .def("ID",
             ( const Standard_GUID & (TDataStd_NamedData::*)() const) static_cast< const Standard_GUID & (TDataStd_NamedData::*)() const>(&TDataStd_NamedData::ID),
             R"#()#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_NamedData::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_NamedData::*)() const>(&TDataStd_NamedData::DynamicType),
             R"#()#"
             
         )
;

    // Class TDataStd_Real from ./opencascade/TDataStd_Real.hxx
    klass = m.attr("TDataStd_Real");


    // nested enums

    static_cast<py::class_<TDataStd_Real ,opencascade::handle<TDataStd_Real>  , TDF_Attribute >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetDimension",
             (void (TDataStd_Real::*)(  const TDataStd_RealEnum  ) ) static_cast<void (TDataStd_Real::*)(  const TDataStd_RealEnum  ) >(&TDataStd_Real::SetDimension),
             R"#(Obsolete method that will be removed in next versions. This field is not supported in the persistence mechanism.)#"  , py::arg("DIM")
          )
        .def("GetDimension",
             (TDataStd_RealEnum (TDataStd_Real::*)() const) static_cast<TDataStd_RealEnum (TDataStd_Real::*)() const>(&TDataStd_Real::GetDimension),
             R"#(Obsolete method that will be removed in next versions. This field is not supported in the persistence mechanism.)#" 
          )
        .def("Set",
             (void (TDataStd_Real::*)(  const double  ) ) static_cast<void (TDataStd_Real::*)(  const double  ) >(&TDataStd_Real::Set),
             R"#(Sets the real number V.)#"  , py::arg("V")
          )
        .def("SetID",
             (void (TDataStd_Real::*)(  const Standard_GUID &  ) ) static_cast<void (TDataStd_Real::*)(  const Standard_GUID &  ) >(&TDataStd_Real::SetID),
             R"#(Sets the explicit GUID for the attribute.)#"  , py::arg("guid")
          )
        .def("SetID",
             (void (TDataStd_Real::*)() ) static_cast<void (TDataStd_Real::*)() >(&TDataStd_Real::SetID),
             R"#(Sets default GUID for the attribute.)#" 
          )
        .def("Get",
             (double (TDataStd_Real::*)() const) static_cast<double (TDataStd_Real::*)() const>(&TDataStd_Real::Get),
             R"#(Returns the real number value contained in the attribute.)#" 
          )
        .def("IsCaptured",
             (bool (TDataStd_Real::*)() const) static_cast<bool (TDataStd_Real::*)() const>(&TDataStd_Real::IsCaptured),
             R"#(Returns True if there is a reference on the same label)#" 
          )
        .def("Restore",
             (void (TDataStd_Real::*)(  const handle<TDF_Attribute> &  ) ) static_cast<void (TDataStd_Real::*)(  const handle<TDF_Attribute> &  ) >(&TDataStd_Real::Restore),
             R"#()#"  , py::arg("With")
          )
        .def("NewEmpty",
             (handle<TDF_Attribute> (TDataStd_Real::*)() const) static_cast<handle<TDF_Attribute> (TDataStd_Real::*)() const>(&TDataStd_Real::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (void (TDataStd_Real::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const) static_cast<void (TDataStd_Real::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const>(&TDataStd_Real::Paste),
             R"#()#"  , py::arg("Into"),  py::arg("RT")
          )
        .def("Dump",
             (Standard_OStream & (TDataStd_Real::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDataStd_Real::*)( Standard_OStream &  ) const>(&TDataStd_Real::Dump),
             R"#()#"  , py::arg("anOS")
          )
        .def("DumpJson",
             (void (TDataStd_Real::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDataStd_Real::*)( Standard_OStream & ,  int  ) const>(&TDataStd_Real::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("GetID_s",
                    ( const Standard_GUID & (*)() ) static_cast< const Standard_GUID & (*)() >(&TDataStd_Real::GetID),
                    R"#(class methods ============= Returns the default GUID for real numbers.)#" 
          )
        .def_static("Set_s",
                    (handle<TDataStd_Real> (*)(  const TDF_Label & ,   const double  ) ) static_cast<handle<TDataStd_Real> (*)(  const TDF_Label & ,   const double  ) >(&TDataStd_Real::Set),
                    R"#(Finds, or creates, a Real attribute with default GUID and sets <value>. The Real attribute is returned. The Real dimension is Scalar by default. Use SetDimension to overwrite. Real methods ============)#"  , py::arg("label"),  py::arg("value")
          )
        .def_static("Set_s",
                    (handle<TDataStd_Real> (*)(  const TDF_Label & ,   const Standard_GUID & ,   const double  ) ) static_cast<handle<TDataStd_Real> (*)(  const TDF_Label & ,   const Standard_GUID & ,   const double  ) >(&TDataStd_Real::Set),
                    R"#(Finds, or creates, a Real attribute with explicit GUID and sets <value>. The Real attribute is returned. Real methods ============)#"  , py::arg("label"),  py::arg("guid"),  py::arg("value")
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_Real::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_Real::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("ID",
             ( const Standard_GUID & (TDataStd_Real::*)() const) static_cast< const Standard_GUID & (TDataStd_Real::*)() const>(&TDataStd_Real::ID),
             R"#()#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_Real::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_Real::*)() const>(&TDataStd_Real::DynamicType),
             R"#()#"
             
         )
;

    // Class TDataStd_RealArray from ./opencascade/TDataStd_RealArray.hxx
    klass = m.attr("TDataStd_RealArray");


    // nested enums

    static_cast<py::class_<TDataStd_RealArray ,opencascade::handle<TDataStd_RealArray>  , TDF_Attribute >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (TDataStd_RealArray::*)(  const int ,   const int  ) ) static_cast<void (TDataStd_RealArray::*)(  const int ,   const int  ) >(&TDataStd_RealArray::Init),
             R"#(Initialize the inner array with bounds from <lower> to <upper>)#"  , py::arg("lower"),  py::arg("upper")
          )
        .def("SetID",
             (void (TDataStd_RealArray::*)(  const Standard_GUID &  ) ) static_cast<void (TDataStd_RealArray::*)(  const Standard_GUID &  ) >(&TDataStd_RealArray::SetID),
             R"#(Sets the explicit GUID (user defined) for the attribute.)#"  , py::arg("theGuid")
          )
        .def("SetID",
             (void (TDataStd_RealArray::*)() ) static_cast<void (TDataStd_RealArray::*)() >(&TDataStd_RealArray::SetID),
             R"#(Sets default GUID for the attribute.)#" 
          )
        .def("SetValue",
             (void (TDataStd_RealArray::*)(  const int ,   const double  ) ) static_cast<void (TDataStd_RealArray::*)(  const int ,   const double  ) >(&TDataStd_RealArray::SetValue),
             R"#(Sets the <Index>th element of the array to <Value> OutOfRange exception is raised if <Index> doesn't respect Lower and Upper bounds of the internal array.)#"  , py::arg("Index"),  py::arg("Value")
          )
        .def("Value",
             (double (TDataStd_RealArray::*)(  const int  ) const) static_cast<double (TDataStd_RealArray::*)(  const int  ) const>(&TDataStd_RealArray::Value),
             R"#(Return the value of the <Index>th element of the array)#"  , py::arg("Index")
          )
        .def("Lower",
             (int (TDataStd_RealArray::*)() const) static_cast<int (TDataStd_RealArray::*)() const>(&TDataStd_RealArray::Lower),
             R"#(Returns the lower boundary of the array.)#" 
          )
        .def("Upper",
             (int (TDataStd_RealArray::*)() const) static_cast<int (TDataStd_RealArray::*)() const>(&TDataStd_RealArray::Upper),
             R"#(Returns the upper boundary of the array.)#" 
          )
        .def("Length",
             (int (TDataStd_RealArray::*)() const) static_cast<int (TDataStd_RealArray::*)() const>(&TDataStd_RealArray::Length),
             R"#(Returns the number of elements of the array of reals in terms of the number of elements it contains.)#" 
          )
        .def("ChangeArray",
             (void (TDataStd_RealArray::*)(  const handle<NCollection_HArray1<double>> & ,   const bool  ) ) static_cast<void (TDataStd_RealArray::*)(  const handle<NCollection_HArray1<double>> & ,   const bool  ) >(&TDataStd_RealArray::ChangeArray),
             R"#(Sets the inner array <myValue> of the RealArray attribute to <newArray>. If value of <newArray> differs from <myValue>, Backup performed and myValue refers to new instance of HArray1OfReal that holds <newArray> values If <isCheckItems> equal True each item of <newArray> will be checked with each item of <myValue> for coincidence (to avoid backup).)#"  , py::arg("newArray"),  py::arg("isCheckItems")=static_cast< const bool>(true)
          )
        .def("GetDelta",
             (bool (TDataStd_RealArray::*)() const) static_cast<bool (TDataStd_RealArray::*)() const>(&TDataStd_RealArray::GetDelta),
             R"#()#" 
          )
        .def("SetDelta",
             (void (TDataStd_RealArray::*)(  const bool  ) ) static_cast<void (TDataStd_RealArray::*)(  const bool  ) >(&TDataStd_RealArray::SetDelta),
             R"#(for internal use only!)#"  , py::arg("isDelta")
          )
        .def("Restore",
             (void (TDataStd_RealArray::*)(  const handle<TDF_Attribute> &  ) ) static_cast<void (TDataStd_RealArray::*)(  const handle<TDF_Attribute> &  ) >(&TDataStd_RealArray::Restore),
             R"#()#"  , py::arg("With")
          )
        .def("NewEmpty",
             (handle<TDF_Attribute> (TDataStd_RealArray::*)() const) static_cast<handle<TDF_Attribute> (TDataStd_RealArray::*)() const>(&TDataStd_RealArray::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (void (TDataStd_RealArray::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const) static_cast<void (TDataStd_RealArray::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const>(&TDataStd_RealArray::Paste),
             R"#(Note. Uses inside ChangeArray() method)#"  , py::arg("Into"),  py::arg("RT")
          )
        .def("Dump",
             (Standard_OStream & (TDataStd_RealArray::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDataStd_RealArray::*)( Standard_OStream &  ) const>(&TDataStd_RealArray::Dump),
             R"#()#"  , py::arg("anOS")
          )
        .def("DeltaOnModification",
             (handle<TDF_DeltaOnModification> (TDataStd_RealArray::*)(  const handle<TDF_Attribute> &  ) const) static_cast<handle<TDF_DeltaOnModification> (TDataStd_RealArray::*)(  const handle<TDF_Attribute> &  ) const>(&TDataStd_RealArray::DeltaOnModification),
             R"#(Makes a DeltaOnModification between <me> and <anOldAttribute>.)#"  , py::arg("anOldAttribute")
          )
        .def("DumpJson",
             (void (TDataStd_RealArray::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDataStd_RealArray::*)( Standard_OStream & ,  int  ) const>(&TDataStd_RealArray::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_RealArray::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_RealArray::get_type_descriptor),
                    R"#()#" 
          )
        .def_static("GetID_s",
                    ( const Standard_GUID & (*)() ) static_cast< const Standard_GUID & (*)() >(&TDataStd_RealArray::GetID),
                    R"#(class methods ============= Returns the GUID for arrays of reals.)#" 
          )
        .def_static("Set_s",
                    (handle<TDataStd_RealArray> (*)(  const TDF_Label & ,   const int ,   const int ,   const bool  ) ) static_cast<handle<TDataStd_RealArray> (*)(  const TDF_Label & ,   const int ,   const int ,   const bool  ) >(&TDataStd_RealArray::Set),
                    R"#(Finds or creates on the <label> a real array attribute with the specified <lower> and <upper> boundaries. If <isDelta> == False, DefaultDeltaOnModification is used. If <isDelta> == True, DeltaOnModification of the current attribute is used. If attribute is already set, input parameter <isDelta> is refused and the found attribute returned.)#"  , py::arg("label"),  py::arg("lower"),  py::arg("upper"),  py::arg("isDelta")=static_cast< const bool>(false)
          )
        .def_static("Set_s",
                    (handle<TDataStd_RealArray> (*)(  const TDF_Label & ,   const Standard_GUID & ,   const int ,   const int ,   const bool  ) ) static_cast<handle<TDataStd_RealArray> (*)(  const TDF_Label & ,   const Standard_GUID & ,   const int ,   const int ,   const bool  ) >(&TDataStd_RealArray::Set),
                    R"#(Finds, or creates, an RealArray attribute with explicit user defined <guid>. The RealArray attribute is returned.)#"  , py::arg("label"),  py::arg("theGuid"),  py::arg("lower"),  py::arg("upper"),  py::arg("isDelta")=static_cast< const bool>(false)
          )
    // static methods using call by reference i.s.o. return
    // operators
        .def("__call__",
             (double (TDataStd_RealArray::*)(  const int  ) const) static_cast<double (TDataStd_RealArray::*)(  const int  ) const>(&TDataStd_RealArray::operator()),
             py::is_operator(),
             R"#()#"  , py::arg("Index")
          )
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_RealArray::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_RealArray::*)() const>(&TDataStd_RealArray::DynamicType),
             R"#()#"
             
         )
       .def("Array",
             ( const handle<NCollection_HArray1<double>> & (TDataStd_RealArray::*)() const) static_cast< const handle<NCollection_HArray1<double>> & (TDataStd_RealArray::*)() const>(&TDataStd_RealArray::Array),
             R"#(Returns the handle of this array of reals.)#"
             
         )
       .def("ID",
             ( const Standard_GUID & (TDataStd_RealArray::*)() const) static_cast< const Standard_GUID & (TDataStd_RealArray::*)() const>(&TDataStd_RealArray::ID),
             R"#()#"
             
         )
;

    // Class TDataStd_RealList from ./opencascade/TDataStd_RealList.hxx
    klass = m.attr("TDataStd_RealList");


    // nested enums

    static_cast<py::class_<TDataStd_RealList ,opencascade::handle<TDataStd_RealList>  , TDF_Attribute >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("IsEmpty",
             (bool (TDataStd_RealList::*)() const) static_cast<bool (TDataStd_RealList::*)() const>(&TDataStd_RealList::IsEmpty),
             R"#()#" 
          )
        .def("Extent",
             (int (TDataStd_RealList::*)() const) static_cast<int (TDataStd_RealList::*)() const>(&TDataStd_RealList::Extent),
             R"#()#" 
          )
        .def("Prepend",
             (void (TDataStd_RealList::*)(  const double  ) ) static_cast<void (TDataStd_RealList::*)(  const double  ) >(&TDataStd_RealList::Prepend),
             R"#()#"  , py::arg("value")
          )
        .def("Append",
             (void (TDataStd_RealList::*)(  const double  ) ) static_cast<void (TDataStd_RealList::*)(  const double  ) >(&TDataStd_RealList::Append),
             R"#()#"  , py::arg("value")
          )
        .def("SetID",
             (void (TDataStd_RealList::*)(  const Standard_GUID &  ) ) static_cast<void (TDataStd_RealList::*)(  const Standard_GUID &  ) >(&TDataStd_RealList::SetID),
             R"#(Sets the explicit GUID (user defined) for the attribute.)#"  , py::arg("theGuid")
          )
        .def("SetID",
             (void (TDataStd_RealList::*)() ) static_cast<void (TDataStd_RealList::*)() >(&TDataStd_RealList::SetID),
             R"#(Sets default GUID for the attribute.)#" 
          )
        .def("InsertBefore",
             (bool (TDataStd_RealList::*)(  const double ,   const double  ) ) static_cast<bool (TDataStd_RealList::*)(  const double ,   const double  ) >(&TDataStd_RealList::InsertBefore),
             R"#(Inserts the <value> before the first meet of <before_value>.)#"  , py::arg("value"),  py::arg("before_value")
          )
        .def("InsertBeforeByIndex",
             (bool (TDataStd_RealList::*)(  const int ,   const double  ) ) static_cast<bool (TDataStd_RealList::*)(  const int ,   const double  ) >(&TDataStd_RealList::InsertBeforeByIndex),
             R"#(Inserts the <value> before the <index> position. The indices start with 1 .. Extent().)#"  , py::arg("index"),  py::arg("before_value")
          )
        .def("InsertAfter",
             (bool (TDataStd_RealList::*)(  const double ,   const double  ) ) static_cast<bool (TDataStd_RealList::*)(  const double ,   const double  ) >(&TDataStd_RealList::InsertAfter),
             R"#(Inserts the <value> after the first meet of <after_value>.)#"  , py::arg("value"),  py::arg("after_value")
          )
        .def("InsertAfterByIndex",
             (bool (TDataStd_RealList::*)(  const int ,   const double  ) ) static_cast<bool (TDataStd_RealList::*)(  const int ,   const double  ) >(&TDataStd_RealList::InsertAfterByIndex),
             R"#(Inserts the <value> after the <index> position. The indices start with 1 .. Extent().)#"  , py::arg("index"),  py::arg("after_value")
          )
        .def("Remove",
             (bool (TDataStd_RealList::*)(  const double  ) ) static_cast<bool (TDataStd_RealList::*)(  const double  ) >(&TDataStd_RealList::Remove),
             R"#(Removes the first meet of the <value>.)#"  , py::arg("value")
          )
        .def("RemoveByIndex",
             (bool (TDataStd_RealList::*)(  const int  ) ) static_cast<bool (TDataStd_RealList::*)(  const int  ) >(&TDataStd_RealList::RemoveByIndex),
             R"#(Removes a value at <index> position.)#"  , py::arg("index")
          )
        .def("Clear",
             (void (TDataStd_RealList::*)() ) static_cast<void (TDataStd_RealList::*)() >(&TDataStd_RealList::Clear),
             R"#()#" 
          )
        .def("First",
             (double (TDataStd_RealList::*)() const) static_cast<double (TDataStd_RealList::*)() const>(&TDataStd_RealList::First),
             R"#()#" 
          )
        .def("Last",
             (double (TDataStd_RealList::*)() const) static_cast<double (TDataStd_RealList::*)() const>(&TDataStd_RealList::Last),
             R"#()#" 
          )
        .def("Restore",
             (void (TDataStd_RealList::*)(  const handle<TDF_Attribute> &  ) ) static_cast<void (TDataStd_RealList::*)(  const handle<TDF_Attribute> &  ) >(&TDataStd_RealList::Restore),
             R"#()#"  , py::arg("With")
          )
        .def("NewEmpty",
             (handle<TDF_Attribute> (TDataStd_RealList::*)() const) static_cast<handle<TDF_Attribute> (TDataStd_RealList::*)() const>(&TDataStd_RealList::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (void (TDataStd_RealList::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const) static_cast<void (TDataStd_RealList::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const>(&TDataStd_RealList::Paste),
             R"#()#"  , py::arg("Into"),  py::arg("RT")
          )
        .def("Dump",
             (Standard_OStream & (TDataStd_RealList::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDataStd_RealList::*)( Standard_OStream &  ) const>(&TDataStd_RealList::Dump),
             R"#()#"  , py::arg("anOS")
          )
        .def("DumpJson",
             (void (TDataStd_RealList::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDataStd_RealList::*)( Standard_OStream & ,  int  ) const>(&TDataStd_RealList::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("GetID_s",
                    ( const Standard_GUID & (*)() ) static_cast< const Standard_GUID & (*)() >(&TDataStd_RealList::GetID),
                    R"#(Static methods ============== Returns the ID of the list of doubles attribute.)#" 
          )
        .def_static("Set_s",
                    (handle<TDataStd_RealList> (*)(  const TDF_Label &  ) ) static_cast<handle<TDataStd_RealList> (*)(  const TDF_Label &  ) >(&TDataStd_RealList::Set),
                    R"#(Finds or creates a list of double values attribute.)#"  , py::arg("label")
          )
        .def_static("Set_s",
                    (handle<TDataStd_RealList> (*)(  const TDF_Label & ,   const Standard_GUID &  ) ) static_cast<handle<TDataStd_RealList> (*)(  const TDF_Label & ,   const Standard_GUID &  ) >(&TDataStd_RealList::Set),
                    R"#(Finds or creates a list of double values attribute with explicit user defined <guid>.)#"  , py::arg("label"),  py::arg("theGuid")
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_RealList::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_RealList::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("List",
             ( const NCollection_List<double> & (TDataStd_RealList::*)() const) static_cast< const NCollection_List<double> & (TDataStd_RealList::*)() const>(&TDataStd_RealList::List),
             R"#()#"
             
         )
       .def("ID",
             ( const Standard_GUID & (TDataStd_RealList::*)() const) static_cast< const Standard_GUID & (TDataStd_RealList::*)() const>(&TDataStd_RealList::ID),
             R"#()#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_RealList::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_RealList::*)() const>(&TDataStd_RealList::DynamicType),
             R"#()#"
             
         )
;

    // Class TDataStd_ReferenceArray from ./opencascade/TDataStd_ReferenceArray.hxx
    klass = m.attr("TDataStd_ReferenceArray");


    // nested enums

    static_cast<py::class_<TDataStd_ReferenceArray ,opencascade::handle<TDataStd_ReferenceArray>  , TDF_Attribute >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (TDataStd_ReferenceArray::*)(  const int ,   const int  ) ) static_cast<void (TDataStd_ReferenceArray::*)(  const int ,   const int  ) >(&TDataStd_ReferenceArray::Init),
             R"#(Initialize the inner array with bounds from <lower> to <upper>)#"  , py::arg("lower"),  py::arg("upper")
          )
        .def("SetValue",
             (void (TDataStd_ReferenceArray::*)(  const int ,   const TDF_Label &  ) ) static_cast<void (TDataStd_ReferenceArray::*)(  const int ,   const TDF_Label &  ) >(&TDataStd_ReferenceArray::SetValue),
             R"#(Sets the <Index>th element of the array to <Value> OutOfRange exception is raised if <Index> doesn't respect Lower and Upper bounds of the internal array.)#"  , py::arg("index"),  py::arg("value")
          )
        .def("SetID",
             (void (TDataStd_ReferenceArray::*)(  const Standard_GUID &  ) ) static_cast<void (TDataStd_ReferenceArray::*)(  const Standard_GUID &  ) >(&TDataStd_ReferenceArray::SetID),
             R"#(Sets the explicit GUID (user defined) for the attribute.)#"  , py::arg("theGuid")
          )
        .def("SetID",
             (void (TDataStd_ReferenceArray::*)() ) static_cast<void (TDataStd_ReferenceArray::*)() >(&TDataStd_ReferenceArray::SetID),
             R"#(Sets default GUID for the attribute.)#" 
          )
        .def("Value",
             (TDF_Label (TDataStd_ReferenceArray::*)(  const int  ) const) static_cast<TDF_Label (TDataStd_ReferenceArray::*)(  const int  ) const>(&TDataStd_ReferenceArray::Value),
             R"#(Returns the value of the <Index>th element of the array.)#"  , py::arg("Index")
          )
        .def("Lower",
             (int (TDataStd_ReferenceArray::*)() const) static_cast<int (TDataStd_ReferenceArray::*)() const>(&TDataStd_ReferenceArray::Lower),
             R"#(Returns the lower boundary of the array.)#" 
          )
        .def("Upper",
             (int (TDataStd_ReferenceArray::*)() const) static_cast<int (TDataStd_ReferenceArray::*)() const>(&TDataStd_ReferenceArray::Upper),
             R"#(Returns the upper boundary of the array.)#" 
          )
        .def("Length",
             (int (TDataStd_ReferenceArray::*)() const) static_cast<int (TDataStd_ReferenceArray::*)() const>(&TDataStd_ReferenceArray::Length),
             R"#(Returns the number of elements in the array.)#" 
          )
        .def("SetInternalArray",
             (void (TDataStd_ReferenceArray::*)(  const handle<NCollection_HArray1<TDF_Label>> & ,   const bool  ) ) static_cast<void (TDataStd_ReferenceArray::*)(  const handle<NCollection_HArray1<TDF_Label>> & ,   const bool  ) >(&TDataStd_ReferenceArray::SetInternalArray),
             R"#()#"  , py::arg("values"),  py::arg("isCheckItems")=static_cast< const bool>(true)
          )
        .def("Restore",
             (void (TDataStd_ReferenceArray::*)(  const handle<TDF_Attribute> &  ) ) static_cast<void (TDataStd_ReferenceArray::*)(  const handle<TDF_Attribute> &  ) >(&TDataStd_ReferenceArray::Restore),
             R"#()#"  , py::arg("With")
          )
        .def("NewEmpty",
             (handle<TDF_Attribute> (TDataStd_ReferenceArray::*)() const) static_cast<handle<TDF_Attribute> (TDataStd_ReferenceArray::*)() const>(&TDataStd_ReferenceArray::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (void (TDataStd_ReferenceArray::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const) static_cast<void (TDataStd_ReferenceArray::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const>(&TDataStd_ReferenceArray::Paste),
             R"#()#"  , py::arg("Into"),  py::arg("RT")
          )
        .def("References",
             (void (TDataStd_ReferenceArray::*)(  const handle<TDF_DataSet> &  ) const) static_cast<void (TDataStd_ReferenceArray::*)(  const handle<TDF_DataSet> &  ) const>(&TDataStd_ReferenceArray::References),
             R"#()#"  , py::arg("DS")
          )
        .def("Dump",
             (Standard_OStream & (TDataStd_ReferenceArray::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDataStd_ReferenceArray::*)( Standard_OStream &  ) const>(&TDataStd_ReferenceArray::Dump),
             R"#()#"  , py::arg("anOS")
          )
        .def("DumpJson",
             (void (TDataStd_ReferenceArray::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDataStd_ReferenceArray::*)( Standard_OStream & ,  int  ) const>(&TDataStd_ReferenceArray::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("GetID_s",
                    ( const Standard_GUID & (*)() ) static_cast< const Standard_GUID & (*)() >(&TDataStd_ReferenceArray::GetID),
                    R"#(Static methods ============== Returns the ID of the array of references (labels) attribute.)#" 
          )
        .def_static("Set_s",
                    (handle<TDataStd_ReferenceArray> (*)(  const TDF_Label & ,   const int ,   const int  ) ) static_cast<handle<TDataStd_ReferenceArray> (*)(  const TDF_Label & ,   const int ,   const int  ) >(&TDataStd_ReferenceArray::Set),
                    R"#(Finds or creates an array of reference values (labels) attribute.)#"  , py::arg("label"),  py::arg("lower"),  py::arg("upper")
          )
        .def_static("Set_s",
                    (handle<TDataStd_ReferenceArray> (*)(  const TDF_Label & ,   const Standard_GUID & ,   const int ,   const int  ) ) static_cast<handle<TDataStd_ReferenceArray> (*)(  const TDF_Label & ,   const Standard_GUID & ,   const int ,   const int  ) >(&TDataStd_ReferenceArray::Set),
                    R"#(Finds or creates an array of reference values (labels) attribute with explicit user defined <guid>.)#"  , py::arg("label"),  py::arg("theGuid"),  py::arg("lower"),  py::arg("upper")
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_ReferenceArray::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_ReferenceArray::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
        .def("__call__",
             (TDF_Label (TDataStd_ReferenceArray::*)(  const int  ) const) static_cast<TDF_Label (TDataStd_ReferenceArray::*)(  const int  ) const>(&TDataStd_ReferenceArray::operator()),
             py::is_operator(),
             R"#()#"  , py::arg("Index")
          )
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("InternalArray",
             ( const handle<NCollection_HArray1<TDF_Label>> & (TDataStd_ReferenceArray::*)() const) static_cast< const handle<NCollection_HArray1<TDF_Label>> & (TDataStd_ReferenceArray::*)() const>(&TDataStd_ReferenceArray::InternalArray),
             R"#()#"
             
         )
       .def("ID",
             ( const Standard_GUID & (TDataStd_ReferenceArray::*)() const) static_cast< const Standard_GUID & (TDataStd_ReferenceArray::*)() const>(&TDataStd_ReferenceArray::ID),
             R"#()#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_ReferenceArray::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_ReferenceArray::*)() const>(&TDataStd_ReferenceArray::DynamicType),
             R"#()#"
             
         )
;

    // Class TDataStd_ReferenceList from ./opencascade/TDataStd_ReferenceList.hxx
    klass = m.attr("TDataStd_ReferenceList");


    // nested enums

    static_cast<py::class_<TDataStd_ReferenceList ,opencascade::handle<TDataStd_ReferenceList>  , TDF_Attribute >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("IsEmpty",
             (bool (TDataStd_ReferenceList::*)() const) static_cast<bool (TDataStd_ReferenceList::*)() const>(&TDataStd_ReferenceList::IsEmpty),
             R"#()#" 
          )
        .def("Extent",
             (int (TDataStd_ReferenceList::*)() const) static_cast<int (TDataStd_ReferenceList::*)() const>(&TDataStd_ReferenceList::Extent),
             R"#()#" 
          )
        .def("Prepend",
             (void (TDataStd_ReferenceList::*)(  const TDF_Label &  ) ) static_cast<void (TDataStd_ReferenceList::*)(  const TDF_Label &  ) >(&TDataStd_ReferenceList::Prepend),
             R"#()#"  , py::arg("value")
          )
        .def("Append",
             (void (TDataStd_ReferenceList::*)(  const TDF_Label &  ) ) static_cast<void (TDataStd_ReferenceList::*)(  const TDF_Label &  ) >(&TDataStd_ReferenceList::Append),
             R"#()#"  , py::arg("value")
          )
        .def("SetID",
             (void (TDataStd_ReferenceList::*)(  const Standard_GUID &  ) ) static_cast<void (TDataStd_ReferenceList::*)(  const Standard_GUID &  ) >(&TDataStd_ReferenceList::SetID),
             R"#(Sets the explicit GUID (user defined) for the attribute.)#"  , py::arg("theGuid")
          )
        .def("SetID",
             (void (TDataStd_ReferenceList::*)() ) static_cast<void (TDataStd_ReferenceList::*)() >(&TDataStd_ReferenceList::SetID),
             R"#(Sets default GUID for the attribute.)#" 
          )
        .def("InsertBefore",
             (bool (TDataStd_ReferenceList::*)(  const TDF_Label & ,   const TDF_Label &  ) ) static_cast<bool (TDataStd_ReferenceList::*)(  const TDF_Label & ,   const TDF_Label &  ) >(&TDataStd_ReferenceList::InsertBefore),
             R"#(Inserts the <value> before the first meet of <before_value>.)#"  , py::arg("value"),  py::arg("before_value")
          )
        .def("InsertBefore",
             (bool (TDataStd_ReferenceList::*)(  const int ,   const TDF_Label &  ) ) static_cast<bool (TDataStd_ReferenceList::*)(  const int ,   const TDF_Label &  ) >(&TDataStd_ReferenceList::InsertBefore),
             R"#(Inserts the label before the <index> position. The indices start with 1 .. Extent().)#"  , py::arg("index"),  py::arg("before_value")
          )
        .def("InsertAfter",
             (bool (TDataStd_ReferenceList::*)(  const TDF_Label & ,   const TDF_Label &  ) ) static_cast<bool (TDataStd_ReferenceList::*)(  const TDF_Label & ,   const TDF_Label &  ) >(&TDataStd_ReferenceList::InsertAfter),
             R"#(Inserts the <value> after the first meet of <after_value>.)#"  , py::arg("value"),  py::arg("after_value")
          )
        .def("InsertAfter",
             (bool (TDataStd_ReferenceList::*)(  const int ,   const TDF_Label &  ) ) static_cast<bool (TDataStd_ReferenceList::*)(  const int ,   const TDF_Label &  ) >(&TDataStd_ReferenceList::InsertAfter),
             R"#(Inserts the label after the <index> position. The indices start with 1 .. Extent().)#"  , py::arg("index"),  py::arg("after_value")
          )
        .def("Remove",
             (bool (TDataStd_ReferenceList::*)(  const TDF_Label &  ) ) static_cast<bool (TDataStd_ReferenceList::*)(  const TDF_Label &  ) >(&TDataStd_ReferenceList::Remove),
             R"#(Removes the first meet of the <value>.)#"  , py::arg("value")
          )
        .def("Remove",
             (bool (TDataStd_ReferenceList::*)(  const int  ) ) static_cast<bool (TDataStd_ReferenceList::*)(  const int  ) >(&TDataStd_ReferenceList::Remove),
             R"#(Removes a label at "index" position.)#"  , py::arg("index")
          )
        .def("Clear",
             (void (TDataStd_ReferenceList::*)() ) static_cast<void (TDataStd_ReferenceList::*)() >(&TDataStd_ReferenceList::Clear),
             R"#()#" 
          )
        .def("Restore",
             (void (TDataStd_ReferenceList::*)(  const handle<TDF_Attribute> &  ) ) static_cast<void (TDataStd_ReferenceList::*)(  const handle<TDF_Attribute> &  ) >(&TDataStd_ReferenceList::Restore),
             R"#()#"  , py::arg("With")
          )
        .def("NewEmpty",
             (handle<TDF_Attribute> (TDataStd_ReferenceList::*)() const) static_cast<handle<TDF_Attribute> (TDataStd_ReferenceList::*)() const>(&TDataStd_ReferenceList::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (void (TDataStd_ReferenceList::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const) static_cast<void (TDataStd_ReferenceList::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const>(&TDataStd_ReferenceList::Paste),
             R"#()#"  , py::arg("Into"),  py::arg("RT")
          )
        .def("References",
             (void (TDataStd_ReferenceList::*)(  const handle<TDF_DataSet> &  ) const) static_cast<void (TDataStd_ReferenceList::*)(  const handle<TDF_DataSet> &  ) const>(&TDataStd_ReferenceList::References),
             R"#()#"  , py::arg("DS")
          )
        .def("Dump",
             (Standard_OStream & (TDataStd_ReferenceList::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDataStd_ReferenceList::*)( Standard_OStream &  ) const>(&TDataStd_ReferenceList::Dump),
             R"#()#"  , py::arg("anOS")
          )
        .def("DumpJson",
             (void (TDataStd_ReferenceList::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDataStd_ReferenceList::*)( Standard_OStream & ,  int  ) const>(&TDataStd_ReferenceList::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("GetID_s",
                    ( const Standard_GUID & (*)() ) static_cast< const Standard_GUID & (*)() >(&TDataStd_ReferenceList::GetID),
                    R"#(Static methods ============== Returns the ID of the list of references (labels) attribute.)#" 
          )
        .def_static("Set_s",
                    (handle<TDataStd_ReferenceList> (*)(  const TDF_Label &  ) ) static_cast<handle<TDataStd_ReferenceList> (*)(  const TDF_Label &  ) >(&TDataStd_ReferenceList::Set),
                    R"#(Finds or creates a list of reference values (labels) attribute.)#"  , py::arg("label")
          )
        .def_static("Set_s",
                    (handle<TDataStd_ReferenceList> (*)(  const TDF_Label & ,   const Standard_GUID &  ) ) static_cast<handle<TDataStd_ReferenceList> (*)(  const TDF_Label & ,   const Standard_GUID &  ) >(&TDataStd_ReferenceList::Set),
                    R"#(Finds or creates a list of reference values (labels) attribute with explicit user defined <guid>.)#"  , py::arg("label"),  py::arg("theGuid")
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_ReferenceList::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_ReferenceList::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("First",
             ( const TDF_Label & (TDataStd_ReferenceList::*)() const) static_cast< const TDF_Label & (TDataStd_ReferenceList::*)() const>(&TDataStd_ReferenceList::First),
             R"#()#"
             
         )
       .def("Last",
             ( const TDF_Label & (TDataStd_ReferenceList::*)() const) static_cast< const TDF_Label & (TDataStd_ReferenceList::*)() const>(&TDataStd_ReferenceList::Last),
             R"#()#"
             
         )
       .def("List",
             ( const NCollection_List<TDF_Label> & (TDataStd_ReferenceList::*)() const) static_cast< const NCollection_List<TDF_Label> & (TDataStd_ReferenceList::*)() const>(&TDataStd_ReferenceList::List),
             R"#()#"
             
         )
       .def("ID",
             ( const Standard_GUID & (TDataStd_ReferenceList::*)() const) static_cast< const Standard_GUID & (TDataStd_ReferenceList::*)() const>(&TDataStd_ReferenceList::ID),
             R"#()#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_ReferenceList::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_ReferenceList::*)() const>(&TDataStd_ReferenceList::DynamicType),
             R"#()#"
             
         )
;

    // Class TDataStd_TreeNode from ./opencascade/TDataStd_TreeNode.hxx
    klass = m.attr("TDataStd_TreeNode");


    // nested enums

    static_cast<py::class_<TDataStd_TreeNode ,opencascade::handle<TDataStd_TreeNode>  , TDF_Attribute >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Append",
             (bool (TDataStd_TreeNode::*)(  const handle<TDataStd_TreeNode> &  ) ) static_cast<bool (TDataStd_TreeNode::*)(  const handle<TDataStd_TreeNode> &  ) >(&TDataStd_TreeNode::Append),
             R"#(Insert the TreeNode <Child> as last child of <me>. If the insertion is successful <me> becomes the Father of <Child>.)#"  , py::arg("Child")
          )
        .def("Prepend",
             (bool (TDataStd_TreeNode::*)(  const handle<TDataStd_TreeNode> &  ) ) static_cast<bool (TDataStd_TreeNode::*)(  const handle<TDataStd_TreeNode> &  ) >(&TDataStd_TreeNode::Prepend),
             R"#(Insert the the TreeNode <Child> as first child of <me>. If the insertion is successful <me> becomes the Father of <Child>)#"  , py::arg("Child")
          )
        .def("InsertBefore",
             (bool (TDataStd_TreeNode::*)(  const handle<TDataStd_TreeNode> &  ) ) static_cast<bool (TDataStd_TreeNode::*)(  const handle<TDataStd_TreeNode> &  ) >(&TDataStd_TreeNode::InsertBefore),
             R"#(Inserts the TreeNode <Node> before <me>. If insertion is successful <me> and <Node> belongs to the same Father.)#"  , py::arg("Node")
          )
        .def("InsertAfter",
             (bool (TDataStd_TreeNode::*)(  const handle<TDataStd_TreeNode> &  ) ) static_cast<bool (TDataStd_TreeNode::*)(  const handle<TDataStd_TreeNode> &  ) >(&TDataStd_TreeNode::InsertAfter),
             R"#(Inserts the TreeNode <Node> after <me>. If insertion is successful <me> and <Node> belongs to the same Father.)#"  , py::arg("Node")
          )
        .def("Remove",
             (bool (TDataStd_TreeNode::*)() ) static_cast<bool (TDataStd_TreeNode::*)() >(&TDataStd_TreeNode::Remove),
             R"#(Removes this tree node attribute from its father node. The result is that this attribute becomes a root node.)#" 
          )
        .def("Depth",
             (int (TDataStd_TreeNode::*)() const) static_cast<int (TDataStd_TreeNode::*)() const>(&TDataStd_TreeNode::Depth),
             R"#(Returns the depth of this tree node in the overall tree node structure. In other words, the number of father tree nodes of this one is returned.)#" 
          )
        .def("NbChildren",
             (int (TDataStd_TreeNode::*)(  const bool  ) const) static_cast<int (TDataStd_TreeNode::*)(  const bool  ) const>(&TDataStd_TreeNode::NbChildren),
             R"#(Returns the number of child nodes. If <allLevels> is true, the method counts children of all levels (children of children ...))#"  , py::arg("allLevels")=static_cast< const bool>(false)
          )
        .def("IsAscendant",
             (bool (TDataStd_TreeNode::*)(  const handle<TDataStd_TreeNode> &  ) const) static_cast<bool (TDataStd_TreeNode::*)(  const handle<TDataStd_TreeNode> &  ) const>(&TDataStd_TreeNode::IsAscendant),
             R"#(Returns true if this tree node attribute is an ascendant of of. In other words, if it is a father or the father of a father of of.)#"  , py::arg("of")
          )
        .def("IsDescendant",
             (bool (TDataStd_TreeNode::*)(  const handle<TDataStd_TreeNode> &  ) const) static_cast<bool (TDataStd_TreeNode::*)(  const handle<TDataStd_TreeNode> &  ) const>(&TDataStd_TreeNode::IsDescendant),
             R"#(Returns true if this tree node attribute is a descendant of of. In other words, if it is a child or the child of a child of of.)#"  , py::arg("of")
          )
        .def("IsRoot",
             (bool (TDataStd_TreeNode::*)() const) static_cast<bool (TDataStd_TreeNode::*)() const>(&TDataStd_TreeNode::IsRoot),
             R"#(Returns true if this tree node attribute is the ultimate father in the tree.)#" 
          )
        .def("Root",
             (handle<TDataStd_TreeNode> (TDataStd_TreeNode::*)() const) static_cast<handle<TDataStd_TreeNode> (TDataStd_TreeNode::*)() const>(&TDataStd_TreeNode::Root),
             R"#(Returns the ultimate father of this tree node attribute.)#" 
          )
        .def("IsFather",
             (bool (TDataStd_TreeNode::*)(  const handle<TDataStd_TreeNode> &  ) const) static_cast<bool (TDataStd_TreeNode::*)(  const handle<TDataStd_TreeNode> &  ) const>(&TDataStd_TreeNode::IsFather),
             R"#(Returns true if this tree node attribute is a father of of.)#"  , py::arg("of")
          )
        .def("IsChild",
             (bool (TDataStd_TreeNode::*)(  const handle<TDataStd_TreeNode> &  ) const) static_cast<bool (TDataStd_TreeNode::*)(  const handle<TDataStd_TreeNode> &  ) const>(&TDataStd_TreeNode::IsChild),
             R"#(Returns true if this tree node attribute is a child of of.)#"  , py::arg("of")
          )
        .def("HasFather",
             (bool (TDataStd_TreeNode::*)() const) static_cast<bool (TDataStd_TreeNode::*)() const>(&TDataStd_TreeNode::HasFather),
             R"#(Returns true if this tree node attribute has a father tree node.)#" 
          )
        .def("Father",
             (handle<TDataStd_TreeNode> (TDataStd_TreeNode::*)() const) static_cast<handle<TDataStd_TreeNode> (TDataStd_TreeNode::*)() const>(&TDataStd_TreeNode::Father),
             R"#(Returns the father TreeNode of <me>. Null if root.)#" 
          )
        .def("HasNext",
             (bool (TDataStd_TreeNode::*)() const) static_cast<bool (TDataStd_TreeNode::*)() const>(&TDataStd_TreeNode::HasNext),
             R"#(Returns true if this tree node attribute has a next tree node.)#" 
          )
        .def("Next",
             (handle<TDataStd_TreeNode> (TDataStd_TreeNode::*)() const) static_cast<handle<TDataStd_TreeNode> (TDataStd_TreeNode::*)() const>(&TDataStd_TreeNode::Next),
             R"#(Returns the next tree node in this tree node attribute. Warning This tree node is null if it is the last one in this tree node attribute.Returns the next TreeNode of <me>. Null if last.)#" 
          )
        .def("HasPrevious",
             (bool (TDataStd_TreeNode::*)() const) static_cast<bool (TDataStd_TreeNode::*)() const>(&TDataStd_TreeNode::HasPrevious),
             R"#(Returns true if this tree node attribute has a previous tree node.)#" 
          )
        .def("Previous",
             (handle<TDataStd_TreeNode> (TDataStd_TreeNode::*)() const) static_cast<handle<TDataStd_TreeNode> (TDataStd_TreeNode::*)() const>(&TDataStd_TreeNode::Previous),
             R"#(Returns the previous tree node of this tree node attribute. Warning This tree node is null if it is the first one in this tree node attribute.)#" 
          )
        .def("HasFirst",
             (bool (TDataStd_TreeNode::*)() const) static_cast<bool (TDataStd_TreeNode::*)() const>(&TDataStd_TreeNode::HasFirst),
             R"#(Returns true if this tree node attribute has a first child tree node.)#" 
          )
        .def("First",
             (handle<TDataStd_TreeNode> (TDataStd_TreeNode::*)() const) static_cast<handle<TDataStd_TreeNode> (TDataStd_TreeNode::*)() const>(&TDataStd_TreeNode::First),
             R"#(Returns the first child tree node in this tree node object.)#" 
          )
        .def("HasLast",
             (bool (TDataStd_TreeNode::*)() const) static_cast<bool (TDataStd_TreeNode::*)() const>(&TDataStd_TreeNode::HasLast),
             R"#(Returns true if this tree node attribute has a last child tree node.)#" 
          )
        .def("Last",
             (handle<TDataStd_TreeNode> (TDataStd_TreeNode::*)() ) static_cast<handle<TDataStd_TreeNode> (TDataStd_TreeNode::*)() >(&TDataStd_TreeNode::Last),
             R"#(Returns the last child tree node in this tree node object.)#" 
          )
        .def("FindLast",
             (handle<TDataStd_TreeNode> (TDataStd_TreeNode::*)() ) static_cast<handle<TDataStd_TreeNode> (TDataStd_TreeNode::*)() >(&TDataStd_TreeNode::FindLast),
             R"#(Returns the last child tree node in this tree node object. to set fields =============)#" 
          )
        .def("SetTreeID",
             (void (TDataStd_TreeNode::*)(  const Standard_GUID &  ) ) static_cast<void (TDataStd_TreeNode::*)(  const Standard_GUID &  ) >(&TDataStd_TreeNode::SetTreeID),
             R"#()#"  , py::arg("explicitID")
          )
        .def("SetFather",
             (void (TDataStd_TreeNode::*)(  const handle<TDataStd_TreeNode> &  ) ) static_cast<void (TDataStd_TreeNode::*)(  const handle<TDataStd_TreeNode> &  ) >(&TDataStd_TreeNode::SetFather),
             R"#()#"  , py::arg("F")
          )
        .def("SetNext",
             (void (TDataStd_TreeNode::*)(  const handle<TDataStd_TreeNode> &  ) ) static_cast<void (TDataStd_TreeNode::*)(  const handle<TDataStd_TreeNode> &  ) >(&TDataStd_TreeNode::SetNext),
             R"#()#"  , py::arg("F")
          )
        .def("SetPrevious",
             (void (TDataStd_TreeNode::*)(  const handle<TDataStd_TreeNode> &  ) ) static_cast<void (TDataStd_TreeNode::*)(  const handle<TDataStd_TreeNode> &  ) >(&TDataStd_TreeNode::SetPrevious),
             R"#()#"  , py::arg("F")
          )
        .def("SetFirst",
             (void (TDataStd_TreeNode::*)(  const handle<TDataStd_TreeNode> &  ) ) static_cast<void (TDataStd_TreeNode::*)(  const handle<TDataStd_TreeNode> &  ) >(&TDataStd_TreeNode::SetFirst),
             R"#()#"  , py::arg("F")
          )
        .def("SetLast",
             (void (TDataStd_TreeNode::*)(  const handle<TDataStd_TreeNode> &  ) ) static_cast<void (TDataStd_TreeNode::*)(  const handle<TDataStd_TreeNode> &  ) >(&TDataStd_TreeNode::SetLast),
             R"#(TreeNode callback: ==================)#"  , py::arg("F")
          )
        .def("AfterAddition",
             (void (TDataStd_TreeNode::*)() ) static_cast<void (TDataStd_TreeNode::*)() >(&TDataStd_TreeNode::AfterAddition),
             R"#(Connect the TreeNode to its father child list)#" 
          )
        .def("BeforeForget",
             (void (TDataStd_TreeNode::*)() ) static_cast<void (TDataStd_TreeNode::*)() >(&TDataStd_TreeNode::BeforeForget),
             R"#(Disconnect the TreeNode from its Father child list)#" 
          )
        .def("AfterResume",
             (void (TDataStd_TreeNode::*)() ) static_cast<void (TDataStd_TreeNode::*)() >(&TDataStd_TreeNode::AfterResume),
             R"#(Reconnect the TreeNode to its father child list.)#" 
          )
        .def("BeforeUndo",
             (bool (TDataStd_TreeNode::*)(  const handle<TDF_AttributeDelta> & ,   const bool  ) ) static_cast<bool (TDataStd_TreeNode::*)(  const handle<TDF_AttributeDelta> & ,   const bool  ) >(&TDataStd_TreeNode::BeforeUndo),
             R"#(Disconnect the TreeNode, if necessary.)#"  , py::arg("anAttDelta"),  py::arg("forceIt")=static_cast< const bool>(false)
          )
        .def("AfterUndo",
             (bool (TDataStd_TreeNode::*)(  const handle<TDF_AttributeDelta> & ,   const bool  ) ) static_cast<bool (TDataStd_TreeNode::*)(  const handle<TDF_AttributeDelta> & ,   const bool  ) >(&TDataStd_TreeNode::AfterUndo),
             R"#(Reconnect the TreeNode, if necessary. Implementation of Attribute methods: ===================================)#"  , py::arg("anAttDelta"),  py::arg("forceIt")=static_cast< const bool>(false)
          )
        .def("Restore",
             (void (TDataStd_TreeNode::*)(  const handle<TDF_Attribute> &  ) ) static_cast<void (TDataStd_TreeNode::*)(  const handle<TDF_Attribute> &  ) >(&TDataStd_TreeNode::Restore),
             R"#()#"  , py::arg("with_")
          )
        .def("Paste",
             (void (TDataStd_TreeNode::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const) static_cast<void (TDataStd_TreeNode::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const>(&TDataStd_TreeNode::Paste),
             R"#()#"  , py::arg("into"),  py::arg("RT")
          )
        .def("NewEmpty",
             (handle<TDF_Attribute> (TDataStd_TreeNode::*)() const) static_cast<handle<TDF_Attribute> (TDataStd_TreeNode::*)() const>(&TDataStd_TreeNode::NewEmpty),
             R"#()#" 
          )
        .def("References",
             (void (TDataStd_TreeNode::*)(  const handle<TDF_DataSet> &  ) const) static_cast<void (TDataStd_TreeNode::*)(  const handle<TDF_DataSet> &  ) const>(&TDataStd_TreeNode::References),
             R"#()#"  , py::arg("aDataSet")
          )
        .def("Dump",
             (Standard_OStream & (TDataStd_TreeNode::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDataStd_TreeNode::*)( Standard_OStream &  ) const>(&TDataStd_TreeNode::Dump),
             R"#()#"  , py::arg("anOS")
          )
        .def("DumpJson",
             (void (TDataStd_TreeNode::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDataStd_TreeNode::*)( Standard_OStream & ,  int  ) const>(&TDataStd_TreeNode::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
        .def("HasFather",
             (bool (TDataStd_TreeNode::*)() const) static_cast<bool (TDataStd_TreeNode::*)() const>(&TDataStd_TreeNode::HasFather),
             R"#(Returns true if this tree node attribute has a father tree node.)#" 
          )
        .def("HasNext",
             (bool (TDataStd_TreeNode::*)() const) static_cast<bool (TDataStd_TreeNode::*)() const>(&TDataStd_TreeNode::HasNext),
             R"#(Returns true if this tree node attribute has a next tree node.)#" 
          )
        .def("HasPrevious",
             (bool (TDataStd_TreeNode::*)() const) static_cast<bool (TDataStd_TreeNode::*)() const>(&TDataStd_TreeNode::HasPrevious),
             R"#(Returns true if this tree node attribute has a previous tree node.)#" 
          )
        .def("HasFirst",
             (bool (TDataStd_TreeNode::*)() const) static_cast<bool (TDataStd_TreeNode::*)() const>(&TDataStd_TreeNode::HasFirst),
             R"#(Returns true if this tree node attribute has a first child tree node.)#" 
          )
        .def("HasLast",
             (bool (TDataStd_TreeNode::*)() const) static_cast<bool (TDataStd_TreeNode::*)() const>(&TDataStd_TreeNode::HasLast),
             R"#(Returns true if this tree node attribute has a last child tree node.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Find_s",
                    (bool (*)(  const TDF_Label & ,  handle<TDataStd_TreeNode> &  ) ) static_cast<bool (*)(  const TDF_Label & ,  handle<TDataStd_TreeNode> &  ) >(&TDataStd_TreeNode::Find),
                    R"#(class methods working on the node ================================= Returns true if the tree node T is found on the label L. Otherwise, false is returned.)#"  , py::arg("L"),  py::arg("T")
          )
        .def_static("Set_s",
                    (handle<TDataStd_TreeNode> (*)(  const TDF_Label &  ) ) static_cast<handle<TDataStd_TreeNode> (*)(  const TDF_Label &  ) >(&TDataStd_TreeNode::Set),
                    R"#(Finds or Creates a TreeNode attribute on the label <L> with the default tree ID, returned by the method <GetDefaultTreeID>. Returns the created/found TreeNode attribute.)#"  , py::arg("L")
          )
        .def_static("Set_s",
                    (handle<TDataStd_TreeNode> (*)(  const TDF_Label & ,   const Standard_GUID &  ) ) static_cast<handle<TDataStd_TreeNode> (*)(  const TDF_Label & ,   const Standard_GUID &  ) >(&TDataStd_TreeNode::Set),
                    R"#(Finds or Creates a TreeNode attribute on the label <L>, with an explicit tree ID. <ExplicitTreeID> is the ID returned by <TDF_Attribute::ID> method. Returns the found/created TreeNode attribute.)#"  , py::arg("L"),  py::arg("ExplicitTreeID")
          )
        .def_static("GetDefaultTreeID_s",
                    ( const Standard_GUID & (*)() ) static_cast< const Standard_GUID & (*)() >(&TDataStd_TreeNode::GetDefaultTreeID),
                    R"#(returns a default tree ID. this ID is used by the <Set> method without explicit tree ID. Instance methods: ================)#" 
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_TreeNode::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_TreeNode::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("ID",
             ( const Standard_GUID & (TDataStd_TreeNode::*)() const) static_cast< const Standard_GUID & (TDataStd_TreeNode::*)() const>(&TDataStd_TreeNode::ID),
             R"#(Returns the tree ID (default or explicit one depending on the Set method used).)#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_TreeNode::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_TreeNode::*)() const>(&TDataStd_TreeNode::DynamicType),
             R"#()#"
             
         )
;

    // Class TDataStd_UAttribute from ./opencascade/TDataStd_UAttribute.hxx
    klass = m.attr("TDataStd_UAttribute");


    // nested enums

    static_cast<py::class_<TDataStd_UAttribute ,opencascade::handle<TDataStd_UAttribute>  , TDF_Attribute >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetID",
             (void (TDataStd_UAttribute::*)(  const Standard_GUID &  ) ) static_cast<void (TDataStd_UAttribute::*)(  const Standard_GUID &  ) >(&TDataStd_UAttribute::SetID),
             R"#()#"  , py::arg("LocalID")
          )
        .def("Restore",
             (void (TDataStd_UAttribute::*)(  const handle<TDF_Attribute> &  ) ) static_cast<void (TDataStd_UAttribute::*)(  const handle<TDF_Attribute> &  ) >(&TDataStd_UAttribute::Restore),
             R"#()#"  , py::arg("with_")
          )
        .def("NewEmpty",
             (handle<TDF_Attribute> (TDataStd_UAttribute::*)() const) static_cast<handle<TDF_Attribute> (TDataStd_UAttribute::*)() const>(&TDataStd_UAttribute::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (void (TDataStd_UAttribute::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const) static_cast<void (TDataStd_UAttribute::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const>(&TDataStd_UAttribute::Paste),
             R"#()#"  , py::arg("into"),  py::arg("RT")
          )
        .def("References",
             (void (TDataStd_UAttribute::*)(  const handle<TDF_DataSet> &  ) const) static_cast<void (TDataStd_UAttribute::*)(  const handle<TDF_DataSet> &  ) const>(&TDataStd_UAttribute::References),
             R"#()#"  , py::arg("DS")
          )
        .def("Dump",
             (Standard_OStream & (TDataStd_UAttribute::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDataStd_UAttribute::*)( Standard_OStream &  ) const>(&TDataStd_UAttribute::Dump),
             R"#()#"  , py::arg("anOS")
          )
        .def("DumpJson",
             (void (TDataStd_UAttribute::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDataStd_UAttribute::*)( Standard_OStream & ,  int  ) const>(&TDataStd_UAttribute::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Set_s",
                    (handle<TDataStd_UAttribute> (*)(  const TDF_Label & ,   const Standard_GUID &  ) ) static_cast<handle<TDataStd_UAttribute> (*)(  const TDF_Label & ,   const Standard_GUID &  ) >(&TDataStd_UAttribute::Set),
                    R"#(api class methods ============= Find, or create, a UAttribute attribute with <LocalID> as Local GUID. The UAttribute attribute is returned. UAttribute methods ============)#"  , py::arg("label"),  py::arg("LocalID")
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_UAttribute::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_UAttribute::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("ID",
             ( const Standard_GUID & (TDataStd_UAttribute::*)() const) static_cast< const Standard_GUID & (TDataStd_UAttribute::*)() const>(&TDataStd_UAttribute::ID),
             R"#()#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_UAttribute::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_UAttribute::*)() const>(&TDataStd_UAttribute::DynamicType),
             R"#()#"
             
         )
;

    // Class TDataStd_Variable from ./opencascade/TDataStd_Variable.hxx
    klass = m.attr("TDataStd_Variable");


    // nested enums

    static_cast<py::class_<TDataStd_Variable ,opencascade::handle<TDataStd_Variable>  , TDF_Attribute >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Name",
             (void (TDataStd_Variable::*)(  const TCollection_ExtendedString &  ) ) static_cast<void (TDataStd_Variable::*)(  const TCollection_ExtendedString &  ) >(&TDataStd_Variable::Name),
             R"#(set or change the name of the variable, in myUnknown and my associated Name attribute.)#"  , py::arg("string")
          )
        .def("Set",
             (void (TDataStd_Variable::*)(  const double  ) const) static_cast<void (TDataStd_Variable::*)(  const double  ) const>(&TDataStd_Variable::Set),
             R"#(retrieve or create the associated real attribute and set the value <value>.)#"  , py::arg("value")
          )
        .def("Set",
             (void (TDataStd_Variable::*)(  const double ,   const TDataStd_RealEnum  ) const) static_cast<void (TDataStd_Variable::*)(  const double ,   const TDataStd_RealEnum  ) const>(&TDataStd_Variable::Set),
             R"#(Obsolete method that will be removed in next versions. The dimension argument is not supported in the persistence mechanism.)#"  , py::arg("value"),  py::arg("dimension")
          )
        .def("IsValued",
             (bool (TDataStd_Variable::*)() const) static_cast<bool (TDataStd_Variable::*)() const>(&TDataStd_Variable::IsValued),
             R"#(returns True if a Real attribute is associated.)#" 
          )
        .def("Get",
             (double (TDataStd_Variable::*)() const) static_cast<double (TDataStd_Variable::*)() const>(&TDataStd_Variable::Get),
             R"#(returns value stored in associated Real attribute.)#" 
          )
        .def("Real",
             (handle<TDataStd_Real> (TDataStd_Variable::*)() const) static_cast<handle<TDataStd_Real> (TDataStd_Variable::*)() const>(&TDataStd_Variable::Real),
             R"#(returns associated Real attribute.)#" 
          )
        .def("IsAssigned",
             (bool (TDataStd_Variable::*)() const) static_cast<bool (TDataStd_Variable::*)() const>(&TDataStd_Variable::IsAssigned),
             R"#(returns True if an Expression attribute is associated. create(if doesn't exist), set and returns the assigned expression attribute.)#" 
          )
        .def("Assign",
             (handle<TDataStd_Expression> (TDataStd_Variable::*)() const) static_cast<handle<TDataStd_Expression> (TDataStd_Variable::*)() const>(&TDataStd_Variable::Assign),
             R"#(create(if doesn't exist) and returns the assigned expression attribute. fill it after.)#" 
          )
        .def("Desassign",
             (void (TDataStd_Variable::*)() const) static_cast<void (TDataStd_Variable::*)() const>(&TDataStd_Variable::Desassign),
             R"#(if <me> is assigned delete the associated expression attribute.)#" 
          )
        .def("Expression",
             (handle<TDataStd_Expression> (TDataStd_Variable::*)() const) static_cast<handle<TDataStd_Expression> (TDataStd_Variable::*)() const>(&TDataStd_Variable::Expression),
             R"#(if <me> is assigned, returns associated Expression attribute.)#" 
          )
        .def("IsCaptured",
             (bool (TDataStd_Variable::*)() const) static_cast<bool (TDataStd_Variable::*)() const>(&TDataStd_Variable::IsCaptured),
             R"#(shortcut for <Real()->IsCaptured()>)#" 
          )
        .def("IsConstant",
             (bool (TDataStd_Variable::*)() const) static_cast<bool (TDataStd_Variable::*)() const>(&TDataStd_Variable::IsConstant),
             R"#(A constant value is not modified by regeneration.)#" 
          )
        .def("Unit",
             (void (TDataStd_Variable::*)(  const TCollection_AsciiString &  ) ) static_cast<void (TDataStd_Variable::*)(  const TCollection_AsciiString &  ) >(&TDataStd_Variable::Unit),
             R"#()#"  , py::arg("unit")
          )
        .def("Constant",
             (void (TDataStd_Variable::*)(  const bool  ) ) static_cast<void (TDataStd_Variable::*)(  const bool  ) >(&TDataStd_Variable::Constant),
             R"#(if <status> is True, this variable will not be modified by the solver.)#"  , py::arg("status")
          )
        .def("Restore",
             (void (TDataStd_Variable::*)(  const handle<TDF_Attribute> &  ) ) static_cast<void (TDataStd_Variable::*)(  const handle<TDF_Attribute> &  ) >(&TDataStd_Variable::Restore),
             R"#()#"  , py::arg("With")
          )
        .def("NewEmpty",
             (handle<TDF_Attribute> (TDataStd_Variable::*)() const) static_cast<handle<TDF_Attribute> (TDataStd_Variable::*)() const>(&TDataStd_Variable::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (void (TDataStd_Variable::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const) static_cast<void (TDataStd_Variable::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const>(&TDataStd_Variable::Paste),
             R"#()#"  , py::arg("Into"),  py::arg("RT")
          )
        .def("References",
             (void (TDataStd_Variable::*)(  const handle<TDF_DataSet> &  ) const) static_cast<void (TDataStd_Variable::*)(  const handle<TDF_DataSet> &  ) const>(&TDataStd_Variable::References),
             R"#(to export reference to the associated Name attribute.)#"  , py::arg("DS")
          )
        .def("Dump",
             (Standard_OStream & (TDataStd_Variable::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDataStd_Variable::*)( Standard_OStream &  ) const>(&TDataStd_Variable::Dump),
             R"#()#"  , py::arg("anOS")
          )
        .def("DumpJson",
             (void (TDataStd_Variable::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDataStd_Variable::*)( Standard_OStream & ,  int  ) const>(&TDataStd_Variable::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("GetID_s",
                    ( const Standard_GUID & (*)() ) static_cast< const Standard_GUID & (*)() >(&TDataStd_Variable::GetID),
                    R"#(class methods =============)#" 
          )
        .def_static("Set_s",
                    (handle<TDataStd_Variable> (*)(  const TDF_Label &  ) ) static_cast<handle<TDataStd_Variable> (*)(  const TDF_Label &  ) >(&TDataStd_Variable::Set),
                    R"#(Find, or create, a Variable attribute. Real methods ============)#"  , py::arg("label")
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_Variable::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_Variable::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Name",
             ( const TCollection_ExtendedString & (TDataStd_Variable::*)() const) static_cast< const TCollection_ExtendedString & (TDataStd_Variable::*)() const>(&TDataStd_Variable::Name),
             R"#(returns string stored in the associated Name attribute.)#"
             
         )
       .def("Unit",
             ( const TCollection_AsciiString & (TDataStd_Variable::*)() const) static_cast< const TCollection_AsciiString & (TDataStd_Variable::*)() const>(&TDataStd_Variable::Unit),
             R"#(to read/write fields ====================)#"
             
         )
       .def("ID",
             ( const Standard_GUID & (TDataStd_Variable::*)() const) static_cast< const Standard_GUID & (TDataStd_Variable::*)() const>(&TDataStd_Variable::ID),
             R"#()#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_Variable::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_Variable::*)() const>(&TDataStd_Variable::DynamicType),
             R"#()#"
             
         )
;

    // Class TDataStd_Comment from ./opencascade/TDataStd_Comment.hxx
    klass = m.attr("TDataStd_Comment");


    // nested enums

    static_cast<py::class_<TDataStd_Comment ,opencascade::handle<TDataStd_Comment>  , TDataStd_GenericExtString >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Set",
             (void (TDataStd_Comment::*)(  const TCollection_ExtendedString &  ) ) static_cast<void (TDataStd_Comment::*)(  const TCollection_ExtendedString &  ) >(&TDataStd_Comment::Set),
             R"#()#"  , py::arg("S")
          )
        .def("SetID",
             (void (TDataStd_Comment::*)(  const Standard_GUID &  ) ) static_cast<void (TDataStd_Comment::*)(  const Standard_GUID &  ) >(&TDataStd_Comment::SetID),
             R"#(Sets the explicit user defined GUID to the attribute.)#"  , py::arg("guid")
          )
        .def("SetID",
             (void (TDataStd_Comment::*)() ) static_cast<void (TDataStd_Comment::*)() >(&TDataStd_Comment::SetID),
             R"#(Sets default GUID for the attribute.)#" 
          )
        .def("Dump",
             (Standard_OStream & (TDataStd_Comment::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDataStd_Comment::*)( Standard_OStream &  ) const>(&TDataStd_Comment::Dump),
             R"#()#"  , py::arg("anOS")
          )
        .def("NewEmpty",
             (handle<TDF_Attribute> (TDataStd_Comment::*)() const) static_cast<handle<TDF_Attribute> (TDataStd_Comment::*)() const>(&TDataStd_Comment::NewEmpty),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("GetID_s",
                    ( const Standard_GUID & (*)() ) static_cast< const Standard_GUID & (*)() >(&TDataStd_Comment::GetID),
                    R"#(class methods ============= Returns the GUID for comments.)#" 
          )
        .def_static("Set_s",
                    (handle<TDataStd_Comment> (*)(  const TDF_Label &  ) ) static_cast<handle<TDataStd_Comment> (*)(  const TDF_Label &  ) >(&TDataStd_Comment::Set),
                    R"#(Find, or create a Comment attribute. the Comment attribute is returned.)#"  , py::arg("label")
          )
        .def_static("Set_s",
                    (handle<TDataStd_Comment> (*)(  const TDF_Label & ,   const TCollection_ExtendedString &  ) ) static_cast<handle<TDataStd_Comment> (*)(  const TDF_Label & ,   const TCollection_ExtendedString &  ) >(&TDataStd_Comment::Set),
                    R"#(Finds, or creates a Comment attribute and sets the string. the Comment attribute is returned. Comment methods ============)#"  , py::arg("label"),  py::arg("string")
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_Comment::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_Comment::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_Comment::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_Comment::*)() const>(&TDataStd_Comment::DynamicType),
             R"#()#"
             
         )
;

    // Class TDataStd_Directory from ./opencascade/TDataStd_Directory.hxx
    klass = m.attr("TDataStd_Directory");


    // nested enums

    static_cast<py::class_<TDataStd_Directory ,opencascade::handle<TDataStd_Directory>  , TDataStd_GenericEmpty >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Dump",
             (Standard_OStream & (TDataStd_Directory::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDataStd_Directory::*)( Standard_OStream &  ) const>(&TDataStd_Directory::Dump),
             R"#()#"  , py::arg("anOS")
          )
        .def("NewEmpty",
             (handle<TDF_Attribute> (TDataStd_Directory::*)() const) static_cast<handle<TDF_Attribute> (TDataStd_Directory::*)() const>(&TDataStd_Directory::NewEmpty),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Find_s",
                    (bool (*)(  const TDF_Label & ,  handle<TDataStd_Directory> &  ) ) static_cast<bool (*)(  const TDF_Label & ,  handle<TDataStd_Directory> &  ) >(&TDataStd_Directory::Find),
                    R"#(class methods ============= Searches for a directory attribute on the label current, or on one of the father labels of current. If a directory attribute is found, true is returned, and the attribute found is set as D.)#"  , py::arg("current"),  py::arg("D")
          )
        .def_static("New_s",
                    (handle<TDataStd_Directory> (*)(  const TDF_Label &  ) ) static_cast<handle<TDataStd_Directory> (*)(  const TDF_Label &  ) >(&TDataStd_Directory::New),
                    R"#(Creates an empty Directory attribute, located at <label>. Raises if <label> has attribute)#"  , py::arg("label")
          )
        .def_static("AddDirectory_s",
                    (handle<TDataStd_Directory> (*)(  const handle<TDataStd_Directory> &  ) ) static_cast<handle<TDataStd_Directory> (*)(  const handle<TDataStd_Directory> &  ) >(&TDataStd_Directory::AddDirectory),
                    R"#(Creates a new sub-label and sets the sub-directory dir on that label.)#"  , py::arg("dir")
          )
        .def_static("MakeObjectLabel_s",
                    (TDF_Label (*)(  const handle<TDataStd_Directory> &  ) ) static_cast<TDF_Label (*)(  const handle<TDataStd_Directory> &  ) >(&TDataStd_Directory::MakeObjectLabel),
                    R"#(Makes new label and returns it to insert other object attributes (sketch,part...etc...))#"  , py::arg("dir")
          )
        .def_static("GetID_s",
                    ( const Standard_GUID & (*)() ) static_cast< const Standard_GUID & (*)() >(&TDataStd_Directory::GetID),
                    R"#(Directory methods ===============)#" 
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_Directory::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_Directory::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("ID",
             ( const Standard_GUID & (TDataStd_Directory::*)() const) static_cast< const Standard_GUID & (TDataStd_Directory::*)() const>(&TDataStd_Directory::ID),
             R"#()#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_Directory::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_Directory::*)() const>(&TDataStd_Directory::DynamicType),
             R"#()#"
             
         )
;

    // Class TDataStd_Name from ./opencascade/TDataStd_Name.hxx
    klass = m.attr("TDataStd_Name");


    // nested enums

    static_cast<py::class_<TDataStd_Name ,opencascade::handle<TDataStd_Name>  , TDataStd_GenericExtString >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Set",
             (void (TDataStd_Name::*)(  const TCollection_ExtendedString &  ) ) static_cast<void (TDataStd_Name::*)(  const TCollection_ExtendedString &  ) >(&TDataStd_Name::Set),
             R"#(Sets <S> as name. Raises if <S> is not a valid name.)#"  , py::arg("S")
          )
        .def("SetID",
             (void (TDataStd_Name::*)(  const Standard_GUID &  ) ) static_cast<void (TDataStd_Name::*)(  const Standard_GUID &  ) >(&TDataStd_Name::SetID),
             R"#(Sets the explicit user defined GUID to the attribute.)#"  , py::arg("guid")
          )
        .def("SetID",
             (void (TDataStd_Name::*)() ) static_cast<void (TDataStd_Name::*)() >(&TDataStd_Name::SetID),
             R"#(Sets default GUID for the attribute.)#" 
          )
        .def("Dump",
             (Standard_OStream & (TDataStd_Name::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDataStd_Name::*)( Standard_OStream &  ) const>(&TDataStd_Name::Dump),
             R"#()#"  , py::arg("anOS")
          )
        .def("NewEmpty",
             (handle<TDF_Attribute> (TDataStd_Name::*)() const) static_cast<handle<TDF_Attribute> (TDataStd_Name::*)() const>(&TDataStd_Name::NewEmpty),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("GetID_s",
                    ( const Standard_GUID & (*)() ) static_cast< const Standard_GUID & (*)() >(&TDataStd_Name::GetID),
                    R"#(class methods working on the name itself ======================================== Returns the GUID for name attributes.)#" 
          )
        .def_static("Set_s",
                    (handle<TDataStd_Name> (*)(  const TDF_Label & ,   const TCollection_ExtendedString &  ) ) static_cast<handle<TDataStd_Name> (*)(  const TDF_Label & ,   const TCollection_ExtendedString &  ) >(&TDataStd_Name::Set),
                    R"#(Creates (if does not exist) and sets the name in the name attribute. from any label <L> search in father labels (L is not concerned) the first name attribute. if found set it in <father>. class methods working on the name tree ====================================== Search in the whole TDF_Data the Name attribute which fit with <fullPath>. Returns True if found. Search under <currentLabel> a label which fit with <name>. Returns True if found. Shortcut which avoids building a ListOfExtendedStrin. Search in the whole TDF_Data the label which fit with name Returns True if found. tools methods to translate path <-> pathlist =========================================== move to draw For Draw test we may provide this tool method which convert a path in a sequence of string to call after the FindLabel methods. Example: if it's given "Assembly:Part_1:Sketch_5" it will return in <pathlist> the list of 3 strings: "Assembly","Part_1","Sketch_5". move to draw from <pathlist> build the string path Name methods ============)#"  , py::arg("label"),  py::arg("string")
          )
        .def_static("Set_s",
                    (handle<TDataStd_Name> (*)(  const TDF_Label & ,   const Standard_GUID & ,   const TCollection_ExtendedString &  ) ) static_cast<handle<TDataStd_Name> (*)(  const TDF_Label & ,   const Standard_GUID & ,   const TCollection_ExtendedString &  ) >(&TDataStd_Name::Set),
                    R"#(Finds, or creates, a Name attribute with explicit user defined <guid> and sets <string>. The Name attribute is returned.)#"  , py::arg("label"),  py::arg("guid"),  py::arg("string")
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_Name::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_Name::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_Name::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_Name::*)() const>(&TDataStd_Name::DynamicType),
             R"#()#"
             
         )
;

    // Class TDataStd_NoteBook from ./opencascade/TDataStd_NoteBook.hxx
    klass = m.attr("TDataStd_NoteBook");


    // nested enums

    static_cast<py::class_<TDataStd_NoteBook ,opencascade::handle<TDataStd_NoteBook>  , TDataStd_GenericEmpty >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Append",
             (handle<TDataStd_Real> (TDataStd_NoteBook::*)(  const double ,   const bool  ) ) static_cast<handle<TDataStd_Real> (TDataStd_NoteBook::*)(  const double ,   const bool  ) >(&TDataStd_NoteBook::Append),
             R"#(Tool to Create an Integer attribute from <value>, Insert it in a new son label of <me>. The Real attribute is returned.)#"  , py::arg("value"),  py::arg("isExported")=static_cast< const bool>(false)
          )
        .def("Append",
             (handle<TDataStd_Integer> (TDataStd_NoteBook::*)(  const int ,   const bool  ) ) static_cast<handle<TDataStd_Integer> (TDataStd_NoteBook::*)(  const int ,   const bool  ) >(&TDataStd_NoteBook::Append),
             R"#(Tool to Create an Real attribute from <value>, Insert it in a new son label of <me>. The Integer attribute is returned.)#"  , py::arg("value"),  py::arg("isExported")=static_cast< const bool>(false)
          )
        .def("Dump",
             (Standard_OStream & (TDataStd_NoteBook::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDataStd_NoteBook::*)( Standard_OStream &  ) const>(&TDataStd_NoteBook::Dump),
             R"#()#"  , py::arg("anOS")
          )
        .def("NewEmpty",
             (handle<TDF_Attribute> (TDataStd_NoteBook::*)() const) static_cast<handle<TDF_Attribute> (TDataStd_NoteBook::*)() const>(&TDataStd_NoteBook::NewEmpty),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Find_s",
                    (bool (*)(  const TDF_Label & ,  handle<TDataStd_NoteBook> &  ) ) static_cast<bool (*)(  const TDF_Label & ,  handle<TDataStd_NoteBook> &  ) >(&TDataStd_NoteBook::Find),
                    R"#(class methods ============= try to retrieve a NoteBook attribute at <current> label or in fathers label of <current>. Returns True if found and set <N>.)#"  , py::arg("current"),  py::arg("N")
          )
        .def_static("New_s",
                    (handle<TDataStd_NoteBook> (*)(  const TDF_Label &  ) ) static_cast<handle<TDataStd_NoteBook> (*)(  const TDF_Label &  ) >(&TDataStd_NoteBook::New),
                    R"#(Create an enpty NoteBook attribute, located at <label>. Raises if <label> has attribute)#"  , py::arg("label")
          )
        .def_static("GetID_s",
                    ( const Standard_GUID & (*)() ) static_cast< const Standard_GUID & (*)() >(&TDataStd_NoteBook::GetID),
                    R"#(NoteBook methods ===============)#" 
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_NoteBook::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_NoteBook::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("ID",
             ( const Standard_GUID & (TDataStd_NoteBook::*)() const) static_cast< const Standard_GUID & (TDataStd_NoteBook::*)() const>(&TDataStd_NoteBook::ID),
             R"#()#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_NoteBook::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_NoteBook::*)() const>(&TDataStd_NoteBook::DynamicType),
             R"#()#"
             
         )
;

    // Class TDataStd_Relation from ./opencascade/TDataStd_Relation.hxx
    klass = m.attr("TDataStd_Relation");


    // nested enums

    static_cast<py::class_<TDataStd_Relation ,opencascade::handle<TDataStd_Relation>  , TDataStd_Expression >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetRelation",
             (void (TDataStd_Relation::*)(  const TCollection_ExtendedString &  ) ) static_cast<void (TDataStd_Relation::*)(  const TCollection_ExtendedString &  ) >(&TDataStd_Relation::SetRelation),
             R"#()#"  , py::arg("E")
          )
        .def("Dump",
             (Standard_OStream & (TDataStd_Relation::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDataStd_Relation::*)( Standard_OStream &  ) const>(&TDataStd_Relation::Dump),
             R"#()#"  , py::arg("anOS")
          )
        .def("DumpJson",
             (void (TDataStd_Relation::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDataStd_Relation::*)( Standard_OStream & ,  int  ) const>(&TDataStd_Relation::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
        .def("NewEmpty",
             (handle<TDF_Attribute> (TDataStd_Relation::*)() const) static_cast<handle<TDF_Attribute> (TDataStd_Relation::*)() const>(&TDataStd_Relation::NewEmpty),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("GetID_s",
                    ( const Standard_GUID & (*)() ) static_cast< const Standard_GUID & (*)() >(&TDataStd_Relation::GetID),
                    R"#(class methods =============)#" 
          )
        .def_static("Set_s",
                    (handle<TDataStd_Relation> (*)(  const TDF_Label &  ) ) static_cast<handle<TDataStd_Relation> (*)(  const TDF_Label &  ) >(&TDataStd_Relation::Set),
                    R"#(Find, or create, an Relation attribute. Real methods ============)#"  , py::arg("label")
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_Relation::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_Relation::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("GetRelation",
             ( const TCollection_ExtendedString & (TDataStd_Relation::*)() const) static_cast< const TCollection_ExtendedString & (TDataStd_Relation::*)() const>(&TDataStd_Relation::GetRelation),
             R"#()#"
             
         )
       .def("ID",
             ( const Standard_GUID & (TDataStd_Relation::*)() const) static_cast< const Standard_GUID & (TDataStd_Relation::*)() const>(&TDataStd_Relation::ID),
             R"#()#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_Relation::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_Relation::*)() const>(&TDataStd_Relation::DynamicType),
             R"#()#"
             
         )
;

    // Class TDataStd_Tick from ./opencascade/TDataStd_Tick.hxx
    klass = m.attr("TDataStd_Tick");


    // nested enums

    static_cast<py::class_<TDataStd_Tick ,opencascade::handle<TDataStd_Tick>  , TDataStd_GenericEmpty >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Dump",
             (Standard_OStream & (TDataStd_Tick::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDataStd_Tick::*)( Standard_OStream &  ) const>(&TDataStd_Tick::Dump),
             R"#()#"  , py::arg("anOS")
          )
        .def("NewEmpty",
             (handle<TDF_Attribute> (TDataStd_Tick::*)() const) static_cast<handle<TDF_Attribute> (TDataStd_Tick::*)() const>(&TDataStd_Tick::NewEmpty),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("GetID_s",
                    ( const Standard_GUID & (*)() ) static_cast< const Standard_GUID & (*)() >(&TDataStd_Tick::GetID),
                    R"#(Static methods ==============)#" 
          )
        .def_static("Set_s",
                    (handle<TDataStd_Tick> (*)(  const TDF_Label &  ) ) static_cast<handle<TDataStd_Tick> (*)(  const TDF_Label &  ) >(&TDataStd_Tick::Set),
                    R"#(Find, or create, a Tick attribute. Tick methods ============)#"  , py::arg("label")
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDataStd_Tick::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDataStd_Tick::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("ID",
             ( const Standard_GUID & (TDataStd_Tick::*)() const) static_cast< const Standard_GUID & (TDataStd_Tick::*)() const>(&TDataStd_Tick::ID),
             R"#()#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDataStd_Tick::*)() const) static_cast< const handle<Standard_Type> & (TDataStd_Tick::*)() const>(&TDataStd_Tick::DynamicType),
             R"#()#"
             
         )
;

// functions

// ./opencascade/TDataStd.hxx
// ./opencascade/TDataStd_AsciiString.hxx
// ./opencascade/TDataStd_BooleanArray.hxx
// ./opencascade/TDataStd_BooleanList.hxx
// ./opencascade/TDataStd_ByteArray.hxx
// ./opencascade/TDataStd_ChildNodeIterator.hxx
// ./opencascade/TDataStd_Comment.hxx
// ./opencascade/TDataStd_Current.hxx
// ./opencascade/TDataStd_DeltaOnModificationOfByteArray.hxx
// ./opencascade/TDataStd_DeltaOnModificationOfExtStringArray.hxx
// ./opencascade/TDataStd_DeltaOnModificationOfIntArray.hxx
// ./opencascade/TDataStd_DeltaOnModificationOfIntPackedMap.hxx
// ./opencascade/TDataStd_DeltaOnModificationOfRealArray.hxx
// ./opencascade/TDataStd_Directory.hxx
// ./opencascade/TDataStd_Expression.hxx
// ./opencascade/TDataStd_ExtStringArray.hxx
// ./opencascade/TDataStd_ExtStringList.hxx
// ./opencascade/TDataStd_GenericEmpty.hxx
// ./opencascade/TDataStd_GenericExtString.hxx
// ./opencascade/TDataStd_HDataMapOfStringByte.hxx
// ./opencascade/TDataStd_HDataMapOfStringHArray1OfInteger.hxx
// ./opencascade/TDataStd_HDataMapOfStringHArray1OfReal.hxx
// ./opencascade/TDataStd_HDataMapOfStringInteger.hxx
// ./opencascade/TDataStd_HDataMapOfStringReal.hxx
// ./opencascade/TDataStd_HDataMapOfStringString.hxx
// ./opencascade/TDataStd_IntPackedMap.hxx
// ./opencascade/TDataStd_Integer.hxx
// ./opencascade/TDataStd_IntegerArray.hxx
// ./opencascade/TDataStd_IntegerList.hxx
// ./opencascade/TDataStd_Name.hxx
// ./opencascade/TDataStd_NamedData.hxx
// ./opencascade/TDataStd_NoteBook.hxx
// ./opencascade/TDataStd_PtrTreeNode.hxx
// ./opencascade/TDataStd_Real.hxx
// ./opencascade/TDataStd_RealArray.hxx
// ./opencascade/TDataStd_RealEnum.hxx
// ./opencascade/TDataStd_RealList.hxx
// ./opencascade/TDataStd_ReferenceArray.hxx
// ./opencascade/TDataStd_ReferenceList.hxx
// ./opencascade/TDataStd_Relation.hxx
// ./opencascade/TDataStd_Tick.hxx
// ./opencascade/TDataStd_TreeNode.hxx
// ./opencascade/TDataStd_UAttribute.hxx
// ./opencascade/TDataStd_Variable.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
