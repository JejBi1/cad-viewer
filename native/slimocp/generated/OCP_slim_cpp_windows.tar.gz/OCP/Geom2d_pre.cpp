
// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;


// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Circ2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Elips2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Pnt2d.hxx>
#include <gp_Ax2d.hxx>
#include <gp_Vec2d.hxx>
#include <gp_Trsf2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Hypr2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Lin2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Parab2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Pnt2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <Geom2d_AxisPlacement.hxx>
#include <Geom2d_BezierCurve.hxx>
#include <Geom2d_BoundedCurve.hxx>
#include <Geom2d_BSplineCurve.hxx>
#include <Geom2d_CartesianPoint.hxx>
#include <Geom2d_Circle.hxx>
#include <Geom2d_Conic.hxx>
#include <Geom2d_Curve.hxx>
#include <Geom2d_Direction.hxx>
#include <Geom2d_Ellipse.hxx>
#include <Geom2d_Geometry.hxx>
#include <Geom2d_Hyperbola.hxx>
#include <Geom2d_Line.hxx>
#include <Geom2d_OffsetCurve.hxx>
#include <Geom2d_Parabola.hxx>
#include <Geom2d_Point.hxx>
#include <Geom2d_Transformation.hxx>
#include <Geom2d_TrimmedCurve.hxx>
#include <Geom2d_UndefinedDerivative.hxx>
#include <Geom2d_UndefinedValue.hxx>
#include <Geom2d_Vector.hxx>
#include <Geom2d_VectorWithMagnitude.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module
        #include <Geom2dEval_RepCurveDesc.hxx>
        

// Module definiiton
void register_Geom2d_enums(py::module &main_module) {


py::module m = main_module.def_submodule("Geom2d", R"#()#");

// add namespaces as submodules
auto Geom2dEval_RepCurveDesc = m.def_submodule("Geom2dEval_RepCurveDesc");

// user-defined inclusion per module in the body

// enums

//Python trampoline classes
    class Py_Geom2d_Geometry : public Geom2d_Geometry{
    public:
        using Geom2d_Geometry::Geom2d_Geometry;


        // public pure virtual
        void Transform( const gp_Trsf2d & T) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Geometry,Transform,T) };
        handle<Geom2d_Geometry> Copy() const  override { using return_type = handle<Geom2d_Geometry>;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Geometry,Copy,) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_Geom2d_Curve : public Geom2d_Curve{
    public:
        using Geom2d_Curve::Geom2d_Curve;


        // public pure virtual
        void Reverse() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,Reverse,) };
        double ReversedParameter( const double U) const  override { using return_type = double;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,ReversedParameter,U) };
        double FirstParameter() const  override { using return_type = double;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,FirstParameter,) };
        double LastParameter() const  override { using return_type = double;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,LastParameter,) };
        bool IsClosed() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,IsClosed,) };
        bool IsPeriodic() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,IsPeriodic,) };
        GeomAbs_Shape Continuity() const  override { using return_type = GeomAbs_Shape;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,Continuity,) };
        bool IsCN( const int N) const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,IsCN,N) };
        gp_Pnt2d EvalD0( const double U) const  override { using return_type = gp_Pnt2d;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,EvalD0,U) };
        Geom2d_Curve::ResD1 EvalD1( const double U) const  override { using return_type = Geom2d_Curve::ResD1;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,EvalD1,U) };
        Geom2d_Curve::ResD2 EvalD2( const double U) const  override { using return_type = Geom2d_Curve::ResD2;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,EvalD2,U) };
        Geom2d_Curve::ResD3 EvalD3( const double U) const  override { using return_type = Geom2d_Curve::ResD3;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,EvalD3,U) };
        gp_Vec2d EvalDN( const double U, const int N) const  override { using return_type = gp_Vec2d;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,EvalDN,U,N) };

        void Transform( const gp_Trsf2d & T) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Geometry,Transform,T) };
        handle<Geom2d_Geometry> Copy() const  override { using return_type = handle<Geom2d_Geometry>;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Geometry,Copy,) };

        // protected pure virtual


        // private pure virtual

    };
    class Py_Geom2d_Point : public Geom2d_Point{
    public:
        using Geom2d_Point::Geom2d_Point;


        // public pure virtual
        gp_Pnt2d Pnt2d() const  override { using return_type = gp_Pnt2d;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Point,Pnt2d,) };
        double X() const  override { using return_type = double;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Point,X,) };
        double Y() const  override { using return_type = double;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Point,Y,) };
        void Coord(double & X,double & Y) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Point,Coord,X,Y) };

        void Transform( const gp_Trsf2d & T) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Geometry,Transform,T) };
        handle<Geom2d_Geometry> Copy() const  override { using return_type = handle<Geom2d_Geometry>;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Geometry,Copy,) };

        // protected pure virtual


        // private pure virtual

    };
    class Py_Geom2d_Vector : public Geom2d_Vector{
    public:
        using Geom2d_Vector::Geom2d_Vector;


        // public pure virtual
        double Magnitude() const  override { using return_type = double;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Vector,Magnitude,) };
        double SquareMagnitude() const  override { using return_type = double;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Vector,SquareMagnitude,) };
        double Crossed( const handle<Geom2d_Vector> & Other) const  override { using return_type = double;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Vector,Crossed,Other) };

        void Transform( const gp_Trsf2d & T) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Geometry,Transform,T) };
        handle<Geom2d_Geometry> Copy() const  override { using return_type = handle<Geom2d_Geometry>;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Geometry,Copy,) };

        // protected pure virtual


        // private pure virtual

    };
    class Py_Geom2d_BoundedCurve : public Geom2d_BoundedCurve{
    public:
        using Geom2d_BoundedCurve::Geom2d_BoundedCurve;


        // public pure virtual
        gp_Pnt2d EndPoint() const  override { using return_type = gp_Pnt2d;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_BoundedCurve,EndPoint,) };
        gp_Pnt2d StartPoint() const  override { using return_type = gp_Pnt2d;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_BoundedCurve,StartPoint,) };

        void Reverse() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,Reverse,) };
        double ReversedParameter( const double U) const  override { using return_type = double;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,ReversedParameter,U) };
        double FirstParameter() const  override { using return_type = double;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,FirstParameter,) };
        double LastParameter() const  override { using return_type = double;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,LastParameter,) };
        bool IsClosed() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,IsClosed,) };
        bool IsPeriodic() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,IsPeriodic,) };
        GeomAbs_Shape Continuity() const  override { using return_type = GeomAbs_Shape;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,Continuity,) };
        bool IsCN( const int N) const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,IsCN,N) };
        gp_Pnt2d EvalD0( const double U) const  override { using return_type = gp_Pnt2d;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,EvalD0,U) };
        Geom2d_Curve::ResD1 EvalD1( const double U) const  override { using return_type = Geom2d_Curve::ResD1;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,EvalD1,U) };
        Geom2d_Curve::ResD2 EvalD2( const double U) const  override { using return_type = Geom2d_Curve::ResD2;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,EvalD2,U) };
        Geom2d_Curve::ResD3 EvalD3( const double U) const  override { using return_type = Geom2d_Curve::ResD3;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,EvalD3,U) };
        gp_Vec2d EvalDN( const double U, const int N) const  override { using return_type = gp_Vec2d;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,EvalDN,U,N) };
        void Transform( const gp_Trsf2d & T) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Geometry,Transform,T) };
        handle<Geom2d_Geometry> Copy() const  override { using return_type = handle<Geom2d_Geometry>;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Geometry,Copy,) };

        // protected pure virtual


        // private pure virtual

    };
    class Py_Geom2d_Conic : public Geom2d_Conic{
    public:
        using Geom2d_Conic::Geom2d_Conic;


        // public pure virtual
        double Eccentricity() const  override { using return_type = double;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Conic,Eccentricity,) };
        double ReversedParameter( const double U) const  override { using return_type = double;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Conic,ReversedParameter,U) };

        double FirstParameter() const  override { using return_type = double;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,FirstParameter,) };
        double LastParameter() const  override { using return_type = double;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,LastParameter,) };
        bool IsClosed() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,IsClosed,) };
        bool IsPeriodic() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,IsPeriodic,) };
        gp_Pnt2d EvalD0( const double U) const  override { using return_type = gp_Pnt2d;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,EvalD0,U) };
        Geom2d_Curve::ResD1 EvalD1( const double U) const  override { using return_type = Geom2d_Curve::ResD1;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,EvalD1,U) };
        Geom2d_Curve::ResD2 EvalD2( const double U) const  override { using return_type = Geom2d_Curve::ResD2;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,EvalD2,U) };
        Geom2d_Curve::ResD3 EvalD3( const double U) const  override { using return_type = Geom2d_Curve::ResD3;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,EvalD3,U) };
        gp_Vec2d EvalDN( const double U, const int N) const  override { using return_type = gp_Vec2d;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Curve,EvalDN,U,N) };
        void Transform( const gp_Trsf2d & T) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Geometry,Transform,T) };
        handle<Geom2d_Geometry> Copy() const  override { using return_type = handle<Geom2d_Geometry>;
    PYBIND11_OVERLOAD_PURE(return_type,Geom2d_Geometry,Copy,) };

        // protected pure virtual


        // private pure virtual

    };

// pre-register typdefs+classes (topologically sorted)
    py::class_<Geom2d_Geometry ,opencascade::handle<Geom2d_Geometry> ,Py_Geom2d_Geometry , Standard_Transient >(
      m,
      "Geom2d_Geometry",R"#(The general abstract class Geometry in 2D space describes the common behaviour of all the geometric entities.)#"
    );
    py::class_<Geom2d_Transformation ,opencascade::handle<Geom2d_Transformation>  , Standard_Transient >(
      m,
      "Geom2d_Transformation",R"#(The class Transformation allows to create Translation, Rotation, Symmetry, Scaling and complex transformations obtained by combination of the previous elementary transformations. The Transformation class can also be used to construct complex transformations by combining these elementary transformations. However, these transformations can never change the type of an object. For example, the projection transformation can change a circle into an ellipse, and therefore change the real type of the object. Such a transformation is forbidden in this environment and cannot be a Geom2d_Transformation. The transformation can be represented as follows:)#"
    );
    py::class_<Geom2d_AxisPlacement ,opencascade::handle<Geom2d_AxisPlacement>  , Geom2d_Geometry >(
      m,
      "Geom2d_AxisPlacement",R"#(Describes an axis in 2D space. An axis is defined by: - its origin, also termed the "Location point" of the axis, - its unit vector, termed the "Direction" of the axis. Note: Geom2d_AxisPlacement axes provide the same kind of "geometric" services as gp_Ax2d axes but have more complex data structures. The geometric objects provided by the Geom2d package use gp_Ax2d objects to include axes in their data structures, or to define an axis of symmetry or axis of rotation. Geom2d_AxisPlacement axes are used in a context where they can be shared by several objects contained inside a common data structure.)#"
    );
    py::class_<Geom2d_Curve ,opencascade::handle<Geom2d_Curve> ,Py_Geom2d_Curve , Geom2d_Geometry >(
      m,
      "Geom2d_Curve",R"#(The abstract class Curve describes the common behavior of curves in 2D space. The Geom2d package provides numerous concrete classes of derived curves, including lines, circles, conics, Bezier or BSpline curves, etc. The main characteristic of these curves is that they are parameterized. The Geom2d_Curve class shows: - how to work with the parametric equation of a curve in order to calculate the point of parameter u, together with the vector tangent and the derivative vectors of order 2, 3,..., N at this point; - how to obtain general information about the curve (for example, level of continuity, closed characteristics, periodicity, bounds of the parameter field); - how the parameter changes when a geometric transformation is applied to the curve or when the orientation of the curve is inverted. All curves must have a geometric continuity: a curve is at least "C0". Generally, this property is checked at the time of construction or when the curve is edited. Where this is not the case, the documentation explicitly states so. Warning The Geom2d package does not prevent the construction of curves with null length or curves which self-intersect.)#"
    );
    py::class_<Geom2d_Point ,opencascade::handle<Geom2d_Point> ,Py_Geom2d_Point , Geom2d_Geometry >(
      m,
      "Geom2d_Point",R"#(The abstract class Point describes the common behavior of geometric points in 2D space. The Geom2d package also provides the concrete class Geom2d_CartesianPoint.)#"
    );
    py::class_<Geom2d_Vector ,opencascade::handle<Geom2d_Vector> ,Py_Geom2d_Vector , Geom2d_Geometry >(
      m,
      "Geom2d_Vector",R"#(The abstract class Vector describes the common behavior of vectors in 2D space. The Geom2d package provides two concrete classes of vectors: Geom2d_Direction (unit vector) and Geom2d_VectorWithMagnitude.)#"
    );
    py::class_<Geom2d_BoundedCurve ,opencascade::handle<Geom2d_BoundedCurve> ,Py_Geom2d_BoundedCurve , Geom2d_Curve >(
      m,
      "Geom2d_BoundedCurve",R"#(The abstract class BoundedCurve describes the common behavior of bounded curves in 2D space. A bounded curve is limited by two finite values of the parameter, termed respectively "first parameter" and "last parameter". The "first parameter" gives the "start point" of the bounded curve, and the "last parameter" gives the "end point" of the bounded curve. The length of a bounded curve is finite. The Geom2d package provides three concrete classes of bounded curves: - two frequently used mathematical formulations of complex curves: - Geom2d_BezierCurve, - Geom2d_BSplineCurve, and - Geom2d_TrimmedCurve to trim a curve, i.e. to only take part of the curve limited by two values of the parameter of the basis curve.)#"
    );
    py::class_<Geom2d_CartesianPoint ,opencascade::handle<Geom2d_CartesianPoint>  , Geom2d_Point >(
      m,
      "Geom2d_CartesianPoint",R"#(Describes a point in 2D space. A Geom2d_CartesianPoint is defined by a gp_Pnt2d point, with its two Cartesian coordinates X and Y.)#"
    );
    py::class_<Geom2d_Conic ,opencascade::handle<Geom2d_Conic> ,Py_Geom2d_Conic , Geom2d_Curve >(
      m,
      "Geom2d_Conic",R"#(The abstract class Conic describes the common behavior of conic curves in 2D space and, in particular, their general characteristics. The Geom2d package provides four specific classes of conics: Geom2d_Circle, Geom2d_Ellipse, Geom2d_Hyperbola and Geom2d_Parabola. A conic is positioned in the plane with a coordinate system (gp_Ax22d object), where the origin is the center of the conic (or the apex in case of a parabola). This coordinate system is the local coordinate system of the conic. It gives the conic an explicit orientation, determining the direction in which the parameter increases along the conic. The "X Axis" of the local coordinate system also defines the origin of the parameter of the conic.)#"
    );
    py::class_<Geom2d_Direction ,opencascade::handle<Geom2d_Direction>  , Geom2d_Vector >(
      m,
      "Geom2d_Direction",R"#(The class Direction specifies a vector that is never null. It is a unit vector.)#"
    );
    py::class_<Geom2d_Line ,opencascade::handle<Geom2d_Line>  , Geom2d_Curve >(
      m,
      "Geom2d_Line",R"#(Describes an infinite line in the plane (2D space). A line is defined and positioned in the plane with an axis (gp_Ax2d object) which gives it an origin and a unit vector. The Geom2d_Line line is parameterized as follows: P (U) = O + U*Dir where: - P is the point of parameter U, - O is the origin and Dir the unit vector of its positioning axis. The parameter range is ] -infinite, +infinite [. The orientation of the line is given by the unit vector of its positioning axis. See Also GCE2d_MakeLine which provides functions for more complex line constructions gp_Ax2d gp_Lin2d for an equivalent, non-parameterized data structure.)#"
    );
    py::class_<Geom2d_OffsetCurve ,opencascade::handle<Geom2d_OffsetCurve>  , Geom2d_Curve >(
      m,
      "Geom2d_OffsetCurve",R"#(This class implements the basis services for the creation, edition, modification and evaluation of planar offset curve. The offset curve is obtained by offsetting by distance along the normal to a basis curve defined in 2D space. The offset curve in this package can be a self intersecting curve even if the basis curve does not self-intersect. The self intersecting portions are not deleted at the construction time. An offset curve is a curve at constant distance (Offset) from a basis curve and the offset curve takes its parametrization from the basis curve. The Offset curve is in the direction of the normal to the basis curve N. The distance offset may be positive or negative to indicate the preferred side of the curve : . distance offset >0 => the curve is in the direction of N . distance offset >0 => the curve is in the direction of - N On the Offset curve : Value(u) = BasisCurve.Value(U) + (Offset * (T ^ Z)) / ||T ^ Z|| where T is the tangent vector to the basis curve and Z the direction of the normal vector to the plane of the curve, N = T ^ Z defines the offset direction and should not have null length.)#"
    );
    py::class_<Geom2d_VectorWithMagnitude ,opencascade::handle<Geom2d_VectorWithMagnitude>  , Geom2d_Vector >(
      m,
      "Geom2d_VectorWithMagnitude",R"#(Defines a vector with magnitude. A vector with magnitude can have a zero length.)#"
    );
    py::class_<Geom2d_BSplineCurve ,opencascade::handle<Geom2d_BSplineCurve>  , Geom2d_BoundedCurve >(
      m,
      "Geom2d_BSplineCurve",R"#(Describes a BSpline curve. A BSpline curve can be: - uniform or non-uniform, - rational or non-rational, - periodic or non-periodic. A BSpline curve is defined by: - its degree; the degree for a Geom2d_BSplineCurve is limited to a value (25) which is defined and controlled by the system. This value is returned by the function MaxDegree; - its periodic or non-periodic nature; - a table of poles (also called control points), with their associated weights if the BSpline curve is rational. The poles of the curve are "control points" used to deform the curve. If the curve is non-periodic, the first pole is the start point of the curve, and the last pole is the end point of the curve. The segment, which joins the first pole to the second pole, is the tangent to the curve at its start point, and the segment, which joins the last pole to the second-from-last pole, is the tangent to the curve at its end point. If the curve is periodic, these geometric properties are not verified. It is more difficult to give a geometric signification to the weights but they are useful for providing exact representations of the arcs of a circle or ellipse. Moreover, if the weights of all the poles are equal, the curve has a polynomial equation; it is therefore a non-rational curve. - a table of knots with their multiplicities. For a Geom2d_BSplineCurve, the table of knots is an increasing sequence of reals without repetition; the multiplicities define the repetition of the knots. A BSpline curve is a piecewise polynomial or rational curve. The knots are the parameters of junction points between two pieces. The multiplicity Mult(i) of the knot Knot(i) of the BSpline curve is related to the degree of continuity of the curve at the knot Knot(i), which is equal to Degree - Mult(i) where Degree is the degree of the BSpline curve. If the knots are regularly spaced (i.e. the difference between two consecutive knots is a constant), three specific and frequently used cases of knot distribution can be identified: - "uniform" if all multiplicities are equal to 1, - "quasi-uniform" if all multiplicities are equal to 1, except the first and the last knot which have a multiplicity of Degree + 1, where Degree is the degree of the BSpline curve, - "Piecewise Bezier" if all multiplicities are equal to Degree except the first and last knot which have a multiplicity of Degree + 1, where Degree is the degree of the BSpline curve. A curve of this type is a concatenation of arcs of Bezier curves. If the BSpline curve is not periodic: - the bounds of the Poles and Weights tables are 1 and NbPoles, where NbPoles is the number of poles of the BSpline curve, - the bounds of the Knots and Multiplicities tables are 1 and NbKnots, where NbKnots is the number of knots of the BSpline curve. If the BSpline curve is periodic, and if there are k periodic knots and p periodic poles, the period is: period = Knot(k + 1) - Knot(1) and the poles and knots tables can be considered as infinite tables, such that: - Knot(i+k) = Knot(i) + period - Pole(i+p) = Pole(i) Note: data structures of a periodic BSpline curve are more complex than those of a non-periodic one. Warnings: In this class we consider that a weight value is zero if Weight <= Resolution from package gp. For two parametric values (or two knot values) U1, U2 we consider that U1 = U2 if Abs (U2 - U1) <= Epsilon (U1). For two weights values W1, W2 we consider that W1 = W2 if Abs (W2 - W1) <= Epsilon (W1). The method Epsilon is defined in the class Real from package Standard.)#"
    );
    py::class_<Geom2d_BezierCurve ,opencascade::handle<Geom2d_BezierCurve>  , Geom2d_BoundedCurve >(
      m,
      "Geom2d_BezierCurve",R"#(Describes a rational or non-rational Bezier curve - a non-rational Bezier curve is defined by a table of poles (also called control points), - a rational Bezier curve is defined by a table of poles with varying weights. These data are manipulated by two parallel arrays: - the poles table, which is an array of gp_Pnt2d points, and - the weights table, which is an array of reals. The bounds of these arrays are 1 and "the number of poles" of the curve. The poles of the curve are "control points" used to deform the curve. The first pole is the start point of the curve, and the last pole is the end point of the curve. The segment which joins the first pole to the second pole is the tangent to the curve at its start point, and the segment which joins the last pole to the second-from-last pole is the tangent to the curve at its end point. It is more difficult to give a geometric signification to the weights but they are useful for providing exact representations of the arcs of a circle or ellipse. Moreover, if the weights of all the poles are equal, the curve is polynomial; it is therefore a non-rational curve. The non-rational curve is a special and frequently used case. The weights are defined and used only in case of a rational curve. The degree of a Bezier curve is equal to the number of poles, minus 1. It must be greater than or equal to 1. However, the degree of a Geom2d_BezierCurve curve is limited to a value (25) which is defined and controlled by the system. This value is returned by the function MaxDegree. The parameter range for a Bezier curve is [ 0, 1 ]. If the first and last control points of the Bezier curve are the same point then the curve is closed. For example, to create a closed Bezier curve with four control points, you have to give a set of control points P1, P2, P3 and P1. The continuity of a Bezier curve is infinite. It is not possible to build a Bezier curve with negative weights. We consider that a weight value is zero if it is less than or equal to gp::Resolution(). We also consider that two weight values W1 and W2 are equal if: |W2 - W1| <= gp::Resolution(). Warning - When considering the continuity of a closed Bezier curve at the junction point, remember that a curve of this type is never periodic. This means that the derivatives for the parameter u = 0 have no reason to be the same as the derivatives for the parameter u = 1 even if the curve is closed. - The length of a Bezier curve can be null.)#"
    );
    py::class_<Geom2d_Circle ,opencascade::handle<Geom2d_Circle>  , Geom2d_Conic >(
      m,
      "Geom2d_Circle",R"#(Describes a circle in the plane (2D space). A circle is defined by its radius and, as with any conic curve, is positioned in the plane with a coordinate system (gp_Ax22d object) where the origin is the center of the circle. The coordinate system is the local coordinate system of the circle. The orientation (direct or indirect) of the local coordinate system gives an explicit orientation to the circle, determining the direction in which the parameter increases along the circle. The Geom2d_Circle circle is parameterized by an angle: P(U) = O + R*std::cos(U)*XDir + R*Sin(U)*YDir where: - P is the point of parameter U, - O, XDir and YDir are respectively the origin, "X Direction" and "Y Direction" of its local coordinate system, - R is the radius of the circle. The "X Axis" of the local coordinate system therefore defines the origin of the parameter of the circle. The parameter is the angle with this "X Direction". A circle is a closed and periodic curve. The period is 2.*Pi and the parameter range is [ 0,2.*Pi [. See Also GCE2d_MakeCircle which provides functions for more complex circle constructions gp_Ax22d and gp_Circ2d for an equivalent, non-parameterized data structure.)#"
    );
    py::class_<Geom2d_Ellipse ,opencascade::handle<Geom2d_Ellipse>  , Geom2d_Conic >(
      m,
      "Geom2d_Ellipse",R"#(Describes an ellipse in the plane (2D space). An ellipse is defined by its major and minor radii and, as with any conic curve, is positioned in the plane with a coordinate system (gp_Ax22d object) where: - the origin is the center of the ellipse, - the "X Direction" defines the major axis, and - the "Y Direction" defines the minor axis. This coordinate system is the local coordinate system of the ellipse. The orientation (direct or indirect) of the local coordinate system gives an explicit orientation to the ellipse, determining the direction in which the parameter increases along the ellipse. The Geom2d_Ellipse ellipse is parameterized by an angle: P(U) = O + MajorRad*std::cos(U)*XDir + MinorRad*Sin(U)*YDir where: - P is the point of parameter U, - O, XDir and YDir are respectively the origin, "X Direction" and "Y Direction" of its local coordinate system, - MajorRad and MinorRad are the major and minor radii of the ellipse. The "X Axis" of the local coordinate system therefore defines the origin of the parameter of the ellipse. An ellipse is a closed and periodic curve. The period is 2.*Pi and the parameter range is [ 0,2.*Pi [. See Also GCE2d_MakeEllipse which provides functions for more complex ellipse constructions gp_Ax22d gp_Elips2d for an equivalent, non-parameterized data structure)#"
    );
    py::class_<Geom2d_Hyperbola ,opencascade::handle<Geom2d_Hyperbola>  , Geom2d_Conic >(
      m,
      "Geom2d_Hyperbola",R"#(Describes a branch of a hyperbola in the plane (2D space). A hyperbola is defined by its major and minor radii and, as with any conic curve, is positioned in the plane with a coordinate system (gp_Ax22d object) where: - the origin is the center of the hyperbola, - the "X Direction" defines the major axis, and - the "Y Direction" defines the minor axis. This coordinate system is the local coordinate system of the hyperbola. The branch of the hyperbola described is the one located on the positive side of the major axis. The orientation (direct or indirect) of the local coordinate system gives an explicit orientation to the hyperbola, determining the direction in which the parameter increases along the hyperbola. The Geom2d_Hyperbola hyperbola is parameterized as follows: P(U) = O + MajRad*std::cosh(U)*XDir + MinRad*std::sinh(U)*YDir where: - P is the point of parameter U, - O, XDir and YDir are respectively the origin, "X Direction" and "Y Direction" of its local coordinate system, - MajRad and MinRad are the major and minor radii of the hyperbola. The "X Axis" of the local coordinate system therefore defines the origin of the parameter of the hyperbola. The parameter range is ] -infinite,+infinite [. The following diagram illustrates the respective positions, in the plane of the hyperbola, of the three branches of hyperbolas constructed using the functions OtherBranch, ConjugateBranch1 and ConjugateBranch2: ^YAxis | FirstConjugateBranch | Other | Main --------------------- C --------------------->XAxis Branch | Branch | SecondConjugateBranch | Warning The value of the major radius (on the major axis) can be less than the value of the minor radius (on the minor axis). See Also GCE2d_MakeHyperbola which provides functions for more complex hyperbola constructions gp_Ax22d gp_Hypr2d for an equivalent, non-parameterized data structure)#"
    );
    py::class_<Geom2d_Parabola ,opencascade::handle<Geom2d_Parabola>  , Geom2d_Conic >(
      m,
      "Geom2d_Parabola",R"#(Describes a parabola in the plane (2D space). A parabola is defined by its focal length (i.e. the distance between its focus and its apex) and is positioned in the plane with a coordinate system (gp_Ax22d object) where: - the origin is the apex of the parabola, and - the "X Axis" defines the axis of symmetry; the parabola is on the positive side of this axis. This coordinate system is the local coordinate system of the parabola. The orientation (direct or indirect) of the local coordinate system gives an explicit orientation to the parabola, determining the direction in which the parameter increases along the parabola. The Geom_Parabola parabola is parameterized as follows: P(U) = O + U*U/(4.*F)*XDir + U*YDir, where: - P is the point of parameter U, - O, XDir and YDir are respectively the origin, "X Direction" and "Y Direction" of its local coordinate system, - F is the focal length of the parabola. The parameter of the parabola is therefore its Y coordinate in the local coordinate system, with the "X Axis" of the local coordinate system defining the origin of the parameter. The parameter range is ] -infinite,+infinite [.)#"
    );
    py::class_<Geom2d_TrimmedCurve ,opencascade::handle<Geom2d_TrimmedCurve>  , Geom2d_BoundedCurve >(
      m,
      "Geom2d_TrimmedCurve",R"#(Defines a portion of a curve limited by two values of parameters inside the parametric domain of the curve. The trimmed curve is defined by: - the basis curve, and - the two parameter values which limit it. The trimmed curve can either have the same orientation as the basis curve or the opposite orientation.)#"
    );

// preregister user-defined template specializations

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
