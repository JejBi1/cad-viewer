
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_ExtendedString.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_HExtendedString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_HAsciiString.hxx>

// module includes
#include <TCollection.hxx>
#include <TCollection_AsciiString.hxx>
#include <TCollection_ExtendedString.hxx>
#include <TCollection_HAsciiString.hxx>
#include <TCollection_HExtendedString.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_TCollection(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("TCollection"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes

// classes

    // Class TCollection from ./opencascade/TCollection.hxx
    klass = m.attr("TCollection");

    // default constructor
    register_default_constructor<TCollection , shared_ptr<TCollection>>(m,"TCollection");

    // nested enums

    static_cast<py::class_<TCollection , shared_ptr<TCollection>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("NextPrimeForMap_s",
                    (int (*)(  const int  ) ) static_cast<int (*)(  const int  ) >(&TCollection::NextPrimeForMap),
                    R"#(Returns a prime number greater than <I> suitable to dimension a Map. When <I> becomes great there is a limit on the result (today the limit is around 1 000 000). This is not a limit of the number of items but a limit in the number of buckets. i.e. there will be more collisions in the map.)#"  , py::arg("I")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class TCollection_AsciiString from ./opencascade/TCollection_AsciiString.hxx
    klass = m.attr("TCollection_AsciiString");


    // nested enums

    static_cast<py::class_<TCollection_AsciiString , shared_ptr<TCollection_AsciiString>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const TCollection_AsciiString & >()  , py::arg("theString") )
        .def(py::init<  const TCollection_AsciiString &, const TCollection_AsciiString & >()  , py::arg("theString"),  py::arg("theOtherString") )
        .def(py::init<  const TCollection_AsciiString &, const char * const  >()  , py::arg("theString"),  py::arg("theMessage") )
        .def(py::init<  const TCollection_AsciiString &, const char >()  , py::arg("theString"),  py::arg("theChar") )
        .def(py::init<  const TCollection_ExtendedString &, const char >()  , py::arg("theExtendedString"),  py::arg("theReplaceNonAscii")=static_cast< const char>(0) )
        .def(py::init<  const char * const  >()  , py::arg("theMessage") )
        .def(py::init<  const char * const , const int >()  , py::arg("theMessage"),  py::arg("theLength") )
        .def(py::init<  const char >()  , py::arg("theChar") )
        .def(py::init<  const double >()  , py::arg("theValue") )
        .def(py::init<  const int >()  , py::arg("theValue") )
        .def(py::init<  const int, const char >()  , py::arg("theLength"),  py::arg("theFiller") )
        .def(py::init<  const typename std::string_view & >()  , py::arg("theStringView") )
        .def(py::init<  const wchar_t * >()  , py::arg("theStringUtf") )
    // custom constructors
        .def(py::init( [](const std::string &s){ return TCollection_AsciiString(s.c_str()); } ))
    // methods
        .def("AssignCat",
             (void (TCollection_AsciiString::*)(  const char  ) ) static_cast<void (TCollection_AsciiString::*)(  const char  ) >(&TCollection_AsciiString::AssignCat),
             R"#(Appends other character to this string. This is an unary operator.)#"  , py::arg("theOther")
          )
        .def("AssignCat",
             (void (TCollection_AsciiString::*)(  const int  ) ) static_cast<void (TCollection_AsciiString::*)(  const int  ) >(&TCollection_AsciiString::AssignCat),
             R"#(Appends other integer to this string. This is an unary operator.)#"  , py::arg("theOther")
          )
        .def("AssignCat",
             (void (TCollection_AsciiString::*)(  const double  ) ) static_cast<void (TCollection_AsciiString::*)(  const double  ) >(&TCollection_AsciiString::AssignCat),
             R"#(Appends other real number to this string. This is an unary operator.)#"  , py::arg("theOther")
          )
        .def("AssignCat",
             (void (TCollection_AsciiString::*)(  const TCollection_ExtendedString & ,   const char  ) ) static_cast<void (TCollection_AsciiString::*)(  const TCollection_ExtendedString & ,   const char  ) >(&TCollection_AsciiString::AssignCat),
             R"#(Appends an extended string to this ASCII string. If theReplaceNonAscii is non-null character, it will be used in place of any non-ASCII character found in the source string. Otherwise, appends UTF-8 representation of the source string.)#"  , py::arg("theOther"),  py::arg("theReplaceNonAscii")=static_cast< const char>(0)
          )
        .def("AssignCat",
             (void (TCollection_AsciiString::*)(  const wchar_t *  ) ) static_cast<void (TCollection_AsciiString::*)(  const wchar_t *  ) >(&TCollection_AsciiString::AssignCat),
             R"#(Appends wide-char string converted to UTF-8 representation.)#"  , py::arg("theStringUtf")
          )
        .def("AssignCat",
             (void (TCollection_AsciiString::*)(  const char * const  ,   const int  ) ) static_cast<void (TCollection_AsciiString::*)(  const char * const  ,   const int  ) >(&TCollection_AsciiString::AssignCat),
             R"#(Core implementation: Appends string (pointer and length) to this ASCII string. This is the primary implementation that all other AssignCat overloads redirect to.)#"  , py::arg("theString"),  py::arg("theLength")
          )
        .def("AssignCat",
             (void (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) ) static_cast<void (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) >(&TCollection_AsciiString::AssignCat),
             R"#(Appends other string to this string. This is an unary operator.)#"  , py::arg("theOther")
          )
        .def("AssignCat",
             (void (TCollection_AsciiString::*)(  const char * const   ) ) static_cast<void (TCollection_AsciiString::*)(  const char * const   ) >(&TCollection_AsciiString::AssignCat),
             R"#(Appends C string to this ASCII string.)#"  , py::arg("theCString")
          )
        .def("AssignCat",
             (void (TCollection_AsciiString::*)(  const typename std::string_view &  ) ) static_cast<void (TCollection_AsciiString::*)(  const typename std::string_view &  ) >(&TCollection_AsciiString::AssignCat),
             R"#(Appends string view to this ASCII string. This is an unary operator.)#"  , py::arg("theStringView")
          )
        .def("Capitalize",
             (void (TCollection_AsciiString::*)() ) static_cast<void (TCollection_AsciiString::*)() >(&TCollection_AsciiString::Capitalize),
             R"#(Converts the first character into its corresponding upper-case character and the other characters into lowercase)#" 
          )
        .def("Cat",
             (TCollection_AsciiString (TCollection_AsciiString::*)(  const char * const  ,   const int  ) const) static_cast<TCollection_AsciiString (TCollection_AsciiString::*)(  const char * const  ,   const int  ) const>(&TCollection_AsciiString::Cat),
             R"#(Core implementation: Appends string (pointer and length) to this ASCII string and returns a new string. This is the primary implementation that all other Cat overloads redirect to.)#"  , py::arg("theString"),  py::arg("theLength")
          )
        .def("Cat",
             (TCollection_AsciiString (TCollection_AsciiString::*)(  const char  ) const) static_cast<TCollection_AsciiString (TCollection_AsciiString::*)(  const char  ) const>(&TCollection_AsciiString::Cat),
             R"#(Appends other character to this string.)#"  , py::arg("theOther")
          )
        .def("Cat",
             (TCollection_AsciiString (TCollection_AsciiString::*)(  const int  ) const) static_cast<TCollection_AsciiString (TCollection_AsciiString::*)(  const int  ) const>(&TCollection_AsciiString::Cat),
             R"#(Appends other integer to this string.)#"  , py::arg("theOther")
          )
        .def("Cat",
             (TCollection_AsciiString (TCollection_AsciiString::*)(  const double  ) const) static_cast<TCollection_AsciiString (TCollection_AsciiString::*)(  const double  ) const>(&TCollection_AsciiString::Cat),
             R"#(Appends other real number to this string.)#"  , py::arg("theOther")
          )
        .def("Cat",
             (TCollection_AsciiString (TCollection_AsciiString::*)(  const TCollection_ExtendedString & ,   const char  ) const) static_cast<TCollection_AsciiString (TCollection_AsciiString::*)(  const TCollection_ExtendedString & ,   const char  ) const>(&TCollection_AsciiString::Cat),
             R"#(Appends extended string to this string. If theReplaceNonAscii is non-null character, it will be used in place of any non-ASCII character found in the source string. Otherwise, concatenates UTF-8 representation of the source string.)#"  , py::arg("theOther"),  py::arg("theReplaceNonAscii")=static_cast< const char>(0)
          )
        .def("Cat",
             (TCollection_AsciiString (TCollection_AsciiString::*)(  const wchar_t *  ) const) static_cast<TCollection_AsciiString (TCollection_AsciiString::*)(  const wchar_t *  ) const>(&TCollection_AsciiString::Cat),
             R"#(Appends wide-char string converted to UTF-8 representation.)#"  , py::arg("theStringUtf")
          )
        .def("Cat",
             (TCollection_AsciiString (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const) static_cast<TCollection_AsciiString (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const>(&TCollection_AsciiString::Cat),
             R"#(Appends other string to this string.)#"  , py::arg("theOther")
          )
        .def("Cat",
             (TCollection_AsciiString (TCollection_AsciiString::*)(  const char * const   ) const) static_cast<TCollection_AsciiString (TCollection_AsciiString::*)(  const char * const   ) const>(&TCollection_AsciiString::Cat),
             R"#(Appends C string to this ASCII string.)#"  , py::arg("theCString")
          )
        .def("Cat",
             (TCollection_AsciiString (TCollection_AsciiString::*)(  const typename std::string_view &  ) const) static_cast<TCollection_AsciiString (TCollection_AsciiString::*)(  const typename std::string_view &  ) const>(&TCollection_AsciiString::Cat),
             R"#(Appends string view to this ASCII string.)#"  , py::arg("theStringView")
          )
        .def("Center",
             (void (TCollection_AsciiString::*)(  const int ,   const char  ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const char  ) >(&TCollection_AsciiString::Center),
             R"#(Modifies this ASCII string so that its length becomes equal to Width and the new characters are equal to Filler. New characters are added both at the beginning and at the end of this string. If Width is less than the length of this ASCII string, nothing happens.)#"  , py::arg("theWidth"),  py::arg("theFiller")
          )
        .def("ChangeAll",
             (void (TCollection_AsciiString::*)(  const char ,   const char ,   const bool  ) ) static_cast<void (TCollection_AsciiString::*)(  const char ,   const char ,   const bool  ) >(&TCollection_AsciiString::ChangeAll),
             R"#(Substitutes all the characters equal to aChar by NewChar in this AsciiString. The substitution can be case sensitive. If you don't use default case sensitive, no matter whether aChar is uppercase or not.)#"  , py::arg("theChar"),  py::arg("theNewChar"),  py::arg("theCaseSensitive")=static_cast< const bool>(true)
          )
        .def("Clear",
             (void (TCollection_AsciiString::*)() ) static_cast<void (TCollection_AsciiString::*)() >(&TCollection_AsciiString::Clear),
             R"#(Removes all characters contained in this string. This produces an empty AsciiString.)#" 
          )
        .def("Copy",
             (void (TCollection_AsciiString::*)(  const char * const  ,   const int  ) ) static_cast<void (TCollection_AsciiString::*)(  const char * const  ,   const int  ) >(&TCollection_AsciiString::Copy),
             R"#(Core implementation: Copy string (pointer and length) to this ASCII string. This is the primary implementation that all other Copy overloads redirect to. Used as operator =)#"  , py::arg("theString"),  py::arg("theLength")
          )
        .def("Copy",
             (void (TCollection_AsciiString::*)(  const char * const   ) ) static_cast<void (TCollection_AsciiString::*)(  const char * const   ) >(&TCollection_AsciiString::Copy),
             R"#(Copy C string to this ASCII string. Used as operator =)#"  , py::arg("theCString")
          )
        .def("Copy",
             (void (TCollection_AsciiString::*)(  const typename std::string_view &  ) ) static_cast<void (TCollection_AsciiString::*)(  const typename std::string_view &  ) >(&TCollection_AsciiString::Copy),
             R"#(Copy string view to this ASCII string. Used as operator =)#"  , py::arg("theStringView")
          )
        .def("Copy",
             (void (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) ) static_cast<void (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) >(&TCollection_AsciiString::Copy),
             R"#(Copy fromwhere to this string. Used as operator =)#"  , py::arg("theFromWhere")
          )
        .def("Swap",
             (void (TCollection_AsciiString::*)( TCollection_AsciiString &  ) ) static_cast<void (TCollection_AsciiString::*)( TCollection_AsciiString &  ) >(&TCollection_AsciiString::Swap),
             R"#(Exchange the data of two strings (without reallocating memory).)#"  , py::arg("theOther")
          )
        .def("FirstLocationInSet",
             (int (TCollection_AsciiString::*)(  const char * const  ,   const int ,   const int ,   const int  ) const) static_cast<int (TCollection_AsciiString::*)(  const char * const  ,   const int ,   const int ,   const int  ) const>(&TCollection_AsciiString::FirstLocationInSet),
             R"#(Core implementation: Returns the index of the first character of this string that is present in the given character set (pointer and length). The search begins at index FromIndex and ends at index ToIndex. Returns zero if failure. Raises an exception if FromIndex or ToIndex is out of range.)#"  , py::arg("theSet"),  py::arg("theSetLength"),  py::arg("theFromIndex"),  py::arg("theToIndex")
          )
        .def("FirstLocationInSet",
             (int (TCollection_AsciiString::*)(  const TCollection_AsciiString & ,   const int ,   const int  ) const) static_cast<int (TCollection_AsciiString::*)(  const TCollection_AsciiString & ,   const int ,   const int  ) const>(&TCollection_AsciiString::FirstLocationInSet),
             R"#(Returns the index of the first character of this string that is present in Set. The search begins to the index FromIndex and ends to the the index ToIndex. Returns zero if failure. Raises an exception if FromIndex or ToIndex is out of range.)#"  , py::arg("theSet"),  py::arg("theFromIndex"),  py::arg("theToIndex")
          )
        .def("FirstLocationInSet",
             (int (TCollection_AsciiString::*)(  const typename std::string_view & ,   const int ,   const int  ) const) static_cast<int (TCollection_AsciiString::*)(  const typename std::string_view & ,   const int ,   const int  ) const>(&TCollection_AsciiString::FirstLocationInSet),
             R"#(Returns the index of the first character of this string that is present in string_view.)#"  , py::arg("theSet"),  py::arg("theFromIndex"),  py::arg("theToIndex")
          )
        .def("FirstLocationNotInSet",
             (int (TCollection_AsciiString::*)(  const char * const  ,   const int ,   const int ,   const int  ) const) static_cast<int (TCollection_AsciiString::*)(  const char * const  ,   const int ,   const int ,   const int  ) const>(&TCollection_AsciiString::FirstLocationNotInSet),
             R"#(Core implementation: Returns the index of the first character of this string that is not present in the given character set (pointer and length). The search begins at index FromIndex and ends at index ToIndex. Returns zero if failure. Raises an exception if FromIndex or ToIndex is out of range.)#"  , py::arg("theSet"),  py::arg("theSetLength"),  py::arg("theFromIndex"),  py::arg("theToIndex")
          )
        .def("FirstLocationNotInSet",
             (int (TCollection_AsciiString::*)(  const TCollection_AsciiString & ,   const int ,   const int  ) const) static_cast<int (TCollection_AsciiString::*)(  const TCollection_AsciiString & ,   const int ,   const int  ) const>(&TCollection_AsciiString::FirstLocationNotInSet),
             R"#(Returns the index of the first character of this string that is not present in the set Set. The search begins to the index FromIndex and ends to the the index ToIndex in this string. Returns zero if failure. Raises an exception if FromIndex or ToIndex is out of range.)#"  , py::arg("theSet"),  py::arg("theFromIndex"),  py::arg("theToIndex")
          )
        .def("FirstLocationNotInSet",
             (int (TCollection_AsciiString::*)(  const typename std::string_view & ,   const int ,   const int  ) const) static_cast<int (TCollection_AsciiString::*)(  const typename std::string_view & ,   const int ,   const int  ) const>(&TCollection_AsciiString::FirstLocationNotInSet),
             R"#(Returns the index of the first character of this string that is not present in string_view.)#"  , py::arg("theSet"),  py::arg("theFromIndex"),  py::arg("theToIndex")
          )
        .def("Insert",
             (void (TCollection_AsciiString::*)(  const int ,   const char  ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const char  ) >(&TCollection_AsciiString::Insert),
             R"#(Inserts a Character at position where.)#"  , py::arg("theWhere"),  py::arg("theWhat")
          )
        .def("Insert",
             (void (TCollection_AsciiString::*)(  const int ,   const char * const  ,   const int  ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const char * const  ,   const int  ) >(&TCollection_AsciiString::Insert),
             R"#(Core implementation: Inserts a string (pointer and length) at position theWhere. This is the primary implementation that all other Insert overloads redirect to.)#"  , py::arg("theWhere"),  py::arg("theString"),  py::arg("theLength")
          )
        .def("Insert",
             (void (TCollection_AsciiString::*)(  const int ,   const TCollection_AsciiString &  ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const TCollection_AsciiString &  ) >(&TCollection_AsciiString::Insert),
             R"#(Inserts a AsciiString at position where.)#"  , py::arg("theWhere"),  py::arg("theWhat")
          )
        .def("Insert",
             (void (TCollection_AsciiString::*)(  const int ,   const char * const   ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const char * const   ) >(&TCollection_AsciiString::Insert),
             R"#(Inserts a C string at position theWhere.)#"  , py::arg("theWhere"),  py::arg("theCString")
          )
        .def("Insert",
             (void (TCollection_AsciiString::*)(  const int ,   const typename std::string_view &  ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const typename std::string_view &  ) >(&TCollection_AsciiString::Insert),
             R"#(Inserts a string_view at position theWhere.)#"  , py::arg("theWhere"),  py::arg("theStringView")
          )
        .def("InsertAfter",
             (void (TCollection_AsciiString::*)(  const int ,   const char * const  ,   const int  ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const char * const  ,   const int  ) >(&TCollection_AsciiString::InsertAfter),
             R"#(Core implementation: Inserts string (pointer and length) after a specific index in this string. This is the primary implementation that all other InsertAfter overloads redirect to. Raises an exception if index is out of bounds (less than 0 or greater than the length).)#"  , py::arg("theIndex"),  py::arg("theString"),  py::arg("theLength")
          )
        .def("InsertAfter",
             (void (TCollection_AsciiString::*)(  const int ,   const TCollection_AsciiString &  ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const TCollection_AsciiString &  ) >(&TCollection_AsciiString::InsertAfter),
             R"#(Inserts an ASCII string after a specific index in this string. Raises an exception if index is out of bounds.)#"  , py::arg("theIndex"),  py::arg("theOther")
          )
        .def("InsertAfter",
             (void (TCollection_AsciiString::*)(  const int ,   const char * const   ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const char * const   ) >(&TCollection_AsciiString::InsertAfter),
             R"#(Inserts a C string after a specific index in this string. Raises an exception if index is out of bounds.)#"  , py::arg("theIndex"),  py::arg("theCString")
          )
        .def("InsertAfter",
             (void (TCollection_AsciiString::*)(  const int ,   const typename std::string_view &  ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const typename std::string_view &  ) >(&TCollection_AsciiString::InsertAfter),
             R"#(Inserts a string_view after a specific index in this string. Raises an exception if index is out of bounds.)#"  , py::arg("theIndex"),  py::arg("theStringView")
          )
        .def("InsertBefore",
             (void (TCollection_AsciiString::*)(  const int ,   const char * const  ,   const int  ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const char * const  ,   const int  ) >(&TCollection_AsciiString::InsertBefore),
             R"#(Core implementation: Inserts string (pointer and length) before a specific index in this string. This is the primary implementation that all other InsertBefore overloads redirect to. Raises an exception if index is out of bounds (less than 1 or greater than the length).)#"  , py::arg("theIndex"),  py::arg("theString"),  py::arg("theLength")
          )
        .def("InsertBefore",
             (void (TCollection_AsciiString::*)(  const int ,   const TCollection_AsciiString &  ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const TCollection_AsciiString &  ) >(&TCollection_AsciiString::InsertBefore),
             R"#(Inserts an ASCII string before a specific index in this string. Raises an exception if index is out of bounds.)#"  , py::arg("theIndex"),  py::arg("theOther")
          )
        .def("InsertBefore",
             (void (TCollection_AsciiString::*)(  const int ,   const char * const   ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const char * const   ) >(&TCollection_AsciiString::InsertBefore),
             R"#(Inserts a C string before a specific index in this string. Raises an exception if index is out of bounds.)#"  , py::arg("theIndex"),  py::arg("theCString")
          )
        .def("InsertBefore",
             (void (TCollection_AsciiString::*)(  const int ,   const typename std::string_view &  ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const typename std::string_view &  ) >(&TCollection_AsciiString::InsertBefore),
             R"#(Inserts a string_view before a specific index in this string. Raises an exception if index is out of bounds.)#"  , py::arg("theIndex"),  py::arg("theStringView")
          )
        .def("IsEmpty",
             (bool (TCollection_AsciiString::*)() const) static_cast<bool (TCollection_AsciiString::*)() const>(&TCollection_AsciiString::IsEmpty),
             R"#(Returns True if this string contains zero character.)#" 
          )
        .def("IsEqual",
             (bool (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const) static_cast<bool (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const>(&TCollection_AsciiString::IsEqual),
             R"#(Returns true if the characters in this ASCII string are identical to the characters in ASCII string other. Note that this method is an alias of operator ==.)#"  , py::arg("theOther")
          )
        .def("IsEqual",
             (bool (TCollection_AsciiString::*)(  const char * const  ,   const int  ) const) static_cast<bool (TCollection_AsciiString::*)(  const char * const  ,   const int  ) const>(&TCollection_AsciiString::IsEqual),
             R"#(Core implementation: Returns true if the characters in this ASCII string are identical to the string (pointer and length). This is the primary implementation that string_view and CString overloads redirect to.)#"  , py::arg("theString"),  py::arg("theLength")
          )
        .def("IsEqual",
             (bool (TCollection_AsciiString::*)(  const char * const   ) const) static_cast<bool (TCollection_AsciiString::*)(  const char * const   ) const>(&TCollection_AsciiString::IsEqual),
             R"#(Returns true if the characters in this ASCII string are identical to the C string.)#"  , py::arg("theCString")
          )
        .def("IsEqual",
             (bool (TCollection_AsciiString::*)(  const typename std::string_view &  ) const) static_cast<bool (TCollection_AsciiString::*)(  const typename std::string_view &  ) const>(&TCollection_AsciiString::IsEqual),
             R"#(Returns true if the characters in this ASCII string are identical to the characters in string_view.)#"  , py::arg("theStringView")
          )
        .def("IsDifferent",
             (bool (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const) static_cast<bool (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const>(&TCollection_AsciiString::IsDifferent),
             R"#(Returns true if there are differences between the characters in this ASCII string and ASCII string other. Note that this method is an alias of operator !=)#"  , py::arg("theOther")
          )
        .def("IsDifferent",
             (bool (TCollection_AsciiString::*)(  const char * const  ,   const int  ) const) static_cast<bool (TCollection_AsciiString::*)(  const char * const  ,   const int  ) const>(&TCollection_AsciiString::IsDifferent),
             R"#(Core implementation: Returns true if there are differences between this ASCII string and the string (pointer and length). This is the primary implementation that string_view and CString overloads redirect to.)#"  , py::arg("theString"),  py::arg("theLength")
          )
        .def("IsDifferent",
             (bool (TCollection_AsciiString::*)(  const char * const   ) const) static_cast<bool (TCollection_AsciiString::*)(  const char * const   ) const>(&TCollection_AsciiString::IsDifferent),
             R"#(Returns true if there are differences between this ASCII string and C string.)#"  , py::arg("theCString")
          )
        .def("IsDifferent",
             (bool (TCollection_AsciiString::*)(  const typename std::string_view &  ) const) static_cast<bool (TCollection_AsciiString::*)(  const typename std::string_view &  ) const>(&TCollection_AsciiString::IsDifferent),
             R"#(Returns true if there are differences between the characters in this ASCII string and string_view.)#"  , py::arg("theStringView")
          )
        .def("IsLess",
             (bool (TCollection_AsciiString::*)(  const char * const  ,   const int  ) const) static_cast<bool (TCollection_AsciiString::*)(  const char * const  ,   const int  ) const>(&TCollection_AsciiString::IsLess),
             R"#(Core implementation: Returns TRUE if this string is lexicographically less than the string (pointer and length). This is the primary implementation that all other IsLess overloads redirect to.)#"  , py::arg("theString"),  py::arg("theLength")
          )
        .def("IsLess",
             (bool (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const) static_cast<bool (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const>(&TCollection_AsciiString::IsLess),
             R"#(Returns TRUE if this string is 'ASCII' less than other.)#"  , py::arg("theOther")
          )
        .def("IsLess",
             (bool (TCollection_AsciiString::*)(  const char * const   ) const) static_cast<bool (TCollection_AsciiString::*)(  const char * const   ) const>(&TCollection_AsciiString::IsLess),
             R"#(Returns TRUE if this string is lexicographically less than C string.)#"  , py::arg("theCString")
          )
        .def("IsLess",
             (bool (TCollection_AsciiString::*)(  const typename std::string_view &  ) const) static_cast<bool (TCollection_AsciiString::*)(  const typename std::string_view &  ) const>(&TCollection_AsciiString::IsLess),
             R"#(Returns TRUE if this ASCII string is lexicographically less than theStringView.)#"  , py::arg("theStringView")
          )
        .def("IsGreater",
             (bool (TCollection_AsciiString::*)(  const char * const  ,   const int  ) const) static_cast<bool (TCollection_AsciiString::*)(  const char * const  ,   const int  ) const>(&TCollection_AsciiString::IsGreater),
             R"#(Core implementation: Returns TRUE if this string is lexicographically greater than the string (pointer and length). This is the primary implementation that all other IsGreater overloads redirect to.)#"  , py::arg("theString"),  py::arg("theLength")
          )
        .def("IsGreater",
             (bool (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const) static_cast<bool (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const>(&TCollection_AsciiString::IsGreater),
             R"#(Returns TRUE if this string is 'ASCII' greater than other.)#"  , py::arg("theOther")
          )
        .def("IsGreater",
             (bool (TCollection_AsciiString::*)(  const char * const   ) const) static_cast<bool (TCollection_AsciiString::*)(  const char * const   ) const>(&TCollection_AsciiString::IsGreater),
             R"#(Returns TRUE if this string is lexicographically greater than C string.)#"  , py::arg("theCString")
          )
        .def("IsGreater",
             (bool (TCollection_AsciiString::*)(  const typename std::string_view &  ) const) static_cast<bool (TCollection_AsciiString::*)(  const typename std::string_view &  ) const>(&TCollection_AsciiString::IsGreater),
             R"#(Returns TRUE if this ASCII string is lexicographically greater than theStringView.)#"  , py::arg("theStringView")
          )
        .def("StartsWith",
             (bool (TCollection_AsciiString::*)(  const char * const  ,   const int  ) const) static_cast<bool (TCollection_AsciiString::*)(  const char * const  ,   const int  ) const>(&TCollection_AsciiString::StartsWith),
             R"#(Core implementation: Determines whether the beginning of this string instance matches the specified string (pointer and length).)#"  , py::arg("theStartString"),  py::arg("theStartLength")
          )
        .def("StartsWith",
             (bool (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const) static_cast<bool (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const>(&TCollection_AsciiString::StartsWith),
             R"#(Determines whether the beginning of this string instance matches the specified string.)#"  , py::arg("theStartString")
          )
        .def("StartsWith",
             (bool (TCollection_AsciiString::*)(  const char * const   ) const) static_cast<bool (TCollection_AsciiString::*)(  const char * const   ) const>(&TCollection_AsciiString::StartsWith),
             R"#(Determines whether the beginning of this string matches the specified C string.)#"  , py::arg("theCString")
          )
        .def("StartsWith",
             (bool (TCollection_AsciiString::*)(  const typename std::string_view &  ) const) static_cast<bool (TCollection_AsciiString::*)(  const typename std::string_view &  ) const>(&TCollection_AsciiString::StartsWith),
             R"#(Determines whether the beginning of this string instance matches the specified string_view.)#"  , py::arg("theStartString")
          )
        .def("EndsWith",
             (bool (TCollection_AsciiString::*)(  const char * const  ,   const int  ) const) static_cast<bool (TCollection_AsciiString::*)(  const char * const  ,   const int  ) const>(&TCollection_AsciiString::EndsWith),
             R"#(Core implementation: Determines whether the end of this string instance matches the specified string (pointer and length).)#"  , py::arg("theEndString"),  py::arg("theEndLength")
          )
        .def("EndsWith",
             (bool (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const) static_cast<bool (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const>(&TCollection_AsciiString::EndsWith),
             R"#(Determines whether the end of this string instance matches the specified string.)#"  , py::arg("theEndString")
          )
        .def("EndsWith",
             (bool (TCollection_AsciiString::*)(  const typename std::string_view &  ) const) static_cast<bool (TCollection_AsciiString::*)(  const typename std::string_view &  ) const>(&TCollection_AsciiString::EndsWith),
             R"#(Determines whether the end of this string instance matches the specified string_view.)#"  , py::arg("theEndString")
          )
        .def("IntegerValue",
             (int (TCollection_AsciiString::*)() const) static_cast<int (TCollection_AsciiString::*)() const>(&TCollection_AsciiString::IntegerValue),
             R"#(Converts a AsciiString containing a numeric expression to an Integer.)#" 
          )
        .def("IsIntegerValue",
             (bool (TCollection_AsciiString::*)() const) static_cast<bool (TCollection_AsciiString::*)() const>(&TCollection_AsciiString::IsIntegerValue),
             R"#(Returns True if the AsciiString contains an integer value. Note: an integer value is considered to be a real value as well.)#" 
          )
        .def("IsRealValue",
             (bool (TCollection_AsciiString::*)( bool  ) const) static_cast<bool (TCollection_AsciiString::*)( bool  ) const>(&TCollection_AsciiString::IsRealValue),
             R"#(Returns True if the AsciiString starts with some characters that can be interpreted as integer or real value.)#"  , py::arg("theToCheckFull")=static_cast<bool>(false)
          )
        .def("IsAscii",
             (bool (TCollection_AsciiString::*)() const) static_cast<bool (TCollection_AsciiString::*)() const>(&TCollection_AsciiString::IsAscii),
             R"#(Returns True if the AsciiString contains only ASCII characters between ' ' and '~'. This means no control character and no extended ASCII code.)#" 
          )
        .def("LeftAdjust",
             (void (TCollection_AsciiString::*)() ) static_cast<void (TCollection_AsciiString::*)() >(&TCollection_AsciiString::LeftAdjust),
             R"#(Removes all space characters in the beginning of the string.)#" 
          )
        .def("LeftJustify",
             (void (TCollection_AsciiString::*)(  const int ,   const char  ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const char  ) >(&TCollection_AsciiString::LeftJustify),
             R"#(left justify Length becomes equal to Width and the new characters are equal to Filler. If Width < Length nothing happens. Raises an exception if Width is less than zero.)#"  , py::arg("theWidth"),  py::arg("theFiller")
          )
        .def("Length",
             (int (TCollection_AsciiString::*)() const) static_cast<int (TCollection_AsciiString::*)() const>(&TCollection_AsciiString::Length),
             R"#(Returns number of characters in this string. This is the same functionality as 'strlen' in C.)#" 
          )
        .def("Location",
             (int (TCollection_AsciiString::*)(  const TCollection_AsciiString & ,   const int ,   const int  ) const) static_cast<int (TCollection_AsciiString::*)(  const TCollection_AsciiString & ,   const int ,   const int  ) const>(&TCollection_AsciiString::Location),
             R"#(Returns an index in this string of the first occurrence of the string S in this string from the starting index FromIndex to the ending index ToIndex returns zero if failure Raises an exception if FromIndex or ToIndex is out of range.)#"  , py::arg("theOther"),  py::arg("theFromIndex"),  py::arg("theToIndex")
          )
        .def("Location",
             (int (TCollection_AsciiString::*)(  const int ,   const char ,   const int ,   const int  ) const) static_cast<int (TCollection_AsciiString::*)(  const int ,   const char ,   const int ,   const int  ) const>(&TCollection_AsciiString::Location),
             R"#(Returns the index of the nth occurrence of the character C in this string from the starting index FromIndex to the ending index ToIndex. Returns zero if failure. Raises an exception if FromIndex or ToIndex is out of range.)#"  , py::arg("theN"),  py::arg("theC"),  py::arg("theFromIndex"),  py::arg("theToIndex")
          )
        .def("LowerCase",
             (void (TCollection_AsciiString::*)() ) static_cast<void (TCollection_AsciiString::*)() >(&TCollection_AsciiString::LowerCase),
             R"#(Converts this string to its lower-case equivalent.)#" 
          )
        .def("Prepend",
             (void (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) ) static_cast<void (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) >(&TCollection_AsciiString::Prepend),
             R"#(Inserts the string other at the beginning of this ASCII string.)#"  , py::arg("theOther")
          )
        .def("Print",
             (void (TCollection_AsciiString::*)( Standard_OStream &  ) const) static_cast<void (TCollection_AsciiString::*)( Standard_OStream &  ) const>(&TCollection_AsciiString::Print),
             R"#(Displays this string on a stream.)#"  , py::arg("theStream")
          )
        .def("Read",
             (void (TCollection_AsciiString::*)( Standard_IStream &  ) ) static_cast<void (TCollection_AsciiString::*)( Standard_IStream &  ) >(&TCollection_AsciiString::Read),
             R"#(Read this string from a stream.)#"  , py::arg("theStream")
          )
        .def("RealValue",
             (double (TCollection_AsciiString::*)() const) static_cast<double (TCollection_AsciiString::*)() const>(&TCollection_AsciiString::RealValue),
             R"#(Converts an AsciiString containing a numeric expression to a Real.)#" 
          )
        .def("RemoveAll",
             (void (TCollection_AsciiString::*)(  const char ,   const bool  ) ) static_cast<void (TCollection_AsciiString::*)(  const char ,   const bool  ) >(&TCollection_AsciiString::RemoveAll),
             R"#(Remove all the occurrences of the character C in the string.)#"  , py::arg("theC"),  py::arg("theCaseSensitive")
          )
        .def("RemoveAll",
             (void (TCollection_AsciiString::*)(  const char  ) ) static_cast<void (TCollection_AsciiString::*)(  const char  ) >(&TCollection_AsciiString::RemoveAll),
             R"#(Removes every what characters from this string.)#"  , py::arg("theWhat")
          )
        .def("Remove",
             (void (TCollection_AsciiString::*)(  const int ,   const int  ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const int  ) >(&TCollection_AsciiString::Remove),
             R"#(Erases ahowmany characters from position where, where included.)#"  , py::arg("theWhere"),  py::arg("theHowMany")=static_cast< const int>(1)
          )
        .def("RightAdjust",
             (void (TCollection_AsciiString::*)() ) static_cast<void (TCollection_AsciiString::*)() >(&TCollection_AsciiString::RightAdjust),
             R"#(Removes all space characters at the end of the string.)#" 
          )
        .def("RightJustify",
             (void (TCollection_AsciiString::*)(  const int ,   const char  ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const char  ) >(&TCollection_AsciiString::RightJustify),
             R"#(Right justify. Length becomes equal to Width and the new characters are equal to Filler. if Width < Length nothing happens. Raises an exception if Width is less than zero.)#"  , py::arg("theWidth"),  py::arg("theFiller")
          )
        .def("Search",
             (int (TCollection_AsciiString::*)(  const char * const  ,   const int  ) const) static_cast<int (TCollection_AsciiString::*)(  const char * const  ,   const int  ) const>(&TCollection_AsciiString::Search),
             R"#(Core implementation: Searches a string (pointer and length) in this string from the beginning and returns position of first item matching. It returns -1 if not found.)#"  , py::arg("theWhat"),  py::arg("theWhatLength")
          )
        .def("Search",
             (int (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const) static_cast<int (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const>(&TCollection_AsciiString::Search),
             R"#(Searches an AsciiString in this string from the beginning and returns position of first item what matching. It returns -1 if not found.)#"  , py::arg("theWhat")
          )
        .def("Search",
             (int (TCollection_AsciiString::*)(  const char * const   ) const) static_cast<int (TCollection_AsciiString::*)(  const char * const   ) const>(&TCollection_AsciiString::Search),
             R"#(Searches a C string in this string from the beginning.)#"  , py::arg("theCString")
          )
        .def("Search",
             (int (TCollection_AsciiString::*)(  const typename std::string_view &  ) const) static_cast<int (TCollection_AsciiString::*)(  const typename std::string_view &  ) const>(&TCollection_AsciiString::Search),
             R"#(Searches a string_view in this string from the beginning and returns position of first item matching. It returns -1 if not found.)#"  , py::arg("theWhat")
          )
        .def("SearchFromEnd",
             (int (TCollection_AsciiString::*)(  const char * const  ,   const int  ) const) static_cast<int (TCollection_AsciiString::*)(  const char * const  ,   const int  ) const>(&TCollection_AsciiString::SearchFromEnd),
             R"#(Core implementation: Searches a string (pointer and length) in this string from the end and returns position of first item matching. It returns -1 if not found.)#"  , py::arg("theWhat"),  py::arg("theWhatLength")
          )
        .def("SearchFromEnd",
             (int (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const) static_cast<int (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const>(&TCollection_AsciiString::SearchFromEnd),
             R"#(Searches a AsciiString in another AsciiString from the end and returns position of first item what matching. It returns -1 if not found.)#"  , py::arg("theWhat")
          )
        .def("SearchFromEnd",
             (int (TCollection_AsciiString::*)(  const char * const   ) const) static_cast<int (TCollection_AsciiString::*)(  const char * const   ) const>(&TCollection_AsciiString::SearchFromEnd),
             R"#(Searches a C string in this string from the end.)#"  , py::arg("theCString")
          )
        .def("SearchFromEnd",
             (int (TCollection_AsciiString::*)(  const typename std::string_view &  ) const) static_cast<int (TCollection_AsciiString::*)(  const typename std::string_view &  ) const>(&TCollection_AsciiString::SearchFromEnd),
             R"#(Searches a string_view in this string from the end and returns position of first item matching. It returns -1 if not found.)#"  , py::arg("theWhat")
          )
        .def("SetValue",
             (void (TCollection_AsciiString::*)(  const int ,   const char  ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const char  ) >(&TCollection_AsciiString::SetValue),
             R"#(Replaces one character in the AsciiString at position where. If where is less than zero or greater than the length of this string an exception is raised.)#"  , py::arg("theWhere"),  py::arg("theWhat")
          )
        .def("SetValue",
             (void (TCollection_AsciiString::*)(  const int ,   const char * const  ,   const int  ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const char * const  ,   const int  ) >(&TCollection_AsciiString::SetValue),
             R"#(Core implementation: Replaces a part of this string with a string (pointer and length). This is the primary implementation that all other SetValue string overloads redirect to.)#"  , py::arg("theWhere"),  py::arg("theString"),  py::arg("theLength")
          )
        .def("SetValue",
             (void (TCollection_AsciiString::*)(  const int ,   const TCollection_AsciiString &  ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const TCollection_AsciiString &  ) >(&TCollection_AsciiString::SetValue),
             R"#(Replaces a part of this string by another AsciiString.)#"  , py::arg("theWhere"),  py::arg("theWhat")
          )
        .def("SetValue",
             (void (TCollection_AsciiString::*)(  const int ,   const char * const   ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const char * const   ) >(&TCollection_AsciiString::SetValue),
             R"#(Replaces a part of this ASCII string with a C string.)#"  , py::arg("theWhere"),  py::arg("theCString")
          )
        .def("SetValue",
             (void (TCollection_AsciiString::*)(  const int ,   const typename std::string_view &  ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const typename std::string_view &  ) >(&TCollection_AsciiString::SetValue),
             R"#(Replaces a part of this ASCII string with a string_view.)#"  , py::arg("theWhere"),  py::arg("theStringView")
          )
        .def("Split",
             (TCollection_AsciiString (TCollection_AsciiString::*)(  const int  ) ) static_cast<TCollection_AsciiString (TCollection_AsciiString::*)(  const int  ) >(&TCollection_AsciiString::Split),
             R"#(Splits a AsciiString into two sub-strings.)#"  , py::arg("theWhere")
          )
        .def("SubString",
             (TCollection_AsciiString (TCollection_AsciiString::*)(  const int ,   const int  ) const) static_cast<TCollection_AsciiString (TCollection_AsciiString::*)(  const int ,   const int  ) const>(&TCollection_AsciiString::SubString),
             R"#(Creation of a sub-string of this string. The sub-string starts to the index Fromindex and ends to the index ToIndex. Raises an exception if ToIndex or FromIndex is out of bounds)#"  , py::arg("theFromIndex"),  py::arg("theToIndex")
          )
        .def("ToCString",
             ( const char * (TCollection_AsciiString::*)() const) static_cast< const char * (TCollection_AsciiString::*)() const>(&TCollection_AsciiString::ToCString),
             R"#(Returns pointer to AsciiString (char *). This is useful for some casual manipulations. Warning: Because this "char *" is 'const', you can't modify its contents.)#" 
          )
        .def("Token",
             (TCollection_AsciiString (TCollection_AsciiString::*)(  const char * const  ,   const int  ) const) static_cast<TCollection_AsciiString (TCollection_AsciiString::*)(  const char * const  ,   const int  ) const>(&TCollection_AsciiString::Token),
             R"#(Extracts whichone token from this string. By default, the separators is set to space and tabulation. By default, the token extracted is the first one (whichone = 1). separators contains all separators you need. If no token indexed by whichone is found, it returns empty AsciiString.)#"  , py::arg("theSeparators")=static_cast< const char * const >(" \t"),  py::arg("theWhichOne")=static_cast< const int>(1)
          )
        .def("Trunc",
             (void (TCollection_AsciiString::*)(  const int  ) ) static_cast<void (TCollection_AsciiString::*)(  const int  ) >(&TCollection_AsciiString::Trunc),
             R"#(Truncates this string to ahowmany characters.)#"  , py::arg("theHowMany")
          )
        .def("UpperCase",
             (void (TCollection_AsciiString::*)() ) static_cast<void (TCollection_AsciiString::*)() >(&TCollection_AsciiString::UpperCase),
             R"#(Converts this string to its upper-case equivalent.)#" 
          )
        .def("UsefullLength",
             (int (TCollection_AsciiString::*)() const) static_cast<int (TCollection_AsciiString::*)() const>(&TCollection_AsciiString::UsefullLength),
             R"#(Length of the string ignoring all spaces (' ') and the control character at the end.)#" 
          )
        .def("Value",
             (char (TCollection_AsciiString::*)(  const int  ) const) static_cast<char (TCollection_AsciiString::*)(  const int  ) const>(&TCollection_AsciiString::Value),
             R"#(Returns character at position where in this string. If where is less than zero or greater than the length of this string, an exception is raised.)#"  , py::arg("theWhere")
          )
        .def("HashCode",
             (size_t (TCollection_AsciiString::*)() const) static_cast<size_t (TCollection_AsciiString::*)() const>(&TCollection_AsciiString::HashCode),
             R"#(Computes a hash code for the given ASCII string Returns the same integer value as the hash function for TCollection_ExtendedString)#" 
          )
        .def("AssignCat",
             (void (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) ) static_cast<void (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) >(&TCollection_AsciiString::AssignCat),
             R"#(Appends other string to this string. This is an unary operator.)#"  , py::arg("theOther")
          )
        .def("AssignCat",
             (void (TCollection_AsciiString::*)(  const char * const   ) ) static_cast<void (TCollection_AsciiString::*)(  const char * const   ) >(&TCollection_AsciiString::AssignCat),
             R"#(Appends C string to this ASCII string.)#"  , py::arg("theCString")
          )
        .def("AssignCat",
             (void (TCollection_AsciiString::*)(  const typename std::string_view &  ) ) static_cast<void (TCollection_AsciiString::*)(  const typename std::string_view &  ) >(&TCollection_AsciiString::AssignCat),
             R"#(Appends string view to this ASCII string. This is an unary operator.)#"  , py::arg("theStringView")
          )
        .def("Cat",
             (TCollection_AsciiString (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const) static_cast<TCollection_AsciiString (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const>(&TCollection_AsciiString::Cat),
             R"#(Appends other string to this string.)#"  , py::arg("theOther")
          )
        .def("Cat",
             (TCollection_AsciiString (TCollection_AsciiString::*)(  const char * const   ) const) static_cast<TCollection_AsciiString (TCollection_AsciiString::*)(  const char * const   ) const>(&TCollection_AsciiString::Cat),
             R"#(Appends C string to this ASCII string.)#"  , py::arg("theCString")
          )
        .def("Cat",
             (TCollection_AsciiString (TCollection_AsciiString::*)(  const typename std::string_view &  ) const) static_cast<TCollection_AsciiString (TCollection_AsciiString::*)(  const typename std::string_view &  ) const>(&TCollection_AsciiString::Cat),
             R"#(Appends string view to this ASCII string.)#"  , py::arg("theStringView")
          )
        .def("Copy",
             (void (TCollection_AsciiString::*)(  const char * const   ) ) static_cast<void (TCollection_AsciiString::*)(  const char * const   ) >(&TCollection_AsciiString::Copy),
             R"#(Copy C string to this ASCII string. Used as operator =)#"  , py::arg("theCString")
          )
        .def("Copy",
             (void (TCollection_AsciiString::*)(  const typename std::string_view &  ) ) static_cast<void (TCollection_AsciiString::*)(  const typename std::string_view &  ) >(&TCollection_AsciiString::Copy),
             R"#(Copy string view to this ASCII string. Used as operator =)#"  , py::arg("theStringView")
          )
        .def("Copy",
             (void (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) ) static_cast<void (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) >(&TCollection_AsciiString::Copy),
             R"#(Copy fromwhere to this string. Used as operator =)#"  , py::arg("theFromWhere")
          )
        .def("Insert",
             (void (TCollection_AsciiString::*)(  const int ,   const TCollection_AsciiString &  ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const TCollection_AsciiString &  ) >(&TCollection_AsciiString::Insert),
             R"#(Inserts a AsciiString at position where.)#"  , py::arg("theWhere"),  py::arg("theWhat")
          )
        .def("Insert",
             (void (TCollection_AsciiString::*)(  const int ,   const char * const   ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const char * const   ) >(&TCollection_AsciiString::Insert),
             R"#(Inserts a C string at position theWhere.)#"  , py::arg("theWhere"),  py::arg("theCString")
          )
        .def("Insert",
             (void (TCollection_AsciiString::*)(  const int ,   const typename std::string_view &  ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const typename std::string_view &  ) >(&TCollection_AsciiString::Insert),
             R"#(Inserts a string_view at position theWhere.)#"  , py::arg("theWhere"),  py::arg("theStringView")
          )
        .def("InsertAfter",
             (void (TCollection_AsciiString::*)(  const int ,   const TCollection_AsciiString &  ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const TCollection_AsciiString &  ) >(&TCollection_AsciiString::InsertAfter),
             R"#(Inserts an ASCII string after a specific index in this string. Raises an exception if index is out of bounds.)#"  , py::arg("theIndex"),  py::arg("theOther")
          )
        .def("InsertAfter",
             (void (TCollection_AsciiString::*)(  const int ,   const char * const   ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const char * const   ) >(&TCollection_AsciiString::InsertAfter),
             R"#(Inserts a C string after a specific index in this string. Raises an exception if index is out of bounds.)#"  , py::arg("theIndex"),  py::arg("theCString")
          )
        .def("InsertAfter",
             (void (TCollection_AsciiString::*)(  const int ,   const typename std::string_view &  ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const typename std::string_view &  ) >(&TCollection_AsciiString::InsertAfter),
             R"#(Inserts a string_view after a specific index in this string. Raises an exception if index is out of bounds.)#"  , py::arg("theIndex"),  py::arg("theStringView")
          )
        .def("InsertBefore",
             (void (TCollection_AsciiString::*)(  const int ,   const TCollection_AsciiString &  ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const TCollection_AsciiString &  ) >(&TCollection_AsciiString::InsertBefore),
             R"#(Inserts an ASCII string before a specific index in this string. Raises an exception if index is out of bounds.)#"  , py::arg("theIndex"),  py::arg("theOther")
          )
        .def("InsertBefore",
             (void (TCollection_AsciiString::*)(  const int ,   const char * const   ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const char * const   ) >(&TCollection_AsciiString::InsertBefore),
             R"#(Inserts a C string before a specific index in this string. Raises an exception if index is out of bounds.)#"  , py::arg("theIndex"),  py::arg("theCString")
          )
        .def("InsertBefore",
             (void (TCollection_AsciiString::*)(  const int ,   const typename std::string_view &  ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const typename std::string_view &  ) >(&TCollection_AsciiString::InsertBefore),
             R"#(Inserts a string_view before a specific index in this string. Raises an exception if index is out of bounds.)#"  , py::arg("theIndex"),  py::arg("theStringView")
          )
        .def("IsEqual",
             (bool (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const) static_cast<bool (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const>(&TCollection_AsciiString::IsEqual),
             R"#(Returns true if the characters in this ASCII string are identical to the characters in ASCII string other. Note that this method is an alias of operator ==.)#"  , py::arg("theOther")
          )
        .def("IsEqual",
             (bool (TCollection_AsciiString::*)(  const char * const   ) const) static_cast<bool (TCollection_AsciiString::*)(  const char * const   ) const>(&TCollection_AsciiString::IsEqual),
             R"#(Returns true if the characters in this ASCII string are identical to the C string.)#"  , py::arg("theCString")
          )
        .def("IsEqual",
             (bool (TCollection_AsciiString::*)(  const typename std::string_view &  ) const) static_cast<bool (TCollection_AsciiString::*)(  const typename std::string_view &  ) const>(&TCollection_AsciiString::IsEqual),
             R"#(Returns true if the characters in this ASCII string are identical to the characters in string_view.)#"  , py::arg("theStringView")
          )
        .def("IsDifferent",
             (bool (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const) static_cast<bool (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const>(&TCollection_AsciiString::IsDifferent),
             R"#(Returns true if there are differences between the characters in this ASCII string and ASCII string other. Note that this method is an alias of operator !=)#"  , py::arg("theOther")
          )
        .def("IsDifferent",
             (bool (TCollection_AsciiString::*)(  const char * const   ) const) static_cast<bool (TCollection_AsciiString::*)(  const char * const   ) const>(&TCollection_AsciiString::IsDifferent),
             R"#(Returns true if there are differences between this ASCII string and C string.)#"  , py::arg("theCString")
          )
        .def("IsDifferent",
             (bool (TCollection_AsciiString::*)(  const typename std::string_view &  ) const) static_cast<bool (TCollection_AsciiString::*)(  const typename std::string_view &  ) const>(&TCollection_AsciiString::IsDifferent),
             R"#(Returns true if there are differences between the characters in this ASCII string and string_view.)#"  , py::arg("theStringView")
          )
        .def("IsLess",
             (bool (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const) static_cast<bool (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const>(&TCollection_AsciiString::IsLess),
             R"#(Returns TRUE if this string is 'ASCII' less than other.)#"  , py::arg("theOther")
          )
        .def("IsLess",
             (bool (TCollection_AsciiString::*)(  const char * const   ) const) static_cast<bool (TCollection_AsciiString::*)(  const char * const   ) const>(&TCollection_AsciiString::IsLess),
             R"#(Returns TRUE if this string is lexicographically less than C string.)#"  , py::arg("theCString")
          )
        .def("IsLess",
             (bool (TCollection_AsciiString::*)(  const typename std::string_view &  ) const) static_cast<bool (TCollection_AsciiString::*)(  const typename std::string_view &  ) const>(&TCollection_AsciiString::IsLess),
             R"#(Returns TRUE if this ASCII string is lexicographically less than theStringView.)#"  , py::arg("theStringView")
          )
        .def("IsGreater",
             (bool (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const) static_cast<bool (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const>(&TCollection_AsciiString::IsGreater),
             R"#(Returns TRUE if this string is 'ASCII' greater than other.)#"  , py::arg("theOther")
          )
        .def("IsGreater",
             (bool (TCollection_AsciiString::*)(  const char * const   ) const) static_cast<bool (TCollection_AsciiString::*)(  const char * const   ) const>(&TCollection_AsciiString::IsGreater),
             R"#(Returns TRUE if this string is lexicographically greater than C string.)#"  , py::arg("theCString")
          )
        .def("IsGreater",
             (bool (TCollection_AsciiString::*)(  const typename std::string_view &  ) const) static_cast<bool (TCollection_AsciiString::*)(  const typename std::string_view &  ) const>(&TCollection_AsciiString::IsGreater),
             R"#(Returns TRUE if this ASCII string is lexicographically greater than theStringView.)#"  , py::arg("theStringView")
          )
        .def("StartsWith",
             (bool (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const) static_cast<bool (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const>(&TCollection_AsciiString::StartsWith),
             R"#(Determines whether the beginning of this string instance matches the specified string.)#"  , py::arg("theStartString")
          )
        .def("StartsWith",
             (bool (TCollection_AsciiString::*)(  const char * const   ) const) static_cast<bool (TCollection_AsciiString::*)(  const char * const   ) const>(&TCollection_AsciiString::StartsWith),
             R"#(Determines whether the beginning of this string matches the specified C string.)#"  , py::arg("theCString")
          )
        .def("StartsWith",
             (bool (TCollection_AsciiString::*)(  const typename std::string_view &  ) const) static_cast<bool (TCollection_AsciiString::*)(  const typename std::string_view &  ) const>(&TCollection_AsciiString::StartsWith),
             R"#(Determines whether the beginning of this string instance matches the specified string_view.)#"  , py::arg("theStartString")
          )
        .def("EndsWith",
             (bool (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const) static_cast<bool (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const>(&TCollection_AsciiString::EndsWith),
             R"#(Determines whether the end of this string instance matches the specified string.)#"  , py::arg("theEndString")
          )
        .def("EndsWith",
             (bool (TCollection_AsciiString::*)(  const typename std::string_view &  ) const) static_cast<bool (TCollection_AsciiString::*)(  const typename std::string_view &  ) const>(&TCollection_AsciiString::EndsWith),
             R"#(Determines whether the end of this string instance matches the specified string_view.)#"  , py::arg("theEndString")
          )
        .def("Search",
             (int (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const) static_cast<int (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const>(&TCollection_AsciiString::Search),
             R"#(Searches an AsciiString in this string from the beginning and returns position of first item what matching. It returns -1 if not found.)#"  , py::arg("theWhat")
          )
        .def("Search",
             (int (TCollection_AsciiString::*)(  const char * const   ) const) static_cast<int (TCollection_AsciiString::*)(  const char * const   ) const>(&TCollection_AsciiString::Search),
             R"#(Searches a C string in this string from the beginning.)#"  , py::arg("theCString")
          )
        .def("Search",
             (int (TCollection_AsciiString::*)(  const typename std::string_view &  ) const) static_cast<int (TCollection_AsciiString::*)(  const typename std::string_view &  ) const>(&TCollection_AsciiString::Search),
             R"#(Searches a string_view in this string from the beginning and returns position of first item matching. It returns -1 if not found.)#"  , py::arg("theWhat")
          )
        .def("SearchFromEnd",
             (int (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const) static_cast<int (TCollection_AsciiString::*)(  const TCollection_AsciiString &  ) const>(&TCollection_AsciiString::SearchFromEnd),
             R"#(Searches a AsciiString in another AsciiString from the end and returns position of first item what matching. It returns -1 if not found.)#"  , py::arg("theWhat")
          )
        .def("SearchFromEnd",
             (int (TCollection_AsciiString::*)(  const char * const   ) const) static_cast<int (TCollection_AsciiString::*)(  const char * const   ) const>(&TCollection_AsciiString::SearchFromEnd),
             R"#(Searches a C string in this string from the end.)#"  , py::arg("theCString")
          )
        .def("SearchFromEnd",
             (int (TCollection_AsciiString::*)(  const typename std::string_view &  ) const) static_cast<int (TCollection_AsciiString::*)(  const typename std::string_view &  ) const>(&TCollection_AsciiString::SearchFromEnd),
             R"#(Searches a string_view in this string from the end and returns position of first item matching. It returns -1 if not found.)#"  , py::arg("theWhat")
          )
        .def("SetValue",
             (void (TCollection_AsciiString::*)(  const int ,   const TCollection_AsciiString &  ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const TCollection_AsciiString &  ) >(&TCollection_AsciiString::SetValue),
             R"#(Replaces a part of this string by another AsciiString.)#"  , py::arg("theWhere"),  py::arg("theWhat")
          )
        .def("SetValue",
             (void (TCollection_AsciiString::*)(  const int ,   const char * const   ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const char * const   ) >(&TCollection_AsciiString::SetValue),
             R"#(Replaces a part of this ASCII string with a C string.)#"  , py::arg("theWhere"),  py::arg("theCString")
          )
        .def("SetValue",
             (void (TCollection_AsciiString::*)(  const int ,   const typename std::string_view &  ) ) static_cast<void (TCollection_AsciiString::*)(  const int ,   const typename std::string_view &  ) >(&TCollection_AsciiString::SetValue),
             R"#(Replaces a part of this ASCII string with a string_view.)#"  , py::arg("theWhere"),  py::arg("theStringView")
          )
        .def("HashCode",
             (size_t (TCollection_AsciiString::*)() const) static_cast<size_t (TCollection_AsciiString::*)() const>(&TCollection_AsciiString::HashCode),
             R"#(Computes a hash code for the given ASCII string Returns the same integer value as the hash function for TCollection_ExtendedString)#" 
          )
        .def("FirstLocationInSet",
             (int (TCollection_AsciiString::*)(  const TCollection_AsciiString & ,   const int ,   const int  ) const) static_cast<int (TCollection_AsciiString::*)(  const TCollection_AsciiString & ,   const int ,   const int  ) const>(&TCollection_AsciiString::FirstLocationInSet),
             R"#(Returns the index of the first character of this string that is present in Set. The search begins to the index FromIndex and ends to the the index ToIndex. Returns zero if failure. Raises an exception if FromIndex or ToIndex is out of range.)#"  , py::arg("theSet"),  py::arg("theFromIndex"),  py::arg("theToIndex")
          )
        .def("FirstLocationInSet",
             (int (TCollection_AsciiString::*)(  const typename std::string_view & ,   const int ,   const int  ) const) static_cast<int (TCollection_AsciiString::*)(  const typename std::string_view & ,   const int ,   const int  ) const>(&TCollection_AsciiString::FirstLocationInSet),
             R"#(Returns the index of the first character of this string that is present in string_view.)#"  , py::arg("theSet"),  py::arg("theFromIndex"),  py::arg("theToIndex")
          )
        .def("FirstLocationNotInSet",
             (int (TCollection_AsciiString::*)(  const TCollection_AsciiString & ,   const int ,   const int  ) const) static_cast<int (TCollection_AsciiString::*)(  const TCollection_AsciiString & ,   const int ,   const int  ) const>(&TCollection_AsciiString::FirstLocationNotInSet),
             R"#(Returns the index of the first character of this string that is not present in the set Set. The search begins to the index FromIndex and ends to the the index ToIndex in this string. Returns zero if failure. Raises an exception if FromIndex or ToIndex is out of range.)#"  , py::arg("theSet"),  py::arg("theFromIndex"),  py::arg("theToIndex")
          )
        .def("FirstLocationNotInSet",
             (int (TCollection_AsciiString::*)(  const typename std::string_view & ,   const int ,   const int  ) const) static_cast<int (TCollection_AsciiString::*)(  const typename std::string_view & ,   const int ,   const int  ) const>(&TCollection_AsciiString::FirstLocationNotInSet),
             R"#(Returns the index of the first character of this string that is not present in string_view.)#"  , py::arg("theSet"),  py::arg("theFromIndex"),  py::arg("theToIndex")
          )
        .def("IsDifferent",
             (bool (TCollection_AsciiString::*)(  const char * const  ,   const int  ) const) static_cast<bool (TCollection_AsciiString::*)(  const char * const  ,   const int  ) const>(&TCollection_AsciiString::IsDifferent),
             R"#(Core implementation: Returns true if there are differences between this ASCII string and the string (pointer and length). This is the primary implementation that string_view and CString overloads redirect to.)#"  , py::arg("theString"),  py::arg("theLength")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("EmptyString_s",
                    ( const TCollection_AsciiString & (*)() ) static_cast< const TCollection_AsciiString & (*)() >(&TCollection_AsciiString::EmptyString),
                    R"#(Returns a const reference to a single shared empty string instance. This method provides access to a static empty string to avoid creating temporary empty strings. Use this method instead of constructing empty strings when you need a const reference.)#" 
          )
        .def_static("IsEqual_s",
                    (bool (*)(  const TCollection_AsciiString & ,   const TCollection_AsciiString &  ) ) static_cast<bool (*)(  const TCollection_AsciiString & ,   const TCollection_AsciiString &  ) >(&TCollection_AsciiString::IsEqual),
                    R"#(Returns True when the two strings are the same. (Just for HashCode for AsciiString))#"  , py::arg("string1"),  py::arg("string2")
          )
        .def_static("IsEqual_s",
                    (bool (*)(  const TCollection_AsciiString & ,   const typename std::string_view &  ) ) static_cast<bool (*)(  const TCollection_AsciiString & ,   const typename std::string_view &  ) >(&TCollection_AsciiString::IsEqual),
                    R"#(Returns True when the ASCII string and string_view are the same. (Just for HashCode for AsciiString))#"  , py::arg("theString1"),  py::arg("theStringView")
          )
        .def_static("IsEqual_s",
                    (bool (*)(  const typename std::string_view & ,   const TCollection_AsciiString &  ) ) static_cast<bool (*)(  const typename std::string_view & ,   const TCollection_AsciiString &  ) >(&TCollection_AsciiString::IsEqual),
                    R"#(Returns True when the string_view and ASCII string are the same. (Just for HashCode for AsciiString))#"  , py::arg("theStringView"),  py::arg("theString2")
          )
        .def_static("IsSameString_s",
                    (bool (*)(  const char * const  ,   const int ,   const char * const  ,   const int ,   const bool  ) ) static_cast<bool (*)(  const char * const  ,   const int ,   const char * const  ,   const int ,   const bool  ) >(&TCollection_AsciiString::IsSameString),
                    R"#(Core implementation: Returns True if the two strings (pointer and length) contain same characters. This is the primary implementation that all other IsSameString overloads redirect to.)#"  , py::arg("theString1"),  py::arg("theLength1"),  py::arg("theString2"),  py::arg("theLength2"),  py::arg("theIsCaseSensitive")
          )
        .def_static("IsSameString_s",
                    (bool (*)(  const TCollection_AsciiString & ,   const TCollection_AsciiString & ,   const bool  ) ) static_cast<bool (*)(  const TCollection_AsciiString & ,   const TCollection_AsciiString & ,   const bool  ) >(&TCollection_AsciiString::IsSameString),
                    R"#(Returns True if the strings contain same characters.)#"  , py::arg("theString1"),  py::arg("theString2"),  py::arg("theIsCaseSensitive")
          )
        .def_static("IsSameString_s",
                    (bool (*)(  const TCollection_AsciiString & ,   const char * const  ,   const bool  ) ) static_cast<bool (*)(  const TCollection_AsciiString & ,   const char * const  ,   const bool  ) >(&TCollection_AsciiString::IsSameString),
                    R"#(Returns True if the string and C string contain same characters.)#"  , py::arg("theString1"),  py::arg("theCString"),  py::arg("theIsCaseSensitive")
          )
        .def_static("IsSameString_s",
                    (bool (*)(  const char * const  ,   const TCollection_AsciiString & ,   const bool  ) ) static_cast<bool (*)(  const char * const  ,   const TCollection_AsciiString & ,   const bool  ) >(&TCollection_AsciiString::IsSameString),
                    R"#(Returns True if the C string and string contain same characters.)#"  , py::arg("theCString"),  py::arg("theString2"),  py::arg("theIsCaseSensitive")
          )
        .def_static("IsSameString_s",
                    (bool (*)(  const TCollection_AsciiString & ,   const typename std::string_view & ,   const bool  ) ) static_cast<bool (*)(  const TCollection_AsciiString & ,   const typename std::string_view & ,   const bool  ) >(&TCollection_AsciiString::IsSameString),
                    R"#(Returns True if the string and string_view contain same characters.)#"  , py::arg("theString1"),  py::arg("theStringView"),  py::arg("theIsCaseSensitive")
          )
        .def_static("IsSameString_s",
                    (bool (*)(  const typename std::string_view & ,   const TCollection_AsciiString & ,   const bool  ) ) static_cast<bool (*)(  const typename std::string_view & ,   const TCollection_AsciiString & ,   const bool  ) >(&TCollection_AsciiString::IsSameString),
                    R"#(Returns True if the string_view and string contain same characters.)#"  , py::arg("theStringView"),  py::arg("theString2"),  py::arg("theIsCaseSensitive")
          )
        .def_static("IsSameString_s",
                    (bool (*)(  const char * const  ,   const char * const  ,   const bool  ) ) static_cast<bool (*)(  const char * const  ,   const char * const  ,   const bool  ) >(&TCollection_AsciiString::IsSameString),
                    R"#(Returns True if the two C strings contain same characters.)#"  , py::arg("theCString1"),  py::arg("theCString2"),  py::arg("theIsCaseSensitive")
          )
        .def_static("IsSameString_s",
                    (bool (*)(  const typename std::string_view & ,   const typename std::string_view & ,   const bool  ) ) static_cast<bool (*)(  const typename std::string_view & ,   const typename std::string_view & ,   const bool  ) >(&TCollection_AsciiString::IsSameString),
                    R"#(Returns True if the two string_views contain same characters.)#"  , py::arg("theStringView1"),  py::arg("theStringView2"),  py::arg("theIsCaseSensitive")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class TCollection_ExtendedString from ./opencascade/TCollection_ExtendedString.hxx
    klass = m.attr("TCollection_ExtendedString");


    // nested enums

    static_cast<py::class_<TCollection_ExtendedString , shared_ptr<TCollection_ExtendedString>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const TCollection_AsciiString &, const bool >()  , py::arg("theString"),  py::arg("theIsMultiByte")=static_cast< const bool>(true) )
        .def(py::init<  const TCollection_ExtendedString & >()  , py::arg("theString") )
        .def(py::init<  const char * const , const bool >()  , py::arg("theString"),  py::arg("theIsMultiByte")=static_cast< const bool>(false) )
        .def(py::init<  const char >()  , py::arg("theChar") )
        .def(py::init<  const char16_t * const  >()  , py::arg("theString") )
        .def(py::init<  const char16_t * const , const int >()  , py::arg("theString"),  py::arg("theLength") )
        .def(py::init<  const char16_t >()  , py::arg("theChar") )
        .def(py::init<  const double >()  , py::arg("theValue") )
        .def(py::init<  const int >()  , py::arg("theValue") )
        .def(py::init<  const int, const char16_t >()  , py::arg("theLength"),  py::arg("theFiller") )
        .def(py::init<  const wchar_t * >()  , py::arg("theStringUtf") )
    // custom constructors
    // methods
        .def("Cat",
             (TCollection_ExtendedString (TCollection_ExtendedString::*)(  const char16_t * const  ,   const int  ) const) static_cast<TCollection_ExtendedString (TCollection_ExtendedString::*)(  const char16_t * const  ,   const int  ) const>(&TCollection_ExtendedString::Cat),
             R"#(Core implementation: Concatenates char16_t string (pointer and length) and returns a new string.)#"  , py::arg("theOther"),  py::arg("theLength")
          )
        .def("Cat",
             (TCollection_ExtendedString (TCollection_ExtendedString::*)(  const char16_t * const   ) const) static_cast<TCollection_ExtendedString (TCollection_ExtendedString::*)(  const char16_t * const   ) const>(&TCollection_ExtendedString::Cat),
             R"#(Concatenates char16_t string and returns a new string.)#"  , py::arg("theOther")
          )
        .def("Cat",
             (TCollection_ExtendedString (TCollection_ExtendedString::*)(  const int  ) const) static_cast<TCollection_ExtendedString (TCollection_ExtendedString::*)(  const int  ) const>(&TCollection_ExtendedString::Cat),
             R"#(Appends the integer value to this string and returns a new string.)#"  , py::arg("theOther")
          )
        .def("Cat",
             (TCollection_ExtendedString (TCollection_ExtendedString::*)(  const double  ) const) static_cast<TCollection_ExtendedString (TCollection_ExtendedString::*)(  const double  ) const>(&TCollection_ExtendedString::Cat),
             R"#(Appends the real value to this string and returns a new string.)#"  , py::arg("theOther")
          )
        .def("Cat",
             (TCollection_ExtendedString (TCollection_ExtendedString::*)(  const char  ) const) static_cast<TCollection_ExtendedString (TCollection_ExtendedString::*)(  const char  ) const>(&TCollection_ExtendedString::Cat),
             R"#(Appends a single ASCII character to this string and returns a new string.)#"  , py::arg("theChar")
          )
        .def("Cat",
             (TCollection_ExtendedString (TCollection_ExtendedString::*)(  const char16_t  ) const) static_cast<TCollection_ExtendedString (TCollection_ExtendedString::*)(  const char16_t  ) const>(&TCollection_ExtendedString::Cat),
             R"#(Appends a single extended (char16_t) character to this string and returns a new string.)#"  , py::arg("theChar")
          )
        .def("Cat",
             (TCollection_ExtendedString (TCollection_ExtendedString::*)(  const TCollection_ExtendedString &  ) const) static_cast<TCollection_ExtendedString (TCollection_ExtendedString::*)(  const TCollection_ExtendedString &  ) const>(&TCollection_ExtendedString::Cat),
             R"#(Appends the other extended string to this string and returns a new string.)#"  , py::arg("theOther")
          )
        .def("ChangeAll",
             (void (TCollection_ExtendedString::*)(  const char16_t ,   const char16_t  ) ) static_cast<void (TCollection_ExtendedString::*)(  const char16_t ,   const char16_t  ) >(&TCollection_ExtendedString::ChangeAll),
             R"#(Substitutes all the characters equal to theChar by theNewChar in this ExtendedString. The substitution can be case sensitive. If you don't use default case sensitive, no matter whether theChar is uppercase or not.)#"  , py::arg("theChar"),  py::arg("theNewChar")
          )
        .def("Clear",
             (void (TCollection_ExtendedString::*)() ) static_cast<void (TCollection_ExtendedString::*)() >(&TCollection_ExtendedString::Clear),
             R"#(Removes all characters contained in this string. This produces an empty ExtendedString.)#" 
          )
        .def("Copy",
             (void (TCollection_ExtendedString::*)(  const char16_t * const  ,   const int  ) ) static_cast<void (TCollection_ExtendedString::*)(  const char16_t * const  ,   const int  ) >(&TCollection_ExtendedString::Copy),
             R"#(Core implementation: Copy from a char16_t pointer with explicit length.)#"  , py::arg("theString"),  py::arg("theLength")
          )
        .def("Copy",
             (void (TCollection_ExtendedString::*)(  const char16_t * const   ) ) static_cast<void (TCollection_ExtendedString::*)(  const char16_t * const   ) >(&TCollection_ExtendedString::Copy),
             R"#(Copy from a char16_t pointer.)#"  , py::arg("theString")
          )
        .def("Copy",
             (void (TCollection_ExtendedString::*)(  const TCollection_ExtendedString &  ) ) static_cast<void (TCollection_ExtendedString::*)(  const TCollection_ExtendedString &  ) >(&TCollection_ExtendedString::Copy),
             R"#(Copy theFromWhere to this string. Used as operator =)#"  , py::arg("theFromWhere")
          )
        .def("Swap",
             (void (TCollection_ExtendedString::*)( TCollection_ExtendedString &  ) ) static_cast<void (TCollection_ExtendedString::*)( TCollection_ExtendedString &  ) >(&TCollection_ExtendedString::Swap),
             R"#(Exchange the data of two strings (without reallocating memory).)#"  , py::arg("theOther")
          )
        .def("Insert",
             (void (TCollection_ExtendedString::*)(  const int ,   const char16_t  ) ) static_cast<void (TCollection_ExtendedString::*)(  const int ,   const char16_t  ) >(&TCollection_ExtendedString::Insert),
             R"#(Insert a Character at position theWhere.)#"  , py::arg("theWhere"),  py::arg("theWhat")
          )
        .def("Insert",
             (void (TCollection_ExtendedString::*)(  const int ,   const char16_t * const  ,   const int  ) ) static_cast<void (TCollection_ExtendedString::*)(  const int ,   const char16_t * const  ,   const int  ) >(&TCollection_ExtendedString::Insert),
             R"#(Core implementation: Insert a char16_t string (pointer and length) at position theWhere.)#"  , py::arg("theWhere"),  py::arg("theWhat"),  py::arg("theLength")
          )
        .def("Insert",
             (void (TCollection_ExtendedString::*)(  const int ,   const char16_t * const   ) ) static_cast<void (TCollection_ExtendedString::*)(  const int ,   const char16_t * const   ) >(&TCollection_ExtendedString::Insert),
             R"#(Insert a char16_t string at position theWhere.)#"  , py::arg("theWhere"),  py::arg("theWhat")
          )
        .def("Insert",
             (void (TCollection_ExtendedString::*)(  const int ,   const TCollection_ExtendedString &  ) ) static_cast<void (TCollection_ExtendedString::*)(  const int ,   const TCollection_ExtendedString &  ) >(&TCollection_ExtendedString::Insert),
             R"#(Insert an ExtendedString at position theWhere.)#"  , py::arg("theWhere"),  py::arg("theWhat")
          )
        .def("IsEmpty",
             (bool (TCollection_ExtendedString::*)() const) static_cast<bool (TCollection_ExtendedString::*)() const>(&TCollection_ExtendedString::IsEmpty),
             R"#(Returns True if this string contains no characters.)#" 
          )
        .def("IsEqual",
             (bool (TCollection_ExtendedString::*)(  const char16_t * const  ,   const int  ) const) static_cast<bool (TCollection_ExtendedString::*)(  const char16_t * const  ,   const int  ) const>(&TCollection_ExtendedString::IsEqual),
             R"#(Core implementation: Returns true if this string equals theOther (pointer and length).)#"  , py::arg("theOther"),  py::arg("theLength")
          )
        .def("IsEqual",
             (bool (TCollection_ExtendedString::*)(  const char16_t * const   ) const) static_cast<bool (TCollection_ExtendedString::*)(  const char16_t * const   ) const>(&TCollection_ExtendedString::IsEqual),
             R"#(Returns true if this string equals theOther null-terminated string. Note that this method is an alias of operator ==.)#"  , py::arg("theOther")
          )
        .def("IsEqual",
             (bool (TCollection_ExtendedString::*)(  const TCollection_ExtendedString &  ) const) static_cast<bool (TCollection_ExtendedString::*)(  const TCollection_ExtendedString &  ) const>(&TCollection_ExtendedString::IsEqual),
             R"#(Returns true if the characters in this extended string are identical to the characters in theOther extended string. Note that this method is an alias of operator ==.)#"  , py::arg("theOther")
          )
        .def("IsDifferent",
             (bool (TCollection_ExtendedString::*)(  const char16_t * const  ,   const int  ) const) static_cast<bool (TCollection_ExtendedString::*)(  const char16_t * const  ,   const int  ) const>(&TCollection_ExtendedString::IsDifferent),
             R"#(Core implementation: Returns true if this string differs from theOther (pointer and length).)#"  , py::arg("theOther"),  py::arg("theLength")
          )
        .def("IsDifferent",
             (bool (TCollection_ExtendedString::*)(  const char16_t * const   ) const) static_cast<bool (TCollection_ExtendedString::*)(  const char16_t * const   ) const>(&TCollection_ExtendedString::IsDifferent),
             R"#(Returns true if this string differs from theOther null-terminated string. Note that this method is an alias of operator !=.)#"  , py::arg("theOther")
          )
        .def("IsDifferent",
             (bool (TCollection_ExtendedString::*)(  const TCollection_ExtendedString &  ) const) static_cast<bool (TCollection_ExtendedString::*)(  const TCollection_ExtendedString &  ) const>(&TCollection_ExtendedString::IsDifferent),
             R"#(Returns true if there are differences between the characters in this extended string and theOther extended string. Note that this method is an alias of operator !=.)#"  , py::arg("theOther")
          )
        .def("IsLess",
             (bool (TCollection_ExtendedString::*)(  const char16_t * const  ,   const int  ) const) static_cast<bool (TCollection_ExtendedString::*)(  const char16_t * const  ,   const int  ) const>(&TCollection_ExtendedString::IsLess),
             R"#(Core implementation: Returns TRUE if this string is lexicographically less than theOther.)#"  , py::arg("theOther"),  py::arg("theLength")
          )
        .def("IsLess",
             (bool (TCollection_ExtendedString::*)(  const char16_t * const   ) const) static_cast<bool (TCollection_ExtendedString::*)(  const char16_t * const   ) const>(&TCollection_ExtendedString::IsLess),
             R"#(Returns TRUE if this string is lexicographically less than theOther.)#"  , py::arg("theOther")
          )
        .def("IsLess",
             (bool (TCollection_ExtendedString::*)(  const TCollection_ExtendedString &  ) const) static_cast<bool (TCollection_ExtendedString::*)(  const TCollection_ExtendedString &  ) const>(&TCollection_ExtendedString::IsLess),
             R"#(Returns TRUE if this string is lexicographically less than theOther.)#"  , py::arg("theOther")
          )
        .def("IsGreater",
             (bool (TCollection_ExtendedString::*)(  const char16_t * const  ,   const int  ) const) static_cast<bool (TCollection_ExtendedString::*)(  const char16_t * const  ,   const int  ) const>(&TCollection_ExtendedString::IsGreater),
             R"#(Core implementation: Returns TRUE if this string is lexicographically greater than theOther.)#"  , py::arg("theOther"),  py::arg("theLength")
          )
        .def("IsGreater",
             (bool (TCollection_ExtendedString::*)(  const char16_t * const   ) const) static_cast<bool (TCollection_ExtendedString::*)(  const char16_t * const   ) const>(&TCollection_ExtendedString::IsGreater),
             R"#(Returns TRUE if this string is lexicographically greater than theOther.)#"  , py::arg("theOther")
          )
        .def("IsGreater",
             (bool (TCollection_ExtendedString::*)(  const TCollection_ExtendedString &  ) const) static_cast<bool (TCollection_ExtendedString::*)(  const TCollection_ExtendedString &  ) const>(&TCollection_ExtendedString::IsGreater),
             R"#(Returns TRUE if this string is lexicographically greater than theOther.)#"  , py::arg("theOther")
          )
        .def("StartsWith",
             (bool (TCollection_ExtendedString::*)(  const char16_t * const  ,   const int  ) const) static_cast<bool (TCollection_ExtendedString::*)(  const char16_t * const  ,   const int  ) const>(&TCollection_ExtendedString::StartsWith),
             R"#(Core implementation: Determines whether this string starts with theStartString.)#"  , py::arg("theStartString"),  py::arg("theLength")
          )
        .def("StartsWith",
             (bool (TCollection_ExtendedString::*)(  const char16_t * const   ) const) static_cast<bool (TCollection_ExtendedString::*)(  const char16_t * const   ) const>(&TCollection_ExtendedString::StartsWith),
             R"#(Determines whether this string starts with theStartString.)#"  , py::arg("theStartString")
          )
        .def("StartsWith",
             (bool (TCollection_ExtendedString::*)(  const TCollection_ExtendedString &  ) const) static_cast<bool (TCollection_ExtendedString::*)(  const TCollection_ExtendedString &  ) const>(&TCollection_ExtendedString::StartsWith),
             R"#(Determines whether the beginning of this string instance matches the specified string.)#"  , py::arg("theStartString")
          )
        .def("EndsWith",
             (bool (TCollection_ExtendedString::*)(  const char16_t * const  ,   const int  ) const) static_cast<bool (TCollection_ExtendedString::*)(  const char16_t * const  ,   const int  ) const>(&TCollection_ExtendedString::EndsWith),
             R"#(Core implementation: Determines whether this string ends with theEndString.)#"  , py::arg("theEndString"),  py::arg("theLength")
          )
        .def("EndsWith",
             (bool (TCollection_ExtendedString::*)(  const char16_t * const   ) const) static_cast<bool (TCollection_ExtendedString::*)(  const char16_t * const   ) const>(&TCollection_ExtendedString::EndsWith),
             R"#(Determines whether this string ends with theEndString.)#"  , py::arg("theEndString")
          )
        .def("EndsWith",
             (bool (TCollection_ExtendedString::*)(  const TCollection_ExtendedString &  ) const) static_cast<bool (TCollection_ExtendedString::*)(  const TCollection_ExtendedString &  ) const>(&TCollection_ExtendedString::EndsWith),
             R"#(Determines whether the end of this string instance matches the specified string.)#"  , py::arg("theEndString")
          )
        .def("IsAscii",
             (bool (TCollection_ExtendedString::*)() const) static_cast<bool (TCollection_ExtendedString::*)() const>(&TCollection_ExtendedString::IsAscii),
             R"#(Returns True if the ExtendedString contains only "Ascii Range" characters.)#" 
          )
        .def("Length",
             (int (TCollection_ExtendedString::*)() const) static_cast<int (TCollection_ExtendedString::*)() const>(&TCollection_ExtendedString::Length),
             R"#(Returns the number of 16-bit code units (might be greater than number of Unicode symbols if string contains surrogate pairs).)#" 
          )
        .def("Print",
             (void (TCollection_ExtendedString::*)( Standard_OStream &  ) const) static_cast<void (TCollection_ExtendedString::*)( Standard_OStream &  ) const>(&TCollection_ExtendedString::Print),
             R"#(Displays this string on a stream.)#"  , py::arg("theStream")
          )
        .def("RemoveAll",
             (void (TCollection_ExtendedString::*)(  const char16_t  ) ) static_cast<void (TCollection_ExtendedString::*)(  const char16_t  ) >(&TCollection_ExtendedString::RemoveAll),
             R"#(Removes every theWhat characters from this string.)#"  , py::arg("theWhat")
          )
        .def("Remove",
             (void (TCollection_ExtendedString::*)(  const int ,   const int  ) ) static_cast<void (TCollection_ExtendedString::*)(  const int ,   const int  ) >(&TCollection_ExtendedString::Remove),
             R"#(Erases theHowMany characters from position theWhere, theWhere included.)#"  , py::arg("theWhere"),  py::arg("theHowMany")=static_cast< const int>(1)
          )
        .def("Search",
             (int (TCollection_ExtendedString::*)(  const char16_t * const  ,   const int  ) const) static_cast<int (TCollection_ExtendedString::*)(  const char16_t * const  ,   const int  ) const>(&TCollection_ExtendedString::Search),
             R"#(Core implementation: Searches for theWhat (pointer and length) from the beginning.)#"  , py::arg("theWhat"),  py::arg("theLength")
          )
        .def("Search",
             (int (TCollection_ExtendedString::*)(  const char16_t * const   ) const) static_cast<int (TCollection_ExtendedString::*)(  const char16_t * const   ) const>(&TCollection_ExtendedString::Search),
             R"#(Searches for theWhat null-terminated string from the beginning.)#"  , py::arg("theWhat")
          )
        .def("Search",
             (int (TCollection_ExtendedString::*)(  const TCollection_ExtendedString &  ) const) static_cast<int (TCollection_ExtendedString::*)(  const TCollection_ExtendedString &  ) const>(&TCollection_ExtendedString::Search),
             R"#(Searches an ExtendedString in this string from the beginning and returns position of first item theWhat matching. It returns -1 if not found.)#"  , py::arg("theWhat")
          )
        .def("SearchFromEnd",
             (int (TCollection_ExtendedString::*)(  const char16_t * const  ,   const int  ) const) static_cast<int (TCollection_ExtendedString::*)(  const char16_t * const  ,   const int  ) const>(&TCollection_ExtendedString::SearchFromEnd),
             R"#(Core implementation: Searches for theWhat (pointer and length) from the end.)#"  , py::arg("theWhat"),  py::arg("theLength")
          )
        .def("SearchFromEnd",
             (int (TCollection_ExtendedString::*)(  const char16_t * const   ) const) static_cast<int (TCollection_ExtendedString::*)(  const char16_t * const   ) const>(&TCollection_ExtendedString::SearchFromEnd),
             R"#(Searches for theWhat null-terminated string from the end.)#"  , py::arg("theWhat")
          )
        .def("SearchFromEnd",
             (int (TCollection_ExtendedString::*)(  const TCollection_ExtendedString &  ) const) static_cast<int (TCollection_ExtendedString::*)(  const TCollection_ExtendedString &  ) const>(&TCollection_ExtendedString::SearchFromEnd),
             R"#(Searches an ExtendedString in this string from the end and returns position of first item theWhat matching. It returns -1 if not found.)#"  , py::arg("theWhat")
          )
        .def("SetValue",
             (void (TCollection_ExtendedString::*)(  const int ,   const char16_t  ) ) static_cast<void (TCollection_ExtendedString::*)(  const int ,   const char16_t  ) >(&TCollection_ExtendedString::SetValue),
             R"#(Replaces one character in the ExtendedString at position theWhere. If theWhere is less than zero or greater than the length of this string an exception is raised.)#"  , py::arg("theWhere"),  py::arg("theWhat")
          )
        .def("SetValue",
             (void (TCollection_ExtendedString::*)(  const int ,   const char16_t * const  ,   const int  ) ) static_cast<void (TCollection_ExtendedString::*)(  const int ,   const char16_t * const  ,   const int  ) >(&TCollection_ExtendedString::SetValue),
             R"#(Core implementation: Replaces a part of this string by char16_t string (pointer and length).)#"  , py::arg("theWhere"),  py::arg("theWhat"),  py::arg("theLength")
          )
        .def("SetValue",
             (void (TCollection_ExtendedString::*)(  const int ,   const char16_t * const   ) ) static_cast<void (TCollection_ExtendedString::*)(  const int ,   const char16_t * const   ) >(&TCollection_ExtendedString::SetValue),
             R"#(Replaces a part of this string by a null-terminated char16_t string.)#"  , py::arg("theWhere"),  py::arg("theWhat")
          )
        .def("SetValue",
             (void (TCollection_ExtendedString::*)(  const int ,   const TCollection_ExtendedString &  ) ) static_cast<void (TCollection_ExtendedString::*)(  const int ,   const TCollection_ExtendedString &  ) >(&TCollection_ExtendedString::SetValue),
             R"#(Replaces a part of this string by another ExtendedString.)#"  , py::arg("theWhere"),  py::arg("theWhat")
          )
        .def("SubString",
             (TCollection_ExtendedString (TCollection_ExtendedString::*)(  const int ,   const int  ) const) static_cast<TCollection_ExtendedString (TCollection_ExtendedString::*)(  const int ,   const int  ) const>(&TCollection_ExtendedString::SubString),
             R"#(Copies characters from this string starting from index theFromIndex to the index theToIndex (inclusive). Raises an exception if theToIndex or theFromIndex is out of bounds.)#"  , py::arg("theFromIndex"),  py::arg("theToIndex")
          )
        .def("Split",
             (TCollection_ExtendedString (TCollection_ExtendedString::*)(  const int  ) ) static_cast<TCollection_ExtendedString (TCollection_ExtendedString::*)(  const int  ) >(&TCollection_ExtendedString::Split),
             R"#(Splits this extended string into two sub-strings at position theWhere. - The second sub-string (from position theWhere + 1 of this string to the end) is returned in a new extended string. - This extended string is modified: its last characters are removed, it becomes equal to the first sub-string (from the first character to position theWhere).)#"  , py::arg("theWhere")
          )
        .def("Token",
             (TCollection_ExtendedString (TCollection_ExtendedString::*)(  const char16_t * const  ,   const int  ) const) static_cast<TCollection_ExtendedString (TCollection_ExtendedString::*)(  const char16_t * const  ,   const int  ) const>(&TCollection_ExtendedString::Token),
             R"#(Extracts theWhichOne token from this string. By default, the theSeparators is set to space and tabulation. By default, the token extracted is the first one (theWhichOne = 1). theSeparators contains all separators you need. If no token indexed by theWhichOne is found, it returns an empty ExtendedString.)#"  , py::arg("theSeparators"),  py::arg("theWhichOne")=static_cast< const int>(1)
          )
        .def("ToExtString",
             ( const char16_t * (TCollection_ExtendedString::*)() const) static_cast< const char16_t * (TCollection_ExtendedString::*)() const>(&TCollection_ExtendedString::ToExtString),
             R"#(Returns pointer to ExtString (char16_t*).)#" 
          )
        .def("ToWideString",
             ( const wchar_t * (TCollection_ExtendedString::*)() const) static_cast< const wchar_t * (TCollection_ExtendedString::*)() const>(&TCollection_ExtendedString::ToWideString),
             R"#(Returns pointer to string as wchar_t* on Windows platform where wchar_t* is considered as UTF-16 string. This method is useful to pass string into wide-char system APIs, and makes sense only on Windows (other systems use UTF-8 and can miss wide-char functions at all).)#" 
          )
        .def("Trunc",
             (void (TCollection_ExtendedString::*)(  const int  ) ) static_cast<void (TCollection_ExtendedString::*)(  const int  ) >(&TCollection_ExtendedString::Trunc),
             R"#(Truncates this string to theHowMany characters.)#"  , py::arg("theHowMany")
          )
        .def("Value",
             (char16_t (TCollection_ExtendedString::*)(  const int  ) const) static_cast<char16_t (TCollection_ExtendedString::*)(  const int  ) const>(&TCollection_ExtendedString::Value),
             R"#(Returns character at position theWhere in this string. If theWhere is less than zero or greater than the length of this string, an exception is raised.)#"  , py::arg("theWhere")
          )
        .def("HashCode",
             (size_t (TCollection_ExtendedString::*)() const) static_cast<size_t (TCollection_ExtendedString::*)() const>(&TCollection_ExtendedString::HashCode),
             R"#(Returns a hashed value for the extended string. Note: if string is ASCII, the computed value is the same as the value computed with the HashCode function on a TCollection_AsciiString string composed with equivalent ASCII characters.)#" 
          )
        .def("LengthOfCString",
             (int (TCollection_ExtendedString::*)() const) static_cast<int (TCollection_ExtendedString::*)() const>(&TCollection_ExtendedString::LengthOfCString),
             R"#(Returns expected CString length in UTF8 coding (like strlen, without null terminator). It can be used for memory calculation before converting to CString containing symbols in UTF8 coding. For external allocation, use: char* buf = new char[str.LengthOfCString() + 1];)#" 
          )
        .def("LeftAdjust",
             (void (TCollection_ExtendedString::*)() ) static_cast<void (TCollection_ExtendedString::*)() >(&TCollection_ExtendedString::LeftAdjust),
             R"#(Removes all space characters in the beginning of the string.)#" 
          )
        .def("RightAdjust",
             (void (TCollection_ExtendedString::*)() ) static_cast<void (TCollection_ExtendedString::*)() >(&TCollection_ExtendedString::RightAdjust),
             R"#(Removes all space characters at the end of the string.)#" 
          )
        .def("LeftJustify",
             (void (TCollection_ExtendedString::*)(  const int ,   const char16_t  ) ) static_cast<void (TCollection_ExtendedString::*)(  const int ,   const char16_t  ) >(&TCollection_ExtendedString::LeftJustify),
             R"#(Left justify. Length becomes equal to theWidth and the new characters are equal to theFiller. If theWidth < Length nothing happens.)#"  , py::arg("theWidth"),  py::arg("theFiller")
          )
        .def("RightJustify",
             (void (TCollection_ExtendedString::*)(  const int ,   const char16_t  ) ) static_cast<void (TCollection_ExtendedString::*)(  const int ,   const char16_t  ) >(&TCollection_ExtendedString::RightJustify),
             R"#(Right justify. Length becomes equal to theWidth and the new characters are equal to theFiller. If theWidth < Length nothing happens.)#"  , py::arg("theWidth"),  py::arg("theFiller")
          )
        .def("Center",
             (void (TCollection_ExtendedString::*)(  const int ,   const char16_t  ) ) static_cast<void (TCollection_ExtendedString::*)(  const int ,   const char16_t  ) >(&TCollection_ExtendedString::Center),
             R"#(Modifies this string so that its length becomes equal to theWidth and the new characters are equal to theFiller. New characters are added both at the beginning and at the end of this string. If theWidth is less than the length of this string, nothing happens.)#"  , py::arg("theWidth"),  py::arg("theFiller")
          )
        .def("Capitalize",
             (void (TCollection_ExtendedString::*)() ) static_cast<void (TCollection_ExtendedString::*)() >(&TCollection_ExtendedString::Capitalize),
             R"#(Converts the first character into its corresponding upper-case character and the other characters into lowercase.)#" 
          )
        .def("Prepend",
             (void (TCollection_ExtendedString::*)(  const char16_t * const  ,   const int  ) ) static_cast<void (TCollection_ExtendedString::*)(  const char16_t * const  ,   const int  ) >(&TCollection_ExtendedString::Prepend),
             R"#(Core implementation: Inserts char16_t string (pointer and length) at the beginning.)#"  , py::arg("theOther"),  py::arg("theLength")
          )
        .def("Prepend",
             (void (TCollection_ExtendedString::*)(  const char16_t * const   ) ) static_cast<void (TCollection_ExtendedString::*)(  const char16_t * const   ) >(&TCollection_ExtendedString::Prepend),
             R"#(Inserts a null-terminated char16_t string at the beginning.)#"  , py::arg("theOther")
          )
        .def("Prepend",
             (void (TCollection_ExtendedString::*)(  const TCollection_ExtendedString &  ) ) static_cast<void (TCollection_ExtendedString::*)(  const TCollection_ExtendedString &  ) >(&TCollection_ExtendedString::Prepend),
             R"#(Inserts the other extended string at the beginning of this string.)#"  , py::arg("theOther")
          )
        .def("FirstLocationInSet",
             (int (TCollection_ExtendedString::*)(  const TCollection_ExtendedString & ,   const int ,   const int  ) const) static_cast<int (TCollection_ExtendedString::*)(  const TCollection_ExtendedString & ,   const int ,   const int  ) const>(&TCollection_ExtendedString::FirstLocationInSet),
             R"#(Returns the index of the first character of this string that is present in theSet. The search begins at index theFromIndex and ends at index theToIndex. Returns zero if failure.)#"  , py::arg("theSet"),  py::arg("theFromIndex"),  py::arg("theToIndex")
          )
        .def("FirstLocationNotInSet",
             (int (TCollection_ExtendedString::*)(  const TCollection_ExtendedString & ,   const int ,   const int  ) const) static_cast<int (TCollection_ExtendedString::*)(  const TCollection_ExtendedString & ,   const int ,   const int  ) const>(&TCollection_ExtendedString::FirstLocationNotInSet),
             R"#(Returns the index of the first character of this string that is NOT present in theSet. The search begins at index theFromIndex and ends at index theToIndex. Returns zero if failure.)#"  , py::arg("theSet"),  py::arg("theFromIndex"),  py::arg("theToIndex")
          )
        .def("IntegerValue",
             (int (TCollection_ExtendedString::*)() const) static_cast<int (TCollection_ExtendedString::*)() const>(&TCollection_ExtendedString::IntegerValue),
             R"#(Converts this extended string containing a numeric expression to an Integer.)#" 
          )
        .def("IsIntegerValue",
             (bool (TCollection_ExtendedString::*)() const) static_cast<bool (TCollection_ExtendedString::*)() const>(&TCollection_ExtendedString::IsIntegerValue),
             R"#(Returns True if this extended string contains an integer value.)#" 
          )
        .def("RealValue",
             (double (TCollection_ExtendedString::*)() const) static_cast<double (TCollection_ExtendedString::*)() const>(&TCollection_ExtendedString::RealValue),
             R"#(Converts this extended string containing a numeric expression to a Real.)#" 
          )
        .def("IsRealValue",
             (bool (TCollection_ExtendedString::*)( bool  ) const) static_cast<bool (TCollection_ExtendedString::*)( bool  ) const>(&TCollection_ExtendedString::IsRealValue),
             R"#(Returns True if this extended string starts with characters that can be interpreted as a real value.)#"  , py::arg("theToCheckFull")=static_cast<bool>(false)
          )
        .def("IsSameString",
             (bool (TCollection_ExtendedString::*)(  const TCollection_ExtendedString & ,   const bool  ) const) static_cast<bool (TCollection_ExtendedString::*)(  const TCollection_ExtendedString & ,   const bool  ) const>(&TCollection_ExtendedString::IsSameString),
             R"#(Returns True if the strings contain same characters.)#"  , py::arg("theOther"),  py::arg("theIsCaseSensitive")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("EmptyString_s",
                    ( const TCollection_ExtendedString & (*)() ) static_cast< const TCollection_ExtendedString & (*)() >(&TCollection_ExtendedString::EmptyString),
                    R"#(Returns a const reference to a single shared empty string instance. This method provides access to a static empty string to avoid creating temporary empty strings. Use this method instead of constructing empty strings when you need a const reference.)#" 
          )
        .def_static("IsEqual_s",
                    (bool (*)(  const TCollection_ExtendedString & ,   const TCollection_ExtendedString &  ) ) static_cast<bool (*)(  const TCollection_ExtendedString & ,   const TCollection_ExtendedString &  ) >(&TCollection_ExtendedString::IsEqual),
                    R"#(Returns true if the characters in this extended string are identical to the characters in the other extended string. Note that this method is an alias of operator ==.)#"  , py::arg("theString1"),  py::arg("theString2")
          )
    // static methods using call by reference i.s.o. return
    // operators
        .def("__add__",
             (TCollection_ExtendedString (TCollection_ExtendedString::*)(  const char16_t * const   ) const) static_cast<TCollection_ExtendedString (TCollection_ExtendedString::*)(  const char16_t * const   ) const>(&TCollection_ExtendedString::operator+),
             py::is_operator(),
             R"#()#"  , py::arg("theOther")
          )
        .def("__add__",
             (TCollection_ExtendedString (TCollection_ExtendedString::*)(  const int  ) const) static_cast<TCollection_ExtendedString (TCollection_ExtendedString::*)(  const int  ) const>(&TCollection_ExtendedString::operator+),
             py::is_operator(),
             R"#()#"  , py::arg("theOther")
          )
        .def("__add__",
             (TCollection_ExtendedString (TCollection_ExtendedString::*)(  const double  ) const) static_cast<TCollection_ExtendedString (TCollection_ExtendedString::*)(  const double  ) const>(&TCollection_ExtendedString::operator+),
             py::is_operator(),
             R"#()#"  , py::arg("theOther")
          )
        .def("__add__",
             (TCollection_ExtendedString (TCollection_ExtendedString::*)(  const char  ) const) static_cast<TCollection_ExtendedString (TCollection_ExtendedString::*)(  const char  ) const>(&TCollection_ExtendedString::operator+),
             py::is_operator(),
             R"#()#"  , py::arg("theChar")
          )
        .def("__add__",
             (TCollection_ExtendedString (TCollection_ExtendedString::*)(  const char16_t  ) const) static_cast<TCollection_ExtendedString (TCollection_ExtendedString::*)(  const char16_t  ) const>(&TCollection_ExtendedString::operator+),
             py::is_operator(),
             R"#()#"  , py::arg("theChar")
          )
        .def("__add__",
             (TCollection_ExtendedString (TCollection_ExtendedString::*)(  const TCollection_ExtendedString &  ) const) static_cast<TCollection_ExtendedString (TCollection_ExtendedString::*)(  const TCollection_ExtendedString &  ) const>(&TCollection_ExtendedString::operator+),
             py::is_operator(),
             R"#()#"  , py::arg("theOther")
          )
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class TCollection_HAsciiString from ./opencascade/TCollection_HAsciiString.hxx
    klass = m.attr("TCollection_HAsciiString");


    // nested enums

    static_cast<py::class_<TCollection_HAsciiString ,opencascade::handle<TCollection_HAsciiString>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const TCollection_AsciiString & >()  , py::arg("aString") )
        .def(py::init<  const char * const  >()  , py::arg("message") )
        .def(py::init<  const char >()  , py::arg("aChar") )
        .def(py::init<  const double >()  , py::arg("value") )
        .def(py::init<  const int >()  , py::arg("value") )
        .def(py::init<  const int, const char >()  , py::arg("length"),  py::arg("filler") )
        .def(py::init<  const handle<TCollection_HAsciiString> & >()  , py::arg("aString") )
        .def(py::init<  const handle<TCollection_HExtendedString> &, const char >()  , py::arg("aString"),  py::arg("replaceNonAscii") )
    // custom constructors
        .def(py::init( [](const std::string &s){ return TCollection_HAsciiString(s.c_str()); } ))
    // methods
        .def("AssignCat",
             (void (TCollection_HAsciiString::*)(  const char * const   ) ) static_cast<void (TCollection_HAsciiString::*)(  const char * const   ) >(&TCollection_HAsciiString::AssignCat),
             R"#(Appends <other> to me.)#"  , py::arg("other")
          )
        .def("AssignCat",
             (void (TCollection_HAsciiString::*)(  const handle<TCollection_HAsciiString> &  ) ) static_cast<void (TCollection_HAsciiString::*)(  const handle<TCollection_HAsciiString> &  ) >(&TCollection_HAsciiString::AssignCat),
             R"#(Appends <other> to me. Example: aString = aString + anotherString)#"  , py::arg("other")
          )
        .def("Capitalize",
             (void (TCollection_HAsciiString::*)() ) static_cast<void (TCollection_HAsciiString::*)() >(&TCollection_HAsciiString::Capitalize),
             R"#(Converts the first character into its corresponding upper-case character and the other characters into lowercase. Example: before me = "hellO " after me = "Hello ")#" 
          )
        .def("Cat",
             (handle<TCollection_HAsciiString> (TCollection_HAsciiString::*)(  const char * const   ) const) static_cast<handle<TCollection_HAsciiString> (TCollection_HAsciiString::*)(  const char * const   ) const>(&TCollection_HAsciiString::Cat),
             R"#(Creates a new string by concatenation of this ASCII string and the other ASCII string. Example: aString = aString + anotherString aString = aString + "Dummy" aString contains "I say " aString = aString + "Hello " + "Dolly" gives "I say Hello Dolly" Warning: To catenate more than one CString, you must put a String before. So the following example is WRONG ! aString = "Hello " + "Dolly" THIS IS NOT ALLOWED This rule is applicable to AssignCat (operator +=) too.)#"  , py::arg("other")
          )
        .def("Cat",
             (handle<TCollection_HAsciiString> (TCollection_HAsciiString::*)(  const handle<TCollection_HAsciiString> &  ) const) static_cast<handle<TCollection_HAsciiString> (TCollection_HAsciiString::*)(  const handle<TCollection_HAsciiString> &  ) const>(&TCollection_HAsciiString::Cat),
             R"#(Creates a new string by concatenation of this ASCII string and the other ASCII string. Example: aString = aString + anotherString)#"  , py::arg("other")
          )
        .def("Center",
             (void (TCollection_HAsciiString::*)(  const int ,   const char  ) ) static_cast<void (TCollection_HAsciiString::*)(  const int ,   const char  ) >(&TCollection_HAsciiString::Center),
             R"#(Modifies this ASCII string so that its length becomes equal to Width and the new characters are equal to Filler. New characters are added both at the beginning and at the end of this string. If Width is less than the length of this ASCII string, nothing happens. Example occ::handle<TCollection_HAsciiString> myAlphabet = new TCollection_HAsciiString ("abcdef"); myAlphabet->Center(9,' '); assert ( !strcmp( myAlphabet->ToCString(), " abcdef ") );)#"  , py::arg("Width"),  py::arg("Filler")
          )
        .def("ChangeAll",
             (void (TCollection_HAsciiString::*)(  const char ,   const char ,   const bool  ) ) static_cast<void (TCollection_HAsciiString::*)(  const char ,   const char ,   const bool  ) >(&TCollection_HAsciiString::ChangeAll),
             R"#(Replaces all characters equal to aChar by NewChar in this ASCII string. The substitution is case sensitive if CaseSensitive is true (default value). If you do not use the default case sensitive option, it does not matter whether aChar is upper-case or not. Example occ::handle<TCollection_HAsciiString> myMistake = new TCollection_HAsciiString ("Hather"); myMistake->ChangeAll('H','F'); assert ( !strcmp( myMistake->ToCString(), "Father") );)#"  , py::arg("aChar"),  py::arg("NewChar"),  py::arg("CaseSensitive")=static_cast< const bool>(true)
          )
        .def("Clear",
             (void (TCollection_HAsciiString::*)() ) static_cast<void (TCollection_HAsciiString::*)() >(&TCollection_HAsciiString::Clear),
             R"#(Removes all characters contained in <me>. This produces an empty HAsciiString.)#" 
          )
        .def("FirstLocationInSet",
             (int (TCollection_HAsciiString::*)(  const handle<TCollection_HAsciiString> & ,   const int ,   const int  ) const) static_cast<int (TCollection_HAsciiString::*)(  const handle<TCollection_HAsciiString> & ,   const int ,   const int  ) const>(&TCollection_HAsciiString::FirstLocationInSet),
             R"#(Returns the index of the first character of <me> that is present in <Set>. The search begins to the index FromIndex and ends to the the index ToIndex. Returns zero if failure. Raises an exception if FromIndex or ToIndex is out of range Example: before me = "aabAcAa", S = "Aa", FromIndex = 1, Toindex = 7 after me = "aabAcAa" returns 1)#"  , py::arg("Set"),  py::arg("FromIndex"),  py::arg("ToIndex")
          )
        .def("FirstLocationNotInSet",
             (int (TCollection_HAsciiString::*)(  const handle<TCollection_HAsciiString> & ,   const int ,   const int  ) const) static_cast<int (TCollection_HAsciiString::*)(  const handle<TCollection_HAsciiString> & ,   const int ,   const int  ) const>(&TCollection_HAsciiString::FirstLocationNotInSet),
             R"#(Returns the index of the first character of <me> that is not present in the set <Set>. The search begins to the index FromIndex and ends to the the index ToIndex in <me>. Returns zero if failure. Raises an exception if FromIndex or ToIndex is out of range. Example: before me = "aabAcAa", S = "Aa", FromIndex = 1, Toindex = 7 after me = "aabAcAa" returns 3)#"  , py::arg("Set"),  py::arg("FromIndex"),  py::arg("ToIndex")
          )
        .def("Insert",
             (void (TCollection_HAsciiString::*)(  const int ,   const char  ) ) static_cast<void (TCollection_HAsciiString::*)(  const int ,   const char  ) >(&TCollection_HAsciiString::Insert),
             R"#(Insert a Character at position <where>. Example: aString contains "hy not ?" aString.Insert(1,'W'); gives "Why not ?" aString contains "Wh" aString.Insert(3,'y'); gives "Why" aString contains "Way" aString.Insert(2,'h'); gives "Why")#"  , py::arg("where"),  py::arg("what")
          )
        .def("Insert",
             (void (TCollection_HAsciiString::*)(  const int ,   const char * const   ) ) static_cast<void (TCollection_HAsciiString::*)(  const int ,   const char * const   ) >(&TCollection_HAsciiString::Insert),
             R"#(Insert a HAsciiString at position <where>.)#"  , py::arg("where"),  py::arg("what")
          )
        .def("Insert",
             (void (TCollection_HAsciiString::*)(  const int ,   const handle<TCollection_HAsciiString> &  ) ) static_cast<void (TCollection_HAsciiString::*)(  const int ,   const handle<TCollection_HAsciiString> &  ) >(&TCollection_HAsciiString::Insert),
             R"#(Insert a HAsciiString at position <where>.)#"  , py::arg("where"),  py::arg("what")
          )
        .def("InsertAfter",
             (void (TCollection_HAsciiString::*)(  const int ,   const handle<TCollection_HAsciiString> &  ) ) static_cast<void (TCollection_HAsciiString::*)(  const int ,   const handle<TCollection_HAsciiString> &  ) >(&TCollection_HAsciiString::InsertAfter),
             R"#(Inserts the other ASCII string a after a specific index in the string <me> Example: before me = "cde" , Index = 0 , other = "ab" after me = "abcde" , other = "ab")#"  , py::arg("Index"),  py::arg("other")
          )
        .def("InsertBefore",
             (void (TCollection_HAsciiString::*)(  const int ,   const handle<TCollection_HAsciiString> &  ) ) static_cast<void (TCollection_HAsciiString::*)(  const int ,   const handle<TCollection_HAsciiString> &  ) >(&TCollection_HAsciiString::InsertBefore),
             R"#(Inserts the other ASCII string a before a specific index in the string <me> Raises an exception if Index is out of bounds Example: before me = "cde" , Index = 1 , other = "ab" after me = "abcde" , other = "ab")#"  , py::arg("Index"),  py::arg("other")
          )
        .def("IsEmpty",
             (bool (TCollection_HAsciiString::*)() const) static_cast<bool (TCollection_HAsciiString::*)() const>(&TCollection_HAsciiString::IsEmpty),
             R"#(Returns True if the string <me> contains zero character)#" 
          )
        .def("IsLess",
             (bool (TCollection_HAsciiString::*)(  const handle<TCollection_HAsciiString> &  ) const) static_cast<bool (TCollection_HAsciiString::*)(  const handle<TCollection_HAsciiString> &  ) const>(&TCollection_HAsciiString::IsLess),
             R"#(Returns TRUE if <me> is 'ASCII' less than <other>.)#"  , py::arg("other")
          )
        .def("IsGreater",
             (bool (TCollection_HAsciiString::*)(  const handle<TCollection_HAsciiString> &  ) const) static_cast<bool (TCollection_HAsciiString::*)(  const handle<TCollection_HAsciiString> &  ) const>(&TCollection_HAsciiString::IsGreater),
             R"#(Returns TRUE if <me> is 'ASCII' greater than <other>.)#"  , py::arg("other")
          )
        .def("IntegerValue",
             (int (TCollection_HAsciiString::*)() const) static_cast<int (TCollection_HAsciiString::*)() const>(&TCollection_HAsciiString::IntegerValue),
             R"#(Converts a HAsciiString containing a numeric expression to an Integer. Example: "215" returns 215.)#" 
          )
        .def("IsIntegerValue",
             (bool (TCollection_HAsciiString::*)() const) static_cast<bool (TCollection_HAsciiString::*)() const>(&TCollection_HAsciiString::IsIntegerValue),
             R"#(Returns True if the string contains an integer value.)#" 
          )
        .def("IsRealValue",
             (bool (TCollection_HAsciiString::*)() const) static_cast<bool (TCollection_HAsciiString::*)() const>(&TCollection_HAsciiString::IsRealValue),
             R"#(Returns True if the string contains a real value.)#" 
          )
        .def("IsAscii",
             (bool (TCollection_HAsciiString::*)() const) static_cast<bool (TCollection_HAsciiString::*)() const>(&TCollection_HAsciiString::IsAscii),
             R"#(Returns True if the string contains only ASCII characters between ' ' and '~'. This means no control character and no extended ASCII code.)#" 
          )
        .def("IsDifferent",
             (bool (TCollection_HAsciiString::*)(  const handle<TCollection_HAsciiString> &  ) const) static_cast<bool (TCollection_HAsciiString::*)(  const handle<TCollection_HAsciiString> &  ) const>(&TCollection_HAsciiString::IsDifferent),
             R"#(Returns True if the string S not contains same characters than the string <me>.)#"  , py::arg("S")
          )
        .def("IsSameString",
             (bool (TCollection_HAsciiString::*)(  const handle<TCollection_HAsciiString> &  ) const) static_cast<bool (TCollection_HAsciiString::*)(  const handle<TCollection_HAsciiString> &  ) const>(&TCollection_HAsciiString::IsSameString),
             R"#(Returns True if the string S contains same characters than the string <me>.)#"  , py::arg("S")
          )
        .def("IsSameString",
             (bool (TCollection_HAsciiString::*)(  const handle<TCollection_HAsciiString> & ,   const bool  ) const) static_cast<bool (TCollection_HAsciiString::*)(  const handle<TCollection_HAsciiString> & ,   const bool  ) const>(&TCollection_HAsciiString::IsSameString),
             R"#(Returns True if the string S contains same characters than the string <me>.)#"  , py::arg("S"),  py::arg("CaseSensitive")
          )
        .def("LeftAdjust",
             (void (TCollection_HAsciiString::*)() ) static_cast<void (TCollection_HAsciiString::*)() >(&TCollection_HAsciiString::LeftAdjust),
             R"#(Removes all space characters in the beginning of the string)#" 
          )
        .def("LeftJustify",
             (void (TCollection_HAsciiString::*)(  const int ,   const char  ) ) static_cast<void (TCollection_HAsciiString::*)(  const int ,   const char  ) >(&TCollection_HAsciiString::LeftJustify),
             R"#(Left justify. Length becomes equal to Width and the new characters are equal to Filler if Width < Length nothing happens Raises an exception if Width is less than zero Example: before me = "abcdef" , Width = 9 , Filler = ' ' after me = "abcdef ")#"  , py::arg("Width"),  py::arg("Filler")
          )
        .def("Length",
             (int (TCollection_HAsciiString::*)() const) static_cast<int (TCollection_HAsciiString::*)() const>(&TCollection_HAsciiString::Length),
             R"#(Returns number of characters in <me>. This is the same functionality as 'strlen' in C.)#" 
          )
        .def("Location",
             (int (TCollection_HAsciiString::*)(  const handle<TCollection_HAsciiString> & ,   const int ,   const int  ) const) static_cast<int (TCollection_HAsciiString::*)(  const handle<TCollection_HAsciiString> & ,   const int ,   const int  ) const>(&TCollection_HAsciiString::Location),
             R"#(returns an index in the string <me> of the first occurrence of the string S in the string <me> from the starting index FromIndex to the ending index ToIndex returns zero if failure Raises an exception if FromIndex or ToIndex is out of range. Example: before me = "aabAaAa", S = "Aa", FromIndex = 1, ToIndex = 7 after me = "aabAaAa" returns 4)#"  , py::arg("other"),  py::arg("FromIndex"),  py::arg("ToIndex")
          )
        .def("Location",
             (int (TCollection_HAsciiString::*)(  const int ,   const char ,   const int ,   const int  ) const) static_cast<int (TCollection_HAsciiString::*)(  const int ,   const char ,   const int ,   const int  ) const>(&TCollection_HAsciiString::Location),
             R"#(Returns the index of the nth occurrence of the character C in the string <me> from the starting index FromIndex to the ending index ToIndex. Returns zero if failure. Raises an exception if FromIndex or ToIndex is out of range Example: before me = "aabAa", N = 3, C = 'a', FromIndex = 1, ToIndex = 5 after me = "aabAa" returns 5)#"  , py::arg("N"),  py::arg("C"),  py::arg("FromIndex"),  py::arg("ToIndex")
          )
        .def("LowerCase",
             (void (TCollection_HAsciiString::*)() ) static_cast<void (TCollection_HAsciiString::*)() >(&TCollection_HAsciiString::LowerCase),
             R"#(Converts <me> to its lower-case equivalent.)#" 
          )
        .def("Prepend",
             (void (TCollection_HAsciiString::*)(  const handle<TCollection_HAsciiString> &  ) ) static_cast<void (TCollection_HAsciiString::*)(  const handle<TCollection_HAsciiString> &  ) >(&TCollection_HAsciiString::Prepend),
             R"#(Inserts the other string at the beginning of the string <me> Example: before me = "cde" , S = "ab" after me = "abcde" , S = "ab")#"  , py::arg("other")
          )
        .def("Print",
             (void (TCollection_HAsciiString::*)( Standard_OStream &  ) const) static_cast<void (TCollection_HAsciiString::*)( Standard_OStream &  ) const>(&TCollection_HAsciiString::Print),
             R"#(Prints this string on the stream <astream>.)#"  , py::arg("astream")
          )
        .def("RealValue",
             (double (TCollection_HAsciiString::*)() const) static_cast<double (TCollection_HAsciiString::*)() const>(&TCollection_HAsciiString::RealValue),
             R"#(Converts a string containing a numeric expression to a Real. Example: "215" returns 215.0. "3.14159267" returns 3.14159267.)#" 
          )
        .def("RemoveAll",
             (void (TCollection_HAsciiString::*)(  const char ,   const bool  ) ) static_cast<void (TCollection_HAsciiString::*)(  const char ,   const bool  ) >(&TCollection_HAsciiString::RemoveAll),
             R"#(Remove all the occurrences of the character C in the string Example: before me = "HellLLo", C = 'L' , CaseSensitive = True after me = "Hello")#"  , py::arg("C"),  py::arg("CaseSensitive")
          )
        .def("RemoveAll",
             (void (TCollection_HAsciiString::*)(  const char  ) ) static_cast<void (TCollection_HAsciiString::*)(  const char  ) >(&TCollection_HAsciiString::RemoveAll),
             R"#(Removes every <what> characters from <me>)#"  , py::arg("what")
          )
        .def("Remove",
             (void (TCollection_HAsciiString::*)(  const int ,   const int  ) ) static_cast<void (TCollection_HAsciiString::*)(  const int ,   const int  ) >(&TCollection_HAsciiString::Remove),
             R"#(Erases <ahowmany> characters from position <where>, <where> included. Example: aString contains "Hello" aString.Erase(2,2) erases 2 characters from position 1 This gives "Hlo".)#"  , py::arg("where"),  py::arg("ahowmany")=static_cast< const int>(1)
          )
        .def("RightAdjust",
             (void (TCollection_HAsciiString::*)() ) static_cast<void (TCollection_HAsciiString::*)() >(&TCollection_HAsciiString::RightAdjust),
             R"#(Removes all space characters at the end of the string.)#" 
          )
        .def("RightJustify",
             (void (TCollection_HAsciiString::*)(  const int ,   const char  ) ) static_cast<void (TCollection_HAsciiString::*)(  const int ,   const char  ) >(&TCollection_HAsciiString::RightJustify),
             R"#(Right justify. Length becomes equal to Width and the new characters are equal to Filler if Width < Length nothing happens Raises an exception if Width is less than zero Example: before me = "abcdef" , Width = 9 , Filler = ' ' after me = " abcdef")#"  , py::arg("Width"),  py::arg("Filler")
          )
        .def("Search",
             (int (TCollection_HAsciiString::*)(  const char * const   ) const) static_cast<int (TCollection_HAsciiString::*)(  const char * const   ) const>(&TCollection_HAsciiString::Search),
             R"#(Searches a CString in <me> from the beginning and returns position of first item <what> matching. It returns -1 if not found. Example: aString contains "Sample single test" aString.Search("le") returns 5)#"  , py::arg("what")
          )
        .def("Search",
             (int (TCollection_HAsciiString::*)(  const handle<TCollection_HAsciiString> &  ) const) static_cast<int (TCollection_HAsciiString::*)(  const handle<TCollection_HAsciiString> &  ) const>(&TCollection_HAsciiString::Search),
             R"#(Searches a String in <me> from the beginning and returns position of first item <what> matching. it returns -1 if not found.)#"  , py::arg("what")
          )
        .def("SearchFromEnd",
             (int (TCollection_HAsciiString::*)(  const char * const   ) const) static_cast<int (TCollection_HAsciiString::*)(  const char * const   ) const>(&TCollection_HAsciiString::SearchFromEnd),
             R"#(Searches a CString in a String from the end and returns position of first item <what> matching. It returns -1 if not found. Example: aString contains "Sample single test" aString.SearchFromEnd("le") returns 12)#"  , py::arg("what")
          )
        .def("SearchFromEnd",
             (int (TCollection_HAsciiString::*)(  const handle<TCollection_HAsciiString> &  ) const) static_cast<int (TCollection_HAsciiString::*)(  const handle<TCollection_HAsciiString> &  ) const>(&TCollection_HAsciiString::SearchFromEnd),
             R"#(Searches a HAsciiString in another HAsciiString from the end and returns position of first item <what> matching. It returns -1 if not found.)#"  , py::arg("what")
          )
        .def("SetValue",
             (void (TCollection_HAsciiString::*)(  const int ,   const char  ) ) static_cast<void (TCollection_HAsciiString::*)(  const int ,   const char  ) >(&TCollection_HAsciiString::SetValue),
             R"#(Replaces one character in the string at position <where>. If <where> is less than zero or greater than the length of <me> an exception is raised. Example: aString contains "Garbake" astring.Replace(6,'g') gives <me> = "Garbage")#"  , py::arg("where"),  py::arg("what")
          )
        .def("SetValue",
             (void (TCollection_HAsciiString::*)(  const int ,   const char * const   ) ) static_cast<void (TCollection_HAsciiString::*)(  const int ,   const char * const   ) >(&TCollection_HAsciiString::SetValue),
             R"#(Replaces a part of <me> in the string at position <where>. If <where> is less than zero or greater than the length of <me> an exception is raised. Example: aString contains "Garbake" astring.Replace(6,'g') gives <me> = "Garbage")#"  , py::arg("where"),  py::arg("what")
          )
        .def("SetValue",
             (void (TCollection_HAsciiString::*)(  const int ,   const handle<TCollection_HAsciiString> &  ) ) static_cast<void (TCollection_HAsciiString::*)(  const int ,   const handle<TCollection_HAsciiString> &  ) >(&TCollection_HAsciiString::SetValue),
             R"#(Replaces a part of <me> by another string.)#"  , py::arg("where"),  py::arg("what")
          )
        .def("Split",
             (handle<TCollection_HAsciiString> (TCollection_HAsciiString::*)(  const int  ) ) static_cast<handle<TCollection_HAsciiString> (TCollection_HAsciiString::*)(  const int  ) >(&TCollection_HAsciiString::Split),
             R"#(Splits a HAsciiString into two sub-strings. Example: aString contains "abcdefg" aString.Split(3) gives <me> = "abc" and returns "defg")#"  , py::arg("where")
          )
        .def("SubString",
             (handle<TCollection_HAsciiString> (TCollection_HAsciiString::*)(  const int ,   const int  ) const) static_cast<handle<TCollection_HAsciiString> (TCollection_HAsciiString::*)(  const int ,   const int  ) const>(&TCollection_HAsciiString::SubString),
             R"#(Creation of a sub-string of the string <me>. The sub-string starts to the index Fromindex and ends to the index ToIndex. Raises an exception if ToIndex or FromIndex is out of bounds Example: before me = "abcdefg", ToIndex=3, FromIndex=6 after me = "abcdefg" returns "cdef")#"  , py::arg("FromIndex"),  py::arg("ToIndex")
          )
        .def("ToCString",
             ( const char * (TCollection_HAsciiString::*)() const) static_cast< const char * (TCollection_HAsciiString::*)() const>(&TCollection_HAsciiString::ToCString),
             R"#(Returns pointer to string (char *) This is useful for some casual manipulations Because this "char *" is 'const', you can't modify its contents.)#" 
          )
        .def("Token",
             (handle<TCollection_HAsciiString> (TCollection_HAsciiString::*)(  const char * const  ,   const int  ) const) static_cast<handle<TCollection_HAsciiString> (TCollection_HAsciiString::*)(  const char * const  ,   const int  ) const>(&TCollection_HAsciiString::Token),
             R"#(Extracts <whichone> token from <me>. By default, the <separators> is set to space and tabulation. By default, the token extracted is the first one (whichone = 1). <separators> contains all separators you need. If no token indexed by <whichone> is found, it returns an empty String. Example: aString contains "This is a message" aString.Token() returns "This" aString.Token(" ",4) returns "message" aString.Token(" ",2) returns "is" aString.Token(" ",9) returns "" Other separators than space character and tabulation are allowed aString contains "1234; test:message , value" aString.Token("; :,",4) returns "value" aString.Token("; :,",2) returns "test")#"  , py::arg("separators")=static_cast< const char * const >(" \t"),  py::arg("whichone")=static_cast< const int>(1)
          )
        .def("Trunc",
             (void (TCollection_HAsciiString::*)(  const int  ) ) static_cast<void (TCollection_HAsciiString::*)(  const int  ) >(&TCollection_HAsciiString::Trunc),
             R"#(Truncates <me> to <ahowmany> characters. Example: me = "Hello Dolly" -> Trunc(3) -> me = "Hel")#"  , py::arg("ahowmany")
          )
        .def("UpperCase",
             (void (TCollection_HAsciiString::*)() ) static_cast<void (TCollection_HAsciiString::*)() >(&TCollection_HAsciiString::UpperCase),
             R"#(Converts <me> to its upper-case equivalent.)#" 
          )
        .def("UsefullLength",
             (int (TCollection_HAsciiString::*)() const) static_cast<int (TCollection_HAsciiString::*)() const>(&TCollection_HAsciiString::UsefullLength),
             R"#(Length of the string ignoring all spaces (' ') and the control character at the end.)#" 
          )
        .def("Value",
             (char (TCollection_HAsciiString::*)(  const int  ) const) static_cast<char (TCollection_HAsciiString::*)(  const int  ) const>(&TCollection_HAsciiString::Value),
             R"#(Returns character at position <where> in <me>. If <where> is less than zero or greater than the length of <me>, an exception is raised. Example: aString contains "Hello" aString.Value(2) returns 'e')#"  , py::arg("where")
          )
        .def("IsSameState",
             (bool (TCollection_HAsciiString::*)(  const handle<TCollection_HAsciiString> &  ) const) static_cast<bool (TCollection_HAsciiString::*)(  const handle<TCollection_HAsciiString> &  ) const>(&TCollection_HAsciiString::IsSameState),
             R"#()#"  , py::arg("other")
          )
        .def("AssignCat",
             (void (TCollection_HAsciiString::*)(  const char * const   ) ) static_cast<void (TCollection_HAsciiString::*)(  const char * const   ) >(&TCollection_HAsciiString::AssignCat),
             R"#(Appends <other> to me.)#"  , py::arg("other")
          )
        .def("AssignCat",
             (void (TCollection_HAsciiString::*)(  const handle<TCollection_HAsciiString> &  ) ) static_cast<void (TCollection_HAsciiString::*)(  const handle<TCollection_HAsciiString> &  ) >(&TCollection_HAsciiString::AssignCat),
             R"#(Appends <other> to me. Example: aString = aString + anotherString)#"  , py::arg("other")
          )
        .def("Length",
             (int (TCollection_HAsciiString::*)() const) static_cast<int (TCollection_HAsciiString::*)() const>(&TCollection_HAsciiString::Length),
             R"#(Returns number of characters in <me>. This is the same functionality as 'strlen' in C.)#" 
          )
        .def("ToCString",
             ( const char * (TCollection_HAsciiString::*)() const) static_cast< const char * (TCollection_HAsciiString::*)() const>(&TCollection_HAsciiString::ToCString),
             R"#(Returns pointer to string (char *) This is useful for some casual manipulations Because this "char *" is 'const', you can't modify its contents.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TCollection_HAsciiString::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TCollection_HAsciiString::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("String",
             ( const TCollection_AsciiString & (TCollection_HAsciiString::*)() const) static_cast< const TCollection_AsciiString & (TCollection_HAsciiString::*)() const>(&TCollection_HAsciiString::String),
             R"#(Returns the field myString.)#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TCollection_HAsciiString::*)() const) static_cast< const handle<Standard_Type> & (TCollection_HAsciiString::*)() const>(&TCollection_HAsciiString::DynamicType),
             R"#()#"
             
         )
       .def("String",
             ( const TCollection_AsciiString & (TCollection_HAsciiString::*)() const) static_cast< const TCollection_AsciiString & (TCollection_HAsciiString::*)() const>(&TCollection_HAsciiString::String),
             R"#(Returns the field myString.)#"
             
         )
;

    // Class TCollection_HExtendedString from ./opencascade/TCollection_HExtendedString.hxx
    klass = m.attr("TCollection_HExtendedString");


    // nested enums

    static_cast<py::class_<TCollection_HExtendedString ,opencascade::handle<TCollection_HExtendedString>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const TCollection_ExtendedString & >()  , py::arg("aString") )
        .def(py::init<  const char * const  >()  , py::arg("message") )
        .def(py::init<  const char16_t * const  >()  , py::arg("message") )
        .def(py::init<  const char16_t >()  , py::arg("aChar") )
        .def(py::init<  const int, const char16_t >()  , py::arg("length"),  py::arg("filler") )
        .def(py::init<  const handle<TCollection_HAsciiString> & >()  , py::arg("aString") )
        .def(py::init<  const handle<TCollection_HExtendedString> & >()  , py::arg("aString") )
    // custom constructors
    // methods
        .def("AssignCat",
             (void (TCollection_HExtendedString::*)(  const handle<TCollection_HExtendedString> &  ) ) static_cast<void (TCollection_HExtendedString::*)(  const handle<TCollection_HExtendedString> &  ) >(&TCollection_HExtendedString::AssignCat),
             R"#(Appends <other> to me.)#"  , py::arg("other")
          )
        .def("Cat",
             (handle<TCollection_HExtendedString> (TCollection_HExtendedString::*)(  const handle<TCollection_HExtendedString> &  ) const) static_cast<handle<TCollection_HExtendedString> (TCollection_HExtendedString::*)(  const handle<TCollection_HExtendedString> &  ) const>(&TCollection_HExtendedString::Cat),
             R"#(Returns a string appending <other> to me.)#"  , py::arg("other")
          )
        .def("ChangeAll",
             (void (TCollection_HExtendedString::*)(  const char16_t ,   const char16_t  ) ) static_cast<void (TCollection_HExtendedString::*)(  const char16_t ,   const char16_t  ) >(&TCollection_HExtendedString::ChangeAll),
             R"#(Substitutes all the characters equal to aChar by NewChar in the string <me>.)#"  , py::arg("aChar"),  py::arg("NewChar")
          )
        .def("Clear",
             (void (TCollection_HExtendedString::*)() ) static_cast<void (TCollection_HExtendedString::*)() >(&TCollection_HExtendedString::Clear),
             R"#(Removes all characters contained in <me>. This produces an empty ExtendedString.)#" 
          )
        .def("IsEmpty",
             (bool (TCollection_HExtendedString::*)() const) static_cast<bool (TCollection_HExtendedString::*)() const>(&TCollection_HExtendedString::IsEmpty),
             R"#(Returns True if the string <me> contains zero character)#" 
          )
        .def("Insert",
             (void (TCollection_HExtendedString::*)(  const int ,   const char16_t  ) ) static_cast<void (TCollection_HExtendedString::*)(  const int ,   const char16_t  ) >(&TCollection_HExtendedString::Insert),
             R"#(Insert a ExtCharacter at position <where>. Example: aString contains "hy not ?" aString.Insert(1,'W'); gives "Why not ?" aString contains "Wh" aString.Insert(3,'y'); gives "Why" aString contains "Way" aString.Insert(2,'h'); gives "Why")#"  , py::arg("where"),  py::arg("what")
          )
        .def("Insert",
             (void (TCollection_HExtendedString::*)(  const int ,   const handle<TCollection_HExtendedString> &  ) ) static_cast<void (TCollection_HExtendedString::*)(  const int ,   const handle<TCollection_HExtendedString> &  ) >(&TCollection_HExtendedString::Insert),
             R"#(Insert a HExtendedString at position <where>.)#"  , py::arg("where"),  py::arg("what")
          )
        .def("IsLess",
             (bool (TCollection_HExtendedString::*)(  const handle<TCollection_HExtendedString> &  ) const) static_cast<bool (TCollection_HExtendedString::*)(  const handle<TCollection_HExtendedString> &  ) const>(&TCollection_HExtendedString::IsLess),
             R"#(Returns TRUE if <me> is less than <other>.)#"  , py::arg("other")
          )
        .def("IsGreater",
             (bool (TCollection_HExtendedString::*)(  const handle<TCollection_HExtendedString> &  ) const) static_cast<bool (TCollection_HExtendedString::*)(  const handle<TCollection_HExtendedString> &  ) const>(&TCollection_HExtendedString::IsGreater),
             R"#(Returns TRUE if <me> is greater than <other>.)#"  , py::arg("other")
          )
        .def("IsAscii",
             (bool (TCollection_HExtendedString::*)() const) static_cast<bool (TCollection_HExtendedString::*)() const>(&TCollection_HExtendedString::IsAscii),
             R"#(Returns True if the string contains only "Ascii Range" characters)#" 
          )
        .def("Length",
             (int (TCollection_HExtendedString::*)() const) static_cast<int (TCollection_HExtendedString::*)() const>(&TCollection_HExtendedString::Length),
             R"#(Returns number of characters in <me>. This is the same functionality as 'strlen' in C.)#" 
          )
        .def("Remove",
             (void (TCollection_HExtendedString::*)(  const int ,   const int  ) ) static_cast<void (TCollection_HExtendedString::*)(  const int ,   const int  ) >(&TCollection_HExtendedString::Remove),
             R"#(Erases <ahowmany> characters from position <where>, <where> included. Example: aString contains "Hello" aString.Erase(2,2) erases 2 characters from position 1 This gives "Hlo".)#"  , py::arg("where"),  py::arg("ahowmany")=static_cast< const int>(1)
          )
        .def("RemoveAll",
             (void (TCollection_HExtendedString::*)(  const char16_t  ) ) static_cast<void (TCollection_HExtendedString::*)(  const char16_t  ) >(&TCollection_HExtendedString::RemoveAll),
             R"#(Removes every <what> characters from <me>.)#"  , py::arg("what")
          )
        .def("SetValue",
             (void (TCollection_HExtendedString::*)(  const int ,   const char16_t  ) ) static_cast<void (TCollection_HExtendedString::*)(  const int ,   const char16_t  ) >(&TCollection_HExtendedString::SetValue),
             R"#(Replaces one character in the string at position <where>. If <where> is less than zero or greater than the length of <me> an exception is raised. Example: aString contains "Garbake" astring.Replace(6,'g') gives <me> = "Garbage")#"  , py::arg("where"),  py::arg("what")
          )
        .def("SetValue",
             (void (TCollection_HExtendedString::*)(  const int ,   const handle<TCollection_HExtendedString> &  ) ) static_cast<void (TCollection_HExtendedString::*)(  const int ,   const handle<TCollection_HExtendedString> &  ) >(&TCollection_HExtendedString::SetValue),
             R"#(Replaces a part of <me> by another string.)#"  , py::arg("where"),  py::arg("what")
          )
        .def("Split",
             (handle<TCollection_HExtendedString> (TCollection_HExtendedString::*)(  const int  ) ) static_cast<handle<TCollection_HExtendedString> (TCollection_HExtendedString::*)(  const int  ) >(&TCollection_HExtendedString::Split),
             R"#(Splits a ExtendedString into two sub-strings. Example: aString contains "abcdefg" aString.Split(3) gives <me> = "abc" and returns "defg")#"  , py::arg("where")
          )
        .def("Search",
             (int (TCollection_HExtendedString::*)(  const handle<TCollection_HExtendedString> &  ) const) static_cast<int (TCollection_HExtendedString::*)(  const handle<TCollection_HExtendedString> &  ) const>(&TCollection_HExtendedString::Search),
             R"#(Searches a String in <me> from the beginning and returns position of first item <what> matching. It returns -1 if not found.)#"  , py::arg("what")
          )
        .def("SearchFromEnd",
             (int (TCollection_HExtendedString::*)(  const handle<TCollection_HExtendedString> &  ) const) static_cast<int (TCollection_HExtendedString::*)(  const handle<TCollection_HExtendedString> &  ) const>(&TCollection_HExtendedString::SearchFromEnd),
             R"#(Searches a ExtendedString in another ExtendedString from the end and returns position of first item <what> matching. It returns -1 if not found.)#"  , py::arg("what")
          )
        .def("ToExtString",
             ( const char16_t * (TCollection_HExtendedString::*)() const) static_cast< const char16_t * (TCollection_HExtendedString::*)() const>(&TCollection_HExtendedString::ToExtString),
             R"#(Returns pointer to ExtString)#" 
          )
        .def("Token",
             (handle<TCollection_HExtendedString> (TCollection_HExtendedString::*)(  const char16_t * const  ,   const int  ) const) static_cast<handle<TCollection_HExtendedString> (TCollection_HExtendedString::*)(  const char16_t * const  ,   const int  ) const>(&TCollection_HExtendedString::Token),
             R"#(Extracts <whichone> token from <me>. By default, the <separators> is set to space and tabulation. By default, the token extracted is the first one (whichone = 1). <separators> contains all separators you need. If no token indexed by <whichone> is found, it returns an empty String. Example: aString contains "This is a message" aString.Token() returns "This" aString.Token(" ",4) returns "message" aString.Token(" ",2) returns "is" aString.Token(" ",9) returns "" Other separators than space character and tabulation are allowed aString contains "1234; test:message , value" aString.Token("; :,",4) returns "value" aString.Token("; :,",2) returns "test")#"  , py::arg("separators"),  py::arg("whichone")=static_cast< const int>(1)
          )
        .def("Trunc",
             (void (TCollection_HExtendedString::*)(  const int  ) ) static_cast<void (TCollection_HExtendedString::*)(  const int  ) >(&TCollection_HExtendedString::Trunc),
             R"#(Truncates <me> to <ahowmany> characters. Example: me = "Hello Dolly" -> Trunc(3) -> me = "Hel")#"  , py::arg("ahowmany")
          )
        .def("Value",
             (char16_t (TCollection_HExtendedString::*)(  const int  ) const) static_cast<char16_t (TCollection_HExtendedString::*)(  const int  ) const>(&TCollection_HExtendedString::Value),
             R"#(Returns ExtCharacter at position <where> in <me>. If <where> is less than zero or greater than the length of <me>, an exception is raised. Example: aString contains "Hello" aString.Value(2) returns 'e')#"  , py::arg("where")
          )
        .def("Print",
             (void (TCollection_HExtendedString::*)( Standard_OStream &  ) const) static_cast<void (TCollection_HExtendedString::*)( Standard_OStream &  ) const>(&TCollection_HExtendedString::Print),
             R"#(Displays <me>.)#"  , py::arg("astream")
          )
        .def("IsSameState",
             (bool (TCollection_HExtendedString::*)(  const handle<TCollection_HExtendedString> &  ) const) static_cast<bool (TCollection_HExtendedString::*)(  const handle<TCollection_HExtendedString> &  ) const>(&TCollection_HExtendedString::IsSameState),
             R"#()#"  , py::arg("other")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TCollection_HExtendedString::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TCollection_HExtendedString::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("String",
             ( const TCollection_ExtendedString & (TCollection_HExtendedString::*)() const) static_cast< const TCollection_ExtendedString & (TCollection_HExtendedString::*)() const>(&TCollection_HExtendedString::String),
             R"#(Returns the field myString)#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TCollection_HExtendedString::*)() const) static_cast< const handle<Standard_Type> & (TCollection_HExtendedString::*)() const>(&TCollection_HExtendedString::DynamicType),
             R"#()#"
             
         )
;

// functions

// ./opencascade/TCollection.hxx
// ./opencascade/TCollection_AsciiString.hxx
    m.def("IsEqual",
          (bool (*)(  const TCollection_AsciiString & ,   const TCollection_AsciiString &  ))  static_cast<bool (*)(  const TCollection_AsciiString & ,   const TCollection_AsciiString &  )>(&IsEqual),
          R"#(Returns True when the two strings are the same.)#"  , py::arg("theString1"),  py::arg("theString2")
          );
// ./opencascade/TCollection_ExtendedString.hxx
// ./opencascade/TCollection_HAsciiString.hxx
// ./opencascade/TCollection_HExtendedString.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body
py::implicitly_convertible<std::string, TCollection_HAsciiString>();
py::implicitly_convertible<std::string, TCollection_AsciiString>();

};

// user-defined post-inclusion per module

// user-defined post
