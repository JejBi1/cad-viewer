#pragma once

#include <initializer_list>
using std::initializer_list;

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_Aspects.hxx>
#include <OpenGl_Context.hxx>
#include <OpenGl_ShaderProgram.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_Context.hxx>
#include <OpenGl_PointSprite.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_Context.hxx>
#include <OpenGl_TextureSet.hxx>
#include <OpenGl_PointSprite.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_Structure.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_ClippingIterator.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_GlFunctions.hxx>
#include <OpenGl_ArbTBO.hxx>
#include <OpenGl_ArbIns.hxx>
#include <OpenGl_ArbDbg.hxx>
#include <OpenGl_ArbFBO.hxx>
#include <OpenGl_ArbFBO.hxx>
#include <OpenGl_ArbSamplerObject.hxx>
#include <OpenGl_ArbTexBindless.hxx>
#include <OpenGl_ExtGS.hxx>
#include <OpenGl_GlCore11Fwd.hxx>
#include <OpenGl_GlCore11.hxx>
#include <OpenGl_GlCore12.hxx>
#include <OpenGl_GlCore13.hxx>
#include <OpenGl_GlCore14.hxx>
#include <OpenGl_GlCore15.hxx>
#include <OpenGl_GlCore20.hxx>
#include <OpenGl_GlCore21.hxx>
#include <OpenGl_GlCore30.hxx>
#include <OpenGl_GlCore31.hxx>
#include <OpenGl_GlCore32.hxx>
#include <OpenGl_GlCore33.hxx>
#include <OpenGl_GlCore40.hxx>
#include <OpenGl_GlCore41.hxx>
#include <OpenGl_GlCore42.hxx>
#include <OpenGl_GlCore43.hxx>
#include <OpenGl_GlCore44.hxx>
#include <OpenGl_GlCore45.hxx>
#include <OpenGl_GlCore46.hxx>
#include <Graphic3d_Camera.hxx>
#include <Graphic3d_PresentationAttributes.hxx>
#include <OpenGl_Aspects.hxx>
#include <OpenGl_FrameBuffer.hxx>
#include <OpenGl_ShaderProgram.hxx>
#include <OpenGl_ShaderManager.hxx>
#include <OpenGl_FrameStats.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_FrameStatsData.hxx>
#include <OpenGl_Workspace.hxx>
#include <OpenGl_Context.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Ax2.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Font_FTFont.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Image_PixMap.hxx>
#include <OpenGl_Texture.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_CStructure.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_ArrayOfTriangles.hxx>
#include <OpenGl_IndexBuffer.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_Context.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_Structure.hxx>
#include <OpenGl_View.hxx>
#include <OpenGl_Window.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_Structure.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_Structure.hxx>
#include <OpenGl_Workspace.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_Context.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_Context.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_IndexBuffer.hxx>
#include <OpenGl_VertexBuffer.hxx>
#include <OpenGl_GraphicDriver.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_Context.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_Texture.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_Element.hxx>
#include <OpenGl_Group.hxx>
#include <OpenGl_Group.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_ShaderProgram.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_ShadowMap.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_XYZ.hxx>
#include <Graphic3d_Camera.hxx>
#include <Graphic3d_CLight.hxx>
#include <Graphic3d_CView.hxx>
#include <OpenGl_FrameBuffer.hxx>
#include <OpenGl_Texture.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Font_TextFormatter.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_Context.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_Texture.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_RenderingParams.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_BackgroundArray.hxx>
#include <OpenGl_DepthPeeling.hxx>
#include <OpenGl_PBREnvironment.hxx>
#include <OpenGl_ShadowMap.hxx>
#include <OpenGl_ShadowMap.hxx>
#include <OpenGl_TextureBuffer.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_Context.hxx>
#include <OpenGl_GraphicDriver.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_FrameBuffer.hxx>
#include <OpenGl_Group.hxx>
#include <OpenGl_View.hxx>
#include <OpenGl_Window.hxx>

// module includes
#include <OpenGl_ArbDbg.hxx>
#include <OpenGl_ArbFBO.hxx>
#include <OpenGl_ArbIns.hxx>
#include <OpenGl_ArbSamplerObject.hxx>
#include <OpenGl_ArbTBO.hxx>
#include <OpenGl_ArbTexBindless.hxx>
#include <OpenGl_Aspects.hxx>
#include <OpenGl_AspectsProgram.hxx>
#include <OpenGl_AspectsSprite.hxx>
#include <OpenGl_AspectsTextureSet.hxx>
#include <OpenGl_BackgroundArray.hxx>
#include <OpenGl_Buffer.hxx>
#include <OpenGl_BufferCompatT.hxx>
#include <OpenGl_CappingAlgo.hxx>
#include <OpenGl_CappingPlaneResource.hxx>
#include <OpenGl_Caps.hxx>
#include <OpenGl_Clipping.hxx>
#include <OpenGl_ClippingIterator.hxx>
#include <OpenGl_Context.hxx>
#include <OpenGl_DepthPeeling.hxx>
#include <OpenGl_Element.hxx>
#include <OpenGl_ExtGS.hxx>
#include <OpenGl_Flipper.hxx>
#include <OpenGl_Font.hxx>
#include <OpenGl_FrameBuffer.hxx>
#include <OpenGl_FrameStats.hxx>
#include <OpenGl_FrameStatsPrs.hxx>
#include <OpenGl_GlCore11.hxx>
#include <OpenGl_GlCore11Fwd.hxx>
#include <OpenGl_GlCore12.hxx>
#include <OpenGl_GlCore13.hxx>
#include <OpenGl_GlCore14.hxx>
#include <OpenGl_GlCore15.hxx>
#include <OpenGl_GlCore20.hxx>
#include <OpenGl_GlCore21.hxx>
#include <OpenGl_GlCore30.hxx>
#include <OpenGl_GlCore31.hxx>
#include <OpenGl_GlCore32.hxx>
#include <OpenGl_GlCore33.hxx>
#include <OpenGl_GlCore40.hxx>
#include <OpenGl_GlCore41.hxx>
#include <OpenGl_GlCore42.hxx>
#include <OpenGl_GlCore43.hxx>
#include <OpenGl_GlCore44.hxx>
#include <OpenGl_GlCore45.hxx>
#include <OpenGl_GlCore46.hxx>
#include <OpenGl_GlFunctions.hxx>
#include <OpenGl_GlNative.hxx>
#include <OpenGl_GlTypes.hxx>
#include <OpenGl_GraduatedTrihedron.hxx>
#include <OpenGl_GraphicDriver.hxx>
#include <OpenGl_GraphicDriverFactory.hxx>
#include <OpenGl_Group.hxx>
#include <OpenGl_HaltonSampler.hxx>
#include <OpenGl_IndexBuffer.hxx>
#include <OpenGl_Layer.hxx>
#include <OpenGl_LayerFilter.hxx>
#include <OpenGl_LayerList.hxx>
#include <OpenGl_LineAttributes.hxx>
#include <OpenGl_Material.hxx>
#include <OpenGl_MaterialState.hxx>
#include <OpenGl_MatrixState.hxx>
#include <OpenGl_NamedResource.hxx>
#include <OpenGl_PBREnvironment.hxx>
#include <OpenGl_PointSprite.hxx>
#include <OpenGl_PrimitiveArray.hxx>
#include <OpenGl_RenderFilter.hxx>
#include <OpenGl_Resource.hxx>
#include <OpenGl_Sampler.hxx>
#include <OpenGl_SceneGeometry.hxx>
#include <OpenGl_SetOfShaderPrograms.hxx>
#include <OpenGl_ShaderGrid.hxx>
#include <OpenGl_ShaderManager.hxx>
#include <OpenGl_ShaderObject.hxx>
#include <OpenGl_ShaderProgram.hxx>
#include <OpenGl_ShaderProgramDumpLevel.hxx>
#include <OpenGl_ShaderStates.hxx>
#include <OpenGl_ShadowMap.hxx>
#include <OpenGl_StencilTest.hxx>
#include <OpenGl_Structure.hxx>
#include <OpenGl_StructureShadow.hxx>
#include <OpenGl_Text.hxx>
#include <OpenGl_TextBuilder.hxx>
#include <OpenGl_Texture.hxx>
#include <OpenGl_TextureBuffer.hxx>
#include <OpenGl_TextureFormat.hxx>
#include <OpenGl_TextureSet.hxx>
#include <OpenGl_TextureSetPairIterator.hxx>
#include <OpenGl_TileSampler.hxx>
#include <OpenGl_UniformBuffer.hxx>
#include <OpenGl_Vec.hxx>
#include <OpenGl_VertexBuffer.hxx>
#include <OpenGl_VertexBufferCompat.hxx>
#include <OpenGl_VertexBufferEditor.hxx>
#include <OpenGl_View.hxx>
#include <OpenGl_Window.hxx>
#include <OpenGl_Workspace.hxx>

// user-defined pre
#include "OCP_specific.inc"

// Class template handling functions

template <typename T>
void preregister_template_OpenGl_VariableSetter(py::object &m, const char *name){
    py::class_<OpenGl_VariableSetter<T> , shared_ptr<OpenGl_VariableSetter<T>> >(m,name,R"#()#");
}

template <typename T>
void register_template_OpenGl_VariableSetter(py::object &m, const char *name){
    static_cast<py::class_<OpenGl_VariableSetter<T> , shared_ptr<OpenGl_VariableSetter<T>> >>(m.attr(name))
        .def("Set",
             (void (OpenGl_VariableSetter<T>::*)(  const handle<OpenGl_Context> & ,   const handle<Graphic3d_ShaderVariable> & ,  OpenGl_ShaderProgram *  ) ) &OpenGl_VariableSetter<T>::Set,
             R"#()#" ,py::arg("theCtx"), py::arg("theVariable"), py::arg("theProgram"))
    ;
};

template <typename theVec_t>
void preregister_template_OpenGl_VertexBufferEditor(py::object &m, const char *name){
    py::class_<OpenGl_VertexBufferEditor<theVec_t> , shared_ptr<OpenGl_VertexBufferEditor<theVec_t>> >(m,name,R"#(Auxiliary class to iteratively modify data of existing VBO. It provides iteration interface with delayed CPU->GPU memory transfer to avoid slow per-element data transfer. User should explicitly call Flush() method to ensure that all data is transferred to VBO. Temporary buffer on CPU side can be initialized with lesser capacity than VBO to allow re-usage of shared buffer with fixed size between VBOs.)#");
}

template <typename theVec_t>
void register_template_OpenGl_VertexBufferEditor(py::object &m, const char *name){
    static_cast<py::class_<OpenGl_VertexBufferEditor<theVec_t> , shared_ptr<OpenGl_VertexBufferEditor<theVec_t>> >>(m.attr(name))
        .def(py::init<  const int >() ,py::arg("theTmpBufferLength")=static_cast< const int>(0) )
        .def(py::init< theVec_t *, const int >() ,py::arg("theTmpBuffer"), py::arg("theTmpBufferLength") )
        .def("Init",
             (bool (OpenGl_VertexBufferEditor<theVec_t>::*)(  const handle<OpenGl_Context> & ,   const handle<OpenGl_Buffer> &  ) ) &OpenGl_VertexBufferEditor<theVec_t>::Init,
             R"#(Initialize editor for specified buffer object. theGlCtx[in] bound OpenGL context to edit buffer object theVbo[in] buffer to edit)#" ,py::arg("theGlCtx"), py::arg("theVbo"))
        .def("Value",
             (theVec_t & (OpenGl_VertexBufferEditor<theVec_t>::*)() ) &OpenGl_VertexBufferEditor<theVec_t>::Value,
             R"#(Modify current element in VBO.)#" )
        .def("Next",
             (bool (OpenGl_VertexBufferEditor<theVec_t>::*)() ) &OpenGl_VertexBufferEditor<theVec_t>::Next,
             R"#(Move to the next position in VBO.)#" )
        .def("Flush",
             (bool (OpenGl_VertexBufferEditor<theVec_t>::*)() ) &OpenGl_VertexBufferEditor<theVec_t>::Flush,
             R"#(Push current data from local buffer to VBO.)#" )
        .def("GetVBO",
             ( const handle<OpenGl_Buffer> & (OpenGl_VertexBufferEditor<theVec_t>::*)() const) &OpenGl_VertexBufferEditor<theVec_t>::GetVBO,
             R"#(Returns assigned VBO)#" )
    ;
};

template <typename BaseBufferT>
void preregister_template_OpenGl_BufferCompatT(py::object &m, const char *name){
    py::class_<OpenGl_BufferCompatT<BaseBufferT> , shared_ptr<OpenGl_BufferCompatT<BaseBufferT>> >(m,name,R"#(Compatibility layer for old OpenGL without VBO. Make sure to pass pointer from GetDataOffset() instead of NULL. Method GetDataOffset() returns pointer to real data in this class (while base class OpenGl_VertexBuffer always return NULL).)#");
}

template <typename BaseBufferT>
void register_template_OpenGl_BufferCompatT(py::object &m, const char *name){
    static_cast<py::class_<OpenGl_BufferCompatT<BaseBufferT> , shared_ptr<OpenGl_BufferCompatT<BaseBufferT>> >>(m.attr(name))
        .def(py::init<  >()  )
        .def("IsVirtual",
             (bool (OpenGl_BufferCompatT<BaseBufferT>::*)() const) &OpenGl_BufferCompatT<BaseBufferT>::IsVirtual,
             R"#(Return TRUE.)#" )
        .def("Create",
             (bool (OpenGl_BufferCompatT<BaseBufferT>::*)(  const handle<OpenGl_Context> &  ) ) &OpenGl_BufferCompatT<BaseBufferT>::Create,
             R"#(Creates VBO name (id) if not yet generated. Data should be initialized by another method.)#" ,py::arg("theGlCtx"))
        .def("Release",
             (void (OpenGl_BufferCompatT<BaseBufferT>::*)( OpenGl_Context *  ) ) &OpenGl_BufferCompatT<BaseBufferT>::Release,
             R"#(Destroy object - will release memory if any.)#" ,py::arg("theGlCtx"))
        .def("Bind",
             (void (OpenGl_BufferCompatT<BaseBufferT>::*)(  const handle<OpenGl_Context> &  ) const) &OpenGl_BufferCompatT<BaseBufferT>::Bind,
             R"#(Bind this VBO.)#" ,py::arg("arg0"))
        .def("Unbind",
             (void (OpenGl_BufferCompatT<BaseBufferT>::*)(  const handle<OpenGl_Context> &  ) const) &OpenGl_BufferCompatT<BaseBufferT>::Unbind,
             R"#(Unbind this VBO.)#" ,py::arg("arg0"))
        .def("initLink",
             (bool (OpenGl_BufferCompatT<BaseBufferT>::*)(  const handle<NCollection_Buffer> & ,   const unsigned int ,   const int ,   const unsigned int  ) ) &OpenGl_BufferCompatT<BaseBufferT>::initLink,
             R"#(Initialize buffer with existing data. Data will NOT be copied by this method!)#" ,py::arg("theData"), py::arg("theComponentsNb"), py::arg("theElemsNb"), py::arg("theDataType"))
        .def("init",
             (bool (OpenGl_BufferCompatT<BaseBufferT>::*)(  const handle<OpenGl_Context> & ,   const unsigned int ,   const int ,   const void * ,   const unsigned int ,   const int  ) ) &OpenGl_BufferCompatT<BaseBufferT>::init,
             R"#(Initialize buffer with new data (data will be copied).)#" ,py::arg("theGlCtx"), py::arg("theComponentsNb"), py::arg("theElemsNb"), py::arg("theData"), py::arg("theDataType"), py::arg("theStride"))
        .def("subData",
             (bool (OpenGl_BufferCompatT<BaseBufferT>::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,   const void * ,   const unsigned int  ) ) &OpenGl_BufferCompatT<BaseBufferT>::subData,
             R"#(Update part of the buffer with new data.)#" ,py::arg("theGlCtx"), py::arg("theElemFrom"), py::arg("theElemsNb"), py::arg("theData"), py::arg("theDataType"))
        .def("getSubData",
             (bool (OpenGl_BufferCompatT<BaseBufferT>::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,  void * ,   const unsigned int  ) ) &OpenGl_BufferCompatT<BaseBufferT>::getSubData,
             R"#(Read back buffer sub-range.)#" ,py::arg("theGlCtx"), py::arg("theElemFrom"), py::arg("theElemsNb"), py::arg("theData"), py::arg("theDataType"))
    ;
};

template <typename T>
void preregister_template_OpenGl_MatrixState(py::object &m, const char *name){
    py::class_<OpenGl_MatrixState<T> , shared_ptr<OpenGl_MatrixState<T>> >(m,name,R"#(Software implementation for OpenGL matrix stack.)#");
}

template <typename T>
void register_template_OpenGl_MatrixState(py::object &m, const char *name){
    static_cast<py::class_<OpenGl_MatrixState<T> , shared_ptr<OpenGl_MatrixState<T>> >>(m.attr(name))
        .def(py::init<  >()  )
        .def("Push",
             (void (OpenGl_MatrixState<T>::*)() ) &OpenGl_MatrixState<T>::Push,
             R"#(Pushes current matrix into stack.)#" )
        .def("Pop",
             (void (OpenGl_MatrixState<T>::*)() ) &OpenGl_MatrixState<T>::Pop,
             R"#(Pops matrix from stack to current.)#" )
        .def("Current",
             ( const typename OpenGl::MatrixType<T>::Mat4 & (OpenGl_MatrixState<T>::*)() ) &OpenGl_MatrixState<T>::Current,
             R"#(Returns current matrix.)#" )
        .def("SetCurrent",
             (void (OpenGl_MatrixState<T>::*)(  const typename OpenGl::MatrixType<T>::Mat4 &  ) ) &OpenGl_MatrixState<T>::SetCurrent,
             R"#(Sets given matrix as current.)#" ,py::arg("theNewCurrent"))
        .def("ChangeCurrent",
             (typename OpenGl::MatrixType<T>::Mat4 & (OpenGl_MatrixState<T>::*)() ) &OpenGl_MatrixState<T>::ChangeCurrent,
             R"#(Change current matrix.)#" )
        .def("SetIdentity",
             (void (OpenGl_MatrixState<T>::*)() ) &OpenGl_MatrixState<T>::SetIdentity,
             R"#(Sets current matrix to identity.)#" )
        .def("DumpJson",
             (void (OpenGl_MatrixState<T>::*)( Standard_OStream & ,  int  ) const) &OpenGl_MatrixState<T>::DumpJson,
             R"#(Dumps the content of me into the stream)#" ,py::arg("theOStream"), py::arg("theDepth")=static_cast<int>(- 1))
    ;
};

template <typename T>
void preregister_template_OpenGl_TextureFormatSelector(py::object &m, const char *name){
    py::class_<OpenGl_TextureFormatSelector<T> , shared_ptr<OpenGl_TextureFormatSelector<T>> >(m,name,R"#(Selects preferable texture format for specified parameters.)#");
}

template <typename T>
void register_template_OpenGl_TextureFormatSelector(py::object &m, const char *name){
    static_cast<py::class_<OpenGl_TextureFormatSelector<T> , shared_ptr<OpenGl_TextureFormatSelector<T>> >>(m.attr(name))
    ;
};


// user-defined post

