
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>

#include <gp_XYZ.hxx>
#include <gp_XY.hxx>

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <NCollection_AccAllocator.hxx>
#include <NCollection_AliasedArray.hxx>
#include <NCollection_AlignedAllocator.hxx>
#include <NCollection_Allocator.hxx>
#include <NCollection_Array1.hxx>
#include <NCollection_Array2.hxx>
#include <NCollection_BaseAllocator.hxx>
#include <NCollection_BaseList.hxx>
#include <NCollection_BaseMap.hxx>
#include <NCollection_BaseSequence.hxx>
#include <NCollection_Buffer.hxx>
#include <NCollection_CellFilter.hxx>
#include <NCollection_DataMap.hxx>
#include <NCollection_DefaultHasher.hxx>
#include <NCollection_DefineAlloc.hxx>
#include <NCollection_DefineHasher.hxx>
#include <NCollection_DoubleMap.hxx>
#include <NCollection_DynamicArray.hxx>
#include <NCollection_EBTree.hxx>
#include <NCollection_FlatDataMap.hxx>
#include <NCollection_FlatMap.hxx>
#include <NCollection_Handle.hxx>
#include <NCollection_HArray1.hxx>
#include <NCollection_HArray2.hxx>
#include <NCollection_HeapAllocator.hxx>
#include <NCollection_HSequence.hxx>
#include <NCollection_IncAllocator.hxx>
#include <NCollection_IndexedDataMap.hxx>
#include <NCollection_IndexedIterator.hxx>
#include <NCollection_IndexedMap.hxx>
#include <NCollection_Iterator.hxx>
#include <NCollection_KDTree.hxx>
#include <NCollection_Lerp.hxx>
#include <NCollection_LinearVector.hxx>
#include <NCollection_List.hxx>
#include <NCollection_ListNode.hxx>
#include <NCollection_LocalArray.hxx>
#include <NCollection_Map.hxx>
#include <NCollection_MapAlgo.hxx>
#include <NCollection_Mat3.hxx>
#include <NCollection_Mat4.hxx>
#include <NCollection_OccAllocator.hxx>
#include <NCollection_OrderedDataMap.hxx>
#include <NCollection_OrderedMap.hxx>
#include <NCollection_PackedMap.hxx>
#include <NCollection_PackedMapAlgo.hxx>
#include <NCollection_Primes.hxx>
#include <NCollection_Sequence.hxx>
#include <NCollection_SparseArray.hxx>
#include <NCollection_SparseArrayBase.hxx>
#include <NCollection_StlIterator.hxx>
#include <NCollection_String.hxx>
#include <NCollection_TListIterator.hxx>
#include <NCollection_TListNode.hxx>
#include <NCollection_UBTree.hxx>
#include <NCollection_UBTreeFiller.hxx>
#include <NCollection_UtfIterator.hxx>
#include <NCollection_UtfString.hxx>
#include <NCollection_Vec2.hxx>
#include <NCollection_Vec3.hxx>
#include <NCollection_Vec4.hxx>
#include <NCollection_Vector.hxx>
#include <NCollection_WinHeapAllocator.hxx>

// template related includes

// ./opencascade/NCollection_String.hxx
#include "NCollection_tmpl.hxx"


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module
const size_t DefaultBlockSize = 24600;
const size_t THE_DEFAULT_BLOCK_SIZE = DefaultBlockSize;

// Module definiiton
void register_NCollection(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("NCollection"));
py::object klass;

// get namespaces as submodules
auto NCollection_PackedMapAlgo = static_cast<py::module>(m.attr("NCollection_PackedMapAlgo"));
auto NCollection_Primes = static_cast<py::module>(m.attr("NCollection_Primes"));
auto NCollection_MapAlgo = static_cast<py::module>(m.attr("NCollection_MapAlgo"));

//Python trampoline classes

// classes

    // Class NCollection_BaseAllocator from ./opencascade/NCollection_BaseAllocator.hxx
    klass = m.attr("NCollection_BaseAllocator");


    // nested enums

    static_cast<py::class_<NCollection_BaseAllocator ,opencascade::handle<NCollection_BaseAllocator>  , Standard_Transient >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("Allocate",
             (void * (NCollection_BaseAllocator::*)(  const size_t  ) ) static_cast<void * (NCollection_BaseAllocator::*)(  const size_t  ) >(&NCollection_BaseAllocator::Allocate),
             R"#()#"  , py::arg("theSize")
          )
        .def("AllocateOptimal",
             (void * (NCollection_BaseAllocator::*)(  const size_t  ) ) static_cast<void * (NCollection_BaseAllocator::*)(  const size_t  ) >(&NCollection_BaseAllocator::AllocateOptimal),
             R"#()#"  , py::arg("theSize")
          )
        .def("Free",
             (void (NCollection_BaseAllocator::*)( void *  ) ) static_cast<void (NCollection_BaseAllocator::*)( void *  ) >(&NCollection_BaseAllocator::Free),
             R"#()#"  , py::arg("theAddress")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("CommonBaseAllocator_s",
                    ( const handle<NCollection_BaseAllocator> & (*)() ) static_cast< const handle<NCollection_BaseAllocator> & (*)() >(&NCollection_BaseAllocator::CommonBaseAllocator),
                    R"#(CommonBaseAllocator This method is designed to have the only one BaseAllocator (to avoid useless copying of collections). However one can use operator new to create more BaseAllocators, but it is injurious.)#" 
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&NCollection_BaseAllocator::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&NCollection_BaseAllocator::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (NCollection_BaseAllocator::*)() const) static_cast< const handle<Standard_Type> & (NCollection_BaseAllocator::*)() const>(&NCollection_BaseAllocator::DynamicType),
             R"#()#"
             
         )
;

    // Class NCollection_BaseList from ./opencascade/NCollection_BaseList.hxx
    klass = m.attr("NCollection_BaseList");


    // nested enums

    static_cast<py::class_<NCollection_BaseList , shared_ptr<NCollection_BaseList>  >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("Extent",
             (int (NCollection_BaseList::*)() const) static_cast<int (NCollection_BaseList::*)() const>(&NCollection_BaseList::Extent),
             R"#()#" 
          )
        .def("Length",
             (int (NCollection_BaseList::*)() const) static_cast<int (NCollection_BaseList::*)() const>(&NCollection_BaseList::Length),
             R"#(Length - number of nodes (legacy int-returning API, synonym of Extent()).)#" 
          )
        .def("Size",
             (size_t (NCollection_BaseList::*)() const) static_cast<size_t (NCollection_BaseList::*)() const>(&NCollection_BaseList::Size),
             R"#(Size - number of nodes.)#" 
          )
        .def("IsEmpty",
             (bool (NCollection_BaseList::*)() const) static_cast<bool (NCollection_BaseList::*)() const>(&NCollection_BaseList::IsEmpty),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Allocator",
             ( const handle<NCollection_BaseAllocator> & (NCollection_BaseList::*)() const) static_cast< const handle<NCollection_BaseAllocator> & (NCollection_BaseList::*)() const>(&NCollection_BaseList::Allocator),
             R"#(Returns attached allocator)#"
             
         )
;

    // Class NCollection_BaseMap from ./opencascade/NCollection_BaseMap.hxx
    klass = m.attr("NCollection_BaseMap");


    // nested enums

    static_cast<py::class_<NCollection_BaseMap , shared_ptr_nodelete<NCollection_BaseMap>  >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("NbBuckets",
             (size_t (NCollection_BaseMap::*)() const) static_cast<size_t (NCollection_BaseMap::*)() const>(&NCollection_BaseMap::NbBuckets),
             R"#(NbBuckets)#" 
          )
        .def("Extent",
             (int (NCollection_BaseMap::*)() const) static_cast<int (NCollection_BaseMap::*)() const>(&NCollection_BaseMap::Extent),
             R"#(Extent (number of elements, legacy int-returning API).)#" 
          )
        .def("Length",
             (int (NCollection_BaseMap::*)() const) static_cast<int (NCollection_BaseMap::*)() const>(&NCollection_BaseMap::Length),
             R"#(Length - number of elements (legacy int-returning API, synonym of Extent()).)#" 
          )
        .def("Size",
             (size_t (NCollection_BaseMap::*)() const) static_cast<size_t (NCollection_BaseMap::*)() const>(&NCollection_BaseMap::Size),
             R"#(Size - number of elements.)#" 
          )
        .def("IsEmpty",
             (bool (NCollection_BaseMap::*)() const) static_cast<bool (NCollection_BaseMap::*)() const>(&NCollection_BaseMap::IsEmpty),
             R"#(IsEmpty)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Allocator",
             ( const handle<NCollection_BaseAllocator> & (NCollection_BaseMap::*)() const) static_cast< const handle<NCollection_BaseAllocator> & (NCollection_BaseMap::*)() const>(&NCollection_BaseMap::Allocator),
             R"#(Returns attached allocator)#"
             
         )
;

    // Class NCollection_BaseSequence from ./opencascade/NCollection_BaseSequence.hxx
    klass = m.attr("NCollection_BaseSequence");


    // nested enums

    static_cast<py::class_<NCollection_BaseSequence , shared_ptr_nodelete<NCollection_BaseSequence>  >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("IsEmpty",
             (bool (NCollection_BaseSequence::*)() const) static_cast<bool (NCollection_BaseSequence::*)() const>(&NCollection_BaseSequence::IsEmpty),
             R"#()#" 
          )
        .def("Length",
             (int (NCollection_BaseSequence::*)() const) static_cast<int (NCollection_BaseSequence::*)() const>(&NCollection_BaseSequence::Length),
             R"#(Number of items (legacy int-returning API).)#" 
          )
        .def("Size",
             (size_t (NCollection_BaseSequence::*)() const) static_cast<size_t (NCollection_BaseSequence::*)() const>(&NCollection_BaseSequence::Size),
             R"#(Size - number of items.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Allocator",
             ( const handle<NCollection_BaseAllocator> & (NCollection_BaseSequence::*)() const) static_cast< const handle<NCollection_BaseAllocator> & (NCollection_BaseSequence::*)() const>(&NCollection_BaseSequence::Allocator),
             R"#(Returns attached allocator)#"
             
         )
;

    // Class NCollection_Buffer from ./opencascade/NCollection_Buffer.hxx
    klass = m.attr("NCollection_Buffer");


    // nested enums

    static_cast<py::class_<NCollection_Buffer ,opencascade::handle<NCollection_Buffer>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const handle<NCollection_BaseAllocator> &, const size_t,uint8_t * >()  , py::arg("theAlloc"),  py::arg("theSize")=static_cast< const size_t>(0),  py::arg("theData")=static_cast<uint8_t *>(nullptr) )
    // custom constructors
    // methods
        .def("Data",
             ( const uint8_t * (NCollection_Buffer::*)() const) static_cast< const uint8_t * (NCollection_Buffer::*)() const>(&NCollection_Buffer::Data),
             R"#(Returns buffer data)#" 
          )
        .def("ChangeData",
             (uint8_t * (NCollection_Buffer::*)() ) static_cast<uint8_t * (NCollection_Buffer::*)() >(&NCollection_Buffer::ChangeData),
             R"#(Returns buffer data)#" 
          )
        .def("IsEmpty",
             (bool (NCollection_Buffer::*)() const) static_cast<bool (NCollection_Buffer::*)() const>(&NCollection_Buffer::IsEmpty),
             R"#(Returns true if buffer is not allocated)#" 
          )
        .def("Size",
             (size_t (NCollection_Buffer::*)() const) static_cast<size_t (NCollection_Buffer::*)() const>(&NCollection_Buffer::Size),
             R"#(Return buffer length in bytes.)#" 
          )
        .def("SetAllocator",
             (void (NCollection_Buffer::*)(  const handle<NCollection_BaseAllocator> &  ) ) static_cast<void (NCollection_Buffer::*)(  const handle<NCollection_BaseAllocator> &  ) >(&NCollection_Buffer::SetAllocator),
             R"#(Assign new buffer allocator with de-allocation of buffer.)#"  , py::arg("theAlloc")
          )
        .def("Allocate",
             (bool (NCollection_Buffer::*)(  const size_t  ) ) static_cast<bool (NCollection_Buffer::*)(  const size_t  ) >(&NCollection_Buffer::Allocate),
             R"#(Allocate the buffer.)#"  , py::arg("theSize")
          )
        .def("Free",
             (void (NCollection_Buffer::*)() ) static_cast<void (NCollection_Buffer::*)() >(&NCollection_Buffer::Free),
             R"#(De-allocate buffer.)#" 
          )
        .def("DumpJson",
             (void (NCollection_Buffer::*)( Standard_OStream & ,  int  ) const) static_cast<void (NCollection_Buffer::*)( Standard_OStream & ,  int  ) const>(&NCollection_Buffer::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&NCollection_Buffer::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&NCollection_Buffer::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Allocator",
             ( const handle<NCollection_BaseAllocator> & (NCollection_Buffer::*)() const) static_cast< const handle<NCollection_BaseAllocator> & (NCollection_Buffer::*)() const>(&NCollection_Buffer::Allocator),
             R"#(Returns buffer allocator)#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (NCollection_Buffer::*)() const) static_cast< const handle<Standard_Type> & (NCollection_Buffer::*)() const>(&NCollection_Buffer::DynamicType),
             R"#()#"
             
         )
;

    // Class NCollection_DefaultHasher<bool> from ./opencascade/NCollection_DefaultHasher.hxx
    klass = m.attr("NCollection_DefaultHasher_bool");

    // default constructor
    register_default_constructor<NCollection_DefaultHasher<bool> , shared_ptr<NCollection_DefaultHasher<bool>>>(m,"NCollection_DefaultHasher_bool");

    // nested enums

    static_cast<py::class_<NCollection_DefaultHasher<bool> , shared_ptr<NCollection_DefaultHasher<bool>>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
        .def("__call__",
             (size_t (NCollection_DefaultHasher<bool>::*)(  const bool  ) const) static_cast<size_t (NCollection_DefaultHasher<bool>::*)(  const bool  ) const>(&NCollection_DefaultHasher<bool>::operator()),
             py::is_operator(),
             R"#()#"  , py::arg("theKey")
          )
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class NCollection_DefaultHasher<char16_t> from ./opencascade/NCollection_DefaultHasher.hxx
    klass = m.attr("NCollection_DefaultHasher_char16_t");

    // default constructor
    register_default_constructor<NCollection_DefaultHasher<char16_t> , shared_ptr<NCollection_DefaultHasher<char16_t>>>(m,"NCollection_DefaultHasher_char16_t");

    // nested enums

    static_cast<py::class_<NCollection_DefaultHasher<char16_t> , shared_ptr<NCollection_DefaultHasher<char16_t>>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
        .def("__call__",
             (size_t (NCollection_DefaultHasher<char16_t>::*)(  const char16_t  ) const) static_cast<size_t (NCollection_DefaultHasher<char16_t>::*)(  const char16_t  ) const>(&NCollection_DefaultHasher<char16_t>::operator()),
             py::is_operator(),
             R"#()#"  , py::arg("theKey")
          )
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class NCollection_DefaultHasher<char32_t> from ./opencascade/NCollection_DefaultHasher.hxx
    klass = m.attr("NCollection_DefaultHasher_char32_t");

    // default constructor
    register_default_constructor<NCollection_DefaultHasher<char32_t> , shared_ptr<NCollection_DefaultHasher<char32_t>>>(m,"NCollection_DefaultHasher_char32_t");

    // nested enums

    static_cast<py::class_<NCollection_DefaultHasher<char32_t> , shared_ptr<NCollection_DefaultHasher<char32_t>>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
        .def("__call__",
             (size_t (NCollection_DefaultHasher<char32_t>::*)(  const char32_t  ) const) static_cast<size_t (NCollection_DefaultHasher<char32_t>::*)(  const char32_t  ) const>(&NCollection_DefaultHasher<char32_t>::operator()),
             py::is_operator(),
             R"#()#"  , py::arg("theKey")
          )
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class NCollection_DefaultHasher<char> from ./opencascade/NCollection_DefaultHasher.hxx
    klass = m.attr("NCollection_DefaultHasher_char");

    // default constructor
    register_default_constructor<NCollection_DefaultHasher<char> , shared_ptr<NCollection_DefaultHasher<char>>>(m,"NCollection_DefaultHasher_char");

    // nested enums

    static_cast<py::class_<NCollection_DefaultHasher<char> , shared_ptr<NCollection_DefaultHasher<char>>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
        .def("__call__",
             (size_t (NCollection_DefaultHasher<char>::*)(  const char  ) const) static_cast<size_t (NCollection_DefaultHasher<char>::*)(  const char  ) const>(&NCollection_DefaultHasher<char>::operator()),
             py::is_operator(),
             R"#()#"  , py::arg("theKey")
          )
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class NCollection_DefaultHasher<int> from ./opencascade/NCollection_DefaultHasher.hxx
    klass = m.attr("NCollection_DefaultHasher_int");

    // default constructor
    register_default_constructor<NCollection_DefaultHasher<int> , shared_ptr<NCollection_DefaultHasher<int>>>(m,"NCollection_DefaultHasher_int");

    // nested enums

    static_cast<py::class_<NCollection_DefaultHasher<int> , shared_ptr<NCollection_DefaultHasher<int>>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
        .def("__call__",
             (size_t (NCollection_DefaultHasher<int>::*)(  const int  ) const) static_cast<size_t (NCollection_DefaultHasher<int>::*)(  const int  ) const>(&NCollection_DefaultHasher<int>::operator()),
             py::is_operator(),
             R"#()#"  , py::arg("theKey")
          )
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class NCollection_DefaultHasher<long long> from ./opencascade/NCollection_DefaultHasher.hxx
    klass = m.attr("NCollection_DefaultHasher_long_long");

    // default constructor
    register_default_constructor<NCollection_DefaultHasher<long long> , shared_ptr<NCollection_DefaultHasher<long long>>>(m,"NCollection_DefaultHasher_long_long");

    // nested enums

    static_cast<py::class_<NCollection_DefaultHasher<long long> , shared_ptr<NCollection_DefaultHasher<long long>>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
        .def("__call__",
             (size_t (NCollection_DefaultHasher<long long>::*)(  const long long  ) const) static_cast<size_t (NCollection_DefaultHasher<long long>::*)(  const long long  ) const>(&NCollection_DefaultHasher<long long>::operator()),
             py::is_operator(),
             R"#()#"  , py::arg("theKey")
          )
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class NCollection_DefaultHasher<long> from ./opencascade/NCollection_DefaultHasher.hxx
    klass = m.attr("NCollection_DefaultHasher_long");

    // default constructor
    register_default_constructor<NCollection_DefaultHasher<long> , shared_ptr<NCollection_DefaultHasher<long>>>(m,"NCollection_DefaultHasher_long");

    // nested enums

    static_cast<py::class_<NCollection_DefaultHasher<long> , shared_ptr<NCollection_DefaultHasher<long>>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
        .def("__call__",
             (size_t (NCollection_DefaultHasher<long>::*)(  const long  ) const) static_cast<size_t (NCollection_DefaultHasher<long>::*)(  const long  ) const>(&NCollection_DefaultHasher<long>::operator()),
             py::is_operator(),
             R"#()#"  , py::arg("theKey")
          )
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class NCollection_DefaultHasher<short> from ./opencascade/NCollection_DefaultHasher.hxx
    klass = m.attr("NCollection_DefaultHasher_short");

    // default constructor
    register_default_constructor<NCollection_DefaultHasher<short> , shared_ptr<NCollection_DefaultHasher<short>>>(m,"NCollection_DefaultHasher_short");

    // nested enums

    static_cast<py::class_<NCollection_DefaultHasher<short> , shared_ptr<NCollection_DefaultHasher<short>>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
        .def("__call__",
             (size_t (NCollection_DefaultHasher<short>::*)(  const short  ) const) static_cast<size_t (NCollection_DefaultHasher<short>::*)(  const short  ) const>(&NCollection_DefaultHasher<short>::operator()),
             py::is_operator(),
             R"#()#"  , py::arg("theKey")
          )
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class NCollection_DefaultHasher<signed char> from ./opencascade/NCollection_DefaultHasher.hxx
    klass = m.attr("NCollection_DefaultHasher_signed_char");

    // default constructor
    register_default_constructor<NCollection_DefaultHasher<signed char> , shared_ptr<NCollection_DefaultHasher<signed char>>>(m,"NCollection_DefaultHasher_signed_char");

    // nested enums

    static_cast<py::class_<NCollection_DefaultHasher<signed char> , shared_ptr<NCollection_DefaultHasher<signed char>>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
        .def("__call__",
             (size_t (NCollection_DefaultHasher<signed char>::*)(  const signed char  ) const) static_cast<size_t (NCollection_DefaultHasher<signed char>::*)(  const signed char  ) const>(&NCollection_DefaultHasher<signed char>::operator()),
             py::is_operator(),
             R"#()#"  , py::arg("theKey")
          )
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class NCollection_DefaultHasher<unsigned char> from ./opencascade/NCollection_DefaultHasher.hxx
    klass = m.attr("NCollection_DefaultHasher_unsigned_char");

    // default constructor
    register_default_constructor<NCollection_DefaultHasher<unsigned char> , shared_ptr<NCollection_DefaultHasher<unsigned char>>>(m,"NCollection_DefaultHasher_unsigned_char");

    // nested enums

    static_cast<py::class_<NCollection_DefaultHasher<unsigned char> , shared_ptr<NCollection_DefaultHasher<unsigned char>>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
        .def("__call__",
             (size_t (NCollection_DefaultHasher<unsigned char>::*)(  const unsigned char  ) const) static_cast<size_t (NCollection_DefaultHasher<unsigned char>::*)(  const unsigned char  ) const>(&NCollection_DefaultHasher<unsigned char>::operator()),
             py::is_operator(),
             R"#()#"  , py::arg("theKey")
          )
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class NCollection_DefaultHasher<unsigned int> from ./opencascade/NCollection_DefaultHasher.hxx
    klass = m.attr("NCollection_DefaultHasher_unsigned_int");

    // default constructor
    register_default_constructor<NCollection_DefaultHasher<unsigned int> , shared_ptr<NCollection_DefaultHasher<unsigned int>>>(m,"NCollection_DefaultHasher_unsigned_int");

    // nested enums

    static_cast<py::class_<NCollection_DefaultHasher<unsigned int> , shared_ptr<NCollection_DefaultHasher<unsigned int>>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
        .def("__call__",
             (size_t (NCollection_DefaultHasher<unsigned int>::*)(  const unsigned int  ) const) static_cast<size_t (NCollection_DefaultHasher<unsigned int>::*)(  const unsigned int  ) const>(&NCollection_DefaultHasher<unsigned int>::operator()),
             py::is_operator(),
             R"#()#"  , py::arg("theKey")
          )
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class NCollection_DefaultHasher<unsigned long long> from ./opencascade/NCollection_DefaultHasher.hxx
    klass = m.attr("NCollection_DefaultHasher_unsigned_long_long");

    // default constructor
    register_default_constructor<NCollection_DefaultHasher<unsigned long long> , shared_ptr<NCollection_DefaultHasher<unsigned long long>>>(m,"NCollection_DefaultHasher_unsigned_long_long");

    // nested enums

    static_cast<py::class_<NCollection_DefaultHasher<unsigned long long> , shared_ptr<NCollection_DefaultHasher<unsigned long long>>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
        .def("__call__",
             (size_t (NCollection_DefaultHasher<unsigned long long>::*)(  const unsigned long long  ) const) static_cast<size_t (NCollection_DefaultHasher<unsigned long long>::*)(  const unsigned long long  ) const>(&NCollection_DefaultHasher<unsigned long long>::operator()),
             py::is_operator(),
             R"#()#"  , py::arg("theKey")
          )
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class NCollection_DefaultHasher<unsigned long> from ./opencascade/NCollection_DefaultHasher.hxx
    klass = m.attr("NCollection_DefaultHasher_unsigned_long");

    // default constructor
    register_default_constructor<NCollection_DefaultHasher<unsigned long> , shared_ptr<NCollection_DefaultHasher<unsigned long>>>(m,"NCollection_DefaultHasher_unsigned_long");

    // nested enums

    static_cast<py::class_<NCollection_DefaultHasher<unsigned long> , shared_ptr<NCollection_DefaultHasher<unsigned long>>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
        .def("__call__",
             (size_t (NCollection_DefaultHasher<unsigned long>::*)(  const unsigned long  ) const) static_cast<size_t (NCollection_DefaultHasher<unsigned long>::*)(  const unsigned long  ) const>(&NCollection_DefaultHasher<unsigned long>::operator()),
             py::is_operator(),
             R"#()#"  , py::arg("theKey")
          )
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class NCollection_DefaultHasher<unsigned short> from ./opencascade/NCollection_DefaultHasher.hxx
    klass = m.attr("NCollection_DefaultHasher_unsigned_short");

    // default constructor
    register_default_constructor<NCollection_DefaultHasher<unsigned short> , shared_ptr<NCollection_DefaultHasher<unsigned short>>>(m,"NCollection_DefaultHasher_unsigned_short");

    // nested enums

    static_cast<py::class_<NCollection_DefaultHasher<unsigned short> , shared_ptr<NCollection_DefaultHasher<unsigned short>>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
        .def("__call__",
             (size_t (NCollection_DefaultHasher<unsigned short>::*)(  const unsigned short  ) const) static_cast<size_t (NCollection_DefaultHasher<unsigned short>::*)(  const unsigned short  ) const>(&NCollection_DefaultHasher<unsigned short>::operator()),
             py::is_operator(),
             R"#()#"  , py::arg("theKey")
          )
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class NCollection_DefaultHasher<wchar_t> from ./opencascade/NCollection_DefaultHasher.hxx
    klass = m.attr("NCollection_DefaultHasher_wchar_t");

    // default constructor
    register_default_constructor<NCollection_DefaultHasher<wchar_t> , shared_ptr<NCollection_DefaultHasher<wchar_t>>>(m,"NCollection_DefaultHasher_wchar_t");

    // nested enums

    static_cast<py::class_<NCollection_DefaultHasher<wchar_t> , shared_ptr<NCollection_DefaultHasher<wchar_t>>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
        .def("__call__",
             (size_t (NCollection_DefaultHasher<wchar_t>::*)(  const wchar_t  ) const) static_cast<size_t (NCollection_DefaultHasher<wchar_t>::*)(  const wchar_t  ) const>(&NCollection_DefaultHasher<wchar_t>::operator()),
             py::is_operator(),
             R"#()#"  , py::arg("theKey")
          )
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class NCollection_SparseArrayBase from ./opencascade/NCollection_SparseArrayBase.hxx
    klass = m.attr("NCollection_SparseArrayBase");


    // nested enums

    static_cast<py::class_<NCollection_SparseArrayBase , shared_ptr_nodelete<NCollection_SparseArrayBase>  >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("Size",
             (size_t (NCollection_SparseArrayBase::*)() const) static_cast<size_t (NCollection_SparseArrayBase::*)() const>(&NCollection_SparseArrayBase::Size),
             R"#(Returns number of currently contained items)#" 
          )
        .def("HasValue",
             (bool (NCollection_SparseArrayBase::*)(  const size_t  ) const) static_cast<bool (NCollection_SparseArrayBase::*)(  const size_t  ) const>(&NCollection_SparseArrayBase::HasValue),
             R"#(Check whether the value at given index is set)#"  , py::arg("theIndex")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class NCollection_UtfStringTool from ./opencascade/NCollection_UtfString.hxx
    klass = m.attr("NCollection_UtfStringTool");


    // nested enums

    static_cast<py::class_<NCollection_UtfStringTool , shared_ptr<NCollection_UtfStringTool>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("FromLocale",
             (wchar_t * (NCollection_UtfStringTool::*)(  const char *  ) ) static_cast<wchar_t * (NCollection_UtfStringTool::*)(  const char *  ) >(&NCollection_UtfStringTool::FromLocale),
             R"#(Convert the string from current locale into UNICODE (wide characters) using system APIs. Returned pointer will be released by this tool.)#"  , py::arg("theString")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("ToLocale_s",
                    (bool (*)(  const wchar_t * ,  char * ,   const int  ) ) static_cast<bool (*)(  const wchar_t * ,  char * ,   const int  ) >(&NCollection_UtfStringTool::ToLocale),
                    R"#(Convert the UNICODE (wide characters) string into locale using system APIs.)#"  , py::arg("theWideString"),  py::arg("theBuffer"),  py::arg("theSizeBytes")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class NCollection_AccAllocator from ./opencascade/NCollection_AccAllocator.hxx
    klass = m.attr("NCollection_AccAllocator");


    // nested enums

    static_cast<py::class_<NCollection_AccAllocator ,opencascade::handle<NCollection_AccAllocator>  , NCollection_BaseAllocator >>(klass)
    // constructors
        .def(py::init<  const size_t >()  , py::arg("theBlockSize")=static_cast< const size_t>(DefaultBlockSize) )
    // custom constructors
    // methods
        .def("Allocate",
             (void * (NCollection_AccAllocator::*)(  const size_t  ) ) static_cast<void * (NCollection_AccAllocator::*)(  const size_t  ) >(&NCollection_AccAllocator::Allocate),
             R"#(Allocate memory with given size)#"  , py::arg("theSize")
          )
        .def("AllocateOptimal",
             (void * (NCollection_AccAllocator::*)(  const size_t  ) ) static_cast<void * (NCollection_AccAllocator::*)(  const size_t  ) >(&NCollection_AccAllocator::AllocateOptimal),
             R"#(Allocate memory with given size)#"  , py::arg("theSize")
          )
        .def("Free",
             (void (NCollection_AccAllocator::*)( void *  ) ) static_cast<void (NCollection_AccAllocator::*)( void *  ) >(&NCollection_AccAllocator::Free),
             R"#(Free a previously allocated memory; memory is returned to the OS when all allocations in some block are freed)#"  , py::arg("theAddress")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&NCollection_AccAllocator::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&NCollection_AccAllocator::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (NCollection_AccAllocator::*)() const) static_cast< const handle<Standard_Type> & (NCollection_AccAllocator::*)() const>(&NCollection_AccAllocator::DynamicType),
             R"#()#"
             
         )
;

    // Class NCollection_AlignedAllocator from ./opencascade/NCollection_AlignedAllocator.hxx
    klass = m.attr("NCollection_AlignedAllocator");


    // nested enums

    static_cast<py::class_<NCollection_AlignedAllocator ,opencascade::handle<NCollection_AlignedAllocator>  , NCollection_BaseAllocator >>(klass)
    // constructors
        .def(py::init<  const size_t >()  , py::arg("theAlignment") )
    // custom constructors
    // methods
        .def("Allocate",
             (void * (NCollection_AlignedAllocator::*)(  const size_t  ) ) static_cast<void * (NCollection_AlignedAllocator::*)(  const size_t  ) >(&NCollection_AlignedAllocator::Allocate),
             R"#(Allocate memory with given size. Returns NULL on failure.)#"  , py::arg("theSize")
          )
        .def("AllocateOptimal",
             (void * (NCollection_AlignedAllocator::*)(  const size_t  ) ) static_cast<void * (NCollection_AlignedAllocator::*)(  const size_t  ) >(&NCollection_AlignedAllocator::AllocateOptimal),
             R"#(Allocate memory with given size. Returns NULL on failure.)#"  , py::arg("theSize")
          )
        .def("Free",
             (void (NCollection_AlignedAllocator::*)( void *  ) ) static_cast<void (NCollection_AlignedAllocator::*)( void *  ) >(&NCollection_AlignedAllocator::Free),
             R"#(Free a previously allocated memory.)#"  , py::arg("thePtr")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&NCollection_AlignedAllocator::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&NCollection_AlignedAllocator::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (NCollection_AlignedAllocator::*)() const) static_cast< const handle<Standard_Type> & (NCollection_AlignedAllocator::*)() const>(&NCollection_AlignedAllocator::DynamicType),
             R"#()#"
             
         )
;

    // Class NCollection_HeapAllocator from ./opencascade/NCollection_HeapAllocator.hxx
    klass = m.attr("NCollection_HeapAllocator");


    // nested enums

    static_cast<py::class_<NCollection_HeapAllocator ,opencascade::handle<NCollection_HeapAllocator>  , NCollection_BaseAllocator >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("Allocate",
             (void * (NCollection_HeapAllocator::*)(  const size_t  ) ) static_cast<void * (NCollection_HeapAllocator::*)(  const size_t  ) >(&NCollection_HeapAllocator::Allocate),
             R"#()#"  , py::arg("theSize")
          )
        .def("AllocateOptimal",
             (void * (NCollection_HeapAllocator::*)(  const size_t  ) ) static_cast<void * (NCollection_HeapAllocator::*)(  const size_t  ) >(&NCollection_HeapAllocator::AllocateOptimal),
             R"#()#"  , py::arg("theSize")
          )
        .def("Free",
             (void (NCollection_HeapAllocator::*)( void *  ) ) static_cast<void (NCollection_HeapAllocator::*)( void *  ) >(&NCollection_HeapAllocator::Free),
             R"#()#"  , py::arg("anAddress")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("GlobalHeapAllocator_s",
                    ( const handle<NCollection_HeapAllocator> & (*)() ) static_cast< const handle<NCollection_HeapAllocator> & (*)() >(&NCollection_HeapAllocator::GlobalHeapAllocator),
                    R"#()#" 
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&NCollection_HeapAllocator::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&NCollection_HeapAllocator::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (NCollection_HeapAllocator::*)() const) static_cast< const handle<Standard_Type> & (NCollection_HeapAllocator::*)() const>(&NCollection_HeapAllocator::DynamicType),
             R"#()#"
             
         )
;

    // Class NCollection_IncAllocator from ./opencascade/NCollection_IncAllocator.hxx
    klass = m.attr("NCollection_IncAllocator");


    // nested enums
        py::enum_<NCollection_IncAllocator::IBlockSizeLevel>(klass, "IBlockSizeLevel_e", R"#(Description ability to next growing size each 5-th new block)#")
            .value("Min", NCollection_IncAllocator::IBlockSizeLevel::Min)
            .value("Small", NCollection_IncAllocator::IBlockSizeLevel::Small)
            .value("Medium", NCollection_IncAllocator::IBlockSizeLevel::Medium)
            .value("Large", NCollection_IncAllocator::IBlockSizeLevel::Large)
            .value("Max", NCollection_IncAllocator::IBlockSizeLevel::Max);

    static_cast<py::class_<NCollection_IncAllocator ,opencascade::handle<NCollection_IncAllocator>  , NCollection_BaseAllocator >>(klass)
    // constructors
        .def(py::init<  const size_t >()  , py::arg("theBlockSize")=static_cast< const size_t>(THE_DEFAULT_BLOCK_SIZE) )
    // custom constructors
    // methods
        .def("SetThreadSafe",
             (void (NCollection_IncAllocator::*)(  const bool  ) ) static_cast<void (NCollection_IncAllocator::*)(  const bool  ) >(&NCollection_IncAllocator::SetThreadSafe),
             R"#(Setup mutex for thread-safe allocations.)#"  , py::arg("theIsThreadSafe")=static_cast< const bool>(true)
          )
        .def("Allocate",
             (void * (NCollection_IncAllocator::*)(  const size_t  ) ) static_cast<void * (NCollection_IncAllocator::*)(  const size_t  ) >(&NCollection_IncAllocator::Allocate),
             R"#(Allocate memory with given size. Returns NULL on failure)#"  , py::arg("size")
          )
        .def("AllocateOptimal",
             (void * (NCollection_IncAllocator::*)(  const size_t  ) ) static_cast<void * (NCollection_IncAllocator::*)(  const size_t  ) >(&NCollection_IncAllocator::AllocateOptimal),
             R"#(Allocate memory with given size. Returns NULL on failure)#"  , py::arg("size")
          )
        .def("Free",
             (void (NCollection_IncAllocator::*)( void *  ) ) static_cast<void (NCollection_IncAllocator::*)( void *  ) >(&NCollection_IncAllocator::Free),
             R"#(Free a previously allocated memory. Does nothing)#"  , py::arg("arg0")
          )
        .def("Reset",
             (void (NCollection_IncAllocator::*)(  const bool  ) ) static_cast<void (NCollection_IncAllocator::*)(  const bool  ) >(&NCollection_IncAllocator::Reset),
             R"#(Re-initialize the allocator so that the next Allocate call should start allocating in the very beginning as though the allocator is just constructed. Warning: make sure that all previously allocated data are no more used in your code!)#"  , py::arg("theReleaseMemory")=static_cast< const bool>(false)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&NCollection_IncAllocator::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&NCollection_IncAllocator::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (NCollection_IncAllocator::*)() const) static_cast< const handle<Standard_Type> & (NCollection_IncAllocator::*)() const>(&NCollection_IncAllocator::DynamicType),
             R"#()#"
             
         )
;

    // Class NCollection_WinHeapAllocator from ./opencascade/NCollection_WinHeapAllocator.hxx
    klass = m.attr("NCollection_WinHeapAllocator");


    // nested enums

    static_cast<py::class_<NCollection_WinHeapAllocator ,opencascade::handle<NCollection_WinHeapAllocator>  , NCollection_BaseAllocator >>(klass)
    // constructors
        .def(py::init<  const size_t >()  , py::arg("theInitSizeBytes")=static_cast< const size_t>(0x80000) )
    // custom constructors
    // methods
        .def("Allocate",
             (void * (NCollection_WinHeapAllocator::*)(  const size_t  ) ) static_cast<void * (NCollection_WinHeapAllocator::*)(  const size_t  ) >(&NCollection_WinHeapAllocator::Allocate),
             R"#(Allocate memory)#"  , py::arg("theSize")
          )
        .def("AllocateOptimal",
             (void * (NCollection_WinHeapAllocator::*)(  const size_t  ) ) static_cast<void * (NCollection_WinHeapAllocator::*)(  const size_t  ) >(&NCollection_WinHeapAllocator::AllocateOptimal),
             R"#(Allocate memory)#"  , py::arg("theSize")
          )
        .def("Free",
             (void (NCollection_WinHeapAllocator::*)( void *  ) ) static_cast<void (NCollection_WinHeapAllocator::*)( void *  ) >(&NCollection_WinHeapAllocator::Free),
             R"#(Release memory)#"  , py::arg("theAddress")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&NCollection_WinHeapAllocator::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&NCollection_WinHeapAllocator::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (NCollection_WinHeapAllocator::*)() const) static_cast< const handle<Standard_Type> & (NCollection_WinHeapAllocator::*)() const>(&NCollection_WinHeapAllocator::DynamicType),
             R"#()#"
             
         )
;

// functions
auto mNCollection_PackedMapAlgo = static_cast<py::module>(m.attr("NCollection_PackedMapAlgo"));
auto mNCollection_Primes = static_cast<py::module>(m.attr("NCollection_Primes"));
auto mNCollection_MapAlgo = static_cast<py::module>(m.attr("NCollection_MapAlgo"));

// ./opencascade/NCollection_AccAllocator.hxx
// ./opencascade/NCollection_AliasedArray.hxx
// ./opencascade/NCollection_AlignedAllocator.hxx
// ./opencascade/NCollection_Allocator.hxx
// ./opencascade/NCollection_Array1.hxx
// ./opencascade/NCollection_Array2.hxx
// ./opencascade/NCollection_BaseAllocator.hxx
// ./opencascade/NCollection_BaseList.hxx
// ./opencascade/NCollection_BaseMap.hxx
// ./opencascade/NCollection_BaseSequence.hxx
// ./opencascade/NCollection_Buffer.hxx
// ./opencascade/NCollection_CellFilter.hxx
// ./opencascade/NCollection_DataMap.hxx
// ./opencascade/NCollection_DefaultHasher.hxx
// ./opencascade/NCollection_DefineAlloc.hxx
// ./opencascade/NCollection_DefineHasher.hxx
// ./opencascade/NCollection_DoubleMap.hxx
// ./opencascade/NCollection_DynamicArray.hxx
// ./opencascade/NCollection_EBTree.hxx
// ./opencascade/NCollection_FlatDataMap.hxx
// ./opencascade/NCollection_FlatMap.hxx
// ./opencascade/NCollection_HArray1.hxx
// ./opencascade/NCollection_HArray2.hxx
// ./opencascade/NCollection_HSequence.hxx
// ./opencascade/NCollection_Handle.hxx
// ./opencascade/NCollection_HeapAllocator.hxx
// ./opencascade/NCollection_IncAllocator.hxx
// ./opencascade/NCollection_IndexedDataMap.hxx
// ./opencascade/NCollection_IndexedIterator.hxx
// ./opencascade/NCollection_IndexedMap.hxx
// ./opencascade/NCollection_Iterator.hxx
// ./opencascade/NCollection_KDTree.hxx
// ./opencascade/NCollection_Lerp.hxx
// ./opencascade/NCollection_LinearVector.hxx
// ./opencascade/NCollection_List.hxx
// ./opencascade/NCollection_ListNode.hxx
// ./opencascade/NCollection_LocalArray.hxx
// ./opencascade/NCollection_Map.hxx
// ./opencascade/NCollection_MapAlgo.hxx
// ./opencascade/NCollection_Mat3.hxx
// ./opencascade/NCollection_Mat4.hxx
// ./opencascade/NCollection_OccAllocator.hxx
// ./opencascade/NCollection_OrderedDataMap.hxx
// ./opencascade/NCollection_OrderedMap.hxx
// ./opencascade/NCollection_PackedMap.hxx
// ./opencascade/NCollection_PackedMapAlgo.hxx
// ./opencascade/NCollection_Primes.hxx
    mNCollection_Primes.def("NextPrimeForMap",
          (size_t (*)(  const size_t  ))  static_cast<size_t (*)(  const size_t  )>(&NCollection_Primes::NextPrimeForMap),
          R"#(Returns the next prime number greater than or equal to theN. If theN exceeds the largest available prime, returns theN + 1.)#"  , py::arg("theN")
          );
// ./opencascade/NCollection_Sequence.hxx
// ./opencascade/NCollection_SparseArray.hxx
// ./opencascade/NCollection_SparseArrayBase.hxx
// ./opencascade/NCollection_StlIterator.hxx
// ./opencascade/NCollection_String.hxx
// ./opencascade/NCollection_TListIterator.hxx
// ./opencascade/NCollection_TListNode.hxx
// ./opencascade/NCollection_UBTree.hxx
// ./opencascade/NCollection_UBTreeFiller.hxx
// ./opencascade/NCollection_UtfIterator.hxx
// ./opencascade/NCollection_UtfString.hxx
// ./opencascade/NCollection_Vec2.hxx
// ./opencascade/NCollection_Vec3.hxx
// ./opencascade/NCollection_Vec4.hxx
// ./opencascade/NCollection_Vector.hxx
// ./opencascade/NCollection_WinHeapAllocator.hxx

// Additional functions


// operators

// register typdefs
    register_template_NCollection_UtfString<char>(m,"NCollection_String");

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
