
// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;


// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <CDM_MetaData.hxx>
#include <CDM_Document.hxx>
#include <PCDM_ReaderFilter.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <CDM_MetaData.hxx>
#include <CDM_Application.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <CDM_Document.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <CDM_Document.hxx>
#include <CDM_Application.hxx>
#include <CDM_MetaData.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <CDM_Document.hxx>

// module includes
#include <CDM_Application.hxx>
#include <CDM_CanCloseStatus.hxx>
#include <CDM_Document.hxx>
#include <CDM_DocumentPointer.hxx>
#include <CDM_MetaData.hxx>
#include <CDM_Reference.hxx>
#include <CDM_ReferenceIterator.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_CDM_enums(py::module &main_module) {


py::module m = main_module.def_submodule("CDM", R"#()#");

// add namespaces as submodules

// user-defined inclusion per module in the body

// enums
    py::enum_<CDM_CanCloseStatus>(m, "CDM_CanCloseStatus",R"#()#")
        .value("CDM_CCS_OK",CDM_CanCloseStatus::CDM_CCS_OK)
        .value("CDM_CCS_NotOpen",CDM_CanCloseStatus::CDM_CCS_NotOpen)
        .value("CDM_CCS_UnstoredReferenced",CDM_CanCloseStatus::CDM_CCS_UnstoredReferenced)
        .value("CDM_CCS_ModifiedReferenced",CDM_CanCloseStatus::CDM_CCS_ModifiedReferenced)
        .value("CDM_CCS_ReferenceRejection",CDM_CanCloseStatus::CDM_CCS_ReferenceRejection).export_values();

//Python trampoline classes
    class Py_CDM_Application : public CDM_Application{
    public:
        using CDM_Application::CDM_Application;


        // public pure virtual


        // protected pure virtual


        // private pure virtual
        handle<CDM_Document> Retrieve( const handle<CDM_MetaData> & aMetaData, const bool UseStorageConfiguration, const handle<PCDM_ReaderFilter> & theFilter, const Message_ProgressRange & theRange) override { using return_type = handle<CDM_Document>;
    PYBIND11_OVERLOAD_PURE(return_type,CDM_Application,Retrieve,aMetaData,UseStorageConfiguration,theFilter,theRange) };
        int DocumentVersion( const handle<CDM_MetaData> & aMetaData) override { using return_type = int;
    PYBIND11_OVERLOAD_PURE(return_type,CDM_Application,DocumentVersion,aMetaData) };

    };
    class Py_CDM_Document : public CDM_Document{
    public:
        using CDM_Document::CDM_Document;


        // public pure virtual
        TCollection_ExtendedString StorageFormat() const  override { using return_type = TCollection_ExtendedString;
    PYBIND11_OVERLOAD_PURE(return_type,CDM_Document,StorageFormat,) };


        // protected pure virtual


        // private pure virtual

    };

// pre-register typdefs+classes (topologically sorted)
    py::class_<CDM_ReferenceIterator , shared_ptr<CDM_ReferenceIterator>  >(
      m,
      "CDM_ReferenceIterator",R"#()#"
    );
    py::class_<CDM_Application ,opencascade::handle<CDM_Application> ,Py_CDM_Application , Standard_Transient >(
      m,
      "CDM_Application",R"#()#"
    );
    py::class_<CDM_Document ,opencascade::handle<CDM_Document> ,Py_CDM_Document , Standard_Transient >(
      m,
      "CDM_Document",R"#(An applicative document is an instance of a class inheriting CDM_Document. These documents have the following properties: - they can have references to other documents. - the modifications of a document are propagated to the referencing documents. - a document can be stored in different formats, with or without a persistent model. - the drivers for storing and retrieving documents are plugged in when necessary. - a document has a modification counter. This counter is incremented when the document is modified. When a document is stored, the current counter value is memorized as the last storage version of the document. A document is considered to be modified when the counter value is different from the storage version. Once the document is saved the storage version and the counter value are identical. The document is now not considered to be modified. - a reference is a link between two documents. A reference has two components: the "From Document" and the "To Document". When a reference is created, an identifier of the reference is generated. This identifier is unique in the scope of the From Document and is conserved during storage and retrieval. This means that the referenced document will be always accessible through this identifier. - a reference memorizes the counter value of the To Document when the reference is created. The From Document is considered to be up to date relative to the To Document when the reference counter value is equal to the To Document counter value. - retrieval of a document having references does not imply the retrieving of the referenced documents.)#"
    );
    py::class_<CDM_MetaData ,opencascade::handle<CDM_MetaData>  , Standard_Transient >(
      m,
      "CDM_MetaData",R"#()#"
    );
    py::class_<CDM_Reference ,opencascade::handle<CDM_Reference>  , Standard_Transient >(
      m,
      "CDM_Reference",R"#()#"
    );

// preregister user-defined template specializations

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
