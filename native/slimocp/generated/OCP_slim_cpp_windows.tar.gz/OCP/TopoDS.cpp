
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TopoDS_Vertex.hxx>
#include <TopoDS_Edge.hxx>
#include <TopoDS_Wire.hxx>
#include <TopoDS_Face.hxx>
#include <TopoDS_Shell.hxx>
#include <TopoDS_Solid.hxx>
#include <TopoDS_CompSolid.hxx>
#include <TopoDS_Compound.hxx>
#include <TopoDS_HShape.hxx>
#include <TopoDS_TVertex.hxx>
#include <TopoDS_TEdge.hxx>
#include <TopoDS_TWire.hxx>
#include <TopoDS_TFace.hxx>
#include <TopoDS_TShell.hxx>
#include <TopoDS_TSolid.hxx>
#include <TopoDS_TCompSolid.hxx>
#include <TopoDS_TCompound.hxx>
#include <TopoDS_Builder.hxx>
#include <TopoDS_Iterator.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TopoDS_Shape.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <TopoDS.hxx>
#include <TopoDS_AlertAttribute.hxx>
#include <TopoDS_AlertWithShape.hxx>
#include <TopoDS_Builder.hxx>
#include <TopoDS_Compound.hxx>
#include <TopoDS_CompSolid.hxx>
#include <TopoDS_Edge.hxx>
#include <TopoDS_Face.hxx>
#include <TopoDS_FrozenShape.hxx>
#include <TopoDS_HShape.hxx>
#include <TopoDS_Iterator.hxx>
#include <TopoDS_LockedShape.hxx>
#include <TopoDS_Shape.hxx>
#include <TopoDS_Shell.hxx>
#include <TopoDS_Solid.hxx>
#include <TopoDS_TCompound.hxx>
#include <TopoDS_TCompSolid.hxx>
#include <TopoDS_TEdge.hxx>
#include <TopoDS_TFace.hxx>
#include <TopoDS_TShape.hxx>
#include <TopoDS_TShell.hxx>
#include <TopoDS_TSolid.hxx>
#include <TopoDS_TVertex.hxx>
#include <TopoDS_TWire.hxx>
#include <TopoDS_UnCompatibleShapes.hxx>
#include <TopoDS_Vertex.hxx>
#include <TopoDS_Wire.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module
#include <cstdint>

// Module definiiton
void register_TopoDS(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("TopoDS"));
py::object klass;

// get namespaces as submodules
auto TopoDS = static_cast<py::module>(m.attr("TopoDS"));

//Python trampoline classes
    class Py_TopoDS_TShape : public TopoDS_TShape{
    public:
        using TopoDS_TShape::TopoDS_TShape;


        // public pure virtual
        handle<TopoDS_TShape> EmptyCopy() const  override { using return_type = handle<TopoDS_TShape>;
    PYBIND11_OVERLOAD_PURE(return_type,TopoDS_TShape,EmptyCopy,) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_TopoDS_TVertex : public TopoDS_TVertex{
    public:
        using TopoDS_TVertex::TopoDS_TVertex;


        // public pure virtual

        handle<TopoDS_TShape> EmptyCopy() const  override { using return_type = handle<TopoDS_TShape>;
    PYBIND11_OVERLOAD_PURE(return_type,TopoDS_TShape,EmptyCopy,) };

        // protected pure virtual


        // private pure virtual

    };

// classes

    // Class TopoDS_AlertAttribute from ./opencascade/TopoDS_AlertAttribute.hxx
    klass = m.attr("TopoDS_AlertAttribute");


    // nested enums

    static_cast<py::class_<TopoDS_AlertAttribute ,opencascade::handle<TopoDS_AlertAttribute>  , Message_AttributeStream >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape &, const TCollection_AsciiString & >()  , py::arg("theShape"),  py::arg("theName")=static_cast< const TCollection_AsciiString &>(TCollection_AsciiString :: EmptyString ( )) )
    // custom constructors
    // methods
        .def("DumpJson",
             (void (TopoDS_AlertAttribute::*)( Standard_OStream & ,  int  ) const) static_cast<void (TopoDS_AlertAttribute::*)( Standard_OStream & ,  int  ) const>(&TopoDS_AlertAttribute::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TopoDS_AlertAttribute::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TopoDS_AlertAttribute::get_type_descriptor),
                    R"#()#" 
          )
        .def_static("Send_s",
                    (void (*)(  const handle<Message_Messenger> & ,   const TopoDS_Shape &  ) ) static_cast<void (*)(  const handle<Message_Messenger> & ,   const TopoDS_Shape &  ) >(&TopoDS_AlertAttribute::Send),
                    R"#(Push shape information into messenger)#"  , py::arg("theMessenger"),  py::arg("theShape")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TopoDS_AlertAttribute::*)() const) static_cast< const handle<Standard_Type> & (TopoDS_AlertAttribute::*)() const>(&TopoDS_AlertAttribute::DynamicType),
             R"#()#"
             
         )
       .def("GetShape",
             ( const TopoDS_Shape & (TopoDS_AlertAttribute::*)() const) static_cast< const TopoDS_Shape & (TopoDS_AlertAttribute::*)() const>(&TopoDS_AlertAttribute::GetShape),
             R"#(Returns contained shape)#"
             
         )
;

    // Class TopoDS_AlertWithShape from ./opencascade/TopoDS_AlertWithShape.hxx
    klass = m.attr("TopoDS_AlertWithShape");


    // nested enums

    static_cast<py::class_<TopoDS_AlertWithShape ,opencascade::handle<TopoDS_AlertWithShape>  , Message_Alert >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("theShape") )
    // custom constructors
    // methods
        .def("SetShape",
             (void (TopoDS_AlertWithShape::*)(  const TopoDS_Shape &  ) ) static_cast<void (TopoDS_AlertWithShape::*)(  const TopoDS_Shape &  ) >(&TopoDS_AlertWithShape::SetShape),
             R"#(Sets the shape)#"  , py::arg("theShape")
          )
        .def("SupportsMerge",
             (bool (TopoDS_AlertWithShape::*)() const) static_cast<bool (TopoDS_AlertWithShape::*)() const>(&TopoDS_AlertWithShape::SupportsMerge),
             R"#(Returns false.)#" 
          )
        .def("Merge",
             (bool (TopoDS_AlertWithShape::*)(  const handle<Message_Alert> &  ) ) static_cast<bool (TopoDS_AlertWithShape::*)(  const handle<Message_Alert> &  ) >(&TopoDS_AlertWithShape::Merge),
             R"#(Returns false.)#"  , py::arg("theTarget")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TopoDS_AlertWithShape::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TopoDS_AlertWithShape::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("GetShape",
             ( const TopoDS_Shape & (TopoDS_AlertWithShape::*)() const) static_cast< const TopoDS_Shape & (TopoDS_AlertWithShape::*)() const>(&TopoDS_AlertWithShape::GetShape),
             R"#(Returns contained shape)#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TopoDS_AlertWithShape::*)() const) static_cast< const handle<Standard_Type> & (TopoDS_AlertWithShape::*)() const>(&TopoDS_AlertWithShape::DynamicType),
             R"#()#"
             
         )
;

    // Class TopoDS_Builder from ./opencascade/TopoDS_Builder.hxx
    klass = m.attr("TopoDS_Builder");

    // default constructor
    register_default_constructor<TopoDS_Builder , shared_ptr<TopoDS_Builder>>(m,"TopoDS_Builder");

    // nested enums

    static_cast<py::class_<TopoDS_Builder , shared_ptr<TopoDS_Builder>  >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("MakeWire",
             (void (TopoDS_Builder::*)( TopoDS_Wire &  ) const) static_cast<void (TopoDS_Builder::*)( TopoDS_Wire &  ) const>(&TopoDS_Builder::MakeWire),
             R"#(Make an empty Wire.)#"  , py::arg("W")
          )
        .def("MakeShell",
             (void (TopoDS_Builder::*)( TopoDS_Shell &  ) const) static_cast<void (TopoDS_Builder::*)( TopoDS_Shell &  ) const>(&TopoDS_Builder::MakeShell),
             R"#(Make an empty Shell.)#"  , py::arg("S")
          )
        .def("MakeSolid",
             (void (TopoDS_Builder::*)( TopoDS_Solid &  ) const) static_cast<void (TopoDS_Builder::*)( TopoDS_Solid &  ) const>(&TopoDS_Builder::MakeSolid),
             R"#(Make a Solid covering the whole 3D space.)#"  , py::arg("S")
          )
        .def("MakeCompSolid",
             (void (TopoDS_Builder::*)( TopoDS_CompSolid &  ) const) static_cast<void (TopoDS_Builder::*)( TopoDS_CompSolid &  ) const>(&TopoDS_Builder::MakeCompSolid),
             R"#(Make an empty Composite Solid.)#"  , py::arg("C")
          )
        .def("MakeCompound",
             (void (TopoDS_Builder::*)( TopoDS_Compound &  ) const) static_cast<void (TopoDS_Builder::*)( TopoDS_Compound &  ) const>(&TopoDS_Builder::MakeCompound),
             R"#(Make an empty Compound.)#"  , py::arg("C")
          )
        .def("Add",
             (void (TopoDS_Builder::*)( TopoDS_Shape & ,   const TopoDS_Shape &  ) const) static_cast<void (TopoDS_Builder::*)( TopoDS_Shape & ,   const TopoDS_Shape &  ) const>(&TopoDS_Builder::Add),
             R"#(Add the Shape C in the Shape S. Exceptions - TopoDS_FrozenShape if S is not free and cannot be modified. - TopoDS__UnCompatibleShapes if S and C are not compatible.)#"  , py::arg("S"),  py::arg("C")
          )
        .def("Remove",
             (void (TopoDS_Builder::*)( TopoDS_Shape & ,   const TopoDS_Shape &  ) const) static_cast<void (TopoDS_Builder::*)( TopoDS_Shape & ,   const TopoDS_Shape &  ) const>(&TopoDS_Builder::Remove),
             R"#(Remove the Shape C from the Shape S. Exceptions TopoDS_FrozenShape if S is frozen and cannot be modified.)#"  , py::arg("S"),  py::arg("C")
          )
        .def("MakeWire",
             (void (TopoDS_Builder::*)( TopoDS_Wire &  ) const) static_cast<void (TopoDS_Builder::*)( TopoDS_Wire &  ) const>(&TopoDS_Builder::MakeWire),
             R"#(Make an empty Wire.)#"  , py::arg("W")
          )
        .def("MakeShell",
             (void (TopoDS_Builder::*)( TopoDS_Shell &  ) const) static_cast<void (TopoDS_Builder::*)( TopoDS_Shell &  ) const>(&TopoDS_Builder::MakeShell),
             R"#(Make an empty Shell.)#"  , py::arg("S")
          )
        .def("MakeSolid",
             (void (TopoDS_Builder::*)( TopoDS_Solid &  ) const) static_cast<void (TopoDS_Builder::*)( TopoDS_Solid &  ) const>(&TopoDS_Builder::MakeSolid),
             R"#(Make a Solid covering the whole 3D space.)#"  , py::arg("S")
          )
        .def("MakeCompSolid",
             (void (TopoDS_Builder::*)( TopoDS_CompSolid &  ) const) static_cast<void (TopoDS_Builder::*)( TopoDS_CompSolid &  ) const>(&TopoDS_Builder::MakeCompSolid),
             R"#(Make an empty Composite Solid.)#"  , py::arg("C")
          )
        .def("MakeCompound",
             (void (TopoDS_Builder::*)( TopoDS_Compound &  ) const) static_cast<void (TopoDS_Builder::*)( TopoDS_Compound &  ) const>(&TopoDS_Builder::MakeCompound),
             R"#(Make an empty Compound.)#"  , py::arg("C")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class TopoDS_HShape from ./opencascade/TopoDS_HShape.hxx
    klass = m.attr("TopoDS_HShape");


    // nested enums

    static_cast<py::class_<TopoDS_HShape ,opencascade::handle<TopoDS_HShape>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("aShape") )
    // custom constructors
    // methods
        .def("Shape",
             (void (TopoDS_HShape::*)(  const TopoDS_Shape &  ) ) static_cast<void (TopoDS_HShape::*)(  const TopoDS_Shape &  ) >(&TopoDS_HShape::Shape),
             R"#(Loads this shape with the shape aShape.)#"  , py::arg("aShape")
          )
        .def("Shape",
             (void (TopoDS_HShape::*)(  const TopoDS_Shape &  ) ) static_cast<void (TopoDS_HShape::*)(  const TopoDS_Shape &  ) >(&TopoDS_HShape::Shape),
             R"#(Loads this shape with the shape aShape.)#"  , py::arg("aShape")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TopoDS_HShape::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TopoDS_HShape::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Shape",
             ( const TopoDS_Shape & (TopoDS_HShape::*)() const) static_cast< const TopoDS_Shape & (TopoDS_HShape::*)() const>(&TopoDS_HShape::Shape),
             R"#(Returns a reference to a constant TopoDS_Shape based on this shape.)#"
             
         )
       .def("ChangeShape",
             (TopoDS_Shape & (TopoDS_HShape::*)() ) static_cast<TopoDS_Shape & (TopoDS_HShape::*)() >(&TopoDS_HShape::ChangeShape),
             R"#(Exchanges the TopoDS_Shape object defining this shape for another one referencing the same underlying shape Accesses the list of shapes within the underlying shape referenced by the TopoDS_Shape object. Returns a reference to a TopoDS_Shape based on this shape. The TopoDS_Shape can be modified.)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TopoDS_HShape::*)() const) static_cast< const handle<Standard_Type> & (TopoDS_HShape::*)() const>(&TopoDS_HShape::DynamicType),
             R"#()#"
             
         )
       .def("Shape",
             ( const TopoDS_Shape & (TopoDS_HShape::*)() const) static_cast< const TopoDS_Shape & (TopoDS_HShape::*)() const>(&TopoDS_HShape::Shape),
             R"#(Returns a reference to a constant TopoDS_Shape based on this shape.)#"
             
         )
       .def("ChangeShape",
             (TopoDS_Shape & (TopoDS_HShape::*)() ) static_cast<TopoDS_Shape & (TopoDS_HShape::*)() >(&TopoDS_HShape::ChangeShape),
             R"#(Exchanges the TopoDS_Shape object defining this shape for another one referencing the same underlying shape Accesses the list of shapes within the underlying shape referenced by the TopoDS_Shape object. Returns a reference to a TopoDS_Shape based on this shape. The TopoDS_Shape can be modified.)#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class TopoDS_Iterator from ./opencascade/TopoDS_Iterator.hxx
    klass = m.attr("TopoDS_Iterator");


    // nested enums

    static_cast<py::class_<TopoDS_Iterator , shared_ptr<TopoDS_Iterator>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const TopoDS_Shape &, const bool, const bool >()  , py::arg("S"),  py::arg("cumOri")=static_cast< const bool>(true),  py::arg("cumLoc")=static_cast< const bool>(true) )
    // custom constructors
    // methods
        .def("Initialize",
             (void (TopoDS_Iterator::*)(  const TopoDS_Shape & ,   const bool ,   const bool  ) ) static_cast<void (TopoDS_Iterator::*)(  const TopoDS_Shape & ,   const bool ,   const bool  ) >(&TopoDS_Iterator::Initialize),
             R"#(Initializes this iterator with shape S. Note: - If cumOri is true, the function composes all sub-shapes with the orientation of S. - If cumLoc is true, the function multiplies all sub-shapes by the location of S, i.e. it applies to each sub-shape the transformation that is associated with S.)#"  , py::arg("S"),  py::arg("cumOri")=static_cast< const bool>(true),  py::arg("cumLoc")=static_cast< const bool>(true)
          )
        .def("More",
             (bool (TopoDS_Iterator::*)() const) static_cast<bool (TopoDS_Iterator::*)() const>(&TopoDS_Iterator::More),
             R"#(Returns true if there is another sub-shape in the shape which this iterator is scanning.)#" 
          )
        .def("Next",
             (void (TopoDS_Iterator::*)() ) static_cast<void (TopoDS_Iterator::*)() >(&TopoDS_Iterator::Next),
             R"#(Moves on to the next sub-shape in the shape which this iterator is scanning. Exceptions Standard_NoMoreObject if there are no more sub-shapes in the shape.)#" 
          )
        .def("begin",
             (NCollection_ForwardRangeIterator<TopoDS_Iterator> (TopoDS_Iterator::*)() ) static_cast<NCollection_ForwardRangeIterator<TopoDS_Iterator> (TopoDS_Iterator::*)() >(&TopoDS_Iterator::begin),
             R"#(Returns an STL-compatible iterator for range-based for loops.)#" 
          )
        .def("end",
             (NCollection_ForwardRangeSentinel (TopoDS_Iterator::*)() const) static_cast<NCollection_ForwardRangeSentinel (TopoDS_Iterator::*)() const>(&TopoDS_Iterator::end),
             R"#(Returns a sentinel marking the end of iteration.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const TopoDS_Shape & (TopoDS_Iterator::*)() const) static_cast< const TopoDS_Shape & (TopoDS_Iterator::*)() const>(&TopoDS_Iterator::Value),
             R"#(Returns the current sub-shape in the shape which this iterator is scanning. Exceptions Standard_NoSuchObject if there is no current sub-shape.)#"
             
         )
;

    // Class TopoDS_Shape from ./opencascade/TopoDS_Shape.hxx
    klass = m.attr("TopoDS_Shape");


    // nested enums

    static_cast<py::class_<TopoDS_Shape , shared_ptr<TopoDS_Shape>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("IsNull",
             (bool (TopoDS_Shape::*)() const) static_cast<bool (TopoDS_Shape::*)() const>(&TopoDS_Shape::IsNull),
             R"#(Returns true if this shape is null. In other words, it references no underlying shape with the potential to be given a location and an orientation.)#" 
          )
        .def("Nullify",
             (void (TopoDS_Shape::*)() ) static_cast<void (TopoDS_Shape::*)() >(&TopoDS_Shape::Nullify),
             R"#(Destroys the reference to the underlying shape stored in this shape. As a result, this shape becomes null.)#" 
          )
        .def("Location",
             (void (TopoDS_Shape::*)(  const TopLoc_Location & ,   const bool  ) ) static_cast<void (TopoDS_Shape::*)(  const TopLoc_Location & ,   const bool  ) >(&TopoDS_Shape::Location),
             R"#(Sets the shape local coordinate system.)#"  , py::arg("theLoc"),  py::arg("theRaiseExc")=static_cast< const bool>(false)
          )
        .def("Located",
             (TopoDS_Shape (TopoDS_Shape::*)(  const TopLoc_Location & ,   const bool  ) const) static_cast<TopoDS_Shape (TopoDS_Shape::*)(  const TopLoc_Location & ,   const bool  ) const>(&TopoDS_Shape::Located),
             R"#(Returns a shape similar to <me> with the local coordinate system set to <Loc>.)#"  , py::arg("theLoc"),  py::arg("theRaiseExc")=static_cast< const bool>(false)
          )
        .def("Orientation",
             (TopAbs_Orientation (TopoDS_Shape::*)() const) static_cast<TopAbs_Orientation (TopoDS_Shape::*)() const>(&TopoDS_Shape::Orientation),
             R"#(Returns the shape orientation.)#" 
          )
        .def("Orientation",
             (void (TopoDS_Shape::*)( TopAbs_Orientation  ) ) static_cast<void (TopoDS_Shape::*)( TopAbs_Orientation  ) >(&TopoDS_Shape::Orientation),
             R"#(Sets the shape orientation.)#"  , py::arg("theOrient")
          )
        .def("Oriented",
             (TopoDS_Shape (TopoDS_Shape::*)( TopAbs_Orientation  ) const) static_cast<TopoDS_Shape (TopoDS_Shape::*)( TopAbs_Orientation  ) const>(&TopoDS_Shape::Oriented),
             R"#(Returns a shape similar to <me> with the orientation set to <Or>.)#"  , py::arg("theOrient")
          )
        .def("ShapeType",
             (TopAbs_ShapeEnum (TopoDS_Shape::*)() const) static_cast<TopAbs_ShapeEnum (TopoDS_Shape::*)() const>(&TopoDS_Shape::ShapeType),
             R"#(Returns the value of the TopAbs_ShapeEnum enumeration that corresponds to this shape, for example VERTEX, EDGE, and so on. Exceptions Standard_NullObject if this shape is null.)#" 
          )
        .def("Free",
             (bool (TopoDS_Shape::*)() const) static_cast<bool (TopoDS_Shape::*)() const>(&TopoDS_Shape::Free),
             R"#(Returns the free flag.)#" 
          )
        .def("Free",
             (void (TopoDS_Shape::*)( bool  ) ) static_cast<void (TopoDS_Shape::*)( bool  ) >(&TopoDS_Shape::Free),
             R"#(Sets the free flag.)#"  , py::arg("theIsFree")
          )
        .def("Locked",
             (bool (TopoDS_Shape::*)() const) static_cast<bool (TopoDS_Shape::*)() const>(&TopoDS_Shape::Locked),
             R"#(Returns the locked flag.)#" 
          )
        .def("Locked",
             (void (TopoDS_Shape::*)( bool  ) ) static_cast<void (TopoDS_Shape::*)( bool  ) >(&TopoDS_Shape::Locked),
             R"#(Sets the locked flag.)#"  , py::arg("theIsLocked")
          )
        .def("Modified",
             (bool (TopoDS_Shape::*)() const) static_cast<bool (TopoDS_Shape::*)() const>(&TopoDS_Shape::Modified),
             R"#(Returns the modification flag.)#" 
          )
        .def("Modified",
             (void (TopoDS_Shape::*)( bool  ) ) static_cast<void (TopoDS_Shape::*)( bool  ) >(&TopoDS_Shape::Modified),
             R"#(Sets the modification flag.)#"  , py::arg("theIsModified")
          )
        .def("Checked",
             (bool (TopoDS_Shape::*)() const) static_cast<bool (TopoDS_Shape::*)() const>(&TopoDS_Shape::Checked),
             R"#(Returns the checked flag.)#" 
          )
        .def("Checked",
             (void (TopoDS_Shape::*)( bool  ) ) static_cast<void (TopoDS_Shape::*)( bool  ) >(&TopoDS_Shape::Checked),
             R"#(Sets the checked flag.)#"  , py::arg("theIsChecked")
          )
        .def("Orientable",
             (bool (TopoDS_Shape::*)() const) static_cast<bool (TopoDS_Shape::*)() const>(&TopoDS_Shape::Orientable),
             R"#(Returns the orientability flag.)#" 
          )
        .def("Orientable",
             (void (TopoDS_Shape::*)(  const bool  ) ) static_cast<void (TopoDS_Shape::*)(  const bool  ) >(&TopoDS_Shape::Orientable),
             R"#(Sets the orientability flag.)#"  , py::arg("theIsOrientable")
          )
        .def("Closed",
             (bool (TopoDS_Shape::*)() const) static_cast<bool (TopoDS_Shape::*)() const>(&TopoDS_Shape::Closed),
             R"#(Returns the closedness flag.)#" 
          )
        .def("Closed",
             (void (TopoDS_Shape::*)( bool  ) ) static_cast<void (TopoDS_Shape::*)( bool  ) >(&TopoDS_Shape::Closed),
             R"#(Sets the closedness flag.)#"  , py::arg("theIsClosed")
          )
        .def("Infinite",
             (bool (TopoDS_Shape::*)() const) static_cast<bool (TopoDS_Shape::*)() const>(&TopoDS_Shape::Infinite),
             R"#(Returns the infinity flag.)#" 
          )
        .def("Infinite",
             (void (TopoDS_Shape::*)( bool  ) ) static_cast<void (TopoDS_Shape::*)( bool  ) >(&TopoDS_Shape::Infinite),
             R"#(Sets the infinity flag.)#"  , py::arg("theIsInfinite")
          )
        .def("Convex",
             (bool (TopoDS_Shape::*)() const) static_cast<bool (TopoDS_Shape::*)() const>(&TopoDS_Shape::Convex),
             R"#(Returns the convexness flag.)#" 
          )
        .def("Convex",
             (void (TopoDS_Shape::*)( bool  ) ) static_cast<void (TopoDS_Shape::*)( bool  ) >(&TopoDS_Shape::Convex),
             R"#(Sets the convexness flag.)#"  , py::arg("theIsConvex")
          )
        .def("Move",
             (void (TopoDS_Shape::*)(  const TopLoc_Location & ,   const bool  ) ) static_cast<void (TopoDS_Shape::*)(  const TopLoc_Location & ,   const bool  ) >(&TopoDS_Shape::Move),
             R"#(Multiplies the Shape location by thePosition.)#"  , py::arg("thePosition"),  py::arg("theRaiseExc")=static_cast< const bool>(false)
          )
        .def("Moved",
             (TopoDS_Shape (TopoDS_Shape::*)(  const TopLoc_Location & ,   const bool  ) const) static_cast<TopoDS_Shape (TopoDS_Shape::*)(  const TopLoc_Location & ,   const bool  ) const>(&TopoDS_Shape::Moved),
             R"#(Returns a shape similar to <me> with a location multiplied by thePosition.)#"  , py::arg("thePosition"),  py::arg("theRaiseExc")=static_cast< const bool>(false)
          )
        .def("Reverse",
             (void (TopoDS_Shape::*)() ) static_cast<void (TopoDS_Shape::*)() >(&TopoDS_Shape::Reverse),
             R"#(Reverses the orientation, using the Reverse method from the TopAbs package.)#" 
          )
        .def("Reversed",
             (TopoDS_Shape (TopoDS_Shape::*)() const) static_cast<TopoDS_Shape (TopoDS_Shape::*)() const>(&TopoDS_Shape::Reversed),
             R"#(Returns a shape similar to <me> with the orientation reversed, using the Reverse method from the TopAbs package.)#" 
          )
        .def("Complement",
             (void (TopoDS_Shape::*)() ) static_cast<void (TopoDS_Shape::*)() >(&TopoDS_Shape::Complement),
             R"#(Complements the orientation, using the Complement method from the TopAbs package.)#" 
          )
        .def("Complemented",
             (TopoDS_Shape (TopoDS_Shape::*)() const) static_cast<TopoDS_Shape (TopoDS_Shape::*)() const>(&TopoDS_Shape::Complemented),
             R"#(Returns a shape similar to <me> with the orientation complemented, using the Complement method from the TopAbs package.)#" 
          )
        .def("Compose",
             (void (TopoDS_Shape::*)( TopAbs_Orientation  ) ) static_cast<void (TopoDS_Shape::*)( TopAbs_Orientation  ) >(&TopoDS_Shape::Compose),
             R"#(Updates the Shape Orientation by composition with theOrient, using the Compose method from the TopAbs package.)#"  , py::arg("theOrient")
          )
        .def("Composed",
             (TopoDS_Shape (TopoDS_Shape::*)( TopAbs_Orientation  ) const) static_cast<TopoDS_Shape (TopoDS_Shape::*)( TopAbs_Orientation  ) const>(&TopoDS_Shape::Composed),
             R"#(Returns a shape similar to <me> with the orientation composed with theOrient, using the Compose method from the TopAbs package.)#"  , py::arg("theOrient")
          )
        .def("NbChildren",
             (int (TopoDS_Shape::*)() const) static_cast<int (TopoDS_Shape::*)() const>(&TopoDS_Shape::NbChildren),
             R"#(Returns the number of direct sub-shapes (children).)#" 
          )
        .def("IsPartner",
             (bool (TopoDS_Shape::*)(  const TopoDS_Shape &  ) const) static_cast<bool (TopoDS_Shape::*)(  const TopoDS_Shape &  ) const>(&TopoDS_Shape::IsPartner),
             R"#(Returns True if two shapes are partners, i.e. if they share the same TShape. Locations and Orientations may differ.)#"  , py::arg("theOther")
          )
        .def("IsSame",
             (bool (TopoDS_Shape::*)(  const TopoDS_Shape &  ) const) static_cast<bool (TopoDS_Shape::*)(  const TopoDS_Shape &  ) const>(&TopoDS_Shape::IsSame),
             R"#(Returns True if two shapes are same, i.e. if they share the same TShape with the same Locations. Orientations may differ.)#"  , py::arg("theOther")
          )
        .def("IsEqual",
             (bool (TopoDS_Shape::*)(  const TopoDS_Shape &  ) const) static_cast<bool (TopoDS_Shape::*)(  const TopoDS_Shape &  ) const>(&TopoDS_Shape::IsEqual),
             R"#(Returns True if two shapes are equal, i.e. if they share the same TShape with the same Locations and Orientations.)#"  , py::arg("theOther")
          )
        .def("IsNotEqual",
             (bool (TopoDS_Shape::*)(  const TopoDS_Shape &  ) const) static_cast<bool (TopoDS_Shape::*)(  const TopoDS_Shape &  ) const>(&TopoDS_Shape::IsNotEqual),
             R"#(Negation of the IsEqual method.)#"  , py::arg("theOther")
          )
        .def("EmptyCopy",
             (void (TopoDS_Shape::*)() ) static_cast<void (TopoDS_Shape::*)() >(&TopoDS_Shape::EmptyCopy),
             R"#(Replace <me> by a new Shape with the same Orientation and Location and a new TShape with the same geometry and no sub-shapes.)#" 
          )
        .def("EmptyCopied",
             (TopoDS_Shape (TopoDS_Shape::*)() const) static_cast<TopoDS_Shape (TopoDS_Shape::*)() const>(&TopoDS_Shape::EmptyCopied),
             R"#(Returns a new Shape with the same Orientation and Location and a new TShape with the same geometry and no sub-shapes.)#" 
          )
        .def("TShape",
             (void (TopoDS_Shape::*)(  const handle<TopoDS_TShape> &  ) ) static_cast<void (TopoDS_Shape::*)(  const handle<TopoDS_TShape> &  ) >(&TopoDS_Shape::TShape),
             R"#()#"  , py::arg("theTShape")
          )
        .def("DumpJson",
             (void (TopoDS_Shape::*)( Standard_OStream & ,  int  ) const) static_cast<void (TopoDS_Shape::*)( Standard_OStream & ,  int  ) const>(&TopoDS_Shape::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
        .def("__bool__",
             []( const TopoDS_Shape & self ){ return !self.IsNull();},
             R"#(Check if shape is not Null)#"
          )
        .def("_address",
             []( const TopoDS_Shape & self ){ return reinterpret_cast<uintptr_t>(&self);},
             R"#(Get the instance address)#"
          )
        .def("__hash__",
             []( const TopoDS_Shape & self ){ return std::hash<TopoDS_Shape>{}(self);},
             R"#(Get the instance hash)#"
          )
        .def_static("_from_address",
                    []( const uintptr_t addr ){ return reinterpret_cast<TopoDS_Shape*>(addr);},
                    R"#(Cast an address to a shape)#"
, py::arg("address")          )
    // properties
    // methods returning by ref wrapped as properties
       .def("Location",
             ( const TopLoc_Location & (TopoDS_Shape::*)() const) static_cast< const TopLoc_Location & (TopoDS_Shape::*)() const>(&TopoDS_Shape::Location),
             R"#(Returns the shape local coordinate system.)#"
             
         )
       .def("TShape",
             ( const handle<TopoDS_TShape> & (TopoDS_Shape::*)() const) static_cast< const handle<TopoDS_TShape> & (TopoDS_Shape::*)() const>(&TopoDS_Shape::TShape),
             R"#(Returns a handle to the actual shape implementation.)#"
             
         )
;

    // Class TopoDS_TShape from ./opencascade/TopoDS_TShape.hxx
    klass = m.attr("TopoDS_TShape");


    // nested enums
        py::enum_<TopoDS_TShape::BitLayout>(klass, "BitLayout_e", R"#(Bit layout for compact state storage. Bits 0-3 store the TopAbs_ShapeEnum value (0-8). Bits 4-11 store boolean flags. Bits 12-15 are reserved for future use.)#")
            .value("Bits_ShapeType_Mask", TopoDS_TShape::BitLayout::Bits_ShapeType_Mask)
            .value("Bits_ShapeType_Shift", TopoDS_TShape::BitLayout::Bits_ShapeType_Shift)
            .value("Bit_Free", TopoDS_TShape::BitLayout::Bit_Free)
            .value("Bit_Modified", TopoDS_TShape::BitLayout::Bit_Modified)
            .value("Bit_Checked", TopoDS_TShape::BitLayout::Bit_Checked)
            .value("Bit_Orientable", TopoDS_TShape::BitLayout::Bit_Orientable)
            .value("Bit_Closed", TopoDS_TShape::BitLayout::Bit_Closed)
            .value("Bit_Infinite", TopoDS_TShape::BitLayout::Bit_Infinite)
            .value("Bit_Convex", TopoDS_TShape::BitLayout::Bit_Convex)
            .value("Bit_Locked", TopoDS_TShape::BitLayout::Bit_Locked)
            .value("Bits_Reserved", TopoDS_TShape::BitLayout::Bits_Reserved);

    static_cast<py::class_<TopoDS_TShape ,opencascade::handle<TopoDS_TShape> ,Py_TopoDS_TShape , Standard_Transient >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("Free",
             (bool (TopoDS_TShape::*)() const) static_cast<bool (TopoDS_TShape::*)() const>(&TopoDS_TShape::Free),
             R"#(Returns the free flag.)#" 
          )
        .def("Free",
             (void (TopoDS_TShape::*)( bool  ) ) static_cast<void (TopoDS_TShape::*)( bool  ) >(&TopoDS_TShape::Free),
             R"#(Sets the free flag.)#"  , py::arg("theIsFree")
          )
        .def("Locked",
             (bool (TopoDS_TShape::*)() const) static_cast<bool (TopoDS_TShape::*)() const>(&TopoDS_TShape::Locked),
             R"#(Returns the locked flag.)#" 
          )
        .def("Locked",
             (void (TopoDS_TShape::*)( bool  ) ) static_cast<void (TopoDS_TShape::*)( bool  ) >(&TopoDS_TShape::Locked),
             R"#(Sets the locked flag.)#"  , py::arg("theIsLocked")
          )
        .def("Modified",
             (bool (TopoDS_TShape::*)() const) static_cast<bool (TopoDS_TShape::*)() const>(&TopoDS_TShape::Modified),
             R"#(Returns the modification flag.)#" 
          )
        .def("Modified",
             (void (TopoDS_TShape::*)( bool  ) ) static_cast<void (TopoDS_TShape::*)( bool  ) >(&TopoDS_TShape::Modified),
             R"#(Sets the modification flag.)#"  , py::arg("theIsModified")
          )
        .def("Checked",
             (bool (TopoDS_TShape::*)() const) static_cast<bool (TopoDS_TShape::*)() const>(&TopoDS_TShape::Checked),
             R"#(Returns the checked flag.)#" 
          )
        .def("Checked",
             (void (TopoDS_TShape::*)( bool  ) ) static_cast<void (TopoDS_TShape::*)( bool  ) >(&TopoDS_TShape::Checked),
             R"#(Sets the checked flag.)#"  , py::arg("theIsChecked")
          )
        .def("Orientable",
             (bool (TopoDS_TShape::*)() const) static_cast<bool (TopoDS_TShape::*)() const>(&TopoDS_TShape::Orientable),
             R"#(Returns the orientability flag.)#" 
          )
        .def("Orientable",
             (void (TopoDS_TShape::*)( bool  ) ) static_cast<void (TopoDS_TShape::*)( bool  ) >(&TopoDS_TShape::Orientable),
             R"#(Sets the orientability flag.)#"  , py::arg("theIsOrientable")
          )
        .def("Closed",
             (bool (TopoDS_TShape::*)() const) static_cast<bool (TopoDS_TShape::*)() const>(&TopoDS_TShape::Closed),
             R"#(Returns the closedness flag.)#" 
          )
        .def("Closed",
             (void (TopoDS_TShape::*)( bool  ) ) static_cast<void (TopoDS_TShape::*)( bool  ) >(&TopoDS_TShape::Closed),
             R"#(Sets the closedness flag.)#"  , py::arg("theIsClosed")
          )
        .def("Infinite",
             (bool (TopoDS_TShape::*)() const) static_cast<bool (TopoDS_TShape::*)() const>(&TopoDS_TShape::Infinite),
             R"#(Returns the infinity flag.)#" 
          )
        .def("Infinite",
             (void (TopoDS_TShape::*)( bool  ) ) static_cast<void (TopoDS_TShape::*)( bool  ) >(&TopoDS_TShape::Infinite),
             R"#(Sets the infinity flag.)#"  , py::arg("theIsInfinite")
          )
        .def("Convex",
             (bool (TopoDS_TShape::*)() const) static_cast<bool (TopoDS_TShape::*)() const>(&TopoDS_TShape::Convex),
             R"#(Returns the convexness flag.)#" 
          )
        .def("Convex",
             (void (TopoDS_TShape::*)( bool  ) ) static_cast<void (TopoDS_TShape::*)( bool  ) >(&TopoDS_TShape::Convex),
             R"#(Sets the convexness flag.)#"  , py::arg("theIsConvex")
          )
        .def("ShapeType",
             (TopAbs_ShapeEnum (TopoDS_TShape::*)() const) static_cast<TopAbs_ShapeEnum (TopoDS_TShape::*)() const>(&TopoDS_TShape::ShapeType),
             R"#(Returns the type as a term of the ShapeEnum enum: VERTEX, EDGE, WIRE, FACE, SHELL, SOLID, COMPSOLID, COMPOUND. The type is embedded in the lower 4 bits of the state.)#" 
          )
        .def("EmptyCopy",
             (handle<TopoDS_TShape> (TopoDS_TShape::*)() const) static_cast<handle<TopoDS_TShape> (TopoDS_TShape::*)() const>(&TopoDS_TShape::EmptyCopy),
             R"#(Returns a copy of the TShape with no sub-shapes.)#" 
          )
        .def("NbChildren",
             (int (TopoDS_TShape::*)() const) static_cast<int (TopoDS_TShape::*)() const>(&TopoDS_TShape::NbChildren),
             R"#(Returns the number of direct sub-shapes (children).)#" 
          )
        .def("DumpJson",
             (void (TopoDS_TShape::*)( Standard_OStream & ,  int  ) const) static_cast<void (TopoDS_TShape::*)( Standard_OStream & ,  int  ) const>(&TopoDS_TShape::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TopoDS_TShape::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TopoDS_TShape::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TopoDS_TShape::*)() const) static_cast< const handle<Standard_Type> & (TopoDS_TShape::*)() const>(&TopoDS_TShape::DynamicType),
             R"#()#"
             
         )
;

    // Class TopoDS_CompSolid from ./opencascade/TopoDS_CompSolid.hxx
    klass = m.attr("TopoDS_CompSolid");


    // nested enums

    static_cast<py::class_<TopoDS_CompSolid , shared_ptr<TopoDS_CompSolid>  , TopoDS_Shape >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class TopoDS_Compound from ./opencascade/TopoDS_Compound.hxx
    klass = m.attr("TopoDS_Compound");


    // nested enums

    static_cast<py::class_<TopoDS_Compound , shared_ptr<TopoDS_Compound>  , TopoDS_Shape >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class TopoDS_Edge from ./opencascade/TopoDS_Edge.hxx
    klass = m.attr("TopoDS_Edge");


    // nested enums

    static_cast<py::class_<TopoDS_Edge , shared_ptr<TopoDS_Edge>  , TopoDS_Shape >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class TopoDS_Face from ./opencascade/TopoDS_Face.hxx
    klass = m.attr("TopoDS_Face");


    // nested enums

    static_cast<py::class_<TopoDS_Face , shared_ptr<TopoDS_Face>  , TopoDS_Shape >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class TopoDS_Shell from ./opencascade/TopoDS_Shell.hxx
    klass = m.attr("TopoDS_Shell");


    // nested enums

    static_cast<py::class_<TopoDS_Shell , shared_ptr<TopoDS_Shell>  , TopoDS_Shape >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class TopoDS_Solid from ./opencascade/TopoDS_Solid.hxx
    klass = m.attr("TopoDS_Solid");


    // nested enums

    static_cast<py::class_<TopoDS_Solid , shared_ptr<TopoDS_Solid>  , TopoDS_Shape >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class TopoDS_TCompSolid from ./opencascade/TopoDS_TCompSolid.hxx
    klass = m.attr("TopoDS_TCompSolid");


    // nested enums

    static_cast<py::class_<TopoDS_TCompSolid ,opencascade::handle<TopoDS_TCompSolid>  , TopoDS_TShape >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("EmptyCopy",
             (handle<TopoDS_TShape> (TopoDS_TCompSolid::*)() const) static_cast<handle<TopoDS_TShape> (TopoDS_TCompSolid::*)() const>(&TopoDS_TCompSolid::EmptyCopy),
             R"#(Returns an empty TCompSolid.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TopoDS_TCompSolid::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TopoDS_TCompSolid::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TopoDS_TCompSolid::*)() const) static_cast< const handle<Standard_Type> & (TopoDS_TCompSolid::*)() const>(&TopoDS_TCompSolid::DynamicType),
             R"#()#"
             
         )
;

    // Class TopoDS_TCompound from ./opencascade/TopoDS_TCompound.hxx
    klass = m.attr("TopoDS_TCompound");


    // nested enums

    static_cast<py::class_<TopoDS_TCompound ,opencascade::handle<TopoDS_TCompound>  , TopoDS_TShape >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("EmptyCopy",
             (handle<TopoDS_TShape> (TopoDS_TCompound::*)() const) static_cast<handle<TopoDS_TShape> (TopoDS_TCompound::*)() const>(&TopoDS_TCompound::EmptyCopy),
             R"#(Returns an empty TCompound.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TopoDS_TCompound::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TopoDS_TCompound::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TopoDS_TCompound::*)() const) static_cast< const handle<Standard_Type> & (TopoDS_TCompound::*)() const>(&TopoDS_TCompound::DynamicType),
             R"#()#"
             
         )
;

    // Class TopoDS_TEdge from ./opencascade/TopoDS_TEdge.hxx
    klass = m.attr("TopoDS_TEdge");


    // nested enums

    static_cast<py::class_<TopoDS_TEdge ,opencascade::handle<TopoDS_TEdge>  , TopoDS_TShape >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("EmptyCopy",
             (handle<TopoDS_TShape> (TopoDS_TEdge::*)() const) static_cast<handle<TopoDS_TShape> (TopoDS_TEdge::*)() const>(&TopoDS_TEdge::EmptyCopy),
             R"#(Returns an empty TEdge.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TopoDS_TEdge::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TopoDS_TEdge::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TopoDS_TEdge::*)() const) static_cast< const handle<Standard_Type> & (TopoDS_TEdge::*)() const>(&TopoDS_TEdge::DynamicType),
             R"#()#"
             
         )
;

    // Class TopoDS_TFace from ./opencascade/TopoDS_TFace.hxx
    klass = m.attr("TopoDS_TFace");


    // nested enums

    static_cast<py::class_<TopoDS_TFace ,opencascade::handle<TopoDS_TFace>  , TopoDS_TShape >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("EmptyCopy",
             (handle<TopoDS_TShape> (TopoDS_TFace::*)() const) static_cast<handle<TopoDS_TShape> (TopoDS_TFace::*)() const>(&TopoDS_TFace::EmptyCopy),
             R"#(Returns an empty TFace.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TopoDS_TFace::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TopoDS_TFace::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TopoDS_TFace::*)() const) static_cast< const handle<Standard_Type> & (TopoDS_TFace::*)() const>(&TopoDS_TFace::DynamicType),
             R"#()#"
             
         )
;

    // Class TopoDS_TShell from ./opencascade/TopoDS_TShell.hxx
    klass = m.attr("TopoDS_TShell");


    // nested enums

    static_cast<py::class_<TopoDS_TShell ,opencascade::handle<TopoDS_TShell>  , TopoDS_TShape >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("EmptyCopy",
             (handle<TopoDS_TShape> (TopoDS_TShell::*)() const) static_cast<handle<TopoDS_TShape> (TopoDS_TShell::*)() const>(&TopoDS_TShell::EmptyCopy),
             R"#(Returns an empty TShell.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TopoDS_TShell::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TopoDS_TShell::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TopoDS_TShell::*)() const) static_cast< const handle<Standard_Type> & (TopoDS_TShell::*)() const>(&TopoDS_TShell::DynamicType),
             R"#()#"
             
         )
;

    // Class TopoDS_TSolid from ./opencascade/TopoDS_TSolid.hxx
    klass = m.attr("TopoDS_TSolid");


    // nested enums

    static_cast<py::class_<TopoDS_TSolid ,opencascade::handle<TopoDS_TSolid>  , TopoDS_TShape >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("EmptyCopy",
             (handle<TopoDS_TShape> (TopoDS_TSolid::*)() const) static_cast<handle<TopoDS_TShape> (TopoDS_TSolid::*)() const>(&TopoDS_TSolid::EmptyCopy),
             R"#(Returns an empty TSolid.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TopoDS_TSolid::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TopoDS_TSolid::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TopoDS_TSolid::*)() const) static_cast< const handle<Standard_Type> & (TopoDS_TSolid::*)() const>(&TopoDS_TSolid::DynamicType),
             R"#()#"
             
         )
;

    // Class TopoDS_TVertex from ./opencascade/TopoDS_TVertex.hxx
    klass = m.attr("TopoDS_TVertex");


    // nested enums

    static_cast<py::class_<TopoDS_TVertex ,opencascade::handle<TopoDS_TVertex> ,Py_TopoDS_TVertex , TopoDS_TShape >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TopoDS_TVertex::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TopoDS_TVertex::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TopoDS_TVertex::*)() const) static_cast< const handle<Standard_Type> & (TopoDS_TVertex::*)() const>(&TopoDS_TVertex::DynamicType),
             R"#()#"
             
         )
;

    // Class TopoDS_TWire from ./opencascade/TopoDS_TWire.hxx
    klass = m.attr("TopoDS_TWire");


    // nested enums

    static_cast<py::class_<TopoDS_TWire ,opencascade::handle<TopoDS_TWire>  , TopoDS_TShape >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("EmptyCopy",
             (handle<TopoDS_TShape> (TopoDS_TWire::*)() const) static_cast<handle<TopoDS_TShape> (TopoDS_TWire::*)() const>(&TopoDS_TWire::EmptyCopy),
             R"#(Returns an empty TWire.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TopoDS_TWire::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TopoDS_TWire::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TopoDS_TWire::*)() const) static_cast< const handle<Standard_Type> & (TopoDS_TWire::*)() const>(&TopoDS_TWire::DynamicType),
             R"#()#"
             
         )
;

    // Class TopoDS_Vertex from ./opencascade/TopoDS_Vertex.hxx
    klass = m.attr("TopoDS_Vertex");


    // nested enums

    static_cast<py::class_<TopoDS_Vertex , shared_ptr<TopoDS_Vertex>  , TopoDS_Shape >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class TopoDS_Wire from ./opencascade/TopoDS_Wire.hxx
    klass = m.attr("TopoDS_Wire");


    // nested enums

    static_cast<py::class_<TopoDS_Wire , shared_ptr<TopoDS_Wire>  , TopoDS_Shape >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

// functions
auto mTopoDS = static_cast<py::module>(m.attr("TopoDS"));

// ./opencascade/TopoDS.hxx
    mTopoDS.def("Vertex",
          ( const TopoDS_Vertex & (*)(  const TopoDS_Shape &  ))  static_cast< const TopoDS_Vertex & (*)(  const TopoDS_Shape &  )>(&TopoDS::Vertex),
          R"#(Casts shape theShape to the more specialized return type, Vertex.)#"  , py::arg("theShape")
          );
    mTopoDS.def("Vertex",
          (TopoDS_Vertex & (*)( TopoDS_Shape &  ))  static_cast<TopoDS_Vertex & (*)( TopoDS_Shape &  )>(&TopoDS::Vertex),
          R"#(Casts shape theShape to the more specialized return type, Vertex.)#"  , py::arg("theShape")
          );
    mTopoDS.def("Edge",
          ( const TopoDS_Edge & (*)(  const TopoDS_Shape &  ))  static_cast< const TopoDS_Edge & (*)(  const TopoDS_Shape &  )>(&TopoDS::Edge),
          R"#(Casts shape theShape to the more specialized return type, Edge.)#"  , py::arg("theShape")
          );
    mTopoDS.def("Edge",
          (TopoDS_Edge & (*)( TopoDS_Shape &  ))  static_cast<TopoDS_Edge & (*)( TopoDS_Shape &  )>(&TopoDS::Edge),
          R"#(Casts shape theShape to the more specialized return type, Edge.)#"  , py::arg("theShape")
          );
    mTopoDS.def("Wire",
          ( const TopoDS_Wire & (*)(  const TopoDS_Shape &  ))  static_cast< const TopoDS_Wire & (*)(  const TopoDS_Shape &  )>(&TopoDS::Wire),
          R"#(Casts shape theShape to the more specialized return type, Wire.)#"  , py::arg("theShape")
          );
    mTopoDS.def("Wire",
          (TopoDS_Wire & (*)( TopoDS_Shape &  ))  static_cast<TopoDS_Wire & (*)( TopoDS_Shape &  )>(&TopoDS::Wire),
          R"#(Casts shape theShape to the more specialized return type, Wire.)#"  , py::arg("theShape")
          );
    mTopoDS.def("Face",
          ( const TopoDS_Face & (*)(  const TopoDS_Shape &  ))  static_cast< const TopoDS_Face & (*)(  const TopoDS_Shape &  )>(&TopoDS::Face),
          R"#(Casts shape theShape to the more specialized return type, Face.)#"  , py::arg("theShape")
          );
    mTopoDS.def("Face",
          (TopoDS_Face & (*)( TopoDS_Shape &  ))  static_cast<TopoDS_Face & (*)( TopoDS_Shape &  )>(&TopoDS::Face),
          R"#(Casts shape theShape to the more specialized return type, Face.)#"  , py::arg("theShape")
          );
    mTopoDS.def("Shell",
          ( const TopoDS_Shell & (*)(  const TopoDS_Shape &  ))  static_cast< const TopoDS_Shell & (*)(  const TopoDS_Shape &  )>(&TopoDS::Shell),
          R"#(Casts shape theShape to the more specialized return type, Shell.)#"  , py::arg("theShape")
          );
    mTopoDS.def("Shell",
          (TopoDS_Shell & (*)( TopoDS_Shape &  ))  static_cast<TopoDS_Shell & (*)( TopoDS_Shape &  )>(&TopoDS::Shell),
          R"#(Casts shape theShape to the more specialized return type, Shell.)#"  , py::arg("theShape")
          );
    mTopoDS.def("Solid",
          ( const TopoDS_Solid & (*)(  const TopoDS_Shape &  ))  static_cast< const TopoDS_Solid & (*)(  const TopoDS_Shape &  )>(&TopoDS::Solid),
          R"#(Casts shape theShape to the more specialized return type, Solid.)#"  , py::arg("theShape")
          );
    mTopoDS.def("Solid",
          (TopoDS_Solid & (*)( TopoDS_Shape &  ))  static_cast<TopoDS_Solid & (*)( TopoDS_Shape &  )>(&TopoDS::Solid),
          R"#(Casts shape theShape to the more specialized return type, Solid.)#"  , py::arg("theShape")
          );
    mTopoDS.def("CompSolid",
          ( const TopoDS_CompSolid & (*)(  const TopoDS_Shape &  ))  static_cast< const TopoDS_CompSolid & (*)(  const TopoDS_Shape &  )>(&TopoDS::CompSolid),
          R"#(Casts shape theShape to the more specialized return type, CompSolid.)#"  , py::arg("theShape")
          );
    mTopoDS.def("CompSolid",
          (TopoDS_CompSolid & (*)( TopoDS_Shape &  ))  static_cast<TopoDS_CompSolid & (*)( TopoDS_Shape &  )>(&TopoDS::CompSolid),
          R"#(Casts shape theShape to the more specialized return type, CompSolid.)#"  , py::arg("theShape")
          );
    mTopoDS.def("Compound",
          ( const TopoDS_Compound & (*)(  const TopoDS_Shape &  ))  static_cast< const TopoDS_Compound & (*)(  const TopoDS_Shape &  )>(&TopoDS::Compound),
          R"#(Casts shape theShape to the more specialized return type, Compound.)#"  , py::arg("theShape")
          );
    mTopoDS.def("Compound",
          (TopoDS_Compound & (*)( TopoDS_Shape &  ))  static_cast<TopoDS_Compound & (*)( TopoDS_Shape &  )>(&TopoDS::Compound),
          R"#(Casts shape theShape to the more specialized return type, Compound.)#"  , py::arg("theShape")
          );
// ./opencascade/TopoDS_AlertAttribute.hxx
// ./opencascade/TopoDS_AlertWithShape.hxx
// ./opencascade/TopoDS_Builder.hxx
// ./opencascade/TopoDS_CompSolid.hxx
// ./opencascade/TopoDS_Compound.hxx
// ./opencascade/TopoDS_Edge.hxx
// ./opencascade/TopoDS_Face.hxx
// ./opencascade/TopoDS_FrozenShape.hxx
// ./opencascade/TopoDS_HShape.hxx
// ./opencascade/TopoDS_Iterator.hxx
// ./opencascade/TopoDS_LockedShape.hxx
// ./opencascade/TopoDS_Shape.hxx
// ./opencascade/TopoDS_Shell.hxx
// ./opencascade/TopoDS_Solid.hxx
// ./opencascade/TopoDS_TCompSolid.hxx
// ./opencascade/TopoDS_TCompound.hxx
// ./opencascade/TopoDS_TEdge.hxx
// ./opencascade/TopoDS_TFace.hxx
// ./opencascade/TopoDS_TShape.hxx
// ./opencascade/TopoDS_TShell.hxx
// ./opencascade/TopoDS_TSolid.hxx
// ./opencascade/TopoDS_TVertex.hxx
// ./opencascade/TopoDS_TWire.hxx
// ./opencascade/TopoDS_UnCompatibleShapes.hxx
// ./opencascade/TopoDS_Vertex.hxx
// ./opencascade/TopoDS_Wire.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions
register_occ_exception<TopoDS_FrozenShape>(m, "TopoDS_FrozenShape");
register_occ_exception<TopoDS_LockedShape>(m, "TopoDS_LockedShape");
register_occ_exception<TopoDS_UnCompatibleShapes>(m, "TopoDS_UnCompatibleShapes");

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
