
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_Camera.hxx>
#include <V3d_View.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <SelectMgr_EntityOwner.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom_Line.hxx>
#include <Geom_Axis1Placement.hxx>
#include <Geom_Axis2Placement.hxx>
#include <Prs3d_LineAspect.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <SelectMgr_EntityOwner.hxx>
#include <TopoDS_Edge.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <SelectMgr_EntityOwner.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_ArrayOfSegments.hxx>
#include <Graphic3d_ArrayOfTriangles.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom_Circle.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <StdSelect_BRepOwner.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <SelectMgr_EntityOwner.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <V3d_Viewer.hxx>
#include <V3d_View.hxx>
#include <Prs3d_LineAspect.hxx>
#include <Prs3d_BasicAspect.hxx>
#include <TopoDS_Shape.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AIS_InteractiveContext.hxx>
#include <Prs3d_BasicAspect.hxx>
#include <V3d_View.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom_Line.hxx>
#include <Geom_Point.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom_Plane.hxx>
#include <Geom_Axis2Placement.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AIS_Line.hxx>
#include <AIS_Point.hxx>
#include <Geom_Plane.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom_Point.hxx>
#include <TopoDS_Vertex.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TColStd_HPackedMapOfInteger.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <SelectMgr_Filter.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <SelectMgr_EntityOwner.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Font_TextFormatter.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_Texture2D.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Poly_Triangulation.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom_Axis2Placement.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <SelectMgr_EntityOwner.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AIS_Animation.hxx>
#include <AIS_AnimationCamera.hxx>
#include <AIS_InteractiveObject.hxx>
#include <AIS_InteractiveContext.hxx>
#include <AIS_Point.hxx>
#include <AIS_RubberBand.hxx>
#include <AIS_XRTrackedDevice.hxx>
#include <SelectMgr_EntityOwner.hxx>
#include <V3d_View.hxx>
#include <WNT_HIDSpaceMouse.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <AIS_AnimationCamera.hxx>
#include <Graphic3d_ArrayOfTriangles.hxx>
#include <V3d_View.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_ArrayOfTriangles.hxx>
#include <Image_Texture.hxx>

// module includes
#include <AIS.hxx>
#include <AIS_Animation.hxx>
#include <AIS_AnimationAxisRotation.hxx>
#include <AIS_AnimationCamera.hxx>
#include <AIS_AnimationObject.hxx>
#include <AIS_AnimationTimer.hxx>
#include <AIS_AttributeFilter.hxx>
#include <AIS_Axis.hxx>
#include <AIS_BadEdgeFilter.hxx>
#include <AIS_BaseAnimationObject.hxx>
#include <AIS_C0RegularityFilter.hxx>
#include <AIS_CameraFrustum.hxx>
#include <AIS_Circle.hxx>
#include <AIS_ColoredDrawer.hxx>
#include <AIS_ColoredShape.hxx>
#include <AIS_ColorScale.hxx>
#include <AIS_ConnectedInteractive.hxx>
#include <AIS_DisplayMode.hxx>
#include <AIS_DisplayStatus.hxx>
#include <AIS_DragAction.hxx>
#include <AIS_ExclusionFilter.hxx>
#include <AIS_GlobalStatus.hxx>
#include <AIS_GraphicTool.hxx>
#include <AIS_InteractiveContext.hxx>
#include <AIS_InteractiveObject.hxx>
#include <AIS_KindOfInteractive.hxx>
#include <AIS_LightSource.hxx>
#include <AIS_Line.hxx>
#include <AIS_Manipulator.hxx>
#include <AIS_ManipulatorMode.hxx>
#include <AIS_ManipulatorOwner.hxx>
#include <AIS_MediaPlayer.hxx>
#include <AIS_MouseGesture.hxx>
#include <AIS_MultipleConnectedInteractive.hxx>
#include <AIS_NavigationMode.hxx>
#include <AIS_Plane.hxx>
#include <AIS_PlaneTrihedron.hxx>
#include <AIS_Point.hxx>
#include <AIS_PointCloud.hxx>
#include <AIS_RotationMode.hxx>
#include <AIS_RubberBand.hxx>
#include <AIS_Selection.hxx>
#include <AIS_SelectionModesConcurrency.hxx>
#include <AIS_SelectionScheme.hxx>
#include <AIS_SelectStatus.hxx>
#include <AIS_Shape.hxx>
#include <AIS_SignatureFilter.hxx>
#include <AIS_StatusOfDetection.hxx>
#include <AIS_StatusOfPick.hxx>
#include <AIS_TextLabel.hxx>
#include <AIS_TexturedShape.hxx>
#include <AIS_Triangulation.hxx>
#include <AIS_Trihedron.hxx>
#include <AIS_TrihedronOwner.hxx>
#include <AIS_TrihedronSelectionMode.hxx>
#include <AIS_TypeFilter.hxx>
#include <AIS_TypeOfAttribute.hxx>
#include <AIS_TypeOfAxis.hxx>
#include <AIS_TypeOfIso.hxx>
#include <AIS_TypeOfPlane.hxx>
#include <AIS_ViewController.hxx>
#include <AIS_ViewCube.hxx>
#include <AIS_ViewInputBuffer.hxx>
#include <AIS_WalkDelta.hxx>
#include <AIS_XRTrackedDevice.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module
#include <Media_PlayerContext.hxx>
#include <WNT_HIDSpaceMouse.hxx>
auto OptionsForAttach = [](){return AIS_Manipulator::OptionsForAttach();};

// Module definiiton
void register_AIS(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("AIS"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes
    class Py_AIS_InteractiveObject : public AIS_InteractiveObject{
    public:
        using AIS_InteractiveObject::AIS_InteractiveObject;


        // public pure virtual

        void ComputeSelection( const handle<SelectMgr_Selection> & theSelection, const int theMode) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,SelectMgr_SelectableObject,ComputeSelection,theSelection,theMode) };

        // protected pure virtual

        void Compute( const handle<PrsMgr_PresentationManager> & thePrsMgr, const handle<Prs3d_Presentation> & thePrs, const int theMode) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,PrsMgr_PresentableObject,Compute,thePrsMgr,thePrs,theMode) };

        // private pure virtual

    };

// classes

    // Class AIS from ./opencascade/AIS.hxx
    klass = m.attr("AIS");

    // default constructor
    register_default_constructor<AIS , shared_ptr<AIS>>(m,"AIS");

    // nested enums

    static_cast<py::class_<AIS , shared_ptr<AIS>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class AIS_Animation from ./opencascade/AIS_Animation.hxx
    klass = m.attr("AIS_Animation");


    // nested enums

    static_cast<py::class_<AIS_Animation ,opencascade::handle<AIS_Animation>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const TCollection_AsciiString & >()  , py::arg("theAnimationName") )
    // custom constructors
    // methods
        .def("StartPts",
             (double (AIS_Animation::*)() const) static_cast<double (AIS_Animation::*)() const>(&AIS_Animation::StartPts),
             R"#(Returns start time of the animation in the timeline)#" 
          )
        .def("SetStartPts",
             (void (AIS_Animation::*)(  const double  ) ) static_cast<void (AIS_Animation::*)(  const double  ) >(&AIS_Animation::SetStartPts),
             R"#(Sets time limits for animation in the animation timeline)#"  , py::arg("thePtsStart")
          )
        .def("Duration",
             (double (AIS_Animation::*)() const) static_cast<double (AIS_Animation::*)() const>(&AIS_Animation::Duration),
             R"#(Returns duration of the animation in the timeline)#" 
          )
        .def("UpdateTotalDuration",
             (void (AIS_Animation::*)() ) static_cast<void (AIS_Animation::*)() >(&AIS_Animation::UpdateTotalDuration),
             R"#(Update total duration considering all animations on timeline.)#" 
          )
        .def("HasOwnDuration",
             (bool (AIS_Animation::*)() const) static_cast<bool (AIS_Animation::*)() const>(&AIS_Animation::HasOwnDuration),
             R"#(Return true if duration is defined.)#" 
          )
        .def("OwnDuration",
             (double (AIS_Animation::*)() const) static_cast<double (AIS_Animation::*)() const>(&AIS_Animation::OwnDuration),
             R"#(Returns own duration of the animation in the timeline)#" 
          )
        .def("SetOwnDuration",
             (void (AIS_Animation::*)(  const double  ) ) static_cast<void (AIS_Animation::*)(  const double  ) >(&AIS_Animation::SetOwnDuration),
             R"#(Defines duration of the animation.)#"  , py::arg("theDuration")
          )
        .def("Add",
             (void (AIS_Animation::*)(  const handle<AIS_Animation> &  ) ) static_cast<void (AIS_Animation::*)(  const handle<AIS_Animation> &  ) >(&AIS_Animation::Add),
             R"#(Add single animation to the timeline.)#"  , py::arg("theAnimation")
          )
        .def("Clear",
             (void (AIS_Animation::*)() ) static_cast<void (AIS_Animation::*)() >(&AIS_Animation::Clear),
             R"#(Clear animation timeline - remove all animations from it.)#" 
          )
        .def("Find",
             (handle<AIS_Animation> (AIS_Animation::*)(  const TCollection_AsciiString &  ) const) static_cast<handle<AIS_Animation> (AIS_Animation::*)(  const TCollection_AsciiString &  ) const>(&AIS_Animation::Find),
             R"#(Return the child animation with the given name.)#"  , py::arg("theAnimationName")
          )
        .def("Remove",
             (bool (AIS_Animation::*)(  const handle<AIS_Animation> &  ) ) static_cast<bool (AIS_Animation::*)(  const handle<AIS_Animation> &  ) >(&AIS_Animation::Remove),
             R"#(Remove the child animation.)#"  , py::arg("theAnimation")
          )
        .def("Replace",
             (bool (AIS_Animation::*)(  const handle<AIS_Animation> & ,   const handle<AIS_Animation> &  ) ) static_cast<bool (AIS_Animation::*)(  const handle<AIS_Animation> & ,   const handle<AIS_Animation> &  ) >(&AIS_Animation::Replace),
             R"#(Replace the child animation.)#"  , py::arg("theAnimationOld"),  py::arg("theAnimationNew")
          )
        .def("CopyFrom",
             (void (AIS_Animation::*)(  const handle<AIS_Animation> &  ) ) static_cast<void (AIS_Animation::*)(  const handle<AIS_Animation> &  ) >(&AIS_Animation::CopyFrom),
             R"#(Clears own children and then copy child animations from another object. Copy also Start Time and Duration values.)#"  , py::arg("theOther")
          )
        .def("StartTimer",
             (void (AIS_Animation::*)(  const double ,   const double ,   const bool ,   const bool  ) ) static_cast<void (AIS_Animation::*)(  const double ,   const double ,   const bool ,   const bool  ) >(&AIS_Animation::StartTimer),
             R"#(Start animation with internally defined timer instance. Calls ::Start() internally.)#"  , py::arg("theStartPts"),  py::arg("thePlaySpeed"),  py::arg("theToUpdate"),  py::arg("theToStopTimer")=static_cast< const bool>(false)
          )
        .def("UpdateTimer",
             (double (AIS_Animation::*)() ) static_cast<double (AIS_Animation::*)() >(&AIS_Animation::UpdateTimer),
             R"#(Update single frame of animation, update timer state)#" 
          )
        .def("ElapsedTime",
             (double (AIS_Animation::*)() const) static_cast<double (AIS_Animation::*)() const>(&AIS_Animation::ElapsedTime),
             R"#(Return elapsed time.)#" 
          )
        .def("SetTimer",
             (void (AIS_Animation::*)(  const handle<Media_Timer> &  ) ) static_cast<void (AIS_Animation::*)(  const handle<Media_Timer> &  ) >(&AIS_Animation::SetTimer),
             R"#(Set playback timer.)#"  , py::arg("theTimer")
          )
        .def("Start",
             (void (AIS_Animation::*)(  const bool  ) ) static_cast<void (AIS_Animation::*)(  const bool  ) >(&AIS_Animation::Start),
             R"#(Start animation. This method changes status of the animation to Started. This status defines whether animation is to be performed in the timeline or not.)#"  , py::arg("theToUpdate")
          )
        .def("Pause",
             (void (AIS_Animation::*)() ) static_cast<void (AIS_Animation::*)() >(&AIS_Animation::Pause),
             R"#(Pause the process timeline.)#" 
          )
        .def("Stop",
             (void (AIS_Animation::*)() ) static_cast<void (AIS_Animation::*)() >(&AIS_Animation::Stop),
             R"#(Stop animation. This method changed status of the animation to Stopped. This status shows that animation will not be performed in the timeline or it is finished.)#" 
          )
        .def("IsStopped",
             (bool (AIS_Animation::*)() ) static_cast<bool (AIS_Animation::*)() >(&AIS_Animation::IsStopped),
             R"#(Check if animation is to be performed in the animation timeline.)#" 
          )
        .def("Update",
             (bool (AIS_Animation::*)(  const double  ) ) static_cast<bool (AIS_Animation::*)(  const double  ) >(&AIS_Animation::Update),
             R"#(Update single frame of animation, update timer state)#"  , py::arg("thePts")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_Animation::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_Animation::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_Animation::*)() const) static_cast< const handle<Standard_Type> & (AIS_Animation::*)() const>(&AIS_Animation::DynamicType),
             R"#()#"
             
         )
       .def("Name",
             ( const TCollection_AsciiString & (AIS_Animation::*)() const) static_cast< const TCollection_AsciiString & (AIS_Animation::*)() const>(&AIS_Animation::Name),
             R"#(Animation name.)#"
             
         )
       .def("Children",
             ( const NCollection_Sequence<handle<AIS_Animation>> & (AIS_Animation::*)() const) static_cast< const NCollection_Sequence<handle<AIS_Animation>> & (AIS_Animation::*)() const>(&AIS_Animation::Children),
             R"#(Return sequence of child animations.)#"
             
         )
       .def("Timer",
             ( const handle<Media_Timer> & (AIS_Animation::*)() const) static_cast< const handle<Media_Timer> & (AIS_Animation::*)() const>(&AIS_Animation::Timer),
             R"#(Return playback timer.)#"
             
         )
;

    // Class AIS_AnimationProgress from ./opencascade/AIS_Animation.hxx
    klass = m.attr("AIS_AnimationProgress");


    // nested enums

    static_cast<py::class_<AIS_AnimationProgress , shared_ptr<AIS_AnimationProgress>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
        .def_readwrite("Pts", &AIS_AnimationProgress::Pts)
        .def_readwrite("LocalPts", &AIS_AnimationProgress::LocalPts)
        .def_readwrite("LocalNormalized", &AIS_AnimationProgress::LocalNormalized)
    // methods returning by ref wrapped as properties
;

    // Class AIS_AttributeFilter from ./opencascade/AIS_AttributeFilter.hxx
    klass = m.attr("AIS_AttributeFilter");


    // nested enums

    static_cast<py::class_<AIS_AttributeFilter ,opencascade::handle<AIS_AttributeFilter>  , SelectMgr_Filter >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const Quantity_NameOfColor >()  , py::arg("aCol") )
        .def(py::init<  const double >()  , py::arg("aWidth") )
    // custom constructors
    // methods
        .def("HasColor",
             (bool (AIS_AttributeFilter::*)() const) static_cast<bool (AIS_AttributeFilter::*)() const>(&AIS_AttributeFilter::HasColor),
             R"#(Indicates that the Interactive Object has the color setting specified by the argument aCol at construction time.)#" 
          )
        .def("HasWidth",
             (bool (AIS_AttributeFilter::*)() const) static_cast<bool (AIS_AttributeFilter::*)() const>(&AIS_AttributeFilter::HasWidth),
             R"#(Indicates that the Interactive Object has the width setting specified by the argument aWidth at construction time.)#" 
          )
        .def("SetColor",
             (void (AIS_AttributeFilter::*)(  const Quantity_NameOfColor  ) ) static_cast<void (AIS_AttributeFilter::*)(  const Quantity_NameOfColor  ) >(&AIS_AttributeFilter::SetColor),
             R"#(Sets the color.)#"  , py::arg("theCol")
          )
        .def("SetWidth",
             (void (AIS_AttributeFilter::*)(  const double  ) ) static_cast<void (AIS_AttributeFilter::*)(  const double  ) >(&AIS_AttributeFilter::SetWidth),
             R"#(Sets the line width.)#"  , py::arg("theWidth")
          )
        .def("UnsetColor",
             (void (AIS_AttributeFilter::*)() ) static_cast<void (AIS_AttributeFilter::*)() >(&AIS_AttributeFilter::UnsetColor),
             R"#(Removes the setting for color from the filter.)#" 
          )
        .def("UnsetWidth",
             (void (AIS_AttributeFilter::*)() ) static_cast<void (AIS_AttributeFilter::*)() >(&AIS_AttributeFilter::UnsetWidth),
             R"#(Removes the setting for width from the filter.)#" 
          )
        .def("IsOk",
             (bool (AIS_AttributeFilter::*)(  const handle<SelectMgr_EntityOwner> &  ) const) static_cast<bool (AIS_AttributeFilter::*)(  const handle<SelectMgr_EntityOwner> &  ) const>(&AIS_AttributeFilter::IsOk),
             R"#(Indicates that the selected Interactive Object passes the filter. The owner, anObj, can be either direct or user. A direct owner is the corresponding construction element, whereas a user is the compound shape of which the entity forms a part. If the Interactive Object returns true when detected by the Local Context selector through the mouse, the object is kept; if not, it is rejected.)#"  , py::arg("anObj")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_AttributeFilter::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_AttributeFilter::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_AttributeFilter::*)() const) static_cast< const handle<Standard_Type> & (AIS_AttributeFilter::*)() const>(&AIS_AttributeFilter::DynamicType),
             R"#()#"
             
         )
;

    // Class AIS_BadEdgeFilter from ./opencascade/AIS_BadEdgeFilter.hxx
    klass = m.attr("AIS_BadEdgeFilter");


    // nested enums

    static_cast<py::class_<AIS_BadEdgeFilter ,opencascade::handle<AIS_BadEdgeFilter>  , SelectMgr_Filter >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ActsOn",
             (bool (AIS_BadEdgeFilter::*)(  const TopAbs_ShapeEnum  ) const) static_cast<bool (AIS_BadEdgeFilter::*)(  const TopAbs_ShapeEnum  ) const>(&AIS_BadEdgeFilter::ActsOn),
             R"#()#"  , py::arg("aType")
          )
        .def("IsOk",
             (bool (AIS_BadEdgeFilter::*)(  const handle<SelectMgr_EntityOwner> &  ) const) static_cast<bool (AIS_BadEdgeFilter::*)(  const handle<SelectMgr_EntityOwner> &  ) const>(&AIS_BadEdgeFilter::IsOk),
             R"#()#"  , py::arg("EO")
          )
        .def("SetContour",
             (void (AIS_BadEdgeFilter::*)(  const int  ) ) static_cast<void (AIS_BadEdgeFilter::*)(  const int  ) >(&AIS_BadEdgeFilter::SetContour),
             R"#(sets <myContour> with current contour. used by IsOk.)#"  , py::arg("Index")
          )
        .def("AddEdge",
             (void (AIS_BadEdgeFilter::*)(  const TopoDS_Edge & ,   const int  ) ) static_cast<void (AIS_BadEdgeFilter::*)(  const TopoDS_Edge & ,   const int  ) >(&AIS_BadEdgeFilter::AddEdge),
             R"#(Adds an edge to the list of non-selectable edges.)#"  , py::arg("anEdge"),  py::arg("Index")
          )
        .def("RemoveEdges",
             (void (AIS_BadEdgeFilter::*)(  const int  ) ) static_cast<void (AIS_BadEdgeFilter::*)(  const int  ) >(&AIS_BadEdgeFilter::RemoveEdges),
             R"#(removes from the list of non-selectable edges all edges in the contour <Index>.)#"  , py::arg("Index")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_BadEdgeFilter::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_BadEdgeFilter::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_BadEdgeFilter::*)() const) static_cast< const handle<Standard_Type> & (AIS_BadEdgeFilter::*)() const>(&AIS_BadEdgeFilter::DynamicType),
             R"#()#"
             
         )
;

    // Class AIS_C0RegularityFilter from ./opencascade/AIS_C0RegularityFilter.hxx
    klass = m.attr("AIS_C0RegularityFilter");


    // nested enums

    static_cast<py::class_<AIS_C0RegularityFilter ,opencascade::handle<AIS_C0RegularityFilter>  , SelectMgr_Filter >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("aShape") )
    // custom constructors
    // methods
        .def("ActsOn",
             (bool (AIS_C0RegularityFilter::*)(  const TopAbs_ShapeEnum  ) const) static_cast<bool (AIS_C0RegularityFilter::*)(  const TopAbs_ShapeEnum  ) const>(&AIS_C0RegularityFilter::ActsOn),
             R"#()#"  , py::arg("aType")
          )
        .def("IsOk",
             (bool (AIS_C0RegularityFilter::*)(  const handle<SelectMgr_EntityOwner> &  ) const) static_cast<bool (AIS_C0RegularityFilter::*)(  const handle<SelectMgr_EntityOwner> &  ) const>(&AIS_C0RegularityFilter::IsOk),
             R"#()#"  , py::arg("EO")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_C0RegularityFilter::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_C0RegularityFilter::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_C0RegularityFilter::*)() const) static_cast< const handle<Standard_Type> & (AIS_C0RegularityFilter::*)() const>(&AIS_C0RegularityFilter::DynamicType),
             R"#()#"
             
         )
;

    // Class AIS_ColoredDrawer from ./opencascade/AIS_ColoredDrawer.hxx
    klass = m.attr("AIS_ColoredDrawer");


    // nested enums

    static_cast<py::class_<AIS_ColoredDrawer ,opencascade::handle<AIS_ColoredDrawer>  , Prs3d_Drawer >>(klass)
    // constructors
        .def(py::init<  const handle<Prs3d_Drawer> & >()  , py::arg("theLink") )
    // custom constructors
    // methods
        .def("IsHidden",
             (bool (AIS_ColoredDrawer::*)() const) static_cast<bool (AIS_ColoredDrawer::*)() const>(&AIS_ColoredDrawer::IsHidden),
             R"#()#" 
          )
        .def("SetHidden",
             (void (AIS_ColoredDrawer::*)(  const bool  ) ) static_cast<void (AIS_ColoredDrawer::*)(  const bool  ) >(&AIS_ColoredDrawer::SetHidden),
             R"#()#"  , py::arg("theToHide")
          )
        .def("HasOwnMaterial",
             (bool (AIS_ColoredDrawer::*)() const) static_cast<bool (AIS_ColoredDrawer::*)() const>(&AIS_ColoredDrawer::HasOwnMaterial),
             R"#()#" 
          )
        .def("UnsetOwnMaterial",
             (void (AIS_ColoredDrawer::*)() ) static_cast<void (AIS_ColoredDrawer::*)() >(&AIS_ColoredDrawer::UnsetOwnMaterial),
             R"#()#" 
          )
        .def("SetOwnMaterial",
             (void (AIS_ColoredDrawer::*)() ) static_cast<void (AIS_ColoredDrawer::*)() >(&AIS_ColoredDrawer::SetOwnMaterial),
             R"#()#" 
          )
        .def("HasOwnColor",
             (bool (AIS_ColoredDrawer::*)() const) static_cast<bool (AIS_ColoredDrawer::*)() const>(&AIS_ColoredDrawer::HasOwnColor),
             R"#()#" 
          )
        .def("UnsetOwnColor",
             (void (AIS_ColoredDrawer::*)() ) static_cast<void (AIS_ColoredDrawer::*)() >(&AIS_ColoredDrawer::UnsetOwnColor),
             R"#()#" 
          )
        .def("SetOwnColor",
             (void (AIS_ColoredDrawer::*)(  const Quantity_Color &  ) ) static_cast<void (AIS_ColoredDrawer::*)(  const Quantity_Color &  ) >(&AIS_ColoredDrawer::SetOwnColor),
             R"#()#"  , py::arg("arg0")
          )
        .def("HasOwnTransparency",
             (bool (AIS_ColoredDrawer::*)() const) static_cast<bool (AIS_ColoredDrawer::*)() const>(&AIS_ColoredDrawer::HasOwnTransparency),
             R"#()#" 
          )
        .def("UnsetOwnTransparency",
             (void (AIS_ColoredDrawer::*)() ) static_cast<void (AIS_ColoredDrawer::*)() >(&AIS_ColoredDrawer::UnsetOwnTransparency),
             R"#()#" 
          )
        .def("SetOwnTransparency",
             (void (AIS_ColoredDrawer::*)( double  ) ) static_cast<void (AIS_ColoredDrawer::*)( double  ) >(&AIS_ColoredDrawer::SetOwnTransparency),
             R"#()#"  , py::arg("arg0")
          )
        .def("HasOwnWidth",
             (bool (AIS_ColoredDrawer::*)() const) static_cast<bool (AIS_ColoredDrawer::*)() const>(&AIS_ColoredDrawer::HasOwnWidth),
             R"#()#" 
          )
        .def("UnsetOwnWidth",
             (void (AIS_ColoredDrawer::*)() ) static_cast<void (AIS_ColoredDrawer::*)() >(&AIS_ColoredDrawer::UnsetOwnWidth),
             R"#()#" 
          )
        .def("SetOwnWidth",
             (void (AIS_ColoredDrawer::*)(  const double  ) ) static_cast<void (AIS_ColoredDrawer::*)(  const double  ) >(&AIS_ColoredDrawer::SetOwnWidth),
             R"#()#"  , py::arg("arg0")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_ColoredDrawer::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_ColoredDrawer::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
        .def_readwrite("myIsHidden", &AIS_ColoredDrawer::myIsHidden)
        .def_readwrite("myHasOwnMaterial", &AIS_ColoredDrawer::myHasOwnMaterial)
        .def_readwrite("myHasOwnColor", &AIS_ColoredDrawer::myHasOwnColor)
        .def_readwrite("myHasOwnTransp", &AIS_ColoredDrawer::myHasOwnTransp)
        .def_readwrite("myHasOwnWidth", &AIS_ColoredDrawer::myHasOwnWidth)
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_ColoredDrawer::*)() const) static_cast< const handle<Standard_Type> & (AIS_ColoredDrawer::*)() const>(&AIS_ColoredDrawer::DynamicType),
             R"#()#"
             
         )
;

    // Class AIS_ExclusionFilter from ./opencascade/AIS_ExclusionFilter.hxx
    klass = m.attr("AIS_ExclusionFilter");


    // nested enums

    static_cast<py::class_<AIS_ExclusionFilter ,opencascade::handle<AIS_ExclusionFilter>  , SelectMgr_Filter >>(klass)
    // constructors
        .def(py::init<  const AIS_KindOfInteractive, const bool >()  , py::arg("TypeToExclude"),  py::arg("ExclusionFlagOn")=static_cast< const bool>(true) )
        .def(py::init<  const AIS_KindOfInteractive, const int, const bool >()  , py::arg("TypeToExclude"),  py::arg("SignatureInType"),  py::arg("ExclusionFlagOn")=static_cast< const bool>(true) )
        .def(py::init<  const bool >()  , py::arg("ExclusionFlagOn")=static_cast< const bool>(true) )
    // custom constructors
    // methods
        .def("IsOk",
             (bool (AIS_ExclusionFilter::*)(  const handle<SelectMgr_EntityOwner> &  ) const) static_cast<bool (AIS_ExclusionFilter::*)(  const handle<SelectMgr_EntityOwner> &  ) const>(&AIS_ExclusionFilter::IsOk),
             R"#()#"  , py::arg("anObj")
          )
        .def("Add",
             (bool (AIS_ExclusionFilter::*)(  const AIS_KindOfInteractive  ) ) static_cast<bool (AIS_ExclusionFilter::*)(  const AIS_KindOfInteractive  ) >(&AIS_ExclusionFilter::Add),
             R"#(Adds the type TypeToExclude to the list of types.)#"  , py::arg("TypeToExclude")
          )
        .def("Add",
             (bool (AIS_ExclusionFilter::*)(  const AIS_KindOfInteractive ,   const int  ) ) static_cast<bool (AIS_ExclusionFilter::*)(  const AIS_KindOfInteractive ,   const int  ) >(&AIS_ExclusionFilter::Add),
             R"#()#"  , py::arg("TypeToExclude"),  py::arg("SignatureInType")
          )
        .def("Remove",
             (bool (AIS_ExclusionFilter::*)(  const AIS_KindOfInteractive  ) ) static_cast<bool (AIS_ExclusionFilter::*)(  const AIS_KindOfInteractive  ) >(&AIS_ExclusionFilter::Remove),
             R"#()#"  , py::arg("TypeToExclude")
          )
        .def("Remove",
             (bool (AIS_ExclusionFilter::*)(  const AIS_KindOfInteractive ,   const int  ) ) static_cast<bool (AIS_ExclusionFilter::*)(  const AIS_KindOfInteractive ,   const int  ) >(&AIS_ExclusionFilter::Remove),
             R"#()#"  , py::arg("TypeToExclude"),  py::arg("SignatureInType")
          )
        .def("Clear",
             (void (AIS_ExclusionFilter::*)() ) static_cast<void (AIS_ExclusionFilter::*)() >(&AIS_ExclusionFilter::Clear),
             R"#()#" 
          )
        .def("IsExclusionFlagOn",
             (bool (AIS_ExclusionFilter::*)() const) static_cast<bool (AIS_ExclusionFilter::*)() const>(&AIS_ExclusionFilter::IsExclusionFlagOn),
             R"#()#" 
          )
        .def("SetExclusionFlag",
             (void (AIS_ExclusionFilter::*)(  const bool  ) ) static_cast<void (AIS_ExclusionFilter::*)(  const bool  ) >(&AIS_ExclusionFilter::SetExclusionFlag),
             R"#()#"  , py::arg("theStatus")
          )
        .def("IsStored",
             (bool (AIS_ExclusionFilter::*)(  const AIS_KindOfInteractive  ) const) static_cast<bool (AIS_ExclusionFilter::*)(  const AIS_KindOfInteractive  ) const>(&AIS_ExclusionFilter::IsStored),
             R"#()#"  , py::arg("aType")
          )
        .def("ListOfStoredTypes",
             (void (AIS_ExclusionFilter::*)( NCollection_List<int> &  ) const) static_cast<void (AIS_ExclusionFilter::*)( NCollection_List<int> &  ) const>(&AIS_ExclusionFilter::ListOfStoredTypes),
             R"#()#"  , py::arg("TheList")
          )
        .def("ListOfSignature",
             (void (AIS_ExclusionFilter::*)(  const AIS_KindOfInteractive ,  NCollection_List<int> &  ) const) static_cast<void (AIS_ExclusionFilter::*)(  const AIS_KindOfInteractive ,  NCollection_List<int> &  ) const>(&AIS_ExclusionFilter::ListOfSignature),
             R"#()#"  , py::arg("aType"),  py::arg("TheStoredList")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_ExclusionFilter::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_ExclusionFilter::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_ExclusionFilter::*)() const) static_cast< const handle<Standard_Type> & (AIS_ExclusionFilter::*)() const>(&AIS_ExclusionFilter::DynamicType),
             R"#()#"
             
         )
;

    // Class AIS_GlobalStatus from ./opencascade/AIS_GlobalStatus.hxx
    klass = m.attr("AIS_GlobalStatus");


    // nested enums

    static_cast<py::class_<AIS_GlobalStatus ,opencascade::handle<AIS_GlobalStatus>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("DisplayMode",
             (int (AIS_GlobalStatus::*)() const) static_cast<int (AIS_GlobalStatus::*)() const>(&AIS_GlobalStatus::DisplayMode),
             R"#(Returns the display mode.)#" 
          )
        .def("SetDisplayMode",
             (void (AIS_GlobalStatus::*)(  const int  ) ) static_cast<void (AIS_GlobalStatus::*)(  const int  ) >(&AIS_GlobalStatus::SetDisplayMode),
             R"#(Sets display mode.)#"  , py::arg("theMode")
          )
        .def("IsHilighted",
             (bool (AIS_GlobalStatus::*)() const) static_cast<bool (AIS_GlobalStatus::*)() const>(&AIS_GlobalStatus::IsHilighted),
             R"#(Returns TRUE if object is highlighted)#" 
          )
        .def("SetHilightStatus",
             (void (AIS_GlobalStatus::*)(  const bool  ) ) static_cast<void (AIS_GlobalStatus::*)(  const bool  ) >(&AIS_GlobalStatus::SetHilightStatus),
             R"#(Sets highlighted state.)#"  , py::arg("theStatus")
          )
        .def("SetHilightStyle",
             (void (AIS_GlobalStatus::*)(  const handle<Prs3d_Drawer> &  ) ) static_cast<void (AIS_GlobalStatus::*)(  const handle<Prs3d_Drawer> &  ) >(&AIS_GlobalStatus::SetHilightStyle),
             R"#(Changes applied highlight style for a particular object)#"  , py::arg("theStyle")
          )
        .def("IsSModeIn",
             (bool (AIS_GlobalStatus::*)( int  ) const) static_cast<bool (AIS_GlobalStatus::*)( int  ) const>(&AIS_GlobalStatus::IsSModeIn),
             R"#(Return TRUE if selection mode was registered.)#"  , py::arg("theMode")
          )
        .def("AddSelectionMode",
             (bool (AIS_GlobalStatus::*)(  const int  ) ) static_cast<bool (AIS_GlobalStatus::*)(  const int  ) >(&AIS_GlobalStatus::AddSelectionMode),
             R"#(Add selection mode.)#"  , py::arg("theMode")
          )
        .def("RemoveSelectionMode",
             (bool (AIS_GlobalStatus::*)(  const int  ) ) static_cast<bool (AIS_GlobalStatus::*)(  const int  ) >(&AIS_GlobalStatus::RemoveSelectionMode),
             R"#(Remove selection mode.)#"  , py::arg("theMode")
          )
        .def("ClearSelectionModes",
             (void (AIS_GlobalStatus::*)() ) static_cast<void (AIS_GlobalStatus::*)() >(&AIS_GlobalStatus::ClearSelectionModes),
             R"#(Remove all selection modes.)#" 
          )
        .def("IsSubIntensityOn",
             (bool (AIS_GlobalStatus::*)() const) static_cast<bool (AIS_GlobalStatus::*)() const>(&AIS_GlobalStatus::IsSubIntensityOn),
             R"#()#" 
          )
        .def("SetSubIntensity",
             (void (AIS_GlobalStatus::*)( bool  ) ) static_cast<void (AIS_GlobalStatus::*)( bool  ) >(&AIS_GlobalStatus::SetSubIntensity),
             R"#()#"  , py::arg("theIsOn")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_GlobalStatus::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_GlobalStatus::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_GlobalStatus::*)() const) static_cast< const handle<Standard_Type> & (AIS_GlobalStatus::*)() const>(&AIS_GlobalStatus::DynamicType),
             R"#()#"
             
         )
       .def("HilightStyle",
             ( const handle<Prs3d_Drawer> & (AIS_GlobalStatus::*)() const) static_cast< const handle<Prs3d_Drawer> & (AIS_GlobalStatus::*)() const>(&AIS_GlobalStatus::HilightStyle),
             R"#(Returns applied highlight style for a particular object)#"
             
         )
       .def("SelectionModes",
             ( const NCollection_List<int> & (AIS_GlobalStatus::*)() const) static_cast< const NCollection_List<int> & (AIS_GlobalStatus::*)() const>(&AIS_GlobalStatus::SelectionModes),
             R"#(Returns active selection modes of the object.)#"
             
         )
;

    // Class AIS_GraphicTool from ./opencascade/AIS_GraphicTool.hxx
    klass = m.attr("AIS_GraphicTool");

    // default constructor
    register_default_constructor<AIS_GraphicTool , shared_ptr<AIS_GraphicTool>>(m,"AIS_GraphicTool");

    // nested enums

    static_cast<py::class_<AIS_GraphicTool , shared_ptr<AIS_GraphicTool>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("GetLineColor_s",
                    (Quantity_NameOfColor (*)(  const handle<Prs3d_Drawer> & ,   const AIS_TypeOfAttribute  ) ) static_cast<Quantity_NameOfColor (*)(  const handle<Prs3d_Drawer> & ,   const AIS_TypeOfAttribute  ) >(&AIS_GraphicTool::GetLineColor),
                    R"#()#"  , py::arg("aDrawer"),  py::arg("TheTypeOfAttributes")
          )
        .def_static("GetLineColor_s",
                    (void (*)(  const handle<Prs3d_Drawer> & ,   const AIS_TypeOfAttribute ,  Quantity_Color &  ) ) static_cast<void (*)(  const handle<Prs3d_Drawer> & ,   const AIS_TypeOfAttribute ,  Quantity_Color &  ) >(&AIS_GraphicTool::GetLineColor),
                    R"#()#"  , py::arg("aDrawer"),  py::arg("TheTypeOfAttributes"),  py::arg("TheLineColor")
          )
        .def_static("GetLineWidth_s",
                    (double (*)(  const handle<Prs3d_Drawer> & ,   const AIS_TypeOfAttribute  ) ) static_cast<double (*)(  const handle<Prs3d_Drawer> & ,   const AIS_TypeOfAttribute  ) >(&AIS_GraphicTool::GetLineWidth),
                    R"#()#"  , py::arg("aDrawer"),  py::arg("TheTypeOfAttributes")
          )
        .def_static("GetLineType_s",
                    (Aspect_TypeOfLine (*)(  const handle<Prs3d_Drawer> & ,   const AIS_TypeOfAttribute  ) ) static_cast<Aspect_TypeOfLine (*)(  const handle<Prs3d_Drawer> & ,   const AIS_TypeOfAttribute  ) >(&AIS_GraphicTool::GetLineType),
                    R"#()#"  , py::arg("aDrawer"),  py::arg("TheTypeOfAttributes")
          )
        .def_static("GetInteriorColor_s",
                    (Quantity_NameOfColor (*)(  const handle<Prs3d_Drawer> &  ) ) static_cast<Quantity_NameOfColor (*)(  const handle<Prs3d_Drawer> &  ) >(&AIS_GraphicTool::GetInteriorColor),
                    R"#()#"  , py::arg("aDrawer")
          )
        .def_static("GetInteriorColor_s",
                    (void (*)(  const handle<Prs3d_Drawer> & ,  Quantity_Color &  ) ) static_cast<void (*)(  const handle<Prs3d_Drawer> & ,  Quantity_Color &  ) >(&AIS_GraphicTool::GetInteriorColor),
                    R"#()#"  , py::arg("aDrawer"),  py::arg("aColor")
          )
        .def_static("GetMaterial_s",
                    (Graphic3d_MaterialAspect (*)(  const handle<Prs3d_Drawer> &  ) ) static_cast<Graphic3d_MaterialAspect (*)(  const handle<Prs3d_Drawer> &  ) >(&AIS_GraphicTool::GetMaterial),
                    R"#()#"  , py::arg("aDrawer")
          )
    // static methods using call by reference i.s.o. return
        .def_static("GetLineAtt_s",
            []( const handle<Prs3d_Drawer> & aDrawer, const AIS_TypeOfAttribute TheTypeOfAttributes,Quantity_NameOfColor & aCol,Aspect_TypeOfLine & aTyp ){
                double  aWidth;

                AIS_GraphicTool::GetLineAtt(aDrawer,TheTypeOfAttributes,aCol,aWidth,aTyp);
                
return std::make_tuple(aWidth); },
            R"#()#"  , py::arg("aDrawer"),  py::arg("TheTypeOfAttributes"),  py::arg("aCol"),  py::arg("aTyp")
          )
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class AIS_InteractiveContext from ./opencascade/AIS_InteractiveContext.hxx
    klass = m.attr("AIS_InteractiveContext");


    // nested enums

    static_cast<py::class_<AIS_InteractiveContext ,opencascade::handle<AIS_InteractiveContext>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const handle<V3d_Viewer> & >()  , py::arg("MainViewer") )
    // custom constructors
    // methods
        .def("DisplayStatus",
             (PrsMgr_DisplayStatus (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) const) static_cast<PrsMgr_DisplayStatus (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) const>(&AIS_InteractiveContext::DisplayStatus),
             R"#(Returns the display status of the entity anIobj. This will be one of the following: - AIS_DS_Displayed displayed in main viewer - AIS_DS_Erased hidden in main viewer - AIS_DS_Temporary temporarily displayed - AIS_DS_None nowhere displayed.)#"  , py::arg("anIobj")
          )
        .def("Status",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,  TCollection_ExtendedString &  ) const) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,  TCollection_ExtendedString &  ) const>(&AIS_InteractiveContext::Status),
             R"#(Returns the status of the Interactive Context for the view of the Interactive Object.)#"  , py::arg("anObj"),  py::arg("astatus")
          )
        .def("IsDisplayed",
             (bool (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) const) static_cast<bool (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) const>(&AIS_InteractiveContext::IsDisplayed),
             R"#(Returns true if Object is displayed in the interactive context.)#"  , py::arg("anIobj")
          )
        .def("IsDisplayed",
             (bool (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const int  ) const) static_cast<bool (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const int  ) const>(&AIS_InteractiveContext::IsDisplayed),
             R"#()#"  , py::arg("aniobj"),  py::arg("aMode")
          )
        .def("SetAutoActivateSelection",
             (void (AIS_InteractiveContext::*)(  const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const bool  ) >(&AIS_InteractiveContext::SetAutoActivateSelection),
             R"#(Enable or disable automatic activation of default selection mode while displaying the object.)#"  , py::arg("theIsAuto")
          )
        .def("GetAutoActivateSelection",
             (bool (AIS_InteractiveContext::*)() const) static_cast<bool (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::GetAutoActivateSelection),
             R"#(Manages displaying the new object should also automatically activate default selection mode; TRUE by default.)#" 
          )
        .def("Display",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) >(&AIS_InteractiveContext::Display),
             R"#(Displays the object in this Context using default Display Mode. This will be the object's default display mode, if there is one. Otherwise, it will be the context mode. The Interactive Object's default selection mode is activated if GetAutoActivateSelection() is TRUE. In general, this is 0.)#"  , py::arg("theIObj"),  py::arg("theToUpdateViewer")
          )
        .def("Display",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const int ,   const int ,   const bool ,   const PrsMgr_DisplayStatus  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const int ,   const int ,   const bool ,   const PrsMgr_DisplayStatus  ) >(&AIS_InteractiveContext::Display),
             R"#(Sets status, display mode and selection mode for specified Object If theSelectionMode equals -1, theIObj will not be activated: it will be displayed but will not be selectable.)#"  , py::arg("theIObj"),  py::arg("theDispMode"),  py::arg("theSelectionMode"),  py::arg("theToUpdateViewer"),  py::arg("theDispStatus")=static_cast< const PrsMgr_DisplayStatus>(PrsMgr_DisplayStatus_None)
          )
        .def("Load",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const int  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const int  ) >(&AIS_InteractiveContext::Load),
             R"#(Allows you to load the Interactive Object with a given selection mode, and/or with the desired decomposition option, whether the object is visualized or not. The loaded objects will be selectable but displayable in highlighting only when detected by the Selector.)#"  , py::arg("theObj"),  py::arg("theSelectionMode")=static_cast< const int>(- 1)
          )
        .def("Erase",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) >(&AIS_InteractiveContext::Erase),
             R"#(Hides the object. The object's presentations are simply flagged as invisible and therefore excluded from redrawing. To show hidden objects, use Display().)#"  , py::arg("theIObj"),  py::arg("theToUpdateViewer")
          )
        .def("EraseAll",
             (void (AIS_InteractiveContext::*)(  const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const bool  ) >(&AIS_InteractiveContext::EraseAll),
             R"#(Hides all objects. The object's presentations are simply flagged as invisible and therefore excluded from redrawing. To show all hidden objects, use DisplayAll().)#"  , py::arg("theToUpdateViewer")
          )
        .def("DisplayAll",
             (void (AIS_InteractiveContext::*)(  const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const bool  ) >(&AIS_InteractiveContext::DisplayAll),
             R"#(Displays all hidden objects.)#"  , py::arg("theToUpdateViewer")
          )
        .def("EraseSelected",
             (void (AIS_InteractiveContext::*)(  const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const bool  ) >(&AIS_InteractiveContext::EraseSelected),
             R"#(Hides selected objects. The object's presentations are simply flagged as invisible and therefore excluded from redrawing. To show hidden objects, use Display().)#"  , py::arg("theToUpdateViewer")
          )
        .def("DisplaySelected",
             (void (AIS_InteractiveContext::*)(  const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const bool  ) >(&AIS_InteractiveContext::DisplaySelected),
             R"#(Displays current objects.)#"  , py::arg("theToUpdateViewer")
          )
        .def("ClearPrs",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const int ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const int ,   const bool  ) >(&AIS_InteractiveContext::ClearPrs),
             R"#(Empties the graphic presentation of the mode indexed by aMode. Warning! Removes theIObj. theIObj is still active if it was previously activated.)#"  , py::arg("theIObj"),  py::arg("theMode"),  py::arg("theToUpdateViewer")
          )
        .def("Remove",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) >(&AIS_InteractiveContext::Remove),
             R"#(Removes Object from every viewer.)#"  , py::arg("theIObj"),  py::arg("theToUpdateViewer")
          )
        .def("RemoveAll",
             (void (AIS_InteractiveContext::*)(  const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const bool  ) >(&AIS_InteractiveContext::RemoveAll),
             R"#(Removes all the objects from Context.)#"  , py::arg("theToUpdateViewer")
          )
        .def("Redisplay",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool ,   const bool  ) >(&AIS_InteractiveContext::Redisplay),
             R"#(Recomputes the seen parts presentation of the Object. If theAllModes equals true, all presentations are present in the object even if unseen.)#"  , py::arg("theIObj"),  py::arg("theToUpdateViewer"),  py::arg("theAllModes")=static_cast< const bool>(false)
          )
        .def("Redisplay",
             (void (AIS_InteractiveContext::*)(  const AIS_KindOfInteractive ,   const int ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const AIS_KindOfInteractive ,   const int ,   const bool  ) >(&AIS_InteractiveContext::Redisplay),
             R"#(Recomputes the Prs/Selection of displayed objects of a given type and a given signature. if signature = -1 doesn't take signature criterion.)#"  , py::arg("theTypeOfObject"),  py::arg("theSignature"),  py::arg("theToUpdateViewer")
          )
        .def("RecomputePrsOnly",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool ,   const bool  ) >(&AIS_InteractiveContext::RecomputePrsOnly),
             R"#(Recomputes the displayed presentations, flags the others. Doesn't update presentations.)#"  , py::arg("theIObj"),  py::arg("theToUpdateViewer"),  py::arg("theAllModes")=static_cast< const bool>(false)
          )
        .def("RecomputeSelectionOnly",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) >(&AIS_InteractiveContext::RecomputeSelectionOnly),
             R"#(Recomputes the active selections, flags the others. Doesn't update presentations.)#"  , py::arg("anIObj")
          )
        .def("Update",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) >(&AIS_InteractiveContext::Update),
             R"#(Updates displayed interactive object by checking and recomputing its flagged as "to be recomputed" presentation and selection structures. This method does not force any recomputation on its own. The method recomputes selections even if they are loaded without activation in particular selector.)#"  , py::arg("theIObj"),  py::arg("theUpdateViewer")
          )
        .def("HighlightStyle",
             ( const handle<Prs3d_Drawer> & (AIS_InteractiveContext::*)(  const Prs3d_TypeOfHighlight  ) const) static_cast< const handle<Prs3d_Drawer> & (AIS_InteractiveContext::*)(  const Prs3d_TypeOfHighlight  ) const>(&AIS_InteractiveContext::HighlightStyle),
             R"#(Returns default highlight style settings (could be overridden by PrsMgr_PresentableObject).)#"  , py::arg("theStyleType")
          )
        .def("SetHighlightStyle",
             (void (AIS_InteractiveContext::*)(  const Prs3d_TypeOfHighlight ,   const handle<Prs3d_Drawer> &  ) ) static_cast<void (AIS_InteractiveContext::*)(  const Prs3d_TypeOfHighlight ,   const handle<Prs3d_Drawer> &  ) >(&AIS_InteractiveContext::SetHighlightStyle),
             R"#(Setup highlight style settings. Tip: it is better modifying existing style returned by method HighlightStyle() instead of creating a new Prs3d_Drawer to avoid unexpected results due misconfiguration.)#"  , py::arg("theStyleType"),  py::arg("theStyle")
          )
        .def("SetHighlightStyle",
             (void (AIS_InteractiveContext::*)(  const handle<Prs3d_Drawer> &  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<Prs3d_Drawer> &  ) >(&AIS_InteractiveContext::SetHighlightStyle),
             R"#(Setup the style of dynamic highlighting corresponding to Prs3d_TypeOfHighlight_Selected. This is just a short-cut to SetHighlightStyle(Prs3d_TypeOfHighlight_Dynamic,theStyle).)#"  , py::arg("theStyle")
          )
        .def("SetSelectionStyle",
             (void (AIS_InteractiveContext::*)(  const handle<Prs3d_Drawer> &  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<Prs3d_Drawer> &  ) >(&AIS_InteractiveContext::SetSelectionStyle),
             R"#(Setup the style of selection highlighting. This is just a short-cut to SetHighlightStyle(Prs3d_TypeOfHighlight_Selected,theStyle).)#"  , py::arg("theStyle")
          )
        .def("HighlightStyle",
             (bool (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,  handle<Prs3d_Drawer> &  ) const) static_cast<bool (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,  handle<Prs3d_Drawer> &  ) const>(&AIS_InteractiveContext::HighlightStyle),
             R"#(Returns highlight style of the object if it is marked as highlighted via global status)#"  , py::arg("theObj"),  py::arg("theStyle")
          )
        .def("HighlightStyle",
             (bool (AIS_InteractiveContext::*)(  const handle<SelectMgr_EntityOwner> & ,  handle<Prs3d_Drawer> &  ) const) static_cast<bool (AIS_InteractiveContext::*)(  const handle<SelectMgr_EntityOwner> & ,  handle<Prs3d_Drawer> &  ) const>(&AIS_InteractiveContext::HighlightStyle),
             R"#(Returns highlight style of the owner if it is selected)#"  , py::arg("theOwner"),  py::arg("theStyle")
          )
        .def("IsHilighted",
             (bool (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) const) static_cast<bool (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) const>(&AIS_InteractiveContext::IsHilighted),
             R"#(Returns true if the object is marked as highlighted via its global status)#"  , py::arg("theObj")
          )
        .def("IsHilighted",
             (bool (AIS_InteractiveContext::*)(  const handle<SelectMgr_EntityOwner> &  ) const) static_cast<bool (AIS_InteractiveContext::*)(  const handle<SelectMgr_EntityOwner> &  ) const>(&AIS_InteractiveContext::IsHilighted),
             R"#(Returns true if the owner is marked as selected)#"  , py::arg("theOwner")
          )
        .def("HilightWithColor",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const handle<Prs3d_Drawer> & ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const handle<Prs3d_Drawer> & ,   const bool  ) >(&AIS_InteractiveContext::HilightWithColor),
             R"#(Changes the color of all the lines of the object in view.)#"  , py::arg("theObj"),  py::arg("theStyle"),  py::arg("theToUpdateViewer")
          )
        .def("Unhilight",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) >(&AIS_InteractiveContext::Unhilight),
             R"#(Removes highlighting from the Object.)#"  , py::arg("theIObj"),  py::arg("theToUpdateViewer")
          )
        .def("DisplayPriority",
             (Graphic3d_DisplayPriority (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) const) static_cast<Graphic3d_DisplayPriority (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) const>(&AIS_InteractiveContext::DisplayPriority),
             R"#(Returns the display priority of the Object.)#"  , py::arg("theIObj")
          )
        .def("SetDisplayPriority",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const Graphic3d_DisplayPriority  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const Graphic3d_DisplayPriority  ) >(&AIS_InteractiveContext::SetDisplayPriority),
             R"#(Sets the display priority of the seen parts presentation of the Object.)#"  , py::arg("theIObj"),  py::arg("thePriority")
          )
        .def("SetDisplayPriority",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const int  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const int  ) >(&AIS_InteractiveContext::SetDisplayPriority),
             R"#()#"  , py::arg("theIObj"),  py::arg("thePriority")
          )
        .def("GetZLayer",
             (Graphic3d_ZLayerId (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) const) static_cast<Graphic3d_ZLayerId (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) const>(&AIS_InteractiveContext::GetZLayer),
             R"#(Get Z layer id set for displayed interactive object.)#"  , py::arg("theIObj")
          )
        .def("SetZLayer",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const Graphic3d_ZLayerId  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const Graphic3d_ZLayerId  ) >(&AIS_InteractiveContext::SetZLayer),
             R"#(Set Z layer id for interactive object. The Z layers can be used to display temporarily presentations of some object in front of the other objects in the scene. The ids for Z layers are generated by V3d_Viewer.)#"  , py::arg("theIObj"),  py::arg("theLayerId")
          )
        .def("SetViewAffinity",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const handle<V3d_View> & ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const handle<V3d_View> & ,   const bool  ) >(&AIS_InteractiveContext::SetViewAffinity),
             R"#(Setup object visibility in specified view. Has no effect if object is not displayed in this context.)#"  , py::arg("theIObj"),  py::arg("theView"),  py::arg("theIsVisible")
          )
        .def("DisplayMode",
             (int (AIS_InteractiveContext::*)() const) static_cast<int (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::DisplayMode),
             R"#(Returns the Display Mode setting to be used by default.)#" 
          )
        .def("SetDisplayMode",
             (void (AIS_InteractiveContext::*)(  const int ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const int ,   const bool  ) >(&AIS_InteractiveContext::SetDisplayMode),
             R"#(Sets the display mode of seen Interactive Objects (which have no overridden Display Mode).)#"  , py::arg("theMode"),  py::arg("theToUpdateViewer")
          )
        .def("SetDisplayMode",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const int ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const int ,   const bool  ) >(&AIS_InteractiveContext::SetDisplayMode),
             R"#(Sets the display mode of seen Interactive Objects. theMode provides the display mode index of the entity theIObj.)#"  , py::arg("theIObj"),  py::arg("theMode"),  py::arg("theToUpdateViewer")
          )
        .def("UnsetDisplayMode",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) >(&AIS_InteractiveContext::UnsetDisplayMode),
             R"#(Unsets the display mode of seen Interactive Objects.)#"  , py::arg("theIObj"),  py::arg("theToUpdateViewer")
          )
        .def("SetLocation",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const TopLoc_Location &  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const TopLoc_Location &  ) >(&AIS_InteractiveContext::SetLocation),
             R"#(Puts the location on the initial graphic representation and the selection for the Object.)#"  , py::arg("theObject"),  py::arg("theLocation")
          )
        .def("ResetLocation",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) >(&AIS_InteractiveContext::ResetLocation),
             R"#(Puts the Object back into its initial position.)#"  , py::arg("theObject")
          )
        .def("HasLocation",
             (bool (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) const) static_cast<bool (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) const>(&AIS_InteractiveContext::HasLocation),
             R"#(Returns true if the Object has a location.)#"  , py::arg("theObject")
          )
        .def("Location",
             (TopLoc_Location (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) const) static_cast<TopLoc_Location (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) const>(&AIS_InteractiveContext::Location),
             R"#(Returns the location of the Object.)#"  , py::arg("theObject")
          )
        .def("SetTransformPersistence",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const handle<Graphic3d_TransformPers> &  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const handle<Graphic3d_TransformPers> &  ) >(&AIS_InteractiveContext::SetTransformPersistence),
             R"#(Sets transform persistence.)#"  , py::arg("theObject"),  py::arg("theTrsfPers")
          )
        .def("SetPixelTolerance",
             (void (AIS_InteractiveContext::*)(  const int  ) ) static_cast<void (AIS_InteractiveContext::*)(  const int  ) >(&AIS_InteractiveContext::SetPixelTolerance),
             R"#(Setup pixel tolerance for MoveTo() operation.)#"  , py::arg("thePrecision")=static_cast< const int>(2)
          )
        .def("PixelTolerance",
             (int (AIS_InteractiveContext::*)() const) static_cast<int (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::PixelTolerance),
             R"#(Returns the pixel tolerance, default is 2. Pixel Tolerance extends sensitivity within MoveTo() operation (picking by point) and can be adjusted by application based on user input precision (e.g. screen pixel density, input device precision, etc.).)#" 
          )
        .def("SetSelectionSensitivity",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const int ,   const int  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const int ,   const int  ) >(&AIS_InteractiveContext::SetSelectionSensitivity),
             R"#(Allows to manage sensitivity of a particular selection of interactive object theObject and changes previous sensitivity value of all sensitive entities in selection with theMode to the given theNewSensitivity.)#"  , py::arg("theObject"),  py::arg("theMode"),  py::arg("theNewSensitivity")
          )
        .def("LastActiveView",
             (handle<V3d_View> (AIS_InteractiveContext::*)() const) static_cast<handle<V3d_View> (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::LastActiveView),
             R"#(Returns last active View (argument of MoveTo()/Select() methods).)#" 
          )
        .def("MoveTo",
             (AIS_StatusOfDetection (AIS_InteractiveContext::*)(  const int ,   const int ,   const handle<V3d_View> & ,   const bool  ) ) static_cast<AIS_StatusOfDetection (AIS_InteractiveContext::*)(  const int ,   const int ,   const handle<V3d_View> & ,   const bool  ) >(&AIS_InteractiveContext::MoveTo),
             R"#(Relays mouse position in pixels theXPix and theYPix to the interactive context selectors. This is done by the view theView passing this position to the main viewer and updating it. If theToRedrawOnUpdate is set to false, callee should call RedrawImmediate() to highlight detected object.)#"  , py::arg("theXPix"),  py::arg("theYPix"),  py::arg("theView"),  py::arg("theToRedrawOnUpdate")
          )
        .def("MoveTo",
             (AIS_StatusOfDetection (AIS_InteractiveContext::*)(  const gp_Ax1 & ,   const handle<V3d_View> & ,   const bool  ) ) static_cast<AIS_StatusOfDetection (AIS_InteractiveContext::*)(  const gp_Ax1 & ,   const handle<V3d_View> & ,   const bool  ) >(&AIS_InteractiveContext::MoveTo),
             R"#(Relays axis theAxis to the interactive context selectors. This is done by the view theView passing this axis to the main viewer and updating it. If theToRedrawOnUpdate is set to false, callee should call RedrawImmediate() to highlight detected object.)#"  , py::arg("theAxis"),  py::arg("theView"),  py::arg("theToRedrawOnUpdate")
          )
        .def("ClearDetected",
             (bool (AIS_InteractiveContext::*)( bool  ) ) static_cast<bool (AIS_InteractiveContext::*)( bool  ) >(&AIS_InteractiveContext::ClearDetected),
             R"#(Clears the list of entities detected by MoveTo() and resets dynamic highlighting.)#"  , py::arg("theToRedrawImmediate")=static_cast<bool>(false)
          )
        .def("HasDetected",
             (bool (AIS_InteractiveContext::*)() const) static_cast<bool (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::HasDetected),
             R"#(Returns true if there is a mouse-detected entity in context.)#" 
          )
        .def("DetectedInteractive",
             (handle<AIS_InteractiveObject> (AIS_InteractiveContext::*)() const) static_cast<handle<AIS_InteractiveObject> (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::DetectedInteractive),
             R"#(Returns the interactive objects last detected in context. In general this is just a wrapper for occ::down_cast<AIS_InteractiveObject>(DetectedOwner()->Selectable()).)#" 
          )
        .def("HasDetectedShape",
             (bool (AIS_InteractiveContext::*)() const) static_cast<bool (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::HasDetectedShape),
             R"#(Returns true if there is a detected shape in local context.)#" 
          )
        .def("HasNextDetected",
             (bool (AIS_InteractiveContext::*)() const) static_cast<bool (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::HasNextDetected),
             R"#(returns True if other entities were detected in the last mouse detection)#" 
          )
        .def("HilightNextDetected",
             (int (AIS_InteractiveContext::*)(  const handle<V3d_View> & ,   const bool  ) ) static_cast<int (AIS_InteractiveContext::*)(  const handle<V3d_View> & ,   const bool  ) >(&AIS_InteractiveContext::HilightNextDetected),
             R"#(If more than 1 object is detected by the selector, only the "best" owner is hilighted at the mouse position. This Method allows the user to hilight one after another the other detected entities. If The method select is called, the selected entity will be the hilighted one! WARNING: Loop Method. When all the detected entities have been hilighted, the next call will hilight the first one again.)#"  , py::arg("theView"),  py::arg("theToRedrawImmediate")=static_cast< const bool>(true)
          )
        .def("HilightPreviousDetected",
             (int (AIS_InteractiveContext::*)(  const handle<V3d_View> & ,   const bool  ) ) static_cast<int (AIS_InteractiveContext::*)(  const handle<V3d_View> & ,   const bool  ) >(&AIS_InteractiveContext::HilightPreviousDetected),
             R"#(Same as previous methods in reverse direction.)#"  , py::arg("theView"),  py::arg("theToRedrawImmediate")=static_cast< const bool>(true)
          )
        .def("InitDetected",
             (void (AIS_InteractiveContext::*)() ) static_cast<void (AIS_InteractiveContext::*)() >(&AIS_InteractiveContext::InitDetected),
             R"#(Initialization for iteration through mouse-detected objects in interactive context or in local context if it is opened.)#" 
          )
        .def("MoreDetected",
             (bool (AIS_InteractiveContext::*)() const) static_cast<bool (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::MoreDetected),
             R"#(Return TRUE if there is more mouse-detected objects after the current one during iteration through mouse-detected interactive objects.)#" 
          )
        .def("NextDetected",
             (void (AIS_InteractiveContext::*)() ) static_cast<void (AIS_InteractiveContext::*)() >(&AIS_InteractiveContext::NextDetected),
             R"#(Gets next current object during iteration through mouse-detected interactive objects.)#" 
          )
        .def("DetectedCurrentOwner",
             (handle<SelectMgr_EntityOwner> (AIS_InteractiveContext::*)() const) static_cast<handle<SelectMgr_EntityOwner> (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::DetectedCurrentOwner),
             R"#(Returns the owner from detected list pointed by current iterator position. WARNING! This method is irrelevant to DetectedOwner() which returns last picked Owner regardless of iterator position!)#" 
          )
        .def("AddSelect",
             (AIS_StatusOfPick (AIS_InteractiveContext::*)(  const handle<SelectMgr_EntityOwner> &  ) ) static_cast<AIS_StatusOfPick (AIS_InteractiveContext::*)(  const handle<SelectMgr_EntityOwner> &  ) >(&AIS_InteractiveContext::AddSelect),
             R"#(Adds object in the selection.)#"  , py::arg("theObject")
          )
        .def("AddSelect",
             (AIS_StatusOfPick (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) ) static_cast<AIS_StatusOfPick (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) >(&AIS_InteractiveContext::AddSelect),
             R"#(Adds object in the selection.)#"  , py::arg("theObject")
          )
        .def("SelectRectangle",
             (AIS_StatusOfPick (AIS_InteractiveContext::*)(  const NCollection_Vec2<int> & ,   const NCollection_Vec2<int> & ,   const handle<V3d_View> & ,   const AIS_SelectionScheme  ) ) static_cast<AIS_StatusOfPick (AIS_InteractiveContext::*)(  const NCollection_Vec2<int> & ,   const NCollection_Vec2<int> & ,   const handle<V3d_View> & ,   const AIS_SelectionScheme  ) >(&AIS_InteractiveContext::SelectRectangle),
             R"#(Selects objects within the bounding rectangle. Viewer should be explicitly redrawn after selection.)#"  , py::arg("thePntMin"),  py::arg("thePntMax"),  py::arg("theView"),  py::arg("theSelScheme")=static_cast< const AIS_SelectionScheme>(AIS_SelectionScheme_Replace)
          )
        .def("SelectPolygon",
             (AIS_StatusOfPick (AIS_InteractiveContext::*)(  const NCollection_Array1<gp_Pnt2d> & ,   const handle<V3d_View> & ,   const AIS_SelectionScheme  ) ) static_cast<AIS_StatusOfPick (AIS_InteractiveContext::*)(  const NCollection_Array1<gp_Pnt2d> & ,   const handle<V3d_View> & ,   const AIS_SelectionScheme  ) >(&AIS_InteractiveContext::SelectPolygon),
             R"#(Select everything found in the polygon defined by bounding polyline. Viewer should be explicitly redrawn after selection.)#"  , py::arg("thePolyline"),  py::arg("theView"),  py::arg("theSelScheme")=static_cast< const AIS_SelectionScheme>(AIS_SelectionScheme_Replace)
          )
        .def("SelectPoint",
             (AIS_StatusOfPick (AIS_InteractiveContext::*)(  const NCollection_Vec2<int> & ,   const handle<V3d_View> & ,   const AIS_SelectionScheme  ) ) static_cast<AIS_StatusOfPick (AIS_InteractiveContext::*)(  const NCollection_Vec2<int> & ,   const handle<V3d_View> & ,   const AIS_SelectionScheme  ) >(&AIS_InteractiveContext::SelectPoint),
             R"#(Selects the topmost object picked by the point in the view, Viewer should be explicitly redrawn after selection.)#"  , py::arg("thePnt"),  py::arg("theView"),  py::arg("theSelScheme")=static_cast< const AIS_SelectionScheme>(AIS_SelectionScheme_Replace)
          )
        .def("SelectDetected",
             (AIS_StatusOfPick (AIS_InteractiveContext::*)(  const AIS_SelectionScheme  ) ) static_cast<AIS_StatusOfPick (AIS_InteractiveContext::*)(  const AIS_SelectionScheme  ) >(&AIS_InteractiveContext::SelectDetected),
             R"#(Select and hilights the previous detected via AIS_InteractiveContext::MoveTo() method; unhilights the previous picked. Viewer should be explicitly redrawn after selection.)#"  , py::arg("theSelScheme")=static_cast< const AIS_SelectionScheme>(AIS_SelectionScheme_Replace)
          )
        .def("BoundingBoxOfSelection",
             (Bnd_Box (AIS_InteractiveContext::*)(  const handle<V3d_View> &  ) const) static_cast<Bnd_Box (AIS_InteractiveContext::*)(  const handle<V3d_View> &  ) const>(&AIS_InteractiveContext::BoundingBoxOfSelection),
             R"#(Returns bounding box of selected objects.)#"  , py::arg("theView")
          )
        .def("BoundingBoxOfSelection",
             (Bnd_Box (AIS_InteractiveContext::*)() const) static_cast<Bnd_Box (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::BoundingBoxOfSelection),
             R"#()#" 
          )
        .def("Select",
             (AIS_StatusOfPick (AIS_InteractiveContext::*)(  const NCollection_Array1<handle<SelectMgr_EntityOwner>> & ,   const AIS_SelectionScheme  ) ) static_cast<AIS_StatusOfPick (AIS_InteractiveContext::*)(  const NCollection_Array1<handle<SelectMgr_EntityOwner>> & ,   const AIS_SelectionScheme  ) >(&AIS_InteractiveContext::Select),
             R"#(Sets list of owner selected/deselected using specified selection scheme.)#"  , py::arg("theOwners"),  py::arg("theSelScheme")
          )
        .def("FitSelected",
             (void (AIS_InteractiveContext::*)(  const handle<V3d_View> & ,   const double ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<V3d_View> & ,   const double ,   const bool  ) >(&AIS_InteractiveContext::FitSelected),
             R"#(Fits the view correspondingly to the bounds of selected objects. Infinite objects are ignored if infinite state of AIS_InteractiveObject is set to true.)#"  , py::arg("theView"),  py::arg("theMargin"),  py::arg("theToUpdate")
          )
        .def("FitSelected",
             (void (AIS_InteractiveContext::*)(  const handle<V3d_View> &  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<V3d_View> &  ) >(&AIS_InteractiveContext::FitSelected),
             R"#(Fits the view correspondingly to the bounds of selected objects. Infinite objects are ignored if infinite state of AIS_InteractiveObject is set to true.)#"  , py::arg("theView")
          )
        .def("ToHilightSelected",
             (bool (AIS_InteractiveContext::*)() const) static_cast<bool (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::ToHilightSelected),
             R"#(Return value specified whether selected object must be hilighted when mouse cursor is moved above it)#" 
          )
        .def("SetToHilightSelected",
             (void (AIS_InteractiveContext::*)(  const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const bool  ) >(&AIS_InteractiveContext::SetToHilightSelected),
             R"#(Specify whether selected object must be hilighted when mouse cursor is moved above it (in MoveTo method). By default this value is false and selected object is not hilighted in this case.)#"  , py::arg("toHilight")
          )
        .def("AutomaticHilight",
             (bool (AIS_InteractiveContext::*)() const) static_cast<bool (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::AutomaticHilight),
             R"#(Returns true if the automatic highlight mode is active; TRUE by default.)#" 
          )
        .def("SetAutomaticHilight",
             (void (AIS_InteractiveContext::*)( bool  ) ) static_cast<void (AIS_InteractiveContext::*)( bool  ) >(&AIS_InteractiveContext::SetAutomaticHilight),
             R"#(Sets the highlighting status of detected and selected entities. This function allows you to disconnect the automatic mode.)#"  , py::arg("theStatus")
          )
        .def("SetSelected",
             (void (AIS_InteractiveContext::*)(  const handle<SelectMgr_EntityOwner> & ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<SelectMgr_EntityOwner> & ,   const bool  ) >(&AIS_InteractiveContext::SetSelected),
             R"#(Unhighlights previously selected owners and marks them as not selected. Marks owner given as selected and highlights it. Performs selection filters check.)#"  , py::arg("theOwners"),  py::arg("theToUpdateViewer")
          )
        .def("SetSelected",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) >(&AIS_InteractiveContext::SetSelected),
             R"#(Puts the interactive object aniObj in the list of selected objects. Performs selection filters check.)#"  , py::arg("theObject"),  py::arg("theToUpdateViewer")
          )
        .def("AddOrRemoveSelected",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) >(&AIS_InteractiveContext::AddOrRemoveSelected),
             R"#(Allows to highlight or unhighlight the owner given depending on its selection status)#"  , py::arg("theObject"),  py::arg("theToUpdateViewer")
          )
        .def("SetSelectedState",
             (bool (AIS_InteractiveContext::*)(  const handle<SelectMgr_EntityOwner> & ,   const bool  ) ) static_cast<bool (AIS_InteractiveContext::*)(  const handle<SelectMgr_EntityOwner> & ,   const bool  ) >(&AIS_InteractiveContext::SetSelectedState),
             R"#(Updates Selected state of specified owner without calling HilightSelected(). Has no effect if Selected state is not changed, and redirects to AddOrRemoveSelected() otherwise.)#"  , py::arg("theOwner"),  py::arg("theIsSelected")
          )
        .def("HilightSelected",
             (void (AIS_InteractiveContext::*)(  const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const bool  ) >(&AIS_InteractiveContext::HilightSelected),
             R"#(Highlights selected objects.)#"  , py::arg("theToUpdateViewer")
          )
        .def("UnhilightSelected",
             (void (AIS_InteractiveContext::*)(  const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const bool  ) >(&AIS_InteractiveContext::UnhilightSelected),
             R"#(Removes highlighting from selected objects.)#"  , py::arg("theToUpdateViewer")
          )
        .def("UpdateSelected",
             (void (AIS_InteractiveContext::*)( bool  ) ) static_cast<void (AIS_InteractiveContext::*)( bool  ) >(&AIS_InteractiveContext::UpdateSelected),
             R"#(Updates the list of selected objects: i.e. highlights the newly selected ones and unhighlights previously selected objects.)#"  , py::arg("theToUpdateViewer")
          )
        .def("ClearSelected",
             (void (AIS_InteractiveContext::*)(  const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const bool  ) >(&AIS_InteractiveContext::ClearSelected),
             R"#(Empties previous selected objects in order to get the selected objects detected by the selector using UpdateSelected.)#"  , py::arg("theToUpdateViewer")
          )
        .def("AddOrRemoveSelected",
             (void (AIS_InteractiveContext::*)(  const handle<SelectMgr_EntityOwner> & ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<SelectMgr_EntityOwner> & ,   const bool  ) >(&AIS_InteractiveContext::AddOrRemoveSelected),
             R"#(Allows to highlight or unhighlight the owner given depending on its selection status)#"  , py::arg("theOwner"),  py::arg("theToUpdateViewer")
          )
        .def("IsSelected",
             (bool (AIS_InteractiveContext::*)(  const handle<SelectMgr_EntityOwner> &  ) const) static_cast<bool (AIS_InteractiveContext::*)(  const handle<SelectMgr_EntityOwner> &  ) const>(&AIS_InteractiveContext::IsSelected),
             R"#(Returns true is the owner given is selected)#"  , py::arg("theOwner")
          )
        .def("IsSelected",
             (bool (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) const) static_cast<bool (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) const>(&AIS_InteractiveContext::IsSelected),
             R"#(Returns true is the object given is selected)#"  , py::arg("theObj")
          )
        .def("FirstSelectedObject",
             (handle<AIS_InteractiveObject> (AIS_InteractiveContext::*)() const) static_cast<handle<AIS_InteractiveObject> (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::FirstSelectedObject),
             R"#(Returns the first selected object in the list of current selected.)#" 
          )
        .def("NbSelected",
             (int (AIS_InteractiveContext::*)() ) static_cast<int (AIS_InteractiveContext::*)() >(&AIS_InteractiveContext::NbSelected),
             R"#(Count a number of selected entities using InitSelected()+MoreSelected()+NextSelected() iterator.)#" 
          )
        .def("InitSelected",
             (void (AIS_InteractiveContext::*)() ) static_cast<void (AIS_InteractiveContext::*)() >(&AIS_InteractiveContext::InitSelected),
             R"#(Initializes a scan of the selected objects.)#" 
          )
        .def("MoreSelected",
             (bool (AIS_InteractiveContext::*)() const) static_cast<bool (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::MoreSelected),
             R"#(Returns true if there is another object found by the scan of the list of selected objects.)#" 
          )
        .def("NextSelected",
             (void (AIS_InteractiveContext::*)() ) static_cast<void (AIS_InteractiveContext::*)() >(&AIS_InteractiveContext::NextSelected),
             R"#(Continues the scan to the next object in the list of selected objects.)#" 
          )
        .def("SelectedOwner",
             (handle<SelectMgr_EntityOwner> (AIS_InteractiveContext::*)() const) static_cast<handle<SelectMgr_EntityOwner> (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::SelectedOwner),
             R"#(Returns the owner of the selected entity.)#" 
          )
        .def("SelectedInteractive",
             (handle<AIS_InteractiveObject> (AIS_InteractiveContext::*)() const) static_cast<handle<AIS_InteractiveObject> (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::SelectedInteractive),
             R"#(Return Handle(AIS_InteractiveObject)::DownCast (SelectedOwner()->Selectable()).)#" 
          )
        .def("HasSelectedShape",
             (bool (AIS_InteractiveContext::*)() const) static_cast<bool (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::HasSelectedShape),
             R"#(Returns TRUE if the interactive context has a shape selected.)#" 
          )
        .def("SelectedShape",
             (TopoDS_Shape (AIS_InteractiveContext::*)() const) static_cast<TopoDS_Shape (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::SelectedShape),
             R"#(Returns the selected shape. Basically it is just a shape returned stored by StdSelect_BRepOwner with graphic transformation being applied:)#" 
          )
        .def("HasApplicative",
             (bool (AIS_InteractiveContext::*)() const) static_cast<bool (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::HasApplicative),
             R"#(Returns SelectedInteractive()->HasOwner().)#" 
          )
        .def("Applicative",
             (handle<Standard_Transient> (AIS_InteractiveContext::*)() const) static_cast<handle<Standard_Transient> (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::Applicative),
             R"#(Returns SelectedInteractive()->GetOwner().)#" 
          )
        .def("BeginImmediateDraw",
             (bool (AIS_InteractiveContext::*)() ) static_cast<bool (AIS_InteractiveContext::*)() >(&AIS_InteractiveContext::BeginImmediateDraw),
             R"#()#" 
          )
        .def("ImmediateAdd",
             (bool (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const int  ) ) static_cast<bool (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const int  ) >(&AIS_InteractiveContext::ImmediateAdd),
             R"#()#"  , py::arg("theObj"),  py::arg("theMode")=static_cast< const int>(0)
          )
        .def("EndImmediateDraw",
             (bool (AIS_InteractiveContext::*)(  const handle<V3d_View> &  ) ) static_cast<bool (AIS_InteractiveContext::*)(  const handle<V3d_View> &  ) >(&AIS_InteractiveContext::EndImmediateDraw),
             R"#()#"  , py::arg("theView")
          )
        .def("EndImmediateDraw",
             (bool (AIS_InteractiveContext::*)() ) static_cast<bool (AIS_InteractiveContext::*)() >(&AIS_InteractiveContext::EndImmediateDraw),
             R"#()#" 
          )
        .def("IsImmediateModeOn",
             (bool (AIS_InteractiveContext::*)() const) static_cast<bool (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::IsImmediateModeOn),
             R"#()#" 
          )
        .def("RedrawImmediate",
             (void (AIS_InteractiveContext::*)(  const handle<V3d_Viewer> &  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<V3d_Viewer> &  ) >(&AIS_InteractiveContext::RedrawImmediate),
             R"#(Redraws immediate structures in all views of the viewer given taking into account its visibility.)#"  , py::arg("theViewer")
          )
        .def("SetSelectionModeActive",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const int ,   const bool ,   const AIS_SelectionModesConcurrency ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const int ,   const bool ,   const AIS_SelectionModesConcurrency ,   const bool  ) >(&AIS_InteractiveContext::SetSelectionModeActive),
             R"#(Activates or deactivates the selection mode for specified object. Has no effect if selection mode was already active/deactivated.)#"  , py::arg("theObj"),  py::arg("theMode"),  py::arg("theToActivate"),  py::arg("theConcurrency")=static_cast< const AIS_SelectionModesConcurrency>(AIS_SelectionModesConcurrency_Multiple),  py::arg("theIsForce")=static_cast< const bool>(false)
          )
        .def("Activate",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const int ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const int ,   const bool  ) >(&AIS_InteractiveContext::Activate),
             R"#(Activates the selection mode aMode whose index is given, for the given interactive entity anIobj.)#"  , py::arg("theObj"),  py::arg("theMode")=static_cast< const int>(0),  py::arg("theIsForce")=static_cast< const bool>(false)
          )
        .def("Activate",
             (void (AIS_InteractiveContext::*)(  const int ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const int ,   const bool  ) >(&AIS_InteractiveContext::Activate),
             R"#(Activates the given selection mode for the all displayed objects.)#"  , py::arg("theMode"),  py::arg("theIsForce")=static_cast< const bool>(false)
          )
        .def("Deactivate",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) >(&AIS_InteractiveContext::Deactivate),
             R"#(Deactivates all the activated selection modes of an object.)#"  , py::arg("theObj")
          )
        .def("Deactivate",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const int  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const int  ) >(&AIS_InteractiveContext::Deactivate),
             R"#(Deactivates all the activated selection modes of the interactive object anIobj with a given selection mode aMode.)#"  , py::arg("theObj"),  py::arg("theMode")
          )
        .def("Deactivate",
             (void (AIS_InteractiveContext::*)(  const int  ) ) static_cast<void (AIS_InteractiveContext::*)(  const int  ) >(&AIS_InteractiveContext::Deactivate),
             R"#(Deactivates the given selection mode for all displayed objects.)#"  , py::arg("theMode")
          )
        .def("Deactivate",
             (void (AIS_InteractiveContext::*)() ) static_cast<void (AIS_InteractiveContext::*)() >(&AIS_InteractiveContext::Deactivate),
             R"#(Deactivates all the activated selection mode at all displayed objects.)#" 
          )
        .def("ActivatedModes",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,  NCollection_List<int> &  ) const) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,  NCollection_List<int> &  ) const>(&AIS_InteractiveContext::ActivatedModes),
             R"#(Returns the list of activated selection modes.)#"  , py::arg("anIobj"),  py::arg("theList")
          )
        .def("FilterType",
             (SelectMgr_FilterType (AIS_InteractiveContext::*)() const) static_cast<SelectMgr_FilterType (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::FilterType),
             R"#(Returns the context selection filter type.)#" 
          )
        .def("SetFilterType",
             (void (AIS_InteractiveContext::*)(  const SelectMgr_FilterType  ) ) static_cast<void (AIS_InteractiveContext::*)(  const SelectMgr_FilterType  ) >(&AIS_InteractiveContext::SetFilterType),
             R"#(Sets the context selection filter type. SelectMgr_TypeFilter_OR selection filter is used by default.)#"  , py::arg("theFilterType")
          )
        .def("AddFilter",
             (void (AIS_InteractiveContext::*)(  const handle<SelectMgr_Filter> &  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<SelectMgr_Filter> &  ) >(&AIS_InteractiveContext::AddFilter),
             R"#(Allows you to add the filter.)#"  , py::arg("theFilter")
          )
        .def("RemoveFilter",
             (void (AIS_InteractiveContext::*)(  const handle<SelectMgr_Filter> &  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<SelectMgr_Filter> &  ) >(&AIS_InteractiveContext::RemoveFilter),
             R"#(Removes a filter from context.)#"  , py::arg("theFilter")
          )
        .def("RemoveFilters",
             (void (AIS_InteractiveContext::*)() ) static_cast<void (AIS_InteractiveContext::*)() >(&AIS_InteractiveContext::RemoveFilters),
             R"#(Remove all filters from context.)#" 
          )
        .def("PickingStrategy",
             (SelectMgr_PickingStrategy (AIS_InteractiveContext::*)() const) static_cast<SelectMgr_PickingStrategy (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::PickingStrategy),
             R"#(Return picking strategy; SelectMgr_PickingStrategy_FirstAcceptable by default.)#" 
          )
        .def("SetPickingStrategy",
             (void (AIS_InteractiveContext::*)(  const SelectMgr_PickingStrategy  ) ) static_cast<void (AIS_InteractiveContext::*)(  const SelectMgr_PickingStrategy  ) >(&AIS_InteractiveContext::SetPickingStrategy),
             R"#(Setup picking strategy - which entities detected by picking line will be accepted, considering Selection Filters. By default (SelectMgr_PickingStrategy_FirstAcceptable), Selection Filters reduce the list of entities so that the context accepts topmost in remaining.)#"  , py::arg("theStrategy")
          )
        .def("SetDefaultDrawer",
             (void (AIS_InteractiveContext::*)(  const handle<Prs3d_Drawer> &  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<Prs3d_Drawer> &  ) >(&AIS_InteractiveContext::SetDefaultDrawer),
             R"#(Sets the default attribute manager; should be set at context creation time. Warning - this setter doesn't update links to the default drawer of already displayed objects!)#"  , py::arg("theDrawer")
          )
        .def("UpdateCurrentViewer",
             (void (AIS_InteractiveContext::*)() ) static_cast<void (AIS_InteractiveContext::*)() >(&AIS_InteractiveContext::UpdateCurrentViewer),
             R"#(Updates the current viewer.)#" 
          )
        .def("DisplayedObjects",
             (void (AIS_InteractiveContext::*)( NCollection_List<handle<AIS_InteractiveObject>> &  ) const) static_cast<void (AIS_InteractiveContext::*)( NCollection_List<handle<AIS_InteractiveObject>> &  ) const>(&AIS_InteractiveContext::DisplayedObjects),
             R"#(Returns the list of displayed objects of a particular Type WhichKind and Signature WhichSignature. By Default, WhichSignature equals -1. This means that there is a check on type only.)#"  , py::arg("aListOfIO")
          )
        .def("DisplayedObjects",
             (void (AIS_InteractiveContext::*)(  const AIS_KindOfInteractive ,   const int ,  NCollection_List<handle<AIS_InteractiveObject>> &  ) const) static_cast<void (AIS_InteractiveContext::*)(  const AIS_KindOfInteractive ,   const int ,  NCollection_List<handle<AIS_InteractiveObject>> &  ) const>(&AIS_InteractiveContext::DisplayedObjects),
             R"#(gives the list of displayed objects of a particular Type and signature. by Default, <WhichSignature> = -1 means control only on <WhichKind>.)#"  , py::arg("theWhichKind"),  py::arg("theWhichSignature"),  py::arg("theListOfIO")
          )
        .def("ErasedObjects",
             (void (AIS_InteractiveContext::*)( NCollection_List<handle<AIS_InteractiveObject>> &  ) const) static_cast<void (AIS_InteractiveContext::*)( NCollection_List<handle<AIS_InteractiveObject>> &  ) const>(&AIS_InteractiveContext::ErasedObjects),
             R"#(Returns the list theListOfIO of erased objects (hidden objects) particular Type WhichKind and Signature WhichSignature. By Default, WhichSignature equals 1. This means that there is a check on type only.)#"  , py::arg("theListOfIO")
          )
        .def("ErasedObjects",
             (void (AIS_InteractiveContext::*)(  const AIS_KindOfInteractive ,   const int ,  NCollection_List<handle<AIS_InteractiveObject>> &  ) const) static_cast<void (AIS_InteractiveContext::*)(  const AIS_KindOfInteractive ,   const int ,  NCollection_List<handle<AIS_InteractiveObject>> &  ) const>(&AIS_InteractiveContext::ErasedObjects),
             R"#(gives the list of erased objects (hidden objects) Type and signature by Default, <WhichSignature> = -1 means control only on <WhichKind>.)#"  , py::arg("theWhichKind"),  py::arg("theWhichSignature"),  py::arg("theListOfIO")
          )
        .def("ObjectsByDisplayStatus",
             (void (AIS_InteractiveContext::*)(  const PrsMgr_DisplayStatus ,  NCollection_List<handle<AIS_InteractiveObject>> &  ) const) static_cast<void (AIS_InteractiveContext::*)(  const PrsMgr_DisplayStatus ,  NCollection_List<handle<AIS_InteractiveObject>> &  ) const>(&AIS_InteractiveContext::ObjectsByDisplayStatus),
             R"#(Returns the list theListOfIO of objects with indicated display status particular Type WhichKind and Signature WhichSignature. By Default, WhichSignature equals 1. This means that there is a check on type only.)#"  , py::arg("theStatus"),  py::arg("theListOfIO")
          )
        .def("ObjectsByDisplayStatus",
             (void (AIS_InteractiveContext::*)(  const AIS_KindOfInteractive ,   const int ,   const PrsMgr_DisplayStatus ,  NCollection_List<handle<AIS_InteractiveObject>> &  ) const) static_cast<void (AIS_InteractiveContext::*)(  const AIS_KindOfInteractive ,   const int ,   const PrsMgr_DisplayStatus ,  NCollection_List<handle<AIS_InteractiveObject>> &  ) const>(&AIS_InteractiveContext::ObjectsByDisplayStatus),
             R"#(gives the list of objects with indicated display status Type and signature by Default, <WhichSignature> = -1 means control only on <WhichKind>.)#"  , py::arg("WhichKind"),  py::arg("WhichSignature"),  py::arg("theStatus"),  py::arg("theListOfIO")
          )
        .def("ObjectsInside",
             (void (AIS_InteractiveContext::*)( NCollection_List<handle<AIS_InteractiveObject>> & ,   const AIS_KindOfInteractive ,   const int  ) const) static_cast<void (AIS_InteractiveContext::*)( NCollection_List<handle<AIS_InteractiveObject>> & ,   const AIS_KindOfInteractive ,   const int  ) const>(&AIS_InteractiveContext::ObjectsInside),
             R"#(fills <aListOfIO> with objects of a particular Type and Signature with no consideration of display status. by Default, <WhichSignature> = -1 means control only on <WhichKind>. if <WhichKind> = AIS_KindOfInteractive_None and <WhichSignature> = -1, all the objects are put into the list.)#"  , py::arg("aListOfIO"),  py::arg("WhichKind")=static_cast< const AIS_KindOfInteractive>(AIS_KindOfInteractive_None),  py::arg("WhichSignature")=static_cast< const int>(- 1)
          )
        .def("ObjectIterator",
             (NCollection_DataMap<opencascade::handle<AIS_InteractiveObject>, opencascade::handle<AIS_GlobalStatus>>::Iterator (AIS_InteractiveContext::*)() const) static_cast<NCollection_DataMap<opencascade::handle<AIS_InteractiveObject>, opencascade::handle<AIS_GlobalStatus>>::Iterator (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::ObjectIterator),
             R"#(Create iterator through all objects registered in context.)#" 
          )
        .def("RebuildSelectionStructs",
             (void (AIS_InteractiveContext::*)() ) static_cast<void (AIS_InteractiveContext::*)() >(&AIS_InteractiveContext::RebuildSelectionStructs),
             R"#(Rebuilds 1st level of BVH selection forcibly)#" 
          )
        .def("Disconnect",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const handle<AIS_InteractiveObject> &  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const handle<AIS_InteractiveObject> &  ) >(&AIS_InteractiveContext::Disconnect),
             R"#(Disconnects theObjToDisconnect from theAssembly and removes dependent selection structures)#"  , py::arg("theAssembly"),  py::arg("theObjToDisconnect")=static_cast< const handle<AIS_InteractiveObject> &>(nullptr)
          )
        .def("ObjectsForView",
             (void (AIS_InteractiveContext::*)( NCollection_List<handle<AIS_InteractiveObject>> & ,   const handle<V3d_View> & ,   const bool ,   const PrsMgr_DisplayStatus  ) const) static_cast<void (AIS_InteractiveContext::*)( NCollection_List<handle<AIS_InteractiveObject>> & ,   const handle<V3d_View> & ,   const bool ,   const PrsMgr_DisplayStatus  ) const>(&AIS_InteractiveContext::ObjectsForView),
             R"#(Query objects visible or hidden in specified view due to affinity mask.)#"  , py::arg("theListOfIO"),  py::arg("theView"),  py::arg("theIsVisibleInView"),  py::arg("theStatus")=static_cast< const PrsMgr_DisplayStatus>(PrsMgr_DisplayStatus_None)
          )
        .def("GravityPoint",
             (gp_Pnt (AIS_InteractiveContext::*)(  const handle<V3d_View> &  ) const) static_cast<gp_Pnt (AIS_InteractiveContext::*)(  const handle<V3d_View> &  ) const>(&AIS_InteractiveContext::GravityPoint),
             R"#(Return rotation gravity point.)#"  , py::arg("theView")
          )
        .def("DisplayActiveSensitive",
             (void (AIS_InteractiveContext::*)(  const handle<V3d_View> &  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<V3d_View> &  ) >(&AIS_InteractiveContext::DisplayActiveSensitive),
             R"#(Visualization of sensitives - for debugging purposes!)#"  , py::arg("aView")
          )
        .def("ClearActiveSensitive",
             (void (AIS_InteractiveContext::*)(  const handle<V3d_View> &  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<V3d_View> &  ) >(&AIS_InteractiveContext::ClearActiveSensitive),
             R"#(Clear visualization of sensitives.)#"  , py::arg("aView")
          )
        .def("DisplayActiveSensitive",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const handle<V3d_View> &  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const handle<V3d_View> &  ) >(&AIS_InteractiveContext::DisplayActiveSensitive),
             R"#(Visualization of sensitives - for debugging purposes!)#"  , py::arg("anObject"),  py::arg("aView")
          )
        .def("SetLocalAttributes",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const handle<Prs3d_Drawer> & ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const handle<Prs3d_Drawer> & ,   const bool  ) >(&AIS_InteractiveContext::SetLocalAttributes),
             R"#(Sets the graphic attributes of the interactive object, such as visualization mode, color, and material.)#"  , py::arg("theIObj"),  py::arg("theDrawer"),  py::arg("theToUpdateViewer")
          )
        .def("UnsetLocalAttributes",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) >(&AIS_InteractiveContext::UnsetLocalAttributes),
             R"#(Removes the settings for local attributes of the Object and returns to defaults.)#"  , py::arg("theIObj"),  py::arg("theToUpdateViewer")
          )
        .def("SetCurrentFacingModel",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const Aspect_TypeOfFacingModel  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const Aspect_TypeOfFacingModel  ) >(&AIS_InteractiveContext::SetCurrentFacingModel),
             R"#(change the current facing model apply on polygons for SetColor(), SetTransparency(), SetMaterial() methods default facing model is Aspect_TOFM_TWO_SIDE. This mean that attributes is applying both on the front and back face.)#"  , py::arg("aniobj"),  py::arg("aModel")=static_cast< const Aspect_TypeOfFacingModel>(Aspect_TOFM_BOTH_SIDE)
          )
        .def("HasColor",
             (bool (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) const) static_cast<bool (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) const>(&AIS_InteractiveContext::HasColor),
             R"#(Returns true if a view of the Interactive Object has color.)#"  , py::arg("aniobj")
          )
        .def("Color",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,  Quantity_Color &  ) const) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,  Quantity_Color &  ) const>(&AIS_InteractiveContext::Color),
             R"#(Returns the color of the Object in the interactive context.)#"  , py::arg("aniobj"),  py::arg("acolor")
          )
        .def("SetColor",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const Quantity_Color & ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const Quantity_Color & ,   const bool  ) >(&AIS_InteractiveContext::SetColor),
             R"#(Sets the color of the selected entity.)#"  , py::arg("theIObj"),  py::arg("theColor"),  py::arg("theToUpdateViewer")
          )
        .def("UnsetColor",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) >(&AIS_InteractiveContext::UnsetColor),
             R"#(Removes the color selection for the selected entity.)#"  , py::arg("theIObj"),  py::arg("theToUpdateViewer")
          )
        .def("Width",
             (double (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) const) static_cast<double (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) const>(&AIS_InteractiveContext::Width),
             R"#(Returns the width of the Interactive Object in the interactive context.)#"  , py::arg("aniobj")
          )
        .def("SetWidth",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const double ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const double ,   const bool  ) >(&AIS_InteractiveContext::SetWidth),
             R"#(Sets the width of the Object.)#"  , py::arg("theIObj"),  py::arg("theValue"),  py::arg("theToUpdateViewer")
          )
        .def("UnsetWidth",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) >(&AIS_InteractiveContext::UnsetWidth),
             R"#(Removes the width setting of the Object.)#"  , py::arg("theIObj"),  py::arg("theToUpdateViewer")
          )
        .def("SetMaterial",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const Graphic3d_MaterialAspect & ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const Graphic3d_MaterialAspect & ,   const bool  ) >(&AIS_InteractiveContext::SetMaterial),
             R"#(Provides the type of material setting for the view of the Object.)#"  , py::arg("theIObj"),  py::arg("theMaterial"),  py::arg("theToUpdateViewer")
          )
        .def("UnsetMaterial",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) >(&AIS_InteractiveContext::UnsetMaterial),
             R"#(Removes the type of material setting for viewing the Object.)#"  , py::arg("theIObj"),  py::arg("theToUpdateViewer")
          )
        .def("SetTransparency",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const double ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const double ,   const bool  ) >(&AIS_InteractiveContext::SetTransparency),
             R"#(Provides the transparency settings for viewing the Object. The transparency value aValue may be between 0.0, opaque, and 1.0, fully transparent.)#"  , py::arg("theIObj"),  py::arg("theValue"),  py::arg("theToUpdateViewer")
          )
        .def("UnsetTransparency",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) >(&AIS_InteractiveContext::UnsetTransparency),
             R"#(Removes the transparency settings for viewing the Object.)#"  , py::arg("theIObj"),  py::arg("theToUpdateViewer")
          )
        .def("SetPolygonOffsets",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const int ,   const float ,   const float ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const int ,   const float ,   const float ,   const bool  ) >(&AIS_InteractiveContext::SetPolygonOffsets),
             R"#(Sets up polygon offsets for the given AIS_InteractiveObject. It simply calls AIS_InteractiveObject::SetPolygonOffsets().)#"  , py::arg("theIObj"),  py::arg("theMode"),  py::arg("theFactor"),  py::arg("theUnits"),  py::arg("theToUpdateViewer")
          )
        .def("HasPolygonOffsets",
             (bool (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) const) static_cast<bool (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) const>(&AIS_InteractiveContext::HasPolygonOffsets),
             R"#(Simply calls AIS_InteractiveObject::HasPolygonOffsets().)#"  , py::arg("anObj")
          )
        .def("SetTrihedronSize",
             (void (AIS_InteractiveContext::*)(  const double ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const double ,   const bool  ) >(&AIS_InteractiveContext::SetTrihedronSize),
             R"#(Sets the size aSize of the trihedron. Is used to change the default value 100 mm for display of trihedra. Use of this function in one of your own interactive objects requires a call to the Compute function of the new class. This will recalculate the presentation for every trihedron displayed.)#"  , py::arg("theSize"),  py::arg("theToUpdateViewer")
          )
        .def("TrihedronSize",
             (double (AIS_InteractiveContext::*)() const) static_cast<double (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::TrihedronSize),
             R"#(returns the current value of trihedron size.)#" 
          )
        .def("SetPlaneSize",
             (void (AIS_InteractiveContext::*)(  const double ,   const double ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const double ,   const double ,   const bool  ) >(&AIS_InteractiveContext::SetPlaneSize),
             R"#(Sets the plane size defined by the length in the X direction XSize and that in the Y direction YSize.)#"  , py::arg("theSizeX"),  py::arg("theSizeY"),  py::arg("theToUpdateViewer")
          )
        .def("SetPlaneSize",
             (void (AIS_InteractiveContext::*)(  const double ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const double ,   const bool  ) >(&AIS_InteractiveContext::SetPlaneSize),
             R"#(Sets the plane size aSize.)#"  , py::arg("theSize"),  py::arg("theToUpdateViewer")
          )
        .def("PlaneSize",
             (bool (AIS_InteractiveContext::*)( double & ,  double &  ) const) static_cast<bool (AIS_InteractiveContext::*)( double & ,  double &  ) const>(&AIS_InteractiveContext::PlaneSize),
             R"#(Returns true if the length in the X direction XSize is the same as that in the Y direction YSize.)#"  , py::arg("XSize"),  py::arg("YSize")
          )
        .def("SetDeviationCoefficient",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const double ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const double ,   const bool  ) >(&AIS_InteractiveContext::SetDeviationCoefficient),
             R"#(Sets the deviation coefficient theCoefficient. Drawings of curves or patches are made with respect to a maximal chordal deviation. A Deviation coefficient is used in the shading display mode. The shape is seen decomposed into triangles. These are used to calculate reflection of light from the surface of the object. The triangles are formed from chords of the curves in the shape. The deviation coefficient theCoefficient gives the highest value of the angle with which a chord can deviate from a tangent to a curve. If this limit is reached, a new triangle is begun. This deviation is absolute and is set through the method: SetMaximalChordialDeviation. The default value is 0.001. In drawing shapes, however, you are allowed to ask for a relative deviation. This deviation will be: SizeOfObject * DeviationCoefficient.)#"  , py::arg("theIObj"),  py::arg("theCoefficient"),  py::arg("theToUpdateViewer")
          )
        .def("SetDeviationAngle",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const double ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const double ,   const bool  ) >(&AIS_InteractiveContext::SetDeviationAngle),
             R"#()#"  , py::arg("theIObj"),  py::arg("theAngle"),  py::arg("theToUpdateViewer")
          )
        .def("SetAngleAndDeviation",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const double ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const double ,   const bool  ) >(&AIS_InteractiveContext::SetAngleAndDeviation),
             R"#(Calls the AIS_Shape SetAngleAndDeviation to set both Angle and Deviation coefficients)#"  , py::arg("theIObj"),  py::arg("theAngle"),  py::arg("theToUpdateViewer")
          )
        .def("SetDeviationCoefficient",
             (void (AIS_InteractiveContext::*)(  const double  ) ) static_cast<void (AIS_InteractiveContext::*)(  const double  ) >(&AIS_InteractiveContext::SetDeviationCoefficient),
             R"#(Sets the deviation coefficient theCoefficient. Drawings of curves or patches are made with respect to a maximal chordal deviation. A Deviation coefficient is used in the shading display mode. The shape is seen decomposed into triangles. These are used to calculate reflection of light from the surface of the object. The triangles are formed from chords of the curves in the shape. The deviation coefficient theCoefficient gives the highest value of the angle with which a chord can deviate from a tangent to a curve. If this limit is reached, a new triangle is begun. This deviation is absolute and is set through the method: SetMaximalChordialDeviation. The default value is 0.001. In drawing shapes, however, you are allowed to ask for a relative deviation. This deviation will be: SizeOfObject * DeviationCoefficient.)#"  , py::arg("theCoefficient")
          )
        .def("DeviationCoefficient",
             (double (AIS_InteractiveContext::*)() const) static_cast<double (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::DeviationCoefficient),
             R"#(Returns the deviation coefficient. Drawings of curves or patches are made with respect to a maximal chordal deviation. A Deviation coefficient is used in the shading display mode. The shape is seen decomposed into triangles. These are used to calculate reflection of light from the surface of the object. The triangles are formed from chords of the curves in the shape. The deviation coefficient gives the highest value of the angle with which a chord can deviate from a tangent to a curve. If this limit is reached, a new triangle is begun. This deviation is absolute and is set through Prs3d_Drawer::SetMaximalChordialDeviation. The default value is 0.001. In drawing shapes, however, you are allowed to ask for a relative deviation. This deviation will be: SizeOfObject * DeviationCoefficient.)#" 
          )
        .def("SetDeviationAngle",
             (void (AIS_InteractiveContext::*)(  const double  ) ) static_cast<void (AIS_InteractiveContext::*)(  const double  ) >(&AIS_InteractiveContext::SetDeviationAngle),
             R"#(default 20 degrees)#"  , py::arg("theAngle")
          )
        .def("DeviationAngle",
             (double (AIS_InteractiveContext::*)() const) static_cast<double (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::DeviationAngle),
             R"#()#" 
          )
        .def("SetHiddenLineAspect",
             (void (AIS_InteractiveContext::*)(  const handle<Prs3d_LineAspect> &  ) const) static_cast<void (AIS_InteractiveContext::*)(  const handle<Prs3d_LineAspect> &  ) const>(&AIS_InteractiveContext::SetHiddenLineAspect),
             R"#(Sets the hidden line aspect anAspect. Aspect defines display attributes for hidden lines in HLR projections.)#"  , py::arg("theAspect")
          )
        .def("DrawHiddenLine",
             (bool (AIS_InteractiveContext::*)() const) static_cast<bool (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::DrawHiddenLine),
             R"#(returns true if the hidden lines are to be drawn. By default the hidden lines are not drawn.)#" 
          )
        .def("EnableDrawHiddenLine",
             (void (AIS_InteractiveContext::*)() const) static_cast<void (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::EnableDrawHiddenLine),
             R"#()#" 
          )
        .def("DisableDrawHiddenLine",
             (void (AIS_InteractiveContext::*)() const) static_cast<void (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::DisableDrawHiddenLine),
             R"#()#" 
          )
        .def("SetIsoNumber",
             (void (AIS_InteractiveContext::*)(  const int ,   const AIS_TypeOfIso  ) ) static_cast<void (AIS_InteractiveContext::*)(  const int ,   const AIS_TypeOfIso  ) >(&AIS_InteractiveContext::SetIsoNumber),
             R"#(Sets the number of U and V isoparameters displayed.)#"  , py::arg("NbIsos"),  py::arg("WhichIsos")=static_cast< const AIS_TypeOfIso>(AIS_TOI_Both)
          )
        .def("IsoNumber",
             (int (AIS_InteractiveContext::*)(  const AIS_TypeOfIso  ) ) static_cast<int (AIS_InteractiveContext::*)(  const AIS_TypeOfIso  ) >(&AIS_InteractiveContext::IsoNumber),
             R"#(Returns the number of U and V isoparameters displayed.)#"  , py::arg("WhichIsos")=static_cast< const AIS_TypeOfIso>(AIS_TOI_Both)
          )
        .def("IsoOnPlane",
             (void (AIS_InteractiveContext::*)(  const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const bool  ) >(&AIS_InteractiveContext::IsoOnPlane),
             R"#(Returns True if drawing isoparameters on planes is enabled.)#"  , py::arg("theToSwitchOn")
          )
        .def("IsoOnPlane",
             (bool (AIS_InteractiveContext::*)() const) static_cast<bool (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::IsoOnPlane),
             R"#(Returns True if drawing isoparameters on planes is enabled. if <forUIsos> = False,)#" 
          )
        .def("IsoOnTriangulation",
             (void (AIS_InteractiveContext::*)(  const bool ,   const handle<AIS_InteractiveObject> &  ) ) static_cast<void (AIS_InteractiveContext::*)(  const bool ,   const handle<AIS_InteractiveObject> &  ) >(&AIS_InteractiveContext::IsoOnTriangulation),
             R"#(Enables or disables on-triangulation build for isolines for a particular object. In case if on-triangulation builder is disabled, default on-plane builder will compute isolines for the object given.)#"  , py::arg("theIsEnabled"),  py::arg("theObject")
          )
        .def("IsoOnTriangulation",
             (void (AIS_InteractiveContext::*)(  const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const bool  ) >(&AIS_InteractiveContext::IsoOnTriangulation),
             R"#(Enables or disables on-triangulation build for isolines for default drawer. In case if on-triangulation builder is disabled, default on-plane builder will compute isolines for the object given.)#"  , py::arg("theToSwitchOn")
          )
        .def("IsoOnTriangulation",
             (bool (AIS_InteractiveContext::*)() const) static_cast<bool (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::IsoOnTriangulation),
             R"#(Returns true if drawing isolines on triangulation algorithm is enabled.)#" 
          )
        .def("Display",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const int ,   const int ,   const bool ,   const bool ,   const PrsMgr_DisplayStatus  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const int ,   const int ,   const bool ,   const bool ,   const PrsMgr_DisplayStatus  ) >(&AIS_InteractiveContext::Display),
             R"#()#"  , py::arg("theIObj"),  py::arg("theDispMode"),  py::arg("theSelectionMode"),  py::arg("theToUpdateViewer"),  py::arg("theToAllowDecomposition"),  py::arg("theDispStatus")=static_cast< const PrsMgr_DisplayStatus>(PrsMgr_DisplayStatus_None)
          )
        .def("Load",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,  int ,  bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,  int ,  bool  ) >(&AIS_InteractiveContext::Load),
             R"#()#"  , py::arg("theObj"),  py::arg("theSelectionMode"),  py::arg("arg2")
          )
        .def("Hilight",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) >(&AIS_InteractiveContext::Hilight),
             R"#(Updates the display in the viewer to take dynamic detection into account. On dynamic detection by the mouse cursor, sensitive primitives are highlighted. The highlight color of entities detected by mouse movement is white by default.)#"  , py::arg("theObj"),  py::arg("theIsToUpdateViewer")
          )
        .def("SetSelectedAspect",
             (void (AIS_InteractiveContext::*)(  const handle<Prs3d_BasicAspect> & ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<Prs3d_BasicAspect> & ,   const bool  ) >(&AIS_InteractiveContext::SetSelectedAspect),
             R"#(Sets the graphic basic aspect to the current presentation of ALL selected objects.)#"  , py::arg("theAspect"),  py::arg("theToUpdateViewer")
          )
        .def("Select",
             (AIS_StatusOfPick (AIS_InteractiveContext::*)(  const int ,   const int ,   const int ,   const int ,   const handle<V3d_View> & ,   const bool  ) ) static_cast<AIS_StatusOfPick (AIS_InteractiveContext::*)(  const int ,   const int ,   const int ,   const int ,   const handle<V3d_View> & ,   const bool  ) >(&AIS_InteractiveContext::Select),
             R"#(Selects everything found in the bounding rectangle defined by the pixel minima and maxima, XPMin, YPMin, XPMax, and YPMax in the view. The objects detected are passed to the main viewer, which is then updated.)#"  , py::arg("theXPMin"),  py::arg("theYPMin"),  py::arg("theXPMax"),  py::arg("theYPMax"),  py::arg("theView"),  py::arg("theToUpdateViewer")
          )
        .def("Select",
             (AIS_StatusOfPick (AIS_InteractiveContext::*)(  const NCollection_Array1<gp_Pnt2d> & ,   const handle<V3d_View> & ,   const bool  ) ) static_cast<AIS_StatusOfPick (AIS_InteractiveContext::*)(  const NCollection_Array1<gp_Pnt2d> & ,   const handle<V3d_View> & ,   const bool  ) >(&AIS_InteractiveContext::Select),
             R"#(polyline selection; clears the previous picked list)#"  , py::arg("thePolyline"),  py::arg("theView"),  py::arg("theToUpdateViewer")
          )
        .def("Select",
             (AIS_StatusOfPick (AIS_InteractiveContext::*)(  const bool  ) ) static_cast<AIS_StatusOfPick (AIS_InteractiveContext::*)(  const bool  ) >(&AIS_InteractiveContext::Select),
             R"#(Stores and hilights the previous detected; Unhilights the previous picked.)#"  , py::arg("theToUpdateViewer")
          )
        .def("ShiftSelect",
             (AIS_StatusOfPick (AIS_InteractiveContext::*)(  const bool  ) ) static_cast<AIS_StatusOfPick (AIS_InteractiveContext::*)(  const bool  ) >(&AIS_InteractiveContext::ShiftSelect),
             R"#(Adds the last detected to the list of previous picked. If the last detected was already declared as picked, removes it from the Picked List.)#"  , py::arg("theToUpdateViewer")
          )
        .def("ShiftSelect",
             (AIS_StatusOfPick (AIS_InteractiveContext::*)(  const NCollection_Array1<gp_Pnt2d> & ,   const handle<V3d_View> & ,   const bool  ) ) static_cast<AIS_StatusOfPick (AIS_InteractiveContext::*)(  const NCollection_Array1<gp_Pnt2d> & ,   const handle<V3d_View> & ,   const bool  ) >(&AIS_InteractiveContext::ShiftSelect),
             R"#(Adds the last detected to the list of previous picked. If the last detected was already declared as picked, removes it from the Picked List.)#"  , py::arg("thePolyline"),  py::arg("theView"),  py::arg("theToUpdateViewer")
          )
        .def("ShiftSelect",
             (AIS_StatusOfPick (AIS_InteractiveContext::*)(  const int ,   const int ,   const int ,   const int ,   const handle<V3d_View> & ,   const bool  ) ) static_cast<AIS_StatusOfPick (AIS_InteractiveContext::*)(  const int ,   const int ,   const int ,   const int ,   const handle<V3d_View> & ,   const bool  ) >(&AIS_InteractiveContext::ShiftSelect),
             R"#(Rectangle of selection; adds new detected entities into the picked list, removes the detected entities that were already stored.)#"  , py::arg("theXPMin"),  py::arg("theYPMin"),  py::arg("theXPMax"),  py::arg("theYPMax"),  py::arg("theView"),  py::arg("theToUpdateViewer")
          )
        .def("SetCurrentObject",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) >(&AIS_InteractiveContext::SetCurrentObject),
             R"#(Updates the view of the current object in open context. Objects selected when there is no open local context are called current objects; those selected in open local context, selected objects.)#"  , py::arg("theIObj"),  py::arg("theToUpdateViewer")
          )
        .def("AddOrRemoveCurrentObject",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) >(&AIS_InteractiveContext::AddOrRemoveCurrentObject),
             R"#(Allows to add or remove the object given to the list of current and highlight/unhighlight it correspondingly. Is valid for global context only; for local context use method AddOrRemoveSelected. Since this method makes sense only for neutral point selection of a whole object, if 0 selection of the object is empty this method simply does nothing.)#"  , py::arg("theObj"),  py::arg("theIsToUpdateViewer")
          )
        .def("UpdateCurrent",
             (void (AIS_InteractiveContext::*)() ) static_cast<void (AIS_InteractiveContext::*)() >(&AIS_InteractiveContext::UpdateCurrent),
             R"#(Updates the list of current objects, i.e. hilights new current objects, removes hilighting from former current objects. Objects selected when there is no open local context are called current objects; those selected in open local context, selected objects.)#" 
          )
        .def("IsCurrent",
             (bool (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) const) static_cast<bool (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> &  ) const>(&AIS_InteractiveContext::IsCurrent),
             R"#(Returns true if there is a non-null interactive object in Neutral Point. Objects selected when there is no open local context are called current objects; those selected in open local context, selected objects.)#"  , py::arg("theObject")
          )
        .def("InitCurrent",
             (void (AIS_InteractiveContext::*)() ) static_cast<void (AIS_InteractiveContext::*)() >(&AIS_InteractiveContext::InitCurrent),
             R"#(Initializes a scan of the current selected objects in Neutral Point. Objects selected when there is no open local context are called current objects; those selected in open local context, selected objects.)#" 
          )
        .def("MoreCurrent",
             (bool (AIS_InteractiveContext::*)() const) static_cast<bool (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::MoreCurrent),
             R"#(Returns true if there is another object found by the scan of the list of current objects. Objects selected when there is no open local context are called current objects; those selected in open local context, selected objects.)#" 
          )
        .def("NextCurrent",
             (void (AIS_InteractiveContext::*)() ) static_cast<void (AIS_InteractiveContext::*)() >(&AIS_InteractiveContext::NextCurrent),
             R"#(Continues the scan to the next object in the list of current objects. Objects selected when there is no open local context are called current objects; those selected in open local context, selected objects.)#" 
          )
        .def("Current",
             (handle<AIS_InteractiveObject> (AIS_InteractiveContext::*)() const) static_cast<handle<AIS_InteractiveObject> (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::Current),
             R"#(Returns the current interactive object. Objects selected when there is no open local context are called current objects; those selected in open local context, selected objects.)#" 
          )
        .def("NbCurrents",
             (int (AIS_InteractiveContext::*)() ) static_cast<int (AIS_InteractiveContext::*)() >(&AIS_InteractiveContext::NbCurrents),
             R"#()#" 
          )
        .def("HilightCurrents",
             (void (AIS_InteractiveContext::*)(  const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const bool  ) >(&AIS_InteractiveContext::HilightCurrents),
             R"#(Highlights current objects. Objects selected when there is no open local context are called current objects; those selected in open local context, selected objects.)#"  , py::arg("theToUpdateViewer")
          )
        .def("UnhilightCurrents",
             (void (AIS_InteractiveContext::*)(  const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const bool  ) >(&AIS_InteractiveContext::UnhilightCurrents),
             R"#(Removes highlighting from current objects. Objects selected when there is no open local context are called current objects; those selected in open local context, selected objects.)#"  , py::arg("theToUpdateViewer")
          )
        .def("ClearCurrents",
             (void (AIS_InteractiveContext::*)(  const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const bool  ) >(&AIS_InteractiveContext::ClearCurrents),
             R"#(Empties previous current objects in order to get the current objects detected by the selector using UpdateCurrent. Objects selected when there is no open local context are called current objects; those selected in open local context, selected objects.)#"  , py::arg("theToUpdateViewer")
          )
        .def("DetectedCurrentObject",
             (handle<AIS_InteractiveObject> (AIS_InteractiveContext::*)() const) static_cast<handle<AIS_InteractiveObject> (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::DetectedCurrentObject),
             R"#(Returns current mouse-detected interactive object or null object, if there is no currently detected interactives DetectedCurrentOwner(), InitDetected(), MoreDetected(), NextDetected().)#" 
          )
        .def("SetSubIntensityColor",
             (void (AIS_InteractiveContext::*)(  const Quantity_Color &  ) ) static_cast<void (AIS_InteractiveContext::*)(  const Quantity_Color &  ) >(&AIS_InteractiveContext::SetSubIntensityColor),
             R"#(Sub-intensity allows temporary highlighting of particular objects with specified color in a manner of selection highlight, but without actual selection (e.g., global status and owner's selection state will not be updated). The method sets up the color for such highlighting. By default, this is Quantity_NOC_GRAY40.)#"  , py::arg("theColor")
          )
        .def("SubIntensityOn",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) >(&AIS_InteractiveContext::SubIntensityOn),
             R"#(Highlights, and removes highlights from, the displayed object which is displayed at Neutral Point with subintensity color. Available only for active local context. There is no effect if there is no local context. If a local context is open, the presentation of the Interactive Object activates the selection mode.)#"  , py::arg("theIObj"),  py::arg("theToUpdateViewer")
          )
        .def("SubIntensityOff",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_InteractiveObject> & ,   const bool  ) >(&AIS_InteractiveContext::SubIntensityOff),
             R"#(Removes the subintensity option for the entity. If a local context is open, the presentation of the Interactive Object activates the selection mode.)#"  , py::arg("theIObj"),  py::arg("theToUpdateViewer")
          )
        .def("SetSelection",
             (void (AIS_InteractiveContext::*)(  const handle<AIS_Selection> &  ) ) static_cast<void (AIS_InteractiveContext::*)(  const handle<AIS_Selection> &  ) >(&AIS_InteractiveContext::SetSelection),
             R"#(Sets selection instance to manipulate a container of selected owners)#"  , py::arg("theSelection")
          )
        .def("DumpJson",
             (void (AIS_InteractiveContext::*)( Standard_OStream & ,  int  ) const) static_cast<void (AIS_InteractiveContext::*)( Standard_OStream & ,  int  ) const>(&AIS_InteractiveContext::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
        .def("EntityOwners",
             []( AIS_InteractiveContext &self , NCollection_Shared<NCollection_IndexedMap<handle<SelectMgr_EntityOwner>>>& theOwners, const handle<AIS_InteractiveObject> & theIObj, const int theMode ){
                 handle<NCollection_Shared<NCollection_IndexedMap<handle<SelectMgr_EntityOwner>>>>  theOwners_ptr; theOwners_ptr = &theOwners;

                 self.EntityOwners(theOwners_ptr,theIObj,theMode);
                 return std::make_tuple(theOwners_ptr); },
             R"#(Returns a collection containing all entity owners created for the interactive object in specified selection mode (in all active modes if the Mode == -1))#"  , py::arg("theOwners"),  py::arg("theIObj"),  py::arg("theMode")=static_cast< const int>(- 1)
          )
        .def("PolygonOffsets",
             []( AIS_InteractiveContext &self ,  const handle<AIS_InteractiveObject> & anObj ){
                 int  aMode;
                float  aFactor;
                float  aUnits;

                 self.PolygonOffsets(anObj,aMode,aFactor,aUnits);
                 return std::make_tuple(aMode,aFactor,aUnits); },
             R"#(Retrieves current polygon offsets settings for Object.)#"  , py::arg("anObj")
          )
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_InteractiveContext::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_InteractiveContext::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_InteractiveContext::*)() const) static_cast< const handle<Standard_Type> & (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::DynamicType),
             R"#()#"
             
         )
       .def("HighlightStyle",
             ( const handle<Prs3d_Drawer> & (AIS_InteractiveContext::*)() const) static_cast< const handle<Prs3d_Drawer> & (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::HighlightStyle),
             R"#(Returns current dynamic highlight style settings corresponding to Prs3d_TypeOfHighlight_Dynamic. This is just a short-cut to HighlightStyle(Prs3d_TypeOfHighlight_Dynamic).)#"
             
         )
       .def("SelectionStyle",
             ( const handle<Prs3d_Drawer> & (AIS_InteractiveContext::*)() const) static_cast< const handle<Prs3d_Drawer> & (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::SelectionStyle),
             R"#(Returns current selection style settings corresponding to Prs3d_TypeOfHighlight_Selected. This is just a short-cut to HighlightStyle(Prs3d_TypeOfHighlight_Selected).)#"
             
         )
       .def("DetectedOwner",
             ( const handle<SelectMgr_EntityOwner> & (AIS_InteractiveContext::*)() const) static_cast< const handle<SelectMgr_EntityOwner> & (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::DetectedOwner),
             R"#(Returns the owner of the detected sensitive primitive which is currently dynamically highlighted. WARNING! This method is irrelevant to InitDetected()/MoreDetected()/NextDetected().)#"
             
         )
       .def("DetectedShape",
             ( const TopoDS_Shape & (AIS_InteractiveContext::*)() const) static_cast< const TopoDS_Shape & (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::DetectedShape),
             R"#(Returns the shape detected in local context.)#"
             
         )
       .def("Filters",
             ( const NCollection_List<handle<SelectMgr_Filter>> & (AIS_InteractiveContext::*)() const) static_cast< const NCollection_List<handle<SelectMgr_Filter>> & (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::Filters),
             R"#(Returns the list of filters active in a local context.)#"
             
         )
       .def("GlobalFilter",
             ( const handle<SelectMgr_AndOrFilter> & (AIS_InteractiveContext::*)() const) static_cast< const handle<SelectMgr_AndOrFilter> & (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::GlobalFilter),
             R"#(Returns the context selection global context filter.)#"
             
         )
       .def("DefaultDrawer",
             ( const handle<Prs3d_Drawer> & (AIS_InteractiveContext::*)() const) static_cast< const handle<Prs3d_Drawer> & (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::DefaultDrawer),
             R"#(Returns the default attribute manager. This contains all the color and line attributes which can be used by interactive objects which do not have their own attributes.)#"
             
         )
       .def("CurrentViewer",
             ( const handle<V3d_Viewer> & (AIS_InteractiveContext::*)() const) static_cast< const handle<V3d_Viewer> & (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::CurrentViewer),
             R"#(Returns the current viewer.)#"
             
         )
       .def("SelectionManager",
             ( const handle<SelectMgr_SelectionManager> & (AIS_InteractiveContext::*)() const) static_cast< const handle<SelectMgr_SelectionManager> & (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::SelectionManager),
             R"#()#"
             
         )
       .def("MainPrsMgr",
             ( const handle<PrsMgr_PresentationManager> & (AIS_InteractiveContext::*)() const) static_cast< const handle<PrsMgr_PresentationManager> & (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::MainPrsMgr),
             R"#()#"
             
         )
       .def("MainSelector",
             ( const handle<StdSelect_ViewerSelector3d> & (AIS_InteractiveContext::*)() const) static_cast< const handle<StdSelect_ViewerSelector3d> & (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::MainSelector),
             R"#()#"
             
         )
       .def("HiddenLineAspect",
             ( const handle<Prs3d_LineAspect> & (AIS_InteractiveContext::*)() const) static_cast< const handle<Prs3d_LineAspect> & (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::HiddenLineAspect),
             R"#(Initializes hidden line aspect in the default drawing tool, or Drawer. The default values are: Color: Quantity_NOC_YELLOW Type of line: Aspect_TOL_DASH Width: 1.)#"
             
         )
       .def("DetectedCurrentShape",
             ( const TopoDS_Shape & (AIS_InteractiveContext::*)() const) static_cast< const TopoDS_Shape & (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::DetectedCurrentShape),
             R"#(Returns current mouse-detected shape or empty (null) shape, if current interactive object is not a shape (AIS_Shape) or there is no current mouse-detected interactive object at all. DetectedCurrentOwner(), InitDetected(), MoreDetected(), NextDetected().)#"
             
         )
       .def("SubIntensityColor",
             ( const Quantity_Color & (AIS_InteractiveContext::*)() const) static_cast< const Quantity_Color & (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::SubIntensityColor),
             R"#(Sub-intensity allows temporary highlighting of particular objects with specified color in a manner of selection highlight, but without actual selection (e.g., global status and owner's selection state will not be updated). The method returns the color of such highlighting. By default, it is Quantity_NOC_GRAY40.)#"
             
         )
       .def("Selection",
             ( const handle<AIS_Selection> & (AIS_InteractiveContext::*)() const) static_cast< const handle<AIS_Selection> & (AIS_InteractiveContext::*)() const>(&AIS_InteractiveContext::Selection),
             R"#(Returns selection instance)#"
             
         )
;

    // Class AIS_InteractiveObject from ./opencascade/AIS_InteractiveObject.hxx
    klass = m.attr("AIS_InteractiveObject");


    // nested enums

    static_cast<py::class_<AIS_InteractiveObject ,opencascade::handle<AIS_InteractiveObject> ,Py_AIS_InteractiveObject , SelectMgr_SelectableObject >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("Type",
             (AIS_KindOfInteractive (AIS_InteractiveObject::*)() const) static_cast<AIS_KindOfInteractive (AIS_InteractiveObject::*)() const>(&AIS_InteractiveObject::Type),
             R"#(Returns the kind of Interactive Object; AIS_KindOfInteractive_None by default.)#" 
          )
        .def("Signature",
             (int (AIS_InteractiveObject::*)() const) static_cast<int (AIS_InteractiveObject::*)() const>(&AIS_InteractiveObject::Signature),
             R"#(Specifies additional characteristics of Interactive Object of Type(); -1 by default. Among the datums, this signature is attributed to the shape. The remaining datums have the following default signatures: - Point signature 1 - Axis signature 2 - Trihedron signature 3 - PlaneTrihedron signature 4 - Line signature 5 - Circle signature 6 - Plane signature 7.)#" 
          )
        .def("Redisplay",
             (void (AIS_InteractiveObject::*)(  const bool  ) ) static_cast<void (AIS_InteractiveObject::*)(  const bool  ) >(&AIS_InteractiveObject::Redisplay),
             R"#(Updates the active presentation; if <AllModes> = true all the presentations inside are recomputed. IMPORTANT: It is preferable to call Redisplay method of corresponding AIS_InteractiveContext instance for cases when it is accessible. This method just redirects call to myCTXPtr, so this class field must be up to date for proper result.)#"  , py::arg("AllModes")=static_cast< const bool>(false)
          )
        .def("HasInteractiveContext",
             (bool (AIS_InteractiveObject::*)() const) static_cast<bool (AIS_InteractiveObject::*)() const>(&AIS_InteractiveObject::HasInteractiveContext),
             R"#(Indicates whether the Interactive Object has a pointer to an interactive context.)#" 
          )
        .def("InteractiveContext",
             (AIS_InteractiveContext * (AIS_InteractiveObject::*)() const) static_cast<AIS_InteractiveContext * (AIS_InteractiveObject::*)() const>(&AIS_InteractiveObject::InteractiveContext),
             R"#(Returns the context pointer to the interactive context.)#" 
          )
        .def("SetContext",
             (void (AIS_InteractiveObject::*)(  const handle<AIS_InteractiveContext> &  ) ) static_cast<void (AIS_InteractiveObject::*)(  const handle<AIS_InteractiveContext> &  ) >(&AIS_InteractiveObject::SetContext),
             R"#(Sets the interactive context aCtx and provides a link to the default drawing tool or "Drawer" if there is none.)#"  , py::arg("aCtx")
          )
        .def("HasOwner",
             (bool (AIS_InteractiveObject::*)() const) static_cast<bool (AIS_InteractiveObject::*)() const>(&AIS_InteractiveObject::HasOwner),
             R"#(Returns true if the object has an owner attributed to it. The owner can be a shape for a set of sub-shapes or a sub-shape for sub-shapes which it is composed of, and takes the form of a transient.)#" 
          )
        .def("SetOwner",
             (void (AIS_InteractiveObject::*)(  const handle<Standard_Transient> &  ) ) static_cast<void (AIS_InteractiveObject::*)(  const handle<Standard_Transient> &  ) >(&AIS_InteractiveObject::SetOwner),
             R"#(Allows you to attribute the owner theApplicativeEntity to an Interactive Object. This can be a shape for a set of sub-shapes or a sub-shape for sub-shapes which it is composed of. The owner takes the form of a transient.)#"  , py::arg("theApplicativeEntity")
          )
        .def("ClearOwner",
             (void (AIS_InteractiveObject::*)() ) static_cast<void (AIS_InteractiveObject::*)() >(&AIS_InteractiveObject::ClearOwner),
             R"#(Each Interactive Object has methods which allow us to attribute an Owner to it in the form of a Transient. This method removes the owner from the graphic entity.)#" 
          )
        .def("ProcessDragging",
             (bool (AIS_InteractiveObject::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> & ,   const handle<SelectMgr_EntityOwner> & ,   const NCollection_Vec2<int> & ,   const NCollection_Vec2<int> & ,   const AIS_DragAction  ) ) static_cast<bool (AIS_InteractiveObject::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> & ,   const handle<SelectMgr_EntityOwner> & ,   const NCollection_Vec2<int> & ,   const NCollection_Vec2<int> & ,   const AIS_DragAction  ) >(&AIS_InteractiveObject::ProcessDragging),
             R"#(Drag object in the viewer.)#"  , py::arg("theCtx"),  py::arg("theView"),  py::arg("theOwner"),  py::arg("theDragFrom"),  py::arg("theDragTo"),  py::arg("theAction")
          )
        .def("GetContext",
             (handle<AIS_InteractiveContext> (AIS_InteractiveObject::*)() const) static_cast<handle<AIS_InteractiveContext> (AIS_InteractiveObject::*)() const>(&AIS_InteractiveObject::GetContext),
             R"#(Returns the context pointer to the interactive context.)#" 
          )
        .def("HasPresentation",
             (bool (AIS_InteractiveObject::*)() const) static_cast<bool (AIS_InteractiveObject::*)() const>(&AIS_InteractiveObject::HasPresentation),
             R"#(Returns TRUE when this object has a presentation in the current DisplayMode())#" 
          )
        .def("Presentation",
             (handle<Prs3d_Presentation> (AIS_InteractiveObject::*)() const) static_cast<handle<Prs3d_Presentation> (AIS_InteractiveObject::*)() const>(&AIS_InteractiveObject::Presentation),
             R"#(Returns the current presentation of this object according to the current DisplayMode())#" 
          )
        .def("SetAspect",
             (void (AIS_InteractiveObject::*)(  const handle<Prs3d_BasicAspect> &  ) ) static_cast<void (AIS_InteractiveObject::*)(  const handle<Prs3d_BasicAspect> &  ) >(&AIS_InteractiveObject::SetAspect),
             R"#(Sets the graphic basic aspect to the current presentation.)#"  , py::arg("anAspect")
          )
        .def("DumpJson",
             (void (AIS_InteractiveObject::*)( Standard_OStream & ,  int  ) const) static_cast<void (AIS_InteractiveObject::*)( Standard_OStream & ,  int  ) const>(&AIS_InteractiveObject::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_InteractiveObject::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_InteractiveObject::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_InteractiveObject::*)() const) static_cast< const handle<Standard_Type> & (AIS_InteractiveObject::*)() const>(&AIS_InteractiveObject::DynamicType),
             R"#()#"
             
         )
       .def("GetOwner",
             ( const handle<Standard_Transient> & (AIS_InteractiveObject::*)() const) static_cast< const handle<Standard_Transient> & (AIS_InteractiveObject::*)() const>(&AIS_InteractiveObject::GetOwner),
             R"#(Returns the owner of the Interactive Object. The owner can be a shape for a set of sub-shapes or a sub-shape for sub-shapes which it is composed of, and takes the form of a transient. There are two types of owners: - Direct owners, decomposition shapes such as edges, wires, and faces. - Users, presentable objects connecting to sensitive primitives, or a shape which has been decomposed.)#"
             
         )
;

    // Class AIS_LightSourceOwner from ./opencascade/AIS_LightSource.hxx
    klass = m.attr("AIS_LightSourceOwner");


    // nested enums

    static_cast<py::class_<AIS_LightSourceOwner ,opencascade::handle<AIS_LightSourceOwner>  , SelectMgr_EntityOwner >>(klass)
    // constructors
        .def(py::init<  const handle<AIS_LightSource> &,int >()  , py::arg("theObject"),  py::arg("thePriority")=static_cast<int>(5) )
    // custom constructors
    // methods
        .def("HandleMouseClick",
             (bool (AIS_LightSourceOwner::*)(  const NCollection_Vec2<int> & ,  Aspect_VKeyMouse ,  Aspect_VKeyFlags ,  bool  ) ) static_cast<bool (AIS_LightSourceOwner::*)(  const NCollection_Vec2<int> & ,  Aspect_VKeyMouse ,  Aspect_VKeyFlags ,  bool  ) >(&AIS_LightSourceOwner::HandleMouseClick),
             R"#(Handle mouse button click event.)#"  , py::arg("thePoint"),  py::arg("theButton"),  py::arg("theModifiers"),  py::arg("theIsDoubleClick")
          )
        .def("HilightWithColor",
             (void (AIS_LightSourceOwner::*)(  const handle<PrsMgr_PresentationManager> & ,   const handle<Prs3d_Drawer> & ,   const int  ) ) static_cast<void (AIS_LightSourceOwner::*)(  const handle<PrsMgr_PresentationManager> & ,   const handle<Prs3d_Drawer> & ,   const int  ) >(&AIS_LightSourceOwner::HilightWithColor),
             R"#(Highlights selectable object's presentation with display mode in presentation manager with given highlight style. Also a check for auto-highlight is performed - if selectable object manages highlighting on its own, execution will be passed to SelectMgr_SelectableObject::HilightOwnerWithColor method.)#"  , py::arg("thePrsMgr"),  py::arg("theStyle"),  py::arg("theMode")
          )
        .def("IsForcedHilight",
             (bool (AIS_LightSourceOwner::*)() const) static_cast<bool (AIS_LightSourceOwner::*)() const>(&AIS_LightSourceOwner::IsForcedHilight),
             R"#(Always update dynamic highlighting.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_LightSourceOwner::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_LightSourceOwner::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_LightSourceOwner::*)() const) static_cast< const handle<Standard_Type> & (AIS_LightSourceOwner::*)() const>(&AIS_LightSourceOwner::DynamicType),
             R"#()#"
             
         )
;

    // Class AIS_ManipulatorOwner from ./opencascade/AIS_ManipulatorOwner.hxx
    klass = m.attr("AIS_ManipulatorOwner");


    // nested enums

    static_cast<py::class_<AIS_ManipulatorOwner ,opencascade::handle<AIS_ManipulatorOwner>  , SelectMgr_EntityOwner >>(klass)
    // constructors
        .def(py::init<  const handle<SelectMgr_SelectableObject> &, const int, const AIS_ManipulatorMode, const int >()  , py::arg("theSelObject"),  py::arg("theIndex"),  py::arg("theMode"),  py::arg("thePriority")=static_cast< const int>(0) )
    // custom constructors
    // methods
        .def("HilightWithColor",
             (void (AIS_ManipulatorOwner::*)(  const handle<PrsMgr_PresentationManager> & ,   const handle<Prs3d_Drawer> & ,   const int  ) ) static_cast<void (AIS_ManipulatorOwner::*)(  const handle<PrsMgr_PresentationManager> & ,   const handle<Prs3d_Drawer> & ,   const int  ) >(&AIS_ManipulatorOwner::HilightWithColor),
             R"#()#"  , py::arg("thePM"),  py::arg("theStyle"),  py::arg("theMode")
          )
        .def("IsHilighted",
             (bool (AIS_ManipulatorOwner::*)(  const handle<PrsMgr_PresentationManager> & ,   const int  ) const) static_cast<bool (AIS_ManipulatorOwner::*)(  const handle<PrsMgr_PresentationManager> & ,   const int  ) const>(&AIS_ManipulatorOwner::IsHilighted),
             R"#()#"  , py::arg("thePM"),  py::arg("theMode")
          )
        .def("Unhilight",
             (void (AIS_ManipulatorOwner::*)(  const handle<PrsMgr_PresentationManager> & ,   const int  ) ) static_cast<void (AIS_ManipulatorOwner::*)(  const handle<PrsMgr_PresentationManager> & ,   const int  ) >(&AIS_ManipulatorOwner::Unhilight),
             R"#()#"  , py::arg("thePM"),  py::arg("theMode")
          )
        .def("Mode",
             (AIS_ManipulatorMode (AIS_ManipulatorOwner::*)() const) static_cast<AIS_ManipulatorMode (AIS_ManipulatorOwner::*)() const>(&AIS_ManipulatorOwner::Mode),
             R"#()#" 
          )
        .def("Index",
             (int (AIS_ManipulatorOwner::*)() const) static_cast<int (AIS_ManipulatorOwner::*)() const>(&AIS_ManipulatorOwner::Index),
             R"#(Returns index of manipulator axis.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_ManipulatorOwner::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_ManipulatorOwner::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_ManipulatorOwner::*)() const) static_cast< const handle<Standard_Type> & (AIS_ManipulatorOwner::*)() const>(&AIS_ManipulatorOwner::DynamicType),
             R"#()#"
             
         )
;

    // Class AIS_PointCloudOwner from ./opencascade/AIS_PointCloud.hxx
    klass = m.attr("AIS_PointCloudOwner");


    // nested enums

    static_cast<py::class_<AIS_PointCloudOwner ,opencascade::handle<AIS_PointCloudOwner>  , SelectMgr_EntityOwner >>(klass)
    // constructors
        .def(py::init<  const handle<AIS_PointCloud> & >()  , py::arg("theOrigin") )
    // custom constructors
    // methods
        .def("IsForcedHilight",
             (bool (AIS_PointCloudOwner::*)() const) static_cast<bool (AIS_PointCloudOwner::*)() const>(&AIS_PointCloudOwner::IsForcedHilight),
             R"#(Always update dynamic highlighting.)#" 
          )
        .def("HilightWithColor",
             (void (AIS_PointCloudOwner::*)(  const handle<PrsMgr_PresentationManager> & ,   const handle<Prs3d_Drawer> & ,   const int  ) ) static_cast<void (AIS_PointCloudOwner::*)(  const handle<PrsMgr_PresentationManager> & ,   const handle<Prs3d_Drawer> & ,   const int  ) >(&AIS_PointCloudOwner::HilightWithColor),
             R"#(Handle dynamic highlighting.)#"  , py::arg("thePrsMgr"),  py::arg("theStyle"),  py::arg("theMode")
          )
        .def("Unhilight",
             (void (AIS_PointCloudOwner::*)(  const handle<PrsMgr_PresentationManager> & ,   const int  ) ) static_cast<void (AIS_PointCloudOwner::*)(  const handle<PrsMgr_PresentationManager> & ,   const int  ) >(&AIS_PointCloudOwner::Unhilight),
             R"#(Removes highlighting.)#"  , py::arg("thePrsMgr"),  py::arg("theMode")
          )
        .def("Clear",
             (void (AIS_PointCloudOwner::*)(  const handle<PrsMgr_PresentationManager> & ,   const int  ) ) static_cast<void (AIS_PointCloudOwner::*)(  const handle<PrsMgr_PresentationManager> & ,   const int  ) >(&AIS_PointCloudOwner::Clear),
             R"#(Clears presentation.)#"  , py::arg("thePrsMgr"),  py::arg("theMode")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_PointCloudOwner::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_PointCloudOwner::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_PointCloudOwner::*)() const) static_cast< const handle<Standard_Type> & (AIS_PointCloudOwner::*)() const>(&AIS_PointCloudOwner::DynamicType),
             R"#()#"
             
         )
       .def("SelectedPoints",
             ( const handle<TColStd_HPackedMapOfInteger> & (AIS_PointCloudOwner::*)() const) static_cast< const handle<TColStd_HPackedMapOfInteger> & (AIS_PointCloudOwner::*)() const>(&AIS_PointCloudOwner::SelectedPoints),
             R"#(Return selected points. WARNING! Indexation starts with 0 (shifted by -1 comparing to Graphic3d_ArrayOfPoints::Vertice()).)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("DetectedPoints",
             ( const handle<TColStd_HPackedMapOfInteger> & (AIS_PointCloudOwner::*)() const) static_cast< const handle<TColStd_HPackedMapOfInteger> & (AIS_PointCloudOwner::*)() const>(&AIS_PointCloudOwner::DetectedPoints),
             R"#(Return last detected points. WARNING! Indexation starts with 0 (shifted by -1 comparing to Graphic3d_ArrayOfPoints::Vertice()).)#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class AIS_Selection from ./opencascade/AIS_Selection.hxx
    klass = m.attr("AIS_Selection");


    // nested enums

    static_cast<py::class_<AIS_Selection ,opencascade::handle<AIS_Selection>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Clear",
             (void (AIS_Selection::*)() ) static_cast<void (AIS_Selection::*)() >(&AIS_Selection::Clear),
             R"#(removes all the object of the selection.)#" 
          )
        .def("Select",
             (AIS_SelectStatus (AIS_Selection::*)(  const handle<SelectMgr_EntityOwner> & ,   const handle<SelectMgr_Filter> & ,   const AIS_SelectionScheme ,   const bool  ) ) static_cast<AIS_SelectStatus (AIS_Selection::*)(  const handle<SelectMgr_EntityOwner> & ,   const handle<SelectMgr_Filter> & ,   const AIS_SelectionScheme ,   const bool  ) >(&AIS_Selection::Select),
             R"#(if the object is not yet in the selection, it will be added. if the object is already in the selection, it will be removed.)#"  , py::arg("theOwner"),  py::arg("theFilter"),  py::arg("theSelScheme"),  py::arg("theIsDetected")
          )
        .def("AddSelect",
             (AIS_SelectStatus (AIS_Selection::*)(  const handle<SelectMgr_EntityOwner> &  ) ) static_cast<AIS_SelectStatus (AIS_Selection::*)(  const handle<SelectMgr_EntityOwner> &  ) >(&AIS_Selection::AddSelect),
             R"#(the object is always add int the selection. faster when the number of objects selected is great.)#"  , py::arg("theObject")
          )
        .def("ClearAndSelect",
             (void (AIS_Selection::*)(  const handle<SelectMgr_EntityOwner> & ,   const handle<SelectMgr_Filter> & ,   const bool  ) ) static_cast<void (AIS_Selection::*)(  const handle<SelectMgr_EntityOwner> & ,   const handle<SelectMgr_Filter> & ,   const bool  ) >(&AIS_Selection::ClearAndSelect),
             R"#(clears the selection and adds the object in the selection.)#"  , py::arg("theObject"),  py::arg("theFilter"),  py::arg("theIsDetected")
          )
        .def("IsSelected",
             (bool (AIS_Selection::*)(  const handle<SelectMgr_EntityOwner> &  ) const) static_cast<bool (AIS_Selection::*)(  const handle<SelectMgr_EntityOwner> &  ) const>(&AIS_Selection::IsSelected),
             R"#(checks if the object is in the selection.)#"  , py::arg("theObject")
          )
        .def("Extent",
             (int (AIS_Selection::*)() const) static_cast<int (AIS_Selection::*)() const>(&AIS_Selection::Extent),
             R"#(Return the number of selected objects.)#" 
          )
        .def("IsEmpty",
             (bool (AIS_Selection::*)() const) static_cast<bool (AIS_Selection::*)() const>(&AIS_Selection::IsEmpty),
             R"#(Return true if list of selected objects is empty.)#" 
          )
        .def("Init",
             (void (AIS_Selection::*)() ) static_cast<void (AIS_Selection::*)() >(&AIS_Selection::Init),
             R"#(Start iteration through selected objects.)#" 
          )
        .def("More",
             (bool (AIS_Selection::*)() const) static_cast<bool (AIS_Selection::*)() const>(&AIS_Selection::More),
             R"#(Return true if iterator points to selected object.)#" 
          )
        .def("Next",
             (void (AIS_Selection::*)() ) static_cast<void (AIS_Selection::*)() >(&AIS_Selection::Next),
             R"#(Continue iteration through selected objects.)#" 
          )
        .def("SelectOwners",
             (void (AIS_Selection::*)(  const NCollection_Array1<handle<SelectMgr_EntityOwner>> & ,   const AIS_SelectionScheme ,   const bool ,   const handle<SelectMgr_Filter> &  ) ) static_cast<void (AIS_Selection::*)(  const NCollection_Array1<handle<SelectMgr_EntityOwner>> & ,   const AIS_SelectionScheme ,   const bool ,   const handle<SelectMgr_Filter> &  ) >(&AIS_Selection::SelectOwners),
             R"#(Select or deselect owners depending on the selection scheme.)#"  , py::arg("thePickedOwners"),  py::arg("theSelScheme"),  py::arg("theToAllowSelOverlap"),  py::arg("theFilter")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_Selection::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_Selection::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_Selection::*)() const) static_cast< const handle<Standard_Type> & (AIS_Selection::*)() const>(&AIS_Selection::DynamicType),
             R"#()#"
             
         )
       .def("Objects",
             ( const NCollection_List<handle<SelectMgr_EntityOwner>> & (AIS_Selection::*)() const) static_cast< const NCollection_List<handle<SelectMgr_EntityOwner>> & (AIS_Selection::*)() const>(&AIS_Selection::Objects),
             R"#(Return the list of selected objects.)#"
             
         )
       .def("Value",
             ( const handle<SelectMgr_EntityOwner> & (AIS_Selection::*)() const) static_cast< const handle<SelectMgr_EntityOwner> & (AIS_Selection::*)() const>(&AIS_Selection::Value),
             R"#(Return selected object at iterator position.)#"
             
         )
;

    // Class AIS_TrihedronOwner from ./opencascade/AIS_TrihedronOwner.hxx
    klass = m.attr("AIS_TrihedronOwner");


    // nested enums

    static_cast<py::class_<AIS_TrihedronOwner ,opencascade::handle<AIS_TrihedronOwner>  , SelectMgr_EntityOwner >>(klass)
    // constructors
        .def(py::init<  const handle<SelectMgr_SelectableObject> &, const Prs3d_DatumParts, const int >()  , py::arg("theSelObject"),  py::arg("theDatumPart"),  py::arg("thePriority") )
    // custom constructors
    // methods
        .def("DatumPart",
             (Prs3d_DatumParts (AIS_TrihedronOwner::*)() const) static_cast<Prs3d_DatumParts (AIS_TrihedronOwner::*)() const>(&AIS_TrihedronOwner::DatumPart),
             R"#(Returns the datum part identifier.)#" 
          )
        .def("HilightWithColor",
             (void (AIS_TrihedronOwner::*)(  const handle<PrsMgr_PresentationManager> & ,   const handle<Prs3d_Drawer> & ,   const int  ) ) static_cast<void (AIS_TrihedronOwner::*)(  const handle<PrsMgr_PresentationManager> & ,   const handle<Prs3d_Drawer> & ,   const int  ) >(&AIS_TrihedronOwner::HilightWithColor),
             R"#(Highlights selectable object's presentation.)#"  , py::arg("thePM"),  py::arg("theStyle"),  py::arg("theMode")
          )
        .def("IsHilighted",
             (bool (AIS_TrihedronOwner::*)(  const handle<PrsMgr_PresentationManager> & ,   const int  ) const) static_cast<bool (AIS_TrihedronOwner::*)(  const handle<PrsMgr_PresentationManager> & ,   const int  ) const>(&AIS_TrihedronOwner::IsHilighted),
             R"#(Returns true if the presentation manager thePM highlights selections corresponding to the selection mode aMode.)#"  , py::arg("thePM"),  py::arg("theMode")
          )
        .def("Unhilight",
             (void (AIS_TrihedronOwner::*)(  const handle<PrsMgr_PresentationManager> & ,   const int  ) ) static_cast<void (AIS_TrihedronOwner::*)(  const handle<PrsMgr_PresentationManager> & ,   const int  ) >(&AIS_TrihedronOwner::Unhilight),
             R"#(Removes highlighting from the owner of a detected selectable object in the presentation manager thePM.)#"  , py::arg("thePM"),  py::arg("theMode")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_TrihedronOwner::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_TrihedronOwner::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_TrihedronOwner::*)() const) static_cast< const handle<Standard_Type> & (AIS_TrihedronOwner::*)() const>(&AIS_TrihedronOwner::DynamicType),
             R"#()#"
             
         )
;

    // Class AIS_TypeFilter from ./opencascade/AIS_TypeFilter.hxx
    klass = m.attr("AIS_TypeFilter");


    // nested enums

    static_cast<py::class_<AIS_TypeFilter ,opencascade::handle<AIS_TypeFilter>  , SelectMgr_Filter >>(klass)
    // constructors
        .def(py::init<  const AIS_KindOfInteractive >()  , py::arg("aGivenKind") )
    // custom constructors
    // methods
        .def("IsOk",
             (bool (AIS_TypeFilter::*)(  const handle<SelectMgr_EntityOwner> &  ) const) static_cast<bool (AIS_TypeFilter::*)(  const handle<SelectMgr_EntityOwner> &  ) const>(&AIS_TypeFilter::IsOk),
             R"#(Returns False if the transient is not an Interactive Object, or if the type of the Interactive Object is not the same as that stored in the filter.)#"  , py::arg("anobj")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_TypeFilter::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_TypeFilter::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_TypeFilter::*)() const) static_cast< const handle<Standard_Type> & (AIS_TypeFilter::*)() const>(&AIS_TypeFilter::DynamicType),
             R"#()#"
             
         )
;

    // Class AIS_ViewController from ./opencascade/AIS_ViewController.hxx
    klass = m.attr("AIS_ViewController");


    // nested enums

    static_cast<py::class_<AIS_ViewController , shared_ptr<AIS_ViewController>  , Aspect_WindowInputListener >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("InputBuffer",
             ( const AIS_ViewInputBuffer & (AIS_ViewController::*)( AIS_ViewInputBufferType  ) const) static_cast< const AIS_ViewInputBuffer & (AIS_ViewController::*)( AIS_ViewInputBufferType  ) const>(&AIS_ViewController::InputBuffer),
             R"#(Return input buffer.)#"  , py::arg("theType")
          )
        .def("ChangeInputBuffer",
             (AIS_ViewInputBuffer & (AIS_ViewController::*)( AIS_ViewInputBufferType  ) ) static_cast<AIS_ViewInputBuffer & (AIS_ViewController::*)( AIS_ViewInputBufferType  ) >(&AIS_ViewController::ChangeInputBuffer),
             R"#(Return input buffer.)#"  , py::arg("theType")
          )
        .def("SetViewAnimation",
             (void (AIS_ViewController::*)(  const handle<AIS_AnimationCamera> &  ) ) static_cast<void (AIS_ViewController::*)(  const handle<AIS_AnimationCamera> &  ) >(&AIS_ViewController::SetViewAnimation),
             R"#(Set view animation to be handled within handleViewRedraw().)#"  , py::arg("theAnimation")
          )
        .def("AbortViewAnimation",
             (void (AIS_ViewController::*)() ) static_cast<void (AIS_ViewController::*)() >(&AIS_ViewController::AbortViewAnimation),
             R"#(Interrupt active view animation.)#" 
          )
        .def("SetObjectsAnimation",
             (void (AIS_ViewController::*)(  const handle<AIS_Animation> &  ) ) static_cast<void (AIS_ViewController::*)(  const handle<AIS_Animation> &  ) >(&AIS_ViewController::SetObjectsAnimation),
             R"#(Set object animation to be handled within handleViewRedraw().)#"  , py::arg("theAnimation")
          )
        .def("ToPauseObjectsAnimation",
             (bool (AIS_ViewController::*)() const) static_cast<bool (AIS_ViewController::*)() const>(&AIS_ViewController::ToPauseObjectsAnimation),
             R"#(Return TRUE if object animation should be paused on mouse click; FALSE by default.)#" 
          )
        .def("SetPauseObjectsAnimation",
             (void (AIS_ViewController::*)( bool  ) ) static_cast<void (AIS_ViewController::*)( bool  ) >(&AIS_ViewController::SetPauseObjectsAnimation),
             R"#(Set if object animation should be paused on mouse click.)#"  , py::arg("theToPause")
          )
        .def("IsContinuousRedraw",
             (bool (AIS_ViewController::*)() const) static_cast<bool (AIS_ViewController::*)() const>(&AIS_ViewController::IsContinuousRedraw),
             R"#(Return TRUE if continuous redrawing is enabled; FALSE by default. This option would request a next viewer frame to be completely redrawn right after current frame is finished.)#" 
          )
        .def("SetContinuousRedraw",
             (void (AIS_ViewController::*)( bool  ) ) static_cast<void (AIS_ViewController::*)( bool  ) >(&AIS_ViewController::SetContinuousRedraw),
             R"#(Enable or disable continuous updates.)#"  , py::arg("theToEnable")
          )
        .def("RotationMode",
             (AIS_RotationMode (AIS_ViewController::*)() const) static_cast<AIS_RotationMode (AIS_ViewController::*)() const>(&AIS_ViewController::RotationMode),
             R"#(Return camera rotation mode, AIS_RotationMode_BndBoxActive by default.)#" 
          )
        .def("SetRotationMode",
             (void (AIS_ViewController::*)( AIS_RotationMode  ) ) static_cast<void (AIS_ViewController::*)( AIS_RotationMode  ) >(&AIS_ViewController::SetRotationMode),
             R"#(Set camera rotation mode.)#"  , py::arg("theMode")
          )
        .def("NavigationMode",
             (AIS_NavigationMode (AIS_ViewController::*)() const) static_cast<AIS_NavigationMode (AIS_ViewController::*)() const>(&AIS_ViewController::NavigationMode),
             R"#(Return camera navigation mode; AIS_NavigationMode_Orbit by default.)#" 
          )
        .def("SetNavigationMode",
             (void (AIS_ViewController::*)( AIS_NavigationMode  ) ) static_cast<void (AIS_ViewController::*)( AIS_NavigationMode  ) >(&AIS_ViewController::SetNavigationMode),
             R"#(Set camera navigation mode.)#"  , py::arg("theMode")
          )
        .def("MouseAcceleration",
             (float (AIS_ViewController::*)() const) static_cast<float (AIS_ViewController::*)() const>(&AIS_ViewController::MouseAcceleration),
             R"#(Return mouse input acceleration ratio in First Person mode; 1.0 by default.)#" 
          )
        .def("SetMouseAcceleration",
             (void (AIS_ViewController::*)( float  ) ) static_cast<void (AIS_ViewController::*)( float  ) >(&AIS_ViewController::SetMouseAcceleration),
             R"#(Set mouse input acceleration ratio.)#"  , py::arg("theRatio")
          )
        .def("OrbitAcceleration",
             (float (AIS_ViewController::*)() const) static_cast<float (AIS_ViewController::*)() const>(&AIS_ViewController::OrbitAcceleration),
             R"#(Return orbit rotation acceleration ratio; 1.0 by default.)#" 
          )
        .def("SetOrbitAcceleration",
             (void (AIS_ViewController::*)( float  ) ) static_cast<void (AIS_ViewController::*)( float  ) >(&AIS_ViewController::SetOrbitAcceleration),
             R"#(Set orbit rotation acceleration ratio.)#"  , py::arg("theRatio")
          )
        .def("ToShowPanAnchorPoint",
             (bool (AIS_ViewController::*)() const) static_cast<bool (AIS_ViewController::*)() const>(&AIS_ViewController::ToShowPanAnchorPoint),
             R"#(Return TRUE if panning anchor point within perspective projection should be displayed in 3D Viewer; TRUE by default.)#" 
          )
        .def("SetShowPanAnchorPoint",
             (void (AIS_ViewController::*)( bool  ) ) static_cast<void (AIS_ViewController::*)( bool  ) >(&AIS_ViewController::SetShowPanAnchorPoint),
             R"#(Set if panning anchor point within perspective projection should be displayed in 3D Viewer.)#"  , py::arg("theToShow")
          )
        .def("ToShowRotateCenter",
             (bool (AIS_ViewController::*)() const) static_cast<bool (AIS_ViewController::*)() const>(&AIS_ViewController::ToShowRotateCenter),
             R"#(Return TRUE if rotation point should be displayed in 3D Viewer; TRUE by default.)#" 
          )
        .def("SetShowRotateCenter",
             (void (AIS_ViewController::*)( bool  ) ) static_cast<void (AIS_ViewController::*)( bool  ) >(&AIS_ViewController::SetShowRotateCenter),
             R"#(Set if rotation point should be displayed in 3D Viewer.)#"  , py::arg("theToShow")
          )
        .def("ToLockOrbitZUp",
             (bool (AIS_ViewController::*)() const) static_cast<bool (AIS_ViewController::*)() const>(&AIS_ViewController::ToLockOrbitZUp),
             R"#(Return TRUE if camera up orientation within AIS_NavigationMode_Orbit rotation mode should be forced Z up; FALSE by default.)#" 
          )
        .def("SetLockOrbitZUp",
             (void (AIS_ViewController::*)( bool  ) ) static_cast<void (AIS_ViewController::*)( bool  ) >(&AIS_ViewController::SetLockOrbitZUp),
             R"#(Set if camera up orientation within AIS_NavigationMode_Orbit rotation mode should be forced Z up.)#"  , py::arg("theToForceUp")
          )
        .def("ToAllowTouchZRotation",
             (bool (AIS_ViewController::*)() const) static_cast<bool (AIS_ViewController::*)() const>(&AIS_ViewController::ToAllowTouchZRotation),
             R"#(Return TRUE if z-rotation via two-touches gesture is enabled; FALSE by default.)#" 
          )
        .def("SetAllowTouchZRotation",
             (void (AIS_ViewController::*)( bool  ) ) static_cast<void (AIS_ViewController::*)( bool  ) >(&AIS_ViewController::SetAllowTouchZRotation),
             R"#(Set if z-rotation via two-touches gesture is enabled.)#"  , py::arg("theToEnable")
          )
        .def("ToAllowRotation",
             (bool (AIS_ViewController::*)() const) static_cast<bool (AIS_ViewController::*)() const>(&AIS_ViewController::ToAllowRotation),
             R"#(Return TRUE if camera rotation is allowed; TRUE by default.)#" 
          )
        .def("SetAllowRotation",
             (void (AIS_ViewController::*)( bool  ) ) static_cast<void (AIS_ViewController::*)( bool  ) >(&AIS_ViewController::SetAllowRotation),
             R"#(Set if camera rotation is allowed.)#"  , py::arg("theToEnable")
          )
        .def("ToAllowPanning",
             (bool (AIS_ViewController::*)() const) static_cast<bool (AIS_ViewController::*)() const>(&AIS_ViewController::ToAllowPanning),
             R"#(Return TRUE if panning is allowed; TRUE by default.)#" 
          )
        .def("SetAllowPanning",
             (void (AIS_ViewController::*)( bool  ) ) static_cast<void (AIS_ViewController::*)( bool  ) >(&AIS_ViewController::SetAllowPanning),
             R"#(Set if panning is allowed.)#"  , py::arg("theToEnable")
          )
        .def("ToAllowZooming",
             (bool (AIS_ViewController::*)() const) static_cast<bool (AIS_ViewController::*)() const>(&AIS_ViewController::ToAllowZooming),
             R"#(Return TRUE if zooming is allowed; TRUE by default.)#" 
          )
        .def("SetAllowZooming",
             (void (AIS_ViewController::*)( bool  ) ) static_cast<void (AIS_ViewController::*)( bool  ) >(&AIS_ViewController::SetAllowZooming),
             R"#(Set if zooming is allowed.)#"  , py::arg("theToEnable")
          )
        .def("ToAllowZFocus",
             (bool (AIS_ViewController::*)() const) static_cast<bool (AIS_ViewController::*)() const>(&AIS_ViewController::ToAllowZFocus),
             R"#(Return TRUE if ZFocus change is allowed; TRUE by default.)#" 
          )
        .def("SetAllowZFocus",
             (void (AIS_ViewController::*)( bool  ) ) static_cast<void (AIS_ViewController::*)( bool  ) >(&AIS_ViewController::SetAllowZFocus),
             R"#(Set if ZFocus change is allowed.)#"  , py::arg("theToEnable")
          )
        .def("ToAllowHighlight",
             (bool (AIS_ViewController::*)() const) static_cast<bool (AIS_ViewController::*)() const>(&AIS_ViewController::ToAllowHighlight),
             R"#(Return TRUE if dynamic highlight on mouse move is allowed; TRUE by default.)#" 
          )
        .def("SetAllowHighlight",
             (void (AIS_ViewController::*)( bool  ) ) static_cast<void (AIS_ViewController::*)( bool  ) >(&AIS_ViewController::SetAllowHighlight),
             R"#(Set if dragging object is allowed.)#"  , py::arg("theToEnable")
          )
        .def("ToAllowDragging",
             (bool (AIS_ViewController::*)() const) static_cast<bool (AIS_ViewController::*)() const>(&AIS_ViewController::ToAllowDragging),
             R"#(Return TRUE if dragging object is allowed; TRUE by default.)#" 
          )
        .def("SetAllowDragging",
             (void (AIS_ViewController::*)( bool  ) ) static_cast<void (AIS_ViewController::*)( bool  ) >(&AIS_ViewController::SetAllowDragging),
             R"#(Set if dynamic highlight on mouse move is allowed.)#"  , py::arg("theToEnable")
          )
        .def("ToStickToRayOnZoom",
             (bool (AIS_ViewController::*)() const) static_cast<bool (AIS_ViewController::*)() const>(&AIS_ViewController::ToStickToRayOnZoom),
             R"#(Return TRUE if picked point should be projected to picking ray on zooming at point; TRUE by default.)#" 
          )
        .def("SetStickToRayOnZoom",
             (void (AIS_ViewController::*)( bool  ) ) static_cast<void (AIS_ViewController::*)( bool  ) >(&AIS_ViewController::SetStickToRayOnZoom),
             R"#(Set if picked point should be projected to picking ray on zooming at point.)#"  , py::arg("theToEnable")
          )
        .def("ToStickToRayOnRotation",
             (bool (AIS_ViewController::*)() const) static_cast<bool (AIS_ViewController::*)() const>(&AIS_ViewController::ToStickToRayOnRotation),
             R"#(Return TRUE if picked point should be projected to picking ray on rotating around point; TRUE by default.)#" 
          )
        .def("SetStickToRayOnRotation",
             (void (AIS_ViewController::*)( bool  ) ) static_cast<void (AIS_ViewController::*)( bool  ) >(&AIS_ViewController::SetStickToRayOnRotation),
             R"#(Set if picked point should be projected to picking ray on rotating around point.)#"  , py::arg("theToEnable")
          )
        .def("ToInvertPitch",
             (bool (AIS_ViewController::*)() const) static_cast<bool (AIS_ViewController::*)() const>(&AIS_ViewController::ToInvertPitch),
             R"#(Return TRUE if pitch direction should be inverted while processing Aspect_VKey_NavLookUp/Aspect_VKey_NavLookDown; FALSE by default.)#" 
          )
        .def("SetInvertPitch",
             (void (AIS_ViewController::*)( bool  ) ) static_cast<void (AIS_ViewController::*)( bool  ) >(&AIS_ViewController::SetInvertPitch),
             R"#(Set flag inverting pitch direction.)#"  , py::arg("theToInvert")
          )
        .def("WalkSpeedAbsolute",
             (float (AIS_ViewController::*)() const) static_cast<float (AIS_ViewController::*)() const>(&AIS_ViewController::WalkSpeedAbsolute),
             R"#(Return normal walking speed, in m/s; 1.5 by default.)#" 
          )
        .def("SetWalkSpeedAbsolute",
             (void (AIS_ViewController::*)( float  ) ) static_cast<void (AIS_ViewController::*)( float  ) >(&AIS_ViewController::SetWalkSpeedAbsolute),
             R"#(Set normal walking speed, in m/s; 1.5 by default.)#"  , py::arg("theSpeed")
          )
        .def("WalkSpeedRelative",
             (float (AIS_ViewController::*)() const) static_cast<float (AIS_ViewController::*)() const>(&AIS_ViewController::WalkSpeedRelative),
             R"#(Return walking speed relative to scene bounding box; 0.1 by default.)#" 
          )
        .def("SetWalkSpeedRelative",
             (void (AIS_ViewController::*)( float  ) ) static_cast<void (AIS_ViewController::*)( float  ) >(&AIS_ViewController::SetWalkSpeedRelative),
             R"#(Set walking speed relative to scene bounding box.)#"  , py::arg("theFactor")
          )
        .def("ThrustSpeed",
             (float (AIS_ViewController::*)() const) static_cast<float (AIS_ViewController::*)() const>(&AIS_ViewController::ThrustSpeed),
             R"#(Return active thrust value; 0.0f by default.)#" 
          )
        .def("SetThrustSpeed",
             (void (AIS_ViewController::*)( float  ) ) static_cast<void (AIS_ViewController::*)( float  ) >(&AIS_ViewController::SetThrustSpeed),
             R"#(Set active thrust value.)#"  , py::arg("theSpeed")
          )
        .def("HasPreviousMoveTo",
             (bool (AIS_ViewController::*)() const) static_cast<bool (AIS_ViewController::*)() const>(&AIS_ViewController::HasPreviousMoveTo),
             R"#(Return TRUE if previous position of MoveTo has been defined.)#" 
          )
        .def("ResetPreviousMoveTo",
             (void (AIS_ViewController::*)() ) static_cast<void (AIS_ViewController::*)() >(&AIS_ViewController::ResetPreviousMoveTo),
             R"#(Reset previous position of MoveTo.)#" 
          )
        .def("ToDisplayXRAuxDevices",
             (bool (AIS_ViewController::*)() const) static_cast<bool (AIS_ViewController::*)() const>(&AIS_ViewController::ToDisplayXRAuxDevices),
             R"#(Return TRUE to display auxiliary tracked XR devices (like tracking stations).)#" 
          )
        .def("SetDisplayXRAuxDevices",
             (void (AIS_ViewController::*)( bool  ) ) static_cast<void (AIS_ViewController::*)( bool  ) >(&AIS_ViewController::SetDisplayXRAuxDevices),
             R"#(Set if auxiliary tracked XR devices should be displayed.)#"  , py::arg("theToDisplay")
          )
        .def("ToDisplayXRHands",
             (bool (AIS_ViewController::*)() const) static_cast<bool (AIS_ViewController::*)() const>(&AIS_ViewController::ToDisplayXRHands),
             R"#(Return TRUE to display XR hand controllers.)#" 
          )
        .def("SetDisplayXRHands",
             (void (AIS_ViewController::*)( bool  ) ) static_cast<void (AIS_ViewController::*)( bool  ) >(&AIS_ViewController::SetDisplayXRHands),
             R"#(Set if tracked XR hand controllers should be displayed.)#"  , py::arg("theToDisplay")
          )
        .def("KeyDown",
             (void (AIS_ViewController::*)( Aspect_VKey ,  double ,  double  ) ) static_cast<void (AIS_ViewController::*)( Aspect_VKey ,  double ,  double  ) >(&AIS_ViewController::KeyDown),
             R"#(Press key. Default implementation updates internal cache.)#"  , py::arg("theKey"),  py::arg("theTime"),  py::arg("thePressure")=static_cast<double>(1.0)
          )
        .def("KeyUp",
             (void (AIS_ViewController::*)( Aspect_VKey ,  double  ) ) static_cast<void (AIS_ViewController::*)( Aspect_VKey ,  double  ) >(&AIS_ViewController::KeyUp),
             R"#(Release key. Default implementation updates internal cache.)#"  , py::arg("theKey"),  py::arg("theTime")
          )
        .def("KeyFromAxis",
             (void (AIS_ViewController::*)( Aspect_VKey ,  Aspect_VKey ,  double ,  double  ) ) static_cast<void (AIS_ViewController::*)( Aspect_VKey ,  Aspect_VKey ,  double ,  double  ) >(&AIS_ViewController::KeyFromAxis),
             R"#(Simulate key up/down events from axis value. Default implementation updates internal cache.)#"  , py::arg("theNegative"),  py::arg("thePositive"),  py::arg("theTime"),  py::arg("thePressure")
          )
        .def("FetchNavigationKeys",
             (AIS_WalkDelta (AIS_ViewController::*)( double ,  double  ) ) static_cast<AIS_WalkDelta (AIS_ViewController::*)( double ,  double  ) >(&AIS_ViewController::FetchNavigationKeys),
             R"#(Fetch active navigation actions.)#"  , py::arg("theCrouchRatio"),  py::arg("theRunRatio")
          )
        .def("MouseDoubleClickInterval",
             (double (AIS_ViewController::*)() const) static_cast<double (AIS_ViewController::*)() const>(&AIS_ViewController::MouseDoubleClickInterval),
             R"#(Return double click interval in seconds; 0.4 by default.)#" 
          )
        .def("SetMouseDoubleClickInterval",
             (void (AIS_ViewController::*)( double  ) ) static_cast<void (AIS_ViewController::*)( double  ) >(&AIS_ViewController::SetMouseDoubleClickInterval),
             R"#(Set double click interval in seconds.)#"  , py::arg("theSeconds")
          )
        .def("SelectInViewer",
             (void (AIS_ViewController::*)(  const NCollection_Vec2<int> & ,   const AIS_SelectionScheme  ) ) static_cast<void (AIS_ViewController::*)(  const NCollection_Vec2<int> & ,   const AIS_SelectionScheme  ) >(&AIS_ViewController::SelectInViewer),
             R"#(Perform selection in 3D viewer. This method is expected to be called from UI thread.)#"  , py::arg("thePnt"),  py::arg("theScheme")=static_cast< const AIS_SelectionScheme>(AIS_SelectionScheme_Replace)
          )
        .def("SelectInViewer",
             (void (AIS_ViewController::*)(  const NCollection_Sequence<NCollection_Vec2<int>> & ,   const AIS_SelectionScheme  ) ) static_cast<void (AIS_ViewController::*)(  const NCollection_Sequence<NCollection_Vec2<int>> & ,   const AIS_SelectionScheme  ) >(&AIS_ViewController::SelectInViewer),
             R"#(Perform selection in 3D viewer. This method is expected to be called from UI thread.)#"  , py::arg("thePnts"),  py::arg("theScheme")=static_cast< const AIS_SelectionScheme>(AIS_SelectionScheme_Replace)
          )
        .def("UpdateRubberBand",
             (void (AIS_ViewController::*)(  const NCollection_Vec2<int> & ,   const NCollection_Vec2<int> &  ) ) static_cast<void (AIS_ViewController::*)(  const NCollection_Vec2<int> & ,   const NCollection_Vec2<int> &  ) >(&AIS_ViewController::UpdateRubberBand),
             R"#(Update rectangle selection tool. This method is expected to be called from UI thread.)#"  , py::arg("thePntFrom"),  py::arg("thePntTo")
          )
        .def("UpdatePolySelection",
             (void (AIS_ViewController::*)(  const NCollection_Vec2<int> & ,  bool  ) ) static_cast<void (AIS_ViewController::*)(  const NCollection_Vec2<int> & ,  bool  ) >(&AIS_ViewController::UpdatePolySelection),
             R"#(Update polygonal selection tool. This method is expected to be called from UI thread.)#"  , py::arg("thePnt"),  py::arg("theToAppend")
          )
        .def("UpdateZoom",
             (bool (AIS_ViewController::*)(  const Aspect_ScrollDelta &  ) ) static_cast<bool (AIS_ViewController::*)(  const Aspect_ScrollDelta &  ) >(&AIS_ViewController::UpdateZoom),
             R"#(Update zoom event (e.g. from mouse scroll). This method is expected to be called from UI thread.)#"  , py::arg("theDelta")
          )
        .def("UpdateZRotation",
             (bool (AIS_ViewController::*)( double  ) ) static_cast<bool (AIS_ViewController::*)( double  ) >(&AIS_ViewController::UpdateZRotation),
             R"#(Update Z rotation event.)#"  , py::arg("theAngle")
          )
        .def("UpdateMouseScroll",
             (bool (AIS_ViewController::*)(  const Aspect_ScrollDelta &  ) ) static_cast<bool (AIS_ViewController::*)(  const Aspect_ScrollDelta &  ) >(&AIS_ViewController::UpdateMouseScroll),
             R"#(Update mouse scroll event; redirects to UpdateZoom by default. This method is expected to be called from UI thread.)#"  , py::arg("theDelta")
          )
        .def("UpdateMouseButtons",
             (bool (AIS_ViewController::*)(  const NCollection_Vec2<int> & ,  Aspect_VKeyMouse ,  Aspect_VKeyFlags ,  bool  ) ) static_cast<bool (AIS_ViewController::*)(  const NCollection_Vec2<int> & ,  Aspect_VKeyMouse ,  Aspect_VKeyFlags ,  bool  ) >(&AIS_ViewController::UpdateMouseButtons),
             R"#(Handle mouse button press/release event. This method is expected to be called from UI thread.)#"  , py::arg("thePoint"),  py::arg("theButtons"),  py::arg("theModifiers"),  py::arg("theIsEmulated")
          )
        .def("UpdateMousePosition",
             (bool (AIS_ViewController::*)(  const NCollection_Vec2<int> & ,  Aspect_VKeyMouse ,  Aspect_VKeyFlags ,  bool  ) ) static_cast<bool (AIS_ViewController::*)(  const NCollection_Vec2<int> & ,  Aspect_VKeyMouse ,  Aspect_VKeyFlags ,  bool  ) >(&AIS_ViewController::UpdateMousePosition),
             R"#(Handle mouse cursor movement event. This method is expected to be called from UI thread.)#"  , py::arg("thePoint"),  py::arg("theButtons"),  py::arg("theModifiers"),  py::arg("theIsEmulated")
          )
        .def("UpdateMouseClick",
             (bool (AIS_ViewController::*)(  const NCollection_Vec2<int> & ,  Aspect_VKeyMouse ,  Aspect_VKeyFlags ,  bool  ) ) static_cast<bool (AIS_ViewController::*)(  const NCollection_Vec2<int> & ,  Aspect_VKeyMouse ,  Aspect_VKeyFlags ,  bool  ) >(&AIS_ViewController::UpdateMouseClick),
             R"#(Handle mouse button click event (emulated by UpdateMouseButtons() while releasing single button). Note that as this method is called by UpdateMouseButtons(), it should be executed from UI thread. Default implementation redirects to SelectInViewer(). This method is expected to be called from UI thread.)#"  , py::arg("thePoint"),  py::arg("theButton"),  py::arg("theModifiers"),  py::arg("theIsDoubleClick")
          )
        .def("TouchToleranceScale",
             (float (AIS_ViewController::*)() const) static_cast<float (AIS_ViewController::*)() const>(&AIS_ViewController::TouchToleranceScale),
             R"#(Return scale factor for adjusting tolerances for starting multi-touch gestures; 1.0 by default This scale factor is expected to be computed from touch screen resolution.)#" 
          )
        .def("SetTouchToleranceScale",
             (void (AIS_ViewController::*)( float  ) ) static_cast<void (AIS_ViewController::*)( float  ) >(&AIS_ViewController::SetTouchToleranceScale),
             R"#(Set scale factor for adjusting tolerances for starting multi-touch gestures.)#"  , py::arg("theTolerance")
          )
        .def("AddTouchPoint",
             (void (AIS_ViewController::*)( size_t ,   const NCollection_Vec2<double> & ,  bool  ) ) static_cast<void (AIS_ViewController::*)( size_t ,   const NCollection_Vec2<double> & ,  bool  ) >(&AIS_ViewController::AddTouchPoint),
             R"#(Add touch point with the given ID. This method is expected to be called from UI thread.)#"  , py::arg("theId"),  py::arg("thePnt"),  py::arg("theClearBefore")=static_cast<bool>(false)
          )
        .def("RemoveTouchPoint",
             (bool (AIS_ViewController::*)( size_t ,  bool  ) ) static_cast<bool (AIS_ViewController::*)( size_t ,  bool  ) >(&AIS_ViewController::RemoveTouchPoint),
             R"#(Remove touch point with the given ID. This method is expected to be called from UI thread.)#"  , py::arg("theId"),  py::arg("theClearSelectPnts")=static_cast<bool>(false)
          )
        .def("UpdateTouchPoint",
             (void (AIS_ViewController::*)( size_t ,   const NCollection_Vec2<double> &  ) ) static_cast<void (AIS_ViewController::*)( size_t ,   const NCollection_Vec2<double> &  ) >(&AIS_ViewController::UpdateTouchPoint),
             R"#(Update touch point with the given ID. If point with specified ID was not registered before, it will be added. This method is expected to be called from UI thread.)#"  , py::arg("theId"),  py::arg("thePnt")
          )
        .def("Update3dMouse",
             (bool (AIS_ViewController::*)(  const WNT_HIDSpaceMouse &  ) ) static_cast<bool (AIS_ViewController::*)(  const WNT_HIDSpaceMouse &  ) >(&AIS_ViewController::Update3dMouse),
             R"#(Process 3d mouse input event (redirects to translation, rotation and keys).)#"  , py::arg("theEvent")
          )
        .def("ProcessExpose",
             (void (AIS_ViewController::*)() ) static_cast<void (AIS_ViewController::*)() >(&AIS_ViewController::ProcessExpose),
             R"#(Handle expose event (window content has been invalidation and should be redrawn). Default implementation does nothing.)#" 
          )
        .def("ProcessConfigure",
             (void (AIS_ViewController::*)( bool  ) ) static_cast<void (AIS_ViewController::*)( bool  ) >(&AIS_ViewController::ProcessConfigure),
             R"#(Handle window resize event. Default implementation does nothing.)#"  , py::arg("theIsResized")
          )
        .def("ProcessInput",
             (void (AIS_ViewController::*)() ) static_cast<void (AIS_ViewController::*)() >(&AIS_ViewController::ProcessInput),
             R"#(Handle window input event immediately. Default implementation does nothing - input events are accumulated in internal buffer until explicit FlushViewEvents() call.)#" 
          )
        .def("ProcessFocus",
             (void (AIS_ViewController::*)( bool  ) ) static_cast<void (AIS_ViewController::*)( bool  ) >(&AIS_ViewController::ProcessFocus),
             R"#(Handle focus event. Default implementation resets cached input state (pressed keys).)#"  , py::arg("theIsActivated")
          )
        .def("ProcessClose",
             (void (AIS_ViewController::*)() ) static_cast<void (AIS_ViewController::*)() >(&AIS_ViewController::ProcessClose),
             R"#(Handle window close event. Default implementation does nothing.)#" 
          )
        .def("ResetViewInput",
             (void (AIS_ViewController::*)() ) static_cast<void (AIS_ViewController::*)() >(&AIS_ViewController::ResetViewInput),
             R"#(Reset input state (pressed keys, mouse buttons, etc.) e.g. on window focus loss. This method is expected to be called from UI thread.)#" 
          )
        .def("UpdateViewOrientation",
             (void (AIS_ViewController::*)( V3d_TypeOfOrientation ,  bool  ) ) static_cast<void (AIS_ViewController::*)( V3d_TypeOfOrientation ,  bool  ) >(&AIS_ViewController::UpdateViewOrientation),
             R"#(Reset view orientation. This method is expected to be called from UI thread.)#"  , py::arg("theOrientation"),  py::arg("theToFitAll")
          )
        .def("FlushViewEvents",
             (void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> & ,  bool  ) ) static_cast<void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> & ,  bool  ) >(&AIS_ViewController::FlushViewEvents),
             R"#(Update buffer for rendering thread. This method is expected to be called within synchronization barrier between GUI and Rendering threads (e.g. GUI thread should be locked beforehand to avoid data races).)#"  , py::arg("theCtx"),  py::arg("theView"),  py::arg("theToHandle")=static_cast<bool>(false)
          )
        .def("HandleViewEvents",
             (void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> &  ) ) static_cast<void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> &  ) >(&AIS_ViewController::HandleViewEvents),
             R"#(Process events within rendering thread.)#"  , py::arg("theCtx"),  py::arg("theView")
          )
        .def("OnSelectionChanged",
             (void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> &  ) ) static_cast<void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> &  ) >(&AIS_ViewController::OnSelectionChanged),
             R"#(Callback called by handleMoveTo() on Selection in 3D Viewer. This method is expected to be called from rendering thread.)#"  , py::arg("theCtx"),  py::arg("theView")
          )
        .def("OnObjectDragged",
             (void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> & ,  AIS_DragAction  ) ) static_cast<void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> & ,  AIS_DragAction  ) >(&AIS_ViewController::OnObjectDragged),
             R"#(Callback called by handleMoveTo() on dragging object in 3D Viewer. This method is expected to be called from rendering thread.)#"  , py::arg("theCtx"),  py::arg("theView"),  py::arg("theAction")
          )
        .def("OnSubviewChanged",
             (void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> & ,   const handle<V3d_View> &  ) ) static_cast<void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> & ,   const handle<V3d_View> &  ) >(&AIS_ViewController::OnSubviewChanged),
             R"#(Callback called by HandleViewEvents() on Selection of another (sub)view. This method is expected to be called from rendering thread.)#"  , py::arg("theCtx"),  py::arg("theOldView"),  py::arg("theNewView")
          )
        .def("PickPoint",
             (bool (AIS_ViewController::*)( gp_Pnt & ,   const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> & ,   const NCollection_Vec2<int> & ,  bool  ) ) static_cast<bool (AIS_ViewController::*)( gp_Pnt & ,   const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> & ,   const NCollection_Vec2<int> & ,  bool  ) >(&AIS_ViewController::PickPoint),
             R"#(Pick closest point under mouse cursor. This method is expected to be called from rendering thread.)#"  , py::arg("thePnt"),  py::arg("theCtx"),  py::arg("theView"),  py::arg("theCursor"),  py::arg("theToStickToPickRay")
          )
        .def("PickAxis",
             (bool (AIS_ViewController::*)( gp_Pnt & ,   const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> & ,   const gp_Ax1 &  ) ) static_cast<bool (AIS_ViewController::*)( gp_Pnt & ,   const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> & ,   const gp_Ax1 &  ) >(&AIS_ViewController::PickAxis),
             R"#(Pick closest point by axis. This method is expected to be called from rendering thread.)#"  , py::arg("theTopPnt"),  py::arg("theCtx"),  py::arg("theView"),  py::arg("theAxis")
          )
        .def("GravityPoint",
             (gp_Pnt (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> &  ) ) static_cast<gp_Pnt (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> &  ) >(&AIS_ViewController::GravityPoint),
             R"#(Compute rotation gravity center point depending on rotation mode. This method is expected to be called from rendering thread.)#"  , py::arg("theCtx"),  py::arg("theView")
          )
        .def("FitAllAuto",
             (void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> &  ) ) static_cast<void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> &  ) >(&AIS_ViewController::FitAllAuto),
             R"#(Modify view camera to fit all objects. Default implementation fits either all visible and all selected objects (swapped on each call).)#"  , py::arg("theCtx"),  py::arg("theView")
          )
        .def("handleViewOrientationKeys",
             (void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> &  ) ) static_cast<void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> &  ) >(&AIS_ViewController::handleViewOrientationKeys),
             R"#(Handle hot-keys defining new camera orientation (Aspect_VKey_ViewTop and similar keys). Default implementation starts an animated transaction from the current to the target camera orientation, when specific action key was pressed. This method is expected to be called from rendering thread.)#"  , py::arg("theCtx"),  py::arg("theView")
          )
        .def("handleNavigationKeys",
             (AIS_WalkDelta (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> &  ) ) static_cast<AIS_WalkDelta (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> &  ) >(&AIS_ViewController::handleNavigationKeys),
             R"#(Perform navigation (Aspect_VKey_NavForward and similar keys). This method is expected to be called from rendering thread.)#"  , py::arg("theCtx"),  py::arg("theView")
          )
        .def("handleCameraActions",
             (void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> & ,   const AIS_WalkDelta &  ) ) static_cast<void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> & ,   const AIS_WalkDelta &  ) >(&AIS_ViewController::handleCameraActions),
             R"#(Perform immediate camera actions (rotate/zoom/pan) on gesture progress. This method is expected to be called from rendering thread.)#"  , py::arg("theCtx"),  py::arg("theView"),  py::arg("theWalk")
          )
        .def("handleMoveTo",
             (void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> &  ) ) static_cast<void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> &  ) >(&AIS_ViewController::handleMoveTo),
             R"#(Perform moveto/selection/dragging. This method is expected to be called from rendering thread.)#"  , py::arg("theCtx"),  py::arg("theView")
          )
        .def("toAskNextFrame",
             (bool (AIS_ViewController::*)() const) static_cast<bool (AIS_ViewController::*)() const>(&AIS_ViewController::toAskNextFrame),
             R"#(Return TRUE if another frame should be drawn right after this one.)#" 
          )
        .def("setAskNextFrame",
             (void (AIS_ViewController::*)( bool  ) ) static_cast<void (AIS_ViewController::*)( bool  ) >(&AIS_ViewController::setAskNextFrame),
             R"#(Set if another frame should be drawn right after this one.)#"  , py::arg("theToDraw")=static_cast<bool>(true)
          )
        .def("hasPanningAnchorPoint",
             (bool (AIS_ViewController::*)() const) static_cast<bool (AIS_ViewController::*)() const>(&AIS_ViewController::hasPanningAnchorPoint),
             R"#(Return if panning anchor point has been defined.)#" 
          )
        .def("setPanningAnchorPoint",
             (void (AIS_ViewController::*)(  const gp_Pnt &  ) ) static_cast<void (AIS_ViewController::*)(  const gp_Pnt &  ) >(&AIS_ViewController::setPanningAnchorPoint),
             R"#(Set active panning anchor point.)#"  , py::arg("thePnt")
          )
        .def("handlePanning",
             (void (AIS_ViewController::*)(  const handle<V3d_View> &  ) ) static_cast<void (AIS_ViewController::*)(  const handle<V3d_View> &  ) >(&AIS_ViewController::handlePanning),
             R"#(Handle panning event myGL.Panning.)#"  , py::arg("theView")
          )
        .def("handleZRotate",
             (void (AIS_ViewController::*)(  const handle<V3d_View> &  ) ) static_cast<void (AIS_ViewController::*)(  const handle<V3d_View> &  ) >(&AIS_ViewController::handleZRotate),
             R"#(Handle Z rotation event myGL.ZRotate.)#"  , py::arg("theView")
          )
        .def("MinZoomDistance",
             (double (AIS_ViewController::*)() const) static_cast<double (AIS_ViewController::*)() const>(&AIS_ViewController::MinZoomDistance),
             R"#(Return minimal camera distance for zoom operation.)#" 
          )
        .def("SetMinZoomDistance",
             (void (AIS_ViewController::*)( double  ) ) static_cast<void (AIS_ViewController::*)( double  ) >(&AIS_ViewController::SetMinZoomDistance),
             R"#(Set minimal camera distance for zoom operation.)#"  , py::arg("theDist")
          )
        .def("handleZoom",
             (void (AIS_ViewController::*)(  const handle<V3d_View> & ,   const Aspect_ScrollDelta & ,   const gp_Pnt *  ) ) static_cast<void (AIS_ViewController::*)(  const handle<V3d_View> & ,   const Aspect_ScrollDelta & ,   const gp_Pnt *  ) >(&AIS_ViewController::handleZoom),
             R"#(Handle zoom event myGL.ZoomActions. This method is expected to be called from rendering thread.)#"  , py::arg("theView"),  py::arg("theParams"),  py::arg("thePnt")
          )
        .def("handleZFocusScroll",
             (void (AIS_ViewController::*)(  const handle<V3d_View> & ,   const Aspect_ScrollDelta &  ) ) static_cast<void (AIS_ViewController::*)(  const handle<V3d_View> & ,   const Aspect_ScrollDelta &  ) >(&AIS_ViewController::handleZFocusScroll),
             R"#(Handle ZScroll event myGL.ZoomActions. This method is expected to be called from rendering thread.)#"  , py::arg("theView"),  py::arg("theParams")
          )
        .def("handleOrbitRotation",
             (void (AIS_ViewController::*)(  const handle<V3d_View> & ,   const gp_Pnt & ,  bool  ) ) static_cast<void (AIS_ViewController::*)(  const handle<V3d_View> & ,   const gp_Pnt & ,  bool  ) >(&AIS_ViewController::handleOrbitRotation),
             R"#(Handle orbital rotation events myGL.OrbitRotation.)#"  , py::arg("theView"),  py::arg("thePnt"),  py::arg("theToLockZUp")
          )
        .def("handleViewRotation",
             (void (AIS_ViewController::*)(  const handle<V3d_View> & ,  double ,  double ,  double ,  bool  ) ) static_cast<void (AIS_ViewController::*)(  const handle<V3d_View> & ,  double ,  double ,  double ,  bool  ) >(&AIS_ViewController::handleViewRotation),
             R"#(Handle view direction rotation events myGL.ViewRotation. This method is expected to be called from rendering thread.)#"  , py::arg("theView"),  py::arg("theYawExtra"),  py::arg("thePitchExtra"),  py::arg("theRoll"),  py::arg("theToRestartOnIncrement")
          )
        .def("handleViewRedraw",
             (void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> &  ) ) static_cast<void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> &  ) >(&AIS_ViewController::handleViewRedraw),
             R"#(Handle view redraw. This method is expected to be called from rendering thread.)#"  , py::arg("theCtx"),  py::arg("theView")
          )
        .def("handleXRInput",
             (void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> & ,   const AIS_WalkDelta &  ) ) static_cast<void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> & ,   const AIS_WalkDelta &  ) >(&AIS_ViewController::handleXRInput),
             R"#(Perform XR input. This method is expected to be called from rendering thread.)#"  , py::arg("theCtx"),  py::arg("theView"),  py::arg("theWalk")
          )
        .def("handleXRTurnPad",
             (void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> &  ) ) static_cast<void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> &  ) >(&AIS_ViewController::handleXRTurnPad),
             R"#(Handle trackpad view turn action.)#"  , py::arg("theCtx"),  py::arg("theView")
          )
        .def("handleXRTeleport",
             (void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> &  ) ) static_cast<void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> &  ) >(&AIS_ViewController::handleXRTeleport),
             R"#(Handle trackpad teleportation action.)#"  , py::arg("theCtx"),  py::arg("theView")
          )
        .def("handleXRPicking",
             (void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> &  ) ) static_cast<void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> &  ) >(&AIS_ViewController::handleXRPicking),
             R"#(Handle picking on trigger click.)#"  , py::arg("theCtx"),  py::arg("theView")
          )
        .def("handleXRHighlight",
             (void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> &  ) ) static_cast<void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> &  ) >(&AIS_ViewController::handleXRHighlight),
             R"#(Perform dynamic highlighting for active hand.)#"  , py::arg("theCtx"),  py::arg("theView")
          )
        .def("handleXRPresentations",
             (void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> &  ) ) static_cast<void (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> &  ) >(&AIS_ViewController::handleXRPresentations),
             R"#(Display auxiliary XR presentations.)#"  , py::arg("theCtx"),  py::arg("theView")
          )
        .def("handleXRMoveTo",
             (int (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> & ,   const gp_Trsf & ,   const bool  ) ) static_cast<int (AIS_ViewController::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> & ,   const gp_Trsf & ,   const bool  ) >(&AIS_ViewController::handleXRMoveTo),
             R"#(Perform picking with/without dynamic highlighting for XR pose.)#"  , py::arg("theCtx"),  py::arg("theView"),  py::arg("thePose"),  py::arg("theToHighlight")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("ViewAnimation",
             ( const handle<AIS_AnimationCamera> & (AIS_ViewController::*)() const) static_cast< const handle<AIS_AnimationCamera> & (AIS_ViewController::*)() const>(&AIS_ViewController::ViewAnimation),
             R"#(Return view animation; empty (but not NULL) animation by default.)#"
             
         )
       .def("ObjectsAnimation",
             ( const handle<AIS_Animation> & (AIS_ViewController::*)() const) static_cast< const handle<AIS_Animation> & (AIS_ViewController::*)() const>(&AIS_ViewController::ObjectsAnimation),
             R"#(Return objects animation; empty (but not NULL) animation by default.)#"
             
         )
       .def("PreviousMoveTo",
             ( const NCollection_Vec2<int> & (AIS_ViewController::*)() const) static_cast< const NCollection_Vec2<int> & (AIS_ViewController::*)() const>(&AIS_ViewController::PreviousMoveTo),
             R"#(Return previous position of MoveTo event in 3D viewer.)#"
             
         )
       .def("MouseGestureMap",
             ( const NCollection_DataMap<unsigned int, AIS_MouseGesture> & (AIS_ViewController::*)() const) static_cast< const NCollection_DataMap<unsigned int, AIS_MouseGesture> & (AIS_ViewController::*)() const>(&AIS_ViewController::MouseGestureMap),
             R"#(Return map defining mouse gestures.)#"
             
         )
       .def("ChangeMouseGestureMap",
             (NCollection_DataMap<unsigned int, AIS_MouseGesture> & (AIS_ViewController::*)() ) static_cast<NCollection_DataMap<unsigned int, AIS_MouseGesture> & (AIS_ViewController::*)() >(&AIS_ViewController::ChangeMouseGestureMap),
             R"#(Return map defining mouse gestures.)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("MouseSelectionSchemes",
             ( const NCollection_DataMap<unsigned int, AIS_SelectionScheme> & (AIS_ViewController::*)() const) static_cast< const NCollection_DataMap<unsigned int, AIS_SelectionScheme> & (AIS_ViewController::*)() const>(&AIS_ViewController::MouseSelectionSchemes),
             R"#(Return map defining mouse selection schemes.)#"
             
         )
       .def("ChangeMouseSelectionSchemes",
             (NCollection_DataMap<unsigned int, AIS_SelectionScheme> & (AIS_ViewController::*)() ) static_cast<NCollection_DataMap<unsigned int, AIS_SelectionScheme> & (AIS_ViewController::*)() >(&AIS_ViewController::ChangeMouseSelectionSchemes),
             R"#(Return map defining mouse gestures.)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("panningAnchorPoint",
             ( const gp_Pnt & (AIS_ViewController::*)() const) static_cast< const gp_Pnt & (AIS_ViewController::*)() const>(&AIS_ViewController::panningAnchorPoint),
             R"#(Return active panning anchor point.)#"
             
         )
;

    // Class AIS_ViewCubeOwner from ./opencascade/AIS_ViewCube.hxx
    klass = m.attr("AIS_ViewCubeOwner");


    // nested enums

    static_cast<py::class_<AIS_ViewCubeOwner ,opencascade::handle<AIS_ViewCubeOwner>  , SelectMgr_EntityOwner >>(klass)
    // constructors
        .def(py::init<  const handle<AIS_ViewCube> &,V3d_TypeOfOrientation,int >()  , py::arg("theObject"),  py::arg("theOrient"),  py::arg("thePriority")=static_cast<int>(5) )
    // custom constructors
    // methods
        .def("IsForcedHilight",
             (bool (AIS_ViewCubeOwner::*)() const) static_cast<bool (AIS_ViewCubeOwner::*)() const>(&AIS_ViewCubeOwner::IsForcedHilight),
             R"#(Returns TRUE. This owner will always call method Hilight for its Selectable Object when the owner is detected.)#" 
          )
        .def("MainOrientation",
             (V3d_TypeOfOrientation (AIS_ViewCubeOwner::*)() const) static_cast<V3d_TypeOfOrientation (AIS_ViewCubeOwner::*)() const>(&AIS_ViewCubeOwner::MainOrientation),
             R"#(Return new orientation to set.)#" 
          )
        .def("HandleMouseClick",
             (bool (AIS_ViewCubeOwner::*)(  const NCollection_Vec2<int> & ,  Aspect_VKeyMouse ,  Aspect_VKeyFlags ,  bool  ) ) static_cast<bool (AIS_ViewCubeOwner::*)(  const NCollection_Vec2<int> & ,  Aspect_VKeyMouse ,  Aspect_VKeyFlags ,  bool  ) >(&AIS_ViewCubeOwner::HandleMouseClick),
             R"#(Handle mouse button click event.)#"  , py::arg("thePoint"),  py::arg("theButton"),  py::arg("theModifiers"),  py::arg("theIsDoubleClick")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_ViewCubeOwner::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_ViewCubeOwner::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_ViewCubeOwner::*)() const) static_cast< const handle<Standard_Type> & (AIS_ViewCubeOwner::*)() const>(&AIS_ViewCubeOwner::DynamicType),
             R"#()#"
             
         )
;

    // Class AIS_ViewCubeSensitive from ./opencascade/AIS_ViewCube.hxx
    klass = m.attr("AIS_ViewCubeSensitive");


    // nested enums

    static_cast<py::class_<AIS_ViewCubeSensitive ,opencascade::handle<AIS_ViewCubeSensitive>  >>(klass)
    // constructors
        .def(py::init<  const handle<SelectMgr_EntityOwner> &, const handle<Graphic3d_ArrayOfTriangles> & >()  , py::arg("theOwner"),  py::arg("theTris") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_ViewCubeSensitive::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_ViewCubeSensitive::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_ViewCubeSensitive::*)() const) static_cast< const handle<Standard_Type> & (AIS_ViewCubeSensitive::*)() const>(&AIS_ViewCubeSensitive::DynamicType),
             R"#()#"
             
         )
;

    // Class AIS_ViewInputBuffer from ./opencascade/AIS_ViewInputBuffer.hxx
    klass = m.attr("AIS_ViewInputBuffer");


    // nested enums

    static_cast<py::class_<AIS_ViewInputBuffer , shared_ptr<AIS_ViewInputBuffer>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Reset",
             (void (AIS_ViewInputBuffer::*)() ) static_cast<void (AIS_ViewInputBuffer::*)() >(&AIS_ViewInputBuffer::Reset),
             R"#(Reset events buffer.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
        .def_readwrite("IsNewGesture", &AIS_ViewInputBuffer::IsNewGesture)
    // methods returning by ref wrapped as properties
;

    // Class AIS_WalkDelta from ./opencascade/AIS_WalkDelta.hxx
    klass = m.attr("AIS_WalkDelta");


    // nested enums

    static_cast<py::class_<AIS_WalkDelta , shared_ptr<AIS_WalkDelta>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("IsJumping",
             (bool (AIS_WalkDelta::*)() const) static_cast<bool (AIS_WalkDelta::*)() const>(&AIS_WalkDelta::IsJumping),
             R"#(Return jumping state.)#" 
          )
        .def("SetJumping",
             (void (AIS_WalkDelta::*)( bool  ) ) static_cast<void (AIS_WalkDelta::*)( bool  ) >(&AIS_WalkDelta::SetJumping),
             R"#(Set jumping state.)#"  , py::arg("theIsJumping")
          )
        .def("IsCrouching",
             (bool (AIS_WalkDelta::*)() const) static_cast<bool (AIS_WalkDelta::*)() const>(&AIS_WalkDelta::IsCrouching),
             R"#(Return crouching state.)#" 
          )
        .def("SetCrouching",
             (void (AIS_WalkDelta::*)( bool  ) ) static_cast<void (AIS_WalkDelta::*)( bool  ) >(&AIS_WalkDelta::SetCrouching),
             R"#(Set crouching state.)#"  , py::arg("theIsCrouching")
          )
        .def("IsRunning",
             (bool (AIS_WalkDelta::*)() const) static_cast<bool (AIS_WalkDelta::*)() const>(&AIS_WalkDelta::IsRunning),
             R"#(Return running state.)#" 
          )
        .def("SetRunning",
             (void (AIS_WalkDelta::*)( bool  ) ) static_cast<void (AIS_WalkDelta::*)( bool  ) >(&AIS_WalkDelta::SetRunning),
             R"#(Set running state.)#"  , py::arg("theIsRunning")
          )
        .def("IsDefined",
             (bool (AIS_WalkDelta::*)() const) static_cast<bool (AIS_WalkDelta::*)() const>(&AIS_WalkDelta::IsDefined),
             R"#(Return TRUE if navigation keys are pressed even if delta from the previous frame is empty.)#" 
          )
        .def("SetDefined",
             (void (AIS_WalkDelta::*)( bool  ) ) static_cast<void (AIS_WalkDelta::*)( bool  ) >(&AIS_WalkDelta::SetDefined),
             R"#(Set if any navigation key is pressed.)#"  , py::arg("theIsDefined")
          )
        .def("IsEmpty",
             (bool (AIS_WalkDelta::*)() const) static_cast<bool (AIS_WalkDelta::*)() const>(&AIS_WalkDelta::IsEmpty),
             R"#(Return TRUE when both Rotation and Translation deltas are empty.)#" 
          )
        .def("ToMove",
             (bool (AIS_WalkDelta::*)() const) static_cast<bool (AIS_WalkDelta::*)() const>(&AIS_WalkDelta::ToMove),
             R"#(Return TRUE if translation delta is defined.)#" 
          )
        .def("ToRotate",
             (bool (AIS_WalkDelta::*)() const) static_cast<bool (AIS_WalkDelta::*)() const>(&AIS_WalkDelta::ToRotate),
             R"#(Return TRUE if rotation delta is defined.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class AIS_WalkPart from ./opencascade/AIS_WalkDelta.hxx
    klass = m.attr("AIS_WalkPart");


    // nested enums

    static_cast<py::class_<AIS_WalkPart , shared_ptr<AIS_WalkPart>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("IsEmpty",
             (bool (AIS_WalkPart::*)() const) static_cast<bool (AIS_WalkPart::*)() const>(&AIS_WalkPart::IsEmpty),
             R"#(Return TRUE if delta is empty.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
        .def_readwrite("Value", &AIS_WalkPart::Value)
        .def_readwrite("Pressure", &AIS_WalkPart::Pressure)
        .def_readwrite("Duration", &AIS_WalkPart::Duration)
    // methods returning by ref wrapped as properties
;

    // Class AIS_AnimationCamera from ./opencascade/AIS_AnimationCamera.hxx
    klass = m.attr("AIS_AnimationCamera");


    // nested enums

    static_cast<py::class_<AIS_AnimationCamera ,opencascade::handle<AIS_AnimationCamera>  , AIS_Animation >>(klass)
    // constructors
        .def(py::init<  const TCollection_AsciiString &, const handle<V3d_View> & >()  , py::arg("theAnimationName"),  py::arg("theView") )
    // custom constructors
    // methods
        .def("SetView",
             (void (AIS_AnimationCamera::*)(  const handle<V3d_View> &  ) ) static_cast<void (AIS_AnimationCamera::*)(  const handle<V3d_View> &  ) >(&AIS_AnimationCamera::SetView),
             R"#(Set target view.)#"  , py::arg("theView")
          )
        .def("SetCameraStart",
             (void (AIS_AnimationCamera::*)(  const handle<Graphic3d_Camera> &  ) ) static_cast<void (AIS_AnimationCamera::*)(  const handle<Graphic3d_Camera> &  ) >(&AIS_AnimationCamera::SetCameraStart),
             R"#(Define camera start position.)#"  , py::arg("theCameraStart")
          )
        .def("SetCameraEnd",
             (void (AIS_AnimationCamera::*)(  const handle<Graphic3d_Camera> &  ) ) static_cast<void (AIS_AnimationCamera::*)(  const handle<Graphic3d_Camera> &  ) >(&AIS_AnimationCamera::SetCameraEnd),
             R"#(Define camera end position.)#"  , py::arg("theCameraEnd")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_AnimationCamera::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_AnimationCamera::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_AnimationCamera::*)() const) static_cast< const handle<Standard_Type> & (AIS_AnimationCamera::*)() const>(&AIS_AnimationCamera::DynamicType),
             R"#()#"
             
         )
       .def("View",
             ( const handle<V3d_View> & (AIS_AnimationCamera::*)() const) static_cast< const handle<V3d_View> & (AIS_AnimationCamera::*)() const>(&AIS_AnimationCamera::View),
             R"#(Return the target view.)#"
             
         )
       .def("CameraStart",
             ( const handle<Graphic3d_Camera> & (AIS_AnimationCamera::*)() const) static_cast< const handle<Graphic3d_Camera> & (AIS_AnimationCamera::*)() const>(&AIS_AnimationCamera::CameraStart),
             R"#(Return camera start position.)#"
             
         )
       .def("CameraEnd",
             ( const handle<Graphic3d_Camera> & (AIS_AnimationCamera::*)() const) static_cast< const handle<Graphic3d_Camera> & (AIS_AnimationCamera::*)() const>(&AIS_AnimationCamera::CameraEnd),
             R"#(Return camera end position.)#"
             
         )
;

    // Class AIS_Axis from ./opencascade/AIS_Axis.hxx
    klass = m.attr("AIS_Axis");


    // nested enums

    static_cast<py::class_<AIS_Axis ,opencascade::handle<AIS_Axis>  , AIS_InteractiveObject >>(klass)
    // constructors
        .def(py::init<  const gp_Ax1 &, const double >()  , py::arg("theAxis"),  py::arg("theLength")=static_cast< const double>(- 1) )
        .def(py::init<  const handle<Geom_Axis1Placement> & >()  , py::arg("anAxis") )
        .def(py::init<  const handle<Geom_Axis2Placement> &, const AIS_TypeOfAxis >()  , py::arg("aComponent"),  py::arg("anAxisType") )
        .def(py::init<  const handle<Geom_Line> & >()  , py::arg("aComponent") )
    // custom constructors
    // methods
        .def("SetComponent",
             (void (AIS_Axis::*)(  const handle<Geom_Line> &  ) ) static_cast<void (AIS_Axis::*)(  const handle<Geom_Line> &  ) >(&AIS_Axis::SetComponent),
             R"#(Sets the coordinates of the lin aComponent.)#"  , py::arg("aComponent")
          )
        .def("SetAxis2Placement",
             (void (AIS_Axis::*)(  const handle<Geom_Axis2Placement> & ,   const AIS_TypeOfAxis  ) ) static_cast<void (AIS_Axis::*)(  const handle<Geom_Axis2Placement> & ,   const AIS_TypeOfAxis  ) >(&AIS_Axis::SetAxis2Placement),
             R"#(Allows you to provide settings for aComponent:the position and direction of an axis in 3D space. The coordinate system used is right-handed.)#"  , py::arg("aComponent"),  py::arg("anAxisType")
          )
        .def("SetAxis1Placement",
             (void (AIS_Axis::*)(  const handle<Geom_Axis1Placement> &  ) ) static_cast<void (AIS_Axis::*)(  const handle<Geom_Axis1Placement> &  ) >(&AIS_Axis::SetAxis1Placement),
             R"#(Constructs a new line to serve as the axis anAxis in 3D space.)#"  , py::arg("anAxis")
          )
        .def("TypeOfAxis",
             (AIS_TypeOfAxis (AIS_Axis::*)() const) static_cast<AIS_TypeOfAxis (AIS_Axis::*)() const>(&AIS_Axis::TypeOfAxis),
             R"#(Returns the type of axis.)#" 
          )
        .def("SetTypeOfAxis",
             (void (AIS_Axis::*)(  const AIS_TypeOfAxis  ) ) static_cast<void (AIS_Axis::*)(  const AIS_TypeOfAxis  ) >(&AIS_Axis::SetTypeOfAxis),
             R"#(Constructs the entity theTypeAxis to stock information concerning type of axis.)#"  , py::arg("theTypeAxis")
          )
        .def("IsXYZAxis",
             (bool (AIS_Axis::*)() const) static_cast<bool (AIS_Axis::*)() const>(&AIS_Axis::IsXYZAxis),
             R"#(Returns a signature of 2 for axis datums. When you activate mode 2 by a signature, you pick AIS objects of type AIS_Axis.)#" 
          )
        .def("AcceptDisplayMode",
             (bool (AIS_Axis::*)(  const int  ) const) static_cast<bool (AIS_Axis::*)(  const int  ) const>(&AIS_Axis::AcceptDisplayMode),
             R"#(Returns true if the interactive object accepts the display mode aMode.)#"  , py::arg("aMode")
          )
        .def("Signature",
             (int (AIS_Axis::*)() const) static_cast<int (AIS_Axis::*)() const>(&AIS_Axis::Signature),
             R"#()#" 
          )
        .def("Type",
             (AIS_KindOfInteractive (AIS_Axis::*)() const) static_cast<AIS_KindOfInteractive (AIS_Axis::*)() const>(&AIS_Axis::Type),
             R"#()#" 
          )
        .def("SetColor",
             (void (AIS_Axis::*)(  const Quantity_Color &  ) ) static_cast<void (AIS_Axis::*)(  const Quantity_Color &  ) >(&AIS_Axis::SetColor),
             R"#()#"  , py::arg("aColor")
          )
        .def("SetWidth",
             (void (AIS_Axis::*)(  const double  ) ) static_cast<void (AIS_Axis::*)(  const double  ) >(&AIS_Axis::SetWidth),
             R"#()#"  , py::arg("aValue")
          )
        .def("SetDisplayAspect",
             (void (AIS_Axis::*)(  const handle<Prs3d_LineAspect> &  ) ) static_cast<void (AIS_Axis::*)(  const handle<Prs3d_LineAspect> &  ) >(&AIS_Axis::SetDisplayAspect),
             R"#(Set required visualization parameters.)#"  , py::arg("theNewDatumAspect")
          )
        .def("UnsetColor",
             (void (AIS_Axis::*)() ) static_cast<void (AIS_Axis::*)() >(&AIS_Axis::UnsetColor),
             R"#()#" 
          )
        .def("UnsetWidth",
             (void (AIS_Axis::*)() ) static_cast<void (AIS_Axis::*)() >(&AIS_Axis::UnsetWidth),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_Axis::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_Axis::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_Axis::*)() const) static_cast< const handle<Standard_Type> & (AIS_Axis::*)() const>(&AIS_Axis::DynamicType),
             R"#()#"
             
         )
       .def("Component",
             ( const handle<Geom_Line> & (AIS_Axis::*)() const) static_cast< const handle<Geom_Line> & (AIS_Axis::*)() const>(&AIS_Axis::Component),
             R"#(Returns the axis entity aComponent and identifies it as a component of a shape.)#"
             
         )
       .def("Axis2Placement",
             ( const handle<Geom_Axis2Placement> & (AIS_Axis::*)() const) static_cast< const handle<Geom_Axis2Placement> & (AIS_Axis::*)() const>(&AIS_Axis::Axis2Placement),
             R"#(Returns the position of axis2 and positions it by identifying it as the x, y, or z axis and giving its direction in 3D space. The coordinate system used is right-handed.)#"
             
         )
;

    // Class AIS_BaseAnimationObject from ./opencascade/AIS_BaseAnimationObject.hxx
    klass = m.attr("AIS_BaseAnimationObject");


    // nested enums

    static_cast<py::class_<AIS_BaseAnimationObject ,opencascade::handle<AIS_BaseAnimationObject>  , AIS_Animation >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_BaseAnimationObject::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_BaseAnimationObject::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_BaseAnimationObject::*)() const) static_cast< const handle<Standard_Type> & (AIS_BaseAnimationObject::*)() const>(&AIS_BaseAnimationObject::DynamicType),
             R"#()#"
             
         )
;

    // Class AIS_CameraFrustum from ./opencascade/AIS_CameraFrustum.hxx
    klass = m.attr("AIS_CameraFrustum");


    // nested enums
        py::enum_<AIS_CameraFrustum::SelectionMode>(klass, "SelectionMode_e", R"#(Selection modes supported by this object)#")
            .value("SelectionMode_Edges", AIS_CameraFrustum::SelectionMode::SelectionMode_Edges)
            .value("SelectionMode_Volume", AIS_CameraFrustum::SelectionMode::SelectionMode_Volume);

    static_cast<py::class_<AIS_CameraFrustum ,opencascade::handle<AIS_CameraFrustum>  , AIS_InteractiveObject >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetCameraFrustum",
             (void (AIS_CameraFrustum::*)(  const handle<Graphic3d_Camera> &  ) ) static_cast<void (AIS_CameraFrustum::*)(  const handle<Graphic3d_Camera> &  ) >(&AIS_CameraFrustum::SetCameraFrustum),
             R"#(Sets camera frustum.)#"  , py::arg("theCamera")
          )
        .def("SetColor",
             (void (AIS_CameraFrustum::*)(  const Quantity_Color &  ) ) static_cast<void (AIS_CameraFrustum::*)(  const Quantity_Color &  ) >(&AIS_CameraFrustum::SetColor),
             R"#(Setup custom color.)#"  , py::arg("theColor")
          )
        .def("UnsetColor",
             (void (AIS_CameraFrustum::*)() ) static_cast<void (AIS_CameraFrustum::*)() >(&AIS_CameraFrustum::UnsetColor),
             R"#(Restore default color.)#" 
          )
        .def("UnsetTransparency",
             (void (AIS_CameraFrustum::*)() ) static_cast<void (AIS_CameraFrustum::*)() >(&AIS_CameraFrustum::UnsetTransparency),
             R"#(Restore transparency setting.)#" 
          )
        .def("AcceptDisplayMode",
             (bool (AIS_CameraFrustum::*)(  const int  ) const) static_cast<bool (AIS_CameraFrustum::*)(  const int  ) const>(&AIS_CameraFrustum::AcceptDisplayMode),
             R"#(Return true if specified display mode is supported.)#"  , py::arg("theMode")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_CameraFrustum::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_CameraFrustum::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_CameraFrustum::*)() const) static_cast< const handle<Standard_Type> & (AIS_CameraFrustum::*)() const>(&AIS_CameraFrustum::DynamicType),
             R"#()#"
             
         )
;

    // Class AIS_Circle from ./opencascade/AIS_Circle.hxx
    klass = m.attr("AIS_Circle");


    // nested enums

    static_cast<py::class_<AIS_Circle ,opencascade::handle<AIS_Circle>  , AIS_InteractiveObject >>(klass)
    // constructors
        .def(py::init<  const handle<Geom_Circle> & >()  , py::arg("aCircle") )
        .def(py::init<  const handle<Geom_Circle> &, const double, const double, const bool >()  , py::arg("theCircle"),  py::arg("theUStart"),  py::arg("theUEnd"),  py::arg("theIsFilledCircleSens")=static_cast< const bool>(false) )
    // custom constructors
    // methods
        .def("Signature",
             (int (AIS_Circle::*)() const) static_cast<int (AIS_Circle::*)() const>(&AIS_Circle::Signature),
             R"#(Returns index 6 by default.)#" 
          )
        .def("Type",
             (AIS_KindOfInteractive (AIS_Circle::*)() const) static_cast<AIS_KindOfInteractive (AIS_Circle::*)() const>(&AIS_Circle::Type),
             R"#(Indicates that the type of Interactive Object is a datum.)#" 
          )
        .def("SetCircle",
             (void (AIS_Circle::*)(  const handle<Geom_Circle> &  ) ) static_cast<void (AIS_Circle::*)(  const handle<Geom_Circle> &  ) >(&AIS_Circle::SetCircle),
             R"#(Allows you to provide settings for the circle datum aCircle.)#"  , py::arg("theCircle")
          )
        .def("SetFirstParam",
             (void (AIS_Circle::*)(  const double  ) ) static_cast<void (AIS_Circle::*)(  const double  ) >(&AIS_Circle::SetFirstParam),
             R"#(Allows you to set the parameter theU for the starting point of an arc.)#"  , py::arg("theU")
          )
        .def("SetLastParam",
             (void (AIS_Circle::*)(  const double  ) ) static_cast<void (AIS_Circle::*)(  const double  ) >(&AIS_Circle::SetLastParam),
             R"#(Allows you to provide the parameter theU for the end point of an arc.)#"  , py::arg("theU")
          )
        .def("SetColor",
             (void (AIS_Circle::*)(  const Quantity_Color &  ) ) static_cast<void (AIS_Circle::*)(  const Quantity_Color &  ) >(&AIS_Circle::SetColor),
             R"#()#"  , py::arg("aColor")
          )
        .def("SetWidth",
             (void (AIS_Circle::*)(  const double  ) ) static_cast<void (AIS_Circle::*)(  const double  ) >(&AIS_Circle::SetWidth),
             R"#(Assigns the width aValue to the solid line boundary of the circle datum.)#"  , py::arg("aValue")
          )
        .def("UnsetColor",
             (void (AIS_Circle::*)() ) static_cast<void (AIS_Circle::*)() >(&AIS_Circle::UnsetColor),
             R"#(Removes color from the solid line boundary of the circle datum.)#" 
          )
        .def("UnsetWidth",
             (void (AIS_Circle::*)() ) static_cast<void (AIS_Circle::*)() >(&AIS_Circle::UnsetWidth),
             R"#(Removes width settings from the solid line boundary of the circle datum.)#" 
          )
        .def("IsFilledCircleSens",
             (bool (AIS_Circle::*)() const) static_cast<bool (AIS_Circle::*)() const>(&AIS_Circle::IsFilledCircleSens),
             R"#(Returns the type of sensitivity for the circle;)#" 
          )
        .def("SetFilledCircleSens",
             (void (AIS_Circle::*)(  const bool  ) ) static_cast<void (AIS_Circle::*)(  const bool  ) >(&AIS_Circle::SetFilledCircleSens),
             R"#(Sets the type of sensitivity for the circle. If theIsFilledCircleSens set to true then the whole circle will be detectable, otherwise only the boundary of the circle.)#"  , py::arg("theIsFilledCircleSens")
          )
    // methods using call by reference i.s.o. return
        .def("Parameters",
             []( AIS_Circle &self   ){
                 double  theU1;
                double  theU2;

                 self.Parameters(theU1,theU2);
                 return std::make_tuple(theU1,theU2); },
             R"#(Constructs instances of the starting point and the end point parameters, theU1 and theU2.)#" 
          )
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_Circle::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_Circle::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_Circle::*)() const) static_cast< const handle<Standard_Type> & (AIS_Circle::*)() const>(&AIS_Circle::DynamicType),
             R"#()#"
             
         )
       .def("Circle",
             ( const handle<Geom_Circle> & (AIS_Circle::*)() const) static_cast< const handle<Geom_Circle> & (AIS_Circle::*)() const>(&AIS_Circle::Circle),
             R"#(Returns the circle component defined in SetCircle.)#"
             
         )
;

    // Class AIS_ColorScale from ./opencascade/AIS_ColorScale.hxx
    klass = m.attr("AIS_ColorScale");


    // nested enums

    static_cast<py::class_<AIS_ColorScale ,opencascade::handle<AIS_ColorScale>  , AIS_InteractiveObject >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("FindColor",
             (bool (AIS_ColorScale::*)(  const double ,  Quantity_Color &  ) const) static_cast<bool (AIS_ColorScale::*)(  const double ,  Quantity_Color &  ) const>(&AIS_ColorScale::FindColor),
             R"#(Calculate color according passed value; returns true if value is in range or false, if isn't)#"  , py::arg("theValue"),  py::arg("theColor")
          )
        .def("GetMin",
             (double (AIS_ColorScale::*)() const) static_cast<double (AIS_ColorScale::*)() const>(&AIS_ColorScale::GetMin),
             R"#(Returns minimal value of color scale, 0.0 by default.)#" 
          )
        .def("SetMin",
             (void (AIS_ColorScale::*)(  const double  ) ) static_cast<void (AIS_ColorScale::*)(  const double  ) >(&AIS_ColorScale::SetMin),
             R"#(Sets the minimal value of color scale.)#"  , py::arg("theMin")
          )
        .def("GetMax",
             (double (AIS_ColorScale::*)() const) static_cast<double (AIS_ColorScale::*)() const>(&AIS_ColorScale::GetMax),
             R"#(Returns maximal value of color scale, 1.0 by default.)#" 
          )
        .def("SetMax",
             (void (AIS_ColorScale::*)(  const double  ) ) static_cast<void (AIS_ColorScale::*)(  const double  ) >(&AIS_ColorScale::SetMax),
             R"#(Sets the maximal value of color scale.)#"  , py::arg("theMax")
          )
        .def("SetRange",
             (void (AIS_ColorScale::*)(  const double ,   const double  ) ) static_cast<void (AIS_ColorScale::*)(  const double ,   const double  ) >(&AIS_ColorScale::SetRange),
             R"#(Sets the minimal and maximal value of color scale. Note that values order will be ignored - the minimum and maximum values will be swapped if needed. ::SetReversed() should be called to swap displaying order.)#"  , py::arg("theMin"),  py::arg("theMax")
          )
        .def("HueMin",
             (double (AIS_ColorScale::*)() const) static_cast<double (AIS_ColorScale::*)() const>(&AIS_ColorScale::HueMin),
             R"#(Returns the hue angle corresponding to minimum value, 230 by default (blue).)#" 
          )
        .def("HueMax",
             (double (AIS_ColorScale::*)() const) static_cast<double (AIS_ColorScale::*)() const>(&AIS_ColorScale::HueMax),
             R"#(Returns the hue angle corresponding to maximum value, 0 by default (red).)#" 
          )
        .def("SetHueRange",
             (void (AIS_ColorScale::*)(  const double ,   const double  ) ) static_cast<void (AIS_ColorScale::*)(  const double ,   const double  ) >(&AIS_ColorScale::SetHueRange),
             R"#(Sets hue angle range corresponding to minimum and maximum values. The valid angle range is [0, 360], see Quantity_Color and Quantity_TOC_HLS for more details.)#"  , py::arg("theMinAngle"),  py::arg("theMaxAngle")
          )
        .def("ColorRange",
             (void (AIS_ColorScale::*)( Quantity_Color & ,  Quantity_Color &  ) const) static_cast<void (AIS_ColorScale::*)( Quantity_Color & ,  Quantity_Color &  ) const>(&AIS_ColorScale::ColorRange),
             R"#(Returns color range corresponding to minimum and maximum values, blue to red by default.)#"  , py::arg("theMinColor"),  py::arg("theMaxColor")
          )
        .def("SetColorRange",
             (void (AIS_ColorScale::*)(  const Quantity_Color & ,   const Quantity_Color &  ) ) static_cast<void (AIS_ColorScale::*)(  const Quantity_Color & ,   const Quantity_Color &  ) >(&AIS_ColorScale::SetColorRange),
             R"#(Sets color range corresponding to minimum and maximum values.)#"  , py::arg("theMinColor"),  py::arg("theMaxColor")
          )
        .def("GetLabelType",
             (Aspect_TypeOfColorScaleData (AIS_ColorScale::*)() const) static_cast<Aspect_TypeOfColorScaleData (AIS_ColorScale::*)() const>(&AIS_ColorScale::GetLabelType),
             R"#(Returns the type of labels, Aspect_TOCSD_AUTO by default. Aspect_TOCSD_AUTO - labels as boundary values for intervals Aspect_TOCSD_USER - user specified label is used)#" 
          )
        .def("SetLabelType",
             (void (AIS_ColorScale::*)(  const Aspect_TypeOfColorScaleData  ) ) static_cast<void (AIS_ColorScale::*)(  const Aspect_TypeOfColorScaleData  ) >(&AIS_ColorScale::SetLabelType),
             R"#(Sets the type of labels. Aspect_TOCSD_AUTO - labels as boundary values for intervals Aspect_TOCSD_USER - user specified label is used)#"  , py::arg("theType")
          )
        .def("GetColorType",
             (Aspect_TypeOfColorScaleData (AIS_ColorScale::*)() const) static_cast<Aspect_TypeOfColorScaleData (AIS_ColorScale::*)() const>(&AIS_ColorScale::GetColorType),
             R"#(Returns the type of colors, Aspect_TOCSD_AUTO by default. Aspect_TOCSD_AUTO - value between Red and Blue Aspect_TOCSD_USER - user specified color from color map)#" 
          )
        .def("SetColorType",
             (void (AIS_ColorScale::*)(  const Aspect_TypeOfColorScaleData  ) ) static_cast<void (AIS_ColorScale::*)(  const Aspect_TypeOfColorScaleData  ) >(&AIS_ColorScale::SetColorType),
             R"#(Sets the type of colors. Aspect_TOCSD_AUTO - value between Red and Blue Aspect_TOCSD_USER - user specified color from color map)#"  , py::arg("theType")
          )
        .def("GetNumberOfIntervals",
             (int (AIS_ColorScale::*)() const) static_cast<int (AIS_ColorScale::*)() const>(&AIS_ColorScale::GetNumberOfIntervals),
             R"#(Returns the number of color scale intervals, 10 by default.)#" 
          )
        .def("SetNumberOfIntervals",
             (void (AIS_ColorScale::*)(  const int  ) ) static_cast<void (AIS_ColorScale::*)(  const int  ) >(&AIS_ColorScale::SetNumberOfIntervals),
             R"#(Sets the number of color scale intervals.)#"  , py::arg("theNum")
          )
        .def("SetTitle",
             (void (AIS_ColorScale::*)(  const TCollection_ExtendedString &  ) ) static_cast<void (AIS_ColorScale::*)(  const TCollection_ExtendedString &  ) >(&AIS_ColorScale::SetTitle),
             R"#(Sets the color scale title string.)#"  , py::arg("theTitle")
          )
        .def("SetFormat",
             (void (AIS_ColorScale::*)(  const TCollection_AsciiString &  ) ) static_cast<void (AIS_ColorScale::*)(  const TCollection_AsciiString &  ) >(&AIS_ColorScale::SetFormat),
             R"#(Sets the color scale auto label format specification.)#"  , py::arg("theFormat")
          )
        .def("GetLabel",
             (TCollection_ExtendedString (AIS_ColorScale::*)(  const int  ) const) static_cast<TCollection_ExtendedString (AIS_ColorScale::*)(  const int  ) const>(&AIS_ColorScale::GetLabel),
             R"#(Returns the user specified label with index theIndex. Index is in range from 1 to GetNumberOfIntervals() or to GetNumberOfIntervals() + 1 if IsLabelAtBorder() is true. Returns empty string if label not defined.)#"  , py::arg("theIndex")
          )
        .def("GetIntervalColor",
             (Quantity_Color (AIS_ColorScale::*)(  const int  ) const) static_cast<Quantity_Color (AIS_ColorScale::*)(  const int  ) const>(&AIS_ColorScale::GetIntervalColor),
             R"#(Returns the user specified color from color map with index (starts at 1). Returns default color if index is out of range in color map.)#"  , py::arg("theIndex")
          )
        .def("SetIntervalColor",
             (void (AIS_ColorScale::*)(  const Quantity_Color & ,   const int  ) ) static_cast<void (AIS_ColorScale::*)(  const Quantity_Color & ,   const int  ) >(&AIS_ColorScale::SetIntervalColor),
             R"#(Sets the color of the specified interval. Note that list is automatically resized to include specified index.)#"  , py::arg("theColor"),  py::arg("theIndex")
          )
        .def("GetLabels",
             (void (AIS_ColorScale::*)( NCollection_Sequence<TCollection_ExtendedString> &  ) const) static_cast<void (AIS_ColorScale::*)( NCollection_Sequence<TCollection_ExtendedString> &  ) const>(&AIS_ColorScale::GetLabels),
             R"#(Returns the user specified labels.)#"  , py::arg("theLabels")
          )
        .def("SetLabels",
             (void (AIS_ColorScale::*)(  const NCollection_Sequence<TCollection_ExtendedString> &  ) ) static_cast<void (AIS_ColorScale::*)(  const NCollection_Sequence<TCollection_ExtendedString> &  ) >(&AIS_ColorScale::SetLabels),
             R"#(Sets the color scale labels. The length of the sequence should be equal to GetNumberOfIntervals() or to GetNumberOfIntervals() + 1 if IsLabelAtBorder() is true. If length of the sequence does not much the number of intervals, then these labels will be considered as "free" and will be located at the virtual intervals corresponding to the number of labels (with flag IsLabelAtBorder() having the same effect as in normal case).)#"  , py::arg("theSeq")
          )
        .def("GetColors",
             (void (AIS_ColorScale::*)( NCollection_Sequence<Quantity_Color> &  ) const) static_cast<void (AIS_ColorScale::*)( NCollection_Sequence<Quantity_Color> &  ) const>(&AIS_ColorScale::GetColors),
             R"#(Returns the user specified colors.)#"  , py::arg("theColors")
          )
        .def("SetColors",
             (void (AIS_ColorScale::*)(  const NCollection_Sequence<Quantity_Color> &  ) ) static_cast<void (AIS_ColorScale::*)(  const NCollection_Sequence<Quantity_Color> &  ) >(&AIS_ColorScale::SetColors),
             R"#(Sets the color scale colors. The length of the sequence should be equal to GetNumberOfIntervals().)#"  , py::arg("theSeq")
          )
        .def("SetUniformColors",
             (void (AIS_ColorScale::*)( double ,  double ,  double  ) ) static_cast<void (AIS_ColorScale::*)( double ,  double ,  double  ) >(&AIS_ColorScale::SetUniformColors),
             R"#(Populates colors scale by colors of the same lightness value in CIE Lch color space, distributed by hue, with perceptually uniform differences between consequent colors. See MakeUniformColors() for description of parameters.)#"  , py::arg("theLightness"),  py::arg("theHueFrom"),  py::arg("theHueTo")
          )
        .def("GetLabelPosition",
             (Aspect_TypeOfColorScalePosition (AIS_ColorScale::*)() const) static_cast<Aspect_TypeOfColorScalePosition (AIS_ColorScale::*)() const>(&AIS_ColorScale::GetLabelPosition),
             R"#(Returns the position of labels concerning color filled rectangles, Aspect_TOCSP_RIGHT by default.)#" 
          )
        .def("SetLabelPosition",
             (void (AIS_ColorScale::*)(  const Aspect_TypeOfColorScalePosition  ) ) static_cast<void (AIS_ColorScale::*)(  const Aspect_TypeOfColorScalePosition  ) >(&AIS_ColorScale::SetLabelPosition),
             R"#(Sets the color scale labels position relative to color bar.)#"  , py::arg("thePos")
          )
        .def("GetTitlePosition",
             (Aspect_TypeOfColorScalePosition (AIS_ColorScale::*)() const) static_cast<Aspect_TypeOfColorScalePosition (AIS_ColorScale::*)() const>(&AIS_ColorScale::GetTitlePosition),
             R"#(Returns the position of color scale title, Aspect_TOCSP_LEFT by default.)#" 
          )
        .def("SetTitlePosition",
             (void (AIS_ColorScale::*)(  const Aspect_TypeOfColorScalePosition  ) ) static_cast<void (AIS_ColorScale::*)(  const Aspect_TypeOfColorScalePosition  ) >(&AIS_ColorScale::SetTitlePosition),
             R"#(Sets the color scale title position.)#"  , py::arg("thePos")
          )
        .def("IsReversed",
             (bool (AIS_ColorScale::*)() const) static_cast<bool (AIS_ColorScale::*)() const>(&AIS_ColorScale::IsReversed),
             R"#(Returns TRUE if the labels and colors used in reversed order, FALSE by default. - Normal, bottom-up order with Minimal value on the Bottom and Maximum value on Top. - Reversed, top-down order with Maximum value on the Bottom and Minimum value on Top.)#" 
          )
        .def("SetReversed",
             (void (AIS_ColorScale::*)(  const bool  ) ) static_cast<void (AIS_ColorScale::*)(  const bool  ) >(&AIS_ColorScale::SetReversed),
             R"#(Sets true if the labels and colors used in reversed order.)#"  , py::arg("theReverse")
          )
        .def("IsSmoothTransition",
             (bool (AIS_ColorScale::*)() const) static_cast<bool (AIS_ColorScale::*)() const>(&AIS_ColorScale::IsSmoothTransition),
             R"#(Return TRUE if color transition between neighbor intervals should be linearly interpolated, FALSE by default.)#" 
          )
        .def("SetSmoothTransition",
             (void (AIS_ColorScale::*)(  const bool  ) ) static_cast<void (AIS_ColorScale::*)(  const bool  ) >(&AIS_ColorScale::SetSmoothTransition),
             R"#(Setup smooth color transition.)#"  , py::arg("theIsSmooth")
          )
        .def("IsLabelAtBorder",
             (bool (AIS_ColorScale::*)() const) static_cast<bool (AIS_ColorScale::*)() const>(&AIS_ColorScale::IsLabelAtBorder),
             R"#(Returns TRUE if the labels are placed at border of color intervals, TRUE by default. The automatically generated label will show value exactly on the current position: - value connecting two neighbor intervals (TRUE) - value in the middle of interval (FALSE))#" 
          )
        .def("SetLabelAtBorder",
             (void (AIS_ColorScale::*)(  const bool  ) ) static_cast<void (AIS_ColorScale::*)(  const bool  ) >(&AIS_ColorScale::SetLabelAtBorder),
             R"#(Sets true if the labels are placed at border of color intervals (TRUE by default). If set to False, labels will be drawn at color intervals rather than at borders.)#"  , py::arg("theOn")
          )
        .def("IsLogarithmic",
             (bool (AIS_ColorScale::*)() const) static_cast<bool (AIS_ColorScale::*)() const>(&AIS_ColorScale::IsLogarithmic),
             R"#(Returns TRUE if the color scale has logarithmic intervals, FALSE by default.)#" 
          )
        .def("SetLogarithmic",
             (void (AIS_ColorScale::*)(  const bool  ) ) static_cast<void (AIS_ColorScale::*)(  const bool  ) >(&AIS_ColorScale::SetLogarithmic),
             R"#(Sets true if the color scale has logarithmic intervals.)#"  , py::arg("isLogarithmic")
          )
        .def("SetLabel",
             (void (AIS_ColorScale::*)(  const TCollection_ExtendedString & ,   const int  ) ) static_cast<void (AIS_ColorScale::*)(  const TCollection_ExtendedString & ,   const int  ) >(&AIS_ColorScale::SetLabel),
             R"#(Sets the color scale label at index. Note that list is automatically resized to include specified index.)#"  , py::arg("theLabel"),  py::arg("theIndex")
          )
        .def("SetSize",
             (void (AIS_ColorScale::*)(  const int ,   const int  ) ) static_cast<void (AIS_ColorScale::*)(  const int ,   const int  ) >(&AIS_ColorScale::SetSize),
             R"#(Sets the size of color bar.)#"  , py::arg("theBreadth"),  py::arg("theHeight")
          )
        .def("GetBreadth",
             (int (AIS_ColorScale::*)() const) static_cast<int (AIS_ColorScale::*)() const>(&AIS_ColorScale::GetBreadth),
             R"#(Returns the breadth of color bar, 0 by default (e.g. should be set by user explicitly before displaying).)#" 
          )
        .def("SetBreadth",
             (void (AIS_ColorScale::*)(  const int  ) ) static_cast<void (AIS_ColorScale::*)(  const int  ) >(&AIS_ColorScale::SetBreadth),
             R"#(Sets the width of color bar.)#"  , py::arg("theBreadth")
          )
        .def("GetHeight",
             (int (AIS_ColorScale::*)() const) static_cast<int (AIS_ColorScale::*)() const>(&AIS_ColorScale::GetHeight),
             R"#(Returns the height of color bar, 0 by default (e.g. should be set by user explicitly before displaying).)#" 
          )
        .def("SetHeight",
             (void (AIS_ColorScale::*)(  const int  ) ) static_cast<void (AIS_ColorScale::*)(  const int  ) >(&AIS_ColorScale::SetHeight),
             R"#(Sets the height of color bar.)#"  , py::arg("theHeight")
          )
        .def("SetPosition",
             (void (AIS_ColorScale::*)(  const int ,   const int  ) ) static_cast<void (AIS_ColorScale::*)(  const int ,   const int  ) >(&AIS_ColorScale::SetPosition),
             R"#(Sets the position of color scale.)#"  , py::arg("theX"),  py::arg("theY")
          )
        .def("GetXPosition",
             (int (AIS_ColorScale::*)() const) static_cast<int (AIS_ColorScale::*)() const>(&AIS_ColorScale::GetXPosition),
             R"#(Returns the left position of color scale, 0 by default.)#" 
          )
        .def("SetXPosition",
             (void (AIS_ColorScale::*)(  const int  ) ) static_cast<void (AIS_ColorScale::*)(  const int  ) >(&AIS_ColorScale::SetXPosition),
             R"#(Sets the left position of color scale.)#"  , py::arg("theX")
          )
        .def("GetYPosition",
             (int (AIS_ColorScale::*)() const) static_cast<int (AIS_ColorScale::*)() const>(&AIS_ColorScale::GetYPosition),
             R"#(Returns the bottom position of color scale, 0 by default.)#" 
          )
        .def("SetYPosition",
             (void (AIS_ColorScale::*)(  const int  ) ) static_cast<void (AIS_ColorScale::*)(  const int  ) >(&AIS_ColorScale::SetYPosition),
             R"#(Sets the bottom position of color scale.)#"  , py::arg("theY")
          )
        .def("GetTextHeight",
             (int (AIS_ColorScale::*)() const) static_cast<int (AIS_ColorScale::*)() const>(&AIS_ColorScale::GetTextHeight),
             R"#(Returns the font height of text labels, 20 by default.)#" 
          )
        .def("SetTextHeight",
             (void (AIS_ColorScale::*)(  const int  ) ) static_cast<void (AIS_ColorScale::*)(  const int  ) >(&AIS_ColorScale::SetTextHeight),
             R"#(Sets the height of text of color scale.)#"  , py::arg("theHeight")
          )
        .def("TextWidth",
             (int (AIS_ColorScale::*)(  const TCollection_ExtendedString &  ) const) static_cast<int (AIS_ColorScale::*)(  const TCollection_ExtendedString &  ) const>(&AIS_ColorScale::TextWidth),
             R"#(Returns the width of text.)#"  , py::arg("theText")
          )
        .def("TextHeight",
             (int (AIS_ColorScale::*)(  const TCollection_ExtendedString &  ) const) static_cast<int (AIS_ColorScale::*)(  const TCollection_ExtendedString &  ) const>(&AIS_ColorScale::TextHeight),
             R"#(Returns the height of text.)#"  , py::arg("theText")
          )
        .def("AcceptDisplayMode",
             (bool (AIS_ColorScale::*)(  const int  ) const) static_cast<bool (AIS_ColorScale::*)(  const int  ) const>(&AIS_ColorScale::AcceptDisplayMode),
             R"#(Return true if specified display mode is supported.)#"  , py::arg("theMode")
          )
        .def("Compute",
             (void (AIS_ColorScale::*)(  const handle<PrsMgr_PresentationManager> & ,   const handle<Prs3d_Presentation> & ,   const int  ) ) static_cast<void (AIS_ColorScale::*)(  const handle<PrsMgr_PresentationManager> & ,   const handle<Prs3d_Presentation> & ,   const int  ) >(&AIS_ColorScale::Compute),
             R"#(Compute presentation.)#"  , py::arg("thePrsMgr"),  py::arg("thePresentation"),  py::arg("theMode")
          )
        .def("ComputeSelection",
             (void (AIS_ColorScale::*)(  const handle<SelectMgr_Selection> & ,   const int  ) ) static_cast<void (AIS_ColorScale::*)(  const handle<SelectMgr_Selection> & ,   const int  ) >(&AIS_ColorScale::ComputeSelection),
             R"#(Compute selection - not implemented for color scale.)#"  , py::arg("arg0"),  py::arg("arg1")
          )
    // methods using call by reference i.s.o. return
        .def("GetRange",
             []( AIS_ColorScale &self   ){
                 double  theMin;
                double  theMax;

                 self.GetRange(theMin,theMax);
                 return std::make_tuple(theMin,theMax); },
             R"#(Returns minimal and maximal values of color scale, 0.0 to 1.0 by default.)#" 
          )
        .def("HueRange",
             []( AIS_ColorScale &self   ){
                 double  theMinAngle;
                double  theMaxAngle;

                 self.HueRange(theMinAngle,theMaxAngle);
                 return std::make_tuple(theMinAngle,theMaxAngle); },
             R"#(Returns the hue angle range corresponding to minimum and maximum values, 230 to 0 by default (blue to red).)#" 
          )
        .def("GetSize",
             []( AIS_ColorScale &self   ){
                 int  theBreadth;
                int  theHeight;

                 self.GetSize(theBreadth,theHeight);
                 return std::make_tuple(theBreadth,theHeight); },
             R"#(Returns the size of color bar, 0 and 0 by default (e.g. should be set by user explicitly before displaying).)#" 
          )
        .def("GetPosition",
             []( AIS_ColorScale &self   ){
                 double  theX;
                double  theY;

                 self.GetPosition(theX,theY);
                 return std::make_tuple(theX,theY); },
             R"#(Returns the bottom-left position of color scale, 0x0 by default.)#" 
          )
        .def("TextSize",
             []( AIS_ColorScale &self ,  const TCollection_ExtendedString & theText, const int theHeight ){
                 int  theWidth;
                int  theAscent;
                int  theDescent;

                 self.TextSize(theText,theHeight,theWidth,theAscent,theDescent);
                 return std::make_tuple(theWidth,theAscent,theDescent); },
             R"#()#"  , py::arg("theText"),  py::arg("theHeight")
          )
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_ColorScale::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_ColorScale::get_type_descriptor),
                    R"#()#" 
          )
        .def_static("FindColor_s",
                    (bool (*)(  const double ,   const double ,   const double ,   const int ,   const NCollection_Vec3<double> & ,   const NCollection_Vec3<double> & ,  Quantity_Color &  ) ) static_cast<bool (*)(  const double ,   const double ,   const double ,   const int ,   const NCollection_Vec3<double> & ,   const NCollection_Vec3<double> & ,  Quantity_Color &  ) >(&AIS_ColorScale::FindColor),
                    R"#(Calculate color according passed value; returns true if value is in range or false, if isn't)#"  , py::arg("theValue"),  py::arg("theMin"),  py::arg("theMax"),  py::arg("theColorsCount"),  py::arg("theColorHlsMin"),  py::arg("theColorHlsMax"),  py::arg("theColor")
          )
        .def_static("FindColor_s",
                    (bool (*)(  const double ,   const double ,   const double ,   const int ,  Quantity_Color &  ) ) static_cast<bool (*)(  const double ,   const double ,   const double ,   const int ,  Quantity_Color &  ) >(&AIS_ColorScale::FindColor),
                    R"#(Calculate color according passed value; returns true if value is in range or false, if isn't)#"  , py::arg("theValue"),  py::arg("theMin"),  py::arg("theMax"),  py::arg("theColorsCount"),  py::arg("theColor")
          )
        .def_static("hueToValidRange_s",
                    (double (*)(  const double  ) ) static_cast<double (*)(  const double  ) >(&AIS_ColorScale::hueToValidRange),
                    R"#(Shift hue into valid range. Lightness and Saturation should be specified in valid range [0.0, 1.0], however Hue might be given out of Quantity_Color range to specify desired range for interpolation.)#"  , py::arg("theHue")
          )
        .def_static("MakeUniformColors_s",
                    (NCollection_Sequence<Quantity_Color> (*)( int ,  double ,  double ,  double  ) ) static_cast<NCollection_Sequence<Quantity_Color> (*)( int ,  double ,  double ,  double  ) >(&AIS_ColorScale::MakeUniformColors),
                    R"#(Generates sequence of colors of the same lightness value in CIE Lch color space (see #Quantity_TOC_CIELch), with hue values in the specified range. The colors are distributed across the range such as to have perceptually same difference between neighbour colors. For each color, maximal chroma value fitting in sRGB gamut is used.)#"  , py::arg("theNbColors"),  py::arg("theLightness"),  py::arg("theHueFrom"),  py::arg("theHueTo")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_ColorScale::*)() const) static_cast< const handle<Standard_Type> & (AIS_ColorScale::*)() const>(&AIS_ColorScale::DynamicType),
             R"#()#"
             
         )
       .def("GetTitle",
             ( const TCollection_ExtendedString & (AIS_ColorScale::*)() const) static_cast< const TCollection_ExtendedString & (AIS_ColorScale::*)() const>(&AIS_ColorScale::GetTitle),
             R"#(Returns the color scale title string, empty string by default.)#"
             
         )
       .def("GetFormat",
             ( const TCollection_AsciiString & (AIS_ColorScale::*)() const) static_cast< const TCollection_AsciiString & (AIS_ColorScale::*)() const>(&AIS_ColorScale::GetFormat),
             R"#(Returns the format for numbers, "%.4g" by default. The same like format for function printf(). Used if GetLabelType() is TOCSD_AUTO;)#"
             
         )
       .def("Format",
             ( const TCollection_AsciiString & (AIS_ColorScale::*)() const) static_cast< const TCollection_AsciiString & (AIS_ColorScale::*)() const>(&AIS_ColorScale::Format),
             R"#(Returns the format of text.)#"
             
         )
       .def("Labels",
             ( const NCollection_Sequence<TCollection_ExtendedString> & (AIS_ColorScale::*)() const) static_cast< const NCollection_Sequence<TCollection_ExtendedString> & (AIS_ColorScale::*)() const>(&AIS_ColorScale::Labels),
             R"#(Returns the user specified labels.)#"
             
         )
       .def("GetColors",
             ( const NCollection_Sequence<Quantity_Color> & (AIS_ColorScale::*)() const) static_cast< const NCollection_Sequence<Quantity_Color> & (AIS_ColorScale::*)() const>(&AIS_ColorScale::GetColors),
             R"#(Returns the user specified colors.)#"
             
         )
;

    // Class AIS_ConnectedInteractive from ./opencascade/AIS_ConnectedInteractive.hxx
    klass = m.attr("AIS_ConnectedInteractive");


    // nested enums

    static_cast<py::class_<AIS_ConnectedInteractive ,opencascade::handle<AIS_ConnectedInteractive>  , AIS_InteractiveObject >>(klass)
    // constructors
        .def(py::init<  const PrsMgr_TypeOfPresentation3d >()  , py::arg("aTypeOfPresentation3d")=static_cast< const PrsMgr_TypeOfPresentation3d>(PrsMgr_TOP_AllView) )
    // custom constructors
    // methods
        .def("Type",
             (AIS_KindOfInteractive (AIS_ConnectedInteractive::*)() const) static_cast<AIS_KindOfInteractive (AIS_ConnectedInteractive::*)() const>(&AIS_ConnectedInteractive::Type),
             R"#(Returns KOI_Object)#" 
          )
        .def("Signature",
             (int (AIS_ConnectedInteractive::*)() const) static_cast<int (AIS_ConnectedInteractive::*)() const>(&AIS_ConnectedInteractive::Signature),
             R"#(Returns 0)#" 
          )
        .def("Connect",
             (void (AIS_ConnectedInteractive::*)(  const handle<AIS_InteractiveObject> &  ) ) static_cast<void (AIS_ConnectedInteractive::*)(  const handle<AIS_InteractiveObject> &  ) >(&AIS_ConnectedInteractive::Connect),
             R"#(Establishes the connection between the Connected Interactive Object, anotherIobj, and its reference.)#"  , py::arg("theAnotherObj")
          )
        .def("Connect",
             (void (AIS_ConnectedInteractive::*)(  const handle<AIS_InteractiveObject> & ,   const gp_Trsf &  ) ) static_cast<void (AIS_ConnectedInteractive::*)(  const handle<AIS_InteractiveObject> & ,   const gp_Trsf &  ) >(&AIS_ConnectedInteractive::Connect),
             R"#(Establishes the connection between the Connected Interactive Object, anotherIobj, and its reference. Locates instance in aLocation.)#"  , py::arg("theAnotherObj"),  py::arg("theLocation")
          )
        .def("Connect",
             (void (AIS_ConnectedInteractive::*)(  const handle<AIS_InteractiveObject> & ,   const handle<TopLoc_Datum3D> &  ) ) static_cast<void (AIS_ConnectedInteractive::*)(  const handle<AIS_InteractiveObject> & ,   const handle<TopLoc_Datum3D> &  ) >(&AIS_ConnectedInteractive::Connect),
             R"#(Establishes the connection between the Connected Interactive Object, anotherIobj, and its reference. Locates instance in aLocation.)#"  , py::arg("theAnotherObj"),  py::arg("theLocation")
          )
        .def("HasConnection",
             (bool (AIS_ConnectedInteractive::*)() const) static_cast<bool (AIS_ConnectedInteractive::*)() const>(&AIS_ConnectedInteractive::HasConnection),
             R"#(Returns true if there is a connection established between the presentation and its source reference.)#" 
          )
        .def("Disconnect",
             (void (AIS_ConnectedInteractive::*)() ) static_cast<void (AIS_ConnectedInteractive::*)() >(&AIS_ConnectedInteractive::Disconnect),
             R"#(Clears the connection with a source reference. The presentation will no longer be displayed. Warning Must be done before deleting the presentation.)#" 
          )
        .def("AcceptShapeDecomposition",
             (bool (AIS_ConnectedInteractive::*)() const) static_cast<bool (AIS_ConnectedInteractive::*)() const>(&AIS_ConnectedInteractive::AcceptShapeDecomposition),
             R"#(Informs the graphic context that the interactive Object may be decomposed into sub-shapes for dynamic selection.)#" 
          )
        .def("AcceptDisplayMode",
             (bool (AIS_ConnectedInteractive::*)(  const int  ) const) static_cast<bool (AIS_ConnectedInteractive::*)(  const int  ) const>(&AIS_ConnectedInteractive::AcceptDisplayMode),
             R"#(Return true if reference presentation accepts specified display mode.)#"  , py::arg("theMode")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_ConnectedInteractive::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_ConnectedInteractive::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_ConnectedInteractive::*)() const) static_cast< const handle<Standard_Type> & (AIS_ConnectedInteractive::*)() const>(&AIS_ConnectedInteractive::DynamicType),
             R"#()#"
             
         )
       .def("ConnectedTo",
             ( const handle<AIS_InteractiveObject> & (AIS_ConnectedInteractive::*)() const) static_cast< const handle<AIS_InteractiveObject> & (AIS_ConnectedInteractive::*)() const>(&AIS_ConnectedInteractive::ConnectedTo),
             R"#(Returns the connection with the reference Interactive Object.)#"
             
         )
;

    // Class AIS_LightSource from ./opencascade/AIS_LightSource.hxx
    klass = m.attr("AIS_LightSource");


    // nested enums

    static_cast<py::class_<AIS_LightSource ,opencascade::handle<AIS_LightSource>  , AIS_InteractiveObject >>(klass)
    // constructors
        .def(py::init<  const handle<Graphic3d_CLight> & >()  , py::arg("theLightSource") )
    // custom constructors
    // methods
        .def("SetLight",
             (void (AIS_LightSource::*)(  const handle<Graphic3d_CLight> &  ) ) static_cast<void (AIS_LightSource::*)(  const handle<Graphic3d_CLight> &  ) >(&AIS_LightSource::SetLight),
             R"#(Set the light.)#"  , py::arg("theLight")
          )
        .def("ToDisplayName",
             (bool (AIS_LightSource::*)() const) static_cast<bool (AIS_LightSource::*)() const>(&AIS_LightSource::ToDisplayName),
             R"#(Returns TRUE if the light source name should be displayed; TRUE by default.)#" 
          )
        .def("SetDisplayName",
             (void (AIS_LightSource::*)( bool  ) ) static_cast<void (AIS_LightSource::*)( bool  ) >(&AIS_LightSource::SetDisplayName),
             R"#(Show/hide light source name.)#"  , py::arg("theToDisplay")
          )
        .def("ToDisplayRange",
             (bool (AIS_LightSource::*)() const) static_cast<bool (AIS_LightSource::*)() const>(&AIS_LightSource::ToDisplayRange),
             R"#(Returns TRUE to display light source range as sphere (positional light) or cone (spot light); TRUE by default. Has no effect for non-zoomable presentation.)#" 
          )
        .def("SetDisplayRange",
             (void (AIS_LightSource::*)( bool  ) ) static_cast<void (AIS_LightSource::*)( bool  ) >(&AIS_LightSource::SetDisplayRange),
             R"#(Show/hide light source range shaded presentation.)#"  , py::arg("theToDisplay")
          )
        .def("Size",
             (double (AIS_LightSource::*)() const) static_cast<double (AIS_LightSource::*)() const>(&AIS_LightSource::Size),
             R"#(Returns the size of presentation; 50 by default.)#" 
          )
        .def("SetSize",
             (void (AIS_LightSource::*)( double  ) ) static_cast<void (AIS_LightSource::*)( double  ) >(&AIS_LightSource::SetSize),
             R"#(Sets the size of presentation.)#"  , py::arg("theSize")
          )
        .def("ArcSize",
             (int (AIS_LightSource::*)() const) static_cast<int (AIS_LightSource::*)() const>(&AIS_LightSource::ArcSize),
             R"#(Returns Sensitive sphere arc size in pixels; 20 by default.)#" 
          )
        .def("SetArcSize",
             (void (AIS_LightSource::*)( int  ) ) static_cast<void (AIS_LightSource::*)( int  ) >(&AIS_LightSource::SetArcSize),
             R"#(Sets the size of sensitive sphere arc.)#"  , py::arg("theSize")
          )
        .def("IsZoomable",
             (bool (AIS_LightSource::*)() const) static_cast<bool (AIS_LightSource::*)() const>(&AIS_LightSource::IsZoomable),
             R"#(Returns TRUE if transform-persistence is allowed; TRUE by default for Ambient and Directional lights and FALSE by default for Positional and Spot lights.)#" 
          )
        .def("SetZoomable",
             (void (AIS_LightSource::*)( bool  ) ) static_cast<void (AIS_LightSource::*)( bool  ) >(&AIS_LightSource::SetZoomable),
             R"#(Sets if transform-persistence is allowed.)#"  , py::arg("theIsZoomable")
          )
        .def("SetDraggable",
             (void (AIS_LightSource::*)( bool  ) ) static_cast<void (AIS_LightSource::*)( bool  ) >(&AIS_LightSource::SetDraggable),
             R"#(Sets if dragging is allowed.)#"  , py::arg("theIsDraggable")
          )
        .def("ToSwitchOnClick",
             (bool (AIS_LightSource::*)() const) static_cast<bool (AIS_LightSource::*)() const>(&AIS_LightSource::ToSwitchOnClick),
             R"#(Returns TRUE if mouse click will turn light on/off; TRUE by default.)#" 
          )
        .def("SetSwitchOnClick",
             (void (AIS_LightSource::*)( bool  ) ) static_cast<void (AIS_LightSource::*)( bool  ) >(&AIS_LightSource::SetSwitchOnClick),
             R"#(Sets if mouse click should turn light on/off.)#"  , py::arg("theToHandle")
          )
        .def("NbArrows",
             (int (AIS_LightSource::*)() const) static_cast<int (AIS_LightSource::*)() const>(&AIS_LightSource::NbArrows),
             R"#(Returns a number of directional light arrows to display; 5 by default.)#" 
          )
        .def("SetNbArrows",
             (void (AIS_LightSource::*)( int  ) ) static_cast<void (AIS_LightSource::*)( int  ) >(&AIS_LightSource::SetNbArrows),
             R"#(Returns a number of directional light arrows to display (supported values: 1, 3, 5, 9).)#"  , py::arg("theNbArrows")
          )
        .def("MarkerImage",
             ( const handle<Graphic3d_MarkerImage> & (AIS_LightSource::*)( bool  ) const) static_cast< const handle<Graphic3d_MarkerImage> & (AIS_LightSource::*)( bool  ) const>(&AIS_LightSource::MarkerImage),
             R"#(Returns light source icon.)#"  , py::arg("theIsEnabled")
          )
        .def("MarkerType",
             (Aspect_TypeOfMarker (AIS_LightSource::*)( bool  ) const) static_cast<Aspect_TypeOfMarker (AIS_LightSource::*)( bool  ) const>(&AIS_LightSource::MarkerType),
             R"#(Returns light source icon.)#"  , py::arg("theIsEnabled")
          )
        .def("SetMarkerImage",
             (void (AIS_LightSource::*)(  const handle<Graphic3d_MarkerImage> & ,  bool  ) ) static_cast<void (AIS_LightSource::*)(  const handle<Graphic3d_MarkerImage> & ,  bool  ) >(&AIS_LightSource::SetMarkerImage),
             R"#(Sets custom icon to light source.)#"  , py::arg("theImage"),  py::arg("theIsEnabled")
          )
        .def("SetMarkerType",
             (void (AIS_LightSource::*)( Aspect_TypeOfMarker ,  bool  ) ) static_cast<void (AIS_LightSource::*)( Aspect_TypeOfMarker ,  bool  ) >(&AIS_LightSource::SetMarkerType),
             R"#(Sets standard icon to light source.)#"  , py::arg("theType"),  py::arg("theIsEnabled")
          )
        .def("NbSplitsQuadric",
             (int (AIS_LightSource::*)() const) static_cast<int (AIS_LightSource::*)() const>(&AIS_LightSource::NbSplitsQuadric),
             R"#(Returns tessellation level for quadric surfaces; 30 by default.)#" 
          )
        .def("SetNbSplitsQuadric",
             (void (AIS_LightSource::*)( int  ) ) static_cast<void (AIS_LightSource::*)( int  ) >(&AIS_LightSource::SetNbSplitsQuadric),
             R"#(Sets tessellation level for quadric surfaces.)#"  , py::arg("theNbSplits")
          )
        .def("NbSplitsArrow",
             (int (AIS_LightSource::*)() const) static_cast<int (AIS_LightSource::*)() const>(&AIS_LightSource::NbSplitsArrow),
             R"#(Returns tessellation level for arrows; 20 by default.)#" 
          )
        .def("SetNbSplitsArrow",
             (void (AIS_LightSource::*)( int  ) ) static_cast<void (AIS_LightSource::*)( int  ) >(&AIS_LightSource::SetNbSplitsArrow),
             R"#(Sets tessellation level for arrows.)#"  , py::arg("theNbSplits")
          )
        .def("Type",
             (AIS_KindOfInteractive (AIS_LightSource::*)() const) static_cast<AIS_KindOfInteractive (AIS_LightSource::*)() const>(&AIS_LightSource::Type),
             R"#(Returns kind of the object.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_LightSource::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_LightSource::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_LightSource::*)() const) static_cast< const handle<Standard_Type> & (AIS_LightSource::*)() const>(&AIS_LightSource::DynamicType),
             R"#()#"
             
         )
       .def("Light",
             ( const handle<Graphic3d_CLight> & (AIS_LightSource::*)() const) static_cast< const handle<Graphic3d_CLight> & (AIS_LightSource::*)() const>(&AIS_LightSource::Light),
             R"#(Returns the light.)#"
             
         )
;

    // Class AIS_Line from ./opencascade/AIS_Line.hxx
    klass = m.attr("AIS_Line");


    // nested enums

    static_cast<py::class_<AIS_Line ,opencascade::handle<AIS_Line>  , AIS_InteractiveObject >>(klass)
    // constructors
        .def(py::init<  const handle<Geom_Line> & >()  , py::arg("aLine") )
        .def(py::init<  const handle<Geom_Point> &, const handle<Geom_Point> & >()  , py::arg("aStartPoint"),  py::arg("aEndPoint") )
    // custom constructors
    // methods
        .def("Signature",
             (int (AIS_Line::*)() const) static_cast<int (AIS_Line::*)() const>(&AIS_Line::Signature),
             R"#(Returns the signature 5.)#" 
          )
        .def("Type",
             (AIS_KindOfInteractive (AIS_Line::*)() const) static_cast<AIS_KindOfInteractive (AIS_Line::*)() const>(&AIS_Line::Type),
             R"#(Returns the type Datum.)#" 
          )
        .def("SetLine",
             (void (AIS_Line::*)(  const handle<Geom_Line> &  ) ) static_cast<void (AIS_Line::*)(  const handle<Geom_Line> &  ) >(&AIS_Line::SetLine),
             R"#(Sets the infinite line.)#"  , py::arg("theLine")
          )
        .def("SetPoints",
             (void (AIS_Line::*)(  const handle<Geom_Point> & ,   const handle<Geom_Point> &  ) ) static_cast<void (AIS_Line::*)(  const handle<Geom_Point> & ,   const handle<Geom_Point> &  ) >(&AIS_Line::SetPoints),
             R"#(Sets the starting point and ending point of the infinite line to create a finite line segment.)#"  , py::arg("thePStart"),  py::arg("thePEnd")
          )
        .def("SetColor",
             (void (AIS_Line::*)(  const Quantity_Color &  ) ) static_cast<void (AIS_Line::*)(  const Quantity_Color &  ) >(&AIS_Line::SetColor),
             R"#(Provides a new color setting aColor for the line in the drawing tool, or "Drawer".)#"  , py::arg("aColor")
          )
        .def("SetWidth",
             (void (AIS_Line::*)(  const double  ) ) static_cast<void (AIS_Line::*)(  const double  ) >(&AIS_Line::SetWidth),
             R"#(Provides the new width setting aValue for the line in the drawing tool, or "Drawer".)#"  , py::arg("aValue")
          )
        .def("UnsetColor",
             (void (AIS_Line::*)() ) static_cast<void (AIS_Line::*)() >(&AIS_Line::UnsetColor),
             R"#(Removes the color setting and returns the original color.)#" 
          )
        .def("UnsetWidth",
             (void (AIS_Line::*)() ) static_cast<void (AIS_Line::*)() >(&AIS_Line::UnsetWidth),
             R"#(Removes the width setting and returns the original width.)#" 
          )
    // methods using call by reference i.s.o. return
        .def("Points",
             []( AIS_Line &self , Geom_Point& thePStart,Geom_Point& thePEnd ){
                 handle<Geom_Point>  thePStart_ptr; thePStart_ptr = &thePStart;
                handle<Geom_Point>  thePEnd_ptr; thePEnd_ptr = &thePEnd;

                 self.Points(thePStart_ptr,thePEnd_ptr);
                 return std::make_tuple(thePStart_ptr,thePEnd_ptr); },
             R"#(Returns the starting point thePStart and the end point thePEnd of the line set by SetPoints.)#"  , py::arg("thePStart"),  py::arg("thePEnd")
          )
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_Line::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_Line::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_Line::*)() const) static_cast< const handle<Standard_Type> & (AIS_Line::*)() const>(&AIS_Line::DynamicType),
             R"#()#"
             
         )
       .def("Line",
             ( const handle<Geom_Line> & (AIS_Line::*)() const) static_cast< const handle<Geom_Line> & (AIS_Line::*)() const>(&AIS_Line::Line),
             R"#(Constructs an infinite line.)#"
             
         )
       .def("StartPoint",
             ( const handle<Geom_Point> & (AIS_Line::*)() const) static_cast< const handle<Geom_Point> & (AIS_Line::*)() const>(&AIS_Line::StartPoint),
             R"#(Returns the starting point of the line set by SetPoints.)#"
             
         )
       .def("EndPoint",
             ( const handle<Geom_Point> & (AIS_Line::*)() const) static_cast< const handle<Geom_Point> & (AIS_Line::*)() const>(&AIS_Line::EndPoint),
             R"#(Returns the end point of the line set by SetPoints.)#"
             
         )
;

    // Class AIS_Manipulator from ./opencascade/AIS_Manipulator.hxx
    klass = m.attr("AIS_Manipulator");


    // nested enums
        py::enum_<AIS_Manipulator::ManipulatorSkin>(klass, "ManipulatorSkin_e", R"#()#")
            .value("ManipulatorSkin_Shaded", AIS_Manipulator::ManipulatorSkin::ManipulatorSkin_Shaded)
            .value("ManipulatorSkin_Flat", AIS_Manipulator::ManipulatorSkin::ManipulatorSkin_Flat);

    static_cast<py::class_<AIS_Manipulator ,opencascade::handle<AIS_Manipulator>  , AIS_InteractiveObject >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const gp_Ax2 & >()  , py::arg("thePosition") )
    // custom constructors
    // methods
        .def("SetPart",
             (void (AIS_Manipulator::*)(  const int ,   const AIS_ManipulatorMode ,   const bool  ) ) static_cast<void (AIS_Manipulator::*)(  const int ,   const AIS_ManipulatorMode ,   const bool  ) >(&AIS_Manipulator::SetPart),
             R"#(Disable or enable visual parts for translation, rotation or scaling for some axis. By default all parts are enabled (will be displayed).)#"  , py::arg("theAxisIndex"),  py::arg("theMode"),  py::arg("theIsEnabled")
          )
        .def("SetPart",
             (void (AIS_Manipulator::*)(  const AIS_ManipulatorMode ,   const bool  ) ) static_cast<void (AIS_Manipulator::*)(  const AIS_ManipulatorMode ,   const bool  ) >(&AIS_Manipulator::SetPart),
             R"#(Disable or enable visual parts for translation, rotation or scaling for ALL axes. By default all parts are enabled (will be displayed).)#"  , py::arg("theMode"),  py::arg("theIsEnabled")
          )
        .def("Attach",
             (void (AIS_Manipulator::*)(  const handle<AIS_InteractiveObject> & ,   const AIS_Manipulator::OptionsForAttach &  ) ) static_cast<void (AIS_Manipulator::*)(  const handle<AIS_InteractiveObject> & ,   const AIS_Manipulator::OptionsForAttach &  ) >(&AIS_Manipulator::Attach),
             R"#(Attaches himself to the input interactive object and become displayed in the same context. It is placed in the center of object bounding box, and its size is adjusted to the object bounding box.)#"  , py::arg("theObject"),  py::arg("theOptions")=static_cast< const AIS_Manipulator::OptionsForAttach &>(OptionsForAttach ( ))
          )
        .def("Attach",
             (void (AIS_Manipulator::*)(  const handle<NCollection_HSequence<handle<AIS_InteractiveObject>>> & ,   const AIS_Manipulator::OptionsForAttach &  ) ) static_cast<void (AIS_Manipulator::*)(  const handle<NCollection_HSequence<handle<AIS_InteractiveObject>>> & ,   const AIS_Manipulator::OptionsForAttach &  ) >(&AIS_Manipulator::Attach),
             R"#(Attaches himself to the input interactive object group and become displayed in the same context. It become attached to the first object, baut manage manipulation of the whole group. It is placed in the center of object bounding box, and its size is adjusted to the object bounding box.)#"  , py::arg("theObject"),  py::arg("theOptions")=static_cast< const AIS_Manipulator::OptionsForAttach &>(OptionsForAttach ( ))
          )
        .def("EnableMode",
             (void (AIS_Manipulator::*)(  const AIS_ManipulatorMode  ) ) static_cast<void (AIS_Manipulator::*)(  const AIS_ManipulatorMode  ) >(&AIS_Manipulator::EnableMode),
             R"#(Enable manipualtion mode.)#"  , py::arg("theMode")
          )
        .def("SetModeActivationOnDetection",
             (void (AIS_Manipulator::*)(  const bool  ) ) static_cast<void (AIS_Manipulator::*)(  const bool  ) >(&AIS_Manipulator::SetModeActivationOnDetection),
             R"#(Enables mode activation on detection (highlighting). By default, mode is activated on selection of manipulator part.)#"  , py::arg("theToEnable")
          )
        .def("IsModeActivationOnDetection",
             (bool (AIS_Manipulator::*)() const) static_cast<bool (AIS_Manipulator::*)() const>(&AIS_Manipulator::IsModeActivationOnDetection),
             R"#(Returns true if manual mode activation is enabled.)#" 
          )
        .def("ProcessDragging",
             (bool (AIS_Manipulator::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> & ,   const handle<SelectMgr_EntityOwner> & ,   const NCollection_Vec2<int> & ,   const NCollection_Vec2<int> & ,   const AIS_DragAction  ) ) static_cast<bool (AIS_Manipulator::*)(  const handle<AIS_InteractiveContext> & ,   const handle<V3d_View> & ,   const handle<SelectMgr_EntityOwner> & ,   const NCollection_Vec2<int> & ,   const NCollection_Vec2<int> & ,   const AIS_DragAction  ) >(&AIS_Manipulator::ProcessDragging),
             R"#(Drag object in the viewer.)#"  , py::arg("theCtx"),  py::arg("theView"),  py::arg("theOwner"),  py::arg("theDragFrom"),  py::arg("theDragTo"),  py::arg("theAction")
          )
        .def("StartTransform",
             (void (AIS_Manipulator::*)(  const int ,   const int ,   const handle<V3d_View> &  ) ) static_cast<void (AIS_Manipulator::*)(  const int ,   const int ,   const handle<V3d_View> &  ) >(&AIS_Manipulator::StartTransform),
             R"#(Init start (reference) transformation.)#"  , py::arg("theX"),  py::arg("theY"),  py::arg("theView")
          )
        .def("Transform",
             (void (AIS_Manipulator::*)(  const gp_Trsf &  ) ) static_cast<void (AIS_Manipulator::*)(  const gp_Trsf &  ) >(&AIS_Manipulator::Transform),
             R"#(Apply to the owning objects the input transformation.)#"  , py::arg("aTrsf")
          )
        .def("RecomputeTransformation",
             (void (AIS_Manipulator::*)(  const handle<Graphic3d_Camera> &  ) ) static_cast<void (AIS_Manipulator::*)(  const handle<Graphic3d_Camera> &  ) >(&AIS_Manipulator::RecomputeTransformation),
             R"#(Apply camera transformation to flat skin manipulator)#"  , py::arg("theCamera")
          )
        .def("RecomputeSelection",
             (void (AIS_Manipulator::*)(  const AIS_ManipulatorMode  ) ) static_cast<void (AIS_Manipulator::*)(  const AIS_ManipulatorMode  ) >(&AIS_Manipulator::RecomputeSelection),
             R"#(Recomputes sensitive primitives for the given selection mode.)#"  , py::arg("theMode")
          )
        .def("StopTransform",
             (void (AIS_Manipulator::*)(  const bool  ) ) static_cast<void (AIS_Manipulator::*)(  const bool  ) >(&AIS_Manipulator::StopTransform),
             R"#(Reset start (reference) transformation.)#"  , py::arg("theToApply")=static_cast< const bool>(true)
          )
        .def("Transform",
             (gp_Trsf (AIS_Manipulator::*)(  const int ,   const int ,   const handle<V3d_View> &  ) ) static_cast<gp_Trsf (AIS_Manipulator::*)(  const int ,   const int ,   const handle<V3d_View> &  ) >(&AIS_Manipulator::Transform),
             R"#(Apply transformation made from mouse moving from start position (save on the first Transform() call and reset on DeactivateCurrentMode() call.) to the in/out mouse position (theX, theY))#"  , py::arg("theX"),  py::arg("theY"),  py::arg("theView")
          )
        .def("ObjectTransformation",
             (bool (AIS_Manipulator::*)(  const int ,   const int ,   const handle<V3d_View> & ,  gp_Trsf &  ) ) static_cast<bool (AIS_Manipulator::*)(  const int ,   const int ,   const handle<V3d_View> & ,  gp_Trsf &  ) >(&AIS_Manipulator::ObjectTransformation),
             R"#(Computes transformation of parent object according to the active mode and input motion vector. You can use this method to get object transformation according to current mode or use own algorithm to implement any other transformation for modes.)#"  , py::arg("theX"),  py::arg("theY"),  py::arg("theView"),  py::arg("theTrsf")
          )
        .def("DeactivateCurrentMode",
             (void (AIS_Manipulator::*)() ) static_cast<void (AIS_Manipulator::*)() >(&AIS_Manipulator::DeactivateCurrentMode),
             R"#(Make inactive the current selected manipulator part and reset current axis index and current mode. After its call HasActiveMode() returns false.)#" 
          )
        .def("Detach",
             (void (AIS_Manipulator::*)() ) static_cast<void (AIS_Manipulator::*)() >(&AIS_Manipulator::Detach),
             R"#(Detaches himself from the owner object, and removes itself from context.)#" 
          )
        .def("Objects",
             (handle<NCollection_HSequence<handle<AIS_InteractiveObject>>> (AIS_Manipulator::*)() const) static_cast<handle<NCollection_HSequence<handle<AIS_InteractiveObject>>> (AIS_Manipulator::*)() const>(&AIS_Manipulator::Objects),
             R"#(Returns all owning objects.)#" 
          )
        .def("Object",
             (handle<AIS_InteractiveObject> (AIS_Manipulator::*)() const) static_cast<handle<AIS_InteractiveObject> (AIS_Manipulator::*)() const>(&AIS_Manipulator::Object),
             R"#(Returns the first (leading) object of the owning objects.)#" 
          )
        .def("Object",
             (handle<AIS_InteractiveObject> (AIS_Manipulator::*)(  const int  ) const) static_cast<handle<AIS_InteractiveObject> (AIS_Manipulator::*)(  const int  ) const>(&AIS_Manipulator::Object),
             R"#(Returns one of the owning objects. raises program error if theIndex is more than owning objects count or less than 1.)#"  , py::arg("theIndex")
          )
        .def("IsAttached",
             (bool (AIS_Manipulator::*)() const) static_cast<bool (AIS_Manipulator::*)() const>(&AIS_Manipulator::IsAttached),
             R"#(Returns true if manipulator is attached to some interactive object (has owning object).)#" 
          )
        .def("HasActiveMode",
             (bool (AIS_Manipulator::*)() const) static_cast<bool (AIS_Manipulator::*)() const>(&AIS_Manipulator::HasActiveMode),
             R"#(Returns true if some part of manipulator is selected (transformation mode is active, and owning object can be transformed).)#" 
          )
        .def("HasActiveTransformation",
             (bool (AIS_Manipulator::*)() ) static_cast<bool (AIS_Manipulator::*)() >(&AIS_Manipulator::HasActiveTransformation),
             R"#()#" 
          )
        .def("StartTransformation",
             (gp_Trsf (AIS_Manipulator::*)() const) static_cast<gp_Trsf (AIS_Manipulator::*)() const>(&AIS_Manipulator::StartTransformation),
             R"#()#" 
          )
        .def("StartTransformation",
             (gp_Trsf (AIS_Manipulator::*)( int  ) const) static_cast<gp_Trsf (AIS_Manipulator::*)( int  ) const>(&AIS_Manipulator::StartTransformation),
             R"#()#"  , py::arg("theIndex")
          )
        .def("SetZoomPersistence",
             (void (AIS_Manipulator::*)(  const bool  ) ) static_cast<void (AIS_Manipulator::*)(  const bool  ) >(&AIS_Manipulator::SetZoomPersistence),
             R"#(Enable or disable zoom persistence mode for the manipulator. With this mode turned on the presentation will keep fixed screen size.)#"  , py::arg("theToEnable")
          )
        .def("ZoomPersistence",
             (bool (AIS_Manipulator::*)() const) static_cast<bool (AIS_Manipulator::*)() const>(&AIS_Manipulator::ZoomPersistence),
             R"#(Returns state of zoom persistence mode, whether it turned on or off.)#" 
          )
        .def("SetTransformPersistence",
             (void (AIS_Manipulator::*)(  const handle<Graphic3d_TransformPers> &  ) ) static_cast<void (AIS_Manipulator::*)(  const handle<Graphic3d_TransformPers> &  ) >(&AIS_Manipulator::SetTransformPersistence),
             R"#(Redefines transform persistence management to setup transformation for sub-presentation of axes.)#"  , py::arg("theTrsfPers")
          )
        .def("SkinMode",
             (AIS_Manipulator::ManipulatorSkin (AIS_Manipulator::*)() const) static_cast<AIS_Manipulator::ManipulatorSkin (AIS_Manipulator::*)() const>(&AIS_Manipulator::SkinMode),
             R"#(Returns current manipulator skin mode.)#" 
          )
        .def("SetSkinMode",
             (void (AIS_Manipulator::*)(  const AIS_Manipulator::ManipulatorSkin  ) ) static_cast<void (AIS_Manipulator::*)(  const AIS_Manipulator::ManipulatorSkin  ) >(&AIS_Manipulator::SetSkinMode),
             R"#(Sets skin mode for the manipulator.)#"  , py::arg("theSkinMode")
          )
        .def("ActiveMode",
             (AIS_ManipulatorMode (AIS_Manipulator::*)() const) static_cast<AIS_ManipulatorMode (AIS_Manipulator::*)() const>(&AIS_Manipulator::ActiveMode),
             R"#()#" 
          )
        .def("ActiveAxisIndex",
             (int (AIS_Manipulator::*)() const) static_cast<int (AIS_Manipulator::*)() const>(&AIS_Manipulator::ActiveAxisIndex),
             R"#()#" 
          )
        .def("SetPosition",
             (void (AIS_Manipulator::*)(  const gp_Ax2 &  ) ) static_cast<void (AIS_Manipulator::*)(  const gp_Ax2 &  ) >(&AIS_Manipulator::SetPosition),
             R"#(Sets position of the manipulator object.)#"  , py::arg("thePosition")
          )
        .def("Size",
             (float (AIS_Manipulator::*)() const) static_cast<float (AIS_Manipulator::*)() const>(&AIS_Manipulator::Size),
             R"#()#" 
          )
        .def("SetSize",
             (void (AIS_Manipulator::*)(  const float  ) ) static_cast<void (AIS_Manipulator::*)(  const float  ) >(&AIS_Manipulator::SetSize),
             R"#(Sets size (length of side of the manipulator cubic bounding box.)#"  , py::arg("theSideLength")
          )
        .def("SetGap",
             (void (AIS_Manipulator::*)(  const float  ) ) static_cast<void (AIS_Manipulator::*)(  const float  ) >(&AIS_Manipulator::SetGap),
             R"#(Sets gaps between translator, scaler and rotator sub-presentations.)#"  , py::arg("theValue")
          )
        .def("SetTransformBehavior",
             (void (AIS_Manipulator::*)(  const AIS_Manipulator::BehaviorOnTransform &  ) ) static_cast<void (AIS_Manipulator::*)(  const AIS_Manipulator::BehaviorOnTransform &  ) >(&AIS_Manipulator::SetTransformBehavior),
             R"#(Sets behavior settings for transformation action carried on the manipulator, whether it translates, rotates together with the transformed object or not.)#"  , py::arg("theSettings")
          )
        .def("Compute",
             (void (AIS_Manipulator::*)(  const handle<PrsMgr_PresentationManager> & ,   const handle<Prs3d_Presentation> & ,   const int  ) ) static_cast<void (AIS_Manipulator::*)(  const handle<PrsMgr_PresentationManager> & ,   const handle<Prs3d_Presentation> & ,   const int  ) >(&AIS_Manipulator::Compute),
             R"#(Fills presentation.)#"  , py::arg("thePrsMgr"),  py::arg("thePrs"),  py::arg("theMode")=static_cast< const int>(0)
          )
        .def("ComputeSelection",
             (void (AIS_Manipulator::*)(  const handle<SelectMgr_Selection> & ,   const int  ) ) static_cast<void (AIS_Manipulator::*)(  const handle<SelectMgr_Selection> & ,   const int  ) >(&AIS_Manipulator::ComputeSelection),
             R"#(Computes selection sensitive zones (triangulation) for manipulator.)#"  , py::arg("theSelection"),  py::arg("theMode")
          )
        .def("IsAutoHilight",
             (bool (AIS_Manipulator::*)() const) static_cast<bool (AIS_Manipulator::*)() const>(&AIS_Manipulator::IsAutoHilight),
             R"#(Disables auto highlighting to use HilightSelected() and HilightOwnerWithColor() overridden methods.)#" 
          )
        .def("ClearSelected",
             (void (AIS_Manipulator::*)() ) static_cast<void (AIS_Manipulator::*)() >(&AIS_Manipulator::ClearSelected),
             R"#(Method which clear all selected owners belonging to this selectable object (for fast presentation draw).)#" 
          )
        .def("HilightSelected",
             (void (AIS_Manipulator::*)(  const handle<PrsMgr_PresentationManager> & ,   const NCollection_Sequence<handle<SelectMgr_EntityOwner>> &  ) ) static_cast<void (AIS_Manipulator::*)(  const handle<PrsMgr_PresentationManager> & ,   const NCollection_Sequence<handle<SelectMgr_EntityOwner>> &  ) >(&AIS_Manipulator::HilightSelected),
             R"#(Method which draws selected owners (for fast presentation draw).)#"  , py::arg("thePM"),  py::arg("theSeq")
          )
        .def("HilightOwnerWithColor",
             (void (AIS_Manipulator::*)(  const handle<PrsMgr_PresentationManager> & ,   const handle<Prs3d_Drawer> & ,   const handle<SelectMgr_EntityOwner> &  ) ) static_cast<void (AIS_Manipulator::*)(  const handle<PrsMgr_PresentationManager> & ,   const handle<Prs3d_Drawer> & ,   const handle<SelectMgr_EntityOwner> &  ) >(&AIS_Manipulator::HilightOwnerWithColor),
             R"#(Method which hilight an owner belonging to this selectable object (for fast presentation draw).)#"  , py::arg("thePM"),  py::arg("theStyle"),  py::arg("theOwner")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_Manipulator::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_Manipulator::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Position",
             ( const gp_Ax2 & (AIS_Manipulator::*)() const) static_cast< const gp_Ax2 & (AIS_Manipulator::*)() const>(&AIS_Manipulator::Position),
             R"#(Returns poition of manipulator interactive object.)#"
             
         )
       .def("ChangeTransformBehavior",
             (AIS_Manipulator::BehaviorOnTransform & (AIS_Manipulator::*)() ) static_cast<AIS_Manipulator::BehaviorOnTransform & (AIS_Manipulator::*)() >(&AIS_Manipulator::ChangeTransformBehavior),
             R"#(Returns behavior settings for transformation action of the manipulator.)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("TransformBehavior",
             ( const AIS_Manipulator::BehaviorOnTransform & (AIS_Manipulator::*)() const) static_cast< const AIS_Manipulator::BehaviorOnTransform & (AIS_Manipulator::*)() const>(&AIS_Manipulator::TransformBehavior),
             R"#(Returns behavior settings for transformation action of the manipulator.)#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_Manipulator::*)() const) static_cast< const handle<Standard_Type> & (AIS_Manipulator::*)() const>(&AIS_Manipulator::DynamicType),
             R"#()#"
             
         )
;

    // Class AIS_MediaPlayer from ./opencascade/AIS_MediaPlayer.hxx
    klass = m.attr("AIS_MediaPlayer");


    // nested enums

    static_cast<py::class_<AIS_MediaPlayer ,opencascade::handle<AIS_MediaPlayer>  , AIS_InteractiveObject >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetCallback",
             (void (AIS_MediaPlayer::*)( Graphic3d_MediaTextureSet::CallbackOnUpdate_t ,  void *  ) ) static_cast<void (AIS_MediaPlayer::*)( Graphic3d_MediaTextureSet::CallbackOnUpdate_t ,  void *  ) >(&AIS_MediaPlayer::SetCallback),
             R"#(Setup callback to be called on queue progress (e.g. when new frame should be displayed).)#"  , py::arg("theCallbackFunction"),  py::arg("theCallbackUserPtr")
          )
        .def("OpenInput",
             (void (AIS_MediaPlayer::*)(  const TCollection_AsciiString & ,  bool  ) ) static_cast<void (AIS_MediaPlayer::*)(  const TCollection_AsciiString & ,  bool  ) >(&AIS_MediaPlayer::OpenInput),
             R"#(Open specified file.)#"  , py::arg("thePath"),  py::arg("theToWait")
          )
        .def("PresentFrame",
             (bool (AIS_MediaPlayer::*)(  const NCollection_Vec2<int> & ,   const NCollection_Vec2<int> &  ) ) static_cast<bool (AIS_MediaPlayer::*)(  const NCollection_Vec2<int> & ,   const NCollection_Vec2<int> &  ) >(&AIS_MediaPlayer::PresentFrame),
             R"#(Display new frame.)#"  , py::arg("theLeftCorner"),  py::arg("theMaxSize")
          )
        .def("PlayPause",
             (void (AIS_MediaPlayer::*)() ) static_cast<void (AIS_MediaPlayer::*)() >(&AIS_MediaPlayer::PlayPause),
             R"#(Switch playback state.)#" 
          )
        .def("SetClosePlayer",
             (void (AIS_MediaPlayer::*)() ) static_cast<void (AIS_MediaPlayer::*)() >(&AIS_MediaPlayer::SetClosePlayer),
             R"#(Schedule player to be closed.)#" 
          )
        .def("Duration",
             (double (AIS_MediaPlayer::*)() const) static_cast<double (AIS_MediaPlayer::*)() const>(&AIS_MediaPlayer::Duration),
             R"#(Return duration.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_MediaPlayer::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_MediaPlayer::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_MediaPlayer::*)() const) static_cast< const handle<Standard_Type> & (AIS_MediaPlayer::*)() const>(&AIS_MediaPlayer::DynamicType),
             R"#()#"
             
         )
       .def("PlayerContext",
             ( const handle<Media_PlayerContext> & (AIS_MediaPlayer::*)() const) static_cast< const handle<Media_PlayerContext> & (AIS_MediaPlayer::*)() const>(&AIS_MediaPlayer::PlayerContext),
             R"#(Return player context.)#"
             
         )
;

    // Class AIS_MultipleConnectedInteractive from ./opencascade/AIS_MultipleConnectedInteractive.hxx
    klass = m.attr("AIS_MultipleConnectedInteractive");


    // nested enums

    static_cast<py::class_<AIS_MultipleConnectedInteractive ,opencascade::handle<AIS_MultipleConnectedInteractive>  , AIS_InteractiveObject >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Connect",
             (handle<AIS_InteractiveObject> (AIS_MultipleConnectedInteractive::*)(  const handle<AIS_InteractiveObject> & ,   const handle<TopLoc_Datum3D> & ,   const handle<Graphic3d_TransformPers> &  ) ) static_cast<handle<AIS_InteractiveObject> (AIS_MultipleConnectedInteractive::*)(  const handle<AIS_InteractiveObject> & ,   const handle<TopLoc_Datum3D> & ,   const handle<Graphic3d_TransformPers> &  ) >(&AIS_MultipleConnectedInteractive::Connect),
             R"#(Establishes the connection between the Connected Interactive Object, theInteractive, and its reference. Locates instance in theLocation and applies specified transformation persistence mode.)#"  , py::arg("theAnotherObj"),  py::arg("theLocation"),  py::arg("theTrsfPers")
          )
        .def("Type",
             (AIS_KindOfInteractive (AIS_MultipleConnectedInteractive::*)() const) static_cast<AIS_KindOfInteractive (AIS_MultipleConnectedInteractive::*)() const>(&AIS_MultipleConnectedInteractive::Type),
             R"#()#" 
          )
        .def("Signature",
             (int (AIS_MultipleConnectedInteractive::*)() const) static_cast<int (AIS_MultipleConnectedInteractive::*)() const>(&AIS_MultipleConnectedInteractive::Signature),
             R"#()#" 
          )
        .def("HasConnection",
             (bool (AIS_MultipleConnectedInteractive::*)() const) static_cast<bool (AIS_MultipleConnectedInteractive::*)() const>(&AIS_MultipleConnectedInteractive::HasConnection),
             R"#(Returns true if the object is connected to others.)#" 
          )
        .def("Disconnect",
             (void (AIS_MultipleConnectedInteractive::*)(  const handle<AIS_InteractiveObject> &  ) ) static_cast<void (AIS_MultipleConnectedInteractive::*)(  const handle<AIS_InteractiveObject> &  ) >(&AIS_MultipleConnectedInteractive::Disconnect),
             R"#(Removes the connection with theInteractive.)#"  , py::arg("theInteractive")
          )
        .def("DisconnectAll",
             (void (AIS_MultipleConnectedInteractive::*)() ) static_cast<void (AIS_MultipleConnectedInteractive::*)() >(&AIS_MultipleConnectedInteractive::DisconnectAll),
             R"#(Clears all the connections to objects.)#" 
          )
        .def("AcceptShapeDecomposition",
             (bool (AIS_MultipleConnectedInteractive::*)() const) static_cast<bool (AIS_MultipleConnectedInteractive::*)() const>(&AIS_MultipleConnectedInteractive::AcceptShapeDecomposition),
             R"#(Informs the graphic context that the interactive Object may be decomposed into sub-shapes for dynamic selection.)#" 
          )
        .def("GlobalSelOwner",
             (handle<SelectMgr_EntityOwner> (AIS_MultipleConnectedInteractive::*)() const) static_cast<handle<SelectMgr_EntityOwner> (AIS_MultipleConnectedInteractive::*)() const>(&AIS_MultipleConnectedInteractive::GlobalSelOwner),
             R"#(Returns the owner of mode for selection of object as a whole)#" 
          )
        .def("SetContext",
             (void (AIS_MultipleConnectedInteractive::*)(  const handle<AIS_InteractiveContext> &  ) ) static_cast<void (AIS_MultipleConnectedInteractive::*)(  const handle<AIS_InteractiveContext> &  ) >(&AIS_MultipleConnectedInteractive::SetContext),
             R"#(Assigns interactive context.)#"  , py::arg("theCtx")
          )
        .def("Connect",
             (handle<AIS_InteractiveObject> (AIS_MultipleConnectedInteractive::*)(  const handle<AIS_InteractiveObject> &  ) ) static_cast<handle<AIS_InteractiveObject> (AIS_MultipleConnectedInteractive::*)(  const handle<AIS_InteractiveObject> &  ) >(&AIS_MultipleConnectedInteractive::Connect),
             R"#(Establishes the connection between the Connected Interactive Object, theInteractive, and its reference. Copies local transformation and transformation persistence mode from theInteractive.)#"  , py::arg("theAnotherObj")
          )
        .def("Connect",
             (handle<AIS_InteractiveObject> (AIS_MultipleConnectedInteractive::*)(  const handle<AIS_InteractiveObject> & ,   const gp_Trsf &  ) ) static_cast<handle<AIS_InteractiveObject> (AIS_MultipleConnectedInteractive::*)(  const handle<AIS_InteractiveObject> & ,   const gp_Trsf &  ) >(&AIS_MultipleConnectedInteractive::Connect),
             R"#(Establishes the connection between the Connected Interactive Object, theInteractive, and its reference. Locates instance in theLocation and copies transformation persistence mode from theInteractive.)#"  , py::arg("theAnotherObj"),  py::arg("theLocation")
          )
        .def("Connect",
             (handle<AIS_InteractiveObject> (AIS_MultipleConnectedInteractive::*)(  const handle<AIS_InteractiveObject> & ,   const gp_Trsf & ,   const handle<Graphic3d_TransformPers> &  ) ) static_cast<handle<AIS_InteractiveObject> (AIS_MultipleConnectedInteractive::*)(  const handle<AIS_InteractiveObject> & ,   const gp_Trsf & ,   const handle<Graphic3d_TransformPers> &  ) >(&AIS_MultipleConnectedInteractive::Connect),
             R"#(Establishes the connection between the Connected Interactive Object, theInteractive, and its reference. Locates instance in theLocation and applies specified transformation persistence mode.)#"  , py::arg("theAnotherObj"),  py::arg("theLocation"),  py::arg("theTrsfPers")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_MultipleConnectedInteractive::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_MultipleConnectedInteractive::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_MultipleConnectedInteractive::*)() const) static_cast< const handle<Standard_Type> & (AIS_MultipleConnectedInteractive::*)() const>(&AIS_MultipleConnectedInteractive::DynamicType),
             R"#()#"
             
         )
       .def("GetAssemblyOwner",
             ( const handle<SelectMgr_EntityOwner> & (AIS_MultipleConnectedInteractive::*)() const) static_cast< const handle<SelectMgr_EntityOwner> & (AIS_MultipleConnectedInteractive::*)() const>(&AIS_MultipleConnectedInteractive::GetAssemblyOwner),
             R"#(Returns common entity owner if the object is an assembly)#"
             
         )
;

    // Class AIS_Plane from ./opencascade/AIS_Plane.hxx
    klass = m.attr("AIS_Plane");


    // nested enums

    static_cast<py::class_<AIS_Plane ,opencascade::handle<AIS_Plane>  , AIS_InteractiveObject >>(klass)
    // constructors
        .def(py::init<  const handle<Geom_Axis2Placement> &, const AIS_TypeOfPlane, const bool >()  , py::arg("aComponent"),  py::arg("aPlaneType"),  py::arg("aCurrentMode")=static_cast< const bool>(false) )
        .def(py::init<  const handle<Geom_Plane> &, const bool >()  , py::arg("aComponent"),  py::arg("aCurrentMode")=static_cast< const bool>(false) )
        .def(py::init<  const handle<Geom_Plane> &, const gp_Pnt &, const bool >()  , py::arg("aComponent"),  py::arg("aCenter"),  py::arg("aCurrentMode")=static_cast< const bool>(false) )
        .def(py::init<  const handle<Geom_Plane> &, const gp_Pnt &, const gp_Pnt &, const gp_Pnt &, const bool >()  , py::arg("aComponent"),  py::arg("aCenter"),  py::arg("aPmin"),  py::arg("aPmax"),  py::arg("aCurrentMode")=static_cast< const bool>(false) )
    // custom constructors
    // methods
        .def("SetSize",
             (void (AIS_Plane::*)(  const double  ) ) static_cast<void (AIS_Plane::*)(  const double  ) >(&AIS_Plane::SetSize),
             R"#(Same value for x and y directions)#"  , py::arg("aValue")
          )
        .def("SetSize",
             (void (AIS_Plane::*)(  const double ,   const double  ) ) static_cast<void (AIS_Plane::*)(  const double ,   const double  ) >(&AIS_Plane::SetSize),
             R"#(Sets the size defined by the length along the X axis XVal and the length along the Y axis YVal.)#"  , py::arg("Xval"),  py::arg("YVal")
          )
        .def("UnsetSize",
             (void (AIS_Plane::*)() ) static_cast<void (AIS_Plane::*)() >(&AIS_Plane::UnsetSize),
             R"#()#" 
          )
        .def("Size",
             (bool (AIS_Plane::*)( double & ,  double &  ) const) static_cast<bool (AIS_Plane::*)( double & ,  double &  ) const>(&AIS_Plane::Size),
             R"#()#"  , py::arg("X"),  py::arg("Y")
          )
        .def("HasOwnSize",
             (bool (AIS_Plane::*)() const) static_cast<bool (AIS_Plane::*)() const>(&AIS_Plane::HasOwnSize),
             R"#()#" 
          )
        .def("SetMinimumSize",
             (void (AIS_Plane::*)(  const double  ) ) static_cast<void (AIS_Plane::*)(  const double  ) >(&AIS_Plane::SetMinimumSize),
             R"#(Sets transform persistence for zoom with value of minimum size)#"  , py::arg("theValue")
          )
        .def("UnsetMinimumSize",
             (void (AIS_Plane::*)() ) static_cast<void (AIS_Plane::*)() >(&AIS_Plane::UnsetMinimumSize),
             R"#(Unsets transform persistence zoom)#" 
          )
        .def("HasMinimumSize",
             (bool (AIS_Plane::*)() const) static_cast<bool (AIS_Plane::*)() const>(&AIS_Plane::HasMinimumSize),
             R"#(Returns true if transform persistence for zoom is set)#" 
          )
        .def("Signature",
             (int (AIS_Plane::*)() const) static_cast<int (AIS_Plane::*)() const>(&AIS_Plane::Signature),
             R"#()#" 
          )
        .def("Type",
             (AIS_KindOfInteractive (AIS_Plane::*)() const) static_cast<AIS_KindOfInteractive (AIS_Plane::*)() const>(&AIS_Plane::Type),
             R"#()#" 
          )
        .def("SetComponent",
             (void (AIS_Plane::*)(  const handle<Geom_Plane> &  ) ) static_cast<void (AIS_Plane::*)(  const handle<Geom_Plane> &  ) >(&AIS_Plane::SetComponent),
             R"#(Creates an instance of the plane aComponent.)#"  , py::arg("aComponent")
          )
        .def("PlaneAttributes",
             (bool (AIS_Plane::*)( handle<Geom_Plane> & ,  gp_Pnt & ,  gp_Pnt & ,  gp_Pnt &  ) ) static_cast<bool (AIS_Plane::*)( handle<Geom_Plane> & ,  gp_Pnt & ,  gp_Pnt & ,  gp_Pnt &  ) >(&AIS_Plane::PlaneAttributes),
             R"#(Returns the settings for the selected plane aComponent, provided in SetPlaneAttributes. These include the points aCenter, aPmin, and aPmax)#"  , py::arg("aComponent"),  py::arg("aCenter"),  py::arg("aPmin"),  py::arg("aPmax")
          )
        .def("SetPlaneAttributes",
             (void (AIS_Plane::*)(  const handle<Geom_Plane> & ,   const gp_Pnt & ,   const gp_Pnt & ,   const gp_Pnt &  ) ) static_cast<void (AIS_Plane::*)(  const handle<Geom_Plane> & ,   const gp_Pnt & ,   const gp_Pnt & ,   const gp_Pnt &  ) >(&AIS_Plane::SetPlaneAttributes),
             R"#(Allows you to provide settings other than default ones for the selected plane. These include: center point aCenter, maximum aPmax and minimum aPmin.)#"  , py::arg("aComponent"),  py::arg("aCenter"),  py::arg("aPmin"),  py::arg("aPmax")
          )
        .def("SetCenter",
             (void (AIS_Plane::*)(  const gp_Pnt &  ) ) static_cast<void (AIS_Plane::*)(  const gp_Pnt &  ) >(&AIS_Plane::SetCenter),
             R"#(Provides settings for the center theCenter other than (0, 0, 0).)#"  , py::arg("theCenter")
          )
        .def("SetAxis2Placement",
             (void (AIS_Plane::*)(  const handle<Geom_Axis2Placement> & ,   const AIS_TypeOfPlane  ) ) static_cast<void (AIS_Plane::*)(  const handle<Geom_Axis2Placement> & ,   const AIS_TypeOfPlane  ) >(&AIS_Plane::SetAxis2Placement),
             R"#(Allows you to provide settings for the position and direction of one of the plane's axes, aComponent, in 3D space. The coordinate system used is right-handed, and the type of plane aPlaneType is one of: - AIS_ TOPL_Unknown - AIS_ TOPL_XYPlane - AIS_ TOPL_XZPlane - AIS_ TOPL_YZPlane}.)#"  , py::arg("aComponent"),  py::arg("aPlaneType")
          )
        .def("Axis2Placement",
             (handle<Geom_Axis2Placement> (AIS_Plane::*)() ) static_cast<handle<Geom_Axis2Placement> (AIS_Plane::*)() >(&AIS_Plane::Axis2Placement),
             R"#(Returns the position of the plane's axis2 system identifying the x, y, or z axis and giving the plane a direction in 3D space. An axis2 system is a right-handed coordinate system.)#" 
          )
        .def("TypeOfPlane",
             (AIS_TypeOfPlane (AIS_Plane::*)() ) static_cast<AIS_TypeOfPlane (AIS_Plane::*)() >(&AIS_Plane::TypeOfPlane),
             R"#(Returns the type of plane - xy, yz, xz or unknown.)#" 
          )
        .def("IsXYZPlane",
             (bool (AIS_Plane::*)() ) static_cast<bool (AIS_Plane::*)() >(&AIS_Plane::IsXYZPlane),
             R"#(Returns the type of plane - xy, yz, or xz.)#" 
          )
        .def("CurrentMode",
             (bool (AIS_Plane::*)() ) static_cast<bool (AIS_Plane::*)() >(&AIS_Plane::CurrentMode),
             R"#(Returns the non-default current display mode set by SetCurrentMode.)#" 
          )
        .def("SetCurrentMode",
             (void (AIS_Plane::*)(  const bool  ) ) static_cast<void (AIS_Plane::*)(  const bool  ) >(&AIS_Plane::SetCurrentMode),
             R"#(Allows you to provide settings for a non-default current display mode.)#"  , py::arg("theCurrentMode")
          )
        .def("AcceptDisplayMode",
             (bool (AIS_Plane::*)(  const int  ) const) static_cast<bool (AIS_Plane::*)(  const int  ) const>(&AIS_Plane::AcceptDisplayMode),
             R"#(Returns true if the display mode selected, aMode, is valid for planes.)#"  , py::arg("aMode")
          )
        .def("SetContext",
             (void (AIS_Plane::*)(  const handle<AIS_InteractiveContext> &  ) ) static_cast<void (AIS_Plane::*)(  const handle<AIS_InteractiveContext> &  ) >(&AIS_Plane::SetContext),
             R"#(connection to <aCtx> default drawer implies a recomputation of Frame values.)#"  , py::arg("aCtx")
          )
        .def("ComputeSelection",
             (void (AIS_Plane::*)(  const handle<SelectMgr_Selection> & ,   const int  ) ) static_cast<void (AIS_Plane::*)(  const handle<SelectMgr_Selection> & ,   const int  ) >(&AIS_Plane::ComputeSelection),
             R"#()#"  , py::arg("theSelection"),  py::arg("theMode")
          )
        .def("SetColor",
             (void (AIS_Plane::*)(  const Quantity_Color &  ) ) static_cast<void (AIS_Plane::*)(  const Quantity_Color &  ) >(&AIS_Plane::SetColor),
             R"#()#"  , py::arg("aColor")
          )
        .def("UnsetColor",
             (void (AIS_Plane::*)() ) static_cast<void (AIS_Plane::*)() >(&AIS_Plane::UnsetColor),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_Plane::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_Plane::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_Plane::*)() const) static_cast< const handle<Standard_Type> & (AIS_Plane::*)() const>(&AIS_Plane::DynamicType),
             R"#()#"
             
         )
       .def("Component",
             ( const handle<Geom_Plane> & (AIS_Plane::*)() ) static_cast< const handle<Geom_Plane> & (AIS_Plane::*)() >(&AIS_Plane::Component),
             R"#(Returns the component specified in SetComponent.)#"
             
         )
       .def("Center",
             ( const gp_Pnt & (AIS_Plane::*)() const) static_cast< const gp_Pnt & (AIS_Plane::*)() const>(&AIS_Plane::Center),
             R"#(Returns the coordinates of the center point.)#"
             
         )
;

    // Class AIS_PlaneTrihedron from ./opencascade/AIS_PlaneTrihedron.hxx
    klass = m.attr("AIS_PlaneTrihedron");


    // nested enums

    static_cast<py::class_<AIS_PlaneTrihedron ,opencascade::handle<AIS_PlaneTrihedron>  , AIS_InteractiveObject >>(klass)
    // constructors
        .def(py::init<  const handle<Geom_Plane> & >()  , py::arg("aPlane") )
    // custom constructors
    // methods
        .def("Component",
             (handle<Geom_Plane> (AIS_PlaneTrihedron::*)() ) static_cast<handle<Geom_Plane> (AIS_PlaneTrihedron::*)() >(&AIS_PlaneTrihedron::Component),
             R"#(Returns the component specified in SetComponent.)#" 
          )
        .def("SetComponent",
             (void (AIS_PlaneTrihedron::*)(  const handle<Geom_Plane> &  ) ) static_cast<void (AIS_PlaneTrihedron::*)(  const handle<Geom_Plane> &  ) >(&AIS_PlaneTrihedron::SetComponent),
             R"#(Creates an instance of the component object aPlane.)#"  , py::arg("aPlane")
          )
        .def("XAxis",
             (handle<AIS_Line> (AIS_PlaneTrihedron::*)() const) static_cast<handle<AIS_Line> (AIS_PlaneTrihedron::*)() const>(&AIS_PlaneTrihedron::XAxis),
             R"#(Returns the "XAxis".)#" 
          )
        .def("YAxis",
             (handle<AIS_Line> (AIS_PlaneTrihedron::*)() const) static_cast<handle<AIS_Line> (AIS_PlaneTrihedron::*)() const>(&AIS_PlaneTrihedron::YAxis),
             R"#(Returns the "YAxis".)#" 
          )
        .def("Position",
             (handle<AIS_Point> (AIS_PlaneTrihedron::*)() const) static_cast<handle<AIS_Point> (AIS_PlaneTrihedron::*)() const>(&AIS_PlaneTrihedron::Position),
             R"#(Returns the point of origin of the plane trihedron.)#" 
          )
        .def("SetLength",
             (void (AIS_PlaneTrihedron::*)(  const double  ) ) static_cast<void (AIS_PlaneTrihedron::*)(  const double  ) >(&AIS_PlaneTrihedron::SetLength),
             R"#(Sets the length of the X and Y axes.)#"  , py::arg("theLength")
          )
        .def("GetLength",
             (double (AIS_PlaneTrihedron::*)() const) static_cast<double (AIS_PlaneTrihedron::*)() const>(&AIS_PlaneTrihedron::GetLength),
             R"#(Returns the length of X and Y axes.)#" 
          )
        .def("AcceptDisplayMode",
             (bool (AIS_PlaneTrihedron::*)(  const int  ) const) static_cast<bool (AIS_PlaneTrihedron::*)(  const int  ) const>(&AIS_PlaneTrihedron::AcceptDisplayMode),
             R"#(Returns true if the display mode selected, aMode, is valid.)#"  , py::arg("aMode")
          )
        .def("Signature",
             (int (AIS_PlaneTrihedron::*)() const) static_cast<int (AIS_PlaneTrihedron::*)() const>(&AIS_PlaneTrihedron::Signature),
             R"#()#" 
          )
        .def("Type",
             (AIS_KindOfInteractive (AIS_PlaneTrihedron::*)() const) static_cast<AIS_KindOfInteractive (AIS_PlaneTrihedron::*)() const>(&AIS_PlaneTrihedron::Type),
             R"#(Returns datum as the type of Interactive Object.)#" 
          )
        .def("SetColor",
             (void (AIS_PlaneTrihedron::*)(  const Quantity_Color &  ) ) static_cast<void (AIS_PlaneTrihedron::*)(  const Quantity_Color &  ) >(&AIS_PlaneTrihedron::SetColor),
             R"#(Allows you to provide settings for the color aColor.)#"  , py::arg("theColor")
          )
        .def("SetXLabel",
             (void (AIS_PlaneTrihedron::*)(  const TCollection_AsciiString &  ) ) static_cast<void (AIS_PlaneTrihedron::*)(  const TCollection_AsciiString &  ) >(&AIS_PlaneTrihedron::SetXLabel),
             R"#()#"  , py::arg("theLabel")
          )
        .def("SetYLabel",
             (void (AIS_PlaneTrihedron::*)(  const TCollection_AsciiString &  ) ) static_cast<void (AIS_PlaneTrihedron::*)(  const TCollection_AsciiString &  ) >(&AIS_PlaneTrihedron::SetYLabel),
             R"#()#"  , py::arg("theLabel")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_PlaneTrihedron::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_PlaneTrihedron::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_PlaneTrihedron::*)() const) static_cast< const handle<Standard_Type> & (AIS_PlaneTrihedron::*)() const>(&AIS_PlaneTrihedron::DynamicType),
             R"#()#"
             
         )
;

    // Class AIS_Point from ./opencascade/AIS_Point.hxx
    klass = m.attr("AIS_Point");


    // nested enums

    static_cast<py::class_<AIS_Point ,opencascade::handle<AIS_Point>  , AIS_InteractiveObject >>(klass)
    // constructors
        .def(py::init<  const handle<Geom_Point> & >()  , py::arg("aComponent") )
    // custom constructors
    // methods
        .def("Signature",
             (int (AIS_Point::*)() const) static_cast<int (AIS_Point::*)() const>(&AIS_Point::Signature),
             R"#(Returns index 1, the default index for a point.)#" 
          )
        .def("Type",
             (AIS_KindOfInteractive (AIS_Point::*)() const) static_cast<AIS_KindOfInteractive (AIS_Point::*)() const>(&AIS_Point::Type),
             R"#(Indicates that a point is a datum.)#" 
          )
        .def("Component",
             (handle<Geom_Point> (AIS_Point::*)() ) static_cast<handle<Geom_Point> (AIS_Point::*)() >(&AIS_Point::Component),
             R"#(Returns the component specified in SetComponent.)#" 
          )
        .def("SetComponent",
             (void (AIS_Point::*)(  const handle<Geom_Point> &  ) ) static_cast<void (AIS_Point::*)(  const handle<Geom_Point> &  ) >(&AIS_Point::SetComponent),
             R"#(Constructs an instance of the point aComponent.)#"  , py::arg("aComponent")
          )
        .def("AcceptDisplayMode",
             (bool (AIS_Point::*)(  const int  ) const) static_cast<bool (AIS_Point::*)(  const int  ) const>(&AIS_Point::AcceptDisplayMode),
             R"#(Returns true if the display mode selected is valid for point datums.)#"  , py::arg("aMode")
          )
        .def("SetColor",
             (void (AIS_Point::*)(  const Quantity_Color &  ) ) static_cast<void (AIS_Point::*)(  const Quantity_Color &  ) >(&AIS_Point::SetColor),
             R"#(Allows you to provide settings for the Color.)#"  , py::arg("theColor")
          )
        .def("UnsetColor",
             (void (AIS_Point::*)() ) static_cast<void (AIS_Point::*)() >(&AIS_Point::UnsetColor),
             R"#(Allows you to remove color settings.)#" 
          )
        .def("SetMarker",
             (void (AIS_Point::*)(  const Aspect_TypeOfMarker  ) ) static_cast<void (AIS_Point::*)(  const Aspect_TypeOfMarker  ) >(&AIS_Point::SetMarker),
             R"#(Allows you to provide settings for a marker. These include - type of marker, - marker color, - scale factor.)#"  , py::arg("aType")
          )
        .def("UnsetMarker",
             (void (AIS_Point::*)() ) static_cast<void (AIS_Point::*)() >(&AIS_Point::UnsetMarker),
             R"#(Removes the marker settings.)#" 
          )
        .def("HasMarker",
             (bool (AIS_Point::*)() const) static_cast<bool (AIS_Point::*)() const>(&AIS_Point::HasMarker),
             R"#(Returns true if the point datum has a marker.)#" 
          )
        .def("Vertex",
             (TopoDS_Vertex (AIS_Point::*)() const) static_cast<TopoDS_Vertex (AIS_Point::*)() const>(&AIS_Point::Vertex),
             R"#(Converts a point into a vertex.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_Point::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_Point::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_Point::*)() const) static_cast< const handle<Standard_Type> & (AIS_Point::*)() const>(&AIS_Point::DynamicType),
             R"#()#"
             
         )
;

    // Class AIS_PointCloud from ./opencascade/AIS_PointCloud.hxx
    klass = m.attr("AIS_PointCloud");


    // nested enums
        py::enum_<AIS_PointCloud::DisplayMode>(klass, "DisplayMode_e", R"#(Display modes supported by this Point Cloud object)#")
            .value("DM_Points", AIS_PointCloud::DisplayMode::DM_Points)
            .value("DM_BndBox", AIS_PointCloud::DisplayMode::DM_BndBox);
        py::enum_<AIS_PointCloud::SelectionMode>(klass, "SelectionMode_e", R"#(Selection modes supported by this Point Cloud object)#")
            .value("SM_Points", AIS_PointCloud::SelectionMode::SM_Points)
            .value("SM_SubsetOfPoints", AIS_PointCloud::SelectionMode::SM_SubsetOfPoints)
            .value("SM_BndBox", AIS_PointCloud::SelectionMode::SM_BndBox);

    static_cast<py::class_<AIS_PointCloud ,opencascade::handle<AIS_PointCloud>  , AIS_InteractiveObject >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetPoints",
             (void (AIS_PointCloud::*)(  const handle<Graphic3d_ArrayOfPoints> &  ) ) static_cast<void (AIS_PointCloud::*)(  const handle<Graphic3d_ArrayOfPoints> &  ) >(&AIS_PointCloud::SetPoints),
             R"#(Sets the points from array of points. Method will not copy the input data - array will be stored as handle.)#"  , py::arg("thePoints")
          )
        .def("SetPoints",
             (void (AIS_PointCloud::*)(  const handle<NCollection_HArray1<gp_Pnt>> & ,   const handle<NCollection_HArray1<Quantity_Color>> & ,   const handle<NCollection_HArray1<gp_Dir>> &  ) ) static_cast<void (AIS_PointCloud::*)(  const handle<NCollection_HArray1<gp_Pnt>> & ,   const handle<NCollection_HArray1<Quantity_Color>> & ,   const handle<NCollection_HArray1<gp_Dir>> &  ) >(&AIS_PointCloud::SetPoints),
             R"#(Sets the points with optional colors. The input data will be copied into internal buffer. The input arrays should have equal length, otherwise the presentation will not be computed and displayed.)#"  , py::arg("theCoords"),  py::arg("theColors")=static_cast< const handle<NCollection_HArray1<Quantity_Color>> &>(nullptr),  py::arg("theNormals")=static_cast< const handle<NCollection_HArray1<gp_Dir>> &>(nullptr)
          )
        .def("GetPoints",
             ( const handle<Graphic3d_ArrayOfPoints> (AIS_PointCloud::*)() const) static_cast< const handle<Graphic3d_ArrayOfPoints> (AIS_PointCloud::*)() const>(&AIS_PointCloud::GetPoints),
             R"#(Get the points array. Method might be overridden to fill in points array dynamically from application data structures.)#" 
          )
        .def("GetBoundingBox",
             (Bnd_Box (AIS_PointCloud::*)() const) static_cast<Bnd_Box (AIS_PointCloud::*)() const>(&AIS_PointCloud::GetBoundingBox),
             R"#(Get bounding box for presentation.)#" 
          )
        .def("SetColor",
             (void (AIS_PointCloud::*)(  const Quantity_Color &  ) ) static_cast<void (AIS_PointCloud::*)(  const Quantity_Color &  ) >(&AIS_PointCloud::SetColor),
             R"#(Setup custom color. Affects presentation only when no per-point color attribute has been assigned.)#"  , py::arg("theColor")
          )
        .def("UnsetColor",
             (void (AIS_PointCloud::*)() ) static_cast<void (AIS_PointCloud::*)() >(&AIS_PointCloud::UnsetColor),
             R"#(Restore default color.)#" 
          )
        .def("SetMaterial",
             (void (AIS_PointCloud::*)(  const Graphic3d_MaterialAspect &  ) ) static_cast<void (AIS_PointCloud::*)(  const Graphic3d_MaterialAspect &  ) >(&AIS_PointCloud::SetMaterial),
             R"#(Setup custom material. Affects presentation only when normals are defined.)#"  , py::arg("theMat")
          )
        .def("UnsetMaterial",
             (void (AIS_PointCloud::*)() ) static_cast<void (AIS_PointCloud::*)() >(&AIS_PointCloud::UnsetMaterial),
             R"#(Restore default material.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_PointCloud::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_PointCloud::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_PointCloud::*)() const) static_cast< const handle<Standard_Type> & (AIS_PointCloud::*)() const>(&AIS_PointCloud::DynamicType),
             R"#()#"
             
         )
;

    // Class AIS_RubberBand from ./opencascade/AIS_RubberBand.hxx
    klass = m.attr("AIS_RubberBand");


    // nested enums

    static_cast<py::class_<AIS_RubberBand ,opencascade::handle<AIS_RubberBand>  , AIS_InteractiveObject >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const Quantity_Color &, const Aspect_TypeOfLine, const Quantity_Color, const double, const double, const bool >()  , py::arg("theLineColor"),  py::arg("theType"),  py::arg("theFillColor"),  py::arg("theTransparency")=static_cast< const double>(1.0),  py::arg("theLineWidth")=static_cast< const double>(1.0),  py::arg("theIsPolygonClosed")=static_cast< const bool>(true) )
        .def(py::init<  const Quantity_Color &, const Aspect_TypeOfLine, const double, const bool >()  , py::arg("theLineColor"),  py::arg("theType"),  py::arg("theLineWidth")=static_cast< const double>(1.0),  py::arg("theIsPolygonClosed")=static_cast< const bool>(true) )
    // custom constructors
    // methods
        .def("SetRectangle",
             (void (AIS_RubberBand::*)(  const int ,   const int ,   const int ,   const int  ) ) static_cast<void (AIS_RubberBand::*)(  const int ,   const int ,   const int ,   const int  ) >(&AIS_RubberBand::SetRectangle),
             R"#(Sets rectangle bounds.)#"  , py::arg("theMinX"),  py::arg("theMinY"),  py::arg("theMaxX"),  py::arg("theMaxY")
          )
        .def("AddPoint",
             (void (AIS_RubberBand::*)(  const NCollection_Vec2<int> &  ) ) static_cast<void (AIS_RubberBand::*)(  const NCollection_Vec2<int> &  ) >(&AIS_RubberBand::AddPoint),
             R"#(Adds last point to the list of points. They are used to build polygon for rubber band.)#"  , py::arg("thePoint")
          )
        .def("RemoveLastPoint",
             (void (AIS_RubberBand::*)() ) static_cast<void (AIS_RubberBand::*)() >(&AIS_RubberBand::RemoveLastPoint),
             R"#(Remove last point from the list of points for the rubber band polygon.)#" 
          )
        .def("ClearPoints",
             (void (AIS_RubberBand::*)() ) static_cast<void (AIS_RubberBand::*)() >(&AIS_RubberBand::ClearPoints),
             R"#(Remove all points for the rubber band polygon.)#" 
          )
        .def("LineColor",
             (Quantity_Color (AIS_RubberBand::*)() const) static_cast<Quantity_Color (AIS_RubberBand::*)() const>(&AIS_RubberBand::LineColor),
             R"#(Returns the Color attributes.)#" 
          )
        .def("SetLineColor",
             (void (AIS_RubberBand::*)(  const Quantity_Color &  ) ) static_cast<void (AIS_RubberBand::*)(  const Quantity_Color &  ) >(&AIS_RubberBand::SetLineColor),
             R"#(Sets color of lines for rubber band presentation.)#"  , py::arg("theColor")
          )
        .def("FillColor",
             (Quantity_Color (AIS_RubberBand::*)() const) static_cast<Quantity_Color (AIS_RubberBand::*)() const>(&AIS_RubberBand::FillColor),
             R"#(Returns the color of rubber band filling.)#" 
          )
        .def("SetFillColor",
             (void (AIS_RubberBand::*)(  const Quantity_Color &  ) ) static_cast<void (AIS_RubberBand::*)(  const Quantity_Color &  ) >(&AIS_RubberBand::SetFillColor),
             R"#(Sets color of rubber band filling.)#"  , py::arg("theColor")
          )
        .def("SetLineWidth",
             (void (AIS_RubberBand::*)(  const double  ) const) static_cast<void (AIS_RubberBand::*)(  const double  ) const>(&AIS_RubberBand::SetLineWidth),
             R"#(Sets width of line for rubber band presentation.)#"  , py::arg("theWidth")
          )
        .def("LineWidth",
             (double (AIS_RubberBand::*)() const) static_cast<double (AIS_RubberBand::*)() const>(&AIS_RubberBand::LineWidth),
             R"#(Returns width of lines.)#" 
          )
        .def("SetLineType",
             (void (AIS_RubberBand::*)(  const Aspect_TypeOfLine  ) ) static_cast<void (AIS_RubberBand::*)(  const Aspect_TypeOfLine  ) >(&AIS_RubberBand::SetLineType),
             R"#(Sets type of line for rubber band presentation.)#"  , py::arg("theType")
          )
        .def("LineType",
             (Aspect_TypeOfLine (AIS_RubberBand::*)() const) static_cast<Aspect_TypeOfLine (AIS_RubberBand::*)() const>(&AIS_RubberBand::LineType),
             R"#(Returns type of lines.)#" 
          )
        .def("SetFillTransparency",
             (void (AIS_RubberBand::*)(  const double  ) const) static_cast<void (AIS_RubberBand::*)(  const double  ) const>(&AIS_RubberBand::SetFillTransparency),
             R"#(Sets fill transparency.)#"  , py::arg("theValue")
          )
        .def("FillTransparency",
             (double (AIS_RubberBand::*)() const) static_cast<double (AIS_RubberBand::*)() const>(&AIS_RubberBand::FillTransparency),
             R"#(Returns fill transparency.)#" 
          )
        .def("SetFilling",
             (void (AIS_RubberBand::*)(  const bool  ) ) static_cast<void (AIS_RubberBand::*)(  const bool  ) >(&AIS_RubberBand::SetFilling),
             R"#(Enable or disable filling of rubber band.)#"  , py::arg("theIsFilling")
          )
        .def("SetFilling",
             (void (AIS_RubberBand::*)(  const Quantity_Color ,   const double  ) ) static_cast<void (AIS_RubberBand::*)(  const Quantity_Color ,   const double  ) >(&AIS_RubberBand::SetFilling),
             R"#(Enable filling of rubber band with defined parameters.)#"  , py::arg("theColor"),  py::arg("theTransparency")
          )
        .def("IsFilling",
             (bool (AIS_RubberBand::*)() const) static_cast<bool (AIS_RubberBand::*)() const>(&AIS_RubberBand::IsFilling),
             R"#(Returns true if filling of rubber band is enabled.)#" 
          )
        .def("IsPolygonClosed",
             (bool (AIS_RubberBand::*)() const) static_cast<bool (AIS_RubberBand::*)() const>(&AIS_RubberBand::IsPolygonClosed),
             R"#(Returns true if automatic closing of rubber band is enabled.)#" 
          )
        .def("SetPolygonClosed",
             (void (AIS_RubberBand::*)( bool  ) ) static_cast<void (AIS_RubberBand::*)( bool  ) >(&AIS_RubberBand::SetPolygonClosed),
             R"#(Automatically create an additional line connecting the first and the last screen points to close the boundary polyline)#"  , py::arg("theIsPolygonClosed")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_RubberBand::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_RubberBand::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_RubberBand::*)() const) static_cast< const handle<Standard_Type> & (AIS_RubberBand::*)() const>(&AIS_RubberBand::DynamicType),
             R"#()#"
             
         )
       .def("Points",
             ( const NCollection_Sequence<NCollection_Vec2<int>> & (AIS_RubberBand::*)() const) static_cast< const NCollection_Sequence<NCollection_Vec2<int>> & (AIS_RubberBand::*)() const>(&AIS_RubberBand::Points),
             R"#(Returns points for the rubber band polygon.)#"
             
         )
;

    // Class AIS_Shape from ./opencascade/AIS_Shape.hxx
    klass = m.attr("AIS_Shape");


    // nested enums

    static_cast<py::class_<AIS_Shape ,opencascade::handle<AIS_Shape>  , AIS_InteractiveObject >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("shap") )
    // custom constructors
    // methods
        .def("Signature",
             (int (AIS_Shape::*)() const) static_cast<int (AIS_Shape::*)() const>(&AIS_Shape::Signature),
             R"#(Returns index 0. This value refers to SHAPE from TopAbs_ShapeEnum)#" 
          )
        .def("Type",
             (AIS_KindOfInteractive (AIS_Shape::*)() const) static_cast<AIS_KindOfInteractive (AIS_Shape::*)() const>(&AIS_Shape::Type),
             R"#(Returns Object as the type of Interactive Object.)#" 
          )
        .def("AcceptShapeDecomposition",
             (bool (AIS_Shape::*)() const) static_cast<bool (AIS_Shape::*)() const>(&AIS_Shape::AcceptShapeDecomposition),
             R"#(Returns true if the Interactive Object accepts shape decomposition.)#" 
          )
        .def("AcceptDisplayMode",
             (bool (AIS_Shape::*)(  const int  ) const) static_cast<bool (AIS_Shape::*)(  const int  ) const>(&AIS_Shape::AcceptDisplayMode),
             R"#(Return true if specified display mode is supported.)#"  , py::arg("theMode")
          )
        .def("SetShape",
             (void (AIS_Shape::*)(  const TopoDS_Shape &  ) ) static_cast<void (AIS_Shape::*)(  const TopoDS_Shape &  ) >(&AIS_Shape::SetShape),
             R"#(Constructs an instance of the shape object theShape.)#"  , py::arg("theShape")
          )
        .def("Set",
             (void (AIS_Shape::*)(  const TopoDS_Shape &  ) ) static_cast<void (AIS_Shape::*)(  const TopoDS_Shape &  ) >(&AIS_Shape::Set),
             R"#(Alias for ::SetShape().)#"  , py::arg("theShape")
          )
        .def("SetOwnDeviationCoefficient",
             (bool (AIS_Shape::*)() ) static_cast<bool (AIS_Shape::*)() >(&AIS_Shape::SetOwnDeviationCoefficient),
             R"#(Sets a local value for deviation coefficient for this specific shape.)#" 
          )
        .def("SetOwnDeviationAngle",
             (bool (AIS_Shape::*)() ) static_cast<bool (AIS_Shape::*)() >(&AIS_Shape::SetOwnDeviationAngle),
             R"#(Sets a local value for deviation angle for this specific shape.)#" 
          )
        .def("SetOwnDeviationCoefficient",
             (void (AIS_Shape::*)(  const double  ) ) static_cast<void (AIS_Shape::*)(  const double  ) >(&AIS_Shape::SetOwnDeviationCoefficient),
             R"#(Sets a local value for deviation coefficient for this specific shape.)#"  , py::arg("aCoefficient")
          )
        .def("SetAngleAndDeviation",
             (void (AIS_Shape::*)(  const double  ) ) static_cast<void (AIS_Shape::*)(  const double  ) >(&AIS_Shape::SetAngleAndDeviation),
             R"#(this compute a new angle and Deviation from the value anAngle and set the values stored in myDrawer with these that become local to the shape)#"  , py::arg("anAngle")
          )
        .def("UserAngle",
             (double (AIS_Shape::*)() const) static_cast<double (AIS_Shape::*)() const>(&AIS_Shape::UserAngle),
             R"#(gives back the angle initial value put by the User.)#" 
          )
        .def("SetOwnDeviationAngle",
             (void (AIS_Shape::*)(  const double  ) ) static_cast<void (AIS_Shape::*)(  const double  ) >(&AIS_Shape::SetOwnDeviationAngle),
             R"#(sets myOwnDeviationAngle field in Prs3d_Drawer & recomputes presentation)#"  , py::arg("anAngle")
          )
        .def("OwnDeviationCoefficient",
             (bool (AIS_Shape::*)( double & ,  double &  ) const) static_cast<bool (AIS_Shape::*)( double & ,  double &  ) const>(&AIS_Shape::OwnDeviationCoefficient),
             R"#(Returns true and the values of the deviation coefficient aCoefficient and the previous deviation coefficient aPreviousCoefficient. If these values are not already set, false is returned.)#"  , py::arg("aCoefficient"),  py::arg("aPreviousCoefficient")
          )
        .def("OwnDeviationAngle",
             (bool (AIS_Shape::*)( double & ,  double &  ) const) static_cast<bool (AIS_Shape::*)( double & ,  double &  ) const>(&AIS_Shape::OwnDeviationAngle),
             R"#(Returns true and the values of the deviation angle anAngle and the previous deviation angle aPreviousAngle. If these values are not already set, false is returned.)#"  , py::arg("anAngle"),  py::arg("aPreviousAngle")
          )
        .def("SetTypeOfHLR",
             (void (AIS_Shape::*)(  const Prs3d_TypeOfHLR  ) ) static_cast<void (AIS_Shape::*)(  const Prs3d_TypeOfHLR  ) >(&AIS_Shape::SetTypeOfHLR),
             R"#(Sets the type of HLR algorithm used by the shape)#"  , py::arg("theTypeOfHLR")
          )
        .def("TypeOfHLR",
             (Prs3d_TypeOfHLR (AIS_Shape::*)() const) static_cast<Prs3d_TypeOfHLR (AIS_Shape::*)() const>(&AIS_Shape::TypeOfHLR),
             R"#(Gets the type of HLR algorithm)#" 
          )
        .def("SetColor",
             (void (AIS_Shape::*)(  const Quantity_Color &  ) ) static_cast<void (AIS_Shape::*)(  const Quantity_Color &  ) >(&AIS_Shape::SetColor),
             R"#(Sets the color aColor in the reconstructed compound shape. Acts via the Drawer methods below on the appearance of: - free boundaries: Prs3d_Drawer_FreeBoundaryAspect, - isos: Prs3d_Drawer_UIsoAspect, Prs3dDrawer_VIsoAspect, - shared boundaries: Prs3d_Drawer_UnFreeBoundaryAspect, - shading: Prs3d_Drawer_ShadingAspect, - visible line color in hidden line mode: Prs3d_Drawer_SeenLineAspect - hidden line color in hidden line mode: Prs3d_Drawer_HiddenLineAspect.)#"  , py::arg("theColor")
          )
        .def("UnsetColor",
             (void (AIS_Shape::*)() ) static_cast<void (AIS_Shape::*)() >(&AIS_Shape::UnsetColor),
             R"#(Removes settings for color in the reconstructed compound shape.)#" 
          )
        .def("SetWidth",
             (void (AIS_Shape::*)(  const double  ) ) static_cast<void (AIS_Shape::*)(  const double  ) >(&AIS_Shape::SetWidth),
             R"#(Sets the value aValue for line width in the reconstructed compound shape. Changes line aspects for lines presentation.)#"  , py::arg("aValue")
          )
        .def("UnsetWidth",
             (void (AIS_Shape::*)() ) static_cast<void (AIS_Shape::*)() >(&AIS_Shape::UnsetWidth),
             R"#(Removes the setting for line width in the reconstructed compound shape.)#" 
          )
        .def("SetMaterial",
             (void (AIS_Shape::*)(  const Graphic3d_MaterialAspect &  ) ) static_cast<void (AIS_Shape::*)(  const Graphic3d_MaterialAspect &  ) >(&AIS_Shape::SetMaterial),
             R"#(Allows you to provide settings for the material aName in the reconstructed compound shape.)#"  , py::arg("aName")
          )
        .def("UnsetMaterial",
             (void (AIS_Shape::*)() ) static_cast<void (AIS_Shape::*)() >(&AIS_Shape::UnsetMaterial),
             R"#(Removes settings for material in the reconstructed compound shape.)#" 
          )
        .def("SetTransparency",
             (void (AIS_Shape::*)(  const double  ) ) static_cast<void (AIS_Shape::*)(  const double  ) >(&AIS_Shape::SetTransparency),
             R"#(Sets the value aValue for transparency in the reconstructed compound shape.)#"  , py::arg("aValue")=static_cast< const double>(0.6)
          )
        .def("UnsetTransparency",
             (void (AIS_Shape::*)() ) static_cast<void (AIS_Shape::*)() >(&AIS_Shape::UnsetTransparency),
             R"#(Removes the setting for transparency in the reconstructed compound shape.)#" 
          )
        .def("Color",
             (void (AIS_Shape::*)( Quantity_Color &  ) const) static_cast<void (AIS_Shape::*)( Quantity_Color &  ) const>(&AIS_Shape::Color),
             R"#(Returns the Color attributes of the shape accordingly to the current facing model;)#"  , py::arg("aColor")
          )
        .def("Material",
             (Graphic3d_NameOfMaterial (AIS_Shape::*)() const) static_cast<Graphic3d_NameOfMaterial (AIS_Shape::*)() const>(&AIS_Shape::Material),
             R"#(Returns the NameOfMaterial attributes of the shape accordingly to the current facing model;)#" 
          )
        .def("Transparency",
             (double (AIS_Shape::*)() const) static_cast<double (AIS_Shape::*)() const>(&AIS_Shape::Transparency),
             R"#(Returns the transparency attributes of the shape accordingly to the current facing model;)#" 
          )
        .def("SetTextureRepeatUV",
             (void (AIS_Shape::*)(  const gp_Pnt2d &  ) ) static_cast<void (AIS_Shape::*)(  const gp_Pnt2d &  ) >(&AIS_Shape::SetTextureRepeatUV),
             R"#(Sets the number of occurrences of the texture on each face. The texture itself is parameterized in (0,1) by (0,1). Each face of the shape to be textured is parameterized in UV space (Umin,Umax) by (Vmin,Vmax).)#"  , py::arg("theRepeatUV")
          )
        .def("SetTextureOriginUV",
             (void (AIS_Shape::*)(  const gp_Pnt2d &  ) ) static_cast<void (AIS_Shape::*)(  const gp_Pnt2d &  ) >(&AIS_Shape::SetTextureOriginUV),
             R"#(Use this method to change the origin of the texture. The texel (0,0) will be mapped to the surface (myUVOrigin.X(), myUVOrigin.Y()).)#"  , py::arg("theOriginUV")
          )
        .def("SetTextureScaleUV",
             (void (AIS_Shape::*)(  const gp_Pnt2d &  ) ) static_cast<void (AIS_Shape::*)(  const gp_Pnt2d &  ) >(&AIS_Shape::SetTextureScaleUV),
             R"#(Use this method to scale the texture (percent of the face). You can specify a scale factor for both U and V. Example: if you set ScaleU and ScaleV to 0.5 and you enable texture repeat, the texture will appear twice on the face in each direction.)#"  , py::arg("theScaleUV")
          )
        .def("DumpJson",
             (void (AIS_Shape::*)( Standard_OStream & ,  int  ) const) static_cast<void (AIS_Shape::*)( Standard_OStream & ,  int  ) const>(&AIS_Shape::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_Shape::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_Shape::get_type_descriptor),
                    R"#()#" 
          )
        .def_static("SelectionType_s",
                    (TopAbs_ShapeEnum (*)(  const int  ) ) static_cast<TopAbs_ShapeEnum (*)(  const int  ) >(&AIS_Shape::SelectionType),
                    R"#(Return shape type for specified selection mode.)#"  , py::arg("theSelMode")
          )
        .def_static("SelectionMode_s",
                    (int (*)(  const TopAbs_ShapeEnum  ) ) static_cast<int (*)(  const TopAbs_ShapeEnum  ) >(&AIS_Shape::SelectionMode),
                    R"#(Return selection mode for specified shape type.)#"  , py::arg("theShapeType")
          )
        .def_static("computeHlrPresentation_s",
                    (void (*)(  const handle<Graphic3d_Camera> & ,   const handle<Prs3d_Presentation> & ,   const TopoDS_Shape & ,   const handle<Prs3d_Drawer> &  ) ) static_cast<void (*)(  const handle<Graphic3d_Camera> & ,   const handle<Prs3d_Presentation> & ,   const TopoDS_Shape & ,   const handle<Prs3d_Drawer> &  ) >(&AIS_Shape::computeHlrPresentation),
                    R"#(Compute HLR presentation for specified shape.)#"  , py::arg("theProjector"),  py::arg("thePrs"),  py::arg("theShape"),  py::arg("theDrawer")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_Shape::*)() const) static_cast< const handle<Standard_Type> & (AIS_Shape::*)() const>(&AIS_Shape::DynamicType),
             R"#()#"
             
         )
       .def("Shape",
             ( const TopoDS_Shape & (AIS_Shape::*)() const) static_cast< const TopoDS_Shape & (AIS_Shape::*)() const>(&AIS_Shape::Shape),
             R"#(Returns this shape object.)#"
             
         )
       .def("BoundingBox",
             ( const Bnd_Box & (AIS_Shape::*)() ) static_cast< const Bnd_Box & (AIS_Shape::*)() >(&AIS_Shape::BoundingBox),
             R"#(Constructs a bounding box with which to reconstruct compound topological shapes for presentation.)#"
             
         )
       .def("TextureRepeatUV",
             ( const gp_Pnt2d & (AIS_Shape::*)() const) static_cast< const gp_Pnt2d & (AIS_Shape::*)() const>(&AIS_Shape::TextureRepeatUV),
             R"#(Return texture repeat UV values; (1, 1) by default.)#"
             
         )
       .def("TextureOriginUV",
             ( const gp_Pnt2d & (AIS_Shape::*)() const) static_cast< const gp_Pnt2d & (AIS_Shape::*)() const>(&AIS_Shape::TextureOriginUV),
             R"#(Return texture origin UV position; (0, 0) by default.)#"
             
         )
       .def("TextureScaleUV",
             ( const gp_Pnt2d & (AIS_Shape::*)() const) static_cast< const gp_Pnt2d & (AIS_Shape::*)() const>(&AIS_Shape::TextureScaleUV),
             R"#(Return scale factor for UV coordinates; (1, 1) by default.)#"
             
         )
;

    // Class AIS_SignatureFilter from ./opencascade/AIS_SignatureFilter.hxx
    klass = m.attr("AIS_SignatureFilter");


    // nested enums

    static_cast<py::class_<AIS_SignatureFilter ,opencascade::handle<AIS_SignatureFilter>  , AIS_TypeFilter >>(klass)
    // constructors
        .def(py::init<  const AIS_KindOfInteractive, const int >()  , py::arg("aGivenKind"),  py::arg("aGivenSignature") )
    // custom constructors
    // methods
        .def("IsOk",
             (bool (AIS_SignatureFilter::*)(  const handle<SelectMgr_EntityOwner> &  ) const) static_cast<bool (AIS_SignatureFilter::*)(  const handle<SelectMgr_EntityOwner> &  ) const>(&AIS_SignatureFilter::IsOk),
             R"#(Returns False if the transient is not an AIS_InteractiveObject. Returns False if the signature of InteractiveObject is not the same as the stored one in the filter...)#"  , py::arg("anobj")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_SignatureFilter::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_SignatureFilter::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_SignatureFilter::*)() const) static_cast< const handle<Standard_Type> & (AIS_SignatureFilter::*)() const>(&AIS_SignatureFilter::DynamicType),
             R"#()#"
             
         )
;

    // Class AIS_TextLabel from ./opencascade/AIS_TextLabel.hxx
    klass = m.attr("AIS_TextLabel");


    // nested enums

    static_cast<py::class_<AIS_TextLabel ,opencascade::handle<AIS_TextLabel>  , AIS_InteractiveObject >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("AcceptDisplayMode",
             (bool (AIS_TextLabel::*)(  const int  ) const) static_cast<bool (AIS_TextLabel::*)(  const int  ) const>(&AIS_TextLabel::AcceptDisplayMode),
             R"#(Return TRUE for supported display mode.)#"  , py::arg("theMode")
          )
        .def("SetColor",
             (void (AIS_TextLabel::*)(  const Quantity_Color &  ) ) static_cast<void (AIS_TextLabel::*)(  const Quantity_Color &  ) >(&AIS_TextLabel::SetColor),
             R"#(Setup color of entire text.)#"  , py::arg("theColor")
          )
        .def("SetTransparency",
             (void (AIS_TextLabel::*)(  const double  ) ) static_cast<void (AIS_TextLabel::*)(  const double  ) >(&AIS_TextLabel::SetTransparency),
             R"#(Setup transparency within [0, 1] range.)#"  , py::arg("theValue")
          )
        .def("UnsetTransparency",
             (void (AIS_TextLabel::*)() ) static_cast<void (AIS_TextLabel::*)() >(&AIS_TextLabel::UnsetTransparency),
             R"#(Removes the transparency setting.)#" 
          )
        .def("SetMaterial",
             (void (AIS_TextLabel::*)(  const Graphic3d_MaterialAspect &  ) ) static_cast<void (AIS_TextLabel::*)(  const Graphic3d_MaterialAspect &  ) >(&AIS_TextLabel::SetMaterial),
             R"#(Material has no effect for text label.)#"  , py::arg("arg0")
          )
        .def("SetText",
             (void (AIS_TextLabel::*)(  const TCollection_ExtendedString &  ) ) static_cast<void (AIS_TextLabel::*)(  const TCollection_ExtendedString &  ) >(&AIS_TextLabel::SetText),
             R"#(Setup text.)#"  , py::arg("theText")
          )
        .def("SetPosition",
             (void (AIS_TextLabel::*)(  const gp_Pnt &  ) ) static_cast<void (AIS_TextLabel::*)(  const gp_Pnt &  ) >(&AIS_TextLabel::SetPosition),
             R"#(Setup position.)#"  , py::arg("thePosition")
          )
        .def("SetHJustification",
             (void (AIS_TextLabel::*)(  const Graphic3d_HorizontalTextAlignment  ) ) static_cast<void (AIS_TextLabel::*)(  const Graphic3d_HorizontalTextAlignment  ) >(&AIS_TextLabel::SetHJustification),
             R"#(Setup horizontal justification.)#"  , py::arg("theHJust")
          )
        .def("SetVJustification",
             (void (AIS_TextLabel::*)(  const Graphic3d_VerticalTextAlignment  ) ) static_cast<void (AIS_TextLabel::*)(  const Graphic3d_VerticalTextAlignment  ) >(&AIS_TextLabel::SetVJustification),
             R"#(Setup vertical justification.)#"  , py::arg("theVJust")
          )
        .def("SetAngle",
             (void (AIS_TextLabel::*)(  const double  ) ) static_cast<void (AIS_TextLabel::*)(  const double  ) >(&AIS_TextLabel::SetAngle),
             R"#(Setup angle.)#"  , py::arg("theAngle")
          )
        .def("SetZoomable",
             (void (AIS_TextLabel::*)(  const bool  ) ) static_cast<void (AIS_TextLabel::*)(  const bool  ) >(&AIS_TextLabel::SetZoomable),
             R"#(Setup zoomable property.)#"  , py::arg("theIsZoomable")
          )
        .def("SetHeight",
             (void (AIS_TextLabel::*)(  const double  ) ) static_cast<void (AIS_TextLabel::*)(  const double  ) >(&AIS_TextLabel::SetHeight),
             R"#(Setup height.)#"  , py::arg("theHeight")
          )
        .def("SetFontAspect",
             (void (AIS_TextLabel::*)(  const Font_FontAspect  ) ) static_cast<void (AIS_TextLabel::*)(  const Font_FontAspect  ) >(&AIS_TextLabel::SetFontAspect),
             R"#(Setup font aspect.)#"  , py::arg("theFontAspect")
          )
        .def("SetFont",
             (void (AIS_TextLabel::*)(  const char *  ) ) static_cast<void (AIS_TextLabel::*)(  const char *  ) >(&AIS_TextLabel::SetFont),
             R"#(Setup font.)#"  , py::arg("theFont")
          )
        .def("SetOrientation3D",
             (void (AIS_TextLabel::*)(  const gp_Ax2 &  ) ) static_cast<void (AIS_TextLabel::*)(  const gp_Ax2 &  ) >(&AIS_TextLabel::SetOrientation3D),
             R"#(Setup label orientation in the model 3D space.)#"  , py::arg("theOrientation")
          )
        .def("UnsetOrientation3D",
             (void (AIS_TextLabel::*)() ) static_cast<void (AIS_TextLabel::*)() >(&AIS_TextLabel::UnsetOrientation3D),
             R"#(Reset label orientation in the model 3D space.)#" 
          )
        .def("FontAspect",
             (Font_FontAspect (AIS_TextLabel::*)() const) static_cast<Font_FontAspect (AIS_TextLabel::*)() const>(&AIS_TextLabel::FontAspect),
             R"#(Returns the font aspect of the label text.)#" 
          )
        .def("HasOrientation3D",
             (bool (AIS_TextLabel::*)() const) static_cast<bool (AIS_TextLabel::*)() const>(&AIS_TextLabel::HasOrientation3D),
             R"#(Returns true if the current text placement mode uses text orientation in the model 3D space.)#" 
          )
        .def("SetFlipping",
             (void (AIS_TextLabel::*)(  const bool  ) ) static_cast<void (AIS_TextLabel::*)(  const bool  ) >(&AIS_TextLabel::SetFlipping),
             R"#()#"  , py::arg("theIsFlipping")
          )
        .def("HasFlipping",
             (bool (AIS_TextLabel::*)() const) static_cast<bool (AIS_TextLabel::*)() const>(&AIS_TextLabel::HasFlipping),
             R"#()#" 
          )
        .def("HasOwnAnchorPoint",
             (bool (AIS_TextLabel::*)() const) static_cast<bool (AIS_TextLabel::*)() const>(&AIS_TextLabel::HasOwnAnchorPoint),
             R"#(Returns flag if text uses position as point of attach)#" 
          )
        .def("SetOwnAnchorPoint",
             (void (AIS_TextLabel::*)(  const bool  ) ) static_cast<void (AIS_TextLabel::*)(  const bool  ) >(&AIS_TextLabel::SetOwnAnchorPoint),
             R"#(Set flag if text uses position as point of attach)#"  , py::arg("theOwnAnchorPoint")
          )
        .def("SetDisplayType",
             (void (AIS_TextLabel::*)(  const Aspect_TypeOfDisplayText  ) ) static_cast<void (AIS_TextLabel::*)(  const Aspect_TypeOfDisplayText  ) >(&AIS_TextLabel::SetDisplayType),
             R"#(Define the display type of the text.)#"  , py::arg("theDisplayType")
          )
        .def("SetColorSubTitle",
             (void (AIS_TextLabel::*)(  const Quantity_Color &  ) ) static_cast<void (AIS_TextLabel::*)(  const Quantity_Color &  ) >(&AIS_TextLabel::SetColorSubTitle),
             R"#(Modifies the colour of the subtitle for the TODT_SUBTITLE TextDisplayType and the colour of backgroubd for the TODT_DEKALE TextDisplayType.)#"  , py::arg("theColor")
          )
        .def("SetTextFormatter",
             (void (AIS_TextLabel::*)(  const handle<Font_TextFormatter> &  ) ) static_cast<void (AIS_TextLabel::*)(  const handle<Font_TextFormatter> &  ) >(&AIS_TextLabel::SetTextFormatter),
             R"#(Setup text formatter for presentation. It's empty by default.)#"  , py::arg("theFormatter")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_TextLabel::get_type_name),
                    R"#(CASCADE RTTI)#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_TextLabel::get_type_descriptor),
                    R"#(CASCADE RTTI)#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Position",
             ( const gp_Pnt & (AIS_TextLabel::*)() const) static_cast< const gp_Pnt & (AIS_TextLabel::*)() const>(&AIS_TextLabel::Position),
             R"#(Returns position.)#"
             
         )
       .def("Text",
             ( const TCollection_ExtendedString & (AIS_TextLabel::*)() const) static_cast< const TCollection_ExtendedString & (AIS_TextLabel::*)() const>(&AIS_TextLabel::Text),
             R"#(Returns the label text.)#"
             
         )
       .def("FontName",
             ( const TCollection_AsciiString & (AIS_TextLabel::*)() const) static_cast< const TCollection_AsciiString & (AIS_TextLabel::*)() const>(&AIS_TextLabel::FontName),
             R"#(Returns the font of the label text.)#"
             
         )
       .def("Orientation3D",
             ( const gp_Ax2 & (AIS_TextLabel::*)() const) static_cast< const gp_Ax2 & (AIS_TextLabel::*)() const>(&AIS_TextLabel::Orientation3D),
             R"#(Returns label orientation in the model 3D space.)#"
             
         )
       .def("TextFormatter",
             ( const handle<Font_TextFormatter> & (AIS_TextLabel::*)() const) static_cast< const handle<Font_TextFormatter> & (AIS_TextLabel::*)() const>(&AIS_TextLabel::TextFormatter),
             R"#(Returns text presentation formatter; NULL by default, which means standard text formatter will be used.)#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_TextLabel::*)() const) static_cast< const handle<Standard_Type> & (AIS_TextLabel::*)() const>(&AIS_TextLabel::DynamicType),
             R"#(CASCADE RTTI)#"
             
         )
;

    // Class AIS_Triangulation from ./opencascade/AIS_Triangulation.hxx
    klass = m.attr("AIS_Triangulation");


    // nested enums

    static_cast<py::class_<AIS_Triangulation ,opencascade::handle<AIS_Triangulation>  , AIS_InteractiveObject >>(klass)
    // constructors
        .def(py::init<  const handle<Poly_Triangulation> & >()  , py::arg("aTriangulation") )
    // custom constructors
    // methods
        .def("SetColors",
             (void (AIS_Triangulation::*)(  const handle<NCollection_HArray1<int>> &  ) ) static_cast<void (AIS_Triangulation::*)(  const handle<NCollection_HArray1<int>> &  ) >(&AIS_Triangulation::SetColors),
             R"#(Set the color for each node. Each 32-bit color is Alpha << 24 + Blue << 16 + Green << 8 + Red Order of color components is essential for further usage by OpenGL)#"  , py::arg("aColor")
          )
        .def("GetColors",
             (handle<NCollection_HArray1<int>> (AIS_Triangulation::*)() const) static_cast<handle<NCollection_HArray1<int>> (AIS_Triangulation::*)() const>(&AIS_Triangulation::GetColors),
             R"#(Get the color for each node. Each 32-bit color is Alpha << 24 + Blue << 16 + Green << 8 + Red)#" 
          )
        .def("HasVertexColors",
             (bool (AIS_Triangulation::*)() const) static_cast<bool (AIS_Triangulation::*)() const>(&AIS_Triangulation::HasVertexColors),
             R"#(Returns true if triangulation has vertex colors.)#" 
          )
        .def("SetTriangulation",
             (void (AIS_Triangulation::*)(  const handle<Poly_Triangulation> &  ) ) static_cast<void (AIS_Triangulation::*)(  const handle<Poly_Triangulation> &  ) >(&AIS_Triangulation::SetTriangulation),
             R"#()#"  , py::arg("aTriangulation")
          )
        .def("GetTriangulation",
             (handle<Poly_Triangulation> (AIS_Triangulation::*)() const) static_cast<handle<Poly_Triangulation> (AIS_Triangulation::*)() const>(&AIS_Triangulation::GetTriangulation),
             R"#(Returns Poly_Triangulation .)#" 
          )
        .def("SetTransparency",
             (void (AIS_Triangulation::*)(  const double  ) ) static_cast<void (AIS_Triangulation::*)(  const double  ) >(&AIS_Triangulation::SetTransparency),
             R"#(Sets the value aValue for transparency in the reconstructed compound shape.)#"  , py::arg("aValue")=static_cast< const double>(0.6)
          )
        .def("UnsetTransparency",
             (void (AIS_Triangulation::*)() ) static_cast<void (AIS_Triangulation::*)() >(&AIS_Triangulation::UnsetTransparency),
             R"#(Removes the setting for transparency in the reconstructed compound shape.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_Triangulation::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_Triangulation::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_Triangulation::*)() const) static_cast< const handle<Standard_Type> & (AIS_Triangulation::*)() const>(&AIS_Triangulation::DynamicType),
             R"#()#"
             
         )
;

    // Class AIS_Trihedron from ./opencascade/AIS_Trihedron.hxx
    klass = m.attr("AIS_Trihedron");


    // nested enums

    static_cast<py::class_<AIS_Trihedron ,opencascade::handle<AIS_Trihedron>  , AIS_InteractiveObject >>(klass)
    // constructors
        .def(py::init<  const handle<Geom_Axis2Placement> & >()  , py::arg("theComponent") )
    // custom constructors
    // methods
        .def("DatumDisplayMode",
             (Prs3d_DatumMode (AIS_Trihedron::*)() const) static_cast<Prs3d_DatumMode (AIS_Trihedron::*)() const>(&AIS_Trihedron::DatumDisplayMode),
             R"#(Returns datum display mode.)#" 
          )
        .def("SetDatumDisplayMode",
             (void (AIS_Trihedron::*)( Prs3d_DatumMode  ) ) static_cast<void (AIS_Trihedron::*)( Prs3d_DatumMode  ) >(&AIS_Trihedron::SetDatumDisplayMode),
             R"#(Sets Shading or Wireframe display mode, triangle or segment graphic group is used relatively.)#"  , py::arg("theMode")
          )
        .def("SetComponent",
             (void (AIS_Trihedron::*)(  const handle<Geom_Axis2Placement> &  ) ) static_cast<void (AIS_Trihedron::*)(  const handle<Geom_Axis2Placement> &  ) >(&AIS_Trihedron::SetComponent),
             R"#(Constructs the right-handed coordinate system aComponent.)#"  , py::arg("theComponent")
          )
        .def("HasOwnSize",
             (bool (AIS_Trihedron::*)() const) static_cast<bool (AIS_Trihedron::*)() const>(&AIS_Trihedron::HasOwnSize),
             R"#(Returns true if the trihedron object has a size other than the default size of 100 mm. along each axis.)#" 
          )
        .def("Size",
             (double (AIS_Trihedron::*)() const) static_cast<double (AIS_Trihedron::*)() const>(&AIS_Trihedron::Size),
             R"#(Returns the size of trihedron object; 100.0 by DEFAULT.)#" 
          )
        .def("SetSize",
             (void (AIS_Trihedron::*)(  const double  ) ) static_cast<void (AIS_Trihedron::*)(  const double  ) >(&AIS_Trihedron::SetSize),
             R"#(Sets the size of trihedron object.)#"  , py::arg("theValue")
          )
        .def("UnsetSize",
             (void (AIS_Trihedron::*)() ) static_cast<void (AIS_Trihedron::*)() >(&AIS_Trihedron::UnsetSize),
             R"#(Removes any non-default settings for size of this trihedron object. If the object has 1 color, the default size of the drawer is reproduced, otherwise DatumAspect becomes null.)#" 
          )
        .def("HasTextColor",
             (bool (AIS_Trihedron::*)() const) static_cast<bool (AIS_Trihedron::*)() const>(&AIS_Trihedron::HasTextColor),
             R"#(Returns true if trihedron has own text color)#" 
          )
        .def("TextColor",
             (Quantity_Color (AIS_Trihedron::*)() const) static_cast<Quantity_Color (AIS_Trihedron::*)() const>(&AIS_Trihedron::TextColor),
             R"#(Returns trihedron text color)#" 
          )
        .def("SetTextColor",
             (void (AIS_Trihedron::*)(  const Quantity_Color &  ) ) static_cast<void (AIS_Trihedron::*)(  const Quantity_Color &  ) >(&AIS_Trihedron::SetTextColor),
             R"#(Sets color of label of trihedron axes.)#"  , py::arg("theColor")
          )
        .def("SetTextColor",
             (void (AIS_Trihedron::*)(  const Prs3d_DatumParts ,   const Quantity_Color &  ) ) static_cast<void (AIS_Trihedron::*)(  const Prs3d_DatumParts ,   const Quantity_Color &  ) >(&AIS_Trihedron::SetTextColor),
             R"#(Sets color of label of trihedron axis.)#"  , py::arg("thePart"),  py::arg("theColor")
          )
        .def("HasArrowColor",
             (bool (AIS_Trihedron::*)() const) static_cast<bool (AIS_Trihedron::*)() const>(&AIS_Trihedron::HasArrowColor),
             R"#(Returns true if trihedron has own arrow color)#" 
          )
        .def("ArrowColor",
             (Quantity_Color (AIS_Trihedron::*)() const) static_cast<Quantity_Color (AIS_Trihedron::*)() const>(&AIS_Trihedron::ArrowColor),
             R"#(Returns trihedron arrow color)#" 
          )
        .def("SetArrowColor",
             (void (AIS_Trihedron::*)(  const Quantity_Color &  ) ) static_cast<void (AIS_Trihedron::*)(  const Quantity_Color &  ) >(&AIS_Trihedron::SetArrowColor),
             R"#(Sets color of arrow of trihedron axes.)#"  , py::arg("theColor")
          )
        .def("SetArrowColor",
             (void (AIS_Trihedron::*)(  const Prs3d_DatumParts ,   const Quantity_Color &  ) ) static_cast<void (AIS_Trihedron::*)(  const Prs3d_DatumParts ,   const Quantity_Color &  ) >(&AIS_Trihedron::SetArrowColor),
             R"#(Sets color of arrow of trihedron axes.)#"  , py::arg("thePart"),  py::arg("theColor")
          )
        .def("DatumPartColor",
             (Quantity_Color (AIS_Trihedron::*)( Prs3d_DatumParts  ) ) static_cast<Quantity_Color (AIS_Trihedron::*)( Prs3d_DatumParts  ) >(&AIS_Trihedron::DatumPartColor),
             R"#(Returns color of datum part: origin or some of trihedron axes.)#"  , py::arg("thePart")
          )
        .def("SetDatumPartColor",
             (void (AIS_Trihedron::*)(  const Prs3d_DatumParts ,   const Quantity_Color &  ) ) static_cast<void (AIS_Trihedron::*)(  const Prs3d_DatumParts ,   const Quantity_Color &  ) >(&AIS_Trihedron::SetDatumPartColor),
             R"#(Sets color of datum part: origin or some of trihedron axes. If presentation is shading mode, this color is set for both sides of facing model)#"  , py::arg("thePart"),  py::arg("theColor")
          )
        .def("SetOriginColor",
             (void (AIS_Trihedron::*)(  const Quantity_Color &  ) ) static_cast<void (AIS_Trihedron::*)(  const Quantity_Color &  ) >(&AIS_Trihedron::SetOriginColor),
             R"#(Sets color of origin. Standard_DEPRECATED("This method is deprecated - SetColor() should be called instead"))#"  , py::arg("theColor")
          )
        .def("SetXAxisColor",
             (void (AIS_Trihedron::*)(  const Quantity_Color &  ) ) static_cast<void (AIS_Trihedron::*)(  const Quantity_Color &  ) >(&AIS_Trihedron::SetXAxisColor),
             R"#(Sets color of x-axis. Standard_DEPRECATED("This method is deprecated - SetColor() should be called instead"))#"  , py::arg("theColor")
          )
        .def("SetYAxisColor",
             (void (AIS_Trihedron::*)(  const Quantity_Color &  ) ) static_cast<void (AIS_Trihedron::*)(  const Quantity_Color &  ) >(&AIS_Trihedron::SetYAxisColor),
             R"#(Sets color of y-axis. Standard_DEPRECATED("This method is deprecated - SetColor() should be called instead"))#"  , py::arg("theColor")
          )
        .def("SetAxisColor",
             (void (AIS_Trihedron::*)(  const Quantity_Color &  ) ) static_cast<void (AIS_Trihedron::*)(  const Quantity_Color &  ) >(&AIS_Trihedron::SetAxisColor),
             R"#(Sets color of z-axis. Standard_DEPRECATED("This method is deprecated - SetColor() should be called instead"))#"  , py::arg("theColor")
          )
        .def("ToDrawArrows",
             (bool (AIS_Trihedron::*)() const) static_cast<bool (AIS_Trihedron::*)() const>(&AIS_Trihedron::ToDrawArrows),
             R"#(Returns true if arrows are to be drawn)#" 
          )
        .def("SetDrawArrows",
             (void (AIS_Trihedron::*)(  const bool  ) ) static_cast<void (AIS_Trihedron::*)(  const bool  ) >(&AIS_Trihedron::SetDrawArrows),
             R"#(Sets whether to draw the arrows in visualization)#"  , py::arg("theToDraw")
          )
        .def("SelectionPriority",
             (int (AIS_Trihedron::*)( Prs3d_DatumParts  ) ) static_cast<int (AIS_Trihedron::*)( Prs3d_DatumParts  ) >(&AIS_Trihedron::SelectionPriority),
             R"#(Returns priority of selection for owner of the given type)#"  , py::arg("thePart")
          )
        .def("SetSelectionPriority",
             (void (AIS_Trihedron::*)( Prs3d_DatumParts ,  int  ) ) static_cast<void (AIS_Trihedron::*)( Prs3d_DatumParts ,  int  ) >(&AIS_Trihedron::SetSelectionPriority),
             R"#(Sets priority of selection for owner of the given type)#"  , py::arg("thePart"),  py::arg("thePriority")
          )
        .def("Label",
             ( const TCollection_ExtendedString & (AIS_Trihedron::*)( Prs3d_DatumParts  ) ) static_cast< const TCollection_ExtendedString & (AIS_Trihedron::*)( Prs3d_DatumParts  ) >(&AIS_Trihedron::Label),
             R"#(Returns text of axis. Parameter thePart should be XAxis, YAxis or ZAxis)#"  , py::arg("thePart")
          )
        .def("SetLabel",
             (void (AIS_Trihedron::*)(  const Prs3d_DatumParts ,   const TCollection_ExtendedString &  ) ) static_cast<void (AIS_Trihedron::*)(  const Prs3d_DatumParts ,   const TCollection_ExtendedString &  ) >(&AIS_Trihedron::SetLabel),
             R"#(Sets text label for trihedron axis. Parameter thePart should be XAxis, YAxis or ZAxis)#"  , py::arg("thePart"),  py::arg("theName")
          )
        .def("SetColor",
             (void (AIS_Trihedron::*)(  const Quantity_Color &  ) ) static_cast<void (AIS_Trihedron::*)(  const Quantity_Color &  ) >(&AIS_Trihedron::SetColor),
             R"#(Sets the color theColor for this trihedron object, it changes color of axes.)#"  , py::arg("theColor")
          )
        .def("AcceptDisplayMode",
             (bool (AIS_Trihedron::*)(  const int  ) const) static_cast<bool (AIS_Trihedron::*)(  const int  ) const>(&AIS_Trihedron::AcceptDisplayMode),
             R"#(Returns true if the display mode selected, aMode, is valid for trihedron datums.)#"  , py::arg("theMode")
          )
        .def("Signature",
             (int (AIS_Trihedron::*)() const) static_cast<int (AIS_Trihedron::*)() const>(&AIS_Trihedron::Signature),
             R"#(Returns index 3, selection of the planes XOY, YOZ, XOZ.)#" 
          )
        .def("Type",
             (AIS_KindOfInteractive (AIS_Trihedron::*)() const) static_cast<AIS_KindOfInteractive (AIS_Trihedron::*)() const>(&AIS_Trihedron::Type),
             R"#(Indicates that the type of Interactive Object is datum.)#" 
          )
        .def("UnsetColor",
             (void (AIS_Trihedron::*)() ) static_cast<void (AIS_Trihedron::*)() >(&AIS_Trihedron::UnsetColor),
             R"#(Removes the settings for color.)#" 
          )
        .def("ClearSelected",
             (void (AIS_Trihedron::*)() ) static_cast<void (AIS_Trihedron::*)() >(&AIS_Trihedron::ClearSelected),
             R"#(Method which clear all selected owners belonging to this selectable object (for fast presentation draw).)#" 
          )
        .def("HilightSelected",
             (void (AIS_Trihedron::*)(  const handle<PrsMgr_PresentationManager> & ,   const NCollection_Sequence<handle<SelectMgr_EntityOwner>> &  ) ) static_cast<void (AIS_Trihedron::*)(  const handle<PrsMgr_PresentationManager> & ,   const NCollection_Sequence<handle<SelectMgr_EntityOwner>> &  ) >(&AIS_Trihedron::HilightSelected),
             R"#(Method which draws selected owners (for fast presentation draw).)#"  , py::arg("thePM"),  py::arg("theOwners")
          )
        .def("HilightOwnerWithColor",
             (void (AIS_Trihedron::*)(  const handle<PrsMgr_PresentationManager> & ,   const handle<Prs3d_Drawer> & ,   const handle<SelectMgr_EntityOwner> &  ) ) static_cast<void (AIS_Trihedron::*)(  const handle<PrsMgr_PresentationManager> & ,   const handle<Prs3d_Drawer> & ,   const handle<SelectMgr_EntityOwner> &  ) >(&AIS_Trihedron::HilightOwnerWithColor),
             R"#(Method which highlights an owner belonging to this selectable object (for fast presentation draw).)#"  , py::arg("thePM"),  py::arg("theStyle"),  py::arg("theOwner")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_Trihedron::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_Trihedron::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_Trihedron::*)() const) static_cast< const handle<Standard_Type> & (AIS_Trihedron::*)() const>(&AIS_Trihedron::DynamicType),
             R"#()#"
             
         )
       .def("Component",
             ( const handle<Geom_Axis2Placement> & (AIS_Trihedron::*)() const) static_cast< const handle<Geom_Axis2Placement> & (AIS_Trihedron::*)() const>(&AIS_Trihedron::Component),
             R"#(Returns the right-handed coordinate system set in SetComponent.)#"
             
         )
;

    // Class AIS_ViewCube from ./opencascade/AIS_ViewCube.hxx
    klass = m.attr("AIS_ViewCube");


    // nested enums

    static_cast<py::class_<AIS_ViewCube ,opencascade::handle<AIS_ViewCube>  , AIS_InteractiveObject >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetViewAnimation",
             (void (AIS_ViewCube::*)(  const handle<AIS_AnimationCamera> &  ) ) static_cast<void (AIS_ViewCube::*)(  const handle<AIS_AnimationCamera> &  ) >(&AIS_ViewCube::SetViewAnimation),
             R"#(Set view animation.)#"  , py::arg("theAnimation")
          )
        .def("ToAutoStartAnimation",
             (bool (AIS_ViewCube::*)() const) static_cast<bool (AIS_ViewCube::*)() const>(&AIS_ViewCube::ToAutoStartAnimation),
             R"#(Return TRUE if automatic camera transformation on selection (highlighting) is enabled; TRUE by default.)#" 
          )
        .def("SetAutoStartAnimation",
             (void (AIS_ViewCube::*)( bool  ) ) static_cast<void (AIS_ViewCube::*)( bool  ) >(&AIS_ViewCube::SetAutoStartAnimation),
             R"#(Enable/disable automatic camera transformation on selection (highlighting). The automatic logic can be disabled if application wants performing action manually basing on picking results (AIS_ViewCubeOwner).)#"  , py::arg("theToEnable")
          )
        .def("IsFixedAnimationLoop",
             (bool (AIS_ViewCube::*)() const) static_cast<bool (AIS_ViewCube::*)() const>(&AIS_ViewCube::IsFixedAnimationLoop),
             R"#(Return TRUE if camera animation should be done in uninterruptible loop; TRUE by default.)#" 
          )
        .def("SetFixedAnimationLoop",
             (void (AIS_ViewCube::*)( bool  ) ) static_cast<void (AIS_ViewCube::*)( bool  ) >(&AIS_ViewCube::SetFixedAnimationLoop),
             R"#(Set if camera animation should be done in uninterruptible loop.)#"  , py::arg("theToEnable")
          )
        .def("ResetStyles",
             (void (AIS_ViewCube::*)() ) static_cast<void (AIS_ViewCube::*)() >(&AIS_ViewCube::ResetStyles),
             R"#(Reset all size and style parameters to default.)#" 
          )
        .def("Size",
             (double (AIS_ViewCube::*)() const) static_cast<double (AIS_ViewCube::*)() const>(&AIS_ViewCube::Size),
             R"#(Returns size (width and height) of View cube sides; 100 by default.)#" 
          )
        .def("SetSize",
             (void (AIS_ViewCube::*)( double ,  bool  ) ) static_cast<void (AIS_ViewCube::*)( double ,  bool  ) >(&AIS_ViewCube::SetSize),
             R"#(Sets size (width and height) of View cube sides.)#"  , py::arg("theValue"),  py::arg("theToAdaptAnother")=static_cast<bool>(true)
          )
        .def("BoxFacetExtension",
             (double (AIS_ViewCube::*)() const) static_cast<double (AIS_ViewCube::*)() const>(&AIS_ViewCube::BoxFacetExtension),
             R"#(Return box facet extension to edge/corner facet split; 10 by default.)#" 
          )
        .def("SetBoxFacetExtension",
             (void (AIS_ViewCube::*)( double  ) ) static_cast<void (AIS_ViewCube::*)( double  ) >(&AIS_ViewCube::SetBoxFacetExtension),
             R"#(Set new value of box facet extension.)#"  , py::arg("theValue")
          )
        .def("AxesPadding",
             (double (AIS_ViewCube::*)() const) static_cast<double (AIS_ViewCube::*)() const>(&AIS_ViewCube::AxesPadding),
             R"#(Return padding between axes and 3D part (box); 10 by default.)#" 
          )
        .def("SetAxesPadding",
             (void (AIS_ViewCube::*)( double  ) ) static_cast<void (AIS_ViewCube::*)( double  ) >(&AIS_ViewCube::SetAxesPadding),
             R"#(Set new value of padding between axes and 3D part (box).)#"  , py::arg("theValue")
          )
        .def("BoxEdgeGap",
             (double (AIS_ViewCube::*)() const) static_cast<double (AIS_ViewCube::*)() const>(&AIS_ViewCube::BoxEdgeGap),
             R"#(Return gap between box edges and box sides; 0 by default.)#" 
          )
        .def("SetBoxEdgeGap",
             (void (AIS_ViewCube::*)( double  ) ) static_cast<void (AIS_ViewCube::*)( double  ) >(&AIS_ViewCube::SetBoxEdgeGap),
             R"#(Set new value of box edges gap.)#"  , py::arg("theValue")
          )
        .def("BoxEdgeMinSize",
             (double (AIS_ViewCube::*)() const) static_cast<double (AIS_ViewCube::*)() const>(&AIS_ViewCube::BoxEdgeMinSize),
             R"#(Return minimal size of box edge; 2 by default.)#" 
          )
        .def("SetBoxEdgeMinSize",
             (void (AIS_ViewCube::*)( double  ) ) static_cast<void (AIS_ViewCube::*)( double  ) >(&AIS_ViewCube::SetBoxEdgeMinSize),
             R"#(Set new value of box edge minimal size.)#"  , py::arg("theValue")
          )
        .def("BoxCornerMinSize",
             (double (AIS_ViewCube::*)() const) static_cast<double (AIS_ViewCube::*)() const>(&AIS_ViewCube::BoxCornerMinSize),
             R"#(Return minimal size of box corner; 2 by default.)#" 
          )
        .def("SetBoxCornerMinSize",
             (void (AIS_ViewCube::*)( double  ) ) static_cast<void (AIS_ViewCube::*)( double  ) >(&AIS_ViewCube::SetBoxCornerMinSize),
             R"#(Set new value of box corner minimal size.)#"  , py::arg("theValue")
          )
        .def("RoundRadius",
             (double (AIS_ViewCube::*)() const) static_cast<double (AIS_ViewCube::*)() const>(&AIS_ViewCube::RoundRadius),
             R"#(Return relative radius of side corners (round rectangle); 0.0 by default. The value in within [0, 0.5] range meaning absolute radius = RoundRadius() / Size().)#" 
          )
        .def("SetRoundRadius",
             (void (AIS_ViewCube::*)(  const double  ) ) static_cast<void (AIS_ViewCube::*)(  const double  ) >(&AIS_ViewCube::SetRoundRadius),
             R"#(Set relative radius of View Cube sides corners (round rectangle). The value should be within [0, 0.5] range.)#"  , py::arg("theValue")
          )
        .def("AxesRadius",
             (double (AIS_ViewCube::*)() const) static_cast<double (AIS_ViewCube::*)() const>(&AIS_ViewCube::AxesRadius),
             R"#(Returns radius of axes of the trihedron; 1.0 by default.)#" 
          )
        .def("SetAxesRadius",
             (void (AIS_ViewCube::*)(  const double  ) ) static_cast<void (AIS_ViewCube::*)(  const double  ) >(&AIS_ViewCube::SetAxesRadius),
             R"#(Sets radius of axes of the trihedron.)#"  , py::arg("theRadius")
          )
        .def("AxesConeRadius",
             (double (AIS_ViewCube::*)() const) static_cast<double (AIS_ViewCube::*)() const>(&AIS_ViewCube::AxesConeRadius),
             R"#(Returns radius of cone of axes of the trihedron; 3.0 by default.)#" 
          )
        .def("SetAxesConeRadius",
             (void (AIS_ViewCube::*)( double  ) ) static_cast<void (AIS_ViewCube::*)( double  ) >(&AIS_ViewCube::SetAxesConeRadius),
             R"#(Sets radius of cone of axes of the trihedron.)#"  , py::arg("theRadius")
          )
        .def("AxesSphereRadius",
             (double (AIS_ViewCube::*)() const) static_cast<double (AIS_ViewCube::*)() const>(&AIS_ViewCube::AxesSphereRadius),
             R"#(Returns radius of sphere (central point) of the trihedron; 4.0 by default.)#" 
          )
        .def("SetAxesSphereRadius",
             (void (AIS_ViewCube::*)( double  ) ) static_cast<void (AIS_ViewCube::*)( double  ) >(&AIS_ViewCube::SetAxesSphereRadius),
             R"#(Sets radius of sphere (central point) of the trihedron.)#"  , py::arg("theRadius")
          )
        .def("ToDrawAxes",
             (bool (AIS_ViewCube::*)() const) static_cast<bool (AIS_ViewCube::*)() const>(&AIS_ViewCube::ToDrawAxes),
             R"#(Returns TRUE if trihedron is drawn; TRUE by default.)#" 
          )
        .def("SetDrawAxes",
             (void (AIS_ViewCube::*)( bool  ) ) static_cast<void (AIS_ViewCube::*)( bool  ) >(&AIS_ViewCube::SetDrawAxes),
             R"#(Enable/disable drawing of trihedron.)#"  , py::arg("theValue")
          )
        .def("ToDrawEdges",
             (bool (AIS_ViewCube::*)() const) static_cast<bool (AIS_ViewCube::*)() const>(&AIS_ViewCube::ToDrawEdges),
             R"#(Returns TRUE if edges of View Cube is drawn; TRUE by default.)#" 
          )
        .def("SetDrawEdges",
             (void (AIS_ViewCube::*)( bool  ) ) static_cast<void (AIS_ViewCube::*)( bool  ) >(&AIS_ViewCube::SetDrawEdges),
             R"#(Enable/disable drawing of edges of View Cube.)#"  , py::arg("theValue")
          )
        .def("ToDrawVertices",
             (bool (AIS_ViewCube::*)() const) static_cast<bool (AIS_ViewCube::*)() const>(&AIS_ViewCube::ToDrawVertices),
             R"#(Return TRUE if vertices (vertex) of View Cube is drawn; TRUE by default.)#" 
          )
        .def("SetDrawVertices",
             (void (AIS_ViewCube::*)( bool  ) ) static_cast<void (AIS_ViewCube::*)( bool  ) >(&AIS_ViewCube::SetDrawVertices),
             R"#(Enable/disable drawing of vertices (corners) of View Cube.)#"  , py::arg("theValue")
          )
        .def("IsYup",
             (bool (AIS_ViewCube::*)() const) static_cast<bool (AIS_ViewCube::*)() const>(&AIS_ViewCube::IsYup),
             R"#(Return TRUE if application expects Y-up viewer orientation instead of Z-up; FALSE by default.)#" 
          )
        .def("SetYup",
             (void (AIS_ViewCube::*)( bool ,  bool  ) ) static_cast<void (AIS_ViewCube::*)( bool ,  bool  ) >(&AIS_ViewCube::SetYup),
             R"#(Set if application expects Y-up viewer orientation instead of Z-up.)#"  , py::arg("theIsYup"),  py::arg("theToUpdateLabels")=static_cast<bool>(true)
          )
        .def("SetBoxColor",
             (void (AIS_ViewCube::*)(  const Quantity_Color &  ) ) static_cast<void (AIS_ViewCube::*)(  const Quantity_Color &  ) >(&AIS_ViewCube::SetBoxColor),
             R"#(Set new value of front color for the 3D part of object.)#"  , py::arg("theColor")
          )
        .def("BoxTransparency",
             (double (AIS_ViewCube::*)() const) static_cast<double (AIS_ViewCube::*)() const>(&AIS_ViewCube::BoxTransparency),
             R"#(Return transparency for 3D part of object.)#" 
          )
        .def("SetBoxTransparency",
             (void (AIS_ViewCube::*)( double  ) ) static_cast<void (AIS_ViewCube::*)( double  ) >(&AIS_ViewCube::SetBoxTransparency),
             R"#(Set new value of transparency for 3D part of object.)#"  , py::arg("theValue")
          )
        .def("SetInnerColor",
             (void (AIS_ViewCube::*)(  const Quantity_Color &  ) ) static_cast<void (AIS_ViewCube::*)(  const Quantity_Color &  ) >(&AIS_ViewCube::SetInnerColor),
             R"#(Set color of sides back material. Alias for:)#"  , py::arg("theColor")
          )
        .def("BoxSideLabel",
             (TCollection_AsciiString (AIS_ViewCube::*)( V3d_TypeOfOrientation  ) const) static_cast<TCollection_AsciiString (AIS_ViewCube::*)( V3d_TypeOfOrientation  ) const>(&AIS_ViewCube::BoxSideLabel),
             R"#(Return box side label or empty string if undefined. Default labels: FRONT, BACK, LEFT, RIGHT, TOP, BOTTOM.)#"  , py::arg("theSide")
          )
        .def("SetBoxSideLabel",
             (void (AIS_ViewCube::*)(  const V3d_TypeOfOrientation ,   const TCollection_AsciiString &  ) ) static_cast<void (AIS_ViewCube::*)(  const V3d_TypeOfOrientation ,   const TCollection_AsciiString &  ) >(&AIS_ViewCube::SetBoxSideLabel),
             R"#(Set box side label.)#"  , py::arg("theSide"),  py::arg("theLabel")
          )
        .def("SetTextColor",
             (void (AIS_ViewCube::*)(  const Quantity_Color &  ) ) static_cast<void (AIS_ViewCube::*)(  const Quantity_Color &  ) >(&AIS_ViewCube::SetTextColor),
             R"#(Set color of text labels on box sides. Alias for:)#"  , py::arg("theColor")
          )
        .def("SetFont",
             (void (AIS_ViewCube::*)(  const TCollection_AsciiString &  ) ) static_cast<void (AIS_ViewCube::*)(  const TCollection_AsciiString &  ) >(&AIS_ViewCube::SetFont),
             R"#(Set font name that is used for displaying of sides and axes text. Alias for:)#"  , py::arg("theFont")
          )
        .def("FontHeight",
             (double (AIS_ViewCube::*)() const) static_cast<double (AIS_ViewCube::*)() const>(&AIS_ViewCube::FontHeight),
             R"#(Return height of font)#" 
          )
        .def("SetFontHeight",
             (void (AIS_ViewCube::*)( double  ) ) static_cast<void (AIS_ViewCube::*)( double  ) >(&AIS_ViewCube::SetFontHeight),
             R"#(Change font height. Alias for:)#"  , py::arg("theValue")
          )
        .def("AxisLabel",
             (TCollection_AsciiString (AIS_ViewCube::*)( Prs3d_DatumParts  ) const) static_cast<TCollection_AsciiString (AIS_ViewCube::*)( Prs3d_DatumParts  ) const>(&AIS_ViewCube::AxisLabel),
             R"#(Return axes labels or empty string if undefined. Default labels: X, Y, Z.)#"  , py::arg("theAxis")
          )
        .def("SetAxesLabels",
             (void (AIS_ViewCube::*)(  const TCollection_AsciiString & ,   const TCollection_AsciiString & ,   const TCollection_AsciiString &  ) ) static_cast<void (AIS_ViewCube::*)(  const TCollection_AsciiString & ,   const TCollection_AsciiString & ,   const TCollection_AsciiString &  ) >(&AIS_ViewCube::SetAxesLabels),
             R"#(Set axes labels.)#"  , py::arg("theX"),  py::arg("theY"),  py::arg("theZ")
          )
        .def("SetColor",
             (void (AIS_ViewCube::*)(  const Quantity_Color &  ) ) static_cast<void (AIS_ViewCube::*)(  const Quantity_Color &  ) >(&AIS_ViewCube::SetColor),
             R"#(Set new value of color for the whole object.)#"  , py::arg("theColor")
          )
        .def("UnsetColor",
             (void (AIS_ViewCube::*)() ) static_cast<void (AIS_ViewCube::*)() >(&AIS_ViewCube::UnsetColor),
             R"#(Reset color for the whole object.)#" 
          )
        .def("SetTransparency",
             (void (AIS_ViewCube::*)(  const double  ) ) static_cast<void (AIS_ViewCube::*)(  const double  ) >(&AIS_ViewCube::SetTransparency),
             R"#(Set new value of transparency for the whole object.)#"  , py::arg("theValue")
          )
        .def("UnsetTransparency",
             (void (AIS_ViewCube::*)() ) static_cast<void (AIS_ViewCube::*)() >(&AIS_ViewCube::UnsetTransparency),
             R"#(Reset transparency for the whole object.)#" 
          )
        .def("SetMaterial",
             (void (AIS_ViewCube::*)(  const Graphic3d_MaterialAspect &  ) ) static_cast<void (AIS_ViewCube::*)(  const Graphic3d_MaterialAspect &  ) >(&AIS_ViewCube::SetMaterial),
             R"#(Sets the material for the interactive object.)#"  , py::arg("theMat")
          )
        .def("UnsetMaterial",
             (void (AIS_ViewCube::*)() ) static_cast<void (AIS_ViewCube::*)() >(&AIS_ViewCube::UnsetMaterial),
             R"#(Sets the material for the interactive object.)#" 
          )
        .def("Duration",
             (double (AIS_ViewCube::*)() const) static_cast<double (AIS_ViewCube::*)() const>(&AIS_ViewCube::Duration),
             R"#(Return duration of animation in seconds; 0.5 sec by default)#" 
          )
        .def("SetDuration",
             (void (AIS_ViewCube::*)( double  ) ) static_cast<void (AIS_ViewCube::*)( double  ) >(&AIS_ViewCube::SetDuration),
             R"#(Set duration of animation.)#"  , py::arg("theValue")
          )
        .def("ToResetCameraUp",
             (bool (AIS_ViewCube::*)() const) static_cast<bool (AIS_ViewCube::*)() const>(&AIS_ViewCube::ToResetCameraUp),
             R"#(Return TRUE if new camera Up direction should be always set to default value for a new camera Direction; FALSE by default. When this flag is FALSE, the new camera Up will be set as current Up orthogonalized to the new camera Direction, and will set to default Up on second click.)#" 
          )
        .def("SetResetCamera",
             (void (AIS_ViewCube::*)( bool  ) ) static_cast<void (AIS_ViewCube::*)( bool  ) >(&AIS_ViewCube::SetResetCamera),
             R"#(Set if new camera Up direction should be always set to default value for a new camera Direction.)#"  , py::arg("theToReset")
          )
        .def("ToFitSelected",
             (bool (AIS_ViewCube::*)() const) static_cast<bool (AIS_ViewCube::*)() const>(&AIS_ViewCube::ToFitSelected),
             R"#(Return TRUE if animation should fit selected objects and FALSE to fit entire scene; TRUE by default.)#" 
          )
        .def("SetFitSelected",
             (void (AIS_ViewCube::*)( bool  ) ) static_cast<void (AIS_ViewCube::*)( bool  ) >(&AIS_ViewCube::SetFitSelected),
             R"#(Set if animation should fit selected objects or to fit entire scene.)#"  , py::arg("theToFitSelected")
          )
        .def("HasAnimation",
             (bool (AIS_ViewCube::*)() const) static_cast<bool (AIS_ViewCube::*)() const>(&AIS_ViewCube::HasAnimation),
             R"#(Returns TRUE if View Cube has unfinished animation of view camera.)#" 
          )
        .def("StartAnimation",
             (void (AIS_ViewCube::*)(  const handle<AIS_ViewCubeOwner> &  ) ) static_cast<void (AIS_ViewCube::*)(  const handle<AIS_ViewCubeOwner> &  ) >(&AIS_ViewCube::StartAnimation),
             R"#(Start camera transformation corresponding to the input detected owner.)#"  , py::arg("theOwner")
          )
        .def("UpdateAnimation",
             (bool (AIS_ViewCube::*)(  const bool  ) ) static_cast<bool (AIS_ViewCube::*)(  const bool  ) >(&AIS_ViewCube::UpdateAnimation),
             R"#(Perform one step of current camera transformation. theToUpdate[in] enable/disable update of view.)#"  , py::arg("theToUpdate")
          )
        .def("HandleClick",
             (void (AIS_ViewCube::*)(  const handle<AIS_ViewCubeOwner> &  ) ) static_cast<void (AIS_ViewCube::*)(  const handle<AIS_ViewCubeOwner> &  ) >(&AIS_ViewCube::HandleClick),
             R"#(Perform camera transformation corresponding to the input detected owner.)#"  , py::arg("theOwner")
          )
        .def("AcceptDisplayMode",
             (bool (AIS_ViewCube::*)(  const int  ) const) static_cast<bool (AIS_ViewCube::*)(  const int  ) const>(&AIS_ViewCube::AcceptDisplayMode),
             R"#(Return TRUE for supported display mode.)#"  , py::arg("theMode")
          )
        .def("GlobalSelOwner",
             (handle<SelectMgr_EntityOwner> (AIS_ViewCube::*)() const) static_cast<handle<SelectMgr_EntityOwner> (AIS_ViewCube::*)() const>(&AIS_ViewCube::GlobalSelOwner),
             R"#(Global selection has no meaning for this class.)#" 
          )
        .def("Compute",
             (void (AIS_ViewCube::*)(  const handle<PrsMgr_PresentationManager> & ,   const handle<Prs3d_Presentation> & ,   const int  ) ) static_cast<void (AIS_ViewCube::*)(  const handle<PrsMgr_PresentationManager> & ,   const handle<Prs3d_Presentation> & ,   const int  ) >(&AIS_ViewCube::Compute),
             R"#(Compute 3D part of View Cube.)#"  , py::arg("thePrsMgr"),  py::arg("thePrs"),  py::arg("theMode")=static_cast< const int>(0)
          )
        .def("ComputeSelection",
             (void (AIS_ViewCube::*)(  const handle<SelectMgr_Selection> & ,   const int  ) ) static_cast<void (AIS_ViewCube::*)(  const handle<SelectMgr_Selection> & ,   const int  ) >(&AIS_ViewCube::ComputeSelection),
             R"#(Redefine computing of sensitive entities for View Cube.)#"  , py::arg("theSelection"),  py::arg("theMode")
          )
        .def("IsAutoHilight",
             (bool (AIS_ViewCube::*)() const) static_cast<bool (AIS_ViewCube::*)() const>(&AIS_ViewCube::IsAutoHilight),
             R"#(Disables auto highlighting to use HilightSelected() and HilightOwnerWithColor() overridden methods.)#" 
          )
        .def("ClearSelected",
             (void (AIS_ViewCube::*)() ) static_cast<void (AIS_ViewCube::*)() >(&AIS_ViewCube::ClearSelected),
             R"#(Method which clear all selected owners belonging to this selectable object.)#" 
          )
        .def("HilightOwnerWithColor",
             (void (AIS_ViewCube::*)(  const handle<PrsMgr_PresentationManager> & ,   const handle<Prs3d_Drawer> & ,   const handle<SelectMgr_EntityOwner> &  ) ) static_cast<void (AIS_ViewCube::*)(  const handle<PrsMgr_PresentationManager> & ,   const handle<Prs3d_Drawer> & ,   const handle<SelectMgr_EntityOwner> &  ) >(&AIS_ViewCube::HilightOwnerWithColor),
             R"#(Method which highlights input owner belonging to this selectable object.)#"  , py::arg("thePM"),  py::arg("theStyle"),  py::arg("theOwner")
          )
        .def("HilightSelected",
             (void (AIS_ViewCube::*)(  const handle<PrsMgr_PresentationManager> & ,   const NCollection_Sequence<handle<SelectMgr_EntityOwner>> &  ) ) static_cast<void (AIS_ViewCube::*)(  const handle<PrsMgr_PresentationManager> & ,   const NCollection_Sequence<handle<SelectMgr_EntityOwner>> &  ) >(&AIS_ViewCube::HilightSelected),
             R"#(Method which draws selected owners.)#"  , py::arg("thePM"),  py::arg("theSeq")
          )
        .def("UnsetAttributes",
             (void (AIS_ViewCube::*)() ) static_cast<void (AIS_ViewCube::*)() >(&AIS_ViewCube::UnsetAttributes),
             R"#(Set default parameters for visual attributes)#" 
          )
        .def("UnsetHilightAttributes",
             (void (AIS_ViewCube::*)() ) static_cast<void (AIS_ViewCube::*)() >(&AIS_ViewCube::UnsetHilightAttributes),
             R"#(Set default parameters for dynamic highlighting attributes, reset highlight attributes)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_ViewCube::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_ViewCube::get_type_descriptor),
                    R"#()#" 
          )
        .def_static("IsBoxSide_s",
                    (bool (*)( V3d_TypeOfOrientation  ) ) static_cast<bool (*)( V3d_TypeOfOrientation  ) >(&AIS_ViewCube::IsBoxSide),
                    R"#(Return TRUE if specified orientation belongs to box side.)#"  , py::arg("theOrient")
          )
        .def_static("IsBoxEdge_s",
                    (bool (*)( V3d_TypeOfOrientation  ) ) static_cast<bool (*)( V3d_TypeOfOrientation  ) >(&AIS_ViewCube::IsBoxEdge),
                    R"#(Return TRUE if specified orientation belongs to box edge.)#"  , py::arg("theOrient")
          )
        .def_static("IsBoxCorner_s",
                    (bool (*)( V3d_TypeOfOrientation  ) ) static_cast<bool (*)( V3d_TypeOfOrientation  ) >(&AIS_ViewCube::IsBoxCorner),
                    R"#(Return TRUE if specified orientation belongs to box corner (vertex).)#"  , py::arg("theOrient")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_ViewCube::*)() const) static_cast< const handle<Standard_Type> & (AIS_ViewCube::*)() const>(&AIS_ViewCube::DynamicType),
             R"#()#"
             
         )
       .def("ViewAnimation",
             ( const handle<AIS_AnimationCamera> & (AIS_ViewCube::*)() const) static_cast< const handle<AIS_AnimationCamera> & (AIS_ViewCube::*)() const>(&AIS_ViewCube::ViewAnimation),
             R"#(Return view animation.)#"
             
         )
       .def("BoxSideStyle",
             ( const handle<Prs3d_ShadingAspect> & (AIS_ViewCube::*)() const) static_cast< const handle<Prs3d_ShadingAspect> & (AIS_ViewCube::*)() const>(&AIS_ViewCube::BoxSideStyle),
             R"#(Return shading style of box sides.)#"
             
         )
       .def("BoxEdgeStyle",
             ( const handle<Prs3d_ShadingAspect> & (AIS_ViewCube::*)() const) static_cast< const handle<Prs3d_ShadingAspect> & (AIS_ViewCube::*)() const>(&AIS_ViewCube::BoxEdgeStyle),
             R"#(Return shading style of box edges.)#"
             
         )
       .def("BoxCornerStyle",
             ( const handle<Prs3d_ShadingAspect> & (AIS_ViewCube::*)() const) static_cast< const handle<Prs3d_ShadingAspect> & (AIS_ViewCube::*)() const>(&AIS_ViewCube::BoxCornerStyle),
             R"#(Return shading style of box corners.)#"
             
         )
       .def("BoxColor",
             ( const Quantity_Color & (AIS_ViewCube::*)() const) static_cast< const Quantity_Color & (AIS_ViewCube::*)() const>(&AIS_ViewCube::BoxColor),
             R"#(Return value of front color for the 3D part of object.)#"
             
         )
       .def("InnerColor",
             ( const Quantity_Color & (AIS_ViewCube::*)() const) static_cast< const Quantity_Color & (AIS_ViewCube::*)() const>(&AIS_ViewCube::InnerColor),
             R"#(Return color of sides back material.)#"
             
         )
       .def("TextColor",
             ( const Quantity_Color & (AIS_ViewCube::*)() const) static_cast< const Quantity_Color & (AIS_ViewCube::*)() const>(&AIS_ViewCube::TextColor),
             R"#(Return text color of labels of box sides; BLACK by default.)#"
             
         )
       .def("Font",
             ( const TCollection_AsciiString & (AIS_ViewCube::*)() const) static_cast< const TCollection_AsciiString & (AIS_ViewCube::*)() const>(&AIS_ViewCube::Font),
             R"#(Return font name that is used for displaying of sides and axes text. Alias for:)#"
             
         )
;

    // Class AIS_XRTrackedDevice from ./opencascade/AIS_XRTrackedDevice.hxx
    klass = m.attr("AIS_XRTrackedDevice");


    // nested enums

    static_cast<py::class_<AIS_XRTrackedDevice ,opencascade::handle<AIS_XRTrackedDevice>  , AIS_InteractiveObject >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<Graphic3d_ArrayOfTriangles> &, const handle<Image_Texture> & >()  , py::arg("theTris"),  py::arg("theTexture") )
    // custom constructors
    // methods
        .def("Role",
             (Aspect_XRTrackedDeviceRole (AIS_XRTrackedDevice::*)() const) static_cast<Aspect_XRTrackedDeviceRole (AIS_XRTrackedDevice::*)() const>(&AIS_XRTrackedDevice::Role),
             R"#(Return device role.)#" 
          )
        .def("SetRole",
             (void (AIS_XRTrackedDevice::*)( Aspect_XRTrackedDeviceRole  ) ) static_cast<void (AIS_XRTrackedDevice::*)( Aspect_XRTrackedDeviceRole  ) >(&AIS_XRTrackedDevice::SetRole),
             R"#(Set device role.)#"  , py::arg("theRole")
          )
        .def("SetLaserColor",
             (void (AIS_XRTrackedDevice::*)(  const Quantity_Color &  ) ) static_cast<void (AIS_XRTrackedDevice::*)(  const Quantity_Color &  ) >(&AIS_XRTrackedDevice::SetLaserColor),
             R"#(Set laser color.)#"  , py::arg("theColor")
          )
        .def("LaserLength",
             (float (AIS_XRTrackedDevice::*)() const) static_cast<float (AIS_XRTrackedDevice::*)() const>(&AIS_XRTrackedDevice::LaserLength),
             R"#(Return laser length.)#" 
          )
        .def("SetLaserLength",
             (void (AIS_XRTrackedDevice::*)( float  ) ) static_cast<void (AIS_XRTrackedDevice::*)( float  ) >(&AIS_XRTrackedDevice::SetLaserLength),
             R"#(Set laser length.)#"  , py::arg("theLength")
          )
        .def("UnitFactor",
             (float (AIS_XRTrackedDevice::*)() const) static_cast<float (AIS_XRTrackedDevice::*)() const>(&AIS_XRTrackedDevice::UnitFactor),
             R"#(Return unit scale factor.)#" 
          )
        .def("SetUnitFactor",
             (void (AIS_XRTrackedDevice::*)( float  ) ) static_cast<void (AIS_XRTrackedDevice::*)( float  ) >(&AIS_XRTrackedDevice::SetUnitFactor),
             R"#(Set unit scale factor.)#"  , py::arg("theFactor")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_XRTrackedDevice::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_XRTrackedDevice::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_XRTrackedDevice::*)() const) static_cast< const handle<Standard_Type> & (AIS_XRTrackedDevice::*)() const>(&AIS_XRTrackedDevice::DynamicType),
             R"#()#"
             
         )
       .def("LaserColor",
             ( const Quantity_Color & (AIS_XRTrackedDevice::*)() const) static_cast< const Quantity_Color & (AIS_XRTrackedDevice::*)() const>(&AIS_XRTrackedDevice::LaserColor),
             R"#(Return laser color.)#"
             
         )
;

    // Class AIS_AnimationAxisRotation from ./opencascade/AIS_AnimationAxisRotation.hxx
    klass = m.attr("AIS_AnimationAxisRotation");


    // nested enums

    static_cast<py::class_<AIS_AnimationAxisRotation ,opencascade::handle<AIS_AnimationAxisRotation>  , AIS_BaseAnimationObject >>(klass)
    // constructors
        .def(py::init<  const TCollection_AsciiString &, const handle<AIS_InteractiveContext> &, const handle<AIS_InteractiveObject> &, const gp_Ax1 &, const double, const double >()  , py::arg("theAnimationName"),  py::arg("theContext"),  py::arg("theObject"),  py::arg("theAxis"),  py::arg("theAngleStart"),  py::arg("theAngleEnd") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_AnimationAxisRotation::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_AnimationAxisRotation::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_AnimationAxisRotation::*)() const) static_cast< const handle<Standard_Type> & (AIS_AnimationAxisRotation::*)() const>(&AIS_AnimationAxisRotation::DynamicType),
             R"#()#"
             
         )
;

    // Class AIS_AnimationObject from ./opencascade/AIS_AnimationObject.hxx
    klass = m.attr("AIS_AnimationObject");


    // nested enums

    static_cast<py::class_<AIS_AnimationObject ,opencascade::handle<AIS_AnimationObject>  , AIS_BaseAnimationObject >>(klass)
    // constructors
        .def(py::init<  const TCollection_AsciiString &, const handle<AIS_InteractiveContext> &, const handle<AIS_InteractiveObject> &, const gp_Trsf &, const gp_Trsf & >()  , py::arg("theAnimationName"),  py::arg("theContext"),  py::arg("theObject"),  py::arg("theTrsfStart"),  py::arg("theTrsfEnd") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_AnimationObject::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_AnimationObject::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_AnimationObject::*)() const) static_cast< const handle<Standard_Type> & (AIS_AnimationObject::*)() const>(&AIS_AnimationObject::DynamicType),
             R"#()#"
             
         )
;

    // Class AIS_ColoredShape from ./opencascade/AIS_ColoredShape.hxx
    klass = m.attr("AIS_ColoredShape");


    // nested enums

    static_cast<py::class_<AIS_ColoredShape ,opencascade::handle<AIS_ColoredShape>  , AIS_Shape >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("theShape") )
        .def(py::init<  const handle<AIS_Shape> & >()  , py::arg("theShape") )
    // custom constructors
    // methods
        .def("CustomAspects",
             (handle<AIS_ColoredDrawer> (AIS_ColoredShape::*)(  const TopoDS_Shape &  ) ) static_cast<handle<AIS_ColoredDrawer> (AIS_ColoredShape::*)(  const TopoDS_Shape &  ) >(&AIS_ColoredShape::CustomAspects),
             R"#(Customize properties of specified sub-shape. The shape will be stored in the map but ignored, if it is not sub-shape of main Shape! This method can be used to mark sub-shapes with customizable properties.)#"  , py::arg("theShape")
          )
        .def("ClearCustomAspects",
             (void (AIS_ColoredShape::*)() ) static_cast<void (AIS_ColoredShape::*)() >(&AIS_ColoredShape::ClearCustomAspects),
             R"#(Reset the map of custom sub-shape aspects.)#" 
          )
        .def("UnsetCustomAspects",
             (void (AIS_ColoredShape::*)(  const TopoDS_Shape & ,   const bool  ) ) static_cast<void (AIS_ColoredShape::*)(  const TopoDS_Shape & ,   const bool  ) >(&AIS_ColoredShape::UnsetCustomAspects),
             R"#(Reset custom properties of specified sub-shape.)#"  , py::arg("theShape"),  py::arg("theToUnregister")=static_cast< const bool>(false)
          )
        .def("SetCustomColor",
             (void (AIS_ColoredShape::*)(  const TopoDS_Shape & ,   const Quantity_Color &  ) ) static_cast<void (AIS_ColoredShape::*)(  const TopoDS_Shape & ,   const Quantity_Color &  ) >(&AIS_ColoredShape::SetCustomColor),
             R"#(Customize color of specified sub-shape)#"  , py::arg("theShape"),  py::arg("theColor")
          )
        .def("SetCustomTransparency",
             (void (AIS_ColoredShape::*)(  const TopoDS_Shape & ,  double  ) ) static_cast<void (AIS_ColoredShape::*)(  const TopoDS_Shape & ,  double  ) >(&AIS_ColoredShape::SetCustomTransparency),
             R"#(Customize transparency of specified sub-shape)#"  , py::arg("theShape"),  py::arg("theTransparency")
          )
        .def("SetCustomWidth",
             (void (AIS_ColoredShape::*)(  const TopoDS_Shape & ,   const double  ) ) static_cast<void (AIS_ColoredShape::*)(  const TopoDS_Shape & ,   const double  ) >(&AIS_ColoredShape::SetCustomWidth),
             R"#(Customize line width of specified sub-shape)#"  , py::arg("theShape"),  py::arg("theLineWidth")
          )
        .def("SetColor",
             (void (AIS_ColoredShape::*)(  const Quantity_Color &  ) ) static_cast<void (AIS_ColoredShape::*)(  const Quantity_Color &  ) >(&AIS_ColoredShape::SetColor),
             R"#(Setup color of entire shape.)#"  , py::arg("theColor")
          )
        .def("SetWidth",
             (void (AIS_ColoredShape::*)(  const double  ) ) static_cast<void (AIS_ColoredShape::*)(  const double  ) >(&AIS_ColoredShape::SetWidth),
             R"#(Setup line width of entire shape.)#"  , py::arg("theLineWidth")
          )
        .def("SetTransparency",
             (void (AIS_ColoredShape::*)(  const double  ) ) static_cast<void (AIS_ColoredShape::*)(  const double  ) >(&AIS_ColoredShape::SetTransparency),
             R"#(Sets transparency value.)#"  , py::arg("theValue")
          )
        .def("SetMaterial",
             (void (AIS_ColoredShape::*)(  const Graphic3d_MaterialAspect &  ) ) static_cast<void (AIS_ColoredShape::*)(  const Graphic3d_MaterialAspect &  ) >(&AIS_ColoredShape::SetMaterial),
             R"#(Sets the material aspect.)#"  , py::arg("theAspect")
          )
        .def("UnsetTransparency",
             (void (AIS_ColoredShape::*)() ) static_cast<void (AIS_ColoredShape::*)() >(&AIS_ColoredShape::UnsetTransparency),
             R"#(Removes the setting for transparency in the reconstructed compound shape.)#" 
          )
        .def("UnsetWidth",
             (void (AIS_ColoredShape::*)() ) static_cast<void (AIS_ColoredShape::*)() >(&AIS_ColoredShape::UnsetWidth),
             R"#(Setup line width of entire shape.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_ColoredShape::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_ColoredShape::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("CustomAspectsMap",
             ( const NCollection_DataMap<TopoDS_Shape, handle<AIS_ColoredDrawer>, TopTools_ShapeMapHasher> & (AIS_ColoredShape::*)() const) static_cast< const NCollection_DataMap<TopoDS_Shape, handle<AIS_ColoredDrawer>, TopTools_ShapeMapHasher> & (AIS_ColoredShape::*)() const>(&AIS_ColoredShape::CustomAspectsMap),
             R"#(Return the map of custom aspects.)#"
             
         )
       .def("ChangeCustomAspectsMap",
             (NCollection_DataMap<TopoDS_Shape, handle<AIS_ColoredDrawer>, TopTools_ShapeMapHasher> & (AIS_ColoredShape::*)() ) static_cast<NCollection_DataMap<TopoDS_Shape, handle<AIS_ColoredDrawer>, TopTools_ShapeMapHasher> & (AIS_ColoredShape::*)() >(&AIS_ColoredShape::ChangeCustomAspectsMap),
             R"#(Return the map of custom aspects.)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_ColoredShape::*)() const) static_cast< const handle<Standard_Type> & (AIS_ColoredShape::*)() const>(&AIS_ColoredShape::DynamicType),
             R"#()#"
             
         )
;

    // Class AIS_TexturedShape from ./opencascade/AIS_TexturedShape.hxx
    klass = m.attr("AIS_TexturedShape");


    // nested enums

    static_cast<py::class_<AIS_TexturedShape ,opencascade::handle<AIS_TexturedShape>  , AIS_Shape >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("theShape") )
    // custom constructors
    // methods
        .def("SetTextureFileName",
             (void (AIS_TexturedShape::*)(  const TCollection_AsciiString &  ) ) static_cast<void (AIS_TexturedShape::*)(  const TCollection_AsciiString &  ) >(&AIS_TexturedShape::SetTextureFileName),
             R"#(Sets the texture source. <theTextureFileName> can specify path to texture image or one of the standard predefined textures. The accepted file types are those used in Image_AlienPixMap with extensions such as rgb, png, jpg and more. To specify the standard predefined texture, the <theTextureFileName> should contain integer - the Graphic3d_NameOfTexture2D enumeration index. Setting texture source using this method resets the source pixmap (if was set previously).)#"  , py::arg("theTextureFileName")
          )
        .def("SetTexturePixMap",
             (void (AIS_TexturedShape::*)(  const handle<Image_PixMap> &  ) ) static_cast<void (AIS_TexturedShape::*)(  const handle<Image_PixMap> &  ) >(&AIS_TexturedShape::SetTexturePixMap),
             R"#(Sets the texture source. <theTexturePixMap> specifies image data. Please note that the data should be in Bottom-Up order, the flag of Image_PixMap::IsTopDown() will be ignored by graphic driver. Setting texture source using this method resets the source by filename (if was set previously).)#"  , py::arg("theTexturePixMap")
          )
        .def("TextureMapState",
             (bool (AIS_TexturedShape::*)() const) static_cast<bool (AIS_TexturedShape::*)() const>(&AIS_TexturedShape::TextureMapState),
             R"#(Returns flag to control texture mapping (for presentation mode 3))#" 
          )
        .def("SetTextureMapOn",
             (void (AIS_TexturedShape::*)() ) static_cast<void (AIS_TexturedShape::*)() >(&AIS_TexturedShape::SetTextureMapOn),
             R"#(Enables texture mapping)#" 
          )
        .def("SetTextureMapOff",
             (void (AIS_TexturedShape::*)() ) static_cast<void (AIS_TexturedShape::*)() >(&AIS_TexturedShape::SetTextureMapOff),
             R"#(Disables texture mapping)#" 
          )
        .def("TextureFile",
             ( const char * (AIS_TexturedShape::*)() const) static_cast< const char * (AIS_TexturedShape::*)() const>(&AIS_TexturedShape::TextureFile),
             R"#(Returns path to the texture file)#" 
          )
        .def("UpdateAttributes",
             (void (AIS_TexturedShape::*)() ) static_cast<void (AIS_TexturedShape::*)() >(&AIS_TexturedShape::UpdateAttributes),
             R"#(Use this method to display the textured shape without recomputing the whole presentation. Use this method when ONLY the texture content has been changed. If other parameters (ie: scale factors, texture origin, texture repeat...) have changed, the whole presentation has to be recomputed:)#" 
          )
        .def("SetColor",
             (void (AIS_TexturedShape::*)(  const Quantity_Color &  ) ) static_cast<void (AIS_TexturedShape::*)(  const Quantity_Color &  ) >(&AIS_TexturedShape::SetColor),
             R"#(Sets the color.)#"  , py::arg("theColor")
          )
        .def("UnsetColor",
             (void (AIS_TexturedShape::*)() ) static_cast<void (AIS_TexturedShape::*)() >(&AIS_TexturedShape::UnsetColor),
             R"#(Removes settings for the color.)#" 
          )
        .def("SetMaterial",
             (void (AIS_TexturedShape::*)(  const Graphic3d_MaterialAspect &  ) ) static_cast<void (AIS_TexturedShape::*)(  const Graphic3d_MaterialAspect &  ) >(&AIS_TexturedShape::SetMaterial),
             R"#(Sets the material aspect.)#"  , py::arg("theAspect")
          )
        .def("UnsetMaterial",
             (void (AIS_TexturedShape::*)() ) static_cast<void (AIS_TexturedShape::*)() >(&AIS_TexturedShape::UnsetMaterial),
             R"#(Removes settings for material aspect.)#" 
          )
        .def("EnableTextureModulate",
             (void (AIS_TexturedShape::*)() ) static_cast<void (AIS_TexturedShape::*)() >(&AIS_TexturedShape::EnableTextureModulate),
             R"#(Enables texture modulation)#" 
          )
        .def("DisableTextureModulate",
             (void (AIS_TexturedShape::*)() ) static_cast<void (AIS_TexturedShape::*)() >(&AIS_TexturedShape::DisableTextureModulate),
             R"#(Disables texture modulation)#" 
          )
        .def("TextureRepeat",
             (bool (AIS_TexturedShape::*)() const) static_cast<bool (AIS_TexturedShape::*)() const>(&AIS_TexturedShape::TextureRepeat),
             R"#(Returns texture repeat flag)#" 
          )
        .def("URepeat",
             (double (AIS_TexturedShape::*)() const) static_cast<double (AIS_TexturedShape::*)() const>(&AIS_TexturedShape::URepeat),
             R"#(Returns texture repeat U value)#" 
          )
        .def("VRepeat",
             (double (AIS_TexturedShape::*)() const) static_cast<double (AIS_TexturedShape::*)() const>(&AIS_TexturedShape::VRepeat),
             R"#(Returns texture repeat V value)#" 
          )
        .def("SetTextureRepeat",
             (void (AIS_TexturedShape::*)(  const bool ,   const double ,   const double  ) ) static_cast<void (AIS_TexturedShape::*)(  const bool ,   const double ,   const double  ) >(&AIS_TexturedShape::SetTextureRepeat),
             R"#(Sets the number of occurrences of the texture on each face. The texture itself is parameterized in (0,1) by (0,1). Each face of the shape to be textured is parameterized in UV space (Umin,Umax) by (Vmin,Vmax). If RepeatYN is set to false, texture coordinates are clamped in the range (0,1)x(0,1) of the face.)#"  , py::arg("theToRepeat"),  py::arg("theURepeat")=static_cast< const double>(1.0),  py::arg("theVRepeat")=static_cast< const double>(1.0)
          )
        .def("TextureOrigin",
             (bool (AIS_TexturedShape::*)() const) static_cast<bool (AIS_TexturedShape::*)() const>(&AIS_TexturedShape::TextureOrigin),
             R"#(Returns true if texture UV origin has been modified)#" 
          )
        .def("TextureUOrigin",
             (double (AIS_TexturedShape::*)() const) static_cast<double (AIS_TexturedShape::*)() const>(&AIS_TexturedShape::TextureUOrigin),
             R"#(Returns texture origin U position (0.0 by default))#" 
          )
        .def("TextureVOrigin",
             (double (AIS_TexturedShape::*)() const) static_cast<double (AIS_TexturedShape::*)() const>(&AIS_TexturedShape::TextureVOrigin),
             R"#(Returns texture origin V position (0.0 by default))#" 
          )
        .def("SetTextureOrigin",
             (void (AIS_TexturedShape::*)(  const bool ,   const double ,   const double  ) ) static_cast<void (AIS_TexturedShape::*)(  const bool ,   const double ,   const double  ) >(&AIS_TexturedShape::SetTextureOrigin),
             R"#(Use this method to change the origin of the texture. The texel (0,0) will be mapped to the surface (UOrigin,VOrigin))#"  , py::arg("theToSetTextureOrigin"),  py::arg("theUOrigin")=static_cast< const double>(0.0),  py::arg("theVOrigin")=static_cast< const double>(0.0)
          )
        .def("TextureScale",
             (bool (AIS_TexturedShape::*)() const) static_cast<bool (AIS_TexturedShape::*)() const>(&AIS_TexturedShape::TextureScale),
             R"#(Returns true if scale factor should be applied to texture mapping)#" 
          )
        .def("TextureScaleU",
             (double (AIS_TexturedShape::*)() const) static_cast<double (AIS_TexturedShape::*)() const>(&AIS_TexturedShape::TextureScaleU),
             R"#(Returns scale factor for U coordinate (1.0 by default))#" 
          )
        .def("TextureScaleV",
             (double (AIS_TexturedShape::*)() const) static_cast<double (AIS_TexturedShape::*)() const>(&AIS_TexturedShape::TextureScaleV),
             R"#(Returns scale factor for V coordinate (1.0 by default))#" 
          )
        .def("SetTextureScale",
             (void (AIS_TexturedShape::*)(  const bool ,   const double ,   const double  ) ) static_cast<void (AIS_TexturedShape::*)(  const bool ,   const double ,   const double  ) >(&AIS_TexturedShape::SetTextureScale),
             R"#(Use this method to scale the texture (percent of the face). You can specify a scale factor for both U and V. Example: if you set ScaleU and ScaleV to 0.5 and you enable texture repeat, the texture will appear twice on the face in each direction.)#"  , py::arg("theToSetTextureScale"),  py::arg("theScaleU")=static_cast< const double>(1.0),  py::arg("theScaleV")=static_cast< const double>(1.0)
          )
        .def("ShowTriangles",
             (bool (AIS_TexturedShape::*)() const) static_cast<bool (AIS_TexturedShape::*)() const>(&AIS_TexturedShape::ShowTriangles),
             R"#(Returns true if displaying of triangles is requested)#" 
          )
        .def("ShowTriangles",
             (void (AIS_TexturedShape::*)(  const bool  ) ) static_cast<void (AIS_TexturedShape::*)(  const bool  ) >(&AIS_TexturedShape::ShowTriangles),
             R"#(Use this method to show the triangulation of the shape (for debugging etc.).)#"  , py::arg("theToShowTriangles")
          )
        .def("TextureModulate",
             (bool (AIS_TexturedShape::*)() const) static_cast<bool (AIS_TexturedShape::*)() const>(&AIS_TexturedShape::TextureModulate),
             R"#(Returns true if texture color modulation is turned on)#" 
          )
        .def("AcceptDisplayMode",
             (bool (AIS_TexturedShape::*)(  const int  ) const) static_cast<bool (AIS_TexturedShape::*)(  const int  ) const>(&AIS_TexturedShape::AcceptDisplayMode),
             R"#(Return true if specified display mode is supported (extends AIS_Shape with Display Mode 3).)#"  , py::arg("theMode")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&AIS_TexturedShape::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&AIS_TexturedShape::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("TexturePixMap",
             ( const handle<Image_PixMap> & (AIS_TexturedShape::*)() const) static_cast< const handle<Image_PixMap> & (AIS_TexturedShape::*)() const>(&AIS_TexturedShape::TexturePixMap),
             R"#(Returns the source pixmap for texture map)#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (AIS_TexturedShape::*)() const) static_cast< const handle<Standard_Type> & (AIS_TexturedShape::*)() const>(&AIS_TexturedShape::DynamicType),
             R"#()#"
             
         )
;

// functions

// ./opencascade/AIS.hxx
// ./opencascade/AIS_Animation.hxx
// ./opencascade/AIS_AnimationAxisRotation.hxx
// ./opencascade/AIS_AnimationCamera.hxx
// ./opencascade/AIS_AnimationObject.hxx
// ./opencascade/AIS_AnimationTimer.hxx
// ./opencascade/AIS_AttributeFilter.hxx
// ./opencascade/AIS_Axis.hxx
// ./opencascade/AIS_BadEdgeFilter.hxx
// ./opencascade/AIS_BaseAnimationObject.hxx
// ./opencascade/AIS_C0RegularityFilter.hxx
// ./opencascade/AIS_CameraFrustum.hxx
// ./opencascade/AIS_Circle.hxx
// ./opencascade/AIS_ColorScale.hxx
// ./opencascade/AIS_ColoredDrawer.hxx
// ./opencascade/AIS_ColoredShape.hxx
// ./opencascade/AIS_ConnectedInteractive.hxx
// ./opencascade/AIS_DisplayMode.hxx
// ./opencascade/AIS_DisplayStatus.hxx
// ./opencascade/AIS_DragAction.hxx
// ./opencascade/AIS_ExclusionFilter.hxx
// ./opencascade/AIS_GlobalStatus.hxx
// ./opencascade/AIS_GraphicTool.hxx
// ./opencascade/AIS_InteractiveContext.hxx
// ./opencascade/AIS_InteractiveObject.hxx
// ./opencascade/AIS_KindOfInteractive.hxx
// ./opencascade/AIS_LightSource.hxx
// ./opencascade/AIS_Line.hxx
// ./opencascade/AIS_Manipulator.hxx
// ./opencascade/AIS_ManipulatorMode.hxx
// ./opencascade/AIS_ManipulatorOwner.hxx
// ./opencascade/AIS_MediaPlayer.hxx
// ./opencascade/AIS_MouseGesture.hxx
// ./opencascade/AIS_MultipleConnectedInteractive.hxx
// ./opencascade/AIS_NavigationMode.hxx
// ./opencascade/AIS_Plane.hxx
// ./opencascade/AIS_PlaneTrihedron.hxx
// ./opencascade/AIS_Point.hxx
// ./opencascade/AIS_PointCloud.hxx
// ./opencascade/AIS_RotationMode.hxx
// ./opencascade/AIS_RubberBand.hxx
// ./opencascade/AIS_SelectStatus.hxx
// ./opencascade/AIS_Selection.hxx
// ./opencascade/AIS_SelectionModesConcurrency.hxx
// ./opencascade/AIS_SelectionScheme.hxx
// ./opencascade/AIS_Shape.hxx
// ./opencascade/AIS_SignatureFilter.hxx
// ./opencascade/AIS_StatusOfDetection.hxx
// ./opencascade/AIS_StatusOfPick.hxx
// ./opencascade/AIS_TextLabel.hxx
// ./opencascade/AIS_TexturedShape.hxx
// ./opencascade/AIS_Triangulation.hxx
// ./opencascade/AIS_Trihedron.hxx
// ./opencascade/AIS_TrihedronOwner.hxx
// ./opencascade/AIS_TrihedronSelectionMode.hxx
// ./opencascade/AIS_TypeFilter.hxx
// ./opencascade/AIS_TypeOfAttribute.hxx
// ./opencascade/AIS_TypeOfAxis.hxx
// ./opencascade/AIS_TypeOfIso.hxx
// ./opencascade/AIS_TypeOfPlane.hxx
// ./opencascade/AIS_ViewController.hxx
// ./opencascade/AIS_ViewCube.hxx
// ./opencascade/AIS_ViewInputBuffer.hxx
// ./opencascade/AIS_WalkDelta.hxx
// ./opencascade/AIS_XRTrackedDevice.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
