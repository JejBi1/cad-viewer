
// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;


// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Quantity_Color.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <XSControl_WorkSession.hxx>
#include <TDocStd_Document.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <XSControl_WorkSession.hxx>
#include <TDocStd_Document.hxx>

// module includes
#include <IGESCAFControl.hxx>
#include <IGESCAFControl_Reader.hxx>
#include <IGESCAFControl_Writer.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module
#include <DE_ConfigurationContext.hxx>

// Module definiiton
void register_IGESCAFControl_enums(py::module &main_module) {


py::module m = main_module.def_submodule("IGESCAFControl", R"#()#");

// add namespaces as submodules

// user-defined inclusion per module in the body

// enums

//Python trampoline classes

// pre-register typdefs+classes (topologically sorted)
    py::class_<IGESCAFControl , shared_ptr<IGESCAFControl>  >(
      m,
      "IGESCAFControl",R"#(Provides high-level API to translate IGES file to and from DECAF document)#"
    );
    py::class_<IGESCAFControl_Reader , shared_ptr<IGESCAFControl_Reader>  , IGESControl_Reader >(
      m,
      "IGESCAFControl_Reader",R"#(Provides a tool to read IGES file and put it into DECAF document. Besides transfer of shapes (including assemblies) provided by IGESControl, supports also colors and part names IGESCAFControl_Reader reader; Methods for translation of an IGES file: reader.ReadFile("filename"); reader.Transfer(Document); or reader.Perform("filename",doc); Methods for managing reading attributes. Colors reader.SetColorMode(colormode); bool colormode = reader.GetColorMode(); Layers reader.SetLayerMode(layermode); bool layermode = reader.GetLayerMode(); Names reader.SetNameMode(namemode); bool namemode = reader.GetNameMode();)#"
    );
    py::class_<IGESCAFControl_Writer , shared_ptr<IGESCAFControl_Writer>  , IGESControl_Writer >(
      m,
      "IGESCAFControl_Writer",R"#(Provides a tool to write DECAF document to the IGES file. Besides transfer of shapes (including assemblies) provided by IGESControl, supports also colors and part names IGESCAFControl_Writer writer(); Methods for writing IGES file: writer.Transfer (Document); writer.Write("filename") or writer.Write(OStream) or writer.Perform(Document,"filename"); Methods for managing the writing of attributes. Colors writer.SetColorMode(colormode); bool colormode = writer.GetColorMode(); Layers writer.SetLayerMode(layermode); bool layermode = writer.GetLayerMode(); Names writer.SetNameMode(namemode); bool namemode = writer.GetNameMode();)#"
    );

// preregister user-defined template specializations

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
