
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Pln.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Lin.hxx>
#include <gp_Pln.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <Bnd_B2.hxx>
#include <Bnd_B3.hxx>
#include <Bnd_BoundSortBox.hxx>
#include <Bnd_Box.hxx>
#include <Bnd_Box2d.hxx>
#include <Bnd_OBB.hxx>
#include <Bnd_Range.hxx>
#include <Bnd_Sphere.hxx>
#include <Bnd_Tools.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_Bnd(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("Bnd"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes

// classes

    // Class Bnd_BoundSortBox from ./opencascade/Bnd_BoundSortBox.hxx
    klass = m.attr("Bnd_BoundSortBox");


    // nested enums

    static_cast<py::class_<Bnd_BoundSortBox , shared_ptr<Bnd_BoundSortBox>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Initialize",
             (void (Bnd_BoundSortBox::*)(  const handle<NCollection_HArray1<Bnd_Box>> &  ) ) static_cast<void (Bnd_BoundSortBox::*)(  const handle<NCollection_HArray1<Bnd_Box>> &  ) >(&Bnd_BoundSortBox::Initialize),
             R"#(Initializes this comparison algorithm with the set of boxes.)#"  , py::arg("theSetOfBoxes")
          )
        .def("Initialize",
             (void (Bnd_BoundSortBox::*)(  const Bnd_Box & ,   const handle<NCollection_HArray1<Bnd_Box>> &  ) ) static_cast<void (Bnd_BoundSortBox::*)(  const Bnd_Box & ,   const handle<NCollection_HArray1<Bnd_Box>> &  ) >(&Bnd_BoundSortBox::Initialize),
             R"#(Initializes this comparison algorithm with the set of boxes and the bounding box that encloses all those boxes. This version of initialization can be used if complete box is known in advance to avoid calculating it again inside the algorithm.)#"  , py::arg("theEnclosingBox"),  py::arg("theSetOfBoxes")
          )
        .def("Initialize",
             (void (Bnd_BoundSortBox::*)(  const Bnd_Box & ,   const int  ) ) static_cast<void (Bnd_BoundSortBox::*)(  const Bnd_Box & ,   const int  ) >(&Bnd_BoundSortBox::Initialize),
             R"#(Initializes this comparison algorithm with the bounding box that encloses all the boxes that will be used by this algorithm. and the expected number of those boxes. Boxes to be considered can then be added using the Add() method.)#"  , py::arg("theEnclosingBox"),  py::arg("theNbBoxes")
          )
        .def("Add",
             (void (Bnd_BoundSortBox::*)(  const Bnd_Box & ,   const int  ) ) static_cast<void (Bnd_BoundSortBox::*)(  const Bnd_Box & ,   const int  ) >(&Bnd_BoundSortBox::Add),
             R"#(Adds the bounding box theBox at position boxIndex in the internal array of boxes to be sorted by this comparison algorithm. This function is used only in conjunction with the Initialize(const Bnd_Box&, const int) method. Exceptions: - Standard_OutOfRange if boxIndex is not in the range [ 1,nbComponents ] where nbComponents is the maximum number of bounding boxes declared for this algorithm at initialization. - Standard_MultiplyDefined if a box already exists at position theIndex in the internal array of boxes.)#"  , py::arg("theBox"),  py::arg("theIndex")
          )
        .def("Compare",
             ( const NCollection_List<int> & (Bnd_BoundSortBox::*)(  const Bnd_Box &  ) ) static_cast< const NCollection_List<int> & (Bnd_BoundSortBox::*)(  const Bnd_Box &  ) >(&Bnd_BoundSortBox::Compare),
             R"#(Compares the bounding box theBox, with the set of bounding boxes provided to this algorithm at initialization, and returns the list of indices of bounding boxes that intersect the theBox or are inside it. The indices correspond to the indices of the bounding boxes in the array provided to this algorithm at initialization.)#"  , py::arg("theBox")
          )
        .def("Compare",
             ( const NCollection_List<int> & (Bnd_BoundSortBox::*)(  const gp_Pln &  ) ) static_cast< const NCollection_List<int> & (Bnd_BoundSortBox::*)(  const gp_Pln &  ) >(&Bnd_BoundSortBox::Compare),
             R"#(Compares the plane thePlane with the set of bounding boxes provided to this algorithm at initialization, and returns the list of indices of bounding boxes that intersect the thePlane. The indices correspond to the indices of the bounding boxes in the array provided to this algorithm at initialization.)#"  , py::arg("thePlane")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Bnd_Box from ./opencascade/Bnd_Box.hxx
    klass = m.attr("Bnd_Box");


    // nested enums

    static_cast<py::class_<Bnd_Box , shared_ptr<Bnd_Box>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const gp_Pnt &, const gp_Pnt & >()  , py::arg("theMin"),  py::arg("theMax") )
    // custom constructors
    // methods
        .def("SetWhole",
             (void (Bnd_Box::*)() ) static_cast<void (Bnd_Box::*)() >(&Bnd_Box::SetWhole),
             R"#(Sets this bounding box so that it covers the whole of 3D space. It is infinitely long in all directions.)#" 
          )
        .def("SetVoid",
             (void (Bnd_Box::*)() ) static_cast<void (Bnd_Box::*)() >(&Bnd_Box::SetVoid),
             R"#(Sets this bounding box so that it is empty. All points are outside a void box.)#" 
          )
        .def("Set",
             (void (Bnd_Box::*)(  const gp_Pnt &  ) ) static_cast<void (Bnd_Box::*)(  const gp_Pnt &  ) >(&Bnd_Box::Set),
             R"#(Sets this bounding box so that it bounds - the point P. This involves first setting this bounding box to be void and then adding the point P.)#"  , py::arg("P")
          )
        .def("Set",
             (void (Bnd_Box::*)(  const gp_Pnt & ,   const gp_Dir &  ) ) static_cast<void (Bnd_Box::*)(  const gp_Pnt & ,   const gp_Dir &  ) >(&Bnd_Box::Set),
             R"#(Sets this bounding box so that it bounds the half-line defined by point P and direction D, i.e. all points M defined by M=P+u*D, where u is greater than or equal to 0, are inside the bounding volume. This involves first setting this box to be void and then adding the half-line.)#"  , py::arg("P"),  py::arg("D")
          )
        .def("Update",
             (void (Bnd_Box::*)(  const double ,   const double ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<void (Bnd_Box::*)(  const double ,   const double ,   const double ,   const double ,   const double ,   const double  ) >(&Bnd_Box::Update),
             R"#(Enlarges this bounding box, if required, so that it contains at least: - interval [ aXmin,aXmax ] in the "X Direction", - interval [ aYmin,aYmax ] in the "Y Direction", - interval [ aZmin,aZmax ] in the "Z Direction";)#"  , py::arg("aXmin"),  py::arg("aYmin"),  py::arg("aZmin"),  py::arg("aXmax"),  py::arg("aYmax"),  py::arg("aZmax")
          )
        .def("Update",
             (void (Bnd_Box::*)(  const double ,   const double ,   const double  ) ) static_cast<void (Bnd_Box::*)(  const double ,   const double ,   const double  ) >(&Bnd_Box::Update),
             R"#(Adds a point of coordinates (X,Y,Z) to this bounding box.)#"  , py::arg("X"),  py::arg("Y"),  py::arg("Z")
          )
        .def("GetGap",
             (double (Bnd_Box::*)() const) static_cast<double (Bnd_Box::*)() const>(&Bnd_Box::GetGap),
             R"#(Returns the gap of this bounding box.)#" 
          )
        .def("SetGap",
             (void (Bnd_Box::*)(  const double  ) ) static_cast<void (Bnd_Box::*)(  const double  ) >(&Bnd_Box::SetGap),
             R"#(Set the gap of this bounding box to abs(Tol).)#"  , py::arg("Tol")
          )
        .def("Enlarge",
             (void (Bnd_Box::*)(  const double  ) ) static_cast<void (Bnd_Box::*)(  const double  ) >(&Bnd_Box::Enlarge),
             R"#(Enlarges the box with a tolerance value. (minvalues-std::abs(<tol>) and maxvalues+std::abs(<tol>)) This means that the minimum values of its X, Y and Z intervals of definition, when they are finite, are reduced by the absolute value of Tol, while the maximum values are increased by the same amount.)#"  , py::arg("Tol")
          )
        .def("Get",
             (Bnd_Box::Limits (Bnd_Box::*)() const) static_cast<Bnd_Box::Limits (Bnd_Box::*)() const>(&Bnd_Box::Get),
             R"#(Returns the bounds of this bounding box as a Limits structure. The gap is included. If this bounding box is infinite (i.e. "open"), returned values may be equal to +/- Precision::Infinite(). If the box is void, returns raw internal values. Can be used with C++17 structured bindings:)#" 
          )
        .def("GetXMin",
             (double (Bnd_Box::*)() const) static_cast<double (Bnd_Box::*)() const>(&Bnd_Box::GetXMin),
             R"#(Returns the Xmin value (IsOpenXmin() ? -Precision::Infinite() : Xmin - GetGap()).)#" 
          )
        .def("GetXMax",
             (double (Bnd_Box::*)() const) static_cast<double (Bnd_Box::*)() const>(&Bnd_Box::GetXMax),
             R"#(Returns the Xmax value (IsOpenXmax() ? Precision::Infinite() : Xmax + GetGap()).)#" 
          )
        .def("GetYMin",
             (double (Bnd_Box::*)() const) static_cast<double (Bnd_Box::*)() const>(&Bnd_Box::GetYMin),
             R"#(Returns the Ymin value (IsOpenYmin() ? -Precision::Infinite() : Ymin - GetGap()).)#" 
          )
        .def("GetYMax",
             (double (Bnd_Box::*)() const) static_cast<double (Bnd_Box::*)() const>(&Bnd_Box::GetYMax),
             R"#(Returns the Ymax value (IsOpenYmax() ? Precision::Infinite() : Ymax + GetGap()).)#" 
          )
        .def("GetZMin",
             (double (Bnd_Box::*)() const) static_cast<double (Bnd_Box::*)() const>(&Bnd_Box::GetZMin),
             R"#(Returns the Zmin value (IsOpenZmin() ? -Precision::Infinite() : Zmin - GetGap()).)#" 
          )
        .def("GetZMax",
             (double (Bnd_Box::*)() const) static_cast<double (Bnd_Box::*)() const>(&Bnd_Box::GetZMax),
             R"#(Returns the Zmax value (IsOpenZmax() ? Precision::Infinite() : Zmax + GetGap()).)#" 
          )
        .def("CornerMin",
             (gp_Pnt (Bnd_Box::*)() const) static_cast<gp_Pnt (Bnd_Box::*)() const>(&Bnd_Box::CornerMin),
             R"#(Returns the lower corner of this bounding box. The gap is included. If this bounding box is infinite (i.e. "open"), returned values may be equal to +/- Precision::Infinite(). Standard_ConstructionError exception will be thrown if the box is void. if IsVoid())#" 
          )
        .def("CornerMax",
             (gp_Pnt (Bnd_Box::*)() const) static_cast<gp_Pnt (Bnd_Box::*)() const>(&Bnd_Box::CornerMax),
             R"#(Returns the upper corner of this bounding box. The gap is included. If this bounding box is infinite (i.e. "open"), returned values may be equal to +/- Precision::Infinite(). Standard_ConstructionError exception will be thrown if the box is void. if IsVoid())#" 
          )
        .def("Center",
             (std::optional<gp_Pnt> (Bnd_Box::*)() const) static_cast<std::optional<gp_Pnt> (Bnd_Box::*)() const>(&Bnd_Box::Center),
             R"#(Returns the center of this bounding box. The gap is included. If this bounding box is infinite (i.e. "open"), returned values may be equal to +/- Precision::Infinite(). Returns std::nullopt if the box is void.)#" 
          )
        .def("OpenXmin",
             (void (Bnd_Box::*)() ) static_cast<void (Bnd_Box::*)() >(&Bnd_Box::OpenXmin),
             R"#(The Box will be infinitely long in the Xmin direction.)#" 
          )
        .def("OpenXmax",
             (void (Bnd_Box::*)() ) static_cast<void (Bnd_Box::*)() >(&Bnd_Box::OpenXmax),
             R"#(The Box will be infinitely long in the Xmax direction.)#" 
          )
        .def("OpenYmin",
             (void (Bnd_Box::*)() ) static_cast<void (Bnd_Box::*)() >(&Bnd_Box::OpenYmin),
             R"#(The Box will be infinitely long in the Ymin direction.)#" 
          )
        .def("OpenYmax",
             (void (Bnd_Box::*)() ) static_cast<void (Bnd_Box::*)() >(&Bnd_Box::OpenYmax),
             R"#(The Box will be infinitely long in the Ymax direction.)#" 
          )
        .def("OpenZmin",
             (void (Bnd_Box::*)() ) static_cast<void (Bnd_Box::*)() >(&Bnd_Box::OpenZmin),
             R"#(The Box will be infinitely long in the Zmin direction.)#" 
          )
        .def("OpenZmax",
             (void (Bnd_Box::*)() ) static_cast<void (Bnd_Box::*)() >(&Bnd_Box::OpenZmax),
             R"#(The Box will be infinitely long in the Zmax direction.)#" 
          )
        .def("IsOpen",
             (bool (Bnd_Box::*)() const) static_cast<bool (Bnd_Box::*)() const>(&Bnd_Box::IsOpen),
             R"#(Returns true if this bounding box has at least one open direction.)#" 
          )
        .def("IsOpenXmin",
             (bool (Bnd_Box::*)() const) static_cast<bool (Bnd_Box::*)() const>(&Bnd_Box::IsOpenXmin),
             R"#(Returns true if this bounding box is open in the Xmin direction.)#" 
          )
        .def("IsOpenXmax",
             (bool (Bnd_Box::*)() const) static_cast<bool (Bnd_Box::*)() const>(&Bnd_Box::IsOpenXmax),
             R"#(Returns true if this bounding box is open in the Xmax direction.)#" 
          )
        .def("IsOpenYmin",
             (bool (Bnd_Box::*)() const) static_cast<bool (Bnd_Box::*)() const>(&Bnd_Box::IsOpenYmin),
             R"#(Returns true if this bounding box is open in the Ymin direction.)#" 
          )
        .def("IsOpenYmax",
             (bool (Bnd_Box::*)() const) static_cast<bool (Bnd_Box::*)() const>(&Bnd_Box::IsOpenYmax),
             R"#(Returns true if this bounding box is open in the Ymax direction.)#" 
          )
        .def("IsOpenZmin",
             (bool (Bnd_Box::*)() const) static_cast<bool (Bnd_Box::*)() const>(&Bnd_Box::IsOpenZmin),
             R"#(Returns true if this bounding box is open in the Zmin direction.)#" 
          )
        .def("IsOpenZmax",
             (bool (Bnd_Box::*)() const) static_cast<bool (Bnd_Box::*)() const>(&Bnd_Box::IsOpenZmax),
             R"#(Returns true if this bounding box is open in the Zmax direction.)#" 
          )
        .def("IsWhole",
             (bool (Bnd_Box::*)() const) static_cast<bool (Bnd_Box::*)() const>(&Bnd_Box::IsWhole),
             R"#(Returns true if this bounding box is infinite in all 6 directions (WholeSpace flag).)#" 
          )
        .def("IsVoid",
             (bool (Bnd_Box::*)() const) static_cast<bool (Bnd_Box::*)() const>(&Bnd_Box::IsVoid),
             R"#(Returns true if this bounding box is empty (Void flag).)#" 
          )
        .def("IsXThin",
             (bool (Bnd_Box::*)(  const double  ) const) static_cast<bool (Bnd_Box::*)(  const double  ) const>(&Bnd_Box::IsXThin),
             R"#(true if xmax-xmin < tol.)#"  , py::arg("tol")
          )
        .def("IsYThin",
             (bool (Bnd_Box::*)(  const double  ) const) static_cast<bool (Bnd_Box::*)(  const double  ) const>(&Bnd_Box::IsYThin),
             R"#(true if ymax-ymin < tol.)#"  , py::arg("tol")
          )
        .def("IsZThin",
             (bool (Bnd_Box::*)(  const double  ) const) static_cast<bool (Bnd_Box::*)(  const double  ) const>(&Bnd_Box::IsZThin),
             R"#(true if zmax-zmin < tol.)#"  , py::arg("tol")
          )
        .def("IsThin",
             (bool (Bnd_Box::*)(  const double  ) const) static_cast<bool (Bnd_Box::*)(  const double  ) const>(&Bnd_Box::IsThin),
             R"#(Returns true if IsXThin, IsYThin and IsZThin are all true, i.e. if the box is thin in all three dimensions.)#"  , py::arg("tol")
          )
        .def("Transformed",
             (Bnd_Box (Bnd_Box::*)(  const gp_Trsf &  ) const) static_cast<Bnd_Box (Bnd_Box::*)(  const gp_Trsf &  ) const>(&Bnd_Box::Transformed),
             R"#(Returns a bounding box which is the result of applying the transformation T to this bounding box. Warning Applying a geometric transformation (for example, a rotation) to a bounding box generally increases its dimensions. This is not optimal for algorithms which use it.)#"  , py::arg("T")
          )
        .def("Add",
             (void (Bnd_Box::*)(  const Bnd_Box &  ) ) static_cast<void (Bnd_Box::*)(  const Bnd_Box &  ) >(&Bnd_Box::Add),
             R"#(Adds the box <Other> to <me>.)#"  , py::arg("Other")
          )
        .def("Add",
             (void (Bnd_Box::*)(  const gp_Pnt &  ) ) static_cast<void (Bnd_Box::*)(  const gp_Pnt &  ) >(&Bnd_Box::Add),
             R"#(Adds a Pnt to the box.)#"  , py::arg("P")
          )
        .def("Add",
             (void (Bnd_Box::*)(  const gp_Pnt & ,   const gp_Dir &  ) ) static_cast<void (Bnd_Box::*)(  const gp_Pnt & ,   const gp_Dir &  ) >(&Bnd_Box::Add),
             R"#(Extends <me> from the Pnt <P> in the direction <D>.)#"  , py::arg("P"),  py::arg("D")
          )
        .def("Add",
             (void (Bnd_Box::*)(  const gp_Dir &  ) ) static_cast<void (Bnd_Box::*)(  const gp_Dir &  ) >(&Bnd_Box::Add),
             R"#(Extends the Box in the given Direction, i.e. adds an half-line. The box may become infinite in 1,2 or 3 directions.)#"  , py::arg("D")
          )
        .def("IsOut",
             (bool (Bnd_Box::*)(  const gp_Pnt &  ) const) static_cast<bool (Bnd_Box::*)(  const gp_Pnt &  ) const>(&Bnd_Box::IsOut),
             R"#(Returns True if the Pnt is out the box.)#"  , py::arg("P")
          )
        .def("IsOut",
             (bool (Bnd_Box::*)(  const gp_Lin &  ) const) static_cast<bool (Bnd_Box::*)(  const gp_Lin &  ) const>(&Bnd_Box::IsOut),
             R"#(Returns False if the line intersects the box.)#"  , py::arg("L")
          )
        .def("IsOut",
             (bool (Bnd_Box::*)(  const gp_Pln &  ) const) static_cast<bool (Bnd_Box::*)(  const gp_Pln &  ) const>(&Bnd_Box::IsOut),
             R"#(Returns False if the plane intersects the box.)#"  , py::arg("P")
          )
        .def("IsOut",
             (bool (Bnd_Box::*)(  const Bnd_Box &  ) const) static_cast<bool (Bnd_Box::*)(  const Bnd_Box &  ) const>(&Bnd_Box::IsOut),
             R"#(Returns False if the <Box> intersects or is inside <me>.)#"  , py::arg("Other")
          )
        .def("IsOut",
             (bool (Bnd_Box::*)(  const Bnd_Box & ,   const gp_Trsf &  ) const) static_cast<bool (Bnd_Box::*)(  const Bnd_Box & ,   const gp_Trsf &  ) const>(&Bnd_Box::IsOut),
             R"#(Returns False if the transformed <Box> intersects or is inside <me>.)#"  , py::arg("Other"),  py::arg("T")
          )
        .def("IsOut",
             (bool (Bnd_Box::*)(  const gp_Trsf & ,   const Bnd_Box & ,   const gp_Trsf &  ) const) static_cast<bool (Bnd_Box::*)(  const gp_Trsf & ,   const Bnd_Box & ,   const gp_Trsf &  ) const>(&Bnd_Box::IsOut),
             R"#(Returns False if the transformed <Box> intersects or is inside the transformed box <me>.)#"  , py::arg("T1"),  py::arg("Other"),  py::arg("T2")
          )
        .def("IsOut",
             (bool (Bnd_Box::*)(  const gp_Pnt & ,   const gp_Pnt & ,   const gp_Dir &  ) const) static_cast<bool (Bnd_Box::*)(  const gp_Pnt & ,   const gp_Pnt & ,   const gp_Dir &  ) const>(&Bnd_Box::IsOut),
             R"#(Returns False if the flat band lying between two parallel lines represented by their reference points <P1>, <P2> and direction <D> intersects the box.)#"  , py::arg("P1"),  py::arg("P2"),  py::arg("D")
          )
        .def("Contains",
             (bool (Bnd_Box::*)(  const gp_Pnt &  ) const) static_cast<bool (Bnd_Box::*)(  const gp_Pnt &  ) const>(&Bnd_Box::Contains),
             R"#(Returns True if the point is inside or on the boundary of this box.)#"  , py::arg("theP")
          )
        .def("Intersects",
             (bool (Bnd_Box::*)(  const Bnd_Box &  ) const) static_cast<bool (Bnd_Box::*)(  const Bnd_Box &  ) const>(&Bnd_Box::Intersects),
             R"#(Returns True if the other box intersects or is inside this box.)#"  , py::arg("theOther")
          )
        .def("Distance",
             (double (Bnd_Box::*)(  const Bnd_Box &  ) const) static_cast<double (Bnd_Box::*)(  const Bnd_Box &  ) const>(&Bnd_Box::Distance),
             R"#(Computes the minimum distance between two boxes.)#"  , py::arg("Other")
          )
        .def("Dump",
             (void (Bnd_Box::*)() const) static_cast<void (Bnd_Box::*)() const>(&Bnd_Box::Dump),
             R"#()#" 
          )
        .def("SquareExtent",
             (double (Bnd_Box::*)() const) static_cast<double (Bnd_Box::*)() const>(&Bnd_Box::SquareExtent),
             R"#(Computes the squared diagonal of me.)#" 
          )
        .def("FinitePart",
             (Bnd_Box (Bnd_Box::*)() const) static_cast<Bnd_Box (Bnd_Box::*)() const>(&Bnd_Box::FinitePart),
             R"#(Returns a finite part of an infinite bounding box (returns self if this is already finite box). This can be a Void box in case if its sides has been defined as infinite (Open) without adding any finite points. WARNING! This method relies on Open flags, the infinite points added using Add() method will be returned as is.)#" 
          )
        .def("HasFinitePart",
             (bool (Bnd_Box::*)() const) static_cast<bool (Bnd_Box::*)() const>(&Bnd_Box::HasFinitePart),
             R"#(Returns TRUE if this box has finite part.)#" 
          )
        .def("DumpJson",
             (void (Bnd_Box::*)( Standard_OStream & ,  int  ) const) static_cast<void (Bnd_Box::*)( Standard_OStream & ,  int  ) const>(&Bnd_Box::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
        .def("InitFromJson",
             (bool (Bnd_Box::*)(  const Standard_SStream & ,  int &  ) ) static_cast<bool (Bnd_Box::*)(  const Standard_SStream & ,  int &  ) >(&Bnd_Box::InitFromJson),
             R"#(Inits the content of me from the stream)#"  , py::arg("theSStream"),  py::arg("theStreamPos")
          )
    // methods using call by reference i.s.o. return
        .def("Get",
             []( Bnd_Box &self   ){
                 double  theXmin;
                double  theYmin;
                double  theZmin;
                double  theXmax;
                double  theYmax;
                double  theZmax;

                 self.Get(theXmin,theYmin,theZmin,theXmax,theYmax,theZmax);
                 return std::make_tuple(theXmin,theYmin,theZmin,theXmax,theYmax,theZmax); },
             R"#(Returns the bounds of this bounding box. The gap is included. If this bounding box is infinite (i.e. "open"), returned values may be equal to +/- Precision::Infinite(). Standard_ConstructionError exception will be thrown if the box is void. if IsVoid())#" 
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Bnd_Box2d from ./opencascade/Bnd_Box2d.hxx
    klass = m.attr("Bnd_Box2d");

    // default constructor
    register_default_constructor<Bnd_Box2d , shared_ptr<Bnd_Box2d>>(m,"Bnd_Box2d");

    // nested enums

    static_cast<py::class_<Bnd_Box2d , shared_ptr<Bnd_Box2d>  >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("SetWhole",
             (void (Bnd_Box2d::*)() ) static_cast<void (Bnd_Box2d::*)() >(&Bnd_Box2d::SetWhole),
             R"#(Sets this bounding box so that it covers the whole 2D space, i.e. it is infinite in all directions.)#" 
          )
        .def("SetVoid",
             (void (Bnd_Box2d::*)() ) static_cast<void (Bnd_Box2d::*)() >(&Bnd_Box2d::SetVoid),
             R"#(Sets this 2D bounding box so that it is empty. All points are outside a void box.)#" 
          )
        .def("Set",
             (void (Bnd_Box2d::*)(  const gp_Pnt2d &  ) ) static_cast<void (Bnd_Box2d::*)(  const gp_Pnt2d &  ) >(&Bnd_Box2d::Set),
             R"#(Sets this 2D bounding box so that it bounds the point P. This involves first setting this bounding box to be void and then adding the point PThe rectangle bounds the point <P>.)#"  , py::arg("thePnt")
          )
        .def("Set",
             (void (Bnd_Box2d::*)(  const gp_Pnt2d & ,   const gp_Dir2d &  ) ) static_cast<void (Bnd_Box2d::*)(  const gp_Pnt2d & ,   const gp_Dir2d &  ) >(&Bnd_Box2d::Set),
             R"#(Sets this 2D bounding box so that it bounds the half-line defined by point P and direction D, i.e. all points M defined by M=P+u*D, where u is greater than or equal to 0, are inside the bounding area. This involves first setting this 2D box to be void and then adding the half-line.)#"  , py::arg("thePnt"),  py::arg("theDir")
          )
        .def("Update",
             (void (Bnd_Box2d::*)(  const double ,   const double ,   const double ,   const double  ) ) static_cast<void (Bnd_Box2d::*)(  const double ,   const double ,   const double ,   const double  ) >(&Bnd_Box2d::Update),
             R"#(Enlarges this 2D bounding box, if required, so that it contains at least: - interval [ aXmin,aXmax ] in the "X Direction", - interval [ aYmin,aYmax ] in the "Y Direction")#"  , py::arg("aXmin"),  py::arg("aYmin"),  py::arg("aXmax"),  py::arg("aYmax")
          )
        .def("Update",
             (void (Bnd_Box2d::*)(  const double ,   const double  ) ) static_cast<void (Bnd_Box2d::*)(  const double ,   const double  ) >(&Bnd_Box2d::Update),
             R"#(Adds a point of coordinates (X,Y) to this bounding box.)#"  , py::arg("X"),  py::arg("Y")
          )
        .def("GetGap",
             (double (Bnd_Box2d::*)() const) static_cast<double (Bnd_Box2d::*)() const>(&Bnd_Box2d::GetGap),
             R"#(Returns the gap of this 2D bounding box.)#" 
          )
        .def("SetGap",
             (void (Bnd_Box2d::*)(  const double  ) ) static_cast<void (Bnd_Box2d::*)(  const double  ) >(&Bnd_Box2d::SetGap),
             R"#(Set the gap of this 2D bounding box to abs(Tol).)#"  , py::arg("Tol")
          )
        .def("Enlarge",
             (void (Bnd_Box2d::*)(  const double  ) ) static_cast<void (Bnd_Box2d::*)(  const double  ) >(&Bnd_Box2d::Enlarge),
             R"#(Enlarges the box with a tolerance value. This means that the minimum values of its X and Y intervals of definition, when they are finite, are reduced by the absolute value of Tol, while the maximum values are increased by the same amount.)#"  , py::arg("theTol")
          )
        .def("Get",
             (Bnd_Box2d::Limits (Bnd_Box2d::*)() const) static_cast<Bnd_Box2d::Limits (Bnd_Box2d::*)() const>(&Bnd_Box2d::Get),
             R"#(Returns the bounds of this 2D bounding box as a Limits structure. The gap is included. If this bounding box is infinite (i.e. "open"), returned values may be equal to +/- Precision::Infinite(). If the box is void, returns raw internal values. Can be used with C++17 structured bindings:)#" 
          )
        .def("GetXMin",
             (double (Bnd_Box2d::*)() const) static_cast<double (Bnd_Box2d::*)() const>(&Bnd_Box2d::GetXMin),
             R"#(Returns the Xmin value (IsOpenXmin() ? -Precision::Infinite() : Xmin - GetGap()).)#" 
          )
        .def("GetXMax",
             (double (Bnd_Box2d::*)() const) static_cast<double (Bnd_Box2d::*)() const>(&Bnd_Box2d::GetXMax),
             R"#(Returns the Xmax value (IsOpenXmax() ? Precision::Infinite() : Xmax + GetGap()).)#" 
          )
        .def("GetYMin",
             (double (Bnd_Box2d::*)() const) static_cast<double (Bnd_Box2d::*)() const>(&Bnd_Box2d::GetYMin),
             R"#(Returns the Ymin value (IsOpenYmin() ? -Precision::Infinite() : Ymin - GetGap()).)#" 
          )
        .def("GetYMax",
             (double (Bnd_Box2d::*)() const) static_cast<double (Bnd_Box2d::*)() const>(&Bnd_Box2d::GetYMax),
             R"#(Returns the Ymax value (IsOpenYmax() ? Precision::Infinite() : Ymax + GetGap()).)#" 
          )
        .def("Center",
             (std::optional<gp_Pnt2d> (Bnd_Box2d::*)() const) static_cast<std::optional<gp_Pnt2d> (Bnd_Box2d::*)() const>(&Bnd_Box2d::Center),
             R"#(Returns the center of this 2D bounding box. The gap is included. If this bounding box is infinite (i.e. "open"), returned values may be equal to +/- Precision::Infinite(). Returns std::nullopt if the box is void.)#" 
          )
        .def("OpenXmin",
             (void (Bnd_Box2d::*)() ) static_cast<void (Bnd_Box2d::*)() >(&Bnd_Box2d::OpenXmin),
             R"#(The Box will be infinitely long in the Xmin direction.)#" 
          )
        .def("OpenXmax",
             (void (Bnd_Box2d::*)() ) static_cast<void (Bnd_Box2d::*)() >(&Bnd_Box2d::OpenXmax),
             R"#(The Box will be infinitely long in the Xmax direction.)#" 
          )
        .def("OpenYmin",
             (void (Bnd_Box2d::*)() ) static_cast<void (Bnd_Box2d::*)() >(&Bnd_Box2d::OpenYmin),
             R"#(The Box will be infinitely long in the Ymin direction.)#" 
          )
        .def("OpenYmax",
             (void (Bnd_Box2d::*)() ) static_cast<void (Bnd_Box2d::*)() >(&Bnd_Box2d::OpenYmax),
             R"#(The Box will be infinitely long in the Ymax direction.)#" 
          )
        .def("IsOpenXmin",
             (bool (Bnd_Box2d::*)() const) static_cast<bool (Bnd_Box2d::*)() const>(&Bnd_Box2d::IsOpenXmin),
             R"#(Returns true if this bounding box is open in the Xmin direction.)#" 
          )
        .def("IsOpenXmax",
             (bool (Bnd_Box2d::*)() const) static_cast<bool (Bnd_Box2d::*)() const>(&Bnd_Box2d::IsOpenXmax),
             R"#(Returns true if this bounding box is open in the Xmax direction.)#" 
          )
        .def("IsOpenYmin",
             (bool (Bnd_Box2d::*)() const) static_cast<bool (Bnd_Box2d::*)() const>(&Bnd_Box2d::IsOpenYmin),
             R"#(Returns true if this bounding box is open in the Ymin direction.)#" 
          )
        .def("IsOpenYmax",
             (bool (Bnd_Box2d::*)() const) static_cast<bool (Bnd_Box2d::*)() const>(&Bnd_Box2d::IsOpenYmax),
             R"#(Returns true if this bounding box is open in the Ymax direction.)#" 
          )
        .def("IsWhole",
             (bool (Bnd_Box2d::*)() const) static_cast<bool (Bnd_Box2d::*)() const>(&Bnd_Box2d::IsWhole),
             R"#(Returns true if this bounding box is infinite in all 4 directions (Whole Space flag).)#" 
          )
        .def("IsVoid",
             (bool (Bnd_Box2d::*)() const) static_cast<bool (Bnd_Box2d::*)() const>(&Bnd_Box2d::IsVoid),
             R"#(Returns true if this 2D bounding box is empty (Void flag).)#" 
          )
        .def("Transformed",
             (Bnd_Box2d (Bnd_Box2d::*)(  const gp_Trsf2d &  ) const) static_cast<Bnd_Box2d (Bnd_Box2d::*)(  const gp_Trsf2d &  ) const>(&Bnd_Box2d::Transformed),
             R"#(Returns a bounding box which is the result of applying the transformation T to this bounding box. Warning Applying a geometric transformation (for example, a rotation) to a bounding box generally increases its dimensions. This is not optimal for algorithms which use it.)#"  , py::arg("T")
          )
        .def("Add",
             (void (Bnd_Box2d::*)(  const Bnd_Box2d &  ) ) static_cast<void (Bnd_Box2d::*)(  const Bnd_Box2d &  ) >(&Bnd_Box2d::Add),
             R"#(Adds the 2d box <Other> to <me>.)#"  , py::arg("Other")
          )
        .def("Add",
             (void (Bnd_Box2d::*)(  const gp_Pnt2d &  ) ) static_cast<void (Bnd_Box2d::*)(  const gp_Pnt2d &  ) >(&Bnd_Box2d::Add),
             R"#(Adds the 2d point.)#"  , py::arg("thePnt")
          )
        .def("Add",
             (void (Bnd_Box2d::*)(  const gp_Pnt2d & ,   const gp_Dir2d &  ) ) static_cast<void (Bnd_Box2d::*)(  const gp_Pnt2d & ,   const gp_Dir2d &  ) >(&Bnd_Box2d::Add),
             R"#(Extends bounding box from thePnt in the direction theDir.)#"  , py::arg("thePnt"),  py::arg("theDir")
          )
        .def("Add",
             (void (Bnd_Box2d::*)(  const gp_Dir2d &  ) ) static_cast<void (Bnd_Box2d::*)(  const gp_Dir2d &  ) >(&Bnd_Box2d::Add),
             R"#(Extends the Box in the given Direction, i.e. adds a half-line. The box may become infinite in 1 or 2 directions.)#"  , py::arg("D")
          )
        .def("IsOut",
             (bool (Bnd_Box2d::*)(  const gp_Pnt2d &  ) const) static_cast<bool (Bnd_Box2d::*)(  const gp_Pnt2d &  ) const>(&Bnd_Box2d::IsOut),
             R"#(Returns True if the 2d pnt <P> is out <me>.)#"  , py::arg("P")
          )
        .def("IsOut",
             (bool (Bnd_Box2d::*)(  const gp_Lin2d &  ) const) static_cast<bool (Bnd_Box2d::*)(  const gp_Lin2d &  ) const>(&Bnd_Box2d::IsOut),
             R"#(Returns True if the line doesn't intersect the box.)#"  , py::arg("theL")
          )
        .def("IsOut",
             (bool (Bnd_Box2d::*)(  const gp_Pnt2d & ,   const gp_Pnt2d &  ) const) static_cast<bool (Bnd_Box2d::*)(  const gp_Pnt2d & ,   const gp_Pnt2d &  ) const>(&Bnd_Box2d::IsOut),
             R"#(Returns True if the segment doesn't intersect the box.)#"  , py::arg("theP0"),  py::arg("theP1")
          )
        .def("IsOut",
             (bool (Bnd_Box2d::*)(  const Bnd_Box2d &  ) const) static_cast<bool (Bnd_Box2d::*)(  const Bnd_Box2d &  ) const>(&Bnd_Box2d::IsOut),
             R"#(Returns True if <Box2d> is out <me>.)#"  , py::arg("Other")
          )
        .def("Contains",
             (bool (Bnd_Box2d::*)(  const gp_Pnt2d &  ) const) static_cast<bool (Bnd_Box2d::*)(  const gp_Pnt2d &  ) const>(&Bnd_Box2d::Contains),
             R"#(Returns True if the 2d point is inside or on the boundary of this box.)#"  , py::arg("theP")
          )
        .def("Intersects",
             (bool (Bnd_Box2d::*)(  const Bnd_Box2d &  ) const) static_cast<bool (Bnd_Box2d::*)(  const Bnd_Box2d &  ) const>(&Bnd_Box2d::Intersects),
             R"#(Returns True if the other 2d box intersects or is inside this box.)#"  , py::arg("theOther")
          )
        .def("Distance",
             (double (Bnd_Box2d::*)(  const Bnd_Box2d &  ) const) static_cast<double (Bnd_Box2d::*)(  const Bnd_Box2d &  ) const>(&Bnd_Box2d::Distance),
             R"#(Computes the minimum distance between two 2D boxes.)#"  , py::arg("theOther")
          )
        .def("IsOut",
             (bool (Bnd_Box2d::*)(  const Bnd_Box2d & ,   const gp_Trsf2d &  ) const) static_cast<bool (Bnd_Box2d::*)(  const Bnd_Box2d & ,   const gp_Trsf2d &  ) const>(&Bnd_Box2d::IsOut),
             R"#(Returns True if transformed <Box2d> is out <me>.)#"  , py::arg("theOther"),  py::arg("theTrsf")
          )
        .def("IsOut",
             (bool (Bnd_Box2d::*)(  const gp_Trsf2d & ,   const Bnd_Box2d & ,   const gp_Trsf2d &  ) const) static_cast<bool (Bnd_Box2d::*)(  const gp_Trsf2d & ,   const Bnd_Box2d & ,   const gp_Trsf2d &  ) const>(&Bnd_Box2d::IsOut),
             R"#(Compares a transformed bounding with a transformed bounding. The default implementation is to make a copy of <me> and <Other>, to transform them and to test.)#"  , py::arg("T1"),  py::arg("Other"),  py::arg("T2")
          )
        .def("Dump",
             (void (Bnd_Box2d::*)() const) static_cast<void (Bnd_Box2d::*)() const>(&Bnd_Box2d::Dump),
             R"#()#" 
          )
        .def("SquareExtent",
             (double (Bnd_Box2d::*)() const) static_cast<double (Bnd_Box2d::*)() const>(&Bnd_Box2d::SquareExtent),
             R"#(Computes the squared diagonal of me.)#" 
          )
    // methods using call by reference i.s.o. return
        .def("Get",
             []( Bnd_Box2d &self   ){
                 double  aXmin;
                double  aYmin;
                double  aXmax;
                double  aYmax;

                 self.Get(aXmin,aYmin,aXmax,aYmax);
                 return std::make_tuple(aXmin,aYmin,aXmax,aYmax); },
             R"#(Returns the bounds of this 2D bounding box. The gap is included. If this bounding box is infinite (i.e. "open"), returned values may be equal to +/- Precision::Infinite(). if IsVoid())#" 
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Bnd_OBB from ./opencascade/Bnd_OBB.hxx
    klass = m.attr("Bnd_OBB");


    // nested enums

    static_cast<py::class_<Bnd_OBB , shared_ptr<Bnd_OBB>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const Bnd_Box & >()  , py::arg("theBox") )
        .def(py::init<  const gp_Pnt &, const gp_Dir &, const gp_Dir &, const gp_Dir &, const double, const double, const double >()  , py::arg("theCenter"),  py::arg("theXDirection"),  py::arg("theYDirection"),  py::arg("theZDirection"),  py::arg("theHXSize"),  py::arg("theHYSize"),  py::arg("theHZSize") )
    // custom constructors
    // methods
        .def("ReBuild",
             (void (Bnd_OBB::*)(  const NCollection_Array1<gp_Pnt> & ,   const NCollection_Array1<double> * ,   const bool  ) ) static_cast<void (Bnd_OBB::*)(  const NCollection_Array1<gp_Pnt> & ,   const NCollection_Array1<double> * ,   const bool  ) >(&Bnd_OBB::ReBuild),
             R"#(Creates new OBB covering every point in theListOfPoints. Tolerance of every such point is set by *theListOfTolerances array. If this array is not void (not null-pointer) then the resulted Bnd_OBB will be enlarged using tolerances of points lying on the box surface. <theIsOptimal> flag defines the mode in which the OBB will be built. Constructing Optimal box takes more time, but the resulting box is usually more tight. In case of construction of Optimal OBB more possible axes are checked.)#"  , py::arg("theListOfPoints"),  py::arg("theListOfTolerances")=static_cast< const NCollection_Array1<double> *>(nullptr),  py::arg("theIsOptimal")=static_cast< const bool>(false)
          )
        .def("SetCenter",
             (void (Bnd_OBB::*)(  const gp_Pnt &  ) ) static_cast<void (Bnd_OBB::*)(  const gp_Pnt &  ) >(&Bnd_OBB::SetCenter),
             R"#(Sets the center of OBB)#"  , py::arg("theCenter")
          )
        .def("SetXComponent",
             (void (Bnd_OBB::*)(  const gp_Dir & ,   const double  ) ) static_cast<void (Bnd_OBB::*)(  const gp_Dir & ,   const double  ) >(&Bnd_OBB::SetXComponent),
             R"#(Sets the X component of OBB - direction and size)#"  , py::arg("theXDirection"),  py::arg("theHXSize")
          )
        .def("SetYComponent",
             (void (Bnd_OBB::*)(  const gp_Dir & ,   const double  ) ) static_cast<void (Bnd_OBB::*)(  const gp_Dir & ,   const double  ) >(&Bnd_OBB::SetYComponent),
             R"#(Sets the Y component of OBB - direction and size)#"  , py::arg("theYDirection"),  py::arg("theHYSize")
          )
        .def("SetZComponent",
             (void (Bnd_OBB::*)(  const gp_Dir & ,   const double  ) ) static_cast<void (Bnd_OBB::*)(  const gp_Dir & ,   const double  ) >(&Bnd_OBB::SetZComponent),
             R"#(Sets the Z component of OBB - direction and size)#"  , py::arg("theZDirection"),  py::arg("theHZSize")
          )
        .def("Position",
             (gp_Ax3 (Bnd_OBB::*)() const) static_cast<gp_Ax3 (Bnd_OBB::*)() const>(&Bnd_OBB::Position),
             R"#(Returns the local coordinates system of this oriented box. So that applying it to axis-aligned box ((-XHSize, -YHSize, -ZHSize), (XHSize, YHSize, ZHSize)) will produce this oriented box.)#" 
          )
        .def("XHSize",
             (double (Bnd_OBB::*)() const) static_cast<double (Bnd_OBB::*)() const>(&Bnd_OBB::XHSize),
             R"#(Returns the X Dimension of OBB)#" 
          )
        .def("YHSize",
             (double (Bnd_OBB::*)() const) static_cast<double (Bnd_OBB::*)() const>(&Bnd_OBB::YHSize),
             R"#(Returns the Y Dimension of OBB)#" 
          )
        .def("ZHSize",
             (double (Bnd_OBB::*)() const) static_cast<double (Bnd_OBB::*)() const>(&Bnd_OBB::ZHSize),
             R"#(Returns the Z Dimension of OBB)#" 
          )
        .def("GetHalfSizes",
             (Bnd_OBB::HalfSizes (Bnd_OBB::*)() const) static_cast<Bnd_OBB::HalfSizes (Bnd_OBB::*)() const>(&Bnd_OBB::GetHalfSizes),
             R"#(Returns the half-size dimensions of the OBB as a HalfSizes structure. Can be used with C++17 structured bindings:)#" 
          )
        .def("IsVoid",
             (bool (Bnd_OBB::*)() const) static_cast<bool (Bnd_OBB::*)() const>(&Bnd_OBB::IsVoid),
             R"#(Checks if the box is empty.)#" 
          )
        .def("SetVoid",
             (void (Bnd_OBB::*)() ) static_cast<void (Bnd_OBB::*)() >(&Bnd_OBB::SetVoid),
             R"#(Clears this box)#" 
          )
        .def("SetAABox",
             (void (Bnd_OBB::*)(  const bool &  ) ) static_cast<void (Bnd_OBB::*)(  const bool &  ) >(&Bnd_OBB::SetAABox),
             R"#(Sets the flag for axes aligned box)#"  , py::arg("theFlag")
          )
        .def("IsAABox",
             (bool (Bnd_OBB::*)() const) static_cast<bool (Bnd_OBB::*)() const>(&Bnd_OBB::IsAABox),
             R"#(Returns TRUE if the box is axes aligned)#" 
          )
        .def("Enlarge",
             (void (Bnd_OBB::*)(  const double  ) ) static_cast<void (Bnd_OBB::*)(  const double  ) >(&Bnd_OBB::Enlarge),
             R"#(Enlarges the box with the given value)#"  , py::arg("theGapAdd")
          )
        .def("GetVertex",
             (bool (Bnd_OBB::*)( gp_Pnt[8]  ) const) static_cast<bool (Bnd_OBB::*)( gp_Pnt[8]  ) const>(&Bnd_OBB::GetVertex),
             R"#(Returns the array of vertices in <this>. The local coordinate of the vertex depending on the index of the array are follow: Index == 0: (-XHSize(), -YHSize(), -ZHSize()) Index == 1: ( XHSize(), -YHSize(), -ZHSize()) Index == 2: (-XHSize(), YHSize(), -ZHSize()) Index == 3: ( XHSize(), YHSize(), -ZHSize()) Index == 4: (-XHSize(), -YHSize(), ZHSize()) Index == 5: ( XHSize(), -YHSize(), ZHSize()) Index == 6: (-XHSize(), YHSize(), ZHSize()) Index == 7: ( XHSize(), YHSize(), ZHSize()).)#"  , py::arg("theP")
          )
        .def("SquareExtent",
             (double (Bnd_OBB::*)() const) static_cast<double (Bnd_OBB::*)() const>(&Bnd_OBB::SquareExtent),
             R"#(Returns square diagonal of this box)#" 
          )
        .def("IsOut",
             (bool (Bnd_OBB::*)(  const Bnd_OBB &  ) const) static_cast<bool (Bnd_OBB::*)(  const Bnd_OBB &  ) const>(&Bnd_OBB::IsOut),
             R"#(Check if the box do not interfere the other box.)#"  , py::arg("theOther")
          )
        .def("IsOut",
             (bool (Bnd_OBB::*)(  const gp_Pnt &  ) const) static_cast<bool (Bnd_OBB::*)(  const gp_Pnt &  ) const>(&Bnd_OBB::IsOut),
             R"#(Check if the point is inside of <this>.)#"  , py::arg("theP")
          )
        .def("Contains",
             (bool (Bnd_OBB::*)(  const gp_Pnt &  ) const) static_cast<bool (Bnd_OBB::*)(  const gp_Pnt &  ) const>(&Bnd_OBB::Contains),
             R"#(Returns True if the point is inside or on the boundary of this OBB.)#"  , py::arg("theP")
          )
        .def("Intersects",
             (bool (Bnd_OBB::*)(  const Bnd_OBB &  ) const) static_cast<bool (Bnd_OBB::*)(  const Bnd_OBB &  ) const>(&Bnd_OBB::Intersects),
             R"#(Returns True if the other OBB intersects or is inside this OBB.)#"  , py::arg("theOther")
          )
        .def("IsCompletelyInside",
             (bool (Bnd_OBB::*)(  const Bnd_OBB &  ) const) static_cast<bool (Bnd_OBB::*)(  const Bnd_OBB &  ) const>(&Bnd_OBB::IsCompletelyInside),
             R"#(Check if the theOther is completely inside *this.)#"  , py::arg("theOther")
          )
        .def("Add",
             (void (Bnd_OBB::*)(  const Bnd_OBB &  ) ) static_cast<void (Bnd_OBB::*)(  const Bnd_OBB &  ) >(&Bnd_OBB::Add),
             R"#(Rebuilds this in order to include all previous objects (which it was created from) and theOther.)#"  , py::arg("theOther")
          )
        .def("Add",
             (void (Bnd_OBB::*)(  const gp_Pnt &  ) ) static_cast<void (Bnd_OBB::*)(  const gp_Pnt &  ) >(&Bnd_OBB::Add),
             R"#(Rebuilds this in order to include all previous objects (which it was created from) and theP.)#"  , py::arg("theP")
          )
        .def("DumpJson",
             (void (Bnd_OBB::*)( Standard_OStream & ,  int  ) const) static_cast<void (Bnd_OBB::*)( Standard_OStream & ,  int  ) const>(&Bnd_OBB::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Center",
             ( const gp_XYZ & (Bnd_OBB::*)() const) static_cast< const gp_XYZ & (Bnd_OBB::*)() const>(&Bnd_OBB::Center),
             R"#(Returns the center of OBB)#"
             
         )
       .def("XDirection",
             ( const gp_XYZ & (Bnd_OBB::*)() const) static_cast< const gp_XYZ & (Bnd_OBB::*)() const>(&Bnd_OBB::XDirection),
             R"#(Returns the X Direction of OBB)#"
             
         )
       .def("YDirection",
             ( const gp_XYZ & (Bnd_OBB::*)() const) static_cast< const gp_XYZ & (Bnd_OBB::*)() const>(&Bnd_OBB::YDirection),
             R"#(Returns the Y Direction of OBB)#"
             
         )
       .def("ZDirection",
             ( const gp_XYZ & (Bnd_OBB::*)() const) static_cast< const gp_XYZ & (Bnd_OBB::*)() const>(&Bnd_OBB::ZDirection),
             R"#(Returns the Z Direction of OBB)#"
             
         )
;

    // Class Bnd_Range from ./opencascade/Bnd_Range.hxx
    klass = m.attr("Bnd_Range");


    // nested enums
        py::enum_<Bnd_Range::IntersectStatus>(klass, "IntersectStatus_e", R"#(Status of intersection check with a periodic value.)#")
            .value("IntersectStatus_Out", Bnd_Range::IntersectStatus::IntersectStatus_Out)
            .value("IntersectStatus_In", Bnd_Range::IntersectStatus::IntersectStatus_In)
            .value("IntersectStatus_Boundary", Bnd_Range::IntersectStatus::IntersectStatus_Boundary);

    static_cast<py::class_<Bnd_Range , shared_ptr<Bnd_Range>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const double, const double >()  , py::arg("theMin"),  py::arg("theMax") )
    // custom constructors
    // methods
        .def("Common",
             (void (Bnd_Range::*)(  const Bnd_Range &  ) ) static_cast<void (Bnd_Range::*)(  const Bnd_Range &  ) >(&Bnd_Range::Common),
             R"#(Replaces <this> with common-part of <this> and theOther)#"  , py::arg("theOther")
          )
        .def("Union",
             (bool (Bnd_Range::*)(  const Bnd_Range &  ) ) static_cast<bool (Bnd_Range::*)(  const Bnd_Range &  ) >(&Bnd_Range::Union),
             R"#(Joins *this and theOther to one interval. Replaces *this to the result. Returns false if the operation cannot be done (e.g. input arguments are empty or separated).)#"  , py::arg("theOther")
          )
        .def("Split",
             (void (Bnd_Range::*)(  const double ,  NCollection_List<Bnd_Range> & ,   const double  ) const) static_cast<void (Bnd_Range::*)(  const double ,  NCollection_List<Bnd_Range> & ,   const double  ) const>(&Bnd_Range::Split),
             R"#(Splits <this> to several sub-ranges by theVal value (e.g. range [3, 15] will be split by theVal==5 to the two ranges: [3, 5] and [5, 15]). New ranges will be pushed to theList (theList must be initialized correctly before calling this method). If thePeriod != 0.0 then at least one boundary of new ranges (if <*this> intersects theVal+k*thePeriod) will be equal to theVal+thePeriod*k, where k is an integer number (k = 0, +/-1, +/-2, ...). (let thePeriod in above example be 4 ==> we will obtain four ranges: [3, 5], [5, 9], [9, 13] and [13, 15].)#"  , py::arg("theVal"),  py::arg("theList"),  py::arg("thePeriod")=static_cast< const double>(0.0)
          )
        .def("IsIntersected",
             (Bnd_Range::IntersectStatus (Bnd_Range::*)(  const double ,   const double  ) const) static_cast<Bnd_Range::IntersectStatus (Bnd_Range::*)(  const double ,   const double  ) const>(&Bnd_Range::IsIntersected),
             R"#(Checks if <this> intersects values like theVal+k*thePeriod, where k is an integer number (k = 0, +/-1, +/-2, ...).)#"  , py::arg("theVal"),  py::arg("thePeriod")=static_cast< const double>(0.0)
          )
        .def("Add",
             (void (Bnd_Range::*)(  const double  ) ) static_cast<void (Bnd_Range::*)(  const double  ) >(&Bnd_Range::Add),
             R"#(Extends <this> to include theParameter)#"  , py::arg("theParameter")
          )
        .def("Add",
             (void (Bnd_Range::*)(  const Bnd_Range &  ) ) static_cast<void (Bnd_Range::*)(  const Bnd_Range &  ) >(&Bnd_Range::Add),
             R"#(Extends this range to include both ranges.)#"  , py::arg("theRange")
          )
        .def("GetMin",
             (bool (Bnd_Range::*)( double &  ) const) static_cast<bool (Bnd_Range::*)( double &  ) const>(&Bnd_Range::GetMin),
             R"#(Obtain MIN boundary of <this>. If <this> is VOID the method returns false.)#"  , py::arg("thePar")
          )
        .def("GetMax",
             (bool (Bnd_Range::*)( double &  ) const) static_cast<bool (Bnd_Range::*)( double &  ) const>(&Bnd_Range::GetMax),
             R"#(Obtain MAX boundary of <this>. If <this> is VOID the method returns false.)#"  , py::arg("thePar")
          )
        .def("GetBounds",
             (bool (Bnd_Range::*)( double & ,  double &  ) const) static_cast<bool (Bnd_Range::*)( double & ,  double &  ) const>(&Bnd_Range::GetBounds),
             R"#(Obtain first and last boundary of <this>. If <this> is VOID the method returns false.)#"  , py::arg("theFirstPar"),  py::arg("theLastPar")
          )
        .def("Get",
             (std::optional<Bnd_Range::Bounds> (Bnd_Range::*)() const) static_cast<std::optional<Bnd_Range::Bounds> (Bnd_Range::*)() const>(&Bnd_Range::Get),
             R"#(Returns the bounds of this range as a Bounds structure. Returns std::nullopt if IsVoid(). Can be used with C++17 structured bindings:)#" 
          )
        .def("GetIntermediatePoint",
             (bool (Bnd_Range::*)(  const double ,  double &  ) const) static_cast<bool (Bnd_Range::*)(  const double ,  double &  ) const>(&Bnd_Range::GetIntermediatePoint),
             R"#(Obtain theParameter satisfied to the equation (theParameter-MIN)/(MAX-MIN) == theLambda. * theLambda == 0 --> MIN boundary will be returned; * theLambda == 0.5 --> Middle point will be returned; * theLambda == 1 --> MAX boundary will be returned; * theLambda < 0 --> the value less than MIN will be returned; * theLambda > 1 --> the value greater than MAX will be returned. If <this> is VOID the method returns false.)#"  , py::arg("theLambda"),  py::arg("theParameter")
          )
        .def("Center",
             (std::optional<double> (Bnd_Range::*)() const) static_cast<std::optional<double> (Bnd_Range::*)() const>(&Bnd_Range::Center),
             R"#(Returns the center of this range ((Min + Max) / 2). Returns std::nullopt if IsVoid().)#" 
          )
        .def("Delta",
             (double (Bnd_Range::*)() const) static_cast<double (Bnd_Range::*)() const>(&Bnd_Range::Delta),
             R"#(Returns range value (MAX-MIN). Returns negative value for VOID range.)#" 
          )
        .def("IsVoid",
             (bool (Bnd_Range::*)() const) static_cast<bool (Bnd_Range::*)() const>(&Bnd_Range::IsVoid),
             R"#(Is <this> initialized.)#" 
          )
        .def("SetVoid",
             (void (Bnd_Range::*)() ) static_cast<void (Bnd_Range::*)() >(&Bnd_Range::SetVoid),
             R"#(Initializes <this> by default parameters. Makes <this> VOID.)#" 
          )
        .def("Enlarge",
             (void (Bnd_Range::*)(  const double  ) ) static_cast<void (Bnd_Range::*)(  const double  ) >(&Bnd_Range::Enlarge),
             R"#(Extends this to the given value (in both side))#"  , py::arg("theDelta")
          )
        .def("Shifted",
             (Bnd_Range (Bnd_Range::*)(  const double  ) const) static_cast<Bnd_Range (Bnd_Range::*)(  const double  ) const>(&Bnd_Range::Shifted),
             R"#(Returns the copy of <*this> shifted by theVal)#"  , py::arg("theVal")
          )
        .def("Shift",
             (void (Bnd_Range::*)(  const double  ) ) static_cast<void (Bnd_Range::*)(  const double  ) >(&Bnd_Range::Shift),
             R"#(Shifts <*this> by theVal)#"  , py::arg("theVal")
          )
        .def("TrimFrom",
             (void (Bnd_Range::*)(  const double  ) ) static_cast<void (Bnd_Range::*)(  const double  ) >(&Bnd_Range::TrimFrom),
             R"#(Trims the First value in range by the given lower limit. Marks range as Void if the given Lower value is greater than range Max.)#"  , py::arg("theValLower")
          )
        .def("TrimTo",
             (void (Bnd_Range::*)(  const double  ) ) static_cast<void (Bnd_Range::*)(  const double  ) >(&Bnd_Range::TrimTo),
             R"#(Trim the Last value in range by the given Upper limit. Marks range as Void if the given Upper value is smaller than range Max.)#"  , py::arg("theValUpper")
          )
        .def("IsOut",
             (bool (Bnd_Range::*)( double  ) const) static_cast<bool (Bnd_Range::*)( double  ) const>(&Bnd_Range::IsOut),
             R"#(Returns True if the value is out of this range.)#"  , py::arg("theValue")
          )
        .def("IsOut",
             (bool (Bnd_Range::*)(  const Bnd_Range &  ) const) static_cast<bool (Bnd_Range::*)(  const Bnd_Range &  ) const>(&Bnd_Range::IsOut),
             R"#(Returns True if the given range is out of this range.)#"  , py::arg("theRange")
          )
        .def("Contains",
             (bool (Bnd_Range::*)( double  ) const) static_cast<bool (Bnd_Range::*)( double  ) const>(&Bnd_Range::Contains),
             R"#(Returns True if the value is within this range.)#"  , py::arg("theValue")
          )
        .def("Intersects",
             (bool (Bnd_Range::*)(  const Bnd_Range &  ) const) static_cast<bool (Bnd_Range::*)(  const Bnd_Range &  ) const>(&Bnd_Range::Intersects),
             R"#(Returns True if the given range intersects (overlaps with) this range.)#"  , py::arg("theRange")
          )
        .def("Min",
             (std::optional<double> (Bnd_Range::*)() const) static_cast<std::optional<double> (Bnd_Range::*)() const>(&Bnd_Range::Min),
             R"#(Returns the MIN boundary of <this>. Returns std::nullopt if IsVoid().)#" 
          )
        .def("Max",
             (std::optional<double> (Bnd_Range::*)() const) static_cast<std::optional<double> (Bnd_Range::*)() const>(&Bnd_Range::Max),
             R"#(Returns the MAX boundary of <this>. Returns std::nullopt if IsVoid().)#" 
          )
        .def("DumpJson",
             (void (Bnd_Range::*)( Standard_OStream & ,  int  ) const) static_cast<void (Bnd_Range::*)( Standard_OStream & ,  int  ) const>(&Bnd_Range::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Bnd_Sphere from ./opencascade/Bnd_Sphere.hxx
    klass = m.attr("Bnd_Sphere");


    // nested enums

    static_cast<py::class_<Bnd_Sphere , shared_ptr<Bnd_Sphere>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const gp_XYZ &, const double, const int, const int >()  , py::arg("theCntr"),  py::arg("theRad"),  py::arg("theU"),  py::arg("theV") )
    // custom constructors
    // methods
        .def("U",
             (int (Bnd_Sphere::*)() const) static_cast<int (Bnd_Sphere::*)() const>(&Bnd_Sphere::U),
             R"#(Returns the U parameter on shape)#" 
          )
        .def("V",
             (int (Bnd_Sphere::*)() const) static_cast<int (Bnd_Sphere::*)() const>(&Bnd_Sphere::V),
             R"#(Returns the V parameter on shape)#" 
          )
        .def("IsValid",
             (bool (Bnd_Sphere::*)() const) static_cast<bool (Bnd_Sphere::*)() const>(&Bnd_Sphere::IsValid),
             R"#(Returns validity status, indicating that this sphere corresponds to a real entity)#" 
          )
        .def("SetValid",
             (void (Bnd_Sphere::*)(  const bool  ) ) static_cast<void (Bnd_Sphere::*)(  const bool  ) >(&Bnd_Sphere::SetValid),
             R"#()#"  , py::arg("isValid")
          )
        .def("Radius",
             (double (Bnd_Sphere::*)() const) static_cast<double (Bnd_Sphere::*)() const>(&Bnd_Sphere::Radius),
             R"#(Returns the radius value)#" 
          )
        .def("Project",
             (bool (Bnd_Sphere::*)(  const gp_XYZ & ,  gp_XYZ & ,  double & ,  bool &  ) const) static_cast<bool (Bnd_Sphere::*)(  const gp_XYZ & ,  gp_XYZ & ,  double & ,  bool &  ) const>(&Bnd_Sphere::Project),
             R"#(Projects a point on entity. Returns true if success)#"  , py::arg("theNode"),  py::arg("theProjNode"),  py::arg("theDist"),  py::arg("theInside")
          )
        .def("Distance",
             (double (Bnd_Sphere::*)(  const gp_XYZ &  ) const) static_cast<double (Bnd_Sphere::*)(  const gp_XYZ &  ) const>(&Bnd_Sphere::Distance),
             R"#()#"  , py::arg("theNode")
          )
        .def("SquareDistance",
             (double (Bnd_Sphere::*)(  const gp_XYZ &  ) const) static_cast<double (Bnd_Sphere::*)(  const gp_XYZ &  ) const>(&Bnd_Sphere::SquareDistance),
             R"#()#"  , py::arg("theNode")
          )
        .def("Add",
             (void (Bnd_Sphere::*)(  const Bnd_Sphere &  ) ) static_cast<void (Bnd_Sphere::*)(  const Bnd_Sphere &  ) >(&Bnd_Sphere::Add),
             R"#()#"  , py::arg("theOther")
          )
        .def("IsOut",
             (bool (Bnd_Sphere::*)(  const Bnd_Sphere &  ) const) static_cast<bool (Bnd_Sphere::*)(  const Bnd_Sphere &  ) const>(&Bnd_Sphere::IsOut),
             R"#()#"  , py::arg("theOther")
          )
        .def("IsOut",
             (bool (Bnd_Sphere::*)(  const gp_XYZ & ,  double &  ) const) static_cast<bool (Bnd_Sphere::*)(  const gp_XYZ & ,  double &  ) const>(&Bnd_Sphere::IsOut),
             R"#()#"  , py::arg("thePnt"),  py::arg("theMaxDist")
          )
        .def("SquareExtent",
             (double (Bnd_Sphere::*)() const) static_cast<double (Bnd_Sphere::*)() const>(&Bnd_Sphere::SquareExtent),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
        .def("Distances",
             []( Bnd_Sphere &self ,  const gp_XYZ & theXYZ ){
                 double  theMin;
                double  theMax;

                 self.Distances(theXYZ,theMin,theMax);
                 return std::make_tuple(theMin,theMax); },
             R"#(Calculate and return minimal and maximal distance to sphere. NOTE: This function is tightly optimized; any modifications may affect performance!)#"  , py::arg("theXYZ")
          )
        .def("SquareDistances",
             []( Bnd_Sphere &self ,  const gp_XYZ & theXYZ ){
                 double  theMin;
                double  theMax;

                 self.SquareDistances(theXYZ,theMin,theMax);
                 return std::make_tuple(theMin,theMax); },
             R"#(Calculate and return minimal and maximal distance to sphere. NOTE: This function is tightly optimized; any modifications may affect performance!)#"  , py::arg("theXYZ")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Center",
             ( const gp_XYZ & (Bnd_Sphere::*)() const) static_cast< const gp_XYZ & (Bnd_Sphere::*)() const>(&Bnd_Sphere::Center),
             R"#(Returns center of sphere object)#"
             
         )
;

    // Class Bnd_Tools from ./opencascade/Bnd_Tools.hxx
    klass = m.attr("Bnd_Tools");

    // default constructor
    register_default_constructor<Bnd_Tools , shared_ptr<Bnd_Tools>>(m,"Bnd_Tools");

    // nested enums

    static_cast<py::class_<Bnd_Tools , shared_ptr<Bnd_Tools>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Bnd2BVH_s",
                    (BVH_Box<double, 2> (*)(  const Bnd_Box2d &  ) ) static_cast<BVH_Box<double, 2> (*)(  const Bnd_Box2d &  ) >(&Bnd_Tools::Bnd2BVH),
                    R"#(Converts the given Bnd_Box2d to BVH_Box)#"  , py::arg("theBox")
          )
        .def_static("Bnd2BVH_s",
                    (BVH_Box<double, 3> (*)(  const Bnd_Box &  ) ) static_cast<BVH_Box<double, 3> (*)(  const Bnd_Box &  ) >(&Bnd_Tools::Bnd2BVH),
                    R"#(Converts the given Bnd_Box to BVH_Box)#"  , py::arg("theBox")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

// functions

// ./opencascade/Bnd_B2.hxx
// ./opencascade/Bnd_B3.hxx
// ./opencascade/Bnd_BoundSortBox.hxx
// ./opencascade/Bnd_Box.hxx
// ./opencascade/Bnd_Box2d.hxx
// ./opencascade/Bnd_OBB.hxx
// ./opencascade/Bnd_Range.hxx
// ./opencascade/Bnd_Sphere.hxx
// ./opencascade/Bnd_Tools.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
