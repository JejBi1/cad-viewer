
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <XSControl_WorkSession.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <XSControl_WorkSession.hxx>
#include <TDataStd_NamedData.hxx>
#include <TDocStd_Document.hxx>
#include <XCAFDoc_ShapeTool.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <XSControl_WorkSession.hxx>
#include <TDocStd_Document.hxx>

// module includes
#include <STEPCAFControl_ActorWrite.hxx>
#include <STEPCAFControl_Controller.hxx>
#include <STEPCAFControl_ExternFile.hxx>
#include <STEPCAFControl_GDTProperty.hxx>
#include <STEPCAFControl_Reader.hxx>
#include <STEPCAFControl_Writer.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module
        #include <istream>
        #include <ostream>

        using std::basic_ostream;
        using std::basic_istream;
        using std::char_traits;

        #include <DE_ConfigurationContext.hxx>
        #include <XCAFDoc_ShapeTool.hxx>
        #include <XSAlgo_ShapeProcessor.hxx>
        

// Module definiiton
void register_STEPCAFControl(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("STEPCAFControl"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes

// classes

    // Class STEPCAFControl_ActorWrite from ./opencascade/STEPCAFControl_ActorWrite.hxx
    klass = m.attr("STEPCAFControl_ActorWrite");


    // nested enums

    static_cast<py::class_<STEPCAFControl_ActorWrite ,opencascade::handle<STEPCAFControl_ActorWrite>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetStdMode",
             (void (STEPCAFControl_ActorWrite::*)(  const bool  ) ) static_cast<void (STEPCAFControl_ActorWrite::*)(  const bool  ) >(&STEPCAFControl_ActorWrite::SetStdMode),
             R"#(Set standard mode of work In standard mode Actor (default) behaves exactly as its ancestor, also map is cleared)#"  , py::arg("stdmode")=static_cast< const bool>(true)
          )
        .def("ClearMap",
             (void (STEPCAFControl_ActorWrite::*)() ) static_cast<void (STEPCAFControl_ActorWrite::*)() >(&STEPCAFControl_ActorWrite::ClearMap),
             R"#(Clears map of shapes registered as assemblies)#" 
          )
        .def("RegisterAssembly",
             (void (STEPCAFControl_ActorWrite::*)(  const TopoDS_Shape &  ) ) static_cast<void (STEPCAFControl_ActorWrite::*)(  const TopoDS_Shape &  ) >(&STEPCAFControl_ActorWrite::RegisterAssembly),
             R"#(Registers shape to be written as assembly The shape should be TopoDS_Compound (else does nothing))#"  , py::arg("S")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&STEPCAFControl_ActorWrite::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&STEPCAFControl_ActorWrite::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (STEPCAFControl_ActorWrite::*)() const) static_cast< const handle<Standard_Type> & (STEPCAFControl_ActorWrite::*)() const>(&STEPCAFControl_ActorWrite::DynamicType),
             R"#()#"
             
         )
;

    // Class STEPCAFControl_Controller from ./opencascade/STEPCAFControl_Controller.hxx
    klass = m.attr("STEPCAFControl_Controller");


    // nested enums

    static_cast<py::class_<STEPCAFControl_Controller ,opencascade::handle<STEPCAFControl_Controller>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Init_s",
                    (bool (*)() ) static_cast<bool (*)() >(&STEPCAFControl_Controller::Init),
                    R"#(Standard Initialisation. It creates a Controller for STEP-XCAF and records it to various names, available to select it later Returns True when done, False if could not be done)#" 
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&STEPCAFControl_Controller::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&STEPCAFControl_Controller::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (STEPCAFControl_Controller::*)() const) static_cast< const handle<Standard_Type> & (STEPCAFControl_Controller::*)() const>(&STEPCAFControl_Controller::DynamicType),
             R"#()#"
             
         )
;

    // Class STEPCAFControl_ExternFile from ./opencascade/STEPCAFControl_ExternFile.hxx
    klass = m.attr("STEPCAFControl_ExternFile");


    // nested enums

    static_cast<py::class_<STEPCAFControl_ExternFile ,opencascade::handle<STEPCAFControl_ExternFile>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetWS",
             (void (STEPCAFControl_ExternFile::*)(  const handle<XSControl_WorkSession> &  ) ) static_cast<void (STEPCAFControl_ExternFile::*)(  const handle<XSControl_WorkSession> &  ) >(&STEPCAFControl_ExternFile::SetWS),
             R"#()#"  , py::arg("WS")
          )
        .def("GetWS",
             (handle<XSControl_WorkSession> (STEPCAFControl_ExternFile::*)() const) static_cast<handle<XSControl_WorkSession> (STEPCAFControl_ExternFile::*)() const>(&STEPCAFControl_ExternFile::GetWS),
             R"#()#" 
          )
        .def("SetLoadStatus",
             (void (STEPCAFControl_ExternFile::*)(  const IFSelect_ReturnStatus  ) ) static_cast<void (STEPCAFControl_ExternFile::*)(  const IFSelect_ReturnStatus  ) >(&STEPCAFControl_ExternFile::SetLoadStatus),
             R"#()#"  , py::arg("stat")
          )
        .def("GetLoadStatus",
             (IFSelect_ReturnStatus (STEPCAFControl_ExternFile::*)() const) static_cast<IFSelect_ReturnStatus (STEPCAFControl_ExternFile::*)() const>(&STEPCAFControl_ExternFile::GetLoadStatus),
             R"#()#" 
          )
        .def("SetTransferStatus",
             (void (STEPCAFControl_ExternFile::*)(  const bool  ) ) static_cast<void (STEPCAFControl_ExternFile::*)(  const bool  ) >(&STEPCAFControl_ExternFile::SetTransferStatus),
             R"#()#"  , py::arg("isok")
          )
        .def("GetTransferStatus",
             (bool (STEPCAFControl_ExternFile::*)() const) static_cast<bool (STEPCAFControl_ExternFile::*)() const>(&STEPCAFControl_ExternFile::GetTransferStatus),
             R"#()#" 
          )
        .def("SetWriteStatus",
             (void (STEPCAFControl_ExternFile::*)(  const IFSelect_ReturnStatus  ) ) static_cast<void (STEPCAFControl_ExternFile::*)(  const IFSelect_ReturnStatus  ) >(&STEPCAFControl_ExternFile::SetWriteStatus),
             R"#()#"  , py::arg("stat")
          )
        .def("GetWriteStatus",
             (IFSelect_ReturnStatus (STEPCAFControl_ExternFile::*)() const) static_cast<IFSelect_ReturnStatus (STEPCAFControl_ExternFile::*)() const>(&STEPCAFControl_ExternFile::GetWriteStatus),
             R"#()#" 
          )
        .def("SetName",
             (void (STEPCAFControl_ExternFile::*)(  const handle<TCollection_HAsciiString> &  ) ) static_cast<void (STEPCAFControl_ExternFile::*)(  const handle<TCollection_HAsciiString> &  ) >(&STEPCAFControl_ExternFile::SetName),
             R"#()#"  , py::arg("name")
          )
        .def("GetName",
             (handle<TCollection_HAsciiString> (STEPCAFControl_ExternFile::*)() const) static_cast<handle<TCollection_HAsciiString> (STEPCAFControl_ExternFile::*)() const>(&STEPCAFControl_ExternFile::GetName),
             R"#()#" 
          )
        .def("SetLabel",
             (void (STEPCAFControl_ExternFile::*)(  const TDF_Label &  ) ) static_cast<void (STEPCAFControl_ExternFile::*)(  const TDF_Label &  ) >(&STEPCAFControl_ExternFile::SetLabel),
             R"#()#"  , py::arg("L")
          )
        .def("GetLabel",
             (TDF_Label (STEPCAFControl_ExternFile::*)() const) static_cast<TDF_Label (STEPCAFControl_ExternFile::*)() const>(&STEPCAFControl_ExternFile::GetLabel),
             R"#()#" 
          )
        .def("SetWS",
             (void (STEPCAFControl_ExternFile::*)(  const handle<XSControl_WorkSession> &  ) ) static_cast<void (STEPCAFControl_ExternFile::*)(  const handle<XSControl_WorkSession> &  ) >(&STEPCAFControl_ExternFile::SetWS),
             R"#()#"  , py::arg("WS")
          )
        .def("GetWS",
             (handle<XSControl_WorkSession> (STEPCAFControl_ExternFile::*)() const) static_cast<handle<XSControl_WorkSession> (STEPCAFControl_ExternFile::*)() const>(&STEPCAFControl_ExternFile::GetWS),
             R"#()#" 
          )
        .def("SetLoadStatus",
             (void (STEPCAFControl_ExternFile::*)(  const IFSelect_ReturnStatus  ) ) static_cast<void (STEPCAFControl_ExternFile::*)(  const IFSelect_ReturnStatus  ) >(&STEPCAFControl_ExternFile::SetLoadStatus),
             R"#()#"  , py::arg("stat")
          )
        .def("GetLoadStatus",
             (IFSelect_ReturnStatus (STEPCAFControl_ExternFile::*)() const) static_cast<IFSelect_ReturnStatus (STEPCAFControl_ExternFile::*)() const>(&STEPCAFControl_ExternFile::GetLoadStatus),
             R"#()#" 
          )
        .def("SetTransferStatus",
             (void (STEPCAFControl_ExternFile::*)(  const bool  ) ) static_cast<void (STEPCAFControl_ExternFile::*)(  const bool  ) >(&STEPCAFControl_ExternFile::SetTransferStatus),
             R"#()#"  , py::arg("isok")
          )
        .def("GetTransferStatus",
             (bool (STEPCAFControl_ExternFile::*)() const) static_cast<bool (STEPCAFControl_ExternFile::*)() const>(&STEPCAFControl_ExternFile::GetTransferStatus),
             R"#()#" 
          )
        .def("SetWriteStatus",
             (void (STEPCAFControl_ExternFile::*)(  const IFSelect_ReturnStatus  ) ) static_cast<void (STEPCAFControl_ExternFile::*)(  const IFSelect_ReturnStatus  ) >(&STEPCAFControl_ExternFile::SetWriteStatus),
             R"#()#"  , py::arg("stat")
          )
        .def("GetWriteStatus",
             (IFSelect_ReturnStatus (STEPCAFControl_ExternFile::*)() const) static_cast<IFSelect_ReturnStatus (STEPCAFControl_ExternFile::*)() const>(&STEPCAFControl_ExternFile::GetWriteStatus),
             R"#()#" 
          )
        .def("SetName",
             (void (STEPCAFControl_ExternFile::*)(  const handle<TCollection_HAsciiString> &  ) ) static_cast<void (STEPCAFControl_ExternFile::*)(  const handle<TCollection_HAsciiString> &  ) >(&STEPCAFControl_ExternFile::SetName),
             R"#()#"  , py::arg("name")
          )
        .def("GetName",
             (handle<TCollection_HAsciiString> (STEPCAFControl_ExternFile::*)() const) static_cast<handle<TCollection_HAsciiString> (STEPCAFControl_ExternFile::*)() const>(&STEPCAFControl_ExternFile::GetName),
             R"#()#" 
          )
        .def("SetLabel",
             (void (STEPCAFControl_ExternFile::*)(  const TDF_Label &  ) ) static_cast<void (STEPCAFControl_ExternFile::*)(  const TDF_Label &  ) >(&STEPCAFControl_ExternFile::SetLabel),
             R"#()#"  , py::arg("Label")
          )
        .def("GetLabel",
             (TDF_Label (STEPCAFControl_ExternFile::*)() const) static_cast<TDF_Label (STEPCAFControl_ExternFile::*)() const>(&STEPCAFControl_ExternFile::GetLabel),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&STEPCAFControl_ExternFile::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&STEPCAFControl_ExternFile::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (STEPCAFControl_ExternFile::*)() const) static_cast< const handle<Standard_Type> & (STEPCAFControl_ExternFile::*)() const>(&STEPCAFControl_ExternFile::DynamicType),
             R"#()#"
             
         )
;

    // Class STEPCAFControl_GDTProperty from ./opencascade/STEPCAFControl_GDTProperty.hxx
    klass = m.attr("STEPCAFControl_GDTProperty");


    // nested enums

    static_cast<py::class_<STEPCAFControl_GDTProperty , shared_ptr<STEPCAFControl_GDTProperty>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class STEPCAFControl_Reader from ./opencascade/STEPCAFControl_Reader.hxx
    klass = m.attr("STEPCAFControl_Reader");


    // nested enums

    static_cast<py::class_<STEPCAFControl_Reader , shared_ptr<STEPCAFControl_Reader>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<XSControl_WorkSession> &, const bool >()  , py::arg("WS"),  py::arg("scratch")=static_cast< const bool>(true) )
    // custom constructors
    // methods
        .def("Init",
             (void (STEPCAFControl_Reader::*)(  const handle<XSControl_WorkSession> & ,   const bool  ) ) static_cast<void (STEPCAFControl_Reader::*)(  const handle<XSControl_WorkSession> & ,   const bool  ) >(&STEPCAFControl_Reader::Init),
             R"#(Clears the internal data structures and attaches to a new session Clears the session if it was not yet set for STEP)#"  , py::arg("WS"),  py::arg("scratch")=static_cast< const bool>(true)
          )
        .def("ReadFile",
             (IFSelect_ReturnStatus (STEPCAFControl_Reader::*)(  const char * const   ) ) static_cast<IFSelect_ReturnStatus (STEPCAFControl_Reader::*)(  const char * const   ) >(&STEPCAFControl_Reader::ReadFile),
             R"#(Loads a file and returns the read status Provided for use like single-file reader.)#"  , py::arg("theFileName")
          )
        .def("ReadFile",
             (IFSelect_ReturnStatus (STEPCAFControl_Reader::*)(  const char * const  ,   const DESTEP_Parameters &  ) ) static_cast<IFSelect_ReturnStatus (STEPCAFControl_Reader::*)(  const char * const  ,   const DESTEP_Parameters &  ) >(&STEPCAFControl_Reader::ReadFile),
             R"#(Loads a file and returns the read status Provided for use like single-file reader.)#"  , py::arg("theFileName"),  py::arg("theParams")
          )
        .def("ReadStream",
             (IFSelect_ReturnStatus (STEPCAFControl_Reader::*)(  const char * const  ,  typename std::istream &  ) ) static_cast<IFSelect_ReturnStatus (STEPCAFControl_Reader::*)(  const char * const  ,  typename std::istream &  ) >(&STEPCAFControl_Reader::ReadStream),
             R"#(Loads a file from stream and returns the read status.)#"  , py::arg("theName"),  py::arg("theIStream")
          )
        .def("NbRootsForTransfer",
             (int (STEPCAFControl_Reader::*)() ) static_cast<int (STEPCAFControl_Reader::*)() >(&STEPCAFControl_Reader::NbRootsForTransfer),
             R"#(Returns number of roots recognized for transfer Shortcut for Reader().NbRootsForTransfer())#" 
          )
        .def("TransferOneRoot",
             (bool (STEPCAFControl_Reader::*)(  const int ,   const handle<TDocStd_Document> & ,   const Message_ProgressRange &  ) ) static_cast<bool (STEPCAFControl_Reader::*)(  const int ,   const handle<TDocStd_Document> & ,   const Message_ProgressRange &  ) >(&STEPCAFControl_Reader::TransferOneRoot),
             R"#(Translates currently loaded STEP file into the document Returns True if succeeded, and False in case of fail Provided for use like single-file reader)#"  , py::arg("num"),  py::arg("doc"),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def("Transfer",
             (bool (STEPCAFControl_Reader::*)(  const handle<TDocStd_Document> & ,   const Message_ProgressRange &  ) ) static_cast<bool (STEPCAFControl_Reader::*)(  const handle<TDocStd_Document> & ,   const Message_ProgressRange &  ) >(&STEPCAFControl_Reader::Transfer),
             R"#(Translates currently loaded STEP file into the document Returns True if succeeded, and False in case of fail Provided for use like single-file reader)#"  , py::arg("doc"),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def("Perform",
             (bool (STEPCAFControl_Reader::*)(  const TCollection_AsciiString & ,   const handle<TDocStd_Document> & ,   const Message_ProgressRange &  ) ) static_cast<bool (STEPCAFControl_Reader::*)(  const TCollection_AsciiString & ,   const handle<TDocStd_Document> & ,   const Message_ProgressRange &  ) >(&STEPCAFControl_Reader::Perform),
             R"#()#"  , py::arg("filename"),  py::arg("doc"),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def("Perform",
             (bool (STEPCAFControl_Reader::*)(  const TCollection_AsciiString & ,   const handle<TDocStd_Document> & ,   const DESTEP_Parameters & ,   const Message_ProgressRange &  ) ) static_cast<bool (STEPCAFControl_Reader::*)(  const TCollection_AsciiString & ,   const handle<TDocStd_Document> & ,   const DESTEP_Parameters & ,   const Message_ProgressRange &  ) >(&STEPCAFControl_Reader::Perform),
             R"#()#"  , py::arg("filename"),  py::arg("doc"),  py::arg("theParams"),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def("Perform",
             (bool (STEPCAFControl_Reader::*)(  const char * const  ,   const handle<TDocStd_Document> & ,   const Message_ProgressRange &  ) ) static_cast<bool (STEPCAFControl_Reader::*)(  const char * const  ,   const handle<TDocStd_Document> & ,   const Message_ProgressRange &  ) >(&STEPCAFControl_Reader::Perform),
             R"#(Translate STEP file given by filename into the document Return True if succeeded, and False in case of fail)#"  , py::arg("filename"),  py::arg("doc"),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def("Perform",
             (bool (STEPCAFControl_Reader::*)(  const char * const  ,   const handle<TDocStd_Document> & ,   const DESTEP_Parameters & ,   const Message_ProgressRange &  ) ) static_cast<bool (STEPCAFControl_Reader::*)(  const char * const  ,   const handle<TDocStd_Document> & ,   const DESTEP_Parameters & ,   const Message_ProgressRange &  ) >(&STEPCAFControl_Reader::Perform),
             R"#(Translate STEP file given by filename into the document Return True if succeeded, and False in case of fail)#"  , py::arg("filename"),  py::arg("doc"),  py::arg("theParams"),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def("ExternFile",
             (bool (STEPCAFControl_Reader::*)(  const char * const  ,  handle<STEPCAFControl_ExternFile> &  ) const) static_cast<bool (STEPCAFControl_Reader::*)(  const char * const  ,  handle<STEPCAFControl_ExternFile> &  ) const>(&STEPCAFControl_Reader::ExternFile),
             R"#(Returns data on external file by its name Returns False if no external file with given name is read)#"  , py::arg("name"),  py::arg("ef")
          )
        .def("SetColorMode",
             (void (STEPCAFControl_Reader::*)(  const bool  ) ) static_cast<void (STEPCAFControl_Reader::*)(  const bool  ) >(&STEPCAFControl_Reader::SetColorMode),
             R"#(Set ColorMode for indicate read Colors or not.)#"  , py::arg("colormode")
          )
        .def("GetColorMode",
             (bool (STEPCAFControl_Reader::*)() const) static_cast<bool (STEPCAFControl_Reader::*)() const>(&STEPCAFControl_Reader::GetColorMode),
             R"#()#" 
          )
        .def("SetNameMode",
             (void (STEPCAFControl_Reader::*)(  const bool  ) ) static_cast<void (STEPCAFControl_Reader::*)(  const bool  ) >(&STEPCAFControl_Reader::SetNameMode),
             R"#(Set NameMode for indicate read Name or not.)#"  , py::arg("namemode")
          )
        .def("GetNameMode",
             (bool (STEPCAFControl_Reader::*)() const) static_cast<bool (STEPCAFControl_Reader::*)() const>(&STEPCAFControl_Reader::GetNameMode),
             R"#()#" 
          )
        .def("SetLayerMode",
             (void (STEPCAFControl_Reader::*)(  const bool  ) ) static_cast<void (STEPCAFControl_Reader::*)(  const bool  ) >(&STEPCAFControl_Reader::SetLayerMode),
             R"#(Set LayerMode for indicate read Layers or not.)#"  , py::arg("layermode")
          )
        .def("GetLayerMode",
             (bool (STEPCAFControl_Reader::*)() const) static_cast<bool (STEPCAFControl_Reader::*)() const>(&STEPCAFControl_Reader::GetLayerMode),
             R"#()#" 
          )
        .def("SetPropsMode",
             (void (STEPCAFControl_Reader::*)(  const bool  ) ) static_cast<void (STEPCAFControl_Reader::*)(  const bool  ) >(&STEPCAFControl_Reader::SetPropsMode),
             R"#(PropsMode for indicate read Validation properties or not.)#"  , py::arg("propsmode")
          )
        .def("GetPropsMode",
             (bool (STEPCAFControl_Reader::*)() const) static_cast<bool (STEPCAFControl_Reader::*)() const>(&STEPCAFControl_Reader::GetPropsMode),
             R"#()#" 
          )
        .def("SetMetaMode",
             (void (STEPCAFControl_Reader::*)(  const bool  ) ) static_cast<void (STEPCAFControl_Reader::*)(  const bool  ) >(&STEPCAFControl_Reader::SetMetaMode),
             R"#(MetaMode for indicate read Metadata or not.)#"  , py::arg("theMetaMode")
          )
        .def("GetMetaMode",
             (bool (STEPCAFControl_Reader::*)() const) static_cast<bool (STEPCAFControl_Reader::*)() const>(&STEPCAFControl_Reader::GetMetaMode),
             R"#()#" 
          )
        .def("SetProductMetaMode",
             (void (STEPCAFControl_Reader::*)(  const bool  ) ) static_cast<void (STEPCAFControl_Reader::*)(  const bool  ) >(&STEPCAFControl_Reader::SetProductMetaMode),
             R"#(MetaMode for indicate whether to read Product Metadata or not.)#"  , py::arg("theProductMetaMode")
          )
        .def("GetProductMetaMode",
             (bool (STEPCAFControl_Reader::*)() const) static_cast<bool (STEPCAFControl_Reader::*)() const>(&STEPCAFControl_Reader::GetProductMetaMode),
             R"#()#" 
          )
        .def("SetSHUOMode",
             (void (STEPCAFControl_Reader::*)(  const bool  ) ) static_cast<void (STEPCAFControl_Reader::*)(  const bool  ) >(&STEPCAFControl_Reader::SetSHUOMode),
             R"#(Set SHUO mode for indicate write SHUO or not.)#"  , py::arg("shuomode")
          )
        .def("GetSHUOMode",
             (bool (STEPCAFControl_Reader::*)() const) static_cast<bool (STEPCAFControl_Reader::*)() const>(&STEPCAFControl_Reader::GetSHUOMode),
             R"#()#" 
          )
        .def("SetGDTMode",
             (void (STEPCAFControl_Reader::*)(  const bool  ) ) static_cast<void (STEPCAFControl_Reader::*)(  const bool  ) >(&STEPCAFControl_Reader::SetGDTMode),
             R"#(Set GDT mode for indicate write GDT or not.)#"  , py::arg("gdtmode")
          )
        .def("GetGDTMode",
             (bool (STEPCAFControl_Reader::*)() const) static_cast<bool (STEPCAFControl_Reader::*)() const>(&STEPCAFControl_Reader::GetGDTMode),
             R"#()#" 
          )
        .def("SetMatMode",
             (void (STEPCAFControl_Reader::*)(  const bool  ) ) static_cast<void (STEPCAFControl_Reader::*)(  const bool  ) >(&STEPCAFControl_Reader::SetMatMode),
             R"#(Set Material mode)#"  , py::arg("matmode")
          )
        .def("GetMatMode",
             (bool (STEPCAFControl_Reader::*)() const) static_cast<bool (STEPCAFControl_Reader::*)() const>(&STEPCAFControl_Reader::GetMatMode),
             R"#()#" 
          )
        .def("SetViewMode",
             (void (STEPCAFControl_Reader::*)(  const bool  ) ) static_cast<void (STEPCAFControl_Reader::*)(  const bool  ) >(&STEPCAFControl_Reader::SetViewMode),
             R"#(Set View mode)#"  , py::arg("viewmode")
          )
        .def("GetViewMode",
             (bool (STEPCAFControl_Reader::*)() const) static_cast<bool (STEPCAFControl_Reader::*)() const>(&STEPCAFControl_Reader::GetViewMode),
             R"#(Get View mode)#" 
          )
        .def("SetShapeFixParameters",
             (void (STEPCAFControl_Reader::*)(  const typename XSAlgo_ShapeProcessor::ParameterMap &  ) ) static_cast<void (STEPCAFControl_Reader::*)(  const typename XSAlgo_ShapeProcessor::ParameterMap &  ) >(&STEPCAFControl_Reader::SetShapeFixParameters),
             R"#(Sets parameters for shape processing.)#"  , py::arg("theParameters")
          )
        .def("SetShapeFixParameters",
             (void (STEPCAFControl_Reader::*)(  const DE_ShapeFixParameters & ,   const typename XSAlgo_ShapeProcessor::ParameterMap &  ) ) static_cast<void (STEPCAFControl_Reader::*)(  const DE_ShapeFixParameters & ,   const typename XSAlgo_ShapeProcessor::ParameterMap &  ) >(&STEPCAFControl_Reader::SetShapeFixParameters),
             R"#(Sets parameters for shape processing. Parameters from theParameters are copied to the internal map. Parameters from theAdditionalParameters are copied to the internal map if they are not present in theParameters.)#"  , py::arg("theParameters"),  py::arg("theAdditionalParameters")=static_cast< const typename XSAlgo_ShapeProcessor::ParameterMap &>(XSAlgo_ShapeProcessor::ParameterMap{ })
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("ExternFiles",
             ( const NCollection_DataMap<TCollection_AsciiString, handle<STEPCAFControl_ExternFile>> & (STEPCAFControl_Reader::*)() const) static_cast< const NCollection_DataMap<TCollection_AsciiString, handle<STEPCAFControl_ExternFile>> & (STEPCAFControl_Reader::*)() const>(&STEPCAFControl_Reader::ExternFiles),
             R"#(Returns data on external files Returns Null handle if no external files are read)#"
             
         )
       .def("GetShapeLabelMap",
             ( const NCollection_DataMap<TopoDS_Shape, TDF_Label, TopTools_ShapeMapHasher> & (STEPCAFControl_Reader::*)() const) static_cast< const NCollection_DataMap<TopoDS_Shape, TDF_Label, TopTools_ShapeMapHasher> & (STEPCAFControl_Reader::*)() const>(&STEPCAFControl_Reader::GetShapeLabelMap),
             R"#()#"
             
         )
       .def("GetShapeFixParameters",
             ( const typename XSAlgo_ShapeProcessor::ParameterMap & (STEPCAFControl_Reader::*)() const) static_cast< const typename XSAlgo_ShapeProcessor::ParameterMap & (STEPCAFControl_Reader::*)() const>(&STEPCAFControl_Reader::GetShapeFixParameters),
             R"#(Returns parameters for shape processing that was set by SetParameters() method.)#"
             
         )
       .def("GetShapeProcessFlags",
             ( const typename XSAlgo_ShapeProcessor::ProcessingFlags & (STEPCAFControl_Reader::*)() const) static_cast< const typename XSAlgo_ShapeProcessor::ProcessingFlags & (STEPCAFControl_Reader::*)() const>(&STEPCAFControl_Reader::GetShapeProcessFlags),
             R"#(Returns flags defining operations to be performed on shapes.)#"
             
         )
;

    // Class STEPCAFControl_Writer from ./opencascade/STEPCAFControl_Writer.hxx
    klass = m.attr("STEPCAFControl_Writer");


    // nested enums

    static_cast<py::class_<STEPCAFControl_Writer , shared_ptr<STEPCAFControl_Writer>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<XSControl_WorkSession> &, const bool >()  , py::arg("theWS"),  py::arg("theScratch")=static_cast< const bool>(true) )
    // custom constructors
    // methods
        .def("Init",
             (void (STEPCAFControl_Writer::*)(  const handle<XSControl_WorkSession> & ,   const bool  ) ) static_cast<void (STEPCAFControl_Writer::*)(  const handle<XSControl_WorkSession> & ,   const bool  ) >(&STEPCAFControl_Writer::Init),
             R"#(Clears the internal data structures and attaches to a new session Clears the session if it was not yet set for STEP)#"  , py::arg("theWS"),  py::arg("theScratch")=static_cast< const bool>(true)
          )
        .def("Write",
             (IFSelect_ReturnStatus (STEPCAFControl_Writer::*)(  const char * const   ) ) static_cast<IFSelect_ReturnStatus (STEPCAFControl_Writer::*)(  const char * const   ) >(&STEPCAFControl_Writer::Write),
             R"#(Writes all the produced models into file In case of multimodel with extern references, filename will be a name of root file, all other files have names of corresponding parts Provided for use like single-file writer)#"  , py::arg("theFileName")
          )
        .def("WriteStream",
             (IFSelect_ReturnStatus (STEPCAFControl_Writer::*)( typename std::ostream &  ) ) static_cast<IFSelect_ReturnStatus (STEPCAFControl_Writer::*)( typename std::ostream &  ) >(&STEPCAFControl_Writer::WriteStream),
             R"#(Writes all the produced models into the stream. Provided for use like single-file writer)#"  , py::arg("theStream")
          )
        .def("Perform",
             (bool (STEPCAFControl_Writer::*)(  const handle<TDocStd_Document> & ,   const TCollection_AsciiString & ,   const Message_ProgressRange &  ) ) static_cast<bool (STEPCAFControl_Writer::*)(  const handle<TDocStd_Document> & ,   const TCollection_AsciiString & ,   const Message_ProgressRange &  ) >(&STEPCAFControl_Writer::Perform),
             R"#()#"  , py::arg("theDoc"),  py::arg("theFileName"),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def("Perform",
             (bool (STEPCAFControl_Writer::*)(  const handle<TDocStd_Document> & ,   const char * const  ,   const Message_ProgressRange &  ) ) static_cast<bool (STEPCAFControl_Writer::*)(  const handle<TDocStd_Document> & ,   const char * const  ,   const Message_ProgressRange &  ) >(&STEPCAFControl_Writer::Perform),
             R"#(Transfers a document and writes it to a STEP file Returns True if translation is OK)#"  , py::arg("theDoc"),  py::arg("theFileName"),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def("Perform",
             (bool (STEPCAFControl_Writer::*)(  const handle<TDocStd_Document> & ,   const char * const  ,   const DESTEP_Parameters & ,   const Message_ProgressRange &  ) ) static_cast<bool (STEPCAFControl_Writer::*)(  const handle<TDocStd_Document> & ,   const char * const  ,   const DESTEP_Parameters & ,   const Message_ProgressRange &  ) >(&STEPCAFControl_Writer::Perform),
             R"#(Transfers a document and writes it to a STEP file This method is utilized if there's a need to set parameters avoiding initialization from Interface_Static Returns True if translation is OK)#"  , py::arg("theDoc"),  py::arg("theFileName"),  py::arg("theParams"),  py::arg("theProgress")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def("ExternFile",
             (bool (STEPCAFControl_Writer::*)(  const TDF_Label & ,  handle<STEPCAFControl_ExternFile> &  ) const) static_cast<bool (STEPCAFControl_Writer::*)(  const TDF_Label & ,  handle<STEPCAFControl_ExternFile> &  ) const>(&STEPCAFControl_Writer::ExternFile),
             R"#(Returns data on external file by its original label Returns False if no external file with given name is read)#"  , py::arg("theLabel"),  py::arg("theExtFile")
          )
        .def("ExternFile",
             (bool (STEPCAFControl_Writer::*)(  const char * const  ,  handle<STEPCAFControl_ExternFile> &  ) const) static_cast<bool (STEPCAFControl_Writer::*)(  const char * const  ,  handle<STEPCAFControl_ExternFile> &  ) const>(&STEPCAFControl_Writer::ExternFile),
             R"#(Returns data on external file by its name Returns False if no external file with given name is read)#"  , py::arg("theName"),  py::arg("theExtFile")
          )
        .def("SetColorMode",
             (void (STEPCAFControl_Writer::*)(  const bool  ) ) static_cast<void (STEPCAFControl_Writer::*)(  const bool  ) >(&STEPCAFControl_Writer::SetColorMode),
             R"#(Set ColorMode for indicate write Colors or not.)#"  , py::arg("theColorMode")
          )
        .def("GetColorMode",
             (bool (STEPCAFControl_Writer::*)() const) static_cast<bool (STEPCAFControl_Writer::*)() const>(&STEPCAFControl_Writer::GetColorMode),
             R"#()#" 
          )
        .def("SetNameMode",
             (void (STEPCAFControl_Writer::*)(  const bool  ) ) static_cast<void (STEPCAFControl_Writer::*)(  const bool  ) >(&STEPCAFControl_Writer::SetNameMode),
             R"#(Set NameMode for indicate write Name or not.)#"  , py::arg("theNameMode")
          )
        .def("GetNameMode",
             (bool (STEPCAFControl_Writer::*)() const) static_cast<bool (STEPCAFControl_Writer::*)() const>(&STEPCAFControl_Writer::GetNameMode),
             R"#()#" 
          )
        .def("SetLayerMode",
             (void (STEPCAFControl_Writer::*)(  const bool  ) ) static_cast<void (STEPCAFControl_Writer::*)(  const bool  ) >(&STEPCAFControl_Writer::SetLayerMode),
             R"#(Set LayerMode for indicate write Layers or not.)#"  , py::arg("theLayerMode")
          )
        .def("GetLayerMode",
             (bool (STEPCAFControl_Writer::*)() const) static_cast<bool (STEPCAFControl_Writer::*)() const>(&STEPCAFControl_Writer::GetLayerMode),
             R"#()#" 
          )
        .def("SetPropsMode",
             (void (STEPCAFControl_Writer::*)(  const bool  ) ) static_cast<void (STEPCAFControl_Writer::*)(  const bool  ) >(&STEPCAFControl_Writer::SetPropsMode),
             R"#(PropsMode for indicate write Validation properties or not.)#"  , py::arg("thePropsMode")
          )
        .def("GetPropsMode",
             (bool (STEPCAFControl_Writer::*)() const) static_cast<bool (STEPCAFControl_Writer::*)() const>(&STEPCAFControl_Writer::GetPropsMode),
             R"#()#" 
          )
        .def("SetMetadataMode",
             (void (STEPCAFControl_Writer::*)(  const bool  ) ) static_cast<void (STEPCAFControl_Writer::*)(  const bool  ) >(&STEPCAFControl_Writer::SetMetadataMode),
             R"#(Set MetadataMode for indicate write metadata or not.)#"  , py::arg("theMetadataMode")
          )
        .def("GetMetadataMode",
             (bool (STEPCAFControl_Writer::*)() const) static_cast<bool (STEPCAFControl_Writer::*)() const>(&STEPCAFControl_Writer::GetMetadataMode),
             R"#()#" 
          )
        .def("SetSHUOMode",
             (void (STEPCAFControl_Writer::*)(  const bool  ) ) static_cast<void (STEPCAFControl_Writer::*)(  const bool  ) >(&STEPCAFControl_Writer::SetSHUOMode),
             R"#(Set SHUO mode for indicate write SHUO or not.)#"  , py::arg("theSHUOMode")
          )
        .def("GetSHUOMode",
             (bool (STEPCAFControl_Writer::*)() const) static_cast<bool (STEPCAFControl_Writer::*)() const>(&STEPCAFControl_Writer::GetSHUOMode),
             R"#()#" 
          )
        .def("SetDimTolMode",
             (void (STEPCAFControl_Writer::*)(  const bool  ) ) static_cast<void (STEPCAFControl_Writer::*)(  const bool  ) >(&STEPCAFControl_Writer::SetDimTolMode),
             R"#(Set dimtolmode for indicate write D&GTs or not.)#"  , py::arg("theDimTolMode")
          )
        .def("GetDimTolMode",
             (bool (STEPCAFControl_Writer::*)() const) static_cast<bool (STEPCAFControl_Writer::*)() const>(&STEPCAFControl_Writer::GetDimTolMode),
             R"#()#" 
          )
        .def("SetMaterialMode",
             (void (STEPCAFControl_Writer::*)(  const bool  ) ) static_cast<void (STEPCAFControl_Writer::*)(  const bool  ) >(&STEPCAFControl_Writer::SetMaterialMode),
             R"#(Set flag for indicate write material or not.)#"  , py::arg("theMaterialMode")
          )
        .def("GetMaterialMode",
             (bool (STEPCAFControl_Writer::*)() const) static_cast<bool (STEPCAFControl_Writer::*)() const>(&STEPCAFControl_Writer::GetMaterialMode),
             R"#()#" 
          )
        .def("SetVisualMaterialMode",
             (void (STEPCAFControl_Writer::*)(  const bool  ) ) static_cast<void (STEPCAFControl_Writer::*)(  const bool  ) >(&STEPCAFControl_Writer::SetVisualMaterialMode),
             R"#(Set flag for indicate write visual material or not.)#"  , py::arg("theVisualMaterialMode")
          )
        .def("GetVisualMaterialMode",
             (bool (STEPCAFControl_Writer::*)() const) static_cast<bool (STEPCAFControl_Writer::*)() const>(&STEPCAFControl_Writer::GetVisualMaterialMode),
             R"#()#" 
          )
        .def("SetCleanDuplicates",
             (void (STEPCAFControl_Writer::*)(  const bool  ) ) static_cast<void (STEPCAFControl_Writer::*)(  const bool  ) >(&STEPCAFControl_Writer::SetCleanDuplicates),
             R"#(Set clean duplicates flag. If set to True, duplicates will be removed from the model.)#"  , py::arg("theCleanDuplicates")
          )
        .def("GetCleanDuplicates",
             (bool (STEPCAFControl_Writer::*)() const) static_cast<bool (STEPCAFControl_Writer::*)() const>(&STEPCAFControl_Writer::GetCleanDuplicates),
             R"#(Returns the flag indicating whether duplicates should be removed from the model.)#" 
          )
        .def("SetShapeFixParameters",
             (void (STEPCAFControl_Writer::*)(  const typename XSAlgo_ShapeProcessor::ParameterMap &  ) ) static_cast<void (STEPCAFControl_Writer::*)(  const typename XSAlgo_ShapeProcessor::ParameterMap &  ) >(&STEPCAFControl_Writer::SetShapeFixParameters),
             R"#(Sets parameters for shape processing.)#"  , py::arg("theParameters")
          )
        .def("SetShapeFixParameters",
             (void (STEPCAFControl_Writer::*)(  const DE_ShapeFixParameters & ,   const typename XSAlgo_ShapeProcessor::ParameterMap &  ) ) static_cast<void (STEPCAFControl_Writer::*)(  const DE_ShapeFixParameters & ,   const typename XSAlgo_ShapeProcessor::ParameterMap &  ) >(&STEPCAFControl_Writer::SetShapeFixParameters),
             R"#(Sets parameters for shape processing. Parameters from theParameters are copied to the internal map. Parameters from theAdditionalParameters are copied to the internal map if they are not present in theParameters.)#"  , py::arg("theParameters"),  py::arg("theAdditionalParameters")=static_cast< const typename XSAlgo_ShapeProcessor::ParameterMap &>(XSAlgo_ShapeProcessor::ParameterMap{ })
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("ExternFiles",
             ( const NCollection_DataMap<TCollection_AsciiString, handle<STEPCAFControl_ExternFile>> & (STEPCAFControl_Writer::*)() const) static_cast< const NCollection_DataMap<TCollection_AsciiString, handle<STEPCAFControl_ExternFile>> & (STEPCAFControl_Writer::*)() const>(&STEPCAFControl_Writer::ExternFiles),
             R"#(Returns data on external files Returns Null handle if no external files are read)#"
             
         )
       .def("GetShapeFixParameters",
             ( const typename XSAlgo_ShapeProcessor::ParameterMap & (STEPCAFControl_Writer::*)() const) static_cast< const typename XSAlgo_ShapeProcessor::ParameterMap & (STEPCAFControl_Writer::*)() const>(&STEPCAFControl_Writer::GetShapeFixParameters),
             R"#(Returns parameters for shape processing that was set by SetParameters() method.)#"
             
         )
       .def("GetShapeProcessFlags",
             ( const typename XSAlgo_ShapeProcessor::ProcessingFlags & (STEPCAFControl_Writer::*)() const) static_cast< const typename XSAlgo_ShapeProcessor::ProcessingFlags & (STEPCAFControl_Writer::*)() const>(&STEPCAFControl_Writer::GetShapeProcessFlags),
             R"#(Returns flags defining operations to be performed on shapes.)#"
             
         )
;

// functions

// ./opencascade/STEPCAFControl_ActorWrite.hxx
// ./opencascade/STEPCAFControl_Controller.hxx
// ./opencascade/STEPCAFControl_ExternFile.hxx
// ./opencascade/STEPCAFControl_GDTProperty.hxx
// ./opencascade/STEPCAFControl_Reader.hxx
// ./opencascade/STEPCAFControl_Writer.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
