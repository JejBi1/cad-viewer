
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_GUID.hxx>
#include <TCollection_ExtendedString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_DeltaOnForget.hxx>
#include <Standard_GUID.hxx>
#include <TDF_AttributeDelta.hxx>
#include <TDF_DeltaOnAddition.hxx>
#include <TDF_DeltaOnResume.hxx>
#include <TDF_DeltaOnModification.hxx>
#include <TDF_DeltaOnRemoval.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_DataSet.hxx>
#include <TDF_IDFilter.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_GUID.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_DataSet.hxx>
#include <TDF_IDFilter.hxx>
#include <TDF_ClosureMode.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_DataSet.hxx>
#include <TDF_IDFilter.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_Label.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_DataSet.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_DataSet.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_IDFilter.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Delta.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_GUID.hxx>
#include <TDF_IDFilter.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Data.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_GUID.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_DataSet.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_GUID.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_IDFilter.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Data.hxx>
#include <TDF_Delta.hxx>

// module includes
#include <TDF.hxx>
#include <TDF_Attribute.hxx>
#include <TDF_AttributeDelta.hxx>
#include <TDF_AttributeIterator.hxx>
#include <TDF_ChildIDIterator.hxx>
#include <TDF_ChildIterator.hxx>
#include <TDF_ClosureMode.hxx>
#include <TDF_ClosureTool.hxx>
#include <TDF_ComparisonTool.hxx>
#include <TDF_CopyLabel.hxx>
#include <TDF_CopyTool.hxx>
#include <TDF_Data.hxx>
#include <TDF_DataSet.hxx>
#include <TDF_DefaultDeltaOnModification.hxx>
#include <TDF_DefaultDeltaOnRemoval.hxx>
#include <TDF_Delta.hxx>
#include <TDF_DeltaOnAddition.hxx>
#include <TDF_DeltaOnForget.hxx>
#include <TDF_DeltaOnModification.hxx>
#include <TDF_DeltaOnRemoval.hxx>
#include <TDF_DeltaOnResume.hxx>
#include <TDF_DerivedAttribute.hxx>
#include <TDF_HAllocator.hxx>
#include <TDF_IDFilter.hxx>
#include <TDF_Label.hxx>
#include <TDF_LabelNode.hxx>
#include <TDF_LabelNodePtr.hxx>
#include <TDF_Reference.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_TagSource.hxx>
#include <TDF_Tool.hxx>
#include <TDF_Transaction.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_TDF(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("TDF"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes
    class Py_TDF_Attribute : public TDF_Attribute{
    public:
        using TDF_Attribute::TDF_Attribute;


        // public pure virtual
         const Standard_GUID & ID() const  override { using return_type =  const Standard_GUID &;
    PYBIND11_OVERLOAD_PURE(return_type,TDF_Attribute,ID,) };
        void Restore( const handle<TDF_Attribute> & anAttribute) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,TDF_Attribute,Restore,anAttribute) };
        handle<TDF_Attribute> NewEmpty() const  override { using return_type = handle<TDF_Attribute>;
    PYBIND11_OVERLOAD_PURE(return_type,TDF_Attribute,NewEmpty,) };
        void Paste( const handle<TDF_Attribute> & intoAttribute, const handle<TDF_RelocationTable> & aRelocationTable) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,TDF_Attribute,Paste,intoAttribute,aRelocationTable) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_TDF_AttributeDelta : public TDF_AttributeDelta{
    public:
        using TDF_AttributeDelta::TDF_AttributeDelta;


        // public pure virtual
        void Apply() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,TDF_AttributeDelta,Apply,) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_TDF_DeltaOnRemoval : public TDF_DeltaOnRemoval{
    public:
        using TDF_DeltaOnRemoval::TDF_DeltaOnRemoval;


        // public pure virtual

        void Apply() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,TDF_AttributeDelta,Apply,) };

        // protected pure virtual


        // private pure virtual

    };

// classes

    // Class TDF from ./opencascade/TDF.hxx
    klass = m.attr("TDF");

    // default constructor
    register_default_constructor<TDF , shared_ptr<TDF>>(m,"TDF");

    // nested enums

    static_cast<py::class_<TDF , shared_ptr<TDF>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("LowestID_s",
                    ( const Standard_GUID & (*)() ) static_cast< const Standard_GUID & (*)() >(&TDF::LowestID),
                    R"#(Returns ID "00000000-0000-0000-0000-000000000000", sometimes used as null ID.)#" 
          )
        .def_static("UppestID_s",
                    ( const Standard_GUID & (*)() ) static_cast< const Standard_GUID & (*)() >(&TDF::UppestID),
                    R"#(Returns ID "ffffffff-ffff-ffff-ffff-ffffffffffff".)#" 
          )
        .def_static("AddLinkGUIDToProgID_s",
                    (void (*)(  const Standard_GUID & ,   const TCollection_ExtendedString &  ) ) static_cast<void (*)(  const Standard_GUID & ,   const TCollection_ExtendedString &  ) >(&TDF::AddLinkGUIDToProgID),
                    R"#(Sets link between GUID and ProgID in hidden DataMap)#"  , py::arg("ID"),  py::arg("ProgID")
          )
        .def_static("GUIDFromProgID_s",
                    (bool (*)(  const TCollection_ExtendedString & ,  Standard_GUID &  ) ) static_cast<bool (*)(  const TCollection_ExtendedString & ,  Standard_GUID &  ) >(&TDF::GUIDFromProgID),
                    R"#(Returns True if there is GUID for given <ProgID> then GUID is returned in <ID>)#"  , py::arg("ProgID"),  py::arg("ID")
          )
        .def_static("ProgIDFromGUID_s",
                    (bool (*)(  const Standard_GUID & ,  TCollection_ExtendedString &  ) ) static_cast<bool (*)(  const Standard_GUID & ,  TCollection_ExtendedString &  ) >(&TDF::ProgIDFromGUID),
                    R"#(Returns True if there is ProgID for given <ID> then ProgID is returned in <ProgID>)#"  , py::arg("ID"),  py::arg("ProgID")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class TDF_Attribute from ./opencascade/TDF_Attribute.hxx
    klass = m.attr("TDF_Attribute");


    // nested enums

    static_cast<py::class_<TDF_Attribute ,opencascade::handle<TDF_Attribute> ,Py_TDF_Attribute , Standard_Transient >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("ID",
             ( const Standard_GUID & (TDF_Attribute::*)() const) static_cast< const Standard_GUID & (TDF_Attribute::*)() const>(&TDF_Attribute::ID),
             R"#(Returns the ID of the attribute.)#" 
          )
        .def("SetID",
             (void (TDF_Attribute::*)(  const Standard_GUID &  ) ) static_cast<void (TDF_Attribute::*)(  const Standard_GUID &  ) >(&TDF_Attribute::SetID),
             R"#(Sets specific ID of the attribute (supports several attributes of one type at the same label feature).)#"  , py::arg("arg0")
          )
        .def("SetID",
             (void (TDF_Attribute::*)() ) static_cast<void (TDF_Attribute::*)() >(&TDF_Attribute::SetID),
             R"#(Sets default ID defined in nested class (to be used for attributes having User ID feature).)#" 
          )
        .def("Label",
             ( const TDF_Label (TDF_Attribute::*)() const) static_cast< const TDF_Label (TDF_Attribute::*)() const>(&TDF_Attribute::Label),
             R"#(Returns the label to which the attribute is attached. If the label is not included in a DF, the label is null. See Label. Warning: If the label is not included in a data framework, it is null. This function should not be redefined inline.)#" 
          )
        .def("Transaction",
             (int (TDF_Attribute::*)() const) static_cast<int (TDF_Attribute::*)() const>(&TDF_Attribute::Transaction),
             R"#(Returns the transaction index in which the attribute has been created or modified.)#" 
          )
        .def("UntilTransaction",
             (int (TDF_Attribute::*)() const) static_cast<int (TDF_Attribute::*)() const>(&TDF_Attribute::UntilTransaction),
             R"#(Returns the upper transaction index until which the attribute is/was valid. This number may vary. A removed attribute validity range is reduced to its transaction index.)#" 
          )
        .def("IsValid",
             (bool (TDF_Attribute::*)() const) static_cast<bool (TDF_Attribute::*)() const>(&TDF_Attribute::IsValid),
             R"#(Returns true if the attribute is valid; i.e. not a backuped or removed one.)#" 
          )
        .def("IsNew",
             (bool (TDF_Attribute::*)() const) static_cast<bool (TDF_Attribute::*)() const>(&TDF_Attribute::IsNew),
             R"#(Returns true if the attribute has no backup)#" 
          )
        .def("IsForgotten",
             (bool (TDF_Attribute::*)() const) static_cast<bool (TDF_Attribute::*)() const>(&TDF_Attribute::IsForgotten),
             R"#(Returns true if the attribute forgotten status is set.)#" 
          )
        .def("IsAttribute",
             (bool (TDF_Attribute::*)(  const Standard_GUID &  ) const) static_cast<bool (TDF_Attribute::*)(  const Standard_GUID &  ) const>(&TDF_Attribute::IsAttribute),
             R"#(Returns true if it exists an associated attribute of <me> with <anID> as ID.)#"  , py::arg("anID")
          )
        .def("FindAttribute",
             (bool (TDF_Attribute::*)(  const Standard_GUID & ,  handle<TDF_Attribute> &  ) const) static_cast<bool (TDF_Attribute::*)(  const Standard_GUID & ,  handle<TDF_Attribute> &  ) const>(&TDF_Attribute::FindAttribute),
             R"#(Finds an associated attribute of <me>, according to <anID>. the returned <anAttribute> is a valid one. The method returns True if found, False otherwise. A removed attribute cannot be found using this method.)#"  , py::arg("anID"),  py::arg("anAttribute")
          )
        .def("AddAttribute",
             (void (TDF_Attribute::*)(  const handle<TDF_Attribute> &  ) const) static_cast<void (TDF_Attribute::*)(  const handle<TDF_Attribute> &  ) const>(&TDF_Attribute::AddAttribute),
             R"#(Adds an Attribute <other> to the label of <me>. Raises if there is already one of the same GUID than <other>.)#"  , py::arg("other")
          )
        .def("ForgetAttribute",
             (bool (TDF_Attribute::*)(  const Standard_GUID &  ) const) static_cast<bool (TDF_Attribute::*)(  const Standard_GUID &  ) const>(&TDF_Attribute::ForgetAttribute),
             R"#(Forgets the Attribute of GUID <aguid> associated to the label of <me>. Be careful that if <me> is the attribute of <guid>, <me> will have a null label after this call. If the attribute doesn't exist returns False. Otherwise returns True.)#"  , py::arg("aguid")
          )
        .def("ForgetAllAttributes",
             (void (TDF_Attribute::*)(  const bool  ) const) static_cast<void (TDF_Attribute::*)(  const bool  ) const>(&TDF_Attribute::ForgetAllAttributes),
             R"#(Forgets all the attributes attached to the label of <me>. Does it on the sub-labels if <clearChildren> is set to true. Of course, this method is compatible with Transaction & Delta mechanisms. Be careful that if <me> will have a null label after this call)#"  , py::arg("clearChildren")=static_cast< const bool>(true)
          )
        .def("AfterAddition",
             (void (TDF_Attribute::*)() ) static_cast<void (TDF_Attribute::*)() >(&TDF_Attribute::AfterAddition),
             R"#(Something to do after adding an Attribute to a label.)#" 
          )
        .def("BeforeRemoval",
             (void (TDF_Attribute::*)() ) static_cast<void (TDF_Attribute::*)() >(&TDF_Attribute::BeforeRemoval),
             R"#(Something to do before removing an Attribute from a label.)#" 
          )
        .def("BeforeForget",
             (void (TDF_Attribute::*)() ) static_cast<void (TDF_Attribute::*)() >(&TDF_Attribute::BeforeForget),
             R"#(Something to do before forgetting an Attribute to a label.)#" 
          )
        .def("AfterResume",
             (void (TDF_Attribute::*)() ) static_cast<void (TDF_Attribute::*)() >(&TDF_Attribute::AfterResume),
             R"#(Something to do after resuming an Attribute from a label.)#" 
          )
        .def("AfterRetrieval",
             (bool (TDF_Attribute::*)(  const bool  ) ) static_cast<bool (TDF_Attribute::*)(  const bool  ) >(&TDF_Attribute::AfterRetrieval),
             R"#(Something to do AFTER creation of an attribute by persistent-transient translation. The returned status says if AfterUndo has been performed (true) or if this callback must be called once again further (false). If <forceIt> is set to true, the method MUST perform and return true. Does nothing by default and returns true.)#"  , py::arg("forceIt")=static_cast< const bool>(false)
          )
        .def("BeforeUndo",
             (bool (TDF_Attribute::*)(  const handle<TDF_AttributeDelta> & ,   const bool  ) ) static_cast<bool (TDF_Attribute::*)(  const handle<TDF_AttributeDelta> & ,   const bool  ) >(&TDF_Attribute::BeforeUndo),
             R"#(Something to do before applying <anAttDelta>. The returned status says if AfterUndo has been performed (true) or if this callback must be called once again further (false). If <forceIt> is set to true, the method MUST perform and return true. Does nothing by default and returns true.)#"  , py::arg("anAttDelta"),  py::arg("forceIt")=static_cast< const bool>(false)
          )
        .def("AfterUndo",
             (bool (TDF_Attribute::*)(  const handle<TDF_AttributeDelta> & ,   const bool  ) ) static_cast<bool (TDF_Attribute::*)(  const handle<TDF_AttributeDelta> & ,   const bool  ) >(&TDF_Attribute::AfterUndo),
             R"#(Something to do after applying <anAttDelta>. The returned status says if AfterUndo has been performed (true) or if this callback must be called once again further (false). If <forceIt> is set to true, the method MUST perform and return true. Does nothing by default and returns true.)#"  , py::arg("anAttDelta"),  py::arg("forceIt")=static_cast< const bool>(false)
          )
        .def("BeforeCommitTransaction",
             (void (TDF_Attribute::*)() ) static_cast<void (TDF_Attribute::*)() >(&TDF_Attribute::BeforeCommitTransaction),
             R"#(A callback. By default does nothing. It is called by TDF_Data::CommitTransaction() method.)#" 
          )
        .def("Backup",
             (void (TDF_Attribute::*)() ) static_cast<void (TDF_Attribute::*)() >(&TDF_Attribute::Backup),
             R"#(Backups the attribute. The backuped attribute is flagged "Backuped" and not "Valid".)#" 
          )
        .def("IsBackuped",
             (bool (TDF_Attribute::*)() const) static_cast<bool (TDF_Attribute::*)() const>(&TDF_Attribute::IsBackuped),
             R"#(Returns true if the attribute backup status is set. This status is set/unset by the Backup() method.)#" 
          )
        .def("BackupCopy",
             (handle<TDF_Attribute> (TDF_Attribute::*)() const) static_cast<handle<TDF_Attribute> (TDF_Attribute::*)() const>(&TDF_Attribute::BackupCopy),
             R"#(Copies the attribute contents into a new other attribute. It is used by Backup().)#" 
          )
        .def("Restore",
             (void (TDF_Attribute::*)(  const handle<TDF_Attribute> &  ) ) static_cast<void (TDF_Attribute::*)(  const handle<TDF_Attribute> &  ) >(&TDF_Attribute::Restore),
             R"#(Restores the backuped contents from <anAttribute> into this one. It is used when aborting a transaction.)#"  , py::arg("anAttribute")
          )
        .def("DeltaOnAddition",
             (handle<TDF_DeltaOnAddition> (TDF_Attribute::*)() const) static_cast<handle<TDF_DeltaOnAddition> (TDF_Attribute::*)() const>(&TDF_Attribute::DeltaOnAddition),
             R"#(Makes an AttributeDelta because <me> appeared. The only known use of a redefinition of this method is to return a null handle (no delta).)#" 
          )
        .def("DeltaOnForget",
             (handle<TDF_DeltaOnForget> (TDF_Attribute::*)() const) static_cast<handle<TDF_DeltaOnForget> (TDF_Attribute::*)() const>(&TDF_Attribute::DeltaOnForget),
             R"#(Makes an AttributeDelta because <me> has been forgotten.)#" 
          )
        .def("DeltaOnResume",
             (handle<TDF_DeltaOnResume> (TDF_Attribute::*)() const) static_cast<handle<TDF_DeltaOnResume> (TDF_Attribute::*)() const>(&TDF_Attribute::DeltaOnResume),
             R"#(Makes an AttributeDelta because <me> has been resumed.)#" 
          )
        .def("DeltaOnModification",
             (handle<TDF_DeltaOnModification> (TDF_Attribute::*)(  const handle<TDF_Attribute> &  ) const) static_cast<handle<TDF_DeltaOnModification> (TDF_Attribute::*)(  const handle<TDF_Attribute> &  ) const>(&TDF_Attribute::DeltaOnModification),
             R"#(Makes a DeltaOnModification between <me> and <anOldAttribute.)#"  , py::arg("anOldAttribute")
          )
        .def("DeltaOnModification",
             (void (TDF_Attribute::*)(  const handle<TDF_DeltaOnModification> &  ) ) static_cast<void (TDF_Attribute::*)(  const handle<TDF_DeltaOnModification> &  ) >(&TDF_Attribute::DeltaOnModification),
             R"#(Applies a DeltaOnModification to <me>.)#"  , py::arg("aDelta")
          )
        .def("DeltaOnRemoval",
             (handle<TDF_DeltaOnRemoval> (TDF_Attribute::*)() const) static_cast<handle<TDF_DeltaOnRemoval> (TDF_Attribute::*)() const>(&TDF_Attribute::DeltaOnRemoval),
             R"#(Makes a DeltaOnRemoval on <me> because <me> has disappeared from the DS.)#" 
          )
        .def("NewEmpty",
             (handle<TDF_Attribute> (TDF_Attribute::*)() const) static_cast<handle<TDF_Attribute> (TDF_Attribute::*)() const>(&TDF_Attribute::NewEmpty),
             R"#(Returns an new empty attribute from the good end type. It is used by the copy algorithm.)#" 
          )
        .def("Paste",
             (void (TDF_Attribute::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const) static_cast<void (TDF_Attribute::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const>(&TDF_Attribute::Paste),
             R"#(This method is different from the "Copy" one, because it is used when copying an attribute from a source structure into a target structure. This method may paste the contents of <me> into <intoAttribute>.)#"  , py::arg("intoAttribute"),  py::arg("aRelocationTable")
          )
        .def("References",
             (void (TDF_Attribute::*)(  const handle<TDF_DataSet> &  ) const) static_cast<void (TDF_Attribute::*)(  const handle<TDF_DataSet> &  ) const>(&TDF_Attribute::References),
             R"#(Adds the first level referenced attributes and labels to <aDataSet>.)#"  , py::arg("aDataSet")
          )
        .def("Dump",
             (Standard_OStream & (TDF_Attribute::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDF_Attribute::*)( Standard_OStream &  ) const>(&TDF_Attribute::Dump),
             R"#(Dumps the minimum information about <me> on <aStream>.)#"  , py::arg("anOS")
          )
        .def("ExtendedDump",
             (void (TDF_Attribute::*)( Standard_OStream & ,   const TDF_IDFilter & ,  NCollection_IndexedMap<handle<TDF_Attribute>> &  ) const) static_cast<void (TDF_Attribute::*)( Standard_OStream & ,   const TDF_IDFilter & ,  NCollection_IndexedMap<handle<TDF_Attribute>> &  ) const>(&TDF_Attribute::ExtendedDump),
             R"#(Dumps the attribute content on <aStream>, using <aMap> like this: if an attribute is not in the map, first put add it to the map and then dump it. Use the map rank instead of dumping each attribute field.)#"  , py::arg("anOS"),  py::arg("aFilter"),  py::arg("aMap")
          )
        .def("Forget",
             (void (TDF_Attribute::*)(  const int  ) ) static_cast<void (TDF_Attribute::*)(  const int  ) >(&TDF_Attribute::Forget),
             R"#(Forgets the attribute. <aTransaction> is the current transaction in which the forget is done. A forgotten attribute is also flagged not "Valid".)#"  , py::arg("aTransaction")
          )
        .def("DumpJson",
             (void (TDF_Attribute::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDF_Attribute::*)( Standard_OStream & ,  int  ) const>(&TDF_Attribute::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
        .def("Transaction",
             (int (TDF_Attribute::*)() const) static_cast<int (TDF_Attribute::*)() const>(&TDF_Attribute::Transaction),
             R"#(Returns the transaction index in which the attribute has been created or modified.)#" 
          )
        .def("IsValid",
             (bool (TDF_Attribute::*)() const) static_cast<bool (TDF_Attribute::*)() const>(&TDF_Attribute::IsValid),
             R"#(Returns true if the attribute is valid; i.e. not a backuped or removed one.)#" 
          )
        .def("IsBackuped",
             (bool (TDF_Attribute::*)() const) static_cast<bool (TDF_Attribute::*)() const>(&TDF_Attribute::IsBackuped),
             R"#(Returns true if the attribute backup status is set. This status is set/unset by the Backup() method.)#" 
          )
        .def("IsNew",
             (bool (TDF_Attribute::*)() const) static_cast<bool (TDF_Attribute::*)() const>(&TDF_Attribute::IsNew),
             R"#(Returns true if the attribute has no backup)#" 
          )
        .def("IsForgotten",
             (bool (TDF_Attribute::*)() const) static_cast<bool (TDF_Attribute::*)() const>(&TDF_Attribute::IsForgotten),
             R"#(Returns true if the attribute forgotten status is set.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDF_Attribute::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDF_Attribute::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDF_Attribute::*)() const) static_cast< const handle<Standard_Type> & (TDF_Attribute::*)() const>(&TDF_Attribute::DynamicType),
             R"#()#"
             
         )
;

    // Class TDF_AttributeDelta from ./opencascade/TDF_AttributeDelta.hxx
    klass = m.attr("TDF_AttributeDelta");


    // nested enums

    static_cast<py::class_<TDF_AttributeDelta ,opencascade::handle<TDF_AttributeDelta> ,Py_TDF_AttributeDelta , Standard_Transient >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("Apply",
             (void (TDF_AttributeDelta::*)() ) static_cast<void (TDF_AttributeDelta::*)() >(&TDF_AttributeDelta::Apply),
             R"#(Applies the delta to the attribute.)#" 
          )
        .def("Label",
             (TDF_Label (TDF_AttributeDelta::*)() const) static_cast<TDF_Label (TDF_AttributeDelta::*)() const>(&TDF_AttributeDelta::Label),
             R"#(Returns the label concerned by <me>.)#" 
          )
        .def("Attribute",
             (handle<TDF_Attribute> (TDF_AttributeDelta::*)() const) static_cast<handle<TDF_Attribute> (TDF_AttributeDelta::*)() const>(&TDF_AttributeDelta::Attribute),
             R"#(Returns the reference attribute.)#" 
          )
        .def("ID",
             (Standard_GUID (TDF_AttributeDelta::*)() const) static_cast<Standard_GUID (TDF_AttributeDelta::*)() const>(&TDF_AttributeDelta::ID),
             R"#(Returns the ID of the attribute concerned by <me>.)#" 
          )
        .def("Dump",
             (Standard_OStream & (TDF_AttributeDelta::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDF_AttributeDelta::*)( Standard_OStream &  ) const>(&TDF_AttributeDelta::Dump),
             R"#(Dumps the contents.)#"  , py::arg("OS")
          )
        .def("DumpJson",
             (void (TDF_AttributeDelta::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDF_AttributeDelta::*)( Standard_OStream & ,  int  ) const>(&TDF_AttributeDelta::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDF_AttributeDelta::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDF_AttributeDelta::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDF_AttributeDelta::*)() const) static_cast< const handle<Standard_Type> & (TDF_AttributeDelta::*)() const>(&TDF_AttributeDelta::DynamicType),
             R"#()#"
             
         )
;

    // Class TDF_AttributeIterator from ./opencascade/TDF_AttributeIterator.hxx
    klass = m.attr("TDF_AttributeIterator");


    // nested enums

    static_cast<py::class_<TDF_AttributeIterator , shared_ptr<TDF_AttributeIterator>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const TDF_Label &, const bool >()  , py::arg("aLabel"),  py::arg("withoutForgotten")=static_cast< const bool>(true) )
        .def(py::init<  const TDF_LabelNodePtr, const bool >()  , py::arg("aLabelNode"),  py::arg("withoutForgotten")=static_cast< const bool>(true) )
    // custom constructors
    // methods
        .def("Initialize",
             (void (TDF_AttributeIterator::*)(  const TDF_Label & ,   const bool  ) ) static_cast<void (TDF_AttributeIterator::*)(  const TDF_Label & ,   const bool  ) >(&TDF_AttributeIterator::Initialize),
             R"#()#"  , py::arg("aLabel"),  py::arg("withoutForgotten")=static_cast< const bool>(true)
          )
        .def("More",
             (bool (TDF_AttributeIterator::*)() const) static_cast<bool (TDF_AttributeIterator::*)() const>(&TDF_AttributeIterator::More),
             R"#()#" 
          )
        .def("Next",
             (void (TDF_AttributeIterator::*)() ) static_cast<void (TDF_AttributeIterator::*)() >(&TDF_AttributeIterator::Next),
             R"#()#" 
          )
        .def("Value",
             (handle<TDF_Attribute> (TDF_AttributeIterator::*)() const) static_cast<handle<TDF_Attribute> (TDF_AttributeIterator::*)() const>(&TDF_AttributeIterator::Value),
             R"#()#" 
          )
        .def("PtrValue",
             ( const TDF_Attribute * (TDF_AttributeIterator::*)() const) static_cast< const TDF_Attribute * (TDF_AttributeIterator::*)() const>(&TDF_AttributeIterator::PtrValue),
             R"#(Provides an access to the internal pointer of the current attribute. The method has better performance as not-creating handle.)#" 
          )
        .def("More",
             (bool (TDF_AttributeIterator::*)() const) static_cast<bool (TDF_AttributeIterator::*)() const>(&TDF_AttributeIterator::More),
             R"#()#" 
          )
        .def("Value",
             (handle<TDF_Attribute> (TDF_AttributeIterator::*)() const) static_cast<handle<TDF_Attribute> (TDF_AttributeIterator::*)() const>(&TDF_AttributeIterator::Value),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class TDF_ChildIDIterator from ./opencascade/TDF_ChildIDIterator.hxx
    klass = m.attr("TDF_ChildIDIterator");


    // nested enums

    static_cast<py::class_<TDF_ChildIDIterator , shared_ptr<TDF_ChildIDIterator>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const TDF_Label &, const Standard_GUID &, const bool >()  , py::arg("aLabel"),  py::arg("anID"),  py::arg("allLevels")=static_cast< const bool>(false) )
    // custom constructors
    // methods
        .def("Initialize",
             (void (TDF_ChildIDIterator::*)(  const TDF_Label & ,   const Standard_GUID & ,   const bool  ) ) static_cast<void (TDF_ChildIDIterator::*)(  const TDF_Label & ,   const Standard_GUID & ,   const bool  ) >(&TDF_ChildIDIterator::Initialize),
             R"#(Initializes the iteration on the children of the given label. If <allLevels> option is set to true, it explores not only the first, but all the sub label levels.)#"  , py::arg("aLabel"),  py::arg("anID"),  py::arg("allLevels")=static_cast< const bool>(false)
          )
        .def("More",
             (bool (TDF_ChildIDIterator::*)() const) static_cast<bool (TDF_ChildIDIterator::*)() const>(&TDF_ChildIDIterator::More),
             R"#(Returns True if there is a current Item in the iteration.)#" 
          )
        .def("Next",
             (void (TDF_ChildIDIterator::*)() ) static_cast<void (TDF_ChildIDIterator::*)() >(&TDF_ChildIDIterator::Next),
             R"#(Move to the next Item)#" 
          )
        .def("NextBrother",
             (void (TDF_ChildIDIterator::*)() ) static_cast<void (TDF_ChildIDIterator::*)() >(&TDF_ChildIDIterator::NextBrother),
             R"#(Move to the next Brother. If there is none, go up etc. This method is interesting only with "allLevels" behavior, because it avoids to explore the current label children.)#" 
          )
        .def("Value",
             (handle<TDF_Attribute> (TDF_ChildIDIterator::*)() const) static_cast<handle<TDF_Attribute> (TDF_ChildIDIterator::*)() const>(&TDF_ChildIDIterator::Value),
             R"#(Returns the current item; a null handle if there is none.)#" 
          )
        .def("More",
             (bool (TDF_ChildIDIterator::*)() const) static_cast<bool (TDF_ChildIDIterator::*)() const>(&TDF_ChildIDIterator::More),
             R"#(Returns True if there is a current Item in the iteration.)#" 
          )
        .def("Value",
             (handle<TDF_Attribute> (TDF_ChildIDIterator::*)() const) static_cast<handle<TDF_Attribute> (TDF_ChildIDIterator::*)() const>(&TDF_ChildIDIterator::Value),
             R"#(Returns the current item; a null handle if there is none.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class TDF_ChildIterator from ./opencascade/TDF_ChildIterator.hxx
    klass = m.attr("TDF_ChildIterator");


    // nested enums

    static_cast<py::class_<TDF_ChildIterator , shared_ptr<TDF_ChildIterator>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const TDF_Label &, const bool >()  , py::arg("aLabel"),  py::arg("allLevels")=static_cast< const bool>(false) )
    // custom constructors
    // methods
        .def("Initialize",
             (void (TDF_ChildIterator::*)(  const TDF_Label & ,   const bool  ) ) static_cast<void (TDF_ChildIterator::*)(  const TDF_Label & ,   const bool  ) >(&TDF_ChildIterator::Initialize),
             R"#(Initializes the iteration on the children of the given label. If <allLevels> option is set to true, it explores not only the first, but all the sub label levels. If allLevels is false, only the first level of child labels is explored. In the example below, the label is iterated using Initialize, More and Next and its child labels dumped using TDF_Tool::Entry. Example void DumpChildren(const TDF_Label& aLabel) { TDF_ChildIterator it; TCollection_AsciiString es; for (it.Initialize(aLabel,true); it.More(); it.Next()){ TDF_Tool::Entry(it.Value(),es); std::cout << as.ToCString() << std::endl; } })#"  , py::arg("aLabel"),  py::arg("allLevels")=static_cast< const bool>(false)
          )
        .def("More",
             (bool (TDF_ChildIterator::*)() const) static_cast<bool (TDF_ChildIterator::*)() const>(&TDF_ChildIterator::More),
             R"#(Returns true if a current label is found in the iteration process.)#" 
          )
        .def("Next",
             (void (TDF_ChildIterator::*)() ) static_cast<void (TDF_ChildIterator::*)() >(&TDF_ChildIterator::Next),
             R"#(Move the current iteration to the next Item.)#" 
          )
        .def("NextBrother",
             (void (TDF_ChildIterator::*)() ) static_cast<void (TDF_ChildIterator::*)() >(&TDF_ChildIterator::NextBrother),
             R"#(Moves this iteration to the next brother label. A brother label is one with the same father as an initial label. Use this function when the non-empty constructor or Initialize has allLevels set to true. The result is that the iteration does not explore the children of the current label. This method is interesting only with "allLevels" behavior, because it avoids to explore the current label children.)#" 
          )
        .def("Value",
             ( const TDF_Label (TDF_ChildIterator::*)() const) static_cast< const TDF_Label (TDF_ChildIterator::*)() const>(&TDF_ChildIterator::Value),
             R"#(Returns the current label; or, if there is none, a null label.)#" 
          )
        .def("More",
             (bool (TDF_ChildIterator::*)() const) static_cast<bool (TDF_ChildIterator::*)() const>(&TDF_ChildIterator::More),
             R"#(Returns true if a current label is found in the iteration process.)#" 
          )
        .def("Value",
             ( const TDF_Label (TDF_ChildIterator::*)() const) static_cast< const TDF_Label (TDF_ChildIterator::*)() const>(&TDF_ChildIterator::Value),
             R"#(Returns the current label; or, if there is none, a null label.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class TDF_ClosureMode from ./opencascade/TDF_ClosureMode.hxx
    klass = m.attr("TDF_ClosureMode");


    // nested enums

    static_cast<py::class_<TDF_ClosureMode , shared_ptr<TDF_ClosureMode>  >>(klass)
    // constructors
        .def(py::init<  const bool >()  , py::arg("aMode")=static_cast< const bool>(true) )
    // custom constructors
    // methods
        .def("Descendants",
             (void (TDF_ClosureMode::*)(  const bool  ) ) static_cast<void (TDF_ClosureMode::*)(  const bool  ) >(&TDF_ClosureMode::Descendants),
             R"#(Sets the mode "Descendants" to <aStatus>.)#"  , py::arg("aStatus")
          )
        .def("Descendants",
             (bool (TDF_ClosureMode::*)() const) static_cast<bool (TDF_ClosureMode::*)() const>(&TDF_ClosureMode::Descendants),
             R"#(Returns true if the mode "Descendants" is set.)#" 
          )
        .def("References",
             (void (TDF_ClosureMode::*)(  const bool  ) ) static_cast<void (TDF_ClosureMode::*)(  const bool  ) >(&TDF_ClosureMode::References),
             R"#(Sets the mode "References" to <aStatus>.)#"  , py::arg("aStatus")
          )
        .def("References",
             (bool (TDF_ClosureMode::*)() const) static_cast<bool (TDF_ClosureMode::*)() const>(&TDF_ClosureMode::References),
             R"#(Returns true if the mode "References" is set.)#" 
          )
        .def("Descendants",
             (void (TDF_ClosureMode::*)(  const bool  ) ) static_cast<void (TDF_ClosureMode::*)(  const bool  ) >(&TDF_ClosureMode::Descendants),
             R"#(Sets the mode "Descendants" to <aStatus>.)#"  , py::arg("aStatus")
          )
        .def("Descendants",
             (bool (TDF_ClosureMode::*)() const) static_cast<bool (TDF_ClosureMode::*)() const>(&TDF_ClosureMode::Descendants),
             R"#(Returns true if the mode "Descendants" is set.)#" 
          )
        .def("References",
             (void (TDF_ClosureMode::*)(  const bool  ) ) static_cast<void (TDF_ClosureMode::*)(  const bool  ) >(&TDF_ClosureMode::References),
             R"#(Sets the mode "References" to <aStatus>.)#"  , py::arg("aStatus")
          )
        .def("References",
             (bool (TDF_ClosureMode::*)() const) static_cast<bool (TDF_ClosureMode::*)() const>(&TDF_ClosureMode::References),
             R"#(Returns true if the mode "References" is set.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class TDF_ClosureTool from ./opencascade/TDF_ClosureTool.hxx
    klass = m.attr("TDF_ClosureTool");

    // default constructor
    register_default_constructor<TDF_ClosureTool , shared_ptr<TDF_ClosureTool>>(m,"TDF_ClosureTool");

    // nested enums

    static_cast<py::class_<TDF_ClosureTool , shared_ptr<TDF_ClosureTool>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Closure_s",
                    (void (*)(  const handle<TDF_DataSet> &  ) ) static_cast<void (*)(  const handle<TDF_DataSet> &  ) >(&TDF_ClosureTool::Closure),
                    R"#(Builds the transitive closure of label and attribute sets into <aDataSet>.)#"  , py::arg("aDataSet")
          )
        .def_static("Closure_s",
                    (void (*)(  const handle<TDF_DataSet> & ,   const TDF_IDFilter & ,   const TDF_ClosureMode &  ) ) static_cast<void (*)(  const handle<TDF_DataSet> & ,   const TDF_IDFilter & ,   const TDF_ClosureMode &  ) >(&TDF_ClosureTool::Closure),
                    R"#(Builds the transitive closure of label and attribute sets into <aDataSet>. Uses <aFilter> to determine if an attribute has to be taken in account or not. Uses <aMode> for various way of closing.)#"  , py::arg("aDataSet"),  py::arg("aFilter"),  py::arg("aMode")
          )
        .def_static("Closure_s",
                    (void (*)(  const TDF_Label & ,  NCollection_Map<TDF_Label> & ,  NCollection_Map<handle<TDF_Attribute>> & ,   const TDF_IDFilter & ,   const TDF_ClosureMode &  ) ) static_cast<void (*)(  const TDF_Label & ,  NCollection_Map<TDF_Label> & ,  NCollection_Map<handle<TDF_Attribute>> & ,   const TDF_IDFilter & ,   const TDF_ClosureMode &  ) >(&TDF_ClosureTool::Closure),
                    R"#(Builds the transitive closure of <aLabel>.)#"  , py::arg("aLabel"),  py::arg("aLabMap"),  py::arg("anAttMap"),  py::arg("aFilter"),  py::arg("aMode")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class TDF_ComparisonTool from ./opencascade/TDF_ComparisonTool.hxx
    klass = m.attr("TDF_ComparisonTool");

    // default constructor
    register_default_constructor<TDF_ComparisonTool , shared_ptr<TDF_ComparisonTool>>(m,"TDF_ComparisonTool");

    // nested enums

    static_cast<py::class_<TDF_ComparisonTool , shared_ptr<TDF_ComparisonTool>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Compare_s",
                    (void (*)(  const handle<TDF_DataSet> & ,   const handle<TDF_DataSet> & ,   const TDF_IDFilter & ,   const handle<TDF_RelocationTable> &  ) ) static_cast<void (*)(  const handle<TDF_DataSet> & ,   const handle<TDF_DataSet> & ,   const TDF_IDFilter & ,   const handle<TDF_RelocationTable> &  ) >(&TDF_ComparisonTool::Compare),
                    R"#(Compares <aSourceDataSet> with <aTargetDataSet>, updating <aRelocationTable> with labels and attributes found in both sets.)#"  , py::arg("aSourceDataSet"),  py::arg("aTargetDataSet"),  py::arg("aFilter"),  py::arg("aRelocationTable")
          )
        .def_static("SourceUnbound_s",
                    (bool (*)(  const handle<TDF_DataSet> & ,   const handle<TDF_RelocationTable> & ,   const TDF_IDFilter & ,   const handle<TDF_DataSet> & ,   const int  ) ) static_cast<bool (*)(  const handle<TDF_DataSet> & ,   const handle<TDF_RelocationTable> & ,   const TDF_IDFilter & ,   const handle<TDF_DataSet> & ,   const int  ) >(&TDF_ComparisonTool::SourceUnbound),
                    R"#(Finds from <aRefDataSet> all the keys not bound into <aRelocationTable> and put them into <aDiffDataSet>. Returns True if the difference contains at least one key. (A key is a source object).)#"  , py::arg("aRefDataSet"),  py::arg("aRelocationTable"),  py::arg("aFilter"),  py::arg("aDiffDataSet"),  py::arg("anOption")=static_cast< const int>(2)
          )
        .def_static("TargetUnbound_s",
                    (bool (*)(  const handle<TDF_DataSet> & ,   const handle<TDF_RelocationTable> & ,   const TDF_IDFilter & ,   const handle<TDF_DataSet> & ,   const int  ) ) static_cast<bool (*)(  const handle<TDF_DataSet> & ,   const handle<TDF_RelocationTable> & ,   const TDF_IDFilter & ,   const handle<TDF_DataSet> & ,   const int  ) >(&TDF_ComparisonTool::TargetUnbound),
                    R"#(Subtracts from <aRefDataSet> all the items bound into <aRelocationTable>. The result is put into <aDiffDataSet>. Returns True if the difference contains at least one item. (An item is a target object).)#"  , py::arg("aRefDataSet"),  py::arg("aRelocationTable"),  py::arg("aFilter"),  py::arg("aDiffDataSet"),  py::arg("anOption")=static_cast< const int>(2)
          )
        .def_static("Cut_s",
                    (void (*)(  const handle<TDF_DataSet> &  ) ) static_cast<void (*)(  const handle<TDF_DataSet> &  ) >(&TDF_ComparisonTool::Cut),
                    R"#(Removes attributes from <aDataSet>.)#"  , py::arg("aDataSet")
          )
        .def_static("IsSelfContained_s",
                    (bool (*)(  const TDF_Label & ,   const handle<TDF_DataSet> &  ) ) static_cast<bool (*)(  const TDF_Label & ,   const handle<TDF_DataSet> &  ) >(&TDF_ComparisonTool::IsSelfContained),
                    R"#(Returns true if all the labels of <aDataSet> are descendant of <aLabel>.)#"  , py::arg("aLabel"),  py::arg("aDataSet")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class TDF_CopyLabel from ./opencascade/TDF_CopyLabel.hxx
    klass = m.attr("TDF_CopyLabel");


    // nested enums

    static_cast<py::class_<TDF_CopyLabel , shared_ptr<TDF_CopyLabel>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const TDF_Label &, const TDF_Label & >()  , py::arg("aSource"),  py::arg("aTarget") )
    // custom constructors
    // methods
        .def("Load",
             (void (TDF_CopyLabel::*)(  const TDF_Label & ,   const TDF_Label &  ) ) static_cast<void (TDF_CopyLabel::*)(  const TDF_Label & ,   const TDF_Label &  ) >(&TDF_CopyLabel::Load),
             R"#(Loads src and tgt labels)#"  , py::arg("aSource"),  py::arg("aTarget")
          )
        .def("UseFilter",
             (void (TDF_CopyLabel::*)(  const TDF_IDFilter &  ) ) static_cast<void (TDF_CopyLabel::*)(  const TDF_IDFilter &  ) >(&TDF_CopyLabel::UseFilter),
             R"#(Sets filter)#"  , py::arg("aFilter")
          )
        .def("Perform",
             (void (TDF_CopyLabel::*)() ) static_cast<void (TDF_CopyLabel::*)() >(&TDF_CopyLabel::Perform),
             R"#(performs algorithm of selfcontained copy)#" 
          )
        .def("IsDone",
             (bool (TDF_CopyLabel::*)() const) static_cast<bool (TDF_CopyLabel::*)() const>(&TDF_CopyLabel::IsDone),
             R"#()#" 
          )
        .def("IsDone",
             (bool (TDF_CopyLabel::*)() const) static_cast<bool (TDF_CopyLabel::*)() const>(&TDF_CopyLabel::IsDone),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("ExternalReferences_s",
                    (bool (*)(  const TDF_Label & ,  NCollection_Map<handle<TDF_Attribute>> & ,   const TDF_IDFilter &  ) ) static_cast<bool (*)(  const TDF_Label & ,  NCollection_Map<handle<TDF_Attribute>> & ,   const TDF_IDFilter &  ) >(&TDF_CopyLabel::ExternalReferences),
                    R"#(Check external references and if exist fills the aExternals Map)#"  , py::arg("Lab"),  py::arg("aExternals"),  py::arg("aFilter")
          )
    // static methods using call by reference i.s.o. return
        .def_static("ExternalReferences_s",
            []( const TDF_Label & aRefLab, const TDF_Label & Lab,NCollection_Map<handle<TDF_Attribute>> & aExternals, const TDF_IDFilter & aFilter,TDF_DataSet& aDataSet ){
                handle<TDF_DataSet>  aDataSet_ptr; aDataSet_ptr = &aDataSet;

                TDF_CopyLabel::ExternalReferences(aRefLab,Lab,aExternals,aFilter,aDataSet_ptr);
                if ( aDataSet_ptr.get() != &aDataSet ) copy_if_assignable(aDataSet, *aDataSet_ptr);

 },
            R"#(Check external references and if exist fills the aExternals Map)#"  , py::arg("aRefLab"),  py::arg("Lab"),  py::arg("aExternals"),  py::arg("aFilter"),  py::arg("aDataSet")
          )
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("RelocationTable",
             ( const handle<TDF_RelocationTable> & (TDF_CopyLabel::*)() const) static_cast< const handle<TDF_RelocationTable> & (TDF_CopyLabel::*)() const>(&TDF_CopyLabel::RelocationTable),
             R"#(returns relocation table)#"
             
         )
;

    // Class TDF_CopyTool from ./opencascade/TDF_CopyTool.hxx
    klass = m.attr("TDF_CopyTool");

    // default constructor
    register_default_constructor<TDF_CopyTool , shared_ptr<TDF_CopyTool>>(m,"TDF_CopyTool");

    // nested enums

    static_cast<py::class_<TDF_CopyTool , shared_ptr<TDF_CopyTool>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Copy_s",
                    (void (*)(  const handle<TDF_DataSet> & ,   const handle<TDF_RelocationTable> &  ) ) static_cast<void (*)(  const handle<TDF_DataSet> & ,   const handle<TDF_RelocationTable> &  ) >(&TDF_CopyTool::Copy),
                    R"#(Copy <aSourceDataSet> with using and updating <aRelocationTable>. This method ignores target attributes privilege over source ones.)#"  , py::arg("aSourceDataSet"),  py::arg("aRelocationTable")
          )
        .def_static("Copy_s",
                    (void (*)(  const handle<TDF_DataSet> & ,   const handle<TDF_RelocationTable> & ,   const TDF_IDFilter &  ) ) static_cast<void (*)(  const handle<TDF_DataSet> & ,   const handle<TDF_RelocationTable> & ,   const TDF_IDFilter &  ) >(&TDF_CopyTool::Copy),
                    R"#(Copy <aSourceDataSet> using and updating <aRelocationTable>. Use <aPrivilegeFilter> to give a list of IDs for which the target attribute prevails over the source one.)#"  , py::arg("aSourceDataSet"),  py::arg("aRelocationTable"),  py::arg("aPrivilegeFilter")
          )
        .def_static("Copy_s",
                    (void (*)(  const handle<TDF_DataSet> & ,   const handle<TDF_RelocationTable> & ,   const TDF_IDFilter & ,   const TDF_IDFilter & ,   const bool  ) ) static_cast<void (*)(  const handle<TDF_DataSet> & ,   const handle<TDF_RelocationTable> & ,   const TDF_IDFilter & ,   const TDF_IDFilter & ,   const bool  ) >(&TDF_CopyTool::Copy),
                    R"#(Copy <aSourceDataSet> using and updating <aRelocationTable>. Use <aPrivilegeFilter> to give a list of IDs for which the target attribute prevails over the source one. If <setSelfContained> is set to true, every TDF_Reference will be replaced by the referenced structure according to <aRefFilter>.)#"  , py::arg("aSourceDataSet"),  py::arg("aRelocationTable"),  py::arg("aPrivilegeFilter"),  py::arg("aRefFilter"),  py::arg("setSelfContained")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class TDF_Data from ./opencascade/TDF_Data.hxx
    klass = m.attr("TDF_Data");


    // nested enums

    static_cast<py::class_<TDF_Data ,opencascade::handle<TDF_Data>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Root",
             ( const TDF_Label (TDF_Data::*)() const) static_cast< const TDF_Label (TDF_Data::*)() const>(&TDF_Data::Root),
             R"#(Returns the root label of the Data structure.)#" 
          )
        .def("Transaction",
             (int (TDF_Data::*)() const) static_cast<int (TDF_Data::*)() const>(&TDF_Data::Transaction),
             R"#(Returns the current transaction number.)#" 
          )
        .def("Time",
             (int (TDF_Data::*)() const) static_cast<int (TDF_Data::*)() const>(&TDF_Data::Time),
             R"#(Returns the current tick. It is incremented each Commit.)#" 
          )
        .def("IsApplicable",
             (bool (TDF_Data::*)(  const handle<TDF_Delta> &  ) const) static_cast<bool (TDF_Data::*)(  const handle<TDF_Delta> &  ) const>(&TDF_Data::IsApplicable),
             R"#(Returns true if <aDelta> is applicable HERE and NOW.)#"  , py::arg("aDelta")
          )
        .def("Undo",
             (handle<TDF_Delta> (TDF_Data::*)(  const handle<TDF_Delta> & ,   const bool  ) ) static_cast<handle<TDF_Delta> (TDF_Data::*)(  const handle<TDF_Delta> & ,   const bool  ) >(&TDF_Data::Undo),
             R"#(Apply <aDelta> to undo a set of attribute modifications.)#"  , py::arg("aDelta"),  py::arg("withDelta")=static_cast< const bool>(false)
          )
        .def("Destroy",
             (void (TDF_Data::*)() ) static_cast<void (TDF_Data::*)() >(&TDF_Data::Destroy),
             R"#()#" 
          )
        .def("NotUndoMode",
             (bool (TDF_Data::*)() const) static_cast<bool (TDF_Data::*)() const>(&TDF_Data::NotUndoMode),
             R"#(Returns the undo mode status.)#" 
          )
        .def("Dump",
             (Standard_OStream & (TDF_Data::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDF_Data::*)( Standard_OStream &  ) const>(&TDF_Data::Dump),
             R"#(Dumps the Data on <aStream>.)#"  , py::arg("anOS")
          )
        .def("AllowModification",
             (void (TDF_Data::*)(  const bool  ) ) static_cast<void (TDF_Data::*)(  const bool  ) >(&TDF_Data::AllowModification),
             R"#(Sets modification mode.)#"  , py::arg("isAllowed")
          )
        .def("IsModificationAllowed",
             (bool (TDF_Data::*)() const) static_cast<bool (TDF_Data::*)() const>(&TDF_Data::IsModificationAllowed),
             R"#(returns modification mode.)#" 
          )
        .def("SetAccessByEntries",
             (void (TDF_Data::*)(  const bool  ) ) static_cast<void (TDF_Data::*)(  const bool  ) >(&TDF_Data::SetAccessByEntries),
             R"#(Initializes a mechanism for fast access to the labels by their entries. The fast access is useful for large documents and often access to the labels via entries. Internally, a table of entry - label is created, which allows to obtain a label by its entry in a very fast way. If the mechanism is turned off, the internal table is cleaned. New labels are added to the table, if the mechanism is on (no need to re-initialize the mechanism).)#"  , py::arg("aSet")
          )
        .def("IsAccessByEntries",
             (bool (TDF_Data::*)() const) static_cast<bool (TDF_Data::*)() const>(&TDF_Data::IsAccessByEntries),
             R"#(Returns a status of mechanism for fast access to the labels via entries.)#" 
          )
        .def("GetLabel",
             (bool (TDF_Data::*)(  const TCollection_AsciiString & ,  TDF_Label &  ) ) static_cast<bool (TDF_Data::*)(  const TCollection_AsciiString & ,  TDF_Label &  ) >(&TDF_Data::GetLabel),
             R"#(Returns a label by an entry. Returns false, if such a label doesn't exist or mechanism for fast access to the label by entry is not initialized.)#"  , py::arg("anEntry"),  py::arg("aLabel")
          )
        .def("RegisterLabel",
             (void (TDF_Data::*)(  const TDF_Label &  ) ) static_cast<void (TDF_Data::*)(  const TDF_Label &  ) >(&TDF_Data::RegisterLabel),
             R"#(An internal method. It is used internally on creation of new labels. It adds a new label into internal table for fast access to the labels by entry.)#"  , py::arg("aLabel")
          )
        .def("DumpJson",
             (void (TDF_Data::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDF_Data::*)( Standard_OStream & ,  int  ) const>(&TDF_Data::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
        .def("Transaction",
             (int (TDF_Data::*)() const) static_cast<int (TDF_Data::*)() const>(&TDF_Data::Transaction),
             R"#(Returns the current transaction number.)#" 
          )
        .def("Root",
             ( const TDF_Label (TDF_Data::*)() const) static_cast< const TDF_Label (TDF_Data::*)() const>(&TDF_Data::Root),
             R"#(Returns the root label of the Data structure.)#" 
          )
        .def("Time",
             (int (TDF_Data::*)() const) static_cast<int (TDF_Data::*)() const>(&TDF_Data::Time),
             R"#(Returns the current tick. It is incremented each Commit.)#" 
          )
        .def("NotUndoMode",
             (bool (TDF_Data::*)() const) static_cast<bool (TDF_Data::*)() const>(&TDF_Data::NotUndoMode),
             R"#(Returns the undo mode status.)#" 
          )
        .def("AllowModification",
             (void (TDF_Data::*)(  const bool  ) ) static_cast<void (TDF_Data::*)(  const bool  ) >(&TDF_Data::AllowModification),
             R"#(Sets modification mode.)#"  , py::arg("theAllowModification")
          )
        .def("IsModificationAllowed",
             (bool (TDF_Data::*)() const) static_cast<bool (TDF_Data::*)() const>(&TDF_Data::IsModificationAllowed),
             R"#(returns modification mode.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDF_Data::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDF_Data::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("LabelNodeAllocator",
             ( const TDF_HAllocator & (TDF_Data::*)() const) static_cast< const TDF_HAllocator & (TDF_Data::*)() const>(&TDF_Data::LabelNodeAllocator),
             R"#(Returns TDF_HAllocator, which is an incremental allocator used by TDF_LabelNode. This allocator is used to manage TDF_LabelNode objects, but it can also be used for allocating memory to application-specific data (be careful because this allocator does not release the memory). The benefits of this allocation scheme are noticeable when dealing with large OCAF documents, due to: 1. Very quick allocation of objects (memory heap is not used, the algorithm that replaces it is very simple). 2. Very quick destruction of objects (memory is released not by destructors of TDF_LabelNode, but rather by the destructor of TDF_Data). 3. TDF_LabelNode objects do not fragmentize the memory; they are kept compactly in a number of arrays of 16K each. 4. Swapping is reduced on large data, because each document now occupies a smaller number of memory pages.)#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDF_Data::*)() const) static_cast< const handle<Standard_Type> & (TDF_Data::*)() const>(&TDF_Data::DynamicType),
             R"#()#"
             
         )
       .def("LabelNodeAllocator",
             ( const handle<NCollection_BaseAllocator> & (TDF_Data::*)() const) static_cast< const handle<NCollection_BaseAllocator> & (TDF_Data::*)() const>(&TDF_Data::LabelNodeAllocator),
             R"#(Returns TDF_HAllocator, which is an incremental allocator used by TDF_LabelNode. This allocator is used to manage TDF_LabelNode objects, but it can also be used for allocating memory to application-specific data (be careful because this allocator does not release the memory). The benefits of this allocation scheme are noticeable when dealing with large OCAF documents, due to: 1. Very quick allocation of objects (memory heap is not used, the algorithm that replaces it is very simple). 2. Very quick destruction of objects (memory is released not by destructors of TDF_LabelNode, but rather by the destructor of TDF_Data). 3. TDF_LabelNode objects do not fragmentize the memory; they are kept compactly in a number of arrays of 16K each. 4. Swapping is reduced on large data, because each document now occupies a smaller number of memory pages.)#"
             
         )
;

    // Class TDF_DataSet from ./opencascade/TDF_DataSet.hxx
    klass = m.attr("TDF_DataSet");


    // nested enums

    static_cast<py::class_<TDF_DataSet ,opencascade::handle<TDF_DataSet>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Clear",
             (void (TDF_DataSet::*)() ) static_cast<void (TDF_DataSet::*)() >(&TDF_DataSet::Clear),
             R"#(Clears all information.)#" 
          )
        .def("IsEmpty",
             (bool (TDF_DataSet::*)() const) static_cast<bool (TDF_DataSet::*)() const>(&TDF_DataSet::IsEmpty),
             R"#(Returns true if there is at least one label or one attribute.)#" 
          )
        .def("AddLabel",
             (void (TDF_DataSet::*)(  const TDF_Label &  ) ) static_cast<void (TDF_DataSet::*)(  const TDF_Label &  ) >(&TDF_DataSet::AddLabel),
             R"#(Adds <aLabel> in the current data set.)#"  , py::arg("aLabel")
          )
        .def("ContainsLabel",
             (bool (TDF_DataSet::*)(  const TDF_Label &  ) const) static_cast<bool (TDF_DataSet::*)(  const TDF_Label &  ) const>(&TDF_DataSet::ContainsLabel),
             R"#(Returns true if the label <alabel> is in the data set.)#"  , py::arg("aLabel")
          )
        .def("AddAttribute",
             (void (TDF_DataSet::*)(  const handle<TDF_Attribute> &  ) ) static_cast<void (TDF_DataSet::*)(  const handle<TDF_Attribute> &  ) >(&TDF_DataSet::AddAttribute),
             R"#(Adds <anAttribute> into the current data set.)#"  , py::arg("anAttribute")
          )
        .def("ContainsAttribute",
             (bool (TDF_DataSet::*)(  const handle<TDF_Attribute> &  ) const) static_cast<bool (TDF_DataSet::*)(  const handle<TDF_Attribute> &  ) const>(&TDF_DataSet::ContainsAttribute),
             R"#(Returns true if <anAttribute> is in the data set.)#"  , py::arg("anAttribute")
          )
        .def("AddRoot",
             (void (TDF_DataSet::*)(  const TDF_Label &  ) ) static_cast<void (TDF_DataSet::*)(  const TDF_Label &  ) >(&TDF_DataSet::AddRoot),
             R"#(Adds a root label to <myRootLabels>.)#"  , py::arg("aLabel")
          )
        .def("Dump",
             (Standard_OStream & (TDF_DataSet::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDF_DataSet::*)( Standard_OStream &  ) const>(&TDF_DataSet::Dump),
             R"#(Dumps the minimum information about <me> on <aStream>.)#"  , py::arg("anOS")
          )
        .def("IsEmpty",
             (bool (TDF_DataSet::*)() const) static_cast<bool (TDF_DataSet::*)() const>(&TDF_DataSet::IsEmpty),
             R"#(Returns true if there is at least one label or one attribute.)#" 
          )
        .def("AddLabel",
             (void (TDF_DataSet::*)(  const TDF_Label &  ) ) static_cast<void (TDF_DataSet::*)(  const TDF_Label &  ) >(&TDF_DataSet::AddLabel),
             R"#(Adds <aLabel> in the current data set.)#"  , py::arg("aLabel")
          )
        .def("ContainsLabel",
             (bool (TDF_DataSet::*)(  const TDF_Label &  ) const) static_cast<bool (TDF_DataSet::*)(  const TDF_Label &  ) const>(&TDF_DataSet::ContainsLabel),
             R"#(Returns true if the label <alabel> is in the data set.)#"  , py::arg("aLabel")
          )
        .def("AddAttribute",
             (void (TDF_DataSet::*)(  const handle<TDF_Attribute> &  ) ) static_cast<void (TDF_DataSet::*)(  const handle<TDF_Attribute> &  ) >(&TDF_DataSet::AddAttribute),
             R"#(Adds <anAttribute> into the current data set.)#"  , py::arg("anAttribute")
          )
        .def("ContainsAttribute",
             (bool (TDF_DataSet::*)(  const handle<TDF_Attribute> &  ) const) static_cast<bool (TDF_DataSet::*)(  const handle<TDF_Attribute> &  ) const>(&TDF_DataSet::ContainsAttribute),
             R"#(Returns true if <anAttribute> is in the data set.)#"  , py::arg("anAttribute")
          )
        .def("AddRoot",
             (void (TDF_DataSet::*)(  const TDF_Label &  ) ) static_cast<void (TDF_DataSet::*)(  const TDF_Label &  ) >(&TDF_DataSet::AddRoot),
             R"#(Adds a root label to <myRootLabels>.)#"  , py::arg("aLabel")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDF_DataSet::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDF_DataSet::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Labels",
             (NCollection_Map<TDF_Label> & (TDF_DataSet::*)() ) static_cast<NCollection_Map<TDF_Label> & (TDF_DataSet::*)() >(&TDF_DataSet::Labels),
             R"#(Returns the map of labels in this data set. This map can be used directly, or updated.)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Attributes",
             (NCollection_Map<handle<TDF_Attribute>> & (TDF_DataSet::*)() ) static_cast<NCollection_Map<handle<TDF_Attribute>> & (TDF_DataSet::*)() >(&TDF_DataSet::Attributes),
             R"#(Returns the map of attributes in the current data set. This map can be used directly, or updated.)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Roots",
             (NCollection_List<TDF_Label> & (TDF_DataSet::*)() ) static_cast<NCollection_List<TDF_Label> & (TDF_DataSet::*)() >(&TDF_DataSet::Roots),
             R"#(Returns <myRootLabels> to be used or updated.)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDF_DataSet::*)() const) static_cast< const handle<Standard_Type> & (TDF_DataSet::*)() const>(&TDF_DataSet::DynamicType),
             R"#()#"
             
         )
       .def("Labels",
             (NCollection_Map<TDF_Label> & (TDF_DataSet::*)() ) static_cast<NCollection_Map<TDF_Label> & (TDF_DataSet::*)() >(&TDF_DataSet::Labels),
             R"#(Returns the map of labels in this data set. This map can be used directly, or updated.)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Attributes",
             (NCollection_Map<handle<TDF_Attribute>> & (TDF_DataSet::*)() ) static_cast<NCollection_Map<handle<TDF_Attribute>> & (TDF_DataSet::*)() >(&TDF_DataSet::Attributes),
             R"#(Returns the map of attributes in the current data set. This map can be used directly, or updated.)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Roots",
             (NCollection_List<TDF_Label> & (TDF_DataSet::*)() ) static_cast<NCollection_List<TDF_Label> & (TDF_DataSet::*)() >(&TDF_DataSet::Roots),
             R"#(Returns <myRootLabels> to be used or updated.)#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class TDF_Delta from ./opencascade/TDF_Delta.hxx
    klass = m.attr("TDF_Delta");


    // nested enums

    static_cast<py::class_<TDF_Delta ,opencascade::handle<TDF_Delta>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("IsEmpty",
             (bool (TDF_Delta::*)() const) static_cast<bool (TDF_Delta::*)() const>(&TDF_Delta::IsEmpty),
             R"#(Returns true if there is nothing to undo.)#" 
          )
        .def("IsApplicable",
             (bool (TDF_Delta::*)(  const int  ) const) static_cast<bool (TDF_Delta::*)(  const int  ) const>(&TDF_Delta::IsApplicable),
             R"#(Returns true if the Undo action of <me> is applicable at <aCurrentTime>.)#"  , py::arg("aCurrentTime")
          )
        .def("BeginTime",
             (int (TDF_Delta::*)() const) static_cast<int (TDF_Delta::*)() const>(&TDF_Delta::BeginTime),
             R"#(Returns the field <myBeginTime>.)#" 
          )
        .def("EndTime",
             (int (TDF_Delta::*)() const) static_cast<int (TDF_Delta::*)() const>(&TDF_Delta::EndTime),
             R"#(Returns the field <myEndTime>.)#" 
          )
        .def("Labels",
             (void (TDF_Delta::*)( NCollection_List<TDF_Label> &  ) const) static_cast<void (TDF_Delta::*)( NCollection_List<TDF_Label> &  ) const>(&TDF_Delta::Labels),
             R"#(Adds in <aLabelList> the labels of the attribute deltas. Caution: <aLabelList> is not cleared before use.)#"  , py::arg("aLabelList")
          )
        .def("Name",
             (TCollection_ExtendedString (TDF_Delta::*)() const) static_cast<TCollection_ExtendedString (TDF_Delta::*)() const>(&TDF_Delta::Name),
             R"#(Returns a name associated with this delta.)#" 
          )
        .def("SetName",
             (void (TDF_Delta::*)(  const TCollection_ExtendedString &  ) ) static_cast<void (TDF_Delta::*)(  const TCollection_ExtendedString &  ) >(&TDF_Delta::SetName),
             R"#(Associates a name <theName> with this delta)#"  , py::arg("theName")
          )
        .def("Dump",
             (void (TDF_Delta::*)( Standard_OStream &  ) const) static_cast<void (TDF_Delta::*)( Standard_OStream &  ) const>(&TDF_Delta::Dump),
             R"#()#"  , py::arg("OS")
          )
        .def("DumpJson",
             (void (TDF_Delta::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDF_Delta::*)( Standard_OStream & ,  int  ) const>(&TDF_Delta::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
        .def("IsEmpty",
             (bool (TDF_Delta::*)() const) static_cast<bool (TDF_Delta::*)() const>(&TDF_Delta::IsEmpty),
             R"#(Returns true if there is nothing to undo.)#" 
          )
        .def("IsApplicable",
             (bool (TDF_Delta::*)(  const int  ) const) static_cast<bool (TDF_Delta::*)(  const int  ) const>(&TDF_Delta::IsApplicable),
             R"#(Returns true if the Undo action of <me> is applicable at <aCurrentTime>.)#"  , py::arg("aCurrentTime")
          )
        .def("BeginTime",
             (int (TDF_Delta::*)() const) static_cast<int (TDF_Delta::*)() const>(&TDF_Delta::BeginTime),
             R"#(Returns the field <myBeginTime>.)#" 
          )
        .def("EndTime",
             (int (TDF_Delta::*)() const) static_cast<int (TDF_Delta::*)() const>(&TDF_Delta::EndTime),
             R"#(Returns the field <myEndTime>.)#" 
          )
        .def("SetName",
             (void (TDF_Delta::*)(  const TCollection_ExtendedString &  ) ) static_cast<void (TDF_Delta::*)(  const TCollection_ExtendedString &  ) >(&TDF_Delta::SetName),
             R"#(Associates a name <theName> with this delta)#"  , py::arg("theName")
          )
        .def("Name",
             (TCollection_ExtendedString (TDF_Delta::*)() const) static_cast<TCollection_ExtendedString (TDF_Delta::*)() const>(&TDF_Delta::Name),
             R"#(Returns a name associated with this delta.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDF_Delta::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDF_Delta::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("AttributeDeltas",
             ( const NCollection_List<handle<TDF_AttributeDelta>> & (TDF_Delta::*)() const) static_cast< const NCollection_List<handle<TDF_AttributeDelta>> & (TDF_Delta::*)() const>(&TDF_Delta::AttributeDeltas),
             R"#(Returns the field <myAttDeltaList>.)#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDF_Delta::*)() const) static_cast< const handle<Standard_Type> & (TDF_Delta::*)() const>(&TDF_Delta::DynamicType),
             R"#()#"
             
         )
       .def("AttributeDeltas",
             ( const NCollection_List<handle<TDF_AttributeDelta>> & (TDF_Delta::*)() const) static_cast< const NCollection_List<handle<TDF_AttributeDelta>> & (TDF_Delta::*)() const>(&TDF_Delta::AttributeDeltas),
             R"#(Returns the field <myAttDeltaList>.)#"
             
         )
;

    // Class TDF_DerivedAttribute from ./opencascade/TDF_DerivedAttribute.hxx
    klass = m.attr("TDF_DerivedAttribute");

    // default constructor
    register_default_constructor<TDF_DerivedAttribute , shared_ptr<TDF_DerivedAttribute>>(m,"TDF_DerivedAttribute");

    // nested enums

    static_cast<py::class_<TDF_DerivedAttribute , shared_ptr<TDF_DerivedAttribute>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Attribute_s",
                    (handle<TDF_Attribute> (*)(  const char *  ) ) static_cast<handle<TDF_Attribute> (*)(  const char *  ) >(&TDF_DerivedAttribute::Attribute),
                    R"#(Returns the derived registered attribute by its type.)#"  , py::arg("theType")
          )
        .def_static("TypeName_s",
                    ( const TCollection_AsciiString & (*)(  const char *  ) ) static_cast< const TCollection_AsciiString & (*)(  const char *  ) >(&TDF_DerivedAttribute::TypeName),
                    R"#(Returns the type name of the registered attribute by its type.)#"  , py::arg("theType")
          )
        .def_static("Attributes_s",
                    (void (*)( NCollection_List<handle<TDF_Attribute>> &  ) ) static_cast<void (*)( NCollection_List<handle<TDF_Attribute>> &  ) >(&TDF_DerivedAttribute::Attributes),
                    R"#(Returns all the derived registered attributes list.)#"  , py::arg("theList")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class TDF_IDFilter from ./opencascade/TDF_IDFilter.hxx
    klass = m.attr("TDF_IDFilter");


    // nested enums

    static_cast<py::class_<TDF_IDFilter , shared_ptr<TDF_IDFilter>  >>(klass)
    // constructors
        .def(py::init<  const bool >()  , py::arg("ignoreMode")=static_cast< const bool>(true) )
    // custom constructors
    // methods
        .def("IgnoreAll",
             (void (TDF_IDFilter::*)(  const bool  ) ) static_cast<void (TDF_IDFilter::*)(  const bool  ) >(&TDF_IDFilter::IgnoreAll),
             R"#(The list of ID is cleared and the filter mode is set to ignore mode if <keep> is true; false otherwise.)#"  , py::arg("ignore")
          )
        .def("IgnoreAll",
             (bool (TDF_IDFilter::*)() const) static_cast<bool (TDF_IDFilter::*)() const>(&TDF_IDFilter::IgnoreAll),
             R"#(Returns true is the mode is set to "ignore all but...".)#" 
          )
        .def("Keep",
             (void (TDF_IDFilter::*)(  const Standard_GUID &  ) ) static_cast<void (TDF_IDFilter::*)(  const Standard_GUID &  ) >(&TDF_IDFilter::Keep),
             R"#(An attribute with <anID> as ID is to be kept and the filter will answer true to the question IsKept(<anID>).)#"  , py::arg("anID")
          )
        .def("Keep",
             (void (TDF_IDFilter::*)(  const NCollection_List<Standard_GUID> &  ) ) static_cast<void (TDF_IDFilter::*)(  const NCollection_List<Standard_GUID> &  ) >(&TDF_IDFilter::Keep),
             R"#(Attributes with ID owned by <anIDList> are to be kept and the filter will answer true to the question IsKept(<anID>) with ID from <anIDList>.)#"  , py::arg("anIDList")
          )
        .def("Ignore",
             (void (TDF_IDFilter::*)(  const Standard_GUID &  ) ) static_cast<void (TDF_IDFilter::*)(  const Standard_GUID &  ) >(&TDF_IDFilter::Ignore),
             R"#(An attribute with <anID> as ID is to be ignored and the filter will answer false to the question IsKept(<anID>).)#"  , py::arg("anID")
          )
        .def("Ignore",
             (void (TDF_IDFilter::*)(  const NCollection_List<Standard_GUID> &  ) ) static_cast<void (TDF_IDFilter::*)(  const NCollection_List<Standard_GUID> &  ) >(&TDF_IDFilter::Ignore),
             R"#(Attributes with ID owned by <anIDList> are to be ignored and the filter will answer false to the question IsKept(<anID>) with ID from <anIDList>.)#"  , py::arg("anIDList")
          )
        .def("IsKept",
             (bool (TDF_IDFilter::*)(  const Standard_GUID &  ) const) static_cast<bool (TDF_IDFilter::*)(  const Standard_GUID &  ) const>(&TDF_IDFilter::IsKept),
             R"#(Returns true if the ID is to be kept.)#"  , py::arg("anID")
          )
        .def("IsKept",
             (bool (TDF_IDFilter::*)(  const handle<TDF_Attribute> &  ) const) static_cast<bool (TDF_IDFilter::*)(  const handle<TDF_Attribute> &  ) const>(&TDF_IDFilter::IsKept),
             R"#(Returns true if the attribute is to be kept.)#"  , py::arg("anAtt")
          )
        .def("IsIgnored",
             (bool (TDF_IDFilter::*)(  const Standard_GUID &  ) const) static_cast<bool (TDF_IDFilter::*)(  const Standard_GUID &  ) const>(&TDF_IDFilter::IsIgnored),
             R"#(Returns true if the ID is to be ignored.)#"  , py::arg("anID")
          )
        .def("IsIgnored",
             (bool (TDF_IDFilter::*)(  const handle<TDF_Attribute> &  ) const) static_cast<bool (TDF_IDFilter::*)(  const handle<TDF_Attribute> &  ) const>(&TDF_IDFilter::IsIgnored),
             R"#(Returns true if the attribute is to be ignored.)#"  , py::arg("anAtt")
          )
        .def("IDList",
             (void (TDF_IDFilter::*)( NCollection_List<Standard_GUID> &  ) const) static_cast<void (TDF_IDFilter::*)( NCollection_List<Standard_GUID> &  ) const>(&TDF_IDFilter::IDList),
             R"#(Copies the list of ID to be kept or ignored in <anIDList>. <anIDList> is cleared before use.)#"  , py::arg("anIDList")
          )
        .def("Copy",
             (void (TDF_IDFilter::*)(  const TDF_IDFilter &  ) ) static_cast<void (TDF_IDFilter::*)(  const TDF_IDFilter &  ) >(&TDF_IDFilter::Copy),
             R"#(Copies into <me> the contents of <fromFilter>. <me> is cleared before copy.)#"  , py::arg("fromFilter")
          )
        .def("Dump",
             (void (TDF_IDFilter::*)( Standard_OStream &  ) const) static_cast<void (TDF_IDFilter::*)( Standard_OStream &  ) const>(&TDF_IDFilter::Dump),
             R"#(Writes the contents of <me> to <OS>.)#"  , py::arg("anOS")
          )
        .def("Assign",
             (void (TDF_IDFilter::*)(  const TDF_IDFilter &  ) ) static_cast<void (TDF_IDFilter::*)(  const TDF_IDFilter &  ) >(&TDF_IDFilter::Assign),
             R"#(Assignment)#"  , py::arg("theFilter")
          )
        .def("IgnoreAll",
             (bool (TDF_IDFilter::*)() const) static_cast<bool (TDF_IDFilter::*)() const>(&TDF_IDFilter::IgnoreAll),
             R"#(Returns true is the mode is set to "ignore all but...".)#" 
          )
        .def("IsKept",
             (bool (TDF_IDFilter::*)(  const Standard_GUID &  ) const) static_cast<bool (TDF_IDFilter::*)(  const Standard_GUID &  ) const>(&TDF_IDFilter::IsKept),
             R"#(Returns true if the ID is to be kept.)#"  , py::arg("anID")
          )
        .def("IsKept",
             (bool (TDF_IDFilter::*)(  const handle<TDF_Attribute> &  ) const) static_cast<bool (TDF_IDFilter::*)(  const handle<TDF_Attribute> &  ) const>(&TDF_IDFilter::IsKept),
             R"#(Returns true if the attribute is to be kept.)#"  , py::arg("anAtt")
          )
        .def("IsIgnored",
             (bool (TDF_IDFilter::*)(  const Standard_GUID &  ) const) static_cast<bool (TDF_IDFilter::*)(  const Standard_GUID &  ) const>(&TDF_IDFilter::IsIgnored),
             R"#(Returns true if the ID is to be ignored.)#"  , py::arg("anID")
          )
        .def("IsIgnored",
             (bool (TDF_IDFilter::*)(  const handle<TDF_Attribute> &  ) const) static_cast<bool (TDF_IDFilter::*)(  const handle<TDF_Attribute> &  ) const>(&TDF_IDFilter::IsIgnored),
             R"#(Returns true if the attribute is to be ignored.)#"  , py::arg("anAtt")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class TDF_Label from ./opencascade/TDF_Label.hxx
    klass = m.attr("TDF_Label");


    // nested enums

    static_cast<py::class_<TDF_Label , shared_ptr<TDF_Label>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Nullify",
             (void (TDF_Label::*)() ) static_cast<void (TDF_Label::*)() >(&TDF_Label::Nullify),
             R"#(Nullifies the label.)#" 
          )
        .def("Data",
             (handle<TDF_Data> (TDF_Label::*)() const) static_cast<handle<TDF_Data> (TDF_Label::*)() const>(&TDF_Label::Data),
             R"#(Returns the Data owning <me>.)#" 
          )
        .def("Tag",
             (int (TDF_Label::*)() const) static_cast<int (TDF_Label::*)() const>(&TDF_Label::Tag),
             R"#(Returns the tag of the label. This is the integer assigned randomly to a label in a data framework. This integer is used to identify this label in an entry.)#" 
          )
        .def("Father",
             ( const TDF_Label (TDF_Label::*)() const) static_cast< const TDF_Label (TDF_Label::*)() const>(&TDF_Label::Father),
             R"#(Returns the label father. This label may be null if the label is root.)#" 
          )
        .def("IsNull",
             (bool (TDF_Label::*)() const) static_cast<bool (TDF_Label::*)() const>(&TDF_Label::IsNull),
             R"#(Returns True if the <aLabel> is null, i.e. it has not been included in the data framework.)#" 
          )
        .def("Imported",
             (void (TDF_Label::*)(  const bool  ) const) static_cast<void (TDF_Label::*)(  const bool  ) const>(&TDF_Label::Imported),
             R"#(Sets or unsets <me> and all its descendants as imported label, according to <aStatus>.)#"  , py::arg("aStatus")
          )
        .def("IsImported",
             (bool (TDF_Label::*)() const) static_cast<bool (TDF_Label::*)() const>(&TDF_Label::IsImported),
             R"#(Returns True if the <aLabel> is imported.)#" 
          )
        .def("IsEqual",
             (bool (TDF_Label::*)(  const TDF_Label &  ) const) static_cast<bool (TDF_Label::*)(  const TDF_Label &  ) const>(&TDF_Label::IsEqual),
             R"#(Returns True if the <aLabel> is equal to me (same LabelNode*).)#"  , py::arg("aLabel")
          )
        .def("IsDifferent",
             (bool (TDF_Label::*)(  const TDF_Label &  ) const) static_cast<bool (TDF_Label::*)(  const TDF_Label &  ) const>(&TDF_Label::IsDifferent),
             R"#()#"  , py::arg("aLabel")
          )
        .def("IsRoot",
             (bool (TDF_Label::*)() const) static_cast<bool (TDF_Label::*)() const>(&TDF_Label::IsRoot),
             R"#()#" 
          )
        .def("IsAttribute",
             (bool (TDF_Label::*)(  const Standard_GUID &  ) const) static_cast<bool (TDF_Label::*)(  const Standard_GUID &  ) const>(&TDF_Label::IsAttribute),
             R"#(Returns true if <me> owns an attribute with <anID> as ID.)#"  , py::arg("anID")
          )
        .def("AddAttribute",
             (void (TDF_Label::*)(  const handle<TDF_Attribute> & ,   const bool  ) const) static_cast<void (TDF_Label::*)(  const handle<TDF_Attribute> & ,   const bool  ) const>(&TDF_Label::AddAttribute),
             R"#(Adds an Attribute to the current label. Raises if there is already one.)#"  , py::arg("anAttribute"),  py::arg("append")=static_cast< const bool>(true)
          )
        .def("ForgetAttribute",
             (void (TDF_Label::*)(  const handle<TDF_Attribute> &  ) const) static_cast<void (TDF_Label::*)(  const handle<TDF_Attribute> &  ) const>(&TDF_Label::ForgetAttribute),
             R"#(Forgets an Attribute from the current label, setting its forgotten status true and its valid status false. Raises if the attribute is not in the structure.)#"  , py::arg("anAttribute")
          )
        .def("ForgetAttribute",
             (bool (TDF_Label::*)(  const Standard_GUID &  ) const) static_cast<bool (TDF_Label::*)(  const Standard_GUID &  ) const>(&TDF_Label::ForgetAttribute),
             R"#(Forgets the Attribute of GUID <aguid> from the current label. If the attribute doesn't exist returns False. Otherwise returns True.)#"  , py::arg("aguid")
          )
        .def("ForgetAllAttributes",
             (void (TDF_Label::*)(  const bool  ) const) static_cast<void (TDF_Label::*)(  const bool  ) const>(&TDF_Label::ForgetAllAttributes),
             R"#(Forgets all the attributes. Does it on also on the sub-labels if <clearChildren> is set to true. Of course, this method is compatible with Transaction & Delta mechanisms.)#"  , py::arg("clearChildren")=static_cast< const bool>(true)
          )
        .def("ResumeAttribute",
             (void (TDF_Label::*)(  const handle<TDF_Attribute> &  ) const) static_cast<void (TDF_Label::*)(  const handle<TDF_Attribute> &  ) const>(&TDF_Label::ResumeAttribute),
             R"#(Undo Forget action, setting its forgotten status false and its valid status true. Raises if the attribute is not in the structure.)#"  , py::arg("anAttribute")
          )
        .def("MayBeModified",
             (bool (TDF_Label::*)() const) static_cast<bool (TDF_Label::*)() const>(&TDF_Label::MayBeModified),
             R"#(Returns true if <me> or a DESCENDANT of <me> owns attributes not yet available in transaction 0. It means at least one of their attributes is new, modified or deleted.)#" 
          )
        .def("AttributesModified",
             (bool (TDF_Label::*)() const) static_cast<bool (TDF_Label::*)() const>(&TDF_Label::AttributesModified),
             R"#(Returns true if <me> owns attributes not yet available in transaction 0. It means at least one attribute is new, modified or deleted.)#" 
          )
        .def("HasAttribute",
             (bool (TDF_Label::*)() const) static_cast<bool (TDF_Label::*)() const>(&TDF_Label::HasAttribute),
             R"#(Returns true if this label has at least one attribute.)#" 
          )
        .def("NbAttributes",
             (int (TDF_Label::*)() const) static_cast<int (TDF_Label::*)() const>(&TDF_Label::NbAttributes),
             R"#(Returns the number of attributes.)#" 
          )
        .def("Depth",
             (int (TDF_Label::*)() const) static_cast<int (TDF_Label::*)() const>(&TDF_Label::Depth),
             R"#(Returns the depth of the label in the data framework. This corresponds to the number of fathers which this label has, and is used in determining whether a label is root, null or equivalent to another label. Exceptions: Standard_NullObject if this label is null. This is because a null object can have no depth.)#" 
          )
        .def("IsDescendant",
             (bool (TDF_Label::*)(  const TDF_Label &  ) const) static_cast<bool (TDF_Label::*)(  const TDF_Label &  ) const>(&TDF_Label::IsDescendant),
             R"#(Returns True if <me> is a descendant of <aLabel>. Attention: every label is its own descendant.)#"  , py::arg("aLabel")
          )
        .def("Root",
             ( const TDF_Label (TDF_Label::*)() const) static_cast< const TDF_Label (TDF_Label::*)() const>(&TDF_Label::Root),
             R"#(Returns the root label Root of the data structure. This has a depth of 0. Exceptions: Standard_NullObject if this label is null. This is because a null object can have no depth.)#" 
          )
        .def("HasChild",
             (bool (TDF_Label::*)() const) static_cast<bool (TDF_Label::*)() const>(&TDF_Label::HasChild),
             R"#(Returns true if this label has at least one child.)#" 
          )
        .def("NbChildren",
             (int (TDF_Label::*)() const) static_cast<int (TDF_Label::*)() const>(&TDF_Label::NbChildren),
             R"#(Returns the number of children.)#" 
          )
        .def("FindChild",
             (TDF_Label (TDF_Label::*)(  const int ,   const bool  ) const) static_cast<TDF_Label (TDF_Label::*)(  const int ,   const bool  ) const>(&TDF_Label::FindChild),
             R"#(Finds a child label having <aTag> as tag. Creates The tag aTag identifies the label which will be the parent. If create is true and no child label is found, a new one is created. Example: //creating a label with tag 10 at Root TDF_Label lab1 = aDF->Root().FindChild(10); //creating labels 7 and 2 on label 10 TDF_Label lab2 = lab1.FindChild(7); TDF_Label lab3 = lab1.FindChild(2);)#"  , py::arg("aTag"),  py::arg("create")=static_cast< const bool>(true)
          )
        .def("NewChild",
             (TDF_Label (TDF_Label::*)() const) static_cast<TDF_Label (TDF_Label::*)() const>(&TDF_Label::NewChild),
             R"#(Create a new child label of me using automatic delivery tags provided by TagSource.)#" 
          )
        .def("Transaction",
             (int (TDF_Label::*)() const) static_cast<int (TDF_Label::*)() const>(&TDF_Label::Transaction),
             R"#(Returns the current transaction index.)#" 
          )
        .def("HasLowerNode",
             (bool (TDF_Label::*)(  const TDF_Label &  ) const) static_cast<bool (TDF_Label::*)(  const TDF_Label &  ) const>(&TDF_Label::HasLowerNode),
             R"#(Returns true if node address of <me> is lower than <otherLabel> one. Used to quickly sort labels (not on entry criterion).)#"  , py::arg("otherLabel")
          )
        .def("HasGreaterNode",
             (bool (TDF_Label::*)(  const TDF_Label &  ) const) static_cast<bool (TDF_Label::*)(  const TDF_Label &  ) const>(&TDF_Label::HasGreaterNode),
             R"#(Returns true if node address of <me> is greater than <otherLabel> one. Used to quickly sort labels (not on entry criterion).)#"  , py::arg("otherLabel")
          )
        .def("Dump",
             (Standard_OStream & (TDF_Label::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDF_Label::*)( Standard_OStream &  ) const>(&TDF_Label::Dump),
             R"#(Dumps the minimum information about <me> on <aStream>.)#"  , py::arg("anOS")
          )
        .def("ExtendedDump",
             (void (TDF_Label::*)( Standard_OStream & ,   const TDF_IDFilter & ,  NCollection_IndexedMap<handle<TDF_Attribute>> &  ) const) static_cast<void (TDF_Label::*)( Standard_OStream & ,   const TDF_IDFilter & ,  NCollection_IndexedMap<handle<TDF_Attribute>> &  ) const>(&TDF_Label::ExtendedDump),
             R"#(Dumps the label on <aStream> and its attributes rank in <aMap> if their IDs are kept by <IDFilter>.)#"  , py::arg("anOS"),  py::arg("aFilter"),  py::arg("aMap")
          )
        .def("EntryDump",
             (void (TDF_Label::*)( Standard_OStream &  ) const) static_cast<void (TDF_Label::*)( Standard_OStream &  ) const>(&TDF_Label::EntryDump),
             R"#(Dumps the label entry.)#"  , py::arg("anOS")
          )
        .def("Nullify",
             (void (TDF_Label::*)() ) static_cast<void (TDF_Label::*)() >(&TDF_Label::Nullify),
             R"#(Nullifies the label.)#" 
          )
        .def("IsRoot",
             (bool (TDF_Label::*)() const) static_cast<bool (TDF_Label::*)() const>(&TDF_Label::IsRoot),
             R"#()#" 
          )
        .def("IsNull",
             (bool (TDF_Label::*)() const) static_cast<bool (TDF_Label::*)() const>(&TDF_Label::IsNull),
             R"#(Returns True if the <aLabel> is null, i.e. it has not been included in the data framework.)#" 
          )
        .def("IsImported",
             (bool (TDF_Label::*)() const) static_cast<bool (TDF_Label::*)() const>(&TDF_Label::IsImported),
             R"#(Returns True if the <aLabel> is imported.)#" 
          )
        .def("IsEqual",
             (bool (TDF_Label::*)(  const TDF_Label &  ) const) static_cast<bool (TDF_Label::*)(  const TDF_Label &  ) const>(&TDF_Label::IsEqual),
             R"#(Returns True if the <aLabel> is equal to me (same LabelNode*).)#"  , py::arg("aLabel")
          )
        .def("IsDifferent",
             (bool (TDF_Label::*)(  const TDF_Label &  ) const) static_cast<bool (TDF_Label::*)(  const TDF_Label &  ) const>(&TDF_Label::IsDifferent),
             R"#()#"  , py::arg("aLabel")
          )
        .def("Tag",
             (int (TDF_Label::*)() const) static_cast<int (TDF_Label::*)() const>(&TDF_Label::Tag),
             R"#(Returns the tag of the label. This is the integer assigned randomly to a label in a data framework. This integer is used to identify this label in an entry.)#" 
          )
        .def("Father",
             ( const TDF_Label (TDF_Label::*)() const) static_cast< const TDF_Label (TDF_Label::*)() const>(&TDF_Label::Father),
             R"#(Returns the label father. This label may be null if the label is root.)#" 
          )
        .def("HasChild",
             (bool (TDF_Label::*)() const) static_cast<bool (TDF_Label::*)() const>(&TDF_Label::HasChild),
             R"#(Returns true if this label has at least one child.)#" 
          )
        .def("AttributesModified",
             (bool (TDF_Label::*)() const) static_cast<bool (TDF_Label::*)() const>(&TDF_Label::AttributesModified),
             R"#(Returns true if <me> owns attributes not yet available in transaction 0. It means at least one attribute is new, modified or deleted.)#" 
          )
        .def("MayBeModified",
             (bool (TDF_Label::*)() const) static_cast<bool (TDF_Label::*)() const>(&TDF_Label::MayBeModified),
             R"#(Returns true if <me> or a DESCENDANT of <me> owns attributes not yet available in transaction 0. It means at least one of their attributes is new, modified or deleted.)#" 
          )
        .def("Data",
             (handle<TDF_Data> (TDF_Label::*)() const) static_cast<handle<TDF_Data> (TDF_Label::*)() const>(&TDF_Label::Data),
             R"#(Returns the Data owning <me>.)#" 
          )
        .def("NewChild",
             (TDF_Label (TDF_Label::*)() const) static_cast<TDF_Label (TDF_Label::*)() const>(&TDF_Label::NewChild),
             R"#(Create a new child label of me using automatic delivery tags provided by TagSource.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
        .def("FindAttribute",
             []( TDF_Label & self , const Standard_GUID& anID, TDF_Attribute& anAttribute){ Handle(TDF_Attribute) dummy_attr; auto rv = self.FindAttribute(anID, dummy_attr); anAttribute.Restore(dummy_attr); return rv;},
             R"#(Finds an attributes according to an ID.)#"
, py::arg("GUID"), py::arg("Attribute")          )
        .def("__bool__",
             []( const TDF_Label & self){ return !self.IsNull();},
             R"#(Check if label is not Null)#"
          )
    // properties
    // methods returning by ref wrapped as properties
;

    // Class TDF_RelocationTable from ./opencascade/TDF_RelocationTable.hxx
    klass = m.attr("TDF_RelocationTable");


    // nested enums

    static_cast<py::class_<TDF_RelocationTable ,opencascade::handle<TDF_RelocationTable>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const bool >()  , py::arg("selfRelocate")=static_cast< const bool>(false) )
    // custom constructors
    // methods
        .def("SelfRelocate",
             (void (TDF_RelocationTable::*)(  const bool  ) ) static_cast<void (TDF_RelocationTable::*)(  const bool  ) >(&TDF_RelocationTable::SelfRelocate),
             R"#(Sets <mySelfRelocate> to <selfRelocate>.)#"  , py::arg("selfRelocate")
          )
        .def("SelfRelocate",
             (bool (TDF_RelocationTable::*)() const) static_cast<bool (TDF_RelocationTable::*)() const>(&TDF_RelocationTable::SelfRelocate),
             R"#(Returns <mySelfRelocate>.)#" 
          )
        .def("AfterRelocate",
             (void (TDF_RelocationTable::*)(  const bool  ) ) static_cast<void (TDF_RelocationTable::*)(  const bool  ) >(&TDF_RelocationTable::AfterRelocate),
             R"#()#"  , py::arg("afterRelocate")
          )
        .def("AfterRelocate",
             (bool (TDF_RelocationTable::*)() const) static_cast<bool (TDF_RelocationTable::*)() const>(&TDF_RelocationTable::AfterRelocate),
             R"#(Returns <myAfterRelocate>.)#" 
          )
        .def("SetRelocation",
             (void (TDF_RelocationTable::*)(  const TDF_Label & ,   const TDF_Label &  ) ) static_cast<void (TDF_RelocationTable::*)(  const TDF_Label & ,   const TDF_Label &  ) >(&TDF_RelocationTable::SetRelocation),
             R"#(Sets the relocation value of <aSourceLabel> to <aTargetLabel>.)#"  , py::arg("aSourceLabel"),  py::arg("aTargetLabel")
          )
        .def("HasRelocation",
             (bool (TDF_RelocationTable::*)(  const TDF_Label & ,  TDF_Label &  ) const) static_cast<bool (TDF_RelocationTable::*)(  const TDF_Label & ,  TDF_Label &  ) const>(&TDF_RelocationTable::HasRelocation),
             R"#(Finds the relocation value of <aSourceLabel> and returns it into <aTargetLabel>.)#"  , py::arg("aSourceLabel"),  py::arg("aTargetLabel")
          )
        .def("SetRelocation",
             (void (TDF_RelocationTable::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_Attribute> &  ) ) static_cast<void (TDF_RelocationTable::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_Attribute> &  ) >(&TDF_RelocationTable::SetRelocation),
             R"#(Sets the relocation value of <aSourceAttribute> to <aTargetAttribute>.)#"  , py::arg("aSourceAttribute"),  py::arg("aTargetAttribute")
          )
        .def("HasRelocation",
             (bool (TDF_RelocationTable::*)(  const handle<TDF_Attribute> & ,  handle<TDF_Attribute> &  ) const) static_cast<bool (TDF_RelocationTable::*)(  const handle<TDF_Attribute> & ,  handle<TDF_Attribute> &  ) const>(&TDF_RelocationTable::HasRelocation),
             R"#(Finds the relocation value of <aSourceAttribute> and returns it into <aTargetAttribute>.)#"  , py::arg("aSourceAttribute"),  py::arg("aTargetAttribute")
          )
        .def("SetTransientRelocation",
             (void (TDF_RelocationTable::*)(  const handle<Standard_Transient> & ,   const handle<Standard_Transient> &  ) ) static_cast<void (TDF_RelocationTable::*)(  const handle<Standard_Transient> & ,   const handle<Standard_Transient> &  ) >(&TDF_RelocationTable::SetTransientRelocation),
             R"#(Sets the relocation value of <aSourceTransient> to <aTargetTransient>.)#"  , py::arg("aSourceTransient"),  py::arg("aTargetTransient")
          )
        .def("HasTransientRelocation",
             (bool (TDF_RelocationTable::*)(  const handle<Standard_Transient> & ,  handle<Standard_Transient> &  ) const) static_cast<bool (TDF_RelocationTable::*)(  const handle<Standard_Transient> & ,  handle<Standard_Transient> &  ) const>(&TDF_RelocationTable::HasTransientRelocation),
             R"#(Finds the relocation value of <aSourceTransient> and returns it into <aTargetTransient>.)#"  , py::arg("aSourceTransient"),  py::arg("aTargetTransient")
          )
        .def("Clear",
             (void (TDF_RelocationTable::*)() ) static_cast<void (TDF_RelocationTable::*)() >(&TDF_RelocationTable::Clear),
             R"#(Clears the relocation dictionary, but lets the self relocation flag to its current value.)#" 
          )
        .def("TargetLabelMap",
             (void (TDF_RelocationTable::*)( NCollection_Map<TDF_Label> &  ) const) static_cast<void (TDF_RelocationTable::*)( NCollection_Map<TDF_Label> &  ) const>(&TDF_RelocationTable::TargetLabelMap),
             R"#(Fills <aLabelMap> with target relocation labels. <aLabelMap> is not cleared before use.)#"  , py::arg("aLabelMap")
          )
        .def("TargetAttributeMap",
             (void (TDF_RelocationTable::*)( NCollection_Map<handle<TDF_Attribute>> &  ) const) static_cast<void (TDF_RelocationTable::*)( NCollection_Map<handle<TDF_Attribute>> &  ) const>(&TDF_RelocationTable::TargetAttributeMap),
             R"#(Fills <anAttributeMap> with target relocation attributes. <anAttributeMap> is not cleared before use.)#"  , py::arg("anAttributeMap")
          )
        .def("Dump",
             (Standard_OStream & (TDF_RelocationTable::*)(  const bool ,   const bool ,   const bool ,  Standard_OStream &  ) const) static_cast<Standard_OStream & (TDF_RelocationTable::*)(  const bool ,   const bool ,   const bool ,  Standard_OStream &  ) const>(&TDF_RelocationTable::Dump),
             R"#(Dumps the relocation table.)#"  , py::arg("dumpLabels"),  py::arg("dumpAttributes"),  py::arg("dumpTransients"),  py::arg("anOS")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDF_RelocationTable::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDF_RelocationTable::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("LabelTable",
             (NCollection_DataMap<TDF_Label, TDF_Label> & (TDF_RelocationTable::*)() ) static_cast<NCollection_DataMap<TDF_Label, TDF_Label> & (TDF_RelocationTable::*)() >(&TDF_RelocationTable::LabelTable),
             R"#(Returns <myLabelTable> to be used or updated.)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("AttributeTable",
             (NCollection_DataMap<handle<TDF_Attribute>, handle<TDF_Attribute>> & (TDF_RelocationTable::*)() ) static_cast<NCollection_DataMap<handle<TDF_Attribute>, handle<TDF_Attribute>> & (TDF_RelocationTable::*)() >(&TDF_RelocationTable::AttributeTable),
             R"#(Returns <myAttributeTable> to be used or updated.)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("TransientTable",
             (NCollection_IndexedDataMap<handle<Standard_Transient>, handle<Standard_Transient>> & (TDF_RelocationTable::*)() ) static_cast<NCollection_IndexedDataMap<handle<Standard_Transient>, handle<Standard_Transient>> & (TDF_RelocationTable::*)() >(&TDF_RelocationTable::TransientTable),
             R"#(Returns <myTransientTable> to be used or updated.)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDF_RelocationTable::*)() const) static_cast< const handle<Standard_Type> & (TDF_RelocationTable::*)() const>(&TDF_RelocationTable::DynamicType),
             R"#()#"
             
         )
;

    // Class TDF_Tool from ./opencascade/TDF_Tool.hxx
    klass = m.attr("TDF_Tool");

    // default constructor
    register_default_constructor<TDF_Tool , shared_ptr<TDF_Tool>>(m,"TDF_Tool");

    // nested enums

    static_cast<py::class_<TDF_Tool , shared_ptr<TDF_Tool>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("NbLabels_s",
                    (int (*)(  const TDF_Label &  ) ) static_cast<int (*)(  const TDF_Label &  ) >(&TDF_Tool::NbLabels),
                    R"#(Returns the number of labels of the tree, including <aLabel>. aLabel is also included in this figure. This information is useful in setting the size of an array.)#"  , py::arg("aLabel")
          )
        .def_static("NbAttributes_s",
                    (int (*)(  const TDF_Label &  ) ) static_cast<int (*)(  const TDF_Label &  ) >(&TDF_Tool::NbAttributes),
                    R"#(Returns the total number of attributes attached to the labels dependent on the label aLabel. The attributes of aLabel are also included in this figure. This information is useful in setting the size of an array.)#"  , py::arg("aLabel")
          )
        .def_static("NbAttributes_s",
                    (int (*)(  const TDF_Label & ,   const TDF_IDFilter &  ) ) static_cast<int (*)(  const TDF_Label & ,   const TDF_IDFilter &  ) >(&TDF_Tool::NbAttributes),
                    R"#(Returns the number of attributes of the tree, selected by a<Filter>, including those of <aLabel>.)#"  , py::arg("aLabel"),  py::arg("aFilter")
          )
        .def_static("IsSelfContained_s",
                    (bool (*)(  const TDF_Label &  ) ) static_cast<bool (*)(  const TDF_Label &  ) >(&TDF_Tool::IsSelfContained),
                    R"#(Returns true if <aLabel> and its descendants reference only attributes or labels attached to themselves.)#"  , py::arg("aLabel")
          )
        .def_static("IsSelfContained_s",
                    (bool (*)(  const TDF_Label & ,   const TDF_IDFilter &  ) ) static_cast<bool (*)(  const TDF_Label & ,   const TDF_IDFilter &  ) >(&TDF_Tool::IsSelfContained),
                    R"#(Returns true if <aLabel> and its descendants reference only attributes or labels attached to themselves and kept by <aFilter>.)#"  , py::arg("aLabel"),  py::arg("aFilter")
          )
        .def_static("OutReferers_s",
                    (void (*)(  const TDF_Label & ,  NCollection_Map<handle<TDF_Attribute>> &  ) ) static_cast<void (*)(  const TDF_Label & ,  NCollection_Map<handle<TDF_Attribute>> &  ) >(&TDF_Tool::OutReferers),
                    R"#(Returns in <theAtts> the attributes having out references.)#"  , py::arg("theLabel"),  py::arg("theAtts")
          )
        .def_static("OutReferers_s",
                    (void (*)(  const TDF_Label & ,   const TDF_IDFilter & ,   const TDF_IDFilter & ,  NCollection_Map<handle<TDF_Attribute>> &  ) ) static_cast<void (*)(  const TDF_Label & ,   const TDF_IDFilter & ,   const TDF_IDFilter & ,  NCollection_Map<handle<TDF_Attribute>> &  ) >(&TDF_Tool::OutReferers),
                    R"#(Returns in <atts> the attributes having out references and kept by <aFilterForReferers>. It considers only the references kept by <aFilterForReferences>. Caution: <atts> is not cleared before use!)#"  , py::arg("aLabel"),  py::arg("aFilterForReferers"),  py::arg("aFilterForReferences"),  py::arg("atts")
          )
        .def_static("OutReferences_s",
                    (void (*)(  const TDF_Label & ,  NCollection_Map<handle<TDF_Attribute>> &  ) ) static_cast<void (*)(  const TDF_Label & ,  NCollection_Map<handle<TDF_Attribute>> &  ) >(&TDF_Tool::OutReferences),
                    R"#(Returns in <atts> the referenced attributes. Caution: <atts> is not cleared before use!)#"  , py::arg("aLabel"),  py::arg("atts")
          )
        .def_static("OutReferences_s",
                    (void (*)(  const TDF_Label & ,   const TDF_IDFilter & ,   const TDF_IDFilter & ,  NCollection_Map<handle<TDF_Attribute>> &  ) ) static_cast<void (*)(  const TDF_Label & ,   const TDF_IDFilter & ,   const TDF_IDFilter & ,  NCollection_Map<handle<TDF_Attribute>> &  ) >(&TDF_Tool::OutReferences),
                    R"#(Returns in <atts> the referenced attributes and kept by <aFilterForReferences>. It considers only the referrers kept by <aFilterForReferers>. Caution: <atts> is not cleared before use!)#"  , py::arg("aLabel"),  py::arg("aFilterForReferers"),  py::arg("aFilterForReferences"),  py::arg("atts")
          )
        .def_static("RelocateLabel_s",
                    (void (*)(  const TDF_Label & ,   const TDF_Label & ,   const TDF_Label & ,  TDF_Label & ,   const bool  ) ) static_cast<void (*)(  const TDF_Label & ,   const TDF_Label & ,   const TDF_Label & ,  TDF_Label & ,   const bool  ) >(&TDF_Tool::RelocateLabel),
                    R"#(Returns the label having the same sub-entry as <aLabel> but located as descendant as <toRoot> instead of <fromRoot>.)#"  , py::arg("aSourceLabel"),  py::arg("fromRoot"),  py::arg("toRoot"),  py::arg("aTargetLabel"),  py::arg("create")=static_cast< const bool>(false)
          )
        .def_static("Entry_s",
                    (void (*)(  const TDF_Label & ,  TCollection_AsciiString &  ) ) static_cast<void (*)(  const TDF_Label & ,  TCollection_AsciiString &  ) >(&TDF_Tool::Entry),
                    R"#(Returns the entry for the label aLabel in the form of the ASCII character string anEntry containing the tag list for aLabel.)#"  , py::arg("aLabel"),  py::arg("anEntry")
          )
        .def_static("TagList_s",
                    (void (*)(  const TDF_Label & ,  NCollection_List<int> &  ) ) static_cast<void (*)(  const TDF_Label & ,  NCollection_List<int> &  ) >(&TDF_Tool::TagList),
                    R"#(Returns the entry of <aLabel> as list of integers in <aTagList>.)#"  , py::arg("aLabel"),  py::arg("aTagList")
          )
        .def_static("TagList_s",
                    (void (*)(  const TCollection_AsciiString & ,  NCollection_List<int> &  ) ) static_cast<void (*)(  const TCollection_AsciiString & ,  NCollection_List<int> &  ) >(&TDF_Tool::TagList),
                    R"#(Returns the entry expressed by <anEntry> as list of integers in <aTagList>.)#"  , py::arg("anEntry"),  py::arg("aTagList")
          )
        .def_static("Label_s",
                    (void (*)(  const handle<TDF_Data> & ,   const TCollection_AsciiString & ,  TDF_Label & ,   const bool  ) ) static_cast<void (*)(  const handle<TDF_Data> & ,   const TCollection_AsciiString & ,  TDF_Label & ,   const bool  ) >(&TDF_Tool::Label),
                    R"#(Returns the label expressed by <anEntry>; creates the label if it does not exist and if <create> is true.)#"  , py::arg("aDF"),  py::arg("anEntry"),  py::arg("aLabel"),  py::arg("create")=static_cast< const bool>(false)
          )
        .def_static("Label_s",
                    (void (*)(  const handle<TDF_Data> & ,   const char * const  ,  TDF_Label & ,   const bool  ) ) static_cast<void (*)(  const handle<TDF_Data> & ,   const char * const  ,  TDF_Label & ,   const bool  ) >(&TDF_Tool::Label),
                    R"#(Returns the label expressed by <anEntry>; creates the label if it does not exist and if <create> is true.)#"  , py::arg("aDF"),  py::arg("anEntry"),  py::arg("aLabel"),  py::arg("create")=static_cast< const bool>(false)
          )
        .def_static("Label_s",
                    (void (*)(  const handle<TDF_Data> & ,   const NCollection_List<int> & ,  TDF_Label & ,   const bool  ) ) static_cast<void (*)(  const handle<TDF_Data> & ,   const NCollection_List<int> & ,  TDF_Label & ,   const bool  ) >(&TDF_Tool::Label),
                    R"#(Returns the label expressed by <anEntry>; creates the label if it does not exist and if <create> is true.)#"  , py::arg("aDF"),  py::arg("aTagList"),  py::arg("aLabel"),  py::arg("create")=static_cast< const bool>(false)
          )
        .def_static("CountLabels_s",
                    (void (*)( NCollection_List<TDF_Label> & ,  NCollection_DataMap<TDF_Label, int> &  ) ) static_cast<void (*)( NCollection_List<TDF_Label> & ,  NCollection_DataMap<TDF_Label, int> &  ) >(&TDF_Tool::CountLabels),
                    R"#(Adds the labels of <aLabelList> to <aLabelMap> if they are unbound, or increases their reference counters. At the end of the process, <aLabelList> contains only the ADDED labels.)#"  , py::arg("aLabelList"),  py::arg("aLabelMap")
          )
        .def_static("DeductLabels_s",
                    (void (*)( NCollection_List<TDF_Label> & ,  NCollection_DataMap<TDF_Label, int> &  ) ) static_cast<void (*)( NCollection_List<TDF_Label> & ,  NCollection_DataMap<TDF_Label, int> &  ) >(&TDF_Tool::DeductLabels),
                    R"#(Decreases the reference counters of the labels of <aLabelList> to <aLabelMap>, and removes labels with null counter. At the end of the process, <aLabelList> contains only the SUPPRESSED labels.)#"  , py::arg("aLabelList"),  py::arg("aLabelMap")
          )
        .def_static("DeepDump_s",
                    (void (*)( Standard_OStream & ,   const handle<TDF_Data> &  ) ) static_cast<void (*)( Standard_OStream & ,   const handle<TDF_Data> &  ) >(&TDF_Tool::DeepDump),
                    R"#(Dumps <aDF> and its labels and their attributes.)#"  , py::arg("anOS"),  py::arg("aDF")
          )
        .def_static("ExtendedDeepDump_s",
                    (void (*)( Standard_OStream & ,   const handle<TDF_Data> & ,   const TDF_IDFilter &  ) ) static_cast<void (*)( Standard_OStream & ,   const handle<TDF_Data> & ,   const TDF_IDFilter &  ) >(&TDF_Tool::ExtendedDeepDump),
                    R"#(Dumps <aDF> and its labels and their attributes, if their IDs are kept by <aFilter>. Dumps also the attributes content.)#"  , py::arg("anOS"),  py::arg("aDF"),  py::arg("aFilter")
          )
        .def_static("DeepDump_s",
                    (void (*)( Standard_OStream & ,   const TDF_Label &  ) ) static_cast<void (*)( Standard_OStream & ,   const TDF_Label &  ) >(&TDF_Tool::DeepDump),
                    R"#(Dumps <aLabel>, its children and their attributes.)#"  , py::arg("anOS"),  py::arg("aLabel")
          )
        .def_static("ExtendedDeepDump_s",
                    (void (*)( Standard_OStream & ,   const TDF_Label & ,   const TDF_IDFilter &  ) ) static_cast<void (*)( Standard_OStream & ,   const TDF_Label & ,   const TDF_IDFilter &  ) >(&TDF_Tool::ExtendedDeepDump),
                    R"#(Dumps <aLabel>, its children and their attributes, if their IDs are kept by <aFilter>. Dumps also the attributes content.)#"  , py::arg("anOS"),  py::arg("aLabel"),  py::arg("aFilter")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class TDF_Transaction from ./opencascade/TDF_Transaction.hxx
    klass = m.attr("TDF_Transaction");


    // nested enums

    static_cast<py::class_<TDF_Transaction , shared_ptr<TDF_Transaction>  >>(klass)
    // constructors
        .def(py::init<  const TCollection_AsciiString & >()  , py::arg("aName")=static_cast< const TCollection_AsciiString &>("") )
        .def(py::init<  const handle<TDF_Data> &, const TCollection_AsciiString & >()  , py::arg("aDF"),  py::arg("aName")=static_cast< const TCollection_AsciiString &>("") )
    // custom constructors
    // methods
        .def("Initialize",
             (void (TDF_Transaction::*)(  const handle<TDF_Data> &  ) ) static_cast<void (TDF_Transaction::*)(  const handle<TDF_Data> &  ) >(&TDF_Transaction::Initialize),
             R"#(Aborts all the transactions on <myDF> and sets <aDF> to build a transaction context on <aDF>, ready to be opened.)#"  , py::arg("aDF")
          )
        .def("Open",
             (int (TDF_Transaction::*)() ) static_cast<int (TDF_Transaction::*)() >(&TDF_Transaction::Open),
             R"#(If not yet done, opens a new transaction on <myDF>. Returns the index of the just opened transaction.)#" 
          )
        .def("Commit",
             (handle<TDF_Delta> (TDF_Transaction::*)(  const bool  ) ) static_cast<handle<TDF_Delta> (TDF_Transaction::*)(  const bool  ) >(&TDF_Transaction::Commit),
             R"#(Commits the transactions until AND including the current opened one.)#"  , py::arg("withDelta")=static_cast< const bool>(false)
          )
        .def("Abort",
             (void (TDF_Transaction::*)() ) static_cast<void (TDF_Transaction::*)() >(&TDF_Transaction::Abort),
             R"#(Aborts the transactions until AND including the current opened one.)#" 
          )
        .def("Data",
             (handle<TDF_Data> (TDF_Transaction::*)() const) static_cast<handle<TDF_Data> (TDF_Transaction::*)() const>(&TDF_Transaction::Data),
             R"#(Returns the Data from TDF.)#" 
          )
        .def("Transaction",
             (int (TDF_Transaction::*)() const) static_cast<int (TDF_Transaction::*)() const>(&TDF_Transaction::Transaction),
             R"#(Returns the number of the transaction opened by <me>.)#" 
          )
        .def("IsOpen",
             (bool (TDF_Transaction::*)() const) static_cast<bool (TDF_Transaction::*)() const>(&TDF_Transaction::IsOpen),
             R"#(Returns true if the transaction is open.)#" 
          )
        .def("DumpJson",
             (void (TDF_Transaction::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDF_Transaction::*)( Standard_OStream & ,  int  ) const>(&TDF_Transaction::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
        .def("Data",
             (handle<TDF_Data> (TDF_Transaction::*)() const) static_cast<handle<TDF_Data> (TDF_Transaction::*)() const>(&TDF_Transaction::Data),
             R"#(Returns the Data from TDF.)#" 
          )
        .def("Transaction",
             (int (TDF_Transaction::*)() const) static_cast<int (TDF_Transaction::*)() const>(&TDF_Transaction::Transaction),
             R"#(Returns the number of the transaction opened by <me>.)#" 
          )
        .def("IsOpen",
             (bool (TDF_Transaction::*)() const) static_cast<bool (TDF_Transaction::*)() const>(&TDF_Transaction::IsOpen),
             R"#(Returns true if the transaction is open.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Name",
             ( const TCollection_AsciiString & (TDF_Transaction::*)() const) static_cast< const TCollection_AsciiString & (TDF_Transaction::*)() const>(&TDF_Transaction::Name),
             R"#(Returns the transaction name.)#"
             
         )
       .def("Name",
             ( const TCollection_AsciiString & (TDF_Transaction::*)() const) static_cast< const TCollection_AsciiString & (TDF_Transaction::*)() const>(&TDF_Transaction::Name),
             R"#(Returns the transaction name.)#"
             
         )
;

    // Class TDF_DeltaOnAddition from ./opencascade/TDF_DeltaOnAddition.hxx
    klass = m.attr("TDF_DeltaOnAddition");


    // nested enums

    static_cast<py::class_<TDF_DeltaOnAddition ,opencascade::handle<TDF_DeltaOnAddition>  , TDF_AttributeDelta >>(klass)
    // constructors
        .def(py::init<  const handle<TDF_Attribute> & >()  , py::arg("anAtt") )
    // custom constructors
    // methods
        .def("Apply",
             (void (TDF_DeltaOnAddition::*)() ) static_cast<void (TDF_DeltaOnAddition::*)() >(&TDF_DeltaOnAddition::Apply),
             R"#(Applies the delta to the attribute.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDF_DeltaOnAddition::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDF_DeltaOnAddition::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDF_DeltaOnAddition::*)() const) static_cast< const handle<Standard_Type> & (TDF_DeltaOnAddition::*)() const>(&TDF_DeltaOnAddition::DynamicType),
             R"#()#"
             
         )
;

    // Class TDF_DeltaOnForget from ./opencascade/TDF_DeltaOnForget.hxx
    klass = m.attr("TDF_DeltaOnForget");


    // nested enums

    static_cast<py::class_<TDF_DeltaOnForget ,opencascade::handle<TDF_DeltaOnForget>  , TDF_AttributeDelta >>(klass)
    // constructors
        .def(py::init<  const handle<TDF_Attribute> & >()  , py::arg("anAtt") )
    // custom constructors
    // methods
        .def("Apply",
             (void (TDF_DeltaOnForget::*)() ) static_cast<void (TDF_DeltaOnForget::*)() >(&TDF_DeltaOnForget::Apply),
             R"#(Applies the delta to the attribute.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDF_DeltaOnForget::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDF_DeltaOnForget::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDF_DeltaOnForget::*)() const) static_cast< const handle<Standard_Type> & (TDF_DeltaOnForget::*)() const>(&TDF_DeltaOnForget::DynamicType),
             R"#()#"
             
         )
;

    // Class TDF_DeltaOnModification from ./opencascade/TDF_DeltaOnModification.hxx
    klass = m.attr("TDF_DeltaOnModification");


    // nested enums

    static_cast<py::class_<TDF_DeltaOnModification ,opencascade::handle<TDF_DeltaOnModification>  , TDF_AttributeDelta >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("Apply",
             (void (TDF_DeltaOnModification::*)() ) static_cast<void (TDF_DeltaOnModification::*)() >(&TDF_DeltaOnModification::Apply),
             R"#(Applies the delta to the attribute.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDF_DeltaOnModification::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDF_DeltaOnModification::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDF_DeltaOnModification::*)() const) static_cast< const handle<Standard_Type> & (TDF_DeltaOnModification::*)() const>(&TDF_DeltaOnModification::DynamicType),
             R"#()#"
             
         )
;

    // Class TDF_DeltaOnRemoval from ./opencascade/TDF_DeltaOnRemoval.hxx
    klass = m.attr("TDF_DeltaOnRemoval");


    // nested enums

    static_cast<py::class_<TDF_DeltaOnRemoval ,opencascade::handle<TDF_DeltaOnRemoval> ,Py_TDF_DeltaOnRemoval , TDF_AttributeDelta >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDF_DeltaOnRemoval::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDF_DeltaOnRemoval::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDF_DeltaOnRemoval::*)() const) static_cast< const handle<Standard_Type> & (TDF_DeltaOnRemoval::*)() const>(&TDF_DeltaOnRemoval::DynamicType),
             R"#()#"
             
         )
;

    // Class TDF_DeltaOnResume from ./opencascade/TDF_DeltaOnResume.hxx
    klass = m.attr("TDF_DeltaOnResume");


    // nested enums

    static_cast<py::class_<TDF_DeltaOnResume ,opencascade::handle<TDF_DeltaOnResume>  , TDF_AttributeDelta >>(klass)
    // constructors
        .def(py::init<  const handle<TDF_Attribute> & >()  , py::arg("anAtt") )
    // custom constructors
    // methods
        .def("Apply",
             (void (TDF_DeltaOnResume::*)() ) static_cast<void (TDF_DeltaOnResume::*)() >(&TDF_DeltaOnResume::Apply),
             R"#(Applies the delta to the attribute.)#" 
          )
        .def("DumpJson",
             (void (TDF_DeltaOnResume::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDF_DeltaOnResume::*)( Standard_OStream & ,  int  ) const>(&TDF_DeltaOnResume::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDF_DeltaOnResume::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDF_DeltaOnResume::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDF_DeltaOnResume::*)() const) static_cast< const handle<Standard_Type> & (TDF_DeltaOnResume::*)() const>(&TDF_DeltaOnResume::DynamicType),
             R"#()#"
             
         )
;

    // Class TDF_Reference from ./opencascade/TDF_Reference.hxx
    klass = m.attr("TDF_Reference");


    // nested enums

    static_cast<py::class_<TDF_Reference ,opencascade::handle<TDF_Reference>  , TDF_Attribute >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Set",
             (void (TDF_Reference::*)(  const TDF_Label &  ) ) static_cast<void (TDF_Reference::*)(  const TDF_Label &  ) >(&TDF_Reference::Set),
             R"#()#"  , py::arg("Origin")
          )
        .def("Get",
             (TDF_Label (TDF_Reference::*)() const) static_cast<TDF_Label (TDF_Reference::*)() const>(&TDF_Reference::Get),
             R"#()#" 
          )
        .def("Restore",
             (void (TDF_Reference::*)(  const handle<TDF_Attribute> &  ) ) static_cast<void (TDF_Reference::*)(  const handle<TDF_Attribute> &  ) >(&TDF_Reference::Restore),
             R"#()#"  , py::arg("With")
          )
        .def("NewEmpty",
             (handle<TDF_Attribute> (TDF_Reference::*)() const) static_cast<handle<TDF_Attribute> (TDF_Reference::*)() const>(&TDF_Reference::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (void (TDF_Reference::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const) static_cast<void (TDF_Reference::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const>(&TDF_Reference::Paste),
             R"#()#"  , py::arg("Into"),  py::arg("RT")
          )
        .def("References",
             (void (TDF_Reference::*)(  const handle<TDF_DataSet> &  ) const) static_cast<void (TDF_Reference::*)(  const handle<TDF_DataSet> &  ) const>(&TDF_Reference::References),
             R"#()#"  , py::arg("DS")
          )
        .def("Dump",
             (Standard_OStream & (TDF_Reference::*)( Standard_OStream &  ) const) static_cast<Standard_OStream & (TDF_Reference::*)( Standard_OStream &  ) const>(&TDF_Reference::Dump),
             R"#()#"  , py::arg("anOS")
          )
        .def("DumpJson",
             (void (TDF_Reference::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDF_Reference::*)( Standard_OStream & ,  int  ) const>(&TDF_Reference::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("GetID_s",
                    ( const Standard_GUID & (*)() ) static_cast< const Standard_GUID & (*)() >(&TDF_Reference::GetID),
                    R"#()#" 
          )
        .def_static("Set_s",
                    (handle<TDF_Reference> (*)(  const TDF_Label & ,   const TDF_Label &  ) ) static_cast<handle<TDF_Reference> (*)(  const TDF_Label & ,   const TDF_Label &  ) >(&TDF_Reference::Set),
                    R"#()#"  , py::arg("I"),  py::arg("Origin")
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDF_Reference::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDF_Reference::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("ID",
             ( const Standard_GUID & (TDF_Reference::*)() const) static_cast< const Standard_GUID & (TDF_Reference::*)() const>(&TDF_Reference::ID),
             R"#()#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDF_Reference::*)() const) static_cast< const handle<Standard_Type> & (TDF_Reference::*)() const>(&TDF_Reference::DynamicType),
             R"#()#"
             
         )
;

    // Class TDF_TagSource from ./opencascade/TDF_TagSource.hxx
    klass = m.attr("TDF_TagSource");


    // nested enums

    static_cast<py::class_<TDF_TagSource ,opencascade::handle<TDF_TagSource>  , TDF_Attribute >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("NewTag",
             (int (TDF_TagSource::*)() ) static_cast<int (TDF_TagSource::*)() >(&TDF_TagSource::NewTag),
             R"#()#" 
          )
        .def("NewChild",
             (TDF_Label (TDF_TagSource::*)() ) static_cast<TDF_Label (TDF_TagSource::*)() >(&TDF_TagSource::NewChild),
             R"#()#" 
          )
        .def("Get",
             (int (TDF_TagSource::*)() const) static_cast<int (TDF_TagSource::*)() const>(&TDF_TagSource::Get),
             R"#()#" 
          )
        .def("Set",
             (void (TDF_TagSource::*)(  const int  ) ) static_cast<void (TDF_TagSource::*)(  const int  ) >(&TDF_TagSource::Set),
             R"#(TDF_Attribute methods =====================)#"  , py::arg("T")
          )
        .def("Restore",
             (void (TDF_TagSource::*)(  const handle<TDF_Attribute> &  ) ) static_cast<void (TDF_TagSource::*)(  const handle<TDF_Attribute> &  ) >(&TDF_TagSource::Restore),
             R"#()#"  , py::arg("with_")
          )
        .def("NewEmpty",
             (handle<TDF_Attribute> (TDF_TagSource::*)() const) static_cast<handle<TDF_Attribute> (TDF_TagSource::*)() const>(&TDF_TagSource::NewEmpty),
             R"#()#" 
          )
        .def("Paste",
             (void (TDF_TagSource::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const) static_cast<void (TDF_TagSource::*)(  const handle<TDF_Attribute> & ,   const handle<TDF_RelocationTable> &  ) const>(&TDF_TagSource::Paste),
             R"#()#"  , py::arg("Into"),  py::arg("RT")
          )
        .def("DumpJson",
             (void (TDF_TagSource::*)( Standard_OStream & ,  int  ) const) static_cast<void (TDF_TagSource::*)( Standard_OStream & ,  int  ) const>(&TDF_TagSource::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("GetID_s",
                    ( const Standard_GUID & (*)() ) static_cast< const Standard_GUID & (*)() >(&TDF_TagSource::GetID),
                    R"#(class methods =============)#" 
          )
        .def_static("Set_s",
                    (handle<TDF_TagSource> (*)(  const TDF_Label &  ) ) static_cast<handle<TDF_TagSource> (*)(  const TDF_Label &  ) >(&TDF_TagSource::Set),
                    R"#(Find, or create, a TagSource attribute. the TagSource attribute is returned.)#"  , py::arg("label")
          )
        .def_static("NewChild_s",
                    (TDF_Label (*)(  const TDF_Label &  ) ) static_cast<TDF_Label (*)(  const TDF_Label &  ) >(&TDF_TagSource::NewChild),
                    R"#(Find (or create) a tagSource attribute located at <L> and make a new child label. TagSource methods =================)#"  , py::arg("L")
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDF_TagSource::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDF_TagSource::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("ID",
             ( const Standard_GUID & (TDF_TagSource::*)() const) static_cast< const Standard_GUID & (TDF_TagSource::*)() const>(&TDF_TagSource::ID),
             R"#()#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDF_TagSource::*)() const) static_cast< const handle<Standard_Type> & (TDF_TagSource::*)() const>(&TDF_TagSource::DynamicType),
             R"#()#"
             
         )
;

    // Class TDF_DefaultDeltaOnModification from ./opencascade/TDF_DefaultDeltaOnModification.hxx
    klass = m.attr("TDF_DefaultDeltaOnModification");


    // nested enums

    static_cast<py::class_<TDF_DefaultDeltaOnModification ,opencascade::handle<TDF_DefaultDeltaOnModification>  , TDF_DeltaOnModification >>(klass)
    // constructors
        .def(py::init<  const handle<TDF_Attribute> & >()  , py::arg("anAttribute") )
    // custom constructors
    // methods
        .def("Apply",
             (void (TDF_DefaultDeltaOnModification::*)() ) static_cast<void (TDF_DefaultDeltaOnModification::*)() >(&TDF_DefaultDeltaOnModification::Apply),
             R"#(Applies the delta to the attribute.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDF_DefaultDeltaOnModification::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDF_DefaultDeltaOnModification::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDF_DefaultDeltaOnModification::*)() const) static_cast< const handle<Standard_Type> & (TDF_DefaultDeltaOnModification::*)() const>(&TDF_DefaultDeltaOnModification::DynamicType),
             R"#()#"
             
         )
;

    // Class TDF_DefaultDeltaOnRemoval from ./opencascade/TDF_DefaultDeltaOnRemoval.hxx
    klass = m.attr("TDF_DefaultDeltaOnRemoval");


    // nested enums

    static_cast<py::class_<TDF_DefaultDeltaOnRemoval ,opencascade::handle<TDF_DefaultDeltaOnRemoval>  , TDF_DeltaOnRemoval >>(klass)
    // constructors
        .def(py::init<  const handle<TDF_Attribute> & >()  , py::arg("anAttribute") )
    // custom constructors
    // methods
        .def("Apply",
             (void (TDF_DefaultDeltaOnRemoval::*)() ) static_cast<void (TDF_DefaultDeltaOnRemoval::*)() >(&TDF_DefaultDeltaOnRemoval::Apply),
             R"#(Applies the delta to the attribute.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TDF_DefaultDeltaOnRemoval::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TDF_DefaultDeltaOnRemoval::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (TDF_DefaultDeltaOnRemoval::*)() const) static_cast< const handle<Standard_Type> & (TDF_DefaultDeltaOnRemoval::*)() const>(&TDF_DefaultDeltaOnRemoval::DynamicType),
             R"#()#"
             
         )
;

// functions

// ./opencascade/TDF.hxx
// ./opencascade/TDF_Attribute.hxx
// ./opencascade/TDF_AttributeDelta.hxx
// ./opencascade/TDF_AttributeIterator.hxx
// ./opencascade/TDF_ChildIDIterator.hxx
// ./opencascade/TDF_ChildIterator.hxx
// ./opencascade/TDF_ClosureMode.hxx
// ./opencascade/TDF_ClosureTool.hxx
// ./opencascade/TDF_ComparisonTool.hxx
// ./opencascade/TDF_CopyLabel.hxx
// ./opencascade/TDF_CopyTool.hxx
// ./opencascade/TDF_Data.hxx
// ./opencascade/TDF_DataSet.hxx
// ./opencascade/TDF_DefaultDeltaOnModification.hxx
// ./opencascade/TDF_DefaultDeltaOnRemoval.hxx
// ./opencascade/TDF_Delta.hxx
// ./opencascade/TDF_DeltaOnAddition.hxx
// ./opencascade/TDF_DeltaOnForget.hxx
// ./opencascade/TDF_DeltaOnModification.hxx
// ./opencascade/TDF_DeltaOnRemoval.hxx
// ./opencascade/TDF_DeltaOnResume.hxx
// ./opencascade/TDF_DerivedAttribute.hxx
// ./opencascade/TDF_HAllocator.hxx
// ./opencascade/TDF_IDFilter.hxx
// ./opencascade/TDF_Label.hxx
// ./opencascade/TDF_LabelNode.hxx
// ./opencascade/TDF_LabelNodePtr.hxx
// ./opencascade/TDF_Reference.hxx
// ./opencascade/TDF_RelocationTable.hxx
// ./opencascade/TDF_TagSource.hxx
// ./opencascade/TDF_Tool.hxx
// ./opencascade/TDF_Transaction.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
