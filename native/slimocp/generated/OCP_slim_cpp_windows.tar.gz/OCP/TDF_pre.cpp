
// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;


// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_GUID.hxx>
#include <TCollection_ExtendedString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_DeltaOnForget.hxx>
#include <Standard_GUID.hxx>
#include <TDF_AttributeDelta.hxx>
#include <TDF_DeltaOnAddition.hxx>
#include <TDF_DeltaOnResume.hxx>
#include <TDF_DeltaOnModification.hxx>
#include <TDF_DeltaOnRemoval.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_DataSet.hxx>
#include <TDF_IDFilter.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_GUID.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_DataSet.hxx>
#include <TDF_IDFilter.hxx>
#include <TDF_ClosureMode.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_DataSet.hxx>
#include <TDF_IDFilter.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_Label.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_DataSet.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_DataSet.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_IDFilter.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Delta.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_GUID.hxx>
#include <TDF_IDFilter.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Data.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_GUID.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_DataSet.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_GUID.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_IDFilter.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Data.hxx>
#include <TDF_Delta.hxx>

// module includes
#include <TDF.hxx>
#include <TDF_Attribute.hxx>
#include <TDF_AttributeDelta.hxx>
#include <TDF_AttributeIterator.hxx>
#include <TDF_ChildIDIterator.hxx>
#include <TDF_ChildIterator.hxx>
#include <TDF_ClosureMode.hxx>
#include <TDF_ClosureTool.hxx>
#include <TDF_ComparisonTool.hxx>
#include <TDF_CopyLabel.hxx>
#include <TDF_CopyTool.hxx>
#include <TDF_Data.hxx>
#include <TDF_DataSet.hxx>
#include <TDF_DefaultDeltaOnModification.hxx>
#include <TDF_DefaultDeltaOnRemoval.hxx>
#include <TDF_Delta.hxx>
#include <TDF_DeltaOnAddition.hxx>
#include <TDF_DeltaOnForget.hxx>
#include <TDF_DeltaOnModification.hxx>
#include <TDF_DeltaOnRemoval.hxx>
#include <TDF_DeltaOnResume.hxx>
#include <TDF_DerivedAttribute.hxx>
#include <TDF_HAllocator.hxx>
#include <TDF_IDFilter.hxx>
#include <TDF_Label.hxx>
#include <TDF_LabelNode.hxx>
#include <TDF_LabelNodePtr.hxx>
#include <TDF_Reference.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_TagSource.hxx>
#include <TDF_Tool.hxx>
#include <TDF_Transaction.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_TDF_enums(py::module &main_module) {


py::module m = main_module.def_submodule("TDF", R"#()#");

// add namespaces as submodules

// user-defined inclusion per module in the body

// enums
    m.attr("TDF_LabelNodeImportMsk") = py::cast(int(TDF_LabelNodeImportMsk));
    m.attr("TDF_LabelNodeAttModMsk") = py::cast(int(TDF_LabelNodeAttModMsk));
    m.attr("TDF_LabelNodeMayModMsk") = py::cast(int(TDF_LabelNodeMayModMsk));
    m.attr("TDF_LabelNodeFlagsMsk") = py::cast(int(TDF_LabelNodeFlagsMsk));
    m.attr("TDF_AttributeValidMsk") = py::cast(int(TDF_AttributeValidMsk));
    m.attr("TDF_AttributeBackupMsk") = py::cast(int(TDF_AttributeBackupMsk));
    m.attr("TDF_AttributeForgottenMsk") = py::cast(int(TDF_AttributeForgottenMsk));

//Python trampoline classes
    class Py_TDF_Attribute : public TDF_Attribute{
    public:
        using TDF_Attribute::TDF_Attribute;


        // public pure virtual
         const Standard_GUID & ID() const  override { using return_type =  const Standard_GUID &;
    PYBIND11_OVERLOAD_PURE(return_type,TDF_Attribute,ID,) };
        void Restore( const handle<TDF_Attribute> & anAttribute) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,TDF_Attribute,Restore,anAttribute) };
        handle<TDF_Attribute> NewEmpty() const  override { using return_type = handle<TDF_Attribute>;
    PYBIND11_OVERLOAD_PURE(return_type,TDF_Attribute,NewEmpty,) };
        void Paste( const handle<TDF_Attribute> & intoAttribute, const handle<TDF_RelocationTable> & aRelocationTable) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,TDF_Attribute,Paste,intoAttribute,aRelocationTable) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_TDF_AttributeDelta : public TDF_AttributeDelta{
    public:
        using TDF_AttributeDelta::TDF_AttributeDelta;


        // public pure virtual
        void Apply() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,TDF_AttributeDelta,Apply,) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_TDF_DeltaOnRemoval : public TDF_DeltaOnRemoval{
    public:
        using TDF_DeltaOnRemoval::TDF_DeltaOnRemoval;


        // public pure virtual

        void Apply() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,TDF_AttributeDelta,Apply,) };

        // protected pure virtual


        // private pure virtual

    };

// pre-register typdefs+classes (topologically sorted)
    py::class_<TDF , shared_ptr<TDF>  >(
      m,
      "TDF",R"#(This package provides data framework for binding features and data structures.)#"
    );
    py::class_<TDF_AttributeIterator , shared_ptr<TDF_AttributeIterator>  >(
      m,
      "TDF_AttributeIterator",R"#()#"
    );
    py::class_<TDF_ChildIDIterator , shared_ptr<TDF_ChildIDIterator>  >(
      m,
      "TDF_ChildIDIterator",R"#(Iterates on the children of a label, to find attributes having ID as Attribute ID.)#"
    );
    py::class_<TDF_ChildIterator , shared_ptr<TDF_ChildIterator>  >(
      m,
      "TDF_ChildIterator",R"#(Iterates on the children of a label, at the first level only. It is possible to ask the iterator to explore all the sub label levels of the given one, with the option "allLevels".)#"
    );
    py::class_<TDF_ClosureMode , shared_ptr<TDF_ClosureMode>  >(
      m,
      "TDF_ClosureMode",R"#(This class provides options closure management.)#"
    );
    py::class_<TDF_ClosureTool , shared_ptr<TDF_ClosureTool>  >(
      m,
      "TDF_ClosureTool",R"#(This class provides services to build the closure of an information set. This class gives services around the transitive enclosure of a set of information, starting from a list of label. You can set closure options by using IDFilter (to select or exclude specific attribute IDs) and CopyOption objects and by giving to Closure method.)#"
    );
    py::class_<TDF_ComparisonTool , shared_ptr<TDF_ComparisonTool>  >(
      m,
      "TDF_ComparisonTool",R"#(This class provides services to compare sets of information. The use of this tool can works after a copy, acted by a CopyTool.)#"
    );
    py::class_<TDF_CopyLabel , shared_ptr<TDF_CopyLabel>  >(
      m,
      "TDF_CopyLabel",R"#(This class gives copy of source label hierarchy)#"
    );
    py::class_<TDF_CopyTool , shared_ptr<TDF_CopyTool>  >(
      m,
      "TDF_CopyTool",R"#(This class provides services to build, copy or paste a set of information.)#"
    );
    py::class_<TDF_DerivedAttribute , shared_ptr<TDF_DerivedAttribute>  >(
      m,
      "TDF_DerivedAttribute",R"#(Class provides global access (through static methods) to all derived attributes information. It is used internally by macros for registration of derived attributes and driver-tables for getting this data.)#"
    );
    py::class_<TDF_IDFilter , shared_ptr<TDF_IDFilter>  >(
      m,
      "TDF_IDFilter",R"#(This class offers filtering services around an ID list.)#"
    );
    py::class_<TDF_Label , shared_ptr<TDF_Label>  >(
      m,
      "TDF_Label",R"#(This class provides basic operations to define a label in a data structure. A label is a feature in the feature hierarchy. A label is always connected to a Data from TDF. To a label is attached attributes containing the software components information.)#"
    );
    py::class_<TDF_Tool , shared_ptr<TDF_Tool>  >(
      m,
      "TDF_Tool",R"#(This class provides general services for a data framework.)#"
    );
    py::class_<TDF_Transaction , shared_ptr<TDF_Transaction>  >(
      m,
      "TDF_Transaction",R"#(This class offers services to open, commit or abort a transaction in a more secure way than using Data from TDF. If you forget to close a transaction, it will be automatically aborted at the destruction of this object, at the closure of its scope.)#"
    );
    py::class_<TDF_Attribute ,opencascade::handle<TDF_Attribute> ,Py_TDF_Attribute , Standard_Transient >(
      m,
      "TDF_Attribute",R"#(A class each application has to implement. It is used to contain the application data. This abstract class, alongwith Label, is one of the cornerstones of Model Editor. The groundwork is to define the root of information. This information is to be attached to a Label, and could be of any of the following types: - a feature - a constraint - a comment)#"
    );
    py::class_<TDF_AttributeDelta ,opencascade::handle<TDF_AttributeDelta> ,Py_TDF_AttributeDelta , Standard_Transient >(
      m,
      "TDF_AttributeDelta",R"#(This class describes the services we need to implement Delta and Undo/Redo services.)#"
    );
    py::class_<TDF_Data ,opencascade::handle<TDF_Data>  , Standard_Transient >(
      m,
      "TDF_Data",R"#(This class is used to manipulate a complete independent, self sufficient data structure and its services:)#"
    );
    py::class_<TDF_DataSet ,opencascade::handle<TDF_DataSet>  , Standard_Transient >(
      m,
      "TDF_DataSet",R"#(This class is a set of TDF information like labels and attributes.)#"
    );
    py::class_<TDF_Delta ,opencascade::handle<TDF_Delta>  , Standard_Transient >(
      m,
      "TDF_Delta",R"#(A set of AttributeDelta for a given transaction number and reference time number. A delta set is available at <aSourceTime>. If applied, it restores the TDF_Data in the state it was at <aTargetTime>.)#"
    );
    py::class_<TDF_RelocationTable ,opencascade::handle<TDF_RelocationTable>  , Standard_Transient >(
      m,
      "TDF_RelocationTable",R"#(This is a relocation dictionary between source and target labels, attributes or any transient(useful for copy or paste actions). Note that one target value may be the relocation value of more than one source object.)#"
    );
    py::class_<TDF_DeltaOnAddition ,opencascade::handle<TDF_DeltaOnAddition>  , TDF_AttributeDelta >(
      m,
      "TDF_DeltaOnAddition",R"#(This class provides default services for an AttributeDelta on an ADDITION action.)#"
    );
    py::class_<TDF_DeltaOnForget ,opencascade::handle<TDF_DeltaOnForget>  , TDF_AttributeDelta >(
      m,
      "TDF_DeltaOnForget",R"#(This class provides default services for an AttributeDelta on an Forget action.)#"
    );
    py::class_<TDF_DeltaOnModification ,opencascade::handle<TDF_DeltaOnModification>  , TDF_AttributeDelta >(
      m,
      "TDF_DeltaOnModification",R"#(This class provides default services for an AttributeDelta on a MODIFICATION action.)#"
    );
    py::class_<TDF_DeltaOnRemoval ,opencascade::handle<TDF_DeltaOnRemoval> ,Py_TDF_DeltaOnRemoval , TDF_AttributeDelta >(
      m,
      "TDF_DeltaOnRemoval",R"#(This class provides default services for an AttributeDelta on a REMOVAL action.)#"
    );
    py::class_<TDF_DeltaOnResume ,opencascade::handle<TDF_DeltaOnResume>  , TDF_AttributeDelta >(
      m,
      "TDF_DeltaOnResume",R"#(This class provides default services for an AttributeDelta on an Resume action.)#"
    );
    py::class_<TDF_Reference ,opencascade::handle<TDF_Reference>  , TDF_Attribute >(
      m,
      "TDF_Reference",R"#(This attribute is used to store in the framework a reference to an other label.)#"
    );
    py::class_<TDF_TagSource ,opencascade::handle<TDF_TagSource>  , TDF_Attribute >(
      m,
      "TDF_TagSource",R"#(This attribute manage a tag provider to create child labels of a given one.)#"
    );
    py::class_<TDF_DefaultDeltaOnModification ,opencascade::handle<TDF_DefaultDeltaOnModification>  , TDF_DeltaOnModification >(
      m,
      "TDF_DefaultDeltaOnModification",R"#(This class provides a default implementation of a TDF_DeltaOnModification.)#"
    );
    py::class_<TDF_DefaultDeltaOnRemoval ,opencascade::handle<TDF_DefaultDeltaOnRemoval>  , TDF_DeltaOnRemoval >(
      m,
      "TDF_DefaultDeltaOnRemoval",R"#(This class provides a default implementation of a TDF_DeltaOnRemoval.)#"
    );

// preregister user-defined template specializations

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
