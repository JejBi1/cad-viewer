
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_Aspects.hxx>
#include <OpenGl_Context.hxx>
#include <OpenGl_ShaderProgram.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_Context.hxx>
#include <OpenGl_PointSprite.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_Context.hxx>
#include <OpenGl_TextureSet.hxx>
#include <OpenGl_PointSprite.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_Structure.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_ClippingIterator.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_GlFunctions.hxx>
#include <OpenGl_ArbTBO.hxx>
#include <OpenGl_ArbIns.hxx>
#include <OpenGl_ArbDbg.hxx>
#include <OpenGl_ArbFBO.hxx>
#include <OpenGl_ArbFBO.hxx>
#include <OpenGl_ArbSamplerObject.hxx>
#include <OpenGl_ArbTexBindless.hxx>
#include <OpenGl_ExtGS.hxx>
#include <OpenGl_GlCore11Fwd.hxx>
#include <OpenGl_GlCore11.hxx>
#include <OpenGl_GlCore12.hxx>
#include <OpenGl_GlCore13.hxx>
#include <OpenGl_GlCore14.hxx>
#include <OpenGl_GlCore15.hxx>
#include <OpenGl_GlCore20.hxx>
#include <OpenGl_GlCore21.hxx>
#include <OpenGl_GlCore30.hxx>
#include <OpenGl_GlCore31.hxx>
#include <OpenGl_GlCore32.hxx>
#include <OpenGl_GlCore33.hxx>
#include <OpenGl_GlCore40.hxx>
#include <OpenGl_GlCore41.hxx>
#include <OpenGl_GlCore42.hxx>
#include <OpenGl_GlCore43.hxx>
#include <OpenGl_GlCore44.hxx>
#include <OpenGl_GlCore45.hxx>
#include <OpenGl_GlCore46.hxx>
#include <Graphic3d_Camera.hxx>
#include <Graphic3d_PresentationAttributes.hxx>
#include <OpenGl_Aspects.hxx>
#include <OpenGl_FrameBuffer.hxx>
#include <OpenGl_ShaderProgram.hxx>
#include <OpenGl_ShaderManager.hxx>
#include <OpenGl_FrameStats.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_FrameStatsData.hxx>
#include <OpenGl_Workspace.hxx>
#include <OpenGl_Context.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Ax2.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Font_FTFont.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Image_PixMap.hxx>
#include <OpenGl_Texture.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_CStructure.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_ArrayOfTriangles.hxx>
#include <OpenGl_IndexBuffer.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_Context.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_Structure.hxx>
#include <OpenGl_View.hxx>
#include <OpenGl_Window.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_Structure.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_Structure.hxx>
#include <OpenGl_Workspace.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_Context.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_Context.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_IndexBuffer.hxx>
#include <OpenGl_VertexBuffer.hxx>
#include <OpenGl_GraphicDriver.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_Context.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_Texture.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_Element.hxx>
#include <OpenGl_Group.hxx>
#include <OpenGl_Group.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_ShaderProgram.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_ShadowMap.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_XYZ.hxx>
#include <Graphic3d_Camera.hxx>
#include <Graphic3d_CLight.hxx>
#include <Graphic3d_CView.hxx>
#include <OpenGl_FrameBuffer.hxx>
#include <OpenGl_Texture.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Font_TextFormatter.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_Context.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_Texture.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_RenderingParams.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_BackgroundArray.hxx>
#include <OpenGl_DepthPeeling.hxx>
#include <OpenGl_PBREnvironment.hxx>
#include <OpenGl_ShadowMap.hxx>
#include <OpenGl_ShadowMap.hxx>
#include <OpenGl_TextureBuffer.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_Context.hxx>
#include <OpenGl_GraphicDriver.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OpenGl_FrameBuffer.hxx>
#include <OpenGl_Group.hxx>
#include <OpenGl_View.hxx>
#include <OpenGl_Window.hxx>

// module includes
#include <OpenGl_ArbDbg.hxx>
#include <OpenGl_ArbFBO.hxx>
#include <OpenGl_ArbIns.hxx>
#include <OpenGl_ArbSamplerObject.hxx>
#include <OpenGl_ArbTBO.hxx>
#include <OpenGl_ArbTexBindless.hxx>
#include <OpenGl_Aspects.hxx>
#include <OpenGl_AspectsProgram.hxx>
#include <OpenGl_AspectsSprite.hxx>
#include <OpenGl_AspectsTextureSet.hxx>
#include <OpenGl_BackgroundArray.hxx>
#include <OpenGl_Buffer.hxx>
#include <OpenGl_BufferCompatT.hxx>
#include <OpenGl_CappingAlgo.hxx>
#include <OpenGl_CappingPlaneResource.hxx>
#include <OpenGl_Caps.hxx>
#include <OpenGl_Clipping.hxx>
#include <OpenGl_ClippingIterator.hxx>
#include <OpenGl_Context.hxx>
#include <OpenGl_DepthPeeling.hxx>
#include <OpenGl_Element.hxx>
#include <OpenGl_ExtGS.hxx>
#include <OpenGl_Flipper.hxx>
#include <OpenGl_Font.hxx>
#include <OpenGl_FrameBuffer.hxx>
#include <OpenGl_FrameStats.hxx>
#include <OpenGl_FrameStatsPrs.hxx>
#include <OpenGl_GlCore11.hxx>
#include <OpenGl_GlCore11Fwd.hxx>
#include <OpenGl_GlCore12.hxx>
#include <OpenGl_GlCore13.hxx>
#include <OpenGl_GlCore14.hxx>
#include <OpenGl_GlCore15.hxx>
#include <OpenGl_GlCore20.hxx>
#include <OpenGl_GlCore21.hxx>
#include <OpenGl_GlCore30.hxx>
#include <OpenGl_GlCore31.hxx>
#include <OpenGl_GlCore32.hxx>
#include <OpenGl_GlCore33.hxx>
#include <OpenGl_GlCore40.hxx>
#include <OpenGl_GlCore41.hxx>
#include <OpenGl_GlCore42.hxx>
#include <OpenGl_GlCore43.hxx>
#include <OpenGl_GlCore44.hxx>
#include <OpenGl_GlCore45.hxx>
#include <OpenGl_GlCore46.hxx>
#include <OpenGl_GlFunctions.hxx>
#include <OpenGl_GlNative.hxx>
#include <OpenGl_GlTypes.hxx>
#include <OpenGl_GraduatedTrihedron.hxx>
#include <OpenGl_GraphicDriver.hxx>
#include <OpenGl_GraphicDriverFactory.hxx>
#include <OpenGl_Group.hxx>
#include <OpenGl_HaltonSampler.hxx>
#include <OpenGl_IndexBuffer.hxx>
#include <OpenGl_Layer.hxx>
#include <OpenGl_LayerFilter.hxx>
#include <OpenGl_LayerList.hxx>
#include <OpenGl_LineAttributes.hxx>
#include <OpenGl_Material.hxx>
#include <OpenGl_MaterialState.hxx>
#include <OpenGl_MatrixState.hxx>
#include <OpenGl_NamedResource.hxx>
#include <OpenGl_PBREnvironment.hxx>
#include <OpenGl_PointSprite.hxx>
#include <OpenGl_PrimitiveArray.hxx>
#include <OpenGl_RenderFilter.hxx>
#include <OpenGl_Resource.hxx>
#include <OpenGl_Sampler.hxx>
#include <OpenGl_SceneGeometry.hxx>
#include <OpenGl_SetOfShaderPrograms.hxx>
#include <OpenGl_ShaderGrid.hxx>
#include <OpenGl_ShaderManager.hxx>
#include <OpenGl_ShaderObject.hxx>
#include <OpenGl_ShaderProgram.hxx>
#include <OpenGl_ShaderProgramDumpLevel.hxx>
#include <OpenGl_ShaderStates.hxx>
#include <OpenGl_ShadowMap.hxx>
#include <OpenGl_StencilTest.hxx>
#include <OpenGl_Structure.hxx>
#include <OpenGl_StructureShadow.hxx>
#include <OpenGl_Text.hxx>
#include <OpenGl_TextBuilder.hxx>
#include <OpenGl_Texture.hxx>
#include <OpenGl_TextureBuffer.hxx>
#include <OpenGl_TextureFormat.hxx>
#include <OpenGl_TextureSet.hxx>
#include <OpenGl_TextureSetPairIterator.hxx>
#include <OpenGl_TileSampler.hxx>
#include <OpenGl_UniformBuffer.hxx>
#include <OpenGl_Vec.hxx>
#include <OpenGl_VertexBuffer.hxx>
#include <OpenGl_VertexBufferCompat.hxx>
#include <OpenGl_VertexBufferEditor.hxx>
#include <OpenGl_View.hxx>
#include <OpenGl_Window.hxx>
#include <OpenGl_Workspace.hxx>

// template related includes

// ./opencascade/OpenGl_SceneGeometry.hxx
#include "BVH_tmpl.hxx"

// ./opencascade/OpenGl_VertexBufferCompat.hxx
#include "OpenGl_tmpl.hxx"

// ./opencascade/OpenGl_VertexBufferCompat.hxx
#include "OpenGl_tmpl.hxx"


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module
#include <Message_Messenger.hxx>
#include <Image_SupportedFormats.hxx>
#include <Image_CompressedPixMap.hxx>
#include <Graphic3d_StructureManager.hxx>
struct NSOpenGLContext {};

// Module definiiton
void register_OpenGl(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("OpenGl"));
py::object klass;

// get namespaces as submodules
auto OpenGl_Raytrace = static_cast<py::module>(m.attr("OpenGl_Raytrace"));

//Python trampoline classes
    class Py_OpenGl_Element : public OpenGl_Element{
    public:
        using OpenGl_Element::OpenGl_Element;


        // public pure virtual
        void Render( const handle<OpenGl_Workspace> & theWorkspace) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,OpenGl_Element,Render,theWorkspace) };
        void Release(OpenGl_Context * theContext) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,OpenGl_Element,Release,theContext) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_OpenGl_Resource : public OpenGl_Resource{
    public:
        using OpenGl_Resource::OpenGl_Resource;


        // public pure virtual
        void Release(OpenGl_Context * theGlCtx) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,OpenGl_Resource,Release,theGlCtx) };
        size_t EstimatedDataSize() const  override { using return_type = size_t;
    PYBIND11_OVERLOAD_PURE(return_type,OpenGl_Resource,EstimatedDataSize,) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_OpenGl_Buffer : public OpenGl_Buffer{
    public:
        using OpenGl_Buffer::OpenGl_Buffer;


        // public pure virtual
        unsigned int GetTarget() const  override { using return_type = unsigned int;
    PYBIND11_OVERLOAD_PURE(return_type,OpenGl_Buffer,GetTarget,) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_OpenGl_NamedResource : public OpenGl_NamedResource{
    public:
        using OpenGl_NamedResource::OpenGl_NamedResource;


        // public pure virtual

        void Release(OpenGl_Context * theGlCtx) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,OpenGl_Resource,Release,theGlCtx) };
        size_t EstimatedDataSize() const  override { using return_type = size_t;
    PYBIND11_OVERLOAD_PURE(return_type,OpenGl_Resource,EstimatedDataSize,) };

        // protected pure virtual


        // private pure virtual

    };

// classes

    // Class OpenGl_ArbDbg from ./opencascade/OpenGl_ArbDbg.hxx
    klass = m.attr("OpenGl_ArbDbg");

    // default constructor
    register_default_constructor<OpenGl_ArbDbg , shared_ptr<OpenGl_ArbDbg>>(m,"OpenGl_ArbDbg");

    // nested enums

    static_cast<py::class_<OpenGl_ArbDbg , shared_ptr<OpenGl_ArbDbg>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_ArbFBO from ./opencascade/OpenGl_ArbFBO.hxx
    klass = m.attr("OpenGl_ArbFBO");

    // default constructor
    register_default_constructor<OpenGl_ArbFBO , shared_ptr<OpenGl_ArbFBO>>(m,"OpenGl_ArbFBO");

    // nested enums

    static_cast<py::class_<OpenGl_ArbFBO , shared_ptr<OpenGl_ArbFBO>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_ArbFBOBlit from ./opencascade/OpenGl_ArbFBO.hxx
    klass = m.attr("OpenGl_ArbFBOBlit");

    // default constructor
    register_default_constructor<OpenGl_ArbFBOBlit , shared_ptr<OpenGl_ArbFBOBlit>>(m,"OpenGl_ArbFBOBlit");

    // nested enums

    static_cast<py::class_<OpenGl_ArbFBOBlit , shared_ptr<OpenGl_ArbFBOBlit>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_ArbIns from ./opencascade/OpenGl_ArbIns.hxx
    klass = m.attr("OpenGl_ArbIns");

    // default constructor
    register_default_constructor<OpenGl_ArbIns , shared_ptr<OpenGl_ArbIns>>(m,"OpenGl_ArbIns");

    // nested enums

    static_cast<py::class_<OpenGl_ArbIns , shared_ptr<OpenGl_ArbIns>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_ArbSamplerObject from ./opencascade/OpenGl_ArbSamplerObject.hxx
    klass = m.attr("OpenGl_ArbSamplerObject");

    // default constructor
    register_default_constructor<OpenGl_ArbSamplerObject , shared_ptr<OpenGl_ArbSamplerObject>>(m,"OpenGl_ArbSamplerObject");

    // nested enums

    static_cast<py::class_<OpenGl_ArbSamplerObject , shared_ptr<OpenGl_ArbSamplerObject>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_ArbTBO from ./opencascade/OpenGl_ArbTBO.hxx
    klass = m.attr("OpenGl_ArbTBO");

    // default constructor
    register_default_constructor<OpenGl_ArbTBO , shared_ptr<OpenGl_ArbTBO>>(m,"OpenGl_ArbTBO");

    // nested enums

    static_cast<py::class_<OpenGl_ArbTBO , shared_ptr<OpenGl_ArbTBO>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_ArbTexBindless from ./opencascade/OpenGl_ArbTexBindless.hxx
    klass = m.attr("OpenGl_ArbTexBindless");

    // default constructor
    register_default_constructor<OpenGl_ArbTexBindless , shared_ptr<OpenGl_ArbTexBindless>>(m,"OpenGl_ArbTexBindless");

    // nested enums

    static_cast<py::class_<OpenGl_ArbTexBindless , shared_ptr<OpenGl_ArbTexBindless>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_AspectsProgram from ./opencascade/OpenGl_AspectsProgram.hxx
    klass = m.attr("OpenGl_AspectsProgram");


    // nested enums

    static_cast<py::class_<OpenGl_AspectsProgram , shared_ptr<OpenGl_AspectsProgram>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ShaderProgram",
             ( const handle<OpenGl_ShaderProgram> & (OpenGl_AspectsProgram::*)(  const handle<OpenGl_Context> & ,   const handle<Graphic3d_ShaderProgram> &  ) ) static_cast< const handle<OpenGl_ShaderProgram> & (OpenGl_AspectsProgram::*)(  const handle<OpenGl_Context> & ,   const handle<Graphic3d_ShaderProgram> &  ) >(&OpenGl_AspectsProgram::ShaderProgram),
             R"#(Return shading program.)#"  , py::arg("theCtx"),  py::arg("theShader")
          )
        .def("UpdateRediness",
             (void (OpenGl_AspectsProgram::*)(  const handle<Graphic3d_Aspects> &  ) ) static_cast<void (OpenGl_AspectsProgram::*)(  const handle<Graphic3d_Aspects> &  ) >(&OpenGl_AspectsProgram::UpdateRediness),
             R"#(Update shader resource up-to-date state.)#"  , py::arg("theAspect")
          )
        .def("Release",
             (void (OpenGl_AspectsProgram::*)( OpenGl_Context *  ) ) static_cast<void (OpenGl_AspectsProgram::*)( OpenGl_Context *  ) >(&OpenGl_AspectsProgram::Release),
             R"#(Release resource.)#"  , py::arg("theCtx")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_AspectsSprite from ./opencascade/OpenGl_AspectsSprite.hxx
    klass = m.attr("OpenGl_AspectsSprite");


    // nested enums

    static_cast<py::class_<OpenGl_AspectsSprite , shared_ptr<OpenGl_AspectsSprite>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("MarkerSize",
             (float (OpenGl_AspectsSprite::*)() const) static_cast<float (OpenGl_AspectsSprite::*)() const>(&OpenGl_AspectsSprite::MarkerSize),
             R"#()#" 
          )
        .def("IsReady",
             (bool (OpenGl_AspectsSprite::*)() const) static_cast<bool (OpenGl_AspectsSprite::*)() const>(&OpenGl_AspectsSprite::IsReady),
             R"#(Return TRUE if resource is up-to-date.)#" 
          )
        .def("Invalidate",
             (void (OpenGl_AspectsSprite::*)() ) static_cast<void (OpenGl_AspectsSprite::*)() >(&OpenGl_AspectsSprite::Invalidate),
             R"#(Invalidate resource state.)#" 
          )
        .def("HasPointSprite",
             (bool (OpenGl_AspectsSprite::*)(  const handle<OpenGl_Context> & ,   const handle<Graphic3d_Aspects> &  ) ) static_cast<bool (OpenGl_AspectsSprite::*)(  const handle<OpenGl_Context> & ,   const handle<Graphic3d_Aspects> &  ) >(&OpenGl_AspectsSprite::HasPointSprite),
             R"#(Return TRUE if OpenGl point sprite resource defines texture.)#"  , py::arg("theCtx"),  py::arg("theAspects")
          )
        .def("IsDisplayListSprite",
             (bool (OpenGl_AspectsSprite::*)(  const handle<OpenGl_Context> & ,   const handle<Graphic3d_Aspects> &  ) ) static_cast<bool (OpenGl_AspectsSprite::*)(  const handle<OpenGl_Context> & ,   const handle<Graphic3d_Aspects> &  ) >(&OpenGl_AspectsSprite::IsDisplayListSprite),
             R"#(Return TRUE if OpenGl point sprite resource defined by obsolete Display List (bitmap).)#"  , py::arg("theCtx"),  py::arg("theAspects")
          )
        .def("Sprite",
             ( const handle<OpenGl_PointSprite> & (OpenGl_AspectsSprite::*)(  const handle<OpenGl_Context> & ,   const handle<Graphic3d_Aspects> & ,  bool  ) ) static_cast< const handle<OpenGl_PointSprite> & (OpenGl_AspectsSprite::*)(  const handle<OpenGl_Context> & ,   const handle<Graphic3d_Aspects> & ,  bool  ) >(&OpenGl_AspectsSprite::Sprite),
             R"#(Return sprite.)#"  , py::arg("theCtx"),  py::arg("theAspects"),  py::arg("theIsAlphaSprite")
          )
        .def("UpdateRediness",
             (void (OpenGl_AspectsSprite::*)(  const handle<Graphic3d_Aspects> &  ) ) static_cast<void (OpenGl_AspectsSprite::*)(  const handle<Graphic3d_Aspects> &  ) >(&OpenGl_AspectsSprite::UpdateRediness),
             R"#(Update texture resource up-to-date state.)#"  , py::arg("theAspect")
          )
        .def("Release",
             (void (OpenGl_AspectsSprite::*)( OpenGl_Context *  ) ) static_cast<void (OpenGl_AspectsSprite::*)( OpenGl_Context *  ) >(&OpenGl_AspectsSprite::Release),
             R"#(Release texture resource.)#"  , py::arg("theCtx")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_AspectsTextureSet from ./opencascade/OpenGl_AspectsTextureSet.hxx
    klass = m.attr("OpenGl_AspectsTextureSet");


    // nested enums

    static_cast<py::class_<OpenGl_AspectsTextureSet , shared_ptr<OpenGl_AspectsTextureSet>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("IsReady",
             (bool (OpenGl_AspectsTextureSet::*)() const) static_cast<bool (OpenGl_AspectsTextureSet::*)() const>(&OpenGl_AspectsTextureSet::IsReady),
             R"#(Return TRUE if resource is up-to-date.)#" 
          )
        .def("Invalidate",
             (void (OpenGl_AspectsTextureSet::*)() ) static_cast<void (OpenGl_AspectsTextureSet::*)() >(&OpenGl_AspectsTextureSet::Invalidate),
             R"#(Invalidate resource state.)#" 
          )
        .def("TextureSet",
             ( const handle<OpenGl_TextureSet> & (OpenGl_AspectsTextureSet::*)(  const handle<OpenGl_Context> & ,   const handle<Graphic3d_Aspects> & ,   const handle<OpenGl_PointSprite> & ,   const handle<OpenGl_PointSprite> & ,  bool  ) ) static_cast< const handle<OpenGl_TextureSet> & (OpenGl_AspectsTextureSet::*)(  const handle<OpenGl_Context> & ,   const handle<Graphic3d_Aspects> & ,   const handle<OpenGl_PointSprite> & ,   const handle<OpenGl_PointSprite> & ,  bool  ) >(&OpenGl_AspectsTextureSet::TextureSet),
             R"#(Return textures array.)#"  , py::arg("theCtx"),  py::arg("theAspect"),  py::arg("theSprite"),  py::arg("theSpriteA"),  py::arg("theToHighlight")
          )
        .def("UpdateRediness",
             (void (OpenGl_AspectsTextureSet::*)(  const handle<Graphic3d_Aspects> &  ) ) static_cast<void (OpenGl_AspectsTextureSet::*)(  const handle<Graphic3d_Aspects> &  ) >(&OpenGl_AspectsTextureSet::UpdateRediness),
             R"#(Update texture resource up-to-date state.)#"  , py::arg("theAspect")
          )
        .def("Release",
             (void (OpenGl_AspectsTextureSet::*)( OpenGl_Context *  ) ) static_cast<void (OpenGl_AspectsTextureSet::*)( OpenGl_Context *  ) >(&OpenGl_AspectsTextureSet::Release),
             R"#(Release texture resource.)#"  , py::arg("theCtx")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_CappingAlgo from ./opencascade/OpenGl_CappingAlgo.hxx
    klass = m.attr("OpenGl_CappingAlgo");

    // default constructor
    register_default_constructor<OpenGl_CappingAlgo , shared_ptr<OpenGl_CappingAlgo>>(m,"OpenGl_CappingAlgo");

    // nested enums

    static_cast<py::class_<OpenGl_CappingAlgo , shared_ptr<OpenGl_CappingAlgo>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("RenderCapping_s",
                    (void (*)(  const handle<OpenGl_Workspace> & ,   const OpenGl_Structure &  ) ) static_cast<void (*)(  const handle<OpenGl_Workspace> & ,   const OpenGl_Structure &  ) >(&OpenGl_CappingAlgo::RenderCapping),
                    R"#(Draw capping surfaces by OpenGl for the clipping planes enabled in current context state. Depth buffer must be generated for the passed groups.)#"  , py::arg("theWorkspace"),  py::arg("theStructure")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_Caps from ./opencascade/OpenGl_Caps.hxx
    klass = m.attr("OpenGl_Caps");


    // nested enums

    static_cast<py::class_<OpenGl_Caps ,opencascade::handle<OpenGl_Caps>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_Caps::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_Caps::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
        .def_readwrite("sRGBDisable", &OpenGl_Caps::sRGBDisable)
        .def_readwrite("compressedTexturesDisable", &OpenGl_Caps::compressedTexturesDisable)
        .def_readwrite("vboDisable", &OpenGl_Caps::vboDisable)
        .def_readwrite("pntSpritesDisable", &OpenGl_Caps::pntSpritesDisable)
        .def_readwrite("keepArrayData", &OpenGl_Caps::keepArrayData)
        .def_readwrite("ffpEnable", &OpenGl_Caps::ffpEnable)
        .def_readwrite("usePolygonMode", &OpenGl_Caps::usePolygonMode)
        .def_readwrite("useSystemBuffer", &OpenGl_Caps::useSystemBuffer)
        .def_readwrite("swapInterval", &OpenGl_Caps::swapInterval)
        .def_readwrite("useZeroToOneDepth", &OpenGl_Caps::useZeroToOneDepth)
        .def_readwrite("buffersNoSwap", &OpenGl_Caps::buffersNoSwap)
        .def_readwrite("buffersOpaqueAlpha", &OpenGl_Caps::buffersOpaqueAlpha)
        .def_readwrite("buffersDeepColor", &OpenGl_Caps::buffersDeepColor)
        .def_readwrite("contextStereo", &OpenGl_Caps::contextStereo)
        .def_readwrite("contextDebug", &OpenGl_Caps::contextDebug)
        .def_readwrite("contextSyncDebug", &OpenGl_Caps::contextSyncDebug)
        .def_readwrite("contextNoAccel", &OpenGl_Caps::contextNoAccel)
        .def_readwrite("contextCompatible", &OpenGl_Caps::contextCompatible)
        .def_readwrite("contextNoExtensions", &OpenGl_Caps::contextNoExtensions)
        .def_readwrite("contextMajorVersionUpper", &OpenGl_Caps::contextMajorVersionUpper)
        .def_readwrite("contextMinorVersionUpper", &OpenGl_Caps::contextMinorVersionUpper)
        .def_readwrite("isTopDownTextureUV", &OpenGl_Caps::isTopDownTextureUV)
        .def_readwrite("glslWarnings", &OpenGl_Caps::glslWarnings)
        .def_readwrite("suppressExtraMsg", &OpenGl_Caps::suppressExtraMsg)
        .def_readwrite("glslDumpLevel", &OpenGl_Caps::glslDumpLevel)
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_Caps::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_Caps::*)() const>(&OpenGl_Caps::DynamicType),
             R"#()#"
             
         )
;

    // Class OpenGl_Clipping from ./opencascade/OpenGl_Clipping.hxx
    klass = m.attr("OpenGl_Clipping");


    // nested enums

    static_cast<py::class_<OpenGl_Clipping , shared_ptr<OpenGl_Clipping>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (OpenGl_Clipping::*)() ) static_cast<void (OpenGl_Clipping::*)() >(&OpenGl_Clipping::Init),
             R"#(Initialize.)#" 
          )
        .def("Reset",
             (void (OpenGl_Clipping::*)(  const handle<Graphic3d_SequenceOfHClipPlane> &  ) ) static_cast<void (OpenGl_Clipping::*)(  const handle<Graphic3d_SequenceOfHClipPlane> &  ) >(&OpenGl_Clipping::Reset),
             R"#(Setup list of global (for entire view) clipping planes and clears local plane list if it was not released before.)#"  , py::arg("thePlanes")
          )
        .def("SetLocalPlanes",
             (void (OpenGl_Clipping::*)(  const handle<Graphic3d_SequenceOfHClipPlane> &  ) ) static_cast<void (OpenGl_Clipping::*)(  const handle<Graphic3d_SequenceOfHClipPlane> &  ) >(&OpenGl_Clipping::SetLocalPlanes),
             R"#(Setup list of local (for current object) clipping planes.)#"  , py::arg("thePlanes")
          )
        .def("IsCappingOn",
             (bool (OpenGl_Clipping::*)() const) static_cast<bool (OpenGl_Clipping::*)() const>(&OpenGl_Clipping::IsCappingOn),
             R"#(Returns true if there are enabled capping planes)#" 
          )
        .def("IsClippingOrCappingOn",
             (bool (OpenGl_Clipping::*)() const) static_cast<bool (OpenGl_Clipping::*)() const>(&OpenGl_Clipping::IsClippingOrCappingOn),
             R"#(Returns true if there are enabled clipping or capping planes)#" 
          )
        .def("NbClippingOrCappingOn",
             (int (OpenGl_Clipping::*)() const) static_cast<int (OpenGl_Clipping::*)() const>(&OpenGl_Clipping::NbClippingOrCappingOn),
             R"#(Returns number of enabled clipping + capping planes)#" 
          )
        .def("HasClippingChains",
             (bool (OpenGl_Clipping::*)() const) static_cast<bool (OpenGl_Clipping::*)() const>(&OpenGl_Clipping::HasClippingChains),
             R"#(Return TRUE if there are clipping chains in the list (defining more than 1 sub-plane))#" 
          )
        .def("HasDisabled",
             (bool (OpenGl_Clipping::*)() const) static_cast<bool (OpenGl_Clipping::*)() const>(&OpenGl_Clipping::HasDisabled),
             R"#(Return true if some clipping planes have been temporarily disabled.)#" 
          )
        .def("SetEnabled",
             (bool (OpenGl_Clipping::*)(  const OpenGl_ClippingIterator & ,   const bool  ) ) static_cast<bool (OpenGl_Clipping::*)(  const OpenGl_ClippingIterator & ,   const bool  ) >(&OpenGl_Clipping::SetEnabled),
             R"#(Disable plane temporarily.)#"  , py::arg("thePlane"),  py::arg("theIsEnabled")
          )
        .def("DisableGlobal",
             (void (OpenGl_Clipping::*)() ) static_cast<void (OpenGl_Clipping::*)() >(&OpenGl_Clipping::DisableGlobal),
             R"#(Temporarily disable all planes from the global (view) list, keep only local (object) list.)#" 
          )
        .def("RestoreDisabled",
             (void (OpenGl_Clipping::*)() ) static_cast<void (OpenGl_Clipping::*)() >(&OpenGl_Clipping::RestoreDisabled),
             R"#(Restore all temporarily disabled planes. Does NOT affect constantly disabled planes Graphic3d_ClipPlane::IsOn().)#" 
          )
        .def("CappedSubPlane",
             (int (OpenGl_Clipping::*)() const) static_cast<int (OpenGl_Clipping::*)() const>(&OpenGl_Clipping::CappedSubPlane),
             R"#(Sub-plane index within filtered Chain; positive number for DisableAllExcept and negative for EnableAllExcept.)#" 
          )
        .def("IsCappingFilterOn",
             (bool (OpenGl_Clipping::*)() const) static_cast<bool (OpenGl_Clipping::*)() const>(&OpenGl_Clipping::IsCappingFilterOn),
             R"#(Return TRUE if capping algorithm is in state, when all clipping planes are temporarily disabled except currently processed one.)#" 
          )
        .def("IsCappingDisableAllExcept",
             (bool (OpenGl_Clipping::*)() const) static_cast<bool (OpenGl_Clipping::*)() const>(&OpenGl_Clipping::IsCappingDisableAllExcept),
             R"#(Return TRUE if capping algorithm is in state, when all clipping planes are temporarily disabled except currently processed one.)#" 
          )
        .def("IsCappingEnableAllExcept",
             (bool (OpenGl_Clipping::*)() const) static_cast<bool (OpenGl_Clipping::*)() const>(&OpenGl_Clipping::IsCappingEnableAllExcept),
             R"#(Return TRUE if capping algorithm is in state, when all clipping planes are enabled except currently rendered one.)#" 
          )
        .def("DisableAllExcept",
             (void (OpenGl_Clipping::*)(  const handle<Graphic3d_ClipPlane> & ,   const int  ) ) static_cast<void (OpenGl_Clipping::*)(  const handle<Graphic3d_ClipPlane> & ,   const int  ) >(&OpenGl_Clipping::DisableAllExcept),
             R"#(Temporarily disable all planes except specified one for Capping algorithm. Does not affect already disabled planes.)#"  , py::arg("theChain"),  py::arg("theSubPlaneIndex")
          )
        .def("EnableAllExcept",
             (void (OpenGl_Clipping::*)(  const handle<Graphic3d_ClipPlane> & ,   const int  ) ) static_cast<void (OpenGl_Clipping::*)(  const handle<Graphic3d_ClipPlane> & ,   const int  ) >(&OpenGl_Clipping::EnableAllExcept),
             R"#(Enable back planes disabled by ::DisableAllExcept() for Capping algorithm. Keeps only specified plane enabled.)#"  , py::arg("theChain"),  py::arg("theSubPlaneIndex")
          )
        .def("ResetCappingFilter",
             (void (OpenGl_Clipping::*)() ) static_cast<void (OpenGl_Clipping::*)() >(&OpenGl_Clipping::ResetCappingFilter),
             R"#(Resets chain filter for Capping algorithm.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("CappedChain",
             ( const handle<Graphic3d_ClipPlane> & (OpenGl_Clipping::*)() const) static_cast< const handle<Graphic3d_ClipPlane> & (OpenGl_Clipping::*)() const>(&OpenGl_Clipping::CappedChain),
             R"#(Chain which is either temporary disabled or the only one enabled for Capping algorithm.)#"
             
         )
;

    // Class OpenGl_ClippingIterator from ./opencascade/OpenGl_ClippingIterator.hxx
    klass = m.attr("OpenGl_ClippingIterator");


    // nested enums

    static_cast<py::class_<OpenGl_ClippingIterator , shared_ptr<OpenGl_ClippingIterator>  >>(klass)
    // constructors
        .def(py::init<  const OpenGl_Clipping & >()  , py::arg("theClipping") )
    // custom constructors
    // methods
        .def("More",
             (bool (OpenGl_ClippingIterator::*)() const) static_cast<bool (OpenGl_ClippingIterator::*)() const>(&OpenGl_ClippingIterator::More),
             R"#(Return true if iterator points to the valid clipping plane.)#" 
          )
        .def("Next",
             (void (OpenGl_ClippingIterator::*)() ) static_cast<void (OpenGl_ClippingIterator::*)() >(&OpenGl_ClippingIterator::Next),
             R"#(Go to the next clipping plane.)#" 
          )
        .def("IsDisabled",
             (bool (OpenGl_ClippingIterator::*)() const) static_cast<bool (OpenGl_ClippingIterator::*)() const>(&OpenGl_ClippingIterator::IsDisabled),
             R"#(Return true if plane has been temporarily disabled either by Graphic3d_ClipPlane->IsOn() property or by temporary filter. Beware that this method does NOT handle a Chain filter for Capping algorithm OpenGl_Clipping::CappedChain()!)#" 
          )
        .def("IsGlobal",
             (bool (OpenGl_ClippingIterator::*)() const) static_cast<bool (OpenGl_ClippingIterator::*)() const>(&OpenGl_ClippingIterator::IsGlobal),
             R"#(Return true if plane from the global (view) list.)#" 
          )
        .def("PlaneIndex",
             (int (OpenGl_ClippingIterator::*)() const) static_cast<int (OpenGl_ClippingIterator::*)() const>(&OpenGl_ClippingIterator::PlaneIndex),
             R"#(Return the plane index.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<Graphic3d_ClipPlane> & (OpenGl_ClippingIterator::*)() const) static_cast< const handle<Graphic3d_ClipPlane> & (OpenGl_ClippingIterator::*)() const>(&OpenGl_ClippingIterator::Value),
             R"#(Return the plane at current iterator position.)#"
             
         )
;

    // Class OpenGl_ClippingState from ./opencascade/OpenGl_ShaderStates.hxx
    klass = m.attr("OpenGl_ClippingState");


    // nested enums

    static_cast<py::class_<OpenGl_ClippingState , shared_ptr<OpenGl_ClippingState>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Index",
             (size_t (OpenGl_ClippingState::*)() const) static_cast<size_t (OpenGl_ClippingState::*)() const>(&OpenGl_ClippingState::Index),
             R"#(Returns current state index.)#" 
          )
        .def("Update",
             (void (OpenGl_ClippingState::*)() ) static_cast<void (OpenGl_ClippingState::*)() >(&OpenGl_ClippingState::Update),
             R"#(Updates current state.)#" 
          )
        .def("Revert",
             (void (OpenGl_ClippingState::*)() ) static_cast<void (OpenGl_ClippingState::*)() >(&OpenGl_ClippingState::Revert),
             R"#(Reverts current state.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_Context from ./opencascade/OpenGl_Context.hxx
    klass = m.attr("OpenGl_Context");


    // nested enums

    static_cast<py::class_<OpenGl_Context ,opencascade::handle<OpenGl_Context>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const handle<OpenGl_Caps> & >()  , py::arg("theCaps")=static_cast< const handle<OpenGl_Caps> &>(nullptr) )
    // custom constructors
    // methods
        .def("forcedRelease",
             (void (OpenGl_Context::*)() ) static_cast<void (OpenGl_Context::*)() >(&OpenGl_Context::forcedRelease),
             R"#(Release all resources, including shared ones)#" 
          )
        .def("Share",
             (void (OpenGl_Context::*)(  const handle<OpenGl_Context> &  ) ) static_cast<void (OpenGl_Context::*)(  const handle<OpenGl_Context> &  ) >(&OpenGl_Context::Share),
             R"#(Share GL context resources. theShareCtx - handle to context to retrieve handles to shared resources.)#"  , py::arg("theShareCtx")
          )
        .def("Init",
             (bool (OpenGl_Context::*)(  const bool  ) ) static_cast<bool (OpenGl_Context::*)(  const bool  ) >(&OpenGl_Context::Init),
             R"#(Initialize class from currently bound OpenGL context. Method should be called only once.)#"  , py::arg("theIsCoreProfile")=static_cast< const bool>(false)
          )
        .def("IsValid",
             (bool (OpenGl_Context::*)() const) static_cast<bool (OpenGl_Context::*)() const>(&OpenGl_Context::IsValid),
             R"#(Returns true if this context is valid (has been initialized))#" 
          )
        .def("Init",
             (bool (OpenGl_Context::*)(  const Aspect_Drawable ,   const Aspect_Display ,   const Aspect_RenderingContext ,   const bool  ) ) static_cast<bool (OpenGl_Context::*)(  const Aspect_Drawable ,   const Aspect_Display ,   const Aspect_RenderingContext ,   const bool  ) >(&OpenGl_Context::Init),
             R"#(Initialize class from specified surface and rendering context. Method should be called only once. The meaning of parameters is platform-specific.)#"  , py::arg("theSurface"),  py::arg("theDisplay"),  py::arg("theContext"),  py::arg("theIsCoreProfile")=static_cast< const bool>(false)
          )
        .def("Window",
             (Aspect_Drawable (OpenGl_Context::*)() const) static_cast<Aspect_Drawable (OpenGl_Context::*)() const>(&OpenGl_Context::Window),
             R"#(Return window handle currently bound to this OpenGL context (EGLSurface | HWND | GLXDrawable).)#" 
          )
        .def("GetDisplay",
             (Aspect_Display (OpenGl_Context::*)() const) static_cast<Aspect_Display (OpenGl_Context::*)() const>(&OpenGl_Context::GetDisplay),
             R"#(Return display / window device context (EGLDisplay | HDC | Display*).)#" 
          )
        .def("RenderingContext",
             (Aspect_RenderingContext (OpenGl_Context::*)() const) static_cast<Aspect_RenderingContext (OpenGl_Context::*)() const>(&OpenGl_Context::RenderingContext),
             R"#(Return rendering context (EGLContext | HGLRC | GLXContext | EAGLContext* | NSOpenGLContext*).)#" 
          )
        .def("CheckExtension",
             (bool (OpenGl_Context::*)(  const char *  ) const) static_cast<bool (OpenGl_Context::*)(  const char *  ) const>(&OpenGl_Context::CheckExtension),
             R"#(Check if theExtName extension is supported by active GL context.)#"  , py::arg("theExtName")
          )
        .def("GraphicsLibrary",
             (Aspect_GraphicsLibrary (OpenGl_Context::*)() const) static_cast<Aspect_GraphicsLibrary (OpenGl_Context::*)() const>(&OpenGl_Context::GraphicsLibrary),
             R"#(Return active graphics library.)#" 
          )
        .def("IsGlGreaterEqual",
             (bool (OpenGl_Context::*)(  const int ,   const int  ) const) static_cast<bool (OpenGl_Context::*)(  const int ,   const int  ) const>(&OpenGl_Context::IsGlGreaterEqual),
             R"#(Returns true if detected GL version is greater or equal to requested one.)#"  , py::arg("theVerMajor"),  py::arg("theVerMinor")
          )
        .def("VersionMajor",
             (int (OpenGl_Context::*)() const) static_cast<int (OpenGl_Context::*)() const>(&OpenGl_Context::VersionMajor),
             R"#(Return cached GL version major number.)#" 
          )
        .def("VersionMinor",
             (int (OpenGl_Context::*)() const) static_cast<int (OpenGl_Context::*)() const>(&OpenGl_Context::VersionMinor),
             R"#(Return cached GL version minor number.)#" 
          )
        .def("Functions",
             ( const OpenGl_GlFunctions * (OpenGl_Context::*)() const) static_cast< const OpenGl_GlFunctions * (OpenGl_Context::*)() const>(&OpenGl_Context::Functions),
             R"#(Access entire map of loaded OpenGL functions.)#" 
          )
        .def("ResetErrors",
             (bool (OpenGl_Context::*)(  const bool  ) ) static_cast<bool (OpenGl_Context::*)(  const bool  ) >(&OpenGl_Context::ResetErrors),
             R"#(Clean up errors stack for this GL context (glGetError() in loop).)#"  , py::arg("theToPrintErrors")=static_cast< const bool>(false)
          )
        .def("IsCurrent",
             (bool (OpenGl_Context::*)() const) static_cast<bool (OpenGl_Context::*)() const>(&OpenGl_Context::IsCurrent),
             R"#(This method uses system-dependent API to retrieve information about GL context bound to the current thread.)#" 
          )
        .def("MakeCurrent",
             (bool (OpenGl_Context::*)() ) static_cast<bool (OpenGl_Context::*)() >(&OpenGl_Context::MakeCurrent),
             R"#(Activates current context. Class should be initialized with appropriate info.)#" 
          )
        .def("SwapBuffers",
             (void (OpenGl_Context::*)() ) static_cast<void (OpenGl_Context::*)() >(&OpenGl_Context::SwapBuffers),
             R"#(Swap front/back buffers for this GL context (should be activated before!).)#" 
          )
        .def("SetSwapInterval",
             (bool (OpenGl_Context::*)(  const int  ) ) static_cast<bool (OpenGl_Context::*)(  const int  ) >(&OpenGl_Context::SetSwapInterval),
             R"#(Setup swap interval (VSync).)#"  , py::arg("theInterval")
          )
        .def("IsRender",
             (bool (OpenGl_Context::*)() const) static_cast<bool (OpenGl_Context::*)() const>(&OpenGl_Context::IsRender),
             R"#(Return true if active mode is GL_RENDER (cached state))#" 
          )
        .def("IsFeedback",
             (bool (OpenGl_Context::*)() const) static_cast<bool (OpenGl_Context::*)() const>(&OpenGl_Context::IsFeedback),
             R"#(Return true if active mode is GL_FEEDBACK (cached state))#" 
          )
        .def("AvailableMemory",
             (size_t (OpenGl_Context::*)() const) static_cast<size_t (OpenGl_Context::*)() const>(&OpenGl_Context::AvailableMemory),
             R"#(This function retrieves information from GL about free GPU memory that is: - OS-dependent. On some OS it is per-process and on others - for entire system. - Vendor-dependent. Currently available only on NVIDIA and AMD/ATi drivers only. - Numbers meaning may vary. You should use this info only for diagnostics purposes.)#" 
          )
        .def("MemoryInfo",
             (TCollection_AsciiString (OpenGl_Context::*)() const) static_cast<TCollection_AsciiString (OpenGl_Context::*)() const>(&OpenGl_Context::MemoryInfo),
             R"#(This function retrieves information from GL about GPU memory and contains more vendor-specific values than AvailableMemory().)#" 
          )
        .def("MemoryInfo",
             (void (OpenGl_Context::*)( NCollection_IndexedDataMap<TCollection_AsciiString, TCollection_AsciiString> &  ) const) static_cast<void (OpenGl_Context::*)( NCollection_IndexedDataMap<TCollection_AsciiString, TCollection_AsciiString> &  ) const>(&OpenGl_Context::MemoryInfo),
             R"#(This function retrieves information from GL about GPU memory.)#"  , py::arg("theDict")
          )
        .def("DiagnosticInformation",
             (void (OpenGl_Context::*)( NCollection_IndexedDataMap<TCollection_AsciiString, TCollection_AsciiString> & ,  Graphic3d_DiagnosticInfo  ) const) static_cast<void (OpenGl_Context::*)( NCollection_IndexedDataMap<TCollection_AsciiString, TCollection_AsciiString> & ,  Graphic3d_DiagnosticInfo  ) const>(&OpenGl_Context::DiagnosticInformation),
             R"#(Fill in the dictionary with OpenGL info. Should be called with bound context.)#"  , py::arg("theDict"),  py::arg("theFlags")
          )
        .def("WindowBufferBits",
             (void (OpenGl_Context::*)( NCollection_Vec4<int> & ,  NCollection_Vec2<int> &  ) const) static_cast<void (OpenGl_Context::*)( NCollection_Vec4<int> & ,  NCollection_Vec2<int> &  ) const>(&OpenGl_Context::WindowBufferBits),
             R"#(Fetches information about window buffer pixel format.)#"  , py::arg("theColorBits"),  py::arg("theDepthStencilBits")
          )
        .def("GetResource",
             ( const handle<OpenGl_Resource> & (OpenGl_Context::*)(  const TCollection_AsciiString &  ) const) static_cast< const handle<OpenGl_Resource> & (OpenGl_Context::*)(  const TCollection_AsciiString &  ) const>(&OpenGl_Context::GetResource),
             R"#(Access shared resource by its name.)#"  , py::arg("theKey")
          )
        .def("ShareResource",
             (bool (OpenGl_Context::*)(  const TCollection_AsciiString & ,   const handle<OpenGl_Resource> &  ) ) static_cast<bool (OpenGl_Context::*)(  const TCollection_AsciiString & ,   const handle<OpenGl_Resource> &  ) >(&OpenGl_Context::ShareResource),
             R"#(Register shared resource. Notice that after registration caller shouldn't release it by himself - it will be automatically released on context destruction.)#"  , py::arg("theKey"),  py::arg("theResource")
          )
        .def("ReleaseResource",
             (void (OpenGl_Context::*)(  const TCollection_AsciiString & ,   const bool  ) ) static_cast<void (OpenGl_Context::*)(  const TCollection_AsciiString & ,   const bool  ) >(&OpenGl_Context::ReleaseResource),
             R"#(Release shared resource. If there are more than one reference to this resource (also used by some other existing object) then call will be ignored. This means that current object itself should nullify handle before this call. Notice that this is unrecommended operation at all and should be used only in case of fat resources to release memory for other needs.)#"  , py::arg("theKey"),  py::arg("theToDelay")=static_cast< const bool>(false)
          )
        .def("ReleaseDelayed",
             (void (OpenGl_Context::*)() ) static_cast<void (OpenGl_Context::*)() >(&OpenGl_Context::ReleaseDelayed),
             R"#(Clean up the delayed release queue.)#" 
          )
        .def("TextureWrapClamp",
             (int (OpenGl_Context::*)() const) static_cast<int (OpenGl_Context::*)() const>(&OpenGl_Context::TextureWrapClamp),
             R"#(Either GL_CLAMP_TO_EDGE (1.2+) or GL_CLAMP (1.1).)#" 
          )
        .def("HasTextureBaseLevel",
             (bool (OpenGl_Context::*)() const) static_cast<bool (OpenGl_Context::*)() const>(&OpenGl_Context::HasTextureBaseLevel),
             R"#(Returns true if texture parameters GL_TEXTURE_BASE_LEVEL/GL_TEXTURE_MAX_LEVEL are supported.)#" 
          )
        .def("MaxDegreeOfAnisotropy",
             (int (OpenGl_Context::*)() const) static_cast<int (OpenGl_Context::*)() const>(&OpenGl_Context::MaxDegreeOfAnisotropy),
             R"#(Returns maximum degree of anisotropy texture filter)#" 
          )
        .def("MaxTextureSize",
             (int (OpenGl_Context::*)() const) static_cast<int (OpenGl_Context::*)() const>(&OpenGl_Context::MaxTextureSize),
             R"#(Returns value for GL_MAX_TEXTURE_SIZE)#" 
          )
        .def("MaxCombinedTextureUnits",
             (int (OpenGl_Context::*)() const) static_cast<int (OpenGl_Context::*)() const>(&OpenGl_Context::MaxCombinedTextureUnits),
             R"#(Returns value for GL_MAX_COMBINED_TEXTURE_IMAGE_UNITS)#" 
          )
        .def("MaxTextureUnitsFFP",
             (int (OpenGl_Context::*)() const) static_cast<int (OpenGl_Context::*)() const>(&OpenGl_Context::MaxTextureUnitsFFP),
             R"#(This method returns the multi-texture limit for obsolete fixed-function pipeline. Use MaxCombinedTextureUnits() instead for limits for using programmable pipeline.)#" 
          )
        .def("SpriteTextureUnit",
             (Graphic3d_TextureUnit (OpenGl_Context::*)() const) static_cast<Graphic3d_TextureUnit (OpenGl_Context::*)() const>(&OpenGl_Context::SpriteTextureUnit),
             R"#(Return texture unit to be used for sprites (Graphic3d_TextureUnit_PointSprite by default).)#" 
          )
        .def("HasTextureMultisampling",
             (bool (OpenGl_Context::*)() const) static_cast<bool (OpenGl_Context::*)() const>(&OpenGl_Context::HasTextureMultisampling),
             R"#(Returns true if MSAA textures are supported.)#" 
          )
        .def("MaxMsaaSamples",
             (int (OpenGl_Context::*)() const) static_cast<int (OpenGl_Context::*)() const>(&OpenGl_Context::MaxMsaaSamples),
             R"#(Returns value for GL_MAX_SAMPLES)#" 
          )
        .def("MaxDumpSizeX",
             (int (OpenGl_Context::*)() const) static_cast<int (OpenGl_Context::*)() const>(&OpenGl_Context::MaxDumpSizeX),
             R"#(Returns maximum FBO width for image dump)#" 
          )
        .def("MaxDumpSizeY",
             (int (OpenGl_Context::*)() const) static_cast<int (OpenGl_Context::*)() const>(&OpenGl_Context::MaxDumpSizeY),
             R"#(Returns maximum FBO height for image dump)#" 
          )
        .def("MaxDrawBuffers",
             (int (OpenGl_Context::*)() const) static_cast<int (OpenGl_Context::*)() const>(&OpenGl_Context::MaxDrawBuffers),
             R"#(Returns value for GL_MAX_DRAW_BUFFERS)#" 
          )
        .def("MaxColorAttachments",
             (int (OpenGl_Context::*)() const) static_cast<int (OpenGl_Context::*)() const>(&OpenGl_Context::MaxColorAttachments),
             R"#(Returns value for GL_MAX_COLOR_ATTACHMENTS)#" 
          )
        .def("MaxClipPlanes",
             (int (OpenGl_Context::*)() const) static_cast<int (OpenGl_Context::*)() const>(&OpenGl_Context::MaxClipPlanes),
             R"#(Get maximum number of clip planes supported by OpenGl. This value is implementation dependent. At least 6 planes should be supported by OpenGl (see specs).)#" 
          )
        .def("HasRayTracing",
             (bool (OpenGl_Context::*)() const) static_cast<bool (OpenGl_Context::*)() const>(&OpenGl_Context::HasRayTracing),
             R"#(Returns TRUE if ray tracing mode is supported)#" 
          )
        .def("HasRayTracingTextures",
             (bool (OpenGl_Context::*)() const) static_cast<bool (OpenGl_Context::*)() const>(&OpenGl_Context::HasRayTracingTextures),
             R"#(Returns TRUE if textures in ray tracing mode are supported)#" 
          )
        .def("HasRayTracingAdaptiveSampling",
             (bool (OpenGl_Context::*)() const) static_cast<bool (OpenGl_Context::*)() const>(&OpenGl_Context::HasRayTracingAdaptiveSampling),
             R"#(Returns TRUE if adaptive screen sampling in ray tracing mode is supported)#" 
          )
        .def("HasRayTracingAdaptiveSamplingAtomic",
             (bool (OpenGl_Context::*)() const) static_cast<bool (OpenGl_Context::*)() const>(&OpenGl_Context::HasRayTracingAdaptiveSamplingAtomic),
             R"#(Returns TRUE if atomic adaptive screen sampling in ray tracing mode is supported)#" 
          )
        .def("HasSRGB",
             (bool (OpenGl_Context::*)() const) static_cast<bool (OpenGl_Context::*)() const>(&OpenGl_Context::HasSRGB),
             R"#(Returns TRUE if sRGB rendering is supported.)#" 
          )
        .def("ToRenderSRGB",
             (bool (OpenGl_Context::*)() const) static_cast<bool (OpenGl_Context::*)() const>(&OpenGl_Context::ToRenderSRGB),
             R"#(Returns TRUE if sRGB rendering is supported and permitted.)#" 
          )
        .def("IsWindowSRGB",
             (bool (OpenGl_Context::*)() const) static_cast<bool (OpenGl_Context::*)() const>(&OpenGl_Context::IsWindowSRGB),
             R"#(Returns TRUE if window/surface buffer is sRGB-ready.)#" 
          )
        .def("SetWindowSRGB",
             (void (OpenGl_Context::*)( bool  ) ) static_cast<void (OpenGl_Context::*)( bool  ) >(&OpenGl_Context::SetWindowSRGB),
             R"#(Overrides if window/surface buffer is sRGB-ready or not (initialized with the context).)#"  , py::arg("theIsSRgb")
          )
        .def("IsWindowDeepColor",
             (bool (OpenGl_Context::*)() const) static_cast<bool (OpenGl_Context::*)() const>(&OpenGl_Context::IsWindowDeepColor),
             R"#(Returns TRUE if window/surface buffer has deep color (10bit per component / 30bit RGB) or better precision.)#" 
          )
        .def("Vec4FromQuantityColor",
             (NCollection_Vec4<float> (OpenGl_Context::*)(  const NCollection_Vec4<float> &  ) const) static_cast<NCollection_Vec4<float> (OpenGl_Context::*)(  const NCollection_Vec4<float> &  ) const>(&OpenGl_Context::Vec4FromQuantityColor),
             R"#(Convert Quantity_ColorRGBA into vec4 with conversion or no conversion into non-linear sRGB basing on ToRenderSRGB() flag.)#"  , py::arg("theColor")
          )
        .def("Vec4LinearFromQuantityColor",
             ( const NCollection_Vec4<float> & (OpenGl_Context::*)(  const NCollection_Vec4<float> &  ) const) static_cast< const NCollection_Vec4<float> & (OpenGl_Context::*)(  const NCollection_Vec4<float> &  ) const>(&OpenGl_Context::Vec4LinearFromQuantityColor),
             R"#(Convert Quantity_ColorRGBA into vec4. Quantity_Color is expected to be linear RGB, hence conversion is NOT required)#"  , py::arg("theColor")
          )
        .def("Vec4sRGBFromQuantityColor",
             (NCollection_Vec4<float> (OpenGl_Context::*)(  const NCollection_Vec4<float> &  ) const) static_cast<NCollection_Vec4<float> (OpenGl_Context::*)(  const NCollection_Vec4<float> &  ) const>(&OpenGl_Context::Vec4sRGBFromQuantityColor),
             R"#(Convert Quantity_ColorRGBA (linear RGB) into non-linear sRGB vec4.)#"  , py::arg("theColor")
          )
        .def("HasPBR",
             (bool (OpenGl_Context::*)() const) static_cast<bool (OpenGl_Context::*)() const>(&OpenGl_Context::HasPBR),
             R"#(Returns TRUE if PBR shading model is supported. Basically, feature requires OpenGL 3.0+ / OpenGL ES 3.0+ hardware; more precisely: - Graphics hardware with moderate capabilities for compiling long enough GLSL program. - FBO (e.g. for baking environment). - Multi-texturing with >= 4 units (LUT and IBL textures). - GL_RG32F texture format (arbTexRG + arbTexFloat) - Cubemap texture lookup textureCubeLod()/textureLod() with LOD index within Fragment Shader, which requires GLSL OpenGL 3.0+ / OpenGL ES 3.0+ or OpenGL 2.1 + GL_EXT_gpu_shader4 extension.)#" 
          )
        .def("PBREnvLUTTexUnit",
             (Graphic3d_TextureUnit (OpenGl_Context::*)() const) static_cast<Graphic3d_TextureUnit (OpenGl_Context::*)() const>(&OpenGl_Context::PBREnvLUTTexUnit),
             R"#(Returns texture unit where Environment Lookup Table is expected to be bound, or 0 if PBR is unavailable.)#" 
          )
        .def("PBRDiffIBLMapSHTexUnit",
             (Graphic3d_TextureUnit (OpenGl_Context::*)() const) static_cast<Graphic3d_TextureUnit (OpenGl_Context::*)() const>(&OpenGl_Context::PBRDiffIBLMapSHTexUnit),
             R"#(Returns texture unit where Diffuse (irradiance) IBL map's spherical harmonics coefficients is expected to be bound, or 0 if PBR is unavailable.)#" 
          )
        .def("PBRSpecIBLMapTexUnit",
             (Graphic3d_TextureUnit (OpenGl_Context::*)() const) static_cast<Graphic3d_TextureUnit (OpenGl_Context::*)() const>(&OpenGl_Context::PBRSpecIBLMapTexUnit),
             R"#(Returns texture unit where Specular IBL map is expected to be bound, or 0 if PBR is unavailable.)#" 
          )
        .def("ShadowMapTexUnit",
             (Graphic3d_TextureUnit (OpenGl_Context::*)() const) static_cast<Graphic3d_TextureUnit (OpenGl_Context::*)() const>(&OpenGl_Context::ShadowMapTexUnit),
             R"#(Returns texture unit where shadow map is expected to be bound, or 0 if unavailable.)#" 
          )
        .def("DepthPeelingDepthTexUnit",
             (Graphic3d_TextureUnit (OpenGl_Context::*)() const) static_cast<Graphic3d_TextureUnit (OpenGl_Context::*)() const>(&OpenGl_Context::DepthPeelingDepthTexUnit),
             R"#(Returns texture unit for occDepthPeelingDepth within enabled Depth Peeling.)#" 
          )
        .def("DepthPeelingFrontColorTexUnit",
             (Graphic3d_TextureUnit (OpenGl_Context::*)() const) static_cast<Graphic3d_TextureUnit (OpenGl_Context::*)() const>(&OpenGl_Context::DepthPeelingFrontColorTexUnit),
             R"#(Returns texture unit for occDepthPeelingFrontColor within enabled Depth Peeling.)#" 
          )
        .def("ToUseVbo",
             (bool (OpenGl_Context::*)() const) static_cast<bool (OpenGl_Context::*)() const>(&OpenGl_Context::ToUseVbo),
             R"#(Returns true if VBO is supported and permitted.)#" 
          )
        .def("IsGlNormalizeEnabled",
             (bool (OpenGl_Context::*)() const) static_cast<bool (OpenGl_Context::*)() const>(&OpenGl_Context::IsGlNormalizeEnabled),
             R"#(Returns cached state of GL_NORMALIZE.)#" 
          )
        .def("SetGlNormalizeEnabled",
             (bool (OpenGl_Context::*)( bool  ) ) static_cast<bool (OpenGl_Context::*)( bool  ) >(&OpenGl_Context::SetGlNormalizeEnabled),
             R"#(Sets GL_NORMALIZE enabled or disabled.)#"  , py::arg("isEnabled")
          )
        .def("PolygonMode",
             (int (OpenGl_Context::*)() const) static_cast<int (OpenGl_Context::*)() const>(&OpenGl_Context::PolygonMode),
             R"#(Returns cached state of polygon rasterization mode (glPolygonMode()).)#" 
          )
        .def("SetPolygonMode",
             (int (OpenGl_Context::*)(  const int  ) ) static_cast<int (OpenGl_Context::*)(  const int  ) >(&OpenGl_Context::SetPolygonMode),
             R"#(Sets polygon rasterization mode (glPolygonMode() function).)#"  , py::arg("theMode")
          )
        .def("IsPolygonHatchEnabled",
             (bool (OpenGl_Context::*)() const) static_cast<bool (OpenGl_Context::*)() const>(&OpenGl_Context::IsPolygonHatchEnabled),
             R"#(Returns cached enabled state of polygon hatching rasterization.)#" 
          )
        .def("SetPolygonHatchEnabled",
             (bool (OpenGl_Context::*)(  const bool  ) ) static_cast<bool (OpenGl_Context::*)(  const bool  ) >(&OpenGl_Context::SetPolygonHatchEnabled),
             R"#(Sets enabled state of polygon hatching rasterization without affecting currently selected hatching pattern.)#"  , py::arg("theIsEnabled")
          )
        .def("PolygonHatchStyle",
             (int (OpenGl_Context::*)() const) static_cast<int (OpenGl_Context::*)() const>(&OpenGl_Context::PolygonHatchStyle),
             R"#(Returns cached state of polygon hatch type.)#" 
          )
        .def("SetPolygonHatchStyle",
             (int (OpenGl_Context::*)(  const handle<Graphic3d_HatchStyle> &  ) ) static_cast<int (OpenGl_Context::*)(  const handle<Graphic3d_HatchStyle> &  ) >(&OpenGl_Context::SetPolygonHatchStyle),
             R"#(Sets polygon hatch pattern. Zero-index value is a default alias for solid filling.)#"  , py::arg("theStyle")
          )
        .def("SetPolygonOffset",
             (void (OpenGl_Context::*)(  const Graphic3d_PolygonOffset &  ) ) static_cast<void (OpenGl_Context::*)(  const Graphic3d_PolygonOffset &  ) >(&OpenGl_Context::SetPolygonOffset),
             R"#(Sets and applies current polygon offset.)#"  , py::arg("theOffset")
          )
        .def("SetCamera",
             (void (OpenGl_Context::*)(  const handle<Graphic3d_Camera> &  ) ) static_cast<void (OpenGl_Context::*)(  const handle<Graphic3d_Camera> &  ) >(&OpenGl_Context::SetCamera),
             R"#(Sets camera object to the context and update matrices.)#"  , py::arg("theCamera")
          )
        .def("ApplyModelWorldMatrix",
             (void (OpenGl_Context::*)() ) static_cast<void (OpenGl_Context::*)() >(&OpenGl_Context::ApplyModelWorldMatrix),
             R"#(Applies matrix into shader manager stored in ModelWorldState to OpenGl. In "model -> world -> view -> projection" it performs: model -> world)#" 
          )
        .def("ApplyWorldViewMatrix",
             (void (OpenGl_Context::*)() ) static_cast<void (OpenGl_Context::*)() >(&OpenGl_Context::ApplyWorldViewMatrix),
             R"#(Applies matrix stored in WorldViewState to OpenGl. In "model -> world -> view -> projection" it performs: model -> world -> view, where model -> world is identical matrix)#" 
          )
        .def("ApplyModelViewMatrix",
             (void (OpenGl_Context::*)() ) static_cast<void (OpenGl_Context::*)() >(&OpenGl_Context::ApplyModelViewMatrix),
             R"#(Applies combination of matrices stored in ModelWorldState and WorldViewState to OpenGl. In "model -> world -> view -> projection" it performs: model -> world -> view)#" 
          )
        .def("ApplyProjectionMatrix",
             (void (OpenGl_Context::*)() ) static_cast<void (OpenGl_Context::*)() >(&OpenGl_Context::ApplyProjectionMatrix),
             R"#(Applies matrix stored in ProjectionState to OpenGl. In "model -> world -> view -> projection" it performs: view -> projection)#" 
          )
        .def("PushMessage",
             (void (OpenGl_Context::*)(  const unsigned int ,   const unsigned int ,   const unsigned int ,   const unsigned int ,   const TCollection_ExtendedString &  ) ) static_cast<void (OpenGl_Context::*)(  const unsigned int ,   const unsigned int ,   const unsigned int ,   const unsigned int ,   const TCollection_ExtendedString &  ) >(&OpenGl_Context::PushMessage),
             R"#(Callback for GL_ARB_debug_output extension)#"  , py::arg("theSource"),  py::arg("theType"),  py::arg("theId"),  py::arg("theSeverity"),  py::arg("theMessage")
          )
        .def("ExcludeMessage",
             (bool (OpenGl_Context::*)(  const unsigned int ,   const unsigned int  ) ) static_cast<bool (OpenGl_Context::*)(  const unsigned int ,   const unsigned int  ) >(&OpenGl_Context::ExcludeMessage),
             R"#(Adds a filter for messages with theId and theSource (GL_DEBUG_SOURCE_))#"  , py::arg("theSource"),  py::arg("theId")
          )
        .def("IncludeMessage",
             (bool (OpenGl_Context::*)(  const unsigned int ,   const unsigned int  ) ) static_cast<bool (OpenGl_Context::*)(  const unsigned int ,   const unsigned int  ) >(&OpenGl_Context::IncludeMessage),
             R"#(Removes a filter for messages with theId and theSource (GL_DEBUG_SOURCE_))#"  , py::arg("theSource"),  py::arg("theId")
          )
        .def("HasStereoBuffers",
             (bool (OpenGl_Context::*)() const) static_cast<bool (OpenGl_Context::*)() const>(&OpenGl_Context::HasStereoBuffers),
             R"#(Returns true if OpenGl context supports left and right rendering buffers.)#" 
          )
        .def("SetFrameStats",
             (void (OpenGl_Context::*)(  const handle<OpenGl_FrameStats> &  ) ) static_cast<void (OpenGl_Context::*)(  const handle<OpenGl_FrameStats> &  ) >(&OpenGl_Context::SetFrameStats),
             R"#(Set structure holding frame statistics. This call makes sense only if application defines OpenGl_FrameStats sub-class.)#"  , py::arg("theStats")
          )
        .def("Viewport",
             ( const int * (OpenGl_Context::*)() const) static_cast< const int * (OpenGl_Context::*)() const>(&OpenGl_Context::Viewport),
             R"#(Return cached viewport definition (x, y, width, height).)#" 
          )
        .def("ResizeViewport",
             (void (OpenGl_Context::*)( const int[4]  ) ) static_cast<void (OpenGl_Context::*)( const int[4]  ) >(&OpenGl_Context::ResizeViewport),
             R"#(Resize the viewport (alias for glViewport).)#"  , py::arg("theRect")
          )
        .def("VirtualViewport",
             ( const int * (OpenGl_Context::*)() const) static_cast< const int * (OpenGl_Context::*)() const>(&OpenGl_Context::VirtualViewport),
             R"#(Return virtual viewport definition (x, y, width, height).)#" 
          )
        .def("ReadBuffer",
             (int (OpenGl_Context::*)() ) static_cast<int (OpenGl_Context::*)() >(&OpenGl_Context::ReadBuffer),
             R"#(Return active read buffer.)#" 
          )
        .def("SetReadBuffer",
             (void (OpenGl_Context::*)(  const int  ) ) static_cast<void (OpenGl_Context::*)(  const int  ) >(&OpenGl_Context::SetReadBuffer),
             R"#(Switch read buffer, wrapper for ::glReadBuffer().)#"  , py::arg("theReadBuffer")
          )
        .def("DrawBuffer",
             (int (OpenGl_Context::*)( int  ) const) static_cast<int (OpenGl_Context::*)( int  ) const>(&OpenGl_Context::DrawBuffer),
             R"#(Return active draw buffer attached to a render target referred by index (layout location).)#"  , py::arg("theIndex")=static_cast<int>(0)
          )
        .def("SetDrawBuffer",
             (void (OpenGl_Context::*)(  const int  ) ) static_cast<void (OpenGl_Context::*)(  const int  ) >(&OpenGl_Context::SetDrawBuffer),
             R"#(Switch draw buffer, wrapper for ::glDrawBuffer().)#"  , py::arg("theDrawBuffer")
          )
        .def("SetDrawBuffers",
             (void (OpenGl_Context::*)(  const int ,   const int *  ) ) static_cast<void (OpenGl_Context::*)(  const int ,   const int *  ) >(&OpenGl_Context::SetDrawBuffers),
             R"#(Switch draw buffer, wrapper for ::glDrawBuffers (GLsizei, const GLenum*).)#"  , py::arg("theNb"),  py::arg("theDrawBuffers")
          )
        .def("SetReadDrawBuffer",
             (void (OpenGl_Context::*)(  const int  ) ) static_cast<void (OpenGl_Context::*)(  const int  ) >(&OpenGl_Context::SetReadDrawBuffer),
             R"#(Switch read/draw buffers.)#"  , py::arg("theBuffer")
          )
        .def("IsFrameBufferSRGB",
             (bool (OpenGl_Context::*)() const) static_cast<bool (OpenGl_Context::*)() const>(&OpenGl_Context::IsFrameBufferSRGB),
             R"#(Returns cached GL_FRAMEBUFFER_SRGB state. If TRUE, GLSL program is expected to write linear RGB color. Otherwise, GLSL program might need manually converting result color into sRGB color space.)#" 
          )
        .def("SetFrameBufferSRGB",
             (void (OpenGl_Context::*)( bool ,  bool  ) ) static_cast<void (OpenGl_Context::*)( bool ,  bool  ) >(&OpenGl_Context::SetFrameBufferSRGB),
             R"#(Enables/disables GL_FRAMEBUFFER_SRGB flag. This flag can be set to: - TRUE when writing into offscreen FBO (always expected to be in sRGB or RGBF formats). - TRUE when writing into sRGB-ready window buffer (might require choosing proper pixel format on window creation). - FALSE if sRGB rendering is not supported or sRGB-not-ready window buffer is used for drawing.)#"  , py::arg("theIsFbo"),  py::arg("theIsFboSRgb")=static_cast<bool>(true)
          )
        .def("SetColorMaskRGBA",
             (void (OpenGl_Context::*)(  const NCollection_Vec4<bool> &  ) ) static_cast<void (OpenGl_Context::*)(  const NCollection_Vec4<bool> &  ) >(&OpenGl_Context::SetColorMaskRGBA),
             R"#(Enable/disable writing into color buffer (wrapper for glColorMask).)#"  , py::arg("theToWriteColor")
          )
        .def("ColorMask",
             (bool (OpenGl_Context::*)() const) static_cast<bool (OpenGl_Context::*)() const>(&OpenGl_Context::ColorMask),
             R"#(Return cached flag indicating writing into color buffer is enabled or disabled (glColorMask).)#" 
          )
        .def("SetColorMask",
             (bool (OpenGl_Context::*)( bool  ) ) static_cast<bool (OpenGl_Context::*)( bool  ) >(&OpenGl_Context::SetColorMask),
             R"#(Enable/disable writing into color buffer (wrapper for glColorMask). Alpha component writes will be disabled unconditionally in case of caps->buffersOpaqueAlpha.)#"  , py::arg("theToWriteColor")
          )
        .def("AllowSampleAlphaToCoverage",
             (bool (OpenGl_Context::*)() const) static_cast<bool (OpenGl_Context::*)() const>(&OpenGl_Context::AllowSampleAlphaToCoverage),
             R"#(Return TRUE if GL_SAMPLE_ALPHA_TO_COVERAGE usage is allowed.)#" 
          )
        .def("SetAllowSampleAlphaToCoverage",
             (void (OpenGl_Context::*)( bool  ) ) static_cast<void (OpenGl_Context::*)( bool  ) >(&OpenGl_Context::SetAllowSampleAlphaToCoverage),
             R"#(Allow GL_SAMPLE_ALPHA_TO_COVERAGE usage.)#"  , py::arg("theToEnable")
          )
        .def("SampleAlphaToCoverage",
             (bool (OpenGl_Context::*)() const) static_cast<bool (OpenGl_Context::*)() const>(&OpenGl_Context::SampleAlphaToCoverage),
             R"#(Return GL_SAMPLE_ALPHA_TO_COVERAGE state.)#" 
          )
        .def("SetSampleAlphaToCoverage",
             (bool (OpenGl_Context::*)( bool  ) ) static_cast<bool (OpenGl_Context::*)( bool  ) >(&OpenGl_Context::SetSampleAlphaToCoverage),
             R"#(Enable/disable GL_SAMPLE_ALPHA_TO_COVERAGE.)#"  , py::arg("theToEnable")
          )
        .def("FaceCulling",
             (Graphic3d_TypeOfBackfacingModel (OpenGl_Context::*)() const) static_cast<Graphic3d_TypeOfBackfacingModel (OpenGl_Context::*)() const>(&OpenGl_Context::FaceCulling),
             R"#(Return back face culling state.)#" 
          )
        .def("SetFaceCulling",
             (void (OpenGl_Context::*)( Graphic3d_TypeOfBackfacingModel  ) ) static_cast<void (OpenGl_Context::*)( Graphic3d_TypeOfBackfacingModel  ) >(&OpenGl_Context::SetFaceCulling),
             R"#(Enable or disable back face culling (glEnable (GL_CULL_FACE)).)#"  , py::arg("theMode")
          )
        .def("ToCullBackFaces",
             (bool (OpenGl_Context::*)() const) static_cast<bool (OpenGl_Context::*)() const>(&OpenGl_Context::ToCullBackFaces),
             R"#(Return back face culling state.)#" 
          )
        .def("SetCullBackFaces",
             (void (OpenGl_Context::*)( bool  ) ) static_cast<void (OpenGl_Context::*)( bool  ) >(&OpenGl_Context::SetCullBackFaces),
             R"#(Enable or disable back face culling (glCullFace() + glEnable(GL_CULL_FACE)).)#"  , py::arg("theToEnable")
          )
        .def("FetchState",
             (void (OpenGl_Context::*)() ) static_cast<void (OpenGl_Context::*)() >(&OpenGl_Context::FetchState),
             R"#(Fetch OpenGl context state. This class tracks value of several OpenGl state variables. Consulting the cached values is quicker than doing the same via OpenGl API. Call this method if any of the controlled OpenGl state variables has a possibility of being out-of-date.)#" 
          )
        .def("BindTextures",
             (handle<OpenGl_TextureSet> (OpenGl_Context::*)(  const handle<OpenGl_TextureSet> &  ) ) static_cast<handle<OpenGl_TextureSet> (OpenGl_Context::*)(  const handle<OpenGl_TextureSet> &  ) >(&OpenGl_Context::BindTextures),
             R"#(Bind specified texture set to current context taking into account active GLSL program.)#"  , py::arg("theTextures")
          )
        .def("BindTextures",
             (handle<OpenGl_TextureSet> (OpenGl_Context::*)(  const handle<OpenGl_TextureSet> & ,   const handle<OpenGl_ShaderProgram> &  ) ) static_cast<handle<OpenGl_TextureSet> (OpenGl_Context::*)(  const handle<OpenGl_TextureSet> & ,   const handle<OpenGl_ShaderProgram> &  ) >(&OpenGl_Context::BindTextures),
             R"#(Bind specified texture set to current context, or unbind previous one when NULL specified.)#"  , py::arg("theTextures"),  py::arg("theProgram")
          )
        .def("BindProgram",
             (bool (OpenGl_Context::*)(  const handle<OpenGl_ShaderProgram> &  ) ) static_cast<bool (OpenGl_Context::*)(  const handle<OpenGl_ShaderProgram> &  ) >(&OpenGl_Context::BindProgram),
             R"#(Bind specified program to current context, or unbind previous one when NULL specified.)#"  , py::arg("theProgram")
          )
        .def("SetShadingMaterial",
             (void (OpenGl_Context::*)(  const OpenGl_Aspects * ,   const handle<Graphic3d_PresentationAttributes> &  ) ) static_cast<void (OpenGl_Context::*)(  const OpenGl_Aspects * ,   const handle<Graphic3d_PresentationAttributes> &  ) >(&OpenGl_Context::SetShadingMaterial),
             R"#(Setup current shading material.)#"  , py::arg("theAspect"),  py::arg("theHighlight")
          )
        .def("SetColor4fv",
             (void (OpenGl_Context::*)(  const NCollection_Vec4<float> &  ) ) static_cast<void (OpenGl_Context::*)(  const NCollection_Vec4<float> &  ) >(&OpenGl_Context::SetColor4fv),
             R"#(Setup current color.)#"  , py::arg("theColor")
          )
        .def("SetColor4fv",
             (void (OpenGl_Context::*)(  const NCollection_Vec4<float> & ,   const NCollection_Vec4<float> &  ) ) static_cast<void (OpenGl_Context::*)(  const NCollection_Vec4<float> & ,   const NCollection_Vec4<float> &  ) >(&OpenGl_Context::SetColor4fv),
             R"#(Setup current front and back colors.)#"  , py::arg("theFrontColor"),  py::arg("theBackColor")
          )
        .def("SetTypeOfLine",
             (void (OpenGl_Context::*)(  const Aspect_TypeOfLine ,   const float  ) ) static_cast<void (OpenGl_Context::*)(  const Aspect_TypeOfLine ,   const float  ) >(&OpenGl_Context::SetTypeOfLine),
             R"#(Setup type of line.)#"  , py::arg("theType"),  py::arg("theFactor")=static_cast< const float>(1.0f)
          )
        .def("SetLineStipple",
             (void (OpenGl_Context::*)(  const uint16_t  ) ) static_cast<void (OpenGl_Context::*)(  const uint16_t  ) >(&OpenGl_Context::SetLineStipple),
             R"#(Setup stipple line pattern with 1.0f factor; wrapper for glLineStipple().)#"  , py::arg("thePattern")
          )
        .def("SetLineStipple",
             (void (OpenGl_Context::*)(  const float ,   const uint16_t  ) ) static_cast<void (OpenGl_Context::*)(  const float ,   const uint16_t  ) >(&OpenGl_Context::SetLineStipple),
             R"#(Setup type of line; wrapper for glLineStipple().)#"  , py::arg("theFactor"),  py::arg("thePattern")
          )
        .def("SetLineWidth",
             (void (OpenGl_Context::*)(  const float  ) ) static_cast<void (OpenGl_Context::*)(  const float  ) >(&OpenGl_Context::SetLineWidth),
             R"#(Setup width of line.)#"  , py::arg("theWidth")
          )
        .def("SetPointSize",
             (void (OpenGl_Context::*)(  const float  ) ) static_cast<void (OpenGl_Context::*)(  const float  ) >(&OpenGl_Context::SetPointSize),
             R"#(Setup point size.)#"  , py::arg("theSize")
          )
        .def("SetPointSpriteOrigin",
             (void (OpenGl_Context::*)() ) static_cast<void (OpenGl_Context::*)() >(&OpenGl_Context::SetPointSpriteOrigin),
             R"#(Setup point sprite origin using GL_POINT_SPRITE_COORD_ORIGIN state: - GL_UPPER_LEFT when GLSL program is active; flipping should be handled in GLSL program for compatibility with OpenGL ES - GL_LOWER_LEFT for FFP)#" 
          )
        .def("SetTextureMatrix",
             (void (OpenGl_Context::*)(  const handle<Graphic3d_TextureParams> & ,   const bool  ) ) static_cast<void (OpenGl_Context::*)(  const handle<Graphic3d_TextureParams> & ,   const bool  ) >(&OpenGl_Context::SetTextureMatrix),
             R"#(Setup texture matrix to active GLSL program or to FFP global state using glMatrixMode (GL_TEXTURE).)#"  , py::arg("theParams"),  py::arg("theIsTopDown")
          )
        .def("BindDefaultVao",
             (void (OpenGl_Context::*)() ) static_cast<void (OpenGl_Context::*)() >(&OpenGl_Context::BindDefaultVao),
             R"#(Bind default Vertex Array Object)#" 
          )
        .def("SetDefaultFrameBuffer",
             (handle<OpenGl_FrameBuffer> (OpenGl_Context::*)(  const handle<OpenGl_FrameBuffer> &  ) ) static_cast<handle<OpenGl_FrameBuffer> (OpenGl_Context::*)(  const handle<OpenGl_FrameBuffer> &  ) >(&OpenGl_Context::SetDefaultFrameBuffer),
             R"#(Setup new Default Frame Buffer Object and return previously set. This call doesn't change Active FBO!)#"  , py::arg("theFbo")
          )
        .def("IsDebugContext",
             (bool (OpenGl_Context::*)() const) static_cast<bool (OpenGl_Context::*)() const>(&OpenGl_Context::IsDebugContext),
             R"#(Return debug context initialization state.)#" 
          )
        .def("EnableFeatures",
             (void (OpenGl_Context::*)() const) static_cast<void (OpenGl_Context::*)() const>(&OpenGl_Context::EnableFeatures),
             R"#()#" 
          )
        .def("DisableFeatures",
             (void (OpenGl_Context::*)() const) static_cast<void (OpenGl_Context::*)() const>(&OpenGl_Context::DisableFeatures),
             R"#()#" 
          )
        .def("Resolution",
             (unsigned int (OpenGl_Context::*)() const) static_cast<unsigned int (OpenGl_Context::*)() const>(&OpenGl_Context::Resolution),
             R"#(Return resolution for rendering text.)#" 
          )
        .def("ResolutionRatio",
             (float (OpenGl_Context::*)() const) static_cast<float (OpenGl_Context::*)() const>(&OpenGl_Context::ResolutionRatio),
             R"#(Resolution scale factor (rendered resolution to standard resolution). This scaling factor for parameters like text size to be properly displayed on device (screen / printer).)#" 
          )
        .def("RenderScale",
             (float (OpenGl_Context::*)() const) static_cast<float (OpenGl_Context::*)() const>(&OpenGl_Context::RenderScale),
             R"#(Rendering scale factor (rendering viewport height to real window buffer height).)#" 
          )
        .def("HasRenderScale",
             (bool (OpenGl_Context::*)() const) static_cast<bool (OpenGl_Context::*)() const>(&OpenGl_Context::HasRenderScale),
             R"#(Return TRUE if rendering scale factor is not 1.)#" 
          )
        .def("RenderScaleInv",
             (float (OpenGl_Context::*)() const) static_cast<float (OpenGl_Context::*)() const>(&OpenGl_Context::RenderScaleInv),
             R"#(Rendering scale factor (inverted value).)#" 
          )
        .def("LineWidthScale",
             (float (OpenGl_Context::*)() const) static_cast<float (OpenGl_Context::*)() const>(&OpenGl_Context::LineWidthScale),
             R"#(Return scale factor for line width.)#" 
          )
        .def("SetResolution",
             (void (OpenGl_Context::*)( unsigned int ,  float ,  float  ) ) static_cast<void (OpenGl_Context::*)( unsigned int ,  float ,  float  ) >(&OpenGl_Context::SetResolution),
             R"#(Set resolution ratio. Note that this method rounds to nearest integer.)#"  , py::arg("theResolution"),  py::arg("theRatio"),  py::arg("theScale")
          )
        .def("SetResolutionRatio",
             (void (OpenGl_Context::*)(  const float  ) ) static_cast<void (OpenGl_Context::*)(  const float  ) >(&OpenGl_Context::SetResolutionRatio),
             R"#(Set resolution ratio. Note that this method rounds to nearest integer.)#"  , py::arg("theRatio")
          )
        .def("LineFeather",
             (float (OpenGl_Context::*)() const) static_cast<float (OpenGl_Context::*)() const>(&OpenGl_Context::LineFeather),
             R"#(Return line feater width in pixels.)#" 
          )
        .def("SetLineFeather",
             (void (OpenGl_Context::*)( float  ) ) static_cast<void (OpenGl_Context::*)( float  ) >(&OpenGl_Context::SetLineFeather),
             R"#(Set line feater width.)#"  , py::arg("theValue")
          )
        .def("GetBufferSubData",
             (bool (OpenGl_Context::*)( unsigned int ,  intptr_t ,  intptr_t ,  void *  ) ) static_cast<bool (OpenGl_Context::*)( unsigned int ,  intptr_t ,  intptr_t ,  void *  ) >(&OpenGl_Context::GetBufferSubData),
             R"#(Wrapper over glGetBufferSubData(), implemented as: - OpenGL 1.5+ (desktop) via glGetBufferSubData(); - OpenGL ES 3.0+ via glMapBufferRange(); - WebGL 2.0+ via gl.getBufferSubData().)#"  , py::arg("theTarget"),  py::arg("theOffset"),  py::arg("theSize"),  py::arg("theData")
          )
        .def("DumpJson",
             (void (OpenGl_Context::*)( Standard_OStream & ,  int  ) const) static_cast<void (OpenGl_Context::*)( Standard_OStream & ,  int  ) const>(&OpenGl_Context::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
        .def("DumpJsonOpenGlState",
             (void (OpenGl_Context::*)( Standard_OStream & ,  int  ) ) static_cast<void (OpenGl_Context::*)( Standard_OStream & ,  int  ) >(&OpenGl_Context::DumpJsonOpenGlState),
             R"#(Dumps the content of openGL state into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
        .def("SetShadeModel",
             (void (OpenGl_Context::*)( Graphic3d_TypeOfShadingModel  ) ) static_cast<void (OpenGl_Context::*)( Graphic3d_TypeOfShadingModel  ) >(&OpenGl_Context::SetShadeModel),
             R"#(Set GL_SHADE_MODEL value.)#"  , py::arg("theModel")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_Context::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_Context::get_type_descriptor),
                    R"#()#" 
          )
        .def_static("GetPowerOfTwo_s",
                    (int (*)(  const int ,   const int  ) ) static_cast<int (*)(  const int ,   const int  ) >(&OpenGl_Context::GetPowerOfTwo),
                    R"#(Function for getting power of to number larger or equal to input number.)#"  , py::arg("theNumber"),  py::arg("theThreshold")
          )
        .def_static("FormatGlEnumHex_s",
                    (TCollection_AsciiString (*)( int  ) ) static_cast<TCollection_AsciiString (*)( int  ) >(&OpenGl_Context::FormatGlEnumHex),
                    R"#(Format GL constant as hex value 0xABCD.)#"  , py::arg("theGlEnum")
          )
        .def_static("FormatPointer_s",
                    (TCollection_AsciiString (*)(  const void *  ) ) static_cast<TCollection_AsciiString (*)(  const void *  ) >(&OpenGl_Context::FormatPointer),
                    R"#(Format pointer as hex value 0xABCD.)#"  , py::arg("thePtr")
          )
        .def_static("FormatSize_s",
                    (TCollection_AsciiString (*)( size_t  ) ) static_cast<TCollection_AsciiString (*)( size_t  ) >(&OpenGl_Context::FormatSize),
                    R"#(Format size value.)#"  , py::arg("theSize")
          )
        .def_static("FormatGlError_s",
                    (TCollection_AsciiString (*)( int  ) ) static_cast<TCollection_AsciiString (*)( int  ) >(&OpenGl_Context::FormatGlError),
                    R"#(Return text description of GL error.)#"  , py::arg("theGlError")
          )
        .def_static("CheckExtension_s",
                    (bool (*)(  const char * ,   const char *  ) ) static_cast<bool (*)(  const char * ,   const char *  ) >(&OpenGl_Context::CheckExtension),
                    R"#(Check if theExtName extension is in extensions string.)#"  , py::arg("theExtString"),  py::arg("theExtName")
          )
        .def_static("CheckIsTransparent_s",
                    (bool (*)(  const OpenGl_Aspects * ,   const handle<Graphic3d_PresentationAttributes> & ,  float & ,  float &  ) ) static_cast<bool (*)(  const OpenGl_Aspects * ,   const handle<Graphic3d_PresentationAttributes> & ,  float & ,  float &  ) >(&OpenGl_Context::CheckIsTransparent),
                    R"#(Checks if transparency is required for the given aspect and highlight style.)#"  , py::arg("theAspect"),  py::arg("theHighlight"),  py::arg("theAlphaFront"),  py::arg("theAlphaBack")
          )
        .def_static("CheckIsTransparent_s",
                    (bool (*)(  const OpenGl_Aspects * ,   const handle<Graphic3d_PresentationAttributes> &  ) ) static_cast<bool (*)(  const OpenGl_Aspects * ,   const handle<Graphic3d_PresentationAttributes> &  ) >(&OpenGl_Context::CheckIsTransparent),
                    R"#(Checks if transparency is required for the given aspect and highlight style.)#"  , py::arg("theAspect"),  py::arg("theHighlight")
          )
    // static methods using call by reference i.s.o. return
        .def_static("ReadGlVersion_s",
            []( ){
                int  theGlVerMajor;
                int  theGlVerMinor;

                OpenGl_Context::ReadGlVersion(theGlVerMajor,theGlVerMinor);
                
return std::make_tuple(theGlVerMajor,theGlVerMinor); },
            R"#(Read OpenGL version information from active context.)#" 
          )
    // operators
    // additional methods and static methods
    // properties
        .def_readwrite("hasGetBufferData", &OpenGl_Context::hasGetBufferData)
        .def_readwrite("hasPackRowLength", &OpenGl_Context::hasPackRowLength)
        .def_readwrite("hasUnpackRowLength", &OpenGl_Context::hasUnpackRowLength)
        .def_readwrite("hasHighp", &OpenGl_Context::hasHighp)
        .def_readwrite("hasUintIndex", &OpenGl_Context::hasUintIndex)
        .def_readwrite("hasTexRGBA8", &OpenGl_Context::hasTexRGBA8)
        .def_readwrite("hasTexFloatLinear", &OpenGl_Context::hasTexFloatLinear)
        .def_readwrite("hasTexSRGB", &OpenGl_Context::hasTexSRGB)
        .def_readwrite("hasFboSRGB", &OpenGl_Context::hasFboSRGB)
        .def_readwrite("hasSRGBControl", &OpenGl_Context::hasSRGBControl)
        .def_readwrite("hasFboRenderMipmap", &OpenGl_Context::hasFboRenderMipmap)
        .def_readwrite("hasFlatShading", &OpenGl_Context::hasFlatShading)
        .def_readwrite("hasGlslBitwiseOps", &OpenGl_Context::hasGlslBitwiseOps)
        .def_readwrite("hasDrawBuffers", &OpenGl_Context::hasDrawBuffers)
        .def_readwrite("hasFloatBuffer", &OpenGl_Context::hasFloatBuffer)
        .def_readwrite("hasHalfFloatBuffer", &OpenGl_Context::hasHalfFloatBuffer)
        .def_readwrite("hasSampleVariables", &OpenGl_Context::hasSampleVariables)
        .def_readwrite("hasGeometryStage", &OpenGl_Context::hasGeometryStage)
        .def_readwrite("arbDrawBuffers", &OpenGl_Context::arbDrawBuffers)
        .def_readwrite("arbNPTW", &OpenGl_Context::arbNPTW)
        .def_readwrite("arbTexRG", &OpenGl_Context::arbTexRG)
        .def_readwrite("arbTexFloat", &OpenGl_Context::arbTexFloat)
        .def_readwrite("arbTboRGB32", &OpenGl_Context::arbTboRGB32)
        .def_readwrite("arbClipControl", &OpenGl_Context::arbClipControl)
        .def_readwrite("arbSampleShading", &OpenGl_Context::arbSampleShading)
        .def_readwrite("arbDepthClamp", &OpenGl_Context::arbDepthClamp)
        .def_readwrite("extFragDepth", &OpenGl_Context::extFragDepth)
        .def_readwrite("extDrawBuffers", &OpenGl_Context::extDrawBuffers)
        .def_readwrite("extBgra", &OpenGl_Context::extBgra)
        .def_readwrite("extTexR16", &OpenGl_Context::extTexR16)
        .def_readwrite("extAnis", &OpenGl_Context::extAnis)
        .def_readwrite("extPDS", &OpenGl_Context::extPDS)
        .def_readwrite("atiMem", &OpenGl_Context::atiMem)
        .def_readwrite("nvxMem", &OpenGl_Context::nvxMem)
        .def_readwrite("oesSampleVariables", &OpenGl_Context::oesSampleVariables)
        .def_readwrite("oesStdDerivatives", &OpenGl_Context::oesStdDerivatives)
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_Context::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_Context::*)() const>(&OpenGl_Context::DynamicType),
             R"#()#"
             
         )
       .def("SharedResources",
             ( const typename OpenGl_Context::OpenGl_ResourcesMap & (OpenGl_Context::*)() const) static_cast< const typename OpenGl_Context::OpenGl_ResourcesMap & (OpenGl_Context::*)() const>(&OpenGl_Context::SharedResources),
             R"#(Return map of shared resources.)#"
             
         )
       .def("ChangeClipping",
             (OpenGl_Clipping & (OpenGl_Context::*)() ) static_cast<OpenGl_Clipping & (OpenGl_Context::*)() >(&OpenGl_Context::ChangeClipping),
             R"#(Returns tool for management of clippings within this context.)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Clipping",
             ( const OpenGl_Clipping & (OpenGl_Context::*)() const) static_cast< const OpenGl_Clipping & (OpenGl_Context::*)() const>(&OpenGl_Context::Clipping),
             R"#(Returns tool for management of clippings within this context.)#"
             
         )
       .def("ShaderManager",
             ( const handle<OpenGl_ShaderManager> & (OpenGl_Context::*)() const) static_cast< const handle<OpenGl_ShaderManager> & (OpenGl_Context::*)() const>(&OpenGl_Context::ShaderManager),
             R"#(Returns tool for management of shader programs within this context.)#"
             
         )
       .def("SupportedTextureFormats",
             ( const handle<Image_SupportedFormats> & (OpenGl_Context::*)() const) static_cast< const handle<Image_SupportedFormats> & (OpenGl_Context::*)() const>(&OpenGl_Context::SupportedTextureFormats),
             R"#(Return map of supported texture formats.)#"
             
         )
       .def("PolygonOffset",
             ( const Graphic3d_PolygonOffset & (OpenGl_Context::*)() const) static_cast< const Graphic3d_PolygonOffset & (OpenGl_Context::*)() const>(&OpenGl_Context::PolygonOffset),
             R"#(Returns currently applied polygon offset parameters.)#"
             
         )
       .def("Camera",
             ( const handle<Graphic3d_Camera> & (OpenGl_Context::*)() const) static_cast< const handle<Graphic3d_Camera> & (OpenGl_Context::*)() const>(&OpenGl_Context::Camera),
             R"#(Returns camera object.)#"
             
         )
       .def("Messenger",
             ( const handle<Message_Messenger> & (OpenGl_Context::*)() const) static_cast< const handle<Message_Messenger> & (OpenGl_Context::*)() const>(&OpenGl_Context::Messenger),
             R"#(Returns messenger instance)#"
             
         )
       .def("FrameStats",
             ( const handle<OpenGl_FrameStats> & (OpenGl_Context::*)() const) static_cast< const handle<OpenGl_FrameStats> & (OpenGl_Context::*)() const>(&OpenGl_Context::FrameStats),
             R"#(Return structure holding frame statistics.)#"
             
         )
       .def("ColorMaskRGBA",
             ( const NCollection_Vec4<bool> & (OpenGl_Context::*)() const) static_cast< const NCollection_Vec4<bool> & (OpenGl_Context::*)() const>(&OpenGl_Context::ColorMaskRGBA),
             R"#(Return cached flag indicating writing into color buffer is enabled or disabled (glColorMask).)#"
             
         )
       .def("ActiveTextures",
             ( const handle<OpenGl_TextureSet> & (OpenGl_Context::*)() const) static_cast< const handle<OpenGl_TextureSet> & (OpenGl_Context::*)() const>(&OpenGl_Context::ActiveTextures),
             R"#(Returns active textures)#"
             
         )
       .def("ActiveProgram",
             ( const handle<OpenGl_ShaderProgram> & (OpenGl_Context::*)() const) static_cast< const handle<OpenGl_ShaderProgram> & (OpenGl_Context::*)() const>(&OpenGl_Context::ActiveProgram),
             R"#(Returns active GLSL program)#"
             
         )
       .def("DefaultFrameBuffer",
             ( const handle<OpenGl_FrameBuffer> & (OpenGl_Context::*)() const) static_cast< const handle<OpenGl_FrameBuffer> & (OpenGl_Context::*)() const>(&OpenGl_Context::DefaultFrameBuffer),
             R"#(Default Frame Buffer Object.)#"
             
         )
       .def("Vendor",
             ( const TCollection_AsciiString & (OpenGl_Context::*)() const) static_cast< const TCollection_AsciiString & (OpenGl_Context::*)() const>(&OpenGl_Context::Vendor),
             R"#(Return Graphics Driver's vendor.)#"
             
         )
;

    // Class OpenGl_Element from ./opencascade/OpenGl_Element.hxx
    klass = m.attr("OpenGl_Element");


    // nested enums

    static_cast<py::class_<OpenGl_Element , shared_ptr_nodelete<OpenGl_Element> ,Py_OpenGl_Element >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Render",
             (void (OpenGl_Element::*)(  const handle<OpenGl_Workspace> &  ) const) static_cast<void (OpenGl_Element::*)(  const handle<OpenGl_Workspace> &  ) const>(&OpenGl_Element::Render),
             R"#()#"  , py::arg("theWorkspace")
          )
        .def("Release",
             (void (OpenGl_Element::*)( OpenGl_Context *  ) ) static_cast<void (OpenGl_Element::*)( OpenGl_Context *  ) >(&OpenGl_Element::Release),
             R"#(Release GPU resources. Pointer to the context is used because this method might be called when the context is already being destroyed and usage of a handle would be unsafe)#"  , py::arg("theContext")
          )
        .def("IsFillDrawMode",
             (bool (OpenGl_Element::*)() const) static_cast<bool (OpenGl_Element::*)() const>(&OpenGl_Element::IsFillDrawMode),
             R"#(Return TRUE if primitive type generates shaded triangulation (to be used in filters).)#" 
          )
        .def("EstimatedDataSize",
             (size_t (OpenGl_Element::*)() const) static_cast<size_t (OpenGl_Element::*)() const>(&OpenGl_Element::EstimatedDataSize),
             R"#(Returns estimated GPU memory usage for holding data without considering overheads and allocation alignment rules.)#" 
          )
        .def("UpdateMemStats",
             (void (OpenGl_Element::*)( Graphic3d_FrameStatsDataTmp &  ) const) static_cast<void (OpenGl_Element::*)( Graphic3d_FrameStatsDataTmp &  ) const>(&OpenGl_Element::UpdateMemStats),
             R"#(Increment memory usage statistics. Default implementation puts EstimatedDataSize() into Graphic3d_FrameStatsCounter_EstimatedBytesGeom.)#"  , py::arg("theStats")
          )
        .def("UpdateDrawStats",
             (void (OpenGl_Element::*)( Graphic3d_FrameStatsDataTmp & ,  bool  ) const) static_cast<void (OpenGl_Element::*)( Graphic3d_FrameStatsDataTmp & ,  bool  ) const>(&OpenGl_Element::UpdateDrawStats),
             R"#(Increment draw calls statistics.)#"  , py::arg("theStats"),  py::arg("theIsDetailed")
          )
        .def("SynchronizeAspects",
             (void (OpenGl_Element::*)() ) static_cast<void (OpenGl_Element::*)() >(&OpenGl_Element::SynchronizeAspects),
             R"#(Update parameters of the drawable elements.)#" 
          )
        .def("DumpJson",
             (void (OpenGl_Element::*)( Standard_OStream & ,  int  ) const) static_cast<void (OpenGl_Element::*)( Standard_OStream & ,  int  ) const>(&OpenGl_Element::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_ElementNode from ./opencascade/OpenGl_Group.hxx
    klass = m.attr("OpenGl_ElementNode");

    // default constructor
    register_default_constructor<OpenGl_ElementNode , shared_ptr<OpenGl_ElementNode>>(m,"OpenGl_ElementNode");

    // nested enums

    static_cast<py::class_<OpenGl_ElementNode , shared_ptr<OpenGl_ElementNode>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_ExtGS from ./opencascade/OpenGl_ExtGS.hxx
    klass = m.attr("OpenGl_ExtGS");

    // default constructor
    register_default_constructor<OpenGl_ExtGS , shared_ptr<OpenGl_ExtGS>>(m,"OpenGl_ExtGS");

    // nested enums

    static_cast<py::class_<OpenGl_ExtGS , shared_ptr<OpenGl_ExtGS>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_FrameStats from ./opencascade/OpenGl_FrameStats.hxx
    klass = m.attr("OpenGl_FrameStats");


    // nested enums

    static_cast<py::class_<OpenGl_FrameStats ,opencascade::handle<OpenGl_FrameStats>  , Graphic3d_FrameStats >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("IsFrameUpdated",
             (bool (OpenGl_FrameStats::*)( handle<OpenGl_FrameStats> &  ) const) static_cast<bool (OpenGl_FrameStats::*)( handle<OpenGl_FrameStats> &  ) const>(&OpenGl_FrameStats::IsFrameUpdated),
             R"#(Copy stats values into another instance (create new instance, if not exists). The main use of this method is to track changes in statistics (e.g. in conjunction with IsEqual() method).)#"  , py::arg("thePrev")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_FrameStats::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_FrameStats::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_FrameStats::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_FrameStats::*)() const>(&OpenGl_FrameStats::DynamicType),
             R"#()#"
             
         )
;

    // Class OpenGl_GlCore11 from ./opencascade/OpenGl_GlCore11.hxx
    klass = m.attr("OpenGl_GlCore11");

    // default constructor
    register_default_constructor<OpenGl_GlCore11 , shared_ptr<OpenGl_GlCore11>>(m,"OpenGl_GlCore11");

    // nested enums

    static_cast<py::class_<OpenGl_GlCore11 , shared_ptr<OpenGl_GlCore11>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_GlCore11Fwd from ./opencascade/OpenGl_GlCore11Fwd.hxx
    klass = m.attr("OpenGl_GlCore11Fwd");

    // default constructor
    register_default_constructor<OpenGl_GlCore11Fwd , shared_ptr<OpenGl_GlCore11Fwd>>(m,"OpenGl_GlCore11Fwd");

    // nested enums

    static_cast<py::class_<OpenGl_GlCore11Fwd , shared_ptr<OpenGl_GlCore11Fwd>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_GlCore12 from ./opencascade/OpenGl_GlCore12.hxx
    klass = m.attr("OpenGl_GlCore12");

    // default constructor
    register_default_constructor<OpenGl_GlCore12 , shared_ptr<OpenGl_GlCore12>>(m,"OpenGl_GlCore12");

    // nested enums

    static_cast<py::class_<OpenGl_GlCore12 , shared_ptr<OpenGl_GlCore12>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_GlCore13 from ./opencascade/OpenGl_GlCore13.hxx
    klass = m.attr("OpenGl_GlCore13");

    // default constructor
    register_default_constructor<OpenGl_GlCore13 , shared_ptr<OpenGl_GlCore13>>(m,"OpenGl_GlCore13");

    // nested enums

    static_cast<py::class_<OpenGl_GlCore13 , shared_ptr<OpenGl_GlCore13>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_GlCore14 from ./opencascade/OpenGl_GlCore14.hxx
    klass = m.attr("OpenGl_GlCore14");

    // default constructor
    register_default_constructor<OpenGl_GlCore14 , shared_ptr<OpenGl_GlCore14>>(m,"OpenGl_GlCore14");

    // nested enums

    static_cast<py::class_<OpenGl_GlCore14 , shared_ptr<OpenGl_GlCore14>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_GlCore15 from ./opencascade/OpenGl_GlCore15.hxx
    klass = m.attr("OpenGl_GlCore15");

    // default constructor
    register_default_constructor<OpenGl_GlCore15 , shared_ptr<OpenGl_GlCore15>>(m,"OpenGl_GlCore15");

    // nested enums

    static_cast<py::class_<OpenGl_GlCore15 , shared_ptr<OpenGl_GlCore15>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_GlCore20 from ./opencascade/OpenGl_GlCore20.hxx
    klass = m.attr("OpenGl_GlCore20");

    // default constructor
    register_default_constructor<OpenGl_GlCore20 , shared_ptr<OpenGl_GlCore20>>(m,"OpenGl_GlCore20");

    // nested enums

    static_cast<py::class_<OpenGl_GlCore20 , shared_ptr<OpenGl_GlCore20>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_GlCore21 from ./opencascade/OpenGl_GlCore21.hxx
    klass = m.attr("OpenGl_GlCore21");

    // default constructor
    register_default_constructor<OpenGl_GlCore21 , shared_ptr<OpenGl_GlCore21>>(m,"OpenGl_GlCore21");

    // nested enums

    static_cast<py::class_<OpenGl_GlCore21 , shared_ptr<OpenGl_GlCore21>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_GlCore30 from ./opencascade/OpenGl_GlCore30.hxx
    klass = m.attr("OpenGl_GlCore30");

    // default constructor
    register_default_constructor<OpenGl_GlCore30 , shared_ptr<OpenGl_GlCore30>>(m,"OpenGl_GlCore30");

    // nested enums

    static_cast<py::class_<OpenGl_GlCore30 , shared_ptr<OpenGl_GlCore30>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_GlCore31 from ./opencascade/OpenGl_GlCore31.hxx
    klass = m.attr("OpenGl_GlCore31");

    // default constructor
    register_default_constructor<OpenGl_GlCore31 , shared_ptr<OpenGl_GlCore31>>(m,"OpenGl_GlCore31");

    // nested enums

    static_cast<py::class_<OpenGl_GlCore31 , shared_ptr<OpenGl_GlCore31>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_GlCore32 from ./opencascade/OpenGl_GlCore32.hxx
    klass = m.attr("OpenGl_GlCore32");

    // default constructor
    register_default_constructor<OpenGl_GlCore32 , shared_ptr<OpenGl_GlCore32>>(m,"OpenGl_GlCore32");

    // nested enums

    static_cast<py::class_<OpenGl_GlCore32 , shared_ptr<OpenGl_GlCore32>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_GlCore33 from ./opencascade/OpenGl_GlCore33.hxx
    klass = m.attr("OpenGl_GlCore33");

    // default constructor
    register_default_constructor<OpenGl_GlCore33 , shared_ptr<OpenGl_GlCore33>>(m,"OpenGl_GlCore33");

    // nested enums

    static_cast<py::class_<OpenGl_GlCore33 , shared_ptr<OpenGl_GlCore33>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_GlCore40 from ./opencascade/OpenGl_GlCore40.hxx
    klass = m.attr("OpenGl_GlCore40");

    // default constructor
    register_default_constructor<OpenGl_GlCore40 , shared_ptr<OpenGl_GlCore40>>(m,"OpenGl_GlCore40");

    // nested enums

    static_cast<py::class_<OpenGl_GlCore40 , shared_ptr<OpenGl_GlCore40>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_GlCore41 from ./opencascade/OpenGl_GlCore41.hxx
    klass = m.attr("OpenGl_GlCore41");

    // default constructor
    register_default_constructor<OpenGl_GlCore41 , shared_ptr<OpenGl_GlCore41>>(m,"OpenGl_GlCore41");

    // nested enums

    static_cast<py::class_<OpenGl_GlCore41 , shared_ptr<OpenGl_GlCore41>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_GlCore42 from ./opencascade/OpenGl_GlCore42.hxx
    klass = m.attr("OpenGl_GlCore42");

    // default constructor
    register_default_constructor<OpenGl_GlCore42 , shared_ptr<OpenGl_GlCore42>>(m,"OpenGl_GlCore42");

    // nested enums

    static_cast<py::class_<OpenGl_GlCore42 , shared_ptr<OpenGl_GlCore42>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_GlCore43 from ./opencascade/OpenGl_GlCore43.hxx
    klass = m.attr("OpenGl_GlCore43");

    // default constructor
    register_default_constructor<OpenGl_GlCore43 , shared_ptr<OpenGl_GlCore43>>(m,"OpenGl_GlCore43");

    // nested enums

    static_cast<py::class_<OpenGl_GlCore43 , shared_ptr<OpenGl_GlCore43>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_GlCore44 from ./opencascade/OpenGl_GlCore44.hxx
    klass = m.attr("OpenGl_GlCore44");

    // default constructor
    register_default_constructor<OpenGl_GlCore44 , shared_ptr<OpenGl_GlCore44>>(m,"OpenGl_GlCore44");

    // nested enums

    static_cast<py::class_<OpenGl_GlCore44 , shared_ptr<OpenGl_GlCore44>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_GlCore45 from ./opencascade/OpenGl_GlCore45.hxx
    klass = m.attr("OpenGl_GlCore45");

    // default constructor
    register_default_constructor<OpenGl_GlCore45 , shared_ptr<OpenGl_GlCore45>>(m,"OpenGl_GlCore45");

    // nested enums

    static_cast<py::class_<OpenGl_GlCore45 , shared_ptr<OpenGl_GlCore45>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_GlCore46 from ./opencascade/OpenGl_GlCore46.hxx
    klass = m.attr("OpenGl_GlCore46");

    // default constructor
    register_default_constructor<OpenGl_GlCore46 , shared_ptr<OpenGl_GlCore46>>(m,"OpenGl_GlCore46");

    // nested enums

    static_cast<py::class_<OpenGl_GlCore46 , shared_ptr<OpenGl_GlCore46>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_GlFunctions from ./opencascade/OpenGl_GlFunctions.hxx
    klass = m.attr("OpenGl_GlFunctions");

    // default constructor
    register_default_constructor<OpenGl_GlFunctions , shared_ptr<OpenGl_GlFunctions>>(m,"OpenGl_GlFunctions");

    // nested enums

    static_cast<py::class_<OpenGl_GlFunctions , shared_ptr<OpenGl_GlFunctions>  >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("load",
             (void (OpenGl_GlFunctions::*)( OpenGl_Context & ,  bool  ) ) static_cast<void (OpenGl_GlFunctions::*)( OpenGl_Context & ,  bool  ) >(&OpenGl_GlFunctions::load),
             R"#(Load functions.)#"  , py::arg("theCtx"),  py::arg("theIsCoreProfile")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("debugPrintError_s",
                    (bool (*)(  const char *  ) ) static_cast<bool (*)(  const char *  ) >(&OpenGl_GlFunctions::debugPrintError),
                    R"#(Check glGetError(); defined for debugging purposes.)#"  , py::arg("theName")
          )
    // static methods using call by reference i.s.o. return
        .def_static("readGlVersion_s",
            []( ){
                int  theGlVerMajor;
                int  theGlVerMinor;

                OpenGl_GlFunctions::readGlVersion(theGlVerMajor,theGlVerMinor);
                
return std::make_tuple(theGlVerMajor,theGlVerMinor); },
            R"#(Read OpenGL version.)#" 
          )
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_GraphicDriver from ./opencascade/OpenGl_GraphicDriver.hxx
    klass = m.attr("OpenGl_GraphicDriver");


    // nested enums

    static_cast<py::class_<OpenGl_GraphicDriver ,opencascade::handle<OpenGl_GraphicDriver>  , Graphic3d_GraphicDriver >>(klass)
    // constructors
        .def(py::init<  const handle<Aspect_DisplayConnection> &, const bool >()  , py::arg("theDisp"),  py::arg("theToInitialize")=static_cast< const bool>(true) )
    // custom constructors
    // methods
        .def("ReleaseContext",
             (void (OpenGl_GraphicDriver::*)() ) static_cast<void (OpenGl_GraphicDriver::*)() >(&OpenGl_GraphicDriver::ReleaseContext),
             R"#(Release default context.)#" 
          )
        .def("InitContext",
             (bool (OpenGl_GraphicDriver::*)() ) static_cast<bool (OpenGl_GraphicDriver::*)() >(&OpenGl_GraphicDriver::InitContext),
             R"#(Perform initialization of default OpenGL context.)#" 
          )
        .def("InitEglContext",
             (bool (OpenGl_GraphicDriver::*)( Aspect_Display ,  Aspect_RenderingContext ,  void *  ) ) static_cast<bool (OpenGl_GraphicDriver::*)( Aspect_Display ,  Aspect_RenderingContext ,  void *  ) >(&OpenGl_GraphicDriver::InitEglContext),
             R"#(Initialize default OpenGL context using existing one.)#"  , py::arg("theEglDisplay"),  py::arg("theEglContext"),  py::arg("theEglConfig")
          )
        .def("InquireLimit",
             (int (OpenGl_GraphicDriver::*)(  const Graphic3d_TypeOfLimit  ) const) static_cast<int (OpenGl_GraphicDriver::*)(  const Graphic3d_TypeOfLimit  ) const>(&OpenGl_GraphicDriver::InquireLimit),
             R"#(Request limit of graphic resource of specific type.)#"  , py::arg("theType")
          )
        .def("CreateStructure",
             (handle<Graphic3d_CStructure> (OpenGl_GraphicDriver::*)(  const handle<Graphic3d_StructureManager> &  ) ) static_cast<handle<Graphic3d_CStructure> (OpenGl_GraphicDriver::*)(  const handle<Graphic3d_StructureManager> &  ) >(&OpenGl_GraphicDriver::CreateStructure),
             R"#()#"  , py::arg("theManager")
          )
        .def("CreateView",
             (handle<Graphic3d_CView> (OpenGl_GraphicDriver::*)(  const handle<Graphic3d_StructureManager> &  ) ) static_cast<handle<Graphic3d_CView> (OpenGl_GraphicDriver::*)(  const handle<Graphic3d_StructureManager> &  ) >(&OpenGl_GraphicDriver::CreateView),
             R"#()#"  , py::arg("theMgr")
          )
        .def("RemoveView",
             (void (OpenGl_GraphicDriver::*)(  const handle<Graphic3d_CView> &  ) ) static_cast<void (OpenGl_GraphicDriver::*)(  const handle<Graphic3d_CView> &  ) >(&OpenGl_GraphicDriver::RemoveView),
             R"#()#"  , py::arg("theView")
          )
        .def("CreateRenderWindow",
             (handle<OpenGl_Window> (OpenGl_GraphicDriver::*)(  const handle<Aspect_Window> & ,   const handle<Aspect_Window> & ,   const Aspect_RenderingContext  ) ) static_cast<handle<OpenGl_Window> (OpenGl_GraphicDriver::*)(  const handle<Aspect_Window> & ,   const handle<Aspect_Window> & ,   const Aspect_RenderingContext  ) >(&OpenGl_GraphicDriver::CreateRenderWindow),
             R"#(Create OpenGL window from native window.)#"  , py::arg("theNativeWindow"),  py::arg("theSizeWindow"),  py::arg("theContext")
          )
        .def("DefaultTextHeight",
             (float (OpenGl_GraphicDriver::*)() const) static_cast<float (OpenGl_GraphicDriver::*)() const>(&OpenGl_GraphicDriver::DefaultTextHeight),
             R"#()#" 
          )
        .def("ViewExists",
             (bool (OpenGl_GraphicDriver::*)(  const handle<Aspect_Window> & ,  handle<Graphic3d_CView> &  ) ) static_cast<bool (OpenGl_GraphicDriver::*)(  const handle<Aspect_Window> & ,  handle<Graphic3d_CView> &  ) >(&OpenGl_GraphicDriver::ViewExists),
             R"#()#"  , py::arg("theWindow"),  py::arg("theView")
          )
        .def("InsertLayerBefore",
             (void (OpenGl_GraphicDriver::*)(  const Graphic3d_ZLayerId ,   const Graphic3d_ZLayerSettings & ,   const Graphic3d_ZLayerId  ) ) static_cast<void (OpenGl_GraphicDriver::*)(  const Graphic3d_ZLayerId ,   const Graphic3d_ZLayerSettings & ,   const Graphic3d_ZLayerId  ) >(&OpenGl_GraphicDriver::InsertLayerBefore),
             R"#(Adds a layer to all views.)#"  , py::arg("theNewLayerId"),  py::arg("theSettings"),  py::arg("theLayerAfter")
          )
        .def("InsertLayerAfter",
             (void (OpenGl_GraphicDriver::*)(  const Graphic3d_ZLayerId ,   const Graphic3d_ZLayerSettings & ,   const Graphic3d_ZLayerId  ) ) static_cast<void (OpenGl_GraphicDriver::*)(  const Graphic3d_ZLayerId ,   const Graphic3d_ZLayerSettings & ,   const Graphic3d_ZLayerId  ) >(&OpenGl_GraphicDriver::InsertLayerAfter),
             R"#(Adds a layer to all views.)#"  , py::arg("theNewLayerId"),  py::arg("theSettings"),  py::arg("theLayerBefore")
          )
        .def("RemoveZLayer",
             (void (OpenGl_GraphicDriver::*)(  const Graphic3d_ZLayerId  ) ) static_cast<void (OpenGl_GraphicDriver::*)(  const Graphic3d_ZLayerId  ) >(&OpenGl_GraphicDriver::RemoveZLayer),
             R"#(Removes Z layer. All structures displayed at the moment in layer will be displayed in default layer (the bottom-level z layer). By default, there are always default bottom-level layer that can't be removed. The passed theLayerId should be not less than 0 (reserved for default layers that can not be removed).)#"  , py::arg("theLayerId")
          )
        .def("SetZLayerSettings",
             (void (OpenGl_GraphicDriver::*)(  const Graphic3d_ZLayerId ,   const Graphic3d_ZLayerSettings &  ) ) static_cast<void (OpenGl_GraphicDriver::*)(  const Graphic3d_ZLayerId ,   const Graphic3d_ZLayerSettings &  ) >(&OpenGl_GraphicDriver::SetZLayerSettings),
             R"#(Sets the settings for a single Z layer.)#"  , py::arg("theLayerId"),  py::arg("theSettings")
          )
        .def("SetBuffersNoSwap",
             (void (OpenGl_GraphicDriver::*)(  const bool  ) ) static_cast<void (OpenGl_GraphicDriver::*)(  const bool  ) >(&OpenGl_GraphicDriver::SetBuffersNoSwap),
             R"#(Specify swap buffer behavior.)#"  , py::arg("theIsNoSwap")
          )
        .def("EnableVBO",
             (void (OpenGl_GraphicDriver::*)(  const bool  ) ) static_cast<void (OpenGl_GraphicDriver::*)(  const bool  ) >(&OpenGl_GraphicDriver::EnableVBO),
             R"#(VBO usage can be forbidden by this method even if it is supported by GL driver. Notice that disabling of VBO will cause rendering performance degradation. Warning! This method should be called only before any primitives are displayed in GL scene!)#"  , py::arg("theToTurnOn")
          )
        .def("IsVerticalSync",
             (bool (OpenGl_GraphicDriver::*)() const) static_cast<bool (OpenGl_GraphicDriver::*)() const>(&OpenGl_GraphicDriver::IsVerticalSync),
             R"#(Returns TRUE if vertical synchronization with display refresh rate (VSync) should be used; TRUE by default.)#" 
          )
        .def("SetVerticalSync",
             (void (OpenGl_GraphicDriver::*)( bool  ) ) static_cast<void (OpenGl_GraphicDriver::*)( bool  ) >(&OpenGl_GraphicDriver::SetVerticalSync),
             R"#(Set if vertical synchronization with display refresh rate (VSync) should be used.)#"  , py::arg("theToEnable")
          )
        .def("MemoryInfo",
             (bool (OpenGl_GraphicDriver::*)( size_t & ,  TCollection_AsciiString &  ) const) static_cast<bool (OpenGl_GraphicDriver::*)( size_t & ,  TCollection_AsciiString &  ) const>(&OpenGl_GraphicDriver::MemoryInfo),
             R"#(Returns information about GPU memory usage. Please read OpenGl_Context::MemoryInfo() for more description.)#"  , py::arg("theFreeBytes"),  py::arg("theInfo")
          )
        .def("GetSharedContext",
             ( const handle<OpenGl_Context> & (OpenGl_GraphicDriver::*)( bool  ) const) static_cast< const handle<OpenGl_Context> & (OpenGl_GraphicDriver::*)( bool  ) const>(&OpenGl_GraphicDriver::GetSharedContext),
             R"#(Method to retrieve valid GL context. Could return NULL-handle if no window created by this driver.)#"  , py::arg("theBound")=static_cast<bool>(false)
          )
        .def("getRawGlDisplay",
             (Aspect_Display (OpenGl_GraphicDriver::*)() const) static_cast<Aspect_Display (OpenGl_GraphicDriver::*)() const>(&OpenGl_GraphicDriver::getRawGlDisplay),
             R"#()#" 
          )
        .def("getRawGlContext",
             (Aspect_RenderingContext (OpenGl_GraphicDriver::*)() const) static_cast<Aspect_RenderingContext (OpenGl_GraphicDriver::*)() const>(&OpenGl_GraphicDriver::getRawGlContext),
             R"#()#" 
          )
        .def("getRawGlConfig",
             (void * (OpenGl_GraphicDriver::*)() const) static_cast<void * (OpenGl_GraphicDriver::*)() const>(&OpenGl_GraphicDriver::getRawGlConfig),
             R"#()#" 
          )
        .def("setDeviceLost",
             (void (OpenGl_GraphicDriver::*)() ) static_cast<void (OpenGl_GraphicDriver::*)() >(&OpenGl_GraphicDriver::setDeviceLost),
             R"#(Set device lost flag for redrawn views.)#" 
          )
        .def("GetStateCounter",
             (OpenGl_StateCounter * (OpenGl_GraphicDriver::*)() const) static_cast<OpenGl_StateCounter * (OpenGl_GraphicDriver::*)() const>(&OpenGl_GraphicDriver::GetStateCounter),
             R"#(State counter for OpenGl structures.)#" 
          )
        .def("GetNextPrimitiveArrayUID",
             (size_t (OpenGl_GraphicDriver::*)() const) static_cast<size_t (OpenGl_GraphicDriver::*)() const>(&OpenGl_GraphicDriver::GetNextPrimitiveArrayUID),
             R"#(Returns unique ID for primitive arrays.)#" 
          )
    // methods using call by reference i.s.o. return
        .def("RemoveStructure",
             []( OpenGl_GraphicDriver &self , Graphic3d_CStructure& theCStructure ){
                 handle<Graphic3d_CStructure>  theCStructure_ptr; theCStructure_ptr = &theCStructure;

                 self.RemoveStructure(theCStructure_ptr);
                 return std::make_tuple(theCStructure_ptr); },
             R"#()#"  , py::arg("theCStructure")
          )
        .def("TextSize",
             []( OpenGl_GraphicDriver &self ,  const handle<Graphic3d_CView> & theView, const char * const  theText, const float theHeight ){
                 float  theWidth;
                float  theAscent;
                float  theDescent;

                 self.TextSize(theView,theText,theHeight,theWidth,theAscent,theDescent);
                 return std::make_tuple(theWidth,theAscent,theDescent); },
             R"#()#"  , py::arg("theView"),  py::arg("theText"),  py::arg("theHeight")
          )
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_GraphicDriver::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_GraphicDriver::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_GraphicDriver::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_GraphicDriver::*)() const>(&OpenGl_GraphicDriver::DynamicType),
             R"#()#"
             
         )
       .def("Options",
             ( const OpenGl_Caps & (OpenGl_GraphicDriver::*)() const) static_cast< const OpenGl_Caps & (OpenGl_GraphicDriver::*)() const>(&OpenGl_GraphicDriver::Options),
             R"#(Returns the visualization options)#"
             
         )
       .def("ChangeOptions",
             (OpenGl_Caps & (OpenGl_GraphicDriver::*)() ) static_cast<OpenGl_Caps & (OpenGl_GraphicDriver::*)() >(&OpenGl_GraphicDriver::ChangeOptions),
             R"#(Returns the visualization options)#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class OpenGl_GraphicDriverFactory from ./opencascade/OpenGl_GraphicDriverFactory.hxx
    klass = m.attr("OpenGl_GraphicDriverFactory");


    // nested enums

    static_cast<py::class_<OpenGl_GraphicDriverFactory ,opencascade::handle<OpenGl_GraphicDriverFactory>  , Graphic3d_GraphicDriverFactory >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("CreateDriver",
             (handle<Graphic3d_GraphicDriver> (OpenGl_GraphicDriverFactory::*)(  const handle<Aspect_DisplayConnection> &  ) ) static_cast<handle<Graphic3d_GraphicDriver> (OpenGl_GraphicDriverFactory::*)(  const handle<Aspect_DisplayConnection> &  ) >(&OpenGl_GraphicDriverFactory::CreateDriver),
             R"#(Creates new empty graphic driver.)#"  , py::arg("theDisp")
          )
        .def("SetDefaultOptions",
             (void (OpenGl_GraphicDriverFactory::*)(  const handle<OpenGl_Caps> &  ) ) static_cast<void (OpenGl_GraphicDriverFactory::*)(  const handle<OpenGl_Caps> &  ) >(&OpenGl_GraphicDriverFactory::SetDefaultOptions),
             R"#(Set default driver options.)#"  , py::arg("theOptions")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_GraphicDriverFactory::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_GraphicDriverFactory::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_GraphicDriverFactory::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_GraphicDriverFactory::*)() const>(&OpenGl_GraphicDriverFactory::DynamicType),
             R"#()#"
             
         )
       .def("DefaultOptions",
             ( const handle<OpenGl_Caps> & (OpenGl_GraphicDriverFactory::*)() const) static_cast< const handle<OpenGl_Caps> & (OpenGl_GraphicDriverFactory::*)() const>(&OpenGl_GraphicDriverFactory::DefaultOptions),
             R"#(Return default driver options.)#"
             
         )
;

    // Class OpenGl_Group from ./opencascade/OpenGl_Group.hxx
    klass = m.attr("OpenGl_Group");


    // nested enums

    static_cast<py::class_<OpenGl_Group ,opencascade::handle<OpenGl_Group>  , Graphic3d_Group >>(klass)
    // constructors
        .def(py::init<  const handle<Graphic3d_Structure> & >()  , py::arg("theStruct") )
    // custom constructors
    // methods
        .def("Clear",
             (void (OpenGl_Group::*)(  const bool  ) ) static_cast<void (OpenGl_Group::*)(  const bool  ) >(&OpenGl_Group::Clear),
             R"#()#"  , py::arg("theToUpdateStructureMgr")
          )
        .def("Aspects",
             (handle<Graphic3d_Aspects> (OpenGl_Group::*)() const) static_cast<handle<Graphic3d_Aspects> (OpenGl_Group::*)() const>(&OpenGl_Group::Aspects),
             R"#(Return line aspect.)#" 
          )
        .def("HasPersistence",
             (bool (OpenGl_Group::*)() const) static_cast<bool (OpenGl_Group::*)() const>(&OpenGl_Group::HasPersistence),
             R"#(Return TRUE if group contains primitives with transform persistence.)#" 
          )
        .def("SetGroupPrimitivesAspect",
             (void (OpenGl_Group::*)(  const handle<Graphic3d_Aspects> &  ) ) static_cast<void (OpenGl_Group::*)(  const handle<Graphic3d_Aspects> &  ) >(&OpenGl_Group::SetGroupPrimitivesAspect),
             R"#(Update aspect.)#"  , py::arg("theAspect")
          )
        .def("SetPrimitivesAspect",
             (void (OpenGl_Group::*)(  const handle<Graphic3d_Aspects> &  ) ) static_cast<void (OpenGl_Group::*)(  const handle<Graphic3d_Aspects> &  ) >(&OpenGl_Group::SetPrimitivesAspect),
             R"#(Append aspect as an element.)#"  , py::arg("theAspect")
          )
        .def("SynchronizeAspects",
             (void (OpenGl_Group::*)() ) static_cast<void (OpenGl_Group::*)() >(&OpenGl_Group::SynchronizeAspects),
             R"#(Update presentation aspects after their modification.)#" 
          )
        .def("ReplaceAspects",
             (void (OpenGl_Group::*)(  const NCollection_DataMap<handle<Graphic3d_Aspects>, handle<Graphic3d_Aspects>> &  ) ) static_cast<void (OpenGl_Group::*)(  const NCollection_DataMap<handle<Graphic3d_Aspects>, handle<Graphic3d_Aspects>> &  ) >(&OpenGl_Group::ReplaceAspects),
             R"#(Replace aspects specified in the replacement map.)#"  , py::arg("theMap")
          )
        .def("AddPrimitiveArray",
             (void (OpenGl_Group::*)(  const Graphic3d_TypeOfPrimitiveArray ,   const handle<Graphic3d_IndexBuffer> & ,   const handle<Graphic3d_Buffer> & ,   const handle<Graphic3d_BoundBuffer> & ,   const bool  ) ) static_cast<void (OpenGl_Group::*)(  const Graphic3d_TypeOfPrimitiveArray ,   const handle<Graphic3d_IndexBuffer> & ,   const handle<Graphic3d_Buffer> & ,   const handle<Graphic3d_BoundBuffer> & ,   const bool  ) >(&OpenGl_Group::AddPrimitiveArray),
             R"#(Add primitive array element)#"  , py::arg("theType"),  py::arg("theIndices"),  py::arg("theAttribs"),  py::arg("theBounds"),  py::arg("theToEvalMinMax")
          )
        .def("AddText",
             (void (OpenGl_Group::*)(  const handle<Graphic3d_Text> & ,   const bool  ) ) static_cast<void (OpenGl_Group::*)(  const handle<Graphic3d_Text> & ,   const bool  ) >(&OpenGl_Group::AddText),
             R"#(Adds a text for display)#"  , py::arg("theTextParams"),  py::arg("theToEvalMinMax")
          )
        .def("SetFlippingOptions",
             (void (OpenGl_Group::*)(  const bool ,   const gp_Ax2 &  ) ) static_cast<void (OpenGl_Group::*)(  const bool ,   const gp_Ax2 &  ) >(&OpenGl_Group::SetFlippingOptions),
             R"#(Add flipping element)#"  , py::arg("theIsEnabled"),  py::arg("theRefPlane")
          )
        .def("SetStencilTestOptions",
             (void (OpenGl_Group::*)(  const bool  ) ) static_cast<void (OpenGl_Group::*)(  const bool  ) >(&OpenGl_Group::SetStencilTestOptions),
             R"#(Add stencil test element)#"  , py::arg("theIsEnabled")
          )
        .def("GlStruct",
             (OpenGl_Structure * (OpenGl_Group::*)() const) static_cast<OpenGl_Structure * (OpenGl_Group::*)() const>(&OpenGl_Group::GlStruct),
             R"#()#" 
          )
        .def("AddElement",
             (void (OpenGl_Group::*)( OpenGl_Element *  ) ) static_cast<void (OpenGl_Group::*)( OpenGl_Element *  ) >(&OpenGl_Group::AddElement),
             R"#()#"  , py::arg("theElem")
          )
        .def("Render",
             (void (OpenGl_Group::*)(  const handle<OpenGl_Workspace> &  ) const) static_cast<void (OpenGl_Group::*)(  const handle<OpenGl_Workspace> &  ) const>(&OpenGl_Group::Render),
             R"#()#"  , py::arg("theWorkspace")
          )
        .def("Release",
             (void (OpenGl_Group::*)(  const handle<OpenGl_Context> &  ) ) static_cast<void (OpenGl_Group::*)(  const handle<OpenGl_Context> &  ) >(&OpenGl_Group::Release),
             R"#()#"  , py::arg("theGlCtx")
          )
        .def("FirstNode",
             ( const OpenGl_ElementNode * (OpenGl_Group::*)() const) static_cast< const OpenGl_ElementNode * (OpenGl_Group::*)() const>(&OpenGl_Group::FirstNode),
             R"#(Returns first OpenGL element node of the group.)#" 
          )
        .def("GlAspects",
             ( const OpenGl_Aspects * (OpenGl_Group::*)() const) static_cast< const OpenGl_Aspects * (OpenGl_Group::*)() const>(&OpenGl_Group::GlAspects),
             R"#(Returns OpenGL aspect.)#" 
          )
        .def("IsRaytracable",
             (bool (OpenGl_Group::*)() const) static_cast<bool (OpenGl_Group::*)() const>(&OpenGl_Group::IsRaytracable),
             R"#(Is the group ray-tracable (contains ray-tracable elements)?)#" 
          )
        .def("DumpJson",
             (void (OpenGl_Group::*)( Standard_OStream & ,  int  ) const) static_cast<void (OpenGl_Group::*)( Standard_OStream & ,  int  ) const>(&OpenGl_Group::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_Group::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_Group::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_Group::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_Group::*)() const>(&OpenGl_Group::DynamicType),
             R"#()#"
             
         )
;

    // Class OpenGl_HaltonSampler from ./opencascade/OpenGl_HaltonSampler.hxx
    klass = m.attr("OpenGl_HaltonSampler");


    // nested enums

    static_cast<py::class_<OpenGl_HaltonSampler , shared_ptr<OpenGl_HaltonSampler>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("sample",
             (float (OpenGl_HaltonSampler::*)( unsigned int ,  unsigned int  ) const) static_cast<float (OpenGl_HaltonSampler::*)( unsigned int ,  unsigned int  ) const>(&OpenGl_HaltonSampler::sample),
             R"#(Return the Halton sample for the given dimension (component) and index. The client must have called initFaure() at least once before. dimension must be smaller than the value returned by get_num_dimensions().)#"  , py::arg("theDimension"),  py::arg("theIndex")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_num_dimensions_s",
                    (unsigned int (*)() ) static_cast<unsigned int (*)() >(&OpenGl_HaltonSampler::get_num_dimensions),
                    R"#(Return the number of supported dimensions.)#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_Material from ./opencascade/OpenGl_Material.hxx
    klass = m.attr("OpenGl_Material");

    // default constructor
    register_default_constructor<OpenGl_Material , shared_ptr<OpenGl_Material>>(m,"OpenGl_Material");

    // nested enums

    static_cast<py::class_<OpenGl_Material , shared_ptr<OpenGl_Material>  >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("SetColor",
             (void (OpenGl_Material::*)(  const NCollection_Vec3<float> &  ) ) static_cast<void (OpenGl_Material::*)(  const NCollection_Vec3<float> &  ) >(&OpenGl_Material::SetColor),
             R"#(Set material color.)#"  , py::arg("theColor")
          )
        .def("IsEqual",
             (bool (OpenGl_Material::*)(  const OpenGl_Material &  ) const) static_cast<bool (OpenGl_Material::*)(  const OpenGl_Material &  ) const>(&OpenGl_Material::IsEqual),
             R"#(Check this material for equality with another material (without tolerance!).)#"  , py::arg("theOther")
          )
        .def("PackedCommon",
             ( const NCollection_Vec4<float> * (OpenGl_Material::*)() const) static_cast< const NCollection_Vec4<float> * (OpenGl_Material::*)() const>(&OpenGl_Material::PackedCommon),
             R"#(Returns packed (serialized) representation of common material properties)#" 
          )
        .def("PackedPbr",
             ( const NCollection_Vec4<float> * (OpenGl_Material::*)() const) static_cast< const NCollection_Vec4<float> * (OpenGl_Material::*)() const>(&OpenGl_Material::PackedPbr),
             R"#(Returns packed (serialized) representation of PBR material properties)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("NbOfVec4Common_s",
                    (int (*)() ) static_cast<int (*)() >(&OpenGl_Material::NbOfVec4Common),
                    R"#()#" 
          )
        .def_static("NbOfVec4Pbr_s",
                    (int (*)() ) static_cast<int (*)() >(&OpenGl_Material::NbOfVec4Pbr),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_MaterialCommon from ./opencascade/OpenGl_Material.hxx
    klass = m.attr("OpenGl_MaterialCommon");


    // nested enums

    static_cast<py::class_<OpenGl_MaterialCommon , shared_ptr<OpenGl_MaterialCommon>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Shine",
             (float (OpenGl_MaterialCommon::*)() const) static_cast<float (OpenGl_MaterialCommon::*)() const>(&OpenGl_MaterialCommon::Shine),
             R"#()#" 
          )
        .def("SetColor",
             (void (OpenGl_MaterialCommon::*)(  const NCollection_Vec3<float> &  ) ) static_cast<void (OpenGl_MaterialCommon::*)(  const NCollection_Vec3<float> &  ) >(&OpenGl_MaterialCommon::SetColor),
             R"#(Set material color.)#"  , py::arg("theColor")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def_property("ChangeShine",
                     [](OpenGl_MaterialCommon& self){return self.ChangeShine();} ,
                     [](OpenGl_MaterialCommon& self, float  val){self.ChangeShine() = val;},                      R"#()#"
         )
;

    // Class OpenGl_MaterialPBR from ./opencascade/OpenGl_Material.hxx
    klass = m.attr("OpenGl_MaterialPBR");


    // nested enums

    static_cast<py::class_<OpenGl_MaterialPBR , shared_ptr<OpenGl_MaterialPBR>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Metallic",
             (float (OpenGl_MaterialPBR::*)() const) static_cast<float (OpenGl_MaterialPBR::*)() const>(&OpenGl_MaterialPBR::Metallic),
             R"#()#" 
          )
        .def("Roughness",
             (float (OpenGl_MaterialPBR::*)() const) static_cast<float (OpenGl_MaterialPBR::*)() const>(&OpenGl_MaterialPBR::Roughness),
             R"#()#" 
          )
        .def("SetColor",
             (void (OpenGl_MaterialPBR::*)(  const NCollection_Vec3<float> &  ) ) static_cast<void (OpenGl_MaterialPBR::*)(  const NCollection_Vec3<float> &  ) >(&OpenGl_MaterialPBR::SetColor),
             R"#(Set material color.)#"  , py::arg("theColor")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def_property("ChangeMetallic",
                     [](OpenGl_MaterialPBR& self){return self.ChangeMetallic();} ,
                     [](OpenGl_MaterialPBR& self, float  val){self.ChangeMetallic() = val;},                      R"#()#"
         )
       .def_property("ChangeRoughness",
                     [](OpenGl_MaterialPBR& self){return self.ChangeRoughness();} ,
                     [](OpenGl_MaterialPBR& self, float  val){self.ChangeRoughness() = val;},                      R"#()#"
         )
;

    // Class OpenGl_RaytraceLight from ./opencascade/OpenGl_SceneGeometry.hxx
    klass = m.attr("OpenGl_RaytraceLight");


    // nested enums

    static_cast<py::class_<OpenGl_RaytraceLight , shared_ptr<OpenGl_RaytraceLight>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const BVH_Vec4f &, const BVH_Vec4f & >()  , py::arg("theEmission"),  py::arg("thePosition") )
    // custom constructors
    // methods
        .def("Packed",
             ( const float * (OpenGl_RaytraceLight::*)() ) static_cast< const float * (OpenGl_RaytraceLight::*)() >(&OpenGl_RaytraceLight::Packed),
             R"#(Returns packed (serialized) representation of light source.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_RaytraceMaterial from ./opencascade/OpenGl_SceneGeometry.hxx
    klass = m.attr("OpenGl_RaytraceMaterial");


    // nested enums

    static_cast<py::class_<OpenGl_RaytraceMaterial , shared_ptr<OpenGl_RaytraceMaterial>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Packed",
             ( const float * (OpenGl_RaytraceMaterial::*)() ) static_cast< const float * (OpenGl_RaytraceMaterial::*)() >(&OpenGl_RaytraceMaterial::Packed),
             R"#(Returns packed (serialized) representation of material.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_Resource from ./opencascade/OpenGl_Resource.hxx
    klass = m.attr("OpenGl_Resource");


    // nested enums

    static_cast<py::class_<OpenGl_Resource ,opencascade::handle<OpenGl_Resource> ,Py_OpenGl_Resource , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Release",
             (void (OpenGl_Resource::*)( OpenGl_Context *  ) ) static_cast<void (OpenGl_Resource::*)( OpenGl_Context *  ) >(&OpenGl_Resource::Release),
             R"#(Release GPU resources. Notice that implementation should be SAFE for several consecutive calls (thus should invalidate internal structures / ids to avoid multiple-free errors).)#"  , py::arg("theGlCtx")
          )
        .def("EstimatedDataSize",
             (size_t (OpenGl_Resource::*)() const) static_cast<size_t (OpenGl_Resource::*)() const>(&OpenGl_Resource::EstimatedDataSize),
             R"#(Returns estimated GPU memory usage for holding data without considering overheads and allocation alignment rules.)#" 
          )
        .def("DumpJson",
             (void (OpenGl_Resource::*)( Standard_OStream & ,  int  ) const) static_cast<void (OpenGl_Resource::*)( Standard_OStream & ,  int  ) const>(&OpenGl_Resource::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_Resource::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_Resource::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_Resource::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_Resource::*)() const>(&OpenGl_Resource::DynamicType),
             R"#()#"
             
         )
;

    // Class OpenGl_SetOfPrograms from ./opencascade/OpenGl_SetOfShaderPrograms.hxx
    klass = m.attr("OpenGl_SetOfPrograms");


    // nested enums

    static_cast<py::class_<OpenGl_SetOfPrograms ,opencascade::handle<OpenGl_SetOfPrograms>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ChangeValue",
             (handle<OpenGl_ShaderProgram> & (OpenGl_SetOfPrograms::*)( int  ) ) static_cast<handle<OpenGl_ShaderProgram> & (OpenGl_SetOfPrograms::*)( int  ) >(&OpenGl_SetOfPrograms::ChangeValue),
             R"#(Access program by index)#"  , py::arg("theProgramBits")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_SetOfPrograms::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_SetOfPrograms::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_SetOfPrograms::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_SetOfPrograms::*)() const>(&OpenGl_SetOfPrograms::DynamicType),
             R"#()#"
             
         )
;

    // Class OpenGl_SetOfShaderPrograms from ./opencascade/OpenGl_SetOfShaderPrograms.hxx
    klass = m.attr("OpenGl_SetOfShaderPrograms");


    // nested enums

    static_cast<py::class_<OpenGl_SetOfShaderPrograms ,opencascade::handle<OpenGl_SetOfShaderPrograms>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<OpenGl_SetOfPrograms> & >()  , py::arg("thePrograms") )
    // custom constructors
    // methods
        .def("ChangeValue",
             (handle<OpenGl_ShaderProgram> & (OpenGl_SetOfShaderPrograms::*)( Graphic3d_TypeOfShadingModel ,  int  ) ) static_cast<handle<OpenGl_ShaderProgram> & (OpenGl_SetOfShaderPrograms::*)( Graphic3d_TypeOfShadingModel ,  int  ) >(&OpenGl_SetOfShaderPrograms::ChangeValue),
             R"#(Access program by index)#"  , py::arg("theShadingModel"),  py::arg("theProgramBits")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_SetOfShaderPrograms::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_SetOfShaderPrograms::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_SetOfShaderPrograms::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_SetOfShaderPrograms::*)() const>(&OpenGl_SetOfShaderPrograms::DynamicType),
             R"#()#"
             
         )
;

    // Class OpenGl_ShaderGrid from ./opencascade/OpenGl_ShaderGrid.hxx
    klass = m.attr("OpenGl_ShaderGrid");

    // default constructor
    register_default_constructor<OpenGl_ShaderGrid , shared_ptr<OpenGl_ShaderGrid>>(m,"OpenGl_ShaderGrid");

    // nested enums

    static_cast<py::class_<OpenGl_ShaderGrid , shared_ptr<OpenGl_ShaderGrid>  >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("IsShown",
             (bool (OpenGl_ShaderGrid::*)() const) static_cast<bool (OpenGl_ShaderGrid::*)() const>(&OpenGl_ShaderGrid::IsShown),
             R"#(Return TRUE if the grid is currently shown.)#" 
          )
        .def("IsBackground",
             (bool (OpenGl_ShaderGrid::*)() const) static_cast<bool (OpenGl_ShaderGrid::*)() const>(&OpenGl_ShaderGrid::IsBackground),
             R"#(Return TRUE if the grid is rendered as a background.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Params",
             ( const Aspect_GridParams & (OpenGl_ShaderGrid::*)() const) static_cast< const Aspect_GridParams & (OpenGl_ShaderGrid::*)() const>(&OpenGl_ShaderGrid::Params),
             R"#(Return current parameters.)#"
             
         )
;

    // Class OpenGl_ShaderManager from ./opencascade/OpenGl_ShaderManager.hxx
    klass = m.attr("OpenGl_ShaderManager");


    // nested enums

    static_cast<py::class_<OpenGl_ShaderManager ,opencascade::handle<OpenGl_ShaderManager>  , Graphic3d_ShaderManager >>(klass)
    // constructors
        .def(py::init< OpenGl_Context * >()  , py::arg("theContext") )
    // custom constructors
    // methods
        .def("clear",
             (void (OpenGl_ShaderManager::*)() ) static_cast<void (OpenGl_ShaderManager::*)() >(&OpenGl_ShaderManager::clear),
             R"#(Release all resources.)#" 
          )
        .def("UpdateSRgbState",
             (void (OpenGl_ShaderManager::*)() ) static_cast<void (OpenGl_ShaderManager::*)() >(&OpenGl_ShaderManager::UpdateSRgbState),
             R"#(Fetch sRGB state from caps and invalidates programs, if necessary.)#" 
          )
        .def("SetLocalOrigin",
             (void (OpenGl_ShaderManager::*)(  const gp_XYZ &  ) ) static_cast<void (OpenGl_ShaderManager::*)(  const gp_XYZ &  ) >(&OpenGl_ShaderManager::SetLocalOrigin),
             R"#(Setup local camera transformation for compensating float precision issues.)#"  , py::arg("theOrigin")
          )
        .def("LocalClippingPlaneW",
             (double (OpenGl_ShaderManager::*)(  const Graphic3d_ClipPlane &  ) const) static_cast<double (OpenGl_ShaderManager::*)(  const Graphic3d_ClipPlane &  ) const>(&OpenGl_ShaderManager::LocalClippingPlaneW),
             R"#(Return clipping plane W equation value moved considering local camera transformation.)#"  , py::arg("thePlane")
          )
        .def("Create",
             (bool (OpenGl_ShaderManager::*)(  const handle<Graphic3d_ShaderProgram> & ,  TCollection_AsciiString & ,  handle<OpenGl_ShaderProgram> &  ) ) static_cast<bool (OpenGl_ShaderManager::*)(  const handle<Graphic3d_ShaderProgram> & ,  TCollection_AsciiString & ,  handle<OpenGl_ShaderProgram> &  ) >(&OpenGl_ShaderManager::Create),
             R"#(Creates new shader program or re-use shared instance.)#"  , py::arg("theProxy"),  py::arg("theShareKey"),  py::arg("theProgram")
          )
        .def("IsEmpty",
             (bool (OpenGl_ShaderManager::*)() const) static_cast<bool (OpenGl_ShaderManager::*)() const>(&OpenGl_ShaderManager::IsEmpty),
             R"#(Returns true if no program objects are registered in the manager.)#" 
          )
        .def("BindFaceProgram",
             (bool (OpenGl_ShaderManager::*)(  const handle<OpenGl_TextureSet> & ,  Graphic3d_TypeOfShadingModel ,  Graphic3d_AlphaMode ,  bool ,  bool ,   const handle<OpenGl_ShaderProgram> &  ) ) static_cast<bool (OpenGl_ShaderManager::*)(  const handle<OpenGl_TextureSet> & ,  Graphic3d_TypeOfShadingModel ,  Graphic3d_AlphaMode ,  bool ,  bool ,   const handle<OpenGl_ShaderProgram> &  ) >(&OpenGl_ShaderManager::BindFaceProgram),
             R"#(Bind program for filled primitives rendering)#"  , py::arg("theTextures"),  py::arg("theShadingModel"),  py::arg("theAlphaMode"),  py::arg("theHasVertColor"),  py::arg("theEnableEnvMap"),  py::arg("theCustomProgram")
          )
        .def("BindFaceProgram",
             (bool (OpenGl_ShaderManager::*)(  const handle<OpenGl_TextureSet> & ,  Graphic3d_TypeOfShadingModel ,  Graphic3d_AlphaMode ,  Aspect_InteriorStyle ,  bool ,  bool ,  bool ,  bool ,   const handle<OpenGl_ShaderProgram> &  ) ) static_cast<bool (OpenGl_ShaderManager::*)(  const handle<OpenGl_TextureSet> & ,  Graphic3d_TypeOfShadingModel ,  Graphic3d_AlphaMode ,  Aspect_InteriorStyle ,  bool ,  bool ,  bool ,  bool ,   const handle<OpenGl_ShaderProgram> &  ) >(&OpenGl_ShaderManager::BindFaceProgram),
             R"#(Bind program for filled primitives rendering)#"  , py::arg("theTextures"),  py::arg("theShadingModel"),  py::arg("theAlphaMode"),  py::arg("theInteriorStyle"),  py::arg("theHasVertColor"),  py::arg("theToUseVertexColorForBackFaces"),  py::arg("theEnableEnvMap"),  py::arg("theEnableMeshEdges"),  py::arg("theCustomProgram")
          )
        .def("BindLineProgram",
             (bool (OpenGl_ShaderManager::*)(  const handle<OpenGl_TextureSet> & ,   const Aspect_TypeOfLine ,   const Graphic3d_TypeOfShadingModel ,   const Graphic3d_AlphaMode ,   const bool ,   const handle<OpenGl_ShaderProgram> &  ) ) static_cast<bool (OpenGl_ShaderManager::*)(  const handle<OpenGl_TextureSet> & ,   const Aspect_TypeOfLine ,   const Graphic3d_TypeOfShadingModel ,   const Graphic3d_AlphaMode ,   const bool ,   const handle<OpenGl_ShaderProgram> &  ) >(&OpenGl_ShaderManager::BindLineProgram),
             R"#(Bind program for line rendering)#"  , py::arg("theTextures"),  py::arg("theLineType"),  py::arg("theShadingModel"),  py::arg("theAlphaMode"),  py::arg("theHasVertColor"),  py::arg("theCustomProgram")
          )
        .def("BindMarkerProgram",
             (bool (OpenGl_ShaderManager::*)(  const handle<OpenGl_TextureSet> & ,  Graphic3d_TypeOfShadingModel ,  Graphic3d_AlphaMode ,  bool ,   const handle<OpenGl_ShaderProgram> &  ) ) static_cast<bool (OpenGl_ShaderManager::*)(  const handle<OpenGl_TextureSet> & ,  Graphic3d_TypeOfShadingModel ,  Graphic3d_AlphaMode ,  bool ,   const handle<OpenGl_ShaderProgram> &  ) >(&OpenGl_ShaderManager::BindMarkerProgram),
             R"#(Bind program for point rendering)#"  , py::arg("theTextures"),  py::arg("theShadingModel"),  py::arg("theAlphaMode"),  py::arg("theHasVertColor"),  py::arg("theCustomProgram")
          )
        .def("BindOutlineProgram",
             (bool (OpenGl_ShaderManager::*)() ) static_cast<bool (OpenGl_ShaderManager::*)() >(&OpenGl_ShaderManager::BindOutlineProgram),
             R"#(Bind program for outline rendering)#" 
          )
        .def("BindFboBlitProgram",
             (bool (OpenGl_ShaderManager::*)( int ,  bool  ) ) static_cast<bool (OpenGl_ShaderManager::*)( int ,  bool  ) >(&OpenGl_ShaderManager::BindFboBlitProgram),
             R"#(Bind program for FBO blit operation.)#"  , py::arg("theNbSamples"),  py::arg("theIsFallback_sRGB")
          )
        .def("BindOitCompositingProgram",
             (bool (OpenGl_ShaderManager::*)( bool  ) ) static_cast<bool (OpenGl_ShaderManager::*)( bool  ) >(&OpenGl_ShaderManager::BindOitCompositingProgram),
             R"#(Bind program for blended order-independent transparency buffers compositing.)#"  , py::arg("theIsMSAAEnabled")
          )
        .def("BindOitDepthPeelingBlendProgram",
             (bool (OpenGl_ShaderManager::*)( bool  ) ) static_cast<bool (OpenGl_ShaderManager::*)( bool  ) >(&OpenGl_ShaderManager::BindOitDepthPeelingBlendProgram),
             R"#(Bind program for Depth Peeling order-independent transparency back color blending.)#"  , py::arg("theIsMSAAEnabled")
          )
        .def("BindOitDepthPeelingFlushProgram",
             (bool (OpenGl_ShaderManager::*)( bool  ) ) static_cast<bool (OpenGl_ShaderManager::*)( bool  ) >(&OpenGl_ShaderManager::BindOitDepthPeelingFlushProgram),
             R"#(Bind program for Depth Peeling order-independent transparency flush.)#"  , py::arg("theIsMSAAEnabled")
          )
        .def("BindStereoProgram",
             (bool (OpenGl_ShaderManager::*)( Graphic3d_StereoMode  ) ) static_cast<bool (OpenGl_ShaderManager::*)( Graphic3d_StereoMode  ) >(&OpenGl_ShaderManager::BindStereoProgram),
             R"#(Bind program for rendering stereoscopic image.)#"  , py::arg("theStereoMode")
          )
        .def("BindBoundBoxProgram",
             (bool (OpenGl_ShaderManager::*)() ) static_cast<bool (OpenGl_ShaderManager::*)() >(&OpenGl_ShaderManager::BindBoundBoxProgram),
             R"#(Bind program for rendering bounding box.)#" 
          )
        .def("BindPBREnvBakingProgram",
             (bool (OpenGl_ShaderManager::*)( int  ) ) static_cast<bool (OpenGl_ShaderManager::*)( int  ) >(&OpenGl_ShaderManager::BindPBREnvBakingProgram),
             R"#(Bind program for IBL maps generation in PBR pipeline.)#"  , py::arg("theIndex")
          )
        .def("BindGridProgram",
             (bool (OpenGl_ShaderManager::*)() ) static_cast<bool (OpenGl_ShaderManager::*)() >(&OpenGl_ShaderManager::BindGridProgram),
             R"#(Compile (once) and bind the GPU grid shader program. Returns FALSE if shader compilation fails or the GAPI is not supported.)#" 
          )
        .def("UpdateLightSourceStateTo",
             (void (OpenGl_ShaderManager::*)(  const handle<Graphic3d_LightSet> & ,  int ,   const handle<OpenGl_ShadowMapArray> &  ) ) static_cast<void (OpenGl_ShaderManager::*)(  const handle<Graphic3d_LightSet> & ,  int ,   const handle<OpenGl_ShadowMapArray> &  ) >(&OpenGl_ShaderManager::UpdateLightSourceStateTo),
             R"#(Updates state of OCCT light sources.)#"  , py::arg("theLights"),  py::arg("theSpecIBLMapLevels"),  py::arg("theShadowMaps")
          )
        .def("SetCastShadows",
             (bool (OpenGl_ShaderManager::*)(  const bool  ) ) static_cast<bool (OpenGl_ShaderManager::*)(  const bool  ) >(&OpenGl_ShaderManager::SetCastShadows),
             R"#(Updates state of OCCT light sources to dynamically enable/disable shadowmap.)#"  , py::arg("theToCast")
          )
        .def("UpdateLightSourceState",
             (void (OpenGl_ShaderManager::*)() ) static_cast<void (OpenGl_ShaderManager::*)() >(&OpenGl_ShaderManager::UpdateLightSourceState),
             R"#(Invalidate state of OCCT light sources.)#" 
          )
        .def("PushLightSourceState",
             (void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> &  ) const) static_cast<void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> &  ) const>(&OpenGl_ShaderManager::PushLightSourceState),
             R"#(Pushes current state of OCCT light sources to specified program (only on state change). Note that light sources definition depends also on WorldViewState.)#"  , py::arg("theProgram")
          )
        .def("pushLightSourceState",
             (void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> &  ) const) static_cast<void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> &  ) const>(&OpenGl_ShaderManager::pushLightSourceState),
             R"#(Pushes current state of OCCT light sources to specified program.)#"  , py::arg("theProgram")
          )
        .def("UpdateProjectionStateTo",
             (void (OpenGl_ShaderManager::*)(  const NCollection_Mat4<float> &  ) ) static_cast<void (OpenGl_ShaderManager::*)(  const NCollection_Mat4<float> &  ) >(&OpenGl_ShaderManager::UpdateProjectionStateTo),
             R"#(Updates state of OCCT projection transform.)#"  , py::arg("theProjectionMatrix")
          )
        .def("PushProjectionState",
             (void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> &  ) const) static_cast<void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> &  ) const>(&OpenGl_ShaderManager::PushProjectionState),
             R"#(Pushes current state of OCCT projection transform to specified program (only on state change).)#"  , py::arg("theProgram")
          )
        .def("pushProjectionState",
             (void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> &  ) const) static_cast<void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> &  ) const>(&OpenGl_ShaderManager::pushProjectionState),
             R"#(Pushes current state of OCCT projection transform to specified program.)#"  , py::arg("theProgram")
          )
        .def("UpdateModelWorldStateTo",
             (void (OpenGl_ShaderManager::*)(  const NCollection_Mat4<float> &  ) ) static_cast<void (OpenGl_ShaderManager::*)(  const NCollection_Mat4<float> &  ) >(&OpenGl_ShaderManager::UpdateModelWorldStateTo),
             R"#(Updates state of OCCT model-world transform.)#"  , py::arg("theModelWorldMatrix")
          )
        .def("PushModelWorldState",
             (void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> &  ) const) static_cast<void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> &  ) const>(&OpenGl_ShaderManager::PushModelWorldState),
             R"#(Pushes current state of OCCT model-world transform to specified program (only on state change).)#"  , py::arg("theProgram")
          )
        .def("pushModelWorldState",
             (void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> &  ) const) static_cast<void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> &  ) const>(&OpenGl_ShaderManager::pushModelWorldState),
             R"#(Pushes current state of OCCT model-world transform to specified program.)#"  , py::arg("theProgram")
          )
        .def("UpdateWorldViewStateTo",
             (void (OpenGl_ShaderManager::*)(  const NCollection_Mat4<float> &  ) ) static_cast<void (OpenGl_ShaderManager::*)(  const NCollection_Mat4<float> &  ) >(&OpenGl_ShaderManager::UpdateWorldViewStateTo),
             R"#(Updates state of OCCT world-view transform.)#"  , py::arg("theWorldViewMatrix")
          )
        .def("PushWorldViewState",
             (void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> &  ) const) static_cast<void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> &  ) const>(&OpenGl_ShaderManager::PushWorldViewState),
             R"#(Pushes current state of OCCT world-view transform to specified program (only on state change).)#"  , py::arg("theProgram")
          )
        .def("pushWorldViewState",
             (void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> &  ) const) static_cast<void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> &  ) const>(&OpenGl_ShaderManager::pushWorldViewState),
             R"#(Pushes current state of OCCT world-view transform to specified program.)#"  , py::arg("theProgram")
          )
        .def("UpdateClippingState",
             (void (OpenGl_ShaderManager::*)() ) static_cast<void (OpenGl_ShaderManager::*)() >(&OpenGl_ShaderManager::UpdateClippingState),
             R"#(Updates state of OCCT clipping planes.)#" 
          )
        .def("RevertClippingState",
             (void (OpenGl_ShaderManager::*)() ) static_cast<void (OpenGl_ShaderManager::*)() >(&OpenGl_ShaderManager::RevertClippingState),
             R"#(Reverts state of OCCT clipping planes.)#" 
          )
        .def("PushClippingState",
             (void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> &  ) const) static_cast<void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> &  ) const>(&OpenGl_ShaderManager::PushClippingState),
             R"#(Pushes current state of OCCT clipping planes to specified program (only on state change).)#"  , py::arg("theProgram")
          )
        .def("pushClippingState",
             (void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> &  ) const) static_cast<void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> &  ) const>(&OpenGl_ShaderManager::pushClippingState),
             R"#(Pushes current state of OCCT clipping planes to specified program.)#"  , py::arg("theProgram")
          )
        .def("UpdateMaterialStateTo",
             (void (OpenGl_ShaderManager::*)(  const OpenGl_Material & ,   const float ,   const bool ,   const bool  ) ) static_cast<void (OpenGl_ShaderManager::*)(  const OpenGl_Material & ,   const float ,   const bool ,   const bool  ) >(&OpenGl_ShaderManager::UpdateMaterialStateTo),
             R"#(Updates state of material.)#"  , py::arg("theMat"),  py::arg("theAlphaCutoff"),  py::arg("theToDistinguish"),  py::arg("theToMapTexture")
          )
        .def("UpdateMaterialState",
             (void (OpenGl_ShaderManager::*)() ) static_cast<void (OpenGl_ShaderManager::*)() >(&OpenGl_ShaderManager::UpdateMaterialState),
             R"#(Updates state of material.)#" 
          )
        .def("PushMaterialState",
             (void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> &  ) const) static_cast<void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> &  ) const>(&OpenGl_ShaderManager::PushMaterialState),
             R"#(Pushes current state of material to specified program (only on state change).)#"  , py::arg("theProgram")
          )
        .def("pushMaterialState",
             (void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> &  ) const) static_cast<void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> &  ) const>(&OpenGl_ShaderManager::pushMaterialState),
             R"#(Pushes current state of material to specified program.)#"  , py::arg("theProgram")
          )
        .def("PushInteriorState",
             (void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> & ,   const handle<Graphic3d_Aspects> &  ) const) static_cast<void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> & ,   const handle<Graphic3d_Aspects> &  ) const>(&OpenGl_ShaderManager::PushInteriorState),
             R"#(Setup interior style line edges variables.)#"  , py::arg("theProgram"),  py::arg("theAspect")
          )
        .def("ResetOitState",
             (void (OpenGl_ShaderManager::*)() ) static_cast<void (OpenGl_ShaderManager::*)() >(&OpenGl_ShaderManager::ResetOitState),
             R"#(Reset the state of OIT rendering pass (only on state change).)#" 
          )
        .def("SetOitState",
             (void (OpenGl_ShaderManager::*)( Graphic3d_RenderTransparentMethod  ) ) static_cast<void (OpenGl_ShaderManager::*)( Graphic3d_RenderTransparentMethod  ) >(&OpenGl_ShaderManager::SetOitState),
             R"#(Set the state of OIT rendering pass (only on state change).)#"  , py::arg("theMode")
          )
        .def("SetWeighedOitState",
             (void (OpenGl_ShaderManager::*)( float  ) ) static_cast<void (OpenGl_ShaderManager::*)( float  ) >(&OpenGl_ShaderManager::SetWeighedOitState),
             R"#(Set the state of weighed OIT rendering pass (only on state change).)#"  , py::arg("theDepthFactor")
          )
        .def("PushOitState",
             (void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> &  ) const) static_cast<void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> &  ) const>(&OpenGl_ShaderManager::PushOitState),
             R"#(Pushes state of OIT uniforms to the specified program.)#"  , py::arg("theProgram")
          )
        .def("pushOitState",
             (void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> &  ) const) static_cast<void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> &  ) const>(&OpenGl_ShaderManager::pushOitState),
             R"#(Pushes state of OIT uniforms to the specified program.)#"  , py::arg("theProgram")
          )
        .def("PushState",
             (void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> & ,  Graphic3d_TypeOfShadingModel  ) const) static_cast<void (OpenGl_ShaderManager::*)(  const handle<OpenGl_ShaderProgram> & ,  Graphic3d_TypeOfShadingModel  ) const>(&OpenGl_ShaderManager::PushState),
             R"#(Pushes current state of OCCT graphics parameters to specified program.)#"  , py::arg("theProgram"),  py::arg("theShadingModel")=static_cast<Graphic3d_TypeOfShadingModel>(Graphic3d_TypeOfShadingModel_Unlit)
          )
        .def("SetContext",
             (void (OpenGl_ShaderManager::*)( OpenGl_Context *  ) ) static_cast<void (OpenGl_ShaderManager::*)( OpenGl_Context *  ) >(&OpenGl_ShaderManager::SetContext),
             R"#(Overwrites context)#"  , py::arg("theCtx")
          )
        .def("IsSameContext",
             (bool (OpenGl_ShaderManager::*)( OpenGl_Context *  ) const) static_cast<bool (OpenGl_ShaderManager::*)( OpenGl_Context *  ) const>(&OpenGl_ShaderManager::IsSameContext),
             R"#(Returns true when provided context is the same as used one by shader manager.)#"  , py::arg("theCtx")
          )
        .def("ChooseFaceShadingModel",
             (Graphic3d_TypeOfShadingModel (OpenGl_ShaderManager::*)( Graphic3d_TypeOfShadingModel ,  bool  ) const) static_cast<Graphic3d_TypeOfShadingModel (OpenGl_ShaderManager::*)( Graphic3d_TypeOfShadingModel ,  bool  ) const>(&OpenGl_ShaderManager::ChooseFaceShadingModel),
             R"#(Choose Shading Model for filled primitives. Fallbacks to FACET model if there are no normal attributes. Fallbacks to corresponding non-PBR models if PBR is unavailable.)#"  , py::arg("theCustomModel"),  py::arg("theHasNodalNormals")
          )
        .def("ChooseLineShadingModel",
             (Graphic3d_TypeOfShadingModel (OpenGl_ShaderManager::*)( Graphic3d_TypeOfShadingModel ,  bool  ) const) static_cast<Graphic3d_TypeOfShadingModel (OpenGl_ShaderManager::*)( Graphic3d_TypeOfShadingModel ,  bool  ) const>(&OpenGl_ShaderManager::ChooseLineShadingModel),
             R"#(Choose Shading Model for line primitives. Fallbacks to UNLIT model if there are no normal attributes. Fallbacks to corresponding non-PBR models if PBR is unavailable.)#"  , py::arg("theCustomModel"),  py::arg("theHasNodalNormals")
          )
        .def("ChooseMarkerShadingModel",
             (Graphic3d_TypeOfShadingModel (OpenGl_ShaderManager::*)( Graphic3d_TypeOfShadingModel ,  bool  ) const) static_cast<Graphic3d_TypeOfShadingModel (OpenGl_ShaderManager::*)( Graphic3d_TypeOfShadingModel ,  bool  ) const>(&OpenGl_ShaderManager::ChooseMarkerShadingModel),
             R"#(Choose Shading Model for Marker primitives.)#"  , py::arg("theCustomModel"),  py::arg("theHasNodalNormals")
          )
        .def("ShadingModel",
             (Graphic3d_TypeOfShadingModel (OpenGl_ShaderManager::*)() const) static_cast<Graphic3d_TypeOfShadingModel (OpenGl_ShaderManager::*)() const>(&OpenGl_ShaderManager::ShadingModel),
             R"#(Returns default Shading Model.)#" 
          )
        .def("SetShadingModel",
             (void (OpenGl_ShaderManager::*)(  const Graphic3d_TypeOfShadingModel  ) ) static_cast<void (OpenGl_ShaderManager::*)(  const Graphic3d_TypeOfShadingModel  ) >(&OpenGl_ShaderManager::SetShadingModel),
             R"#(Sets shading model.)#"  , py::arg("theModel")
          )
    // methods using call by reference i.s.o. return
        .def("Unregister",
             []( OpenGl_ShaderManager &self , TCollection_AsciiString & theShareKey,OpenGl_ShaderProgram& theProgram ){
                 handle<OpenGl_ShaderProgram>  theProgram_ptr; theProgram_ptr = &theProgram;

                 self.Unregister(theShareKey,theProgram_ptr);
                 return std::make_tuple(theProgram_ptr); },
             R"#(Unregisters specified shader program.)#"  , py::arg("theShareKey"),  py::arg("theProgram")
          )
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_ShaderManager::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_ShaderManager::get_type_descriptor),
                    R"#()#" 
          )
        .def_static("PBRShadingModelFallback_s",
                    (Graphic3d_TypeOfShadingModel (*)( Graphic3d_TypeOfShadingModel ,  bool  ) ) static_cast<Graphic3d_TypeOfShadingModel (*)( Graphic3d_TypeOfShadingModel ,  bool  ) >(&OpenGl_ShaderManager::PBRShadingModelFallback),
                    R"#(Resets PBR shading models to corresponding non-PBR ones if PBR is not allowed.)#"  , py::arg("theShadingModel"),  py::arg("theIsPbrAllowed")=static_cast<bool>(false)
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_ShaderManager::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_ShaderManager::*)() const>(&OpenGl_ShaderManager::DynamicType),
             R"#()#"
             
         )
       .def("LocalOrigin",
             ( const gp_XYZ & (OpenGl_ShaderManager::*)() const) static_cast< const gp_XYZ & (OpenGl_ShaderManager::*)() const>(&OpenGl_ShaderManager::LocalOrigin),
             R"#(Return local camera transformation.)#"
             
         )
       .def("ShaderPrograms",
             ( const NCollection_Sequence<handle<OpenGl_ShaderProgram>> & (OpenGl_ShaderManager::*)() const) static_cast< const NCollection_Sequence<handle<OpenGl_ShaderProgram>> & (OpenGl_ShaderManager::*)() const>(&OpenGl_ShaderManager::ShaderPrograms),
             R"#(Returns list of registered shader programs.)#"
             
         )
       .def("BoundBoxVertBuffer",
             ( const handle<OpenGl_VertexBuffer> & (OpenGl_ShaderManager::*)() const) static_cast< const handle<OpenGl_VertexBuffer> & (OpenGl_ShaderManager::*)() const>(&OpenGl_ShaderManager::BoundBoxVertBuffer),
             R"#(Returns bounding box vertex buffer.)#"
             
         )
       .def("GetBgCubeMapProgram",
             ( const handle<Graphic3d_ShaderProgram> & (OpenGl_ShaderManager::*)() ) static_cast< const handle<Graphic3d_ShaderProgram> & (OpenGl_ShaderManager::*)() >(&OpenGl_ShaderManager::GetBgCubeMapProgram),
             R"#(Generates shader program to render environment cubemap as background.)#"
             
         )
       .def("GetBgSkydomeProgram",
             ( const handle<Graphic3d_ShaderProgram> & (OpenGl_ShaderManager::*)() ) static_cast< const handle<Graphic3d_ShaderProgram> & (OpenGl_ShaderManager::*)() >(&OpenGl_ShaderManager::GetBgSkydomeProgram),
             R"#(Generates shader program to render skydome background.)#"
             
         )
       .def("GetColoredQuadProgram",
             ( const handle<Graphic3d_ShaderProgram> & (OpenGl_ShaderManager::*)() ) static_cast< const handle<Graphic3d_ShaderProgram> & (OpenGl_ShaderManager::*)() >(&OpenGl_ShaderManager::GetColoredQuadProgram),
             R"#(Generates shader program to render correctly colored quad.)#"
             
         )
       .def("LightSourceState",
             ( const OpenGl_LightSourceState & (OpenGl_ShaderManager::*)() const) static_cast< const OpenGl_LightSourceState & (OpenGl_ShaderManager::*)() const>(&OpenGl_ShaderManager::LightSourceState),
             R"#(Returns current state of OCCT light sources.)#"
             
         )
       .def("ProjectionState",
             ( const OpenGl_ProjectionState & (OpenGl_ShaderManager::*)() const) static_cast< const OpenGl_ProjectionState & (OpenGl_ShaderManager::*)() const>(&OpenGl_ShaderManager::ProjectionState),
             R"#(Returns current state of OCCT projection transform.)#"
             
         )
       .def("ModelWorldState",
             ( const OpenGl_ModelWorldState & (OpenGl_ShaderManager::*)() const) static_cast< const OpenGl_ModelWorldState & (OpenGl_ShaderManager::*)() const>(&OpenGl_ShaderManager::ModelWorldState),
             R"#(Returns current state of OCCT model-world transform.)#"
             
         )
       .def("WorldViewState",
             ( const OpenGl_WorldViewState & (OpenGl_ShaderManager::*)() const) static_cast< const OpenGl_WorldViewState & (OpenGl_ShaderManager::*)() const>(&OpenGl_ShaderManager::WorldViewState),
             R"#(Returns current state of OCCT world-view transform.)#"
             
         )
       .def("MaterialState",
             ( const OpenGl_MaterialState & (OpenGl_ShaderManager::*)() const) static_cast< const OpenGl_MaterialState & (OpenGl_ShaderManager::*)() const>(&OpenGl_ShaderManager::MaterialState),
             R"#(Returns current state of material.)#"
             
         )
       .def("OitState",
             ( const OpenGl_OitState & (OpenGl_ShaderManager::*)() const) static_cast< const OpenGl_OitState & (OpenGl_ShaderManager::*)() const>(&OpenGl_ShaderManager::OitState),
             R"#(Returns state of OIT uniforms.)#"
             
         )
;

    // Class OpenGl_ShaderUniformLocation from ./opencascade/OpenGl_ShaderProgram.hxx
    klass = m.attr("OpenGl_ShaderUniformLocation");


    // nested enums

    static_cast<py::class_<OpenGl_ShaderUniformLocation , shared_ptr<OpenGl_ShaderUniformLocation>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init< GLint >()  , py::arg("theLocation") )
    // custom constructors
    // methods
        .def("IsValid",
             (bool (OpenGl_ShaderUniformLocation::*)() const) static_cast<bool (OpenGl_ShaderUniformLocation::*)() const>(&OpenGl_ShaderUniformLocation::IsValid),
             R"#(Note you may safely put invalid location in functions like glUniform* - the data passed in will be silently ignored.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_ShadowMapArray from ./opencascade/OpenGl_ShadowMap.hxx
    klass = m.attr("OpenGl_ShadowMapArray");


    // nested enums

    static_cast<py::class_<OpenGl_ShadowMapArray ,opencascade::handle<OpenGl_ShadowMapArray>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Release",
             (void (OpenGl_ShadowMapArray::*)( OpenGl_Context *  ) ) static_cast<void (OpenGl_ShadowMapArray::*)( OpenGl_Context *  ) >(&OpenGl_ShadowMapArray::Release),
             R"#(Releases all OpenGL resources.)#"  , py::arg("theCtx")
          )
        .def("IsValid",
             (bool (OpenGl_ShadowMapArray::*)() const) static_cast<bool (OpenGl_ShadowMapArray::*)() const>(&OpenGl_ShadowMapArray::IsValid),
             R"#(Return TRUE if defined.)#" 
          )
        .def("EstimatedDataSize",
             (size_t (OpenGl_ShadowMapArray::*)() const) static_cast<size_t (OpenGl_ShadowMapArray::*)() const>(&OpenGl_ShadowMapArray::EstimatedDataSize),
             R"#(Returns estimated GPU memory usage for holding data without considering overheads and allocation alignment rules.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_StateCounter from ./opencascade/OpenGl_GraphicDriver.hxx
    klass = m.attr("OpenGl_StateCounter");


    // nested enums

    static_cast<py::class_<OpenGl_StateCounter , shared_ptr<OpenGl_StateCounter>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Increment",
             (size_t (OpenGl_StateCounter::*)() ) static_cast<size_t (OpenGl_StateCounter::*)() >(&OpenGl_StateCounter::Increment),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_StateInterface from ./opencascade/OpenGl_ShaderStates.hxx
    klass = m.attr("OpenGl_StateInterface");


    // nested enums

    static_cast<py::class_<OpenGl_StateInterface , shared_ptr<OpenGl_StateInterface>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Index",
             (size_t (OpenGl_StateInterface::*)() const) static_cast<size_t (OpenGl_StateInterface::*)() const>(&OpenGl_StateInterface::Index),
             R"#(Returns current state index.)#" 
          )
        .def("Update",
             (void (OpenGl_StateInterface::*)() ) static_cast<void (OpenGl_StateInterface::*)() >(&OpenGl_StateInterface::Update),
             R"#(Increment current state.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_Structure from ./opencascade/OpenGl_Structure.hxx
    klass = m.attr("OpenGl_Structure");


    // nested enums

    static_cast<py::class_<OpenGl_Structure ,opencascade::handle<OpenGl_Structure>  , Graphic3d_CStructure >>(klass)
    // constructors
        .def(py::init<  const handle<Graphic3d_StructureManager> & >()  , py::arg("theManager") )
    // custom constructors
    // methods
        .def("OnVisibilityChanged",
             (void (OpenGl_Structure::*)() ) static_cast<void (OpenGl_Structure::*)() >(&OpenGl_Structure::OnVisibilityChanged),
             R"#(Setup structure graphic state)#" 
          )
        .def("Clear",
             (void (OpenGl_Structure::*)() ) static_cast<void (OpenGl_Structure::*)() >(&OpenGl_Structure::Clear),
             R"#(Clear graphic data)#" 
          )
        .def("Connect",
             (void (OpenGl_Structure::*)( Graphic3d_CStructure &  ) ) static_cast<void (OpenGl_Structure::*)( Graphic3d_CStructure &  ) >(&OpenGl_Structure::Connect),
             R"#(Connect other structure to this one)#"  , py::arg("theStructure")
          )
        .def("Disconnect",
             (void (OpenGl_Structure::*)( Graphic3d_CStructure &  ) ) static_cast<void (OpenGl_Structure::*)( Graphic3d_CStructure &  ) >(&OpenGl_Structure::Disconnect),
             R"#(Disconnect other structure to this one)#"  , py::arg("theStructure")
          )
        .def("SetTransformation",
             (void (OpenGl_Structure::*)(  const handle<TopLoc_Datum3D> &  ) ) static_cast<void (OpenGl_Structure::*)(  const handle<TopLoc_Datum3D> &  ) >(&OpenGl_Structure::SetTransformation),
             R"#(Synchronize structure transformation)#"  , py::arg("theTrsf")
          )
        .def("SetTransformPersistence",
             (void (OpenGl_Structure::*)(  const handle<Graphic3d_TransformPers> &  ) ) static_cast<void (OpenGl_Structure::*)(  const handle<Graphic3d_TransformPers> &  ) >(&OpenGl_Structure::SetTransformPersistence),
             R"#(Set transformation persistence.)#"  , py::arg("theTrsfPers")
          )
        .def("SetZLayer",
             (void (OpenGl_Structure::*)(  const Graphic3d_ZLayerId  ) ) static_cast<void (OpenGl_Structure::*)(  const Graphic3d_ZLayerId  ) >(&OpenGl_Structure::SetZLayer),
             R"#(Set z layer ID to display the structure in specified layer)#"  , py::arg("theLayerIndex")
          )
        .def("GraphicHighlight",
             (void (OpenGl_Structure::*)(  const handle<Graphic3d_PresentationAttributes> &  ) ) static_cast<void (OpenGl_Structure::*)(  const handle<Graphic3d_PresentationAttributes> &  ) >(&OpenGl_Structure::GraphicHighlight),
             R"#(Highlights structure according to the given style and updates corresponding class fields (highlight status and style))#"  , py::arg("theStyle")
          )
        .def("GraphicUnhighlight",
             (void (OpenGl_Structure::*)() ) static_cast<void (OpenGl_Structure::*)() >(&OpenGl_Structure::GraphicUnhighlight),
             R"#(Unighlights structure and updates corresponding class fields (highlight status and style))#" 
          )
        .def("ShadowLink",
             (handle<Graphic3d_CStructure> (OpenGl_Structure::*)(  const handle<Graphic3d_StructureManager> &  ) const) static_cast<handle<Graphic3d_CStructure> (OpenGl_Structure::*)(  const handle<Graphic3d_StructureManager> &  ) const>(&OpenGl_Structure::ShadowLink),
             R"#(Create shadow link to this structure)#"  , py::arg("theManager")
          )
        .def("NewGroup",
             (handle<Graphic3d_Group> (OpenGl_Structure::*)(  const handle<Graphic3d_Structure> &  ) ) static_cast<handle<Graphic3d_Group> (OpenGl_Structure::*)(  const handle<Graphic3d_Structure> &  ) >(&OpenGl_Structure::NewGroup),
             R"#(Create new group within this structure)#"  , py::arg("theStruct")
          )
        .def("RemoveGroup",
             (void (OpenGl_Structure::*)(  const handle<Graphic3d_Group> &  ) ) static_cast<void (OpenGl_Structure::*)(  const handle<Graphic3d_Group> &  ) >(&OpenGl_Structure::RemoveGroup),
             R"#(Remove group from this structure)#"  , py::arg("theGroup")
          )
        .def("GlDriver",
             (OpenGl_GraphicDriver * (OpenGl_Structure::*)() const) static_cast<OpenGl_GraphicDriver * (OpenGl_Structure::*)() const>(&OpenGl_Structure::GlDriver),
             R"#(Access graphic driver)#" 
          )
        .def("Clear",
             (void (OpenGl_Structure::*)(  const handle<OpenGl_Context> &  ) ) static_cast<void (OpenGl_Structure::*)(  const handle<OpenGl_Context> &  ) >(&OpenGl_Structure::Clear),
             R"#()#"  , py::arg("theGlCtx")
          )
        .def("Render",
             (void (OpenGl_Structure::*)(  const handle<OpenGl_Workspace> &  ) const) static_cast<void (OpenGl_Structure::*)(  const handle<OpenGl_Workspace> &  ) const>(&OpenGl_Structure::Render),
             R"#(Renders the structure.)#"  , py::arg("theWorkspace")
          )
        .def("Release",
             (void (OpenGl_Structure::*)(  const handle<OpenGl_Context> &  ) ) static_cast<void (OpenGl_Structure::*)(  const handle<OpenGl_Context> &  ) >(&OpenGl_Structure::Release),
             R"#(Releases structure resources.)#"  , py::arg("theGlCtx")
          )
        .def("ReleaseGlResources",
             (void (OpenGl_Structure::*)(  const handle<OpenGl_Context> &  ) ) static_cast<void (OpenGl_Structure::*)(  const handle<OpenGl_Context> &  ) >(&OpenGl_Structure::ReleaseGlResources),
             R"#(This method releases GL resources without actual elements destruction. As result structure could be correctly destroyed layer without GL context (after last window was closed for example).)#"  , py::arg("theGlCtx")
          )
        .def("InstancedStructure",
             ( const OpenGl_Structure * (OpenGl_Structure::*)() const) static_cast< const OpenGl_Structure * (OpenGl_Structure::*)() const>(&OpenGl_Structure::InstancedStructure),
             R"#(Returns instanced OpenGL structure.)#" 
          )
        .def("ModificationState",
             (size_t (OpenGl_Structure::*)() const) static_cast<size_t (OpenGl_Structure::*)() const>(&OpenGl_Structure::ModificationState),
             R"#(Returns structure modification state (for ray-tracing).)#" 
          )
        .def("ResetModificationState",
             (void (OpenGl_Structure::*)() const) static_cast<void (OpenGl_Structure::*)() const>(&OpenGl_Structure::ResetModificationState),
             R"#(Resets structure modification state (for ray-tracing).)#" 
          )
        .def("updateLayerTransformation",
             (void (OpenGl_Structure::*)() ) static_cast<void (OpenGl_Structure::*)() >(&OpenGl_Structure::updateLayerTransformation),
             R"#(Update render transformation matrix.)#" 
          )
        .def("DumpJson",
             (void (OpenGl_Structure::*)( Standard_OStream & ,  int  ) const) static_cast<void (OpenGl_Structure::*)( Standard_OStream & ,  int  ) const>(&OpenGl_Structure::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_Structure::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_Structure::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_Structure::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_Structure::*)() const>(&OpenGl_Structure::DynamicType),
             R"#()#"
             
         )
;

    // Class OpenGl_TextBuilder from ./opencascade/OpenGl_TextBuilder.hxx
    klass = m.attr("OpenGl_TextBuilder");


    // nested enums

    static_cast<py::class_<OpenGl_TextBuilder , shared_ptr<OpenGl_TextBuilder>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Perform",
             (void (OpenGl_TextBuilder::*)(  const handle<Font_TextFormatter> & ,   const handle<OpenGl_Context> & ,  OpenGl_Font & ,  NCollection_DynamicArray<GLuint> & ,  NCollection_DynamicArray<handle<OpenGl_VertexBuffer>> & ,  NCollection_DynamicArray<handle<OpenGl_VertexBuffer>> &  ) ) static_cast<void (OpenGl_TextBuilder::*)(  const handle<Font_TextFormatter> & ,   const handle<OpenGl_Context> & ,  OpenGl_Font & ,  NCollection_DynamicArray<GLuint> & ,  NCollection_DynamicArray<handle<OpenGl_VertexBuffer>> & ,  NCollection_DynamicArray<handle<OpenGl_VertexBuffer>> &  ) >(&OpenGl_TextBuilder::Perform),
             R"#(Creates texture quads for the given text.)#"  , py::arg("theFormatter"),  py::arg("theContext"),  py::arg("theFont"),  py::arg("theTextures"),  py::arg("theVertsPerTexture"),  py::arg("theTCrdsPerTexture")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_TextureFormat from ./opencascade/OpenGl_TextureFormat.hxx
    klass = m.attr("OpenGl_TextureFormat");


    // nested enums

    static_cast<py::class_<OpenGl_TextureFormat , shared_ptr<OpenGl_TextureFormat>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("IsValid",
             (bool (OpenGl_TextureFormat::*)() const) static_cast<bool (OpenGl_TextureFormat::*)() const>(&OpenGl_TextureFormat::IsValid),
             R"#(Return TRUE if format is defined.)#" 
          )
        .def("InternalFormat",
             (GLint (OpenGl_TextureFormat::*)() const) static_cast<GLint (OpenGl_TextureFormat::*)() const>(&OpenGl_TextureFormat::InternalFormat),
             R"#(Returns OpenGL internal format of the pixel data (example: GL_R32F).)#" 
          )
        .def("SetInternalFormat",
             (void (OpenGl_TextureFormat::*)( GLint  ) ) static_cast<void (OpenGl_TextureFormat::*)( GLint  ) >(&OpenGl_TextureFormat::SetInternalFormat),
             R"#(Sets texture internal format.)#"  , py::arg("theInternal")
          )
        .def("PixelFormat",
             (GLenum (OpenGl_TextureFormat::*)() const) static_cast<GLenum (OpenGl_TextureFormat::*)() const>(&OpenGl_TextureFormat::PixelFormat),
             R"#(Returns OpenGL format of the pixel data (example: GL_RED).)#" 
          )
        .def("SetPixelFormat",
             (void (OpenGl_TextureFormat::*)( GLenum  ) ) static_cast<void (OpenGl_TextureFormat::*)( GLenum  ) >(&OpenGl_TextureFormat::SetPixelFormat),
             R"#(Sets OpenGL format of the pixel data.)#"  , py::arg("theFormat")
          )
        .def("DataType",
             (GLint (OpenGl_TextureFormat::*)() const) static_cast<GLint (OpenGl_TextureFormat::*)() const>(&OpenGl_TextureFormat::DataType),
             R"#(Returns OpenGL data type of the pixel data (example: GL_FLOAT).)#" 
          )
        .def("SetDataType",
             (void (OpenGl_TextureFormat::*)( GLint  ) ) static_cast<void (OpenGl_TextureFormat::*)( GLint  ) >(&OpenGl_TextureFormat::SetDataType),
             R"#(Sets OpenGL data type of the pixel data.)#"  , py::arg("theType")
          )
        .def("NbComponents",
             (GLint (OpenGl_TextureFormat::*)() const) static_cast<GLint (OpenGl_TextureFormat::*)() const>(&OpenGl_TextureFormat::NbComponents),
             R"#(Returns number of components (channels). Here for debugging purposes.)#" 
          )
        .def("SetNbComponents",
             (void (OpenGl_TextureFormat::*)( GLint  ) ) static_cast<void (OpenGl_TextureFormat::*)( GLint  ) >(&OpenGl_TextureFormat::SetNbComponents),
             R"#(Sets number of components (channels).)#"  , py::arg("theNbComponents")
          )
        .def("IsSRGB",
             (bool (OpenGl_TextureFormat::*)() const) static_cast<bool (OpenGl_TextureFormat::*)() const>(&OpenGl_TextureFormat::IsSRGB),
             R"#(Return TRUE if internal texture format is sRGB(A).)#" 
          )
        .def("ImageFormat",
             (Image_Format (OpenGl_TextureFormat::*)() const) static_cast<Image_Format (OpenGl_TextureFormat::*)() const>(&OpenGl_TextureFormat::ImageFormat),
             R"#(Returns image format (best match or Image_Format_UNKNOWN if no suitable fit).)#" 
          )
        .def("SetImageFormat",
             (void (OpenGl_TextureFormat::*)( Image_Format  ) ) static_cast<void (OpenGl_TextureFormat::*)( Image_Format  ) >(&OpenGl_TextureFormat::SetImageFormat),
             R"#(Sets image format.)#"  , py::arg("theFormat")
          )
        .def("Internal",
             (GLint (OpenGl_TextureFormat::*)() const) static_cast<GLint (OpenGl_TextureFormat::*)() const>(&OpenGl_TextureFormat::Internal),
             R"#(Returns OpenGL internal format of the pixel data (example: GL_R32F).)#" 
          )
        .def("Format",
             (GLenum (OpenGl_TextureFormat::*)() const) static_cast<GLenum (OpenGl_TextureFormat::*)() const>(&OpenGl_TextureFormat::Format),
             R"#(Returns OpenGL format of the pixel data (example: GL_RED).)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("FindFormat_s",
                    (OpenGl_TextureFormat (*)(  const handle<OpenGl_Context> & ,  Image_Format ,  bool  ) ) static_cast<OpenGl_TextureFormat (*)(  const handle<OpenGl_Context> & ,  Image_Format ,  bool  ) >(&OpenGl_TextureFormat::FindFormat),
                    R"#(Find texture format suitable to specified image format.)#"  , py::arg("theCtx"),  py::arg("theFormat"),  py::arg("theIsColorMap")
          )
        .def_static("FindSizedFormat_s",
                    (OpenGl_TextureFormat (*)(  const handle<OpenGl_Context> & ,  GLint  ) ) static_cast<OpenGl_TextureFormat (*)(  const handle<OpenGl_Context> & ,  GLint  ) >(&OpenGl_TextureFormat::FindSizedFormat),
                    R"#(Find texture format suitable to specified internal (sized) texture format.)#"  , py::arg("theCtx"),  py::arg("theSizedFormat")
          )
        .def_static("FindCompressedFormat_s",
                    (OpenGl_TextureFormat (*)(  const handle<OpenGl_Context> & ,  Image_CompressedFormat ,  bool  ) ) static_cast<OpenGl_TextureFormat (*)(  const handle<OpenGl_Context> & ,  Image_CompressedFormat ,  bool  ) >(&OpenGl_TextureFormat::FindCompressedFormat),
                    R"#(Find texture format suitable to specified compressed texture format.)#"  , py::arg("theCtx"),  py::arg("theFormat"),  py::arg("theIsColorMap")
          )
        .def_static("FormatFormat_s",
                    (TCollection_AsciiString (*)( GLint  ) ) static_cast<TCollection_AsciiString (*)( GLint  ) >(&OpenGl_TextureFormat::FormatFormat),
                    R"#(Format pixel format enumeration.)#"  , py::arg("theInternalFormat")
          )
        .def_static("FormatDataType_s",
                    (TCollection_AsciiString (*)( GLint  ) ) static_cast<TCollection_AsciiString (*)( GLint  ) >(&OpenGl_TextureFormat::FormatDataType),
                    R"#(Format data type enumeration.)#"  , py::arg("theDataType")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_TextureFormatSelector<GLbyte> from ./opencascade/OpenGl_TextureFormat.hxx
    klass = m.attr("OpenGl_TextureFormatSelector_GLbyte");

    // default constructor
    register_default_constructor<OpenGl_TextureFormatSelector<GLbyte> , shared_ptr<OpenGl_TextureFormatSelector<GLbyte>>>(m,"OpenGl_TextureFormatSelector_GLbyte");

    // nested enums

    static_cast<py::class_<OpenGl_TextureFormatSelector<GLbyte> , shared_ptr<OpenGl_TextureFormatSelector<GLbyte>>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("DataType_s",
                    (GLint (*)() ) static_cast<GLint (*)() >(&OpenGl_TextureFormatSelector<GLbyte>::DataType),
                    R"#()#" 
          )
        .def_static("Internal_s",
                    (GLint (*)( GLuint  ) ) static_cast<GLint (*)( GLuint  ) >(&OpenGl_TextureFormatSelector<GLbyte>::Internal),
                    R"#()#"  , py::arg("theChannels")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_TextureFormatSelector<GLfloat> from ./opencascade/OpenGl_TextureFormat.hxx
    klass = m.attr("OpenGl_TextureFormatSelector_GLfloat");

    // default constructor
    register_default_constructor<OpenGl_TextureFormatSelector<GLfloat> , shared_ptr<OpenGl_TextureFormatSelector<GLfloat>>>(m,"OpenGl_TextureFormatSelector_GLfloat");

    // nested enums

    static_cast<py::class_<OpenGl_TextureFormatSelector<GLfloat> , shared_ptr<OpenGl_TextureFormatSelector<GLfloat>>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("DataType_s",
                    (GLint (*)() ) static_cast<GLint (*)() >(&OpenGl_TextureFormatSelector<GLfloat>::DataType),
                    R"#()#" 
          )
        .def_static("Internal_s",
                    (GLint (*)( GLuint  ) ) static_cast<GLint (*)( GLuint  ) >(&OpenGl_TextureFormatSelector<GLfloat>::Internal),
                    R"#()#"  , py::arg("theChannels")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_TextureFormatSelector<GLint> from ./opencascade/OpenGl_TextureFormat.hxx
    klass = m.attr("OpenGl_TextureFormatSelector_GLint");

    // default constructor
    register_default_constructor<OpenGl_TextureFormatSelector<GLint> , shared_ptr<OpenGl_TextureFormatSelector<GLint>>>(m,"OpenGl_TextureFormatSelector_GLint");

    // nested enums

    static_cast<py::class_<OpenGl_TextureFormatSelector<GLint> , shared_ptr<OpenGl_TextureFormatSelector<GLint>>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("DataType_s",
                    (GLint (*)() ) static_cast<GLint (*)() >(&OpenGl_TextureFormatSelector<GLint>::DataType),
                    R"#()#" 
          )
        .def_static("Internal_s",
                    (GLint (*)( GLuint  ) ) static_cast<GLint (*)( GLuint  ) >(&OpenGl_TextureFormatSelector<GLint>::Internal),
                    R"#()#"  , py::arg("theChannels")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_TextureFormatSelector<GLshort> from ./opencascade/OpenGl_TextureFormat.hxx
    klass = m.attr("OpenGl_TextureFormatSelector_GLshort");

    // default constructor
    register_default_constructor<OpenGl_TextureFormatSelector<GLshort> , shared_ptr<OpenGl_TextureFormatSelector<GLshort>>>(m,"OpenGl_TextureFormatSelector_GLshort");

    // nested enums

    static_cast<py::class_<OpenGl_TextureFormatSelector<GLshort> , shared_ptr<OpenGl_TextureFormatSelector<GLshort>>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("DataType_s",
                    (GLint (*)() ) static_cast<GLint (*)() >(&OpenGl_TextureFormatSelector<GLshort>::DataType),
                    R"#()#" 
          )
        .def_static("Internal_s",
                    (GLint (*)( GLuint  ) ) static_cast<GLint (*)( GLuint  ) >(&OpenGl_TextureFormatSelector<GLshort>::Internal),
                    R"#()#"  , py::arg("theChannels")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_TextureFormatSelector<GLubyte> from ./opencascade/OpenGl_TextureFormat.hxx
    klass = m.attr("OpenGl_TextureFormatSelector_GLubyte");

    // default constructor
    register_default_constructor<OpenGl_TextureFormatSelector<GLubyte> , shared_ptr<OpenGl_TextureFormatSelector<GLubyte>>>(m,"OpenGl_TextureFormatSelector_GLubyte");

    // nested enums

    static_cast<py::class_<OpenGl_TextureFormatSelector<GLubyte> , shared_ptr<OpenGl_TextureFormatSelector<GLubyte>>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("DataType_s",
                    (GLint (*)() ) static_cast<GLint (*)() >(&OpenGl_TextureFormatSelector<GLubyte>::DataType),
                    R"#()#" 
          )
        .def_static("Internal_s",
                    (GLint (*)( GLuint  ) ) static_cast<GLint (*)( GLuint  ) >(&OpenGl_TextureFormatSelector<GLubyte>::Internal),
                    R"#()#"  , py::arg("theChannels")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_TextureFormatSelector<GLuint> from ./opencascade/OpenGl_TextureFormat.hxx
    klass = m.attr("OpenGl_TextureFormatSelector_GLuint");

    // default constructor
    register_default_constructor<OpenGl_TextureFormatSelector<GLuint> , shared_ptr<OpenGl_TextureFormatSelector<GLuint>>>(m,"OpenGl_TextureFormatSelector_GLuint");

    // nested enums

    static_cast<py::class_<OpenGl_TextureFormatSelector<GLuint> , shared_ptr<OpenGl_TextureFormatSelector<GLuint>>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("DataType_s",
                    (GLint (*)() ) static_cast<GLint (*)() >(&OpenGl_TextureFormatSelector<GLuint>::DataType),
                    R"#()#" 
          )
        .def_static("Internal_s",
                    (GLint (*)( GLuint  ) ) static_cast<GLint (*)( GLuint  ) >(&OpenGl_TextureFormatSelector<GLuint>::Internal),
                    R"#()#"  , py::arg("theChannels")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_TextureFormatSelector<GLushort> from ./opencascade/OpenGl_TextureFormat.hxx
    klass = m.attr("OpenGl_TextureFormatSelector_GLushort");

    // default constructor
    register_default_constructor<OpenGl_TextureFormatSelector<GLushort> , shared_ptr<OpenGl_TextureFormatSelector<GLushort>>>(m,"OpenGl_TextureFormatSelector_GLushort");

    // nested enums

    static_cast<py::class_<OpenGl_TextureFormatSelector<GLushort> , shared_ptr<OpenGl_TextureFormatSelector<GLushort>>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("DataType_s",
                    (GLint (*)() ) static_cast<GLint (*)() >(&OpenGl_TextureFormatSelector<GLushort>::DataType),
                    R"#()#" 
          )
        .def_static("Internal_s",
                    (GLint (*)( GLuint  ) ) static_cast<GLint (*)( GLuint  ) >(&OpenGl_TextureFormatSelector<GLushort>::Internal),
                    R"#()#"  , py::arg("theChannels")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_TextureSet from ./opencascade/OpenGl_TextureSet.hxx
    klass = m.attr("OpenGl_TextureSet");


    // nested enums

    static_cast<py::class_<OpenGl_TextureSet ,opencascade::handle<OpenGl_TextureSet>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<OpenGl_Texture> & >()  , py::arg("theTexture") )
        .def(py::init< int >()  , py::arg("theNbTextures") )
    // custom constructors
    // methods
        .def("TextureSetBits",
             (int (OpenGl_TextureSet::*)() const) static_cast<int (OpenGl_TextureSet::*)() const>(&OpenGl_TextureSet::TextureSetBits),
             R"#(Return texture units declared within the program,)#" 
          )
        .def("IsEmpty",
             (bool (OpenGl_TextureSet::*)() const) static_cast<bool (OpenGl_TextureSet::*)() const>(&OpenGl_TextureSet::IsEmpty),
             R"#(Return TRUE if texture array is empty.)#" 
          )
        .def("Size",
             (int (OpenGl_TextureSet::*)() const) static_cast<int (OpenGl_TextureSet::*)() const>(&OpenGl_TextureSet::Size),
             R"#(Return number of textures.)#" 
          )
        .def("Lower",
             (int (OpenGl_TextureSet::*)() const) static_cast<int (OpenGl_TextureSet::*)() const>(&OpenGl_TextureSet::Lower),
             R"#(Return the lower index in texture set.)#" 
          )
        .def("Upper",
             (int (OpenGl_TextureSet::*)() const) static_cast<int (OpenGl_TextureSet::*)() const>(&OpenGl_TextureSet::Upper),
             R"#(Return the upper index in texture set.)#" 
          )
        .def("FirstUnit",
             (Graphic3d_TextureUnit (OpenGl_TextureSet::*)() const) static_cast<Graphic3d_TextureUnit (OpenGl_TextureSet::*)() const>(&OpenGl_TextureSet::FirstUnit),
             R"#(Return the first texture unit.)#" 
          )
        .def("LastUnit",
             (Graphic3d_TextureUnit (OpenGl_TextureSet::*)() const) static_cast<Graphic3d_TextureUnit (OpenGl_TextureSet::*)() const>(&OpenGl_TextureSet::LastUnit),
             R"#(Return the last texture unit.)#" 
          )
        .def("Value",
             ( const handle<OpenGl_Texture> & (OpenGl_TextureSet::*)( int  ) const) static_cast< const handle<OpenGl_Texture> & (OpenGl_TextureSet::*)( int  ) const>(&OpenGl_TextureSet::Value),
             R"#(Return the texture at specified position within [0, Size()) range.)#"  , py::arg("theIndex")
          )
        .def("ChangeValue",
             (handle<OpenGl_Texture> & (OpenGl_TextureSet::*)( int  ) ) static_cast<handle<OpenGl_Texture> & (OpenGl_TextureSet::*)( int  ) >(&OpenGl_TextureSet::ChangeValue),
             R"#(Return the texture at specified position within [0, Size()) range.)#"  , py::arg("theIndex")
          )
        .def("IsModulate",
             (bool (OpenGl_TextureSet::*)() const) static_cast<bool (OpenGl_TextureSet::*)() const>(&OpenGl_TextureSet::IsModulate),
             R"#(Return TRUE if texture color modulation has been enabled for the first texture or if texture is not set at all.)#" 
          )
        .def("HasNonPointSprite",
             (bool (OpenGl_TextureSet::*)() const) static_cast<bool (OpenGl_TextureSet::*)() const>(&OpenGl_TextureSet::HasNonPointSprite),
             R"#(Return TRUE if other than point sprite textures are defined within point set.)#" 
          )
        .def("HasPointSprite",
             (bool (OpenGl_TextureSet::*)() const) static_cast<bool (OpenGl_TextureSet::*)() const>(&OpenGl_TextureSet::HasPointSprite),
             R"#(Return TRUE if last texture is a point sprite.)#" 
          )
        .def("InitZero",
             (void (OpenGl_TextureSet::*)() ) static_cast<void (OpenGl_TextureSet::*)() >(&OpenGl_TextureSet::InitZero),
             R"#(Nullify all handles.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_TextureSet::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_TextureSet::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_TextureSet::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_TextureSet::*)() const>(&OpenGl_TextureSet::DynamicType),
             R"#()#"
             
         )
       .def_property("ChangeTextureSetBits",
                     [](OpenGl_TextureSet& self){return self.ChangeTextureSetBits();} ,
                     [](OpenGl_TextureSet& self, int  val){self.ChangeTextureSetBits() = val;},                      R"#(Return texture units declared within the program,)#"
         )
       .def("First",
             ( const handle<OpenGl_Texture> & (OpenGl_TextureSet::*)() const) static_cast< const handle<OpenGl_Texture> & (OpenGl_TextureSet::*)() const>(&OpenGl_TextureSet::First),
             R"#(Return the first texture.)#"
             
         )
       .def("ChangeFirst",
             (handle<OpenGl_Texture> & (OpenGl_TextureSet::*)() ) static_cast<handle<OpenGl_Texture> & (OpenGl_TextureSet::*)() >(&OpenGl_TextureSet::ChangeFirst),
             R"#(Return the first texture.)#"
             
         )
       .def("Last",
             ( const handle<OpenGl_Texture> & (OpenGl_TextureSet::*)() const) static_cast< const handle<OpenGl_Texture> & (OpenGl_TextureSet::*)() const>(&OpenGl_TextureSet::Last),
             R"#(Return the last texture.)#"
             
         )
       .def("ChangeLast",
             (handle<OpenGl_Texture> & (OpenGl_TextureSet::*)() ) static_cast<handle<OpenGl_Texture> & (OpenGl_TextureSet::*)() >(&OpenGl_TextureSet::ChangeLast),
             R"#(Return the last texture.)#"
             
         )
       .def("ChangeLastUnit",
             (Graphic3d_TextureUnit & (OpenGl_TextureSet::*)() ) static_cast<Graphic3d_TextureUnit & (OpenGl_TextureSet::*)() >(&OpenGl_TextureSet::ChangeLastUnit),
             R"#(Return the last texture unit.)#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class OpenGl_TextureSetPairIterator from ./opencascade/OpenGl_TextureSetPairIterator.hxx
    klass = m.attr("OpenGl_TextureSetPairIterator");


    // nested enums

    static_cast<py::class_<OpenGl_TextureSetPairIterator , shared_ptr<OpenGl_TextureSetPairIterator>  >>(klass)
    // constructors
        .def(py::init<  const handle<OpenGl_TextureSet> &, const handle<OpenGl_TextureSet> & >()  , py::arg("theSet1"),  py::arg("theSet2") )
    // custom constructors
    // methods
        .def("More",
             (bool (OpenGl_TextureSetPairIterator::*)() const) static_cast<bool (OpenGl_TextureSetPairIterator::*)() const>(&OpenGl_TextureSetPairIterator::More),
             R"#(Return TRUE if there are more texture units to pass through.)#" 
          )
        .def("Unit",
             (Graphic3d_TextureUnit (OpenGl_TextureSetPairIterator::*)() const) static_cast<Graphic3d_TextureUnit (OpenGl_TextureSetPairIterator::*)() const>(&OpenGl_TextureSetPairIterator::Unit),
             R"#(Return current texture unit.)#" 
          )
        .def("Texture1",
             ( const OpenGl_Texture * (OpenGl_TextureSetPairIterator::*)() const) static_cast< const OpenGl_Texture * (OpenGl_TextureSetPairIterator::*)() const>(&OpenGl_TextureSetPairIterator::Texture1),
             R"#(Access texture from first texture set.)#" 
          )
        .def("Texture2",
             ( const OpenGl_Texture * (OpenGl_TextureSetPairIterator::*)() const) static_cast< const OpenGl_Texture * (OpenGl_TextureSetPairIterator::*)() const>(&OpenGl_TextureSetPairIterator::Texture2),
             R"#(Access texture from second texture set.)#" 
          )
        .def("Next",
             (void (OpenGl_TextureSetPairIterator::*)() ) static_cast<void (OpenGl_TextureSetPairIterator::*)() >(&OpenGl_TextureSetPairIterator::Next),
             R"#(Move iterator position to the next pair.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_TileSampler from ./opencascade/OpenGl_TileSampler.hxx
    klass = m.attr("OpenGl_TileSampler");


    // nested enums

    static_cast<py::class_<OpenGl_TileSampler , shared_ptr<OpenGl_TileSampler>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("TileSize",
             (NCollection_Vec2<int> (OpenGl_TileSampler::*)() const) static_cast<NCollection_Vec2<int> (OpenGl_TileSampler::*)() const>(&OpenGl_TileSampler::TileSize),
             R"#(Size of individual tile in pixels.)#" 
          )
        .def("VarianceScaleFactor",
             (float (OpenGl_TileSampler::*)() const) static_cast<float (OpenGl_TileSampler::*)() const>(&OpenGl_TileSampler::VarianceScaleFactor),
             R"#(Scale factor for quantization of visual error (float) into signed integer.)#" 
          )
        .def("NbTilesX",
             (int (OpenGl_TileSampler::*)() const) static_cast<int (OpenGl_TileSampler::*)() const>(&OpenGl_TileSampler::NbTilesX),
             R"#(Returns number of tiles in X dimension.)#" 
          )
        .def("NbTilesY",
             (int (OpenGl_TileSampler::*)() const) static_cast<int (OpenGl_TileSampler::*)() const>(&OpenGl_TileSampler::NbTilesY),
             R"#(Returns number of tiles in Y dimension.)#" 
          )
        .def("NbTiles",
             (int (OpenGl_TileSampler::*)() const) static_cast<int (OpenGl_TileSampler::*)() const>(&OpenGl_TileSampler::NbTiles),
             R"#(Returns total number of tiles in viewport.)#" 
          )
        .def("NbOffsetTiles",
             (NCollection_Vec2<int> (OpenGl_TileSampler::*)( bool  ) const) static_cast<NCollection_Vec2<int> (OpenGl_TileSampler::*)( bool  ) const>(&OpenGl_TileSampler::NbOffsetTiles),
             R"#(Number of tiles within offsets texture.)#"  , py::arg("theAdaptive")
          )
        .def("NbOffsetTilesMax",
             (NCollection_Vec2<int> (OpenGl_TileSampler::*)() const) static_cast<NCollection_Vec2<int> (OpenGl_TileSampler::*)() const>(&OpenGl_TileSampler::NbOffsetTilesMax),
             R"#(Maximum number of tiles within offsets texture.)#" 
          )
        .def("OffsetTilesViewport",
             (NCollection_Vec2<int> (OpenGl_TileSampler::*)( bool  ) const) static_cast<NCollection_Vec2<int> (OpenGl_TileSampler::*)( bool  ) const>(&OpenGl_TileSampler::OffsetTilesViewport),
             R"#(Viewport for rendering using offsets texture.)#"  , py::arg("theAdaptive")
          )
        .def("OffsetTilesViewportMax",
             (NCollection_Vec2<int> (OpenGl_TileSampler::*)() const) static_cast<NCollection_Vec2<int> (OpenGl_TileSampler::*)() const>(&OpenGl_TileSampler::OffsetTilesViewportMax),
             R"#(Maximum viewport for rendering using offsets texture.)#" 
          )
        .def("MaxTileSamples",
             (int (OpenGl_TileSampler::*)() const) static_cast<int (OpenGl_TileSampler::*)() const>(&OpenGl_TileSampler::MaxTileSamples),
             R"#(Return maximum number of samples per tile.)#" 
          )
        .def("SetSize",
             (void (OpenGl_TileSampler::*)(  const Graphic3d_RenderingParams & ,   const NCollection_Vec2<int> &  ) ) static_cast<void (OpenGl_TileSampler::*)(  const Graphic3d_RenderingParams & ,   const NCollection_Vec2<int> &  ) >(&OpenGl_TileSampler::SetSize),
             R"#(Specifies size of ray-tracing viewport and recomputes tile size.)#"  , py::arg("theParams"),  py::arg("theSize")
          )
        .def("GrabVarianceMap",
             (void (OpenGl_TileSampler::*)(  const handle<OpenGl_Context> & ,   const handle<OpenGl_Texture> &  ) ) static_cast<void (OpenGl_TileSampler::*)(  const handle<OpenGl_Context> & ,   const handle<OpenGl_Texture> &  ) >(&OpenGl_TileSampler::GrabVarianceMap),
             R"#(Fetches current error estimation from the GPU and builds 2D discrete distribution for tile sampling.)#"  , py::arg("theContext"),  py::arg("theTexture")
          )
        .def("Reset",
             (void (OpenGl_TileSampler::*)() ) static_cast<void (OpenGl_TileSampler::*)() >(&OpenGl_TileSampler::Reset),
             R"#(Resets (restart) tile sampler to initial state.)#" 
          )
        .def("UploadSamples",
             (bool (OpenGl_TileSampler::*)(  const handle<OpenGl_Context> & ,   const handle<OpenGl_Texture> & ,   const bool  ) ) static_cast<bool (OpenGl_TileSampler::*)(  const handle<OpenGl_Context> & ,   const handle<OpenGl_Texture> & ,   const bool  ) >(&OpenGl_TileSampler::UploadSamples),
             R"#(Uploads tile samples to the given OpenGL texture.)#"  , py::arg("theContext"),  py::arg("theSamplesTexture"),  py::arg("theAdaptive")
          )
        .def("UploadOffsets",
             (bool (OpenGl_TileSampler::*)(  const handle<OpenGl_Context> & ,   const handle<OpenGl_Texture> & ,   const bool  ) ) static_cast<bool (OpenGl_TileSampler::*)(  const handle<OpenGl_Context> & ,   const handle<OpenGl_Texture> & ,   const bool  ) >(&OpenGl_TileSampler::UploadOffsets),
             R"#(Uploads offsets of sampled tiles to the given OpenGL texture.)#"  , py::arg("theContext"),  py::arg("theOffsetsTexture"),  py::arg("theAdaptive")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("ViewSize",
             ( const NCollection_Vec2<int> & (OpenGl_TileSampler::*)() const) static_cast< const NCollection_Vec2<int> & (OpenGl_TileSampler::*)() const>(&OpenGl_TileSampler::ViewSize),
             R"#(Returns ray-tracing viewport.)#"
             
         )
;

    // Class OpenGl_TriangleSet from ./opencascade/OpenGl_SceneGeometry.hxx
    klass = m.attr("OpenGl_TriangleSet");


    // nested enums

    static_cast<py::class_<OpenGl_TriangleSet , shared_ptr<OpenGl_TriangleSet>  , OpenGl_BVHTriangulation3f >>(klass)
    // constructors
        .def(py::init<  const size_t, const handle<BVH_Builder<float, 3>> & >()  , py::arg("theArrayID"),  py::arg("theBuilder") )
    // custom constructors
    // methods
        .def("AssociatedPArrayID",
             (size_t (OpenGl_TriangleSet::*)() const) static_cast<size_t (OpenGl_TriangleSet::*)() const>(&OpenGl_TriangleSet::AssociatedPArrayID),
             R"#(Returns ID of associated primitive array.)#" 
          )
        .def("MaterialIndex",
             (int (OpenGl_TriangleSet::*)() const) static_cast<int (OpenGl_TriangleSet::*)() const>(&OpenGl_TriangleSet::MaterialIndex),
             R"#(Returns material index of triangle set.)#" 
          )
        .def("SetMaterialIndex",
             (void (OpenGl_TriangleSet::*)( int  ) ) static_cast<void (OpenGl_TriangleSet::*)( int  ) >(&OpenGl_TriangleSet::SetMaterialIndex),
             R"#(Sets material index for entire triangle set.)#"  , py::arg("theMatID")
          )
        .def("Box",
             (typename BVH_Set<float, 3>::BVH_BoxNt (OpenGl_TriangleSet::*)() const) static_cast<typename BVH_Set<float, 3>::BVH_BoxNt (OpenGl_TriangleSet::*)() const>(&OpenGl_TriangleSet::Box),
             R"#(Returns AABB of primitive set.)#" 
          )
        .def("Center",
             (float (OpenGl_TriangleSet::*)(  const int ,   const int  ) const) static_cast<float (OpenGl_TriangleSet::*)(  const int ,   const int  ) const>(&OpenGl_TriangleSet::Center),
             R"#(Returns centroid position along the given axis.)#"  , py::arg("theIndex"),  py::arg("theAxis")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_TriangleSet::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_TriangleSet::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_TriangleSet::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_TriangleSet::*)() const>(&OpenGl_TriangleSet::DynamicType),
             R"#()#"
             
         )
       .def("QuadBVH",
             ( const QuadBvhHandle & (OpenGl_TriangleSet::*)() ) static_cast< const QuadBvhHandle & (OpenGl_TriangleSet::*)() >(&OpenGl_TriangleSet::QuadBVH),
             R"#(Returns quad BVH (QBVH) tree produced from binary BVH.)#"
             
         )
;

    // Class OpenGl_View from ./opencascade/OpenGl_View.hxx
    klass = m.attr("OpenGl_View");


    // nested enums

    static_cast<py::class_<OpenGl_View ,opencascade::handle<OpenGl_View>  , Graphic3d_CView >>(klass)
    // constructors
        .def(py::init<  const handle<Graphic3d_StructureManager> &, const handle<OpenGl_GraphicDriver> &, const handle<OpenGl_Caps> &,OpenGl_StateCounter * >()  , py::arg("theMgr"),  py::arg("theDriver"),  py::arg("theCaps"),  py::arg("theCounter") )
    // custom constructors
    // methods
        .def("ReleaseGlResources",
             (void (OpenGl_View::*)(  const handle<OpenGl_Context> &  ) ) static_cast<void (OpenGl_View::*)(  const handle<OpenGl_Context> &  ) >(&OpenGl_View::ReleaseGlResources),
             R"#(Release OpenGL resources.)#"  , py::arg("theCtx")
          )
        .def("Remove",
             (void (OpenGl_View::*)() ) static_cast<void (OpenGl_View::*)() >(&OpenGl_View::Remove),
             R"#(Deletes and erases the view.)#" 
          )
        .def("SetImmediateModeDrawToFront",
             (bool (OpenGl_View::*)(  const bool  ) ) static_cast<bool (OpenGl_View::*)(  const bool  ) >(&OpenGl_View::SetImmediateModeDrawToFront),
             R"#(Returns previous mode.)#"  , py::arg("theDrawToFrontBuffer")
          )
        .def("SetWindow",
             (void (OpenGl_View::*)(  const handle<Graphic3d_CView> & ,   const handle<Aspect_Window> & ,   const Aspect_RenderingContext  ) ) static_cast<void (OpenGl_View::*)(  const handle<Graphic3d_CView> & ,   const handle<Aspect_Window> & ,   const Aspect_RenderingContext  ) >(&OpenGl_View::SetWindow),
             R"#(Creates and maps rendering window to the view.)#"  , py::arg("theParentVIew"),  py::arg("theWindow"),  py::arg("theContext")
          )
        .def("Window",
             (handle<Aspect_Window> (OpenGl_View::*)() const) static_cast<handle<Aspect_Window> (OpenGl_View::*)() const>(&OpenGl_View::Window),
             R"#(Returns window associated with the view.)#" 
          )
        .def("IsDefined",
             (bool (OpenGl_View::*)() const) static_cast<bool (OpenGl_View::*)() const>(&OpenGl_View::IsDefined),
             R"#(Returns True if the window associated to the view is defined.)#" 
          )
        .def("Resized",
             (void (OpenGl_View::*)() ) static_cast<void (OpenGl_View::*)() >(&OpenGl_View::Resized),
             R"#(Handle changing size of the rendering window.)#" 
          )
        .def("Redraw",
             (void (OpenGl_View::*)() ) static_cast<void (OpenGl_View::*)() >(&OpenGl_View::Redraw),
             R"#(Redraw content of the view.)#" 
          )
        .def("RedrawImmediate",
             (void (OpenGl_View::*)() ) static_cast<void (OpenGl_View::*)() >(&OpenGl_View::RedrawImmediate),
             R"#(Redraw immediate content of the view.)#" 
          )
        .def("Invalidate",
             (void (OpenGl_View::*)() ) static_cast<void (OpenGl_View::*)() >(&OpenGl_View::Invalidate),
             R"#(Marks BVH tree for given priority list as dirty and marks primitive set for rebuild.)#" 
          )
        .def("IsInvalidated",
             (bool (OpenGl_View::*)() ) static_cast<bool (OpenGl_View::*)() >(&OpenGl_View::IsInvalidated),
             R"#(Return true if view content cache has been invalidated.)#" 
          )
        .def("BufferDump",
             (bool (OpenGl_View::*)( Image_PixMap & ,   const Graphic3d_BufferType &  ) ) static_cast<bool (OpenGl_View::*)( Image_PixMap & ,   const Graphic3d_BufferType &  ) >(&OpenGl_View::BufferDump),
             R"#(Dump active rendering buffer into specified memory buffer. In Ray-Tracing allow to get a raw HDR buffer using Graphic3d_BT_RGB_RayTraceHdrLeft buffer type, only Left view will be dumped ignoring stereoscopic parameter.)#"  , py::arg("theImage"),  py::arg("theBufferType")
          )
        .def("ShadowMapDump",
             (bool (OpenGl_View::*)( Image_PixMap & ,   const TCollection_AsciiString &  ) ) static_cast<bool (OpenGl_View::*)( Image_PixMap & ,   const TCollection_AsciiString &  ) >(&OpenGl_View::ShadowMapDump),
             R"#(Dumps the graphical contents of a shadowmap framebuffer into an image.)#"  , py::arg("theImage"),  py::arg("theLightName")
          )
        .def("InvalidateBVHData",
             (void (OpenGl_View::*)(  const Graphic3d_ZLayerId  ) ) static_cast<void (OpenGl_View::*)(  const Graphic3d_ZLayerId  ) >(&OpenGl_View::InvalidateBVHData),
             R"#(Marks BVH tree and the set of BVH primitives of correspondent priority list with id theLayerId as outdated.)#"  , py::arg("theLayerId")
          )
        .def("InsertLayerBefore",
             (void (OpenGl_View::*)(  const Graphic3d_ZLayerId ,   const Graphic3d_ZLayerSettings & ,   const Graphic3d_ZLayerId  ) ) static_cast<void (OpenGl_View::*)(  const Graphic3d_ZLayerId ,   const Graphic3d_ZLayerSettings & ,   const Graphic3d_ZLayerId  ) >(&OpenGl_View::InsertLayerBefore),
             R"#(Add a layer to the view.)#"  , py::arg("theLayerId"),  py::arg("theSettings"),  py::arg("theLayerAfter")
          )
        .def("InsertLayerAfter",
             (void (OpenGl_View::*)(  const Graphic3d_ZLayerId ,   const Graphic3d_ZLayerSettings & ,   const Graphic3d_ZLayerId  ) ) static_cast<void (OpenGl_View::*)(  const Graphic3d_ZLayerId ,   const Graphic3d_ZLayerSettings & ,   const Graphic3d_ZLayerId  ) >(&OpenGl_View::InsertLayerAfter),
             R"#(Add a layer to the view.)#"  , py::arg("theNewLayerId"),  py::arg("theSettings"),  py::arg("theLayerBefore")
          )
        .def("RemoveZLayer",
             (void (OpenGl_View::*)(  const Graphic3d_ZLayerId  ) ) static_cast<void (OpenGl_View::*)(  const Graphic3d_ZLayerId  ) >(&OpenGl_View::RemoveZLayer),
             R"#(Remove a z layer with the given ID.)#"  , py::arg("theLayerId")
          )
        .def("SetZLayerSettings",
             (void (OpenGl_View::*)(  const Graphic3d_ZLayerId ,   const Graphic3d_ZLayerSettings &  ) ) static_cast<void (OpenGl_View::*)(  const Graphic3d_ZLayerId ,   const Graphic3d_ZLayerSettings &  ) >(&OpenGl_View::SetZLayerSettings),
             R"#(Sets the settings for a single Z layer of specified view.)#"  , py::arg("theLayerId"),  py::arg("theSettings")
          )
        .def("ZLayerMax",
             (int (OpenGl_View::*)() const) static_cast<int (OpenGl_View::*)() const>(&OpenGl_View::ZLayerMax),
             R"#(Returns the maximum Z layer ID. First layer ID is Graphic3d_ZLayerId_Default, last ID is ZLayerMax().)#" 
          )
        .def("Layer",
             (handle<Graphic3d_Layer> (OpenGl_View::*)(  const Graphic3d_ZLayerId  ) const) static_cast<handle<Graphic3d_Layer> (OpenGl_View::*)(  const Graphic3d_ZLayerId  ) const>(&OpenGl_View::Layer),
             R"#(Returns layer with given ID or NULL if undefined.)#"  , py::arg("theLayerId")
          )
        .def("MinMaxValues",
             (Bnd_Box (OpenGl_View::*)(  const bool  ) const) static_cast<Bnd_Box (OpenGl_View::*)(  const bool  ) const>(&OpenGl_View::MinMaxValues),
             R"#(Returns the bounding box of all structures displayed in the view. If theToIncludeAuxiliary is TRUE, then the boundary box also includes minimum and maximum limits of graphical elements forming parts of infinite and other auxiliary structures.)#"  , py::arg("theToIncludeAuxiliary")
          )
        .def("ZFitAllBounds",
             (void (OpenGl_View::*)( Bnd_Box & ,  Bnd_Box &  ) const) static_cast<void (OpenGl_View::*)( Bnd_Box & ,  Bnd_Box &  ) const>(&OpenGl_View::ZFitAllBounds),
             R"#(Return primary and graphical bounding boxes used by camera Z fitting.)#"  , py::arg("thePrimaryBox"),  py::arg("theGraphicBox")
          )
        .def("FBO",
             (handle<Standard_Transient> (OpenGl_View::*)() const) static_cast<handle<Standard_Transient> (OpenGl_View::*)() const>(&OpenGl_View::FBO),
             R"#(Returns pointer to an assigned framebuffer object.)#" 
          )
        .def("SetFBO",
             (void (OpenGl_View::*)(  const handle<Standard_Transient> &  ) ) static_cast<void (OpenGl_View::*)(  const handle<Standard_Transient> &  ) >(&OpenGl_View::SetFBO),
             R"#(Sets framebuffer object for offscreen rendering.)#"  , py::arg("theFbo")
          )
        .def("FBOCreate",
             (handle<Standard_Transient> (OpenGl_View::*)(  const int ,   const int  ) ) static_cast<handle<Standard_Transient> (OpenGl_View::*)(  const int ,   const int  ) >(&OpenGl_View::FBOCreate),
             R"#(Generate offscreen FBO in the graphic library. If not supported on hardware returns NULL.)#"  , py::arg("theWidth"),  py::arg("theHeight")
          )
        .def("FBOChangeViewport",
             (void (OpenGl_View::*)(  const handle<Standard_Transient> & ,   const int ,   const int  ) ) static_cast<void (OpenGl_View::*)(  const handle<Standard_Transient> & ,   const int ,   const int  ) >(&OpenGl_View::FBOChangeViewport),
             R"#(Change offscreen FBO viewport.)#"  , py::arg("theFbo"),  py::arg("theWidth"),  py::arg("theHeight")
          )
        .def("GradientBackground",
             (Aspect_GradientBackground (OpenGl_View::*)() const) static_cast<Aspect_GradientBackground (OpenGl_View::*)() const>(&OpenGl_View::GradientBackground),
             R"#(Returns gradient background fill colors.)#" 
          )
        .def("SetGradientBackground",
             (void (OpenGl_View::*)(  const Aspect_GradientBackground &  ) ) static_cast<void (OpenGl_View::*)(  const Aspect_GradientBackground &  ) >(&OpenGl_View::SetGradientBackground),
             R"#(Sets gradient background fill colors.)#"  , py::arg("theBackground")
          )
        .def("SetBackgroundImage",
             (void (OpenGl_View::*)(  const handle<Graphic3d_TextureMap> & ,  bool  ) ) static_cast<void (OpenGl_View::*)(  const handle<Graphic3d_TextureMap> & ,  bool  ) >(&OpenGl_View::SetBackgroundImage),
             R"#(Sets image texture or environment cubemap as background.)#"  , py::arg("theTextureMap"),  py::arg("theToUpdatePBREnv")=static_cast<bool>(true)
          )
        .def("SetTextureEnv",
             (void (OpenGl_View::*)(  const handle<Graphic3d_TextureEnv> &  ) ) static_cast<void (OpenGl_View::*)(  const handle<Graphic3d_TextureEnv> &  ) >(&OpenGl_View::SetTextureEnv),
             R"#(Sets environment texture for the view.)#"  , py::arg("theTextureEnv")
          )
        .def("BackgroundImageStyle",
             (Aspect_FillMethod (OpenGl_View::*)() const) static_cast<Aspect_FillMethod (OpenGl_View::*)() const>(&OpenGl_View::BackgroundImageStyle),
             R"#(Returns background image fill style.)#" 
          )
        .def("SetBackgroundImageStyle",
             (void (OpenGl_View::*)(  const Aspect_FillMethod  ) ) static_cast<void (OpenGl_View::*)(  const Aspect_FillMethod  ) >(&OpenGl_View::SetBackgroundImageStyle),
             R"#(Sets background image fill style.)#"  , py::arg("theFillStyle")
          )
        .def("SetImageBasedLighting",
             (void (OpenGl_View::*)( bool  ) ) static_cast<void (OpenGl_View::*)( bool  ) >(&OpenGl_View::SetImageBasedLighting),
             R"#(Enables or disables IBL (Image Based Lighting) from background cubemap. Has no effect if PBR is not used.)#"  , py::arg("theToEnableIBL")
          )
        .def("GridDisplay",
             (void (OpenGl_View::*)(  const Aspect_GridParams & ,   const gp_Ax3 &  ) ) static_cast<void (OpenGl_View::*)(  const Aspect_GridParams & ,   const gp_Ax3 &  ) >(&OpenGl_View::GridDisplay),
             R"#(Display a shader-rendered grid on the given plane.)#"  , py::arg("theParams"),  py::arg("thePlane")
          )
        .def("GridErase",
             (void (OpenGl_View::*)() ) static_cast<void (OpenGl_View::*)() >(&OpenGl_View::GridErase),
             R"#(Erase the shader-rendered grid.)#" 
          )
        .def("ShaderGridEcho",
             (bool (OpenGl_View::*)(  const int ,   const int ,  Graphic3d_Vertex &  ) const) static_cast<bool (OpenGl_View::*)(  const int ,   const int ,  Graphic3d_Vertex &  ) const>(&OpenGl_View::ShaderGridEcho),
             R"#(Return snapped point for the shader-rendered grid under the window pixel.)#"  , py::arg("theX"),  py::arg("theY"),  py::arg("thePoint")
          )
        .def("ShaderGridEcho",
             (bool (OpenGl_View::*)(  const int ,   const int ,  Graphic3d_Vertex & ,  Graphic3d_Vertex &  ) const) static_cast<bool (OpenGl_View::*)(  const int ,   const int ,  Graphic3d_Vertex & ,  Graphic3d_Vertex &  ) const>(&OpenGl_View::ShaderGridEcho),
             R"#(Return snapped point and clip-safe display point for the shader-rendered grid echo marker.)#"  , py::arg("theX"),  py::arg("theY"),  py::arg("thePoint"),  py::arg("theDisplayPoint")
          )
        .def("ShaderGridSnapPoint",
             (bool (OpenGl_View::*)(  const Graphic3d_Vertex & ,  Graphic3d_Vertex &  ) const) static_cast<bool (OpenGl_View::*)(  const Graphic3d_Vertex & ,  Graphic3d_Vertex &  ) const>(&OpenGl_View::ShaderGridSnapPoint),
             R"#(Return snapped point for the shader-rendered grid from an arbitrary world point.)#"  , py::arg("thePoint"),  py::arg("theGridPoint")
          )
        .def("SpecIBLMapLevels",
             (unsigned int (OpenGl_View::*)() const) static_cast<unsigned int (OpenGl_View::*)() const>(&OpenGl_View::SpecIBLMapLevels),
             R"#(Returns number of mipmap levels used in specular IBL map. 0 if PBR environment is not created.)#" 
          )
        .def("SetLocalOrigin",
             (void (OpenGl_View::*)(  const gp_XYZ &  ) ) static_cast<void (OpenGl_View::*)(  const gp_XYZ &  ) >(&OpenGl_View::SetLocalOrigin),
             R"#(Setup local camera origin currently set for rendering.)#"  , py::arg("theOrigin")
          )
        .def("SetLights",
             (void (OpenGl_View::*)(  const handle<Graphic3d_LightSet> &  ) ) static_cast<void (OpenGl_View::*)(  const handle<Graphic3d_LightSet> &  ) >(&OpenGl_View::SetLights),
             R"#(Sets list of lights for the view.)#"  , py::arg("theLights")
          )
        .def("SetClipPlanes",
             (void (OpenGl_View::*)(  const handle<Graphic3d_SequenceOfHClipPlane> &  ) ) static_cast<void (OpenGl_View::*)(  const handle<Graphic3d_SequenceOfHClipPlane> &  ) >(&OpenGl_View::SetClipPlanes),
             R"#(Sets list of clip planes for the view.)#"  , py::arg("thePlanes")
          )
        .def("DiagnosticInformation",
             (void (OpenGl_View::*)( NCollection_IndexedDataMap<TCollection_AsciiString, TCollection_AsciiString> & ,  Graphic3d_DiagnosticInfo  ) const) static_cast<void (OpenGl_View::*)( NCollection_IndexedDataMap<TCollection_AsciiString, TCollection_AsciiString> & ,  Graphic3d_DiagnosticInfo  ) const>(&OpenGl_View::DiagnosticInformation),
             R"#(Fill in the dictionary with diagnostic info. Should be called within rendering thread.)#"  , py::arg("theDict"),  py::arg("theFlags")
          )
        .def("StatisticInformation",
             (TCollection_AsciiString (OpenGl_View::*)() const) static_cast<TCollection_AsciiString (OpenGl_View::*)() const>(&OpenGl_View::StatisticInformation),
             R"#(Returns string with statistic performance info.)#" 
          )
        .def("StatisticInformation",
             (void (OpenGl_View::*)( NCollection_IndexedDataMap<TCollection_AsciiString, TCollection_AsciiString> &  ) const) static_cast<void (OpenGl_View::*)( NCollection_IndexedDataMap<TCollection_AsciiString, TCollection_AsciiString> &  ) const>(&OpenGl_View::StatisticInformation),
             R"#(Fills in the dictionary with statistic performance info.)#"  , py::arg("theDict")
          )
        .def("HasImmediateStructures",
             (bool (OpenGl_View::*)() const) static_cast<bool (OpenGl_View::*)() const>(&OpenGl_View::HasImmediateStructures),
             R"#(Returns true if there are immediate structures to display)#" 
          )
        .def("GraduatedTrihedronDisplay",
             (void (OpenGl_View::*)(  const Graphic3d_GraduatedTrihedron &  ) ) static_cast<void (OpenGl_View::*)(  const Graphic3d_GraduatedTrihedron &  ) >(&OpenGl_View::GraduatedTrihedronDisplay),
             R"#(Displays Graduated Trihedron.)#"  , py::arg("theTrihedronData")
          )
        .def("GraduatedTrihedronErase",
             (void (OpenGl_View::*)() ) static_cast<void (OpenGl_View::*)() >(&OpenGl_View::GraduatedTrihedronErase),
             R"#(Erases Graduated Trihedron.)#" 
          )
        .def("GraduatedTrihedronMinMaxValues",
             (void (OpenGl_View::*)(  const NCollection_Vec3<float> ,   const NCollection_Vec3<float>  ) ) static_cast<void (OpenGl_View::*)(  const NCollection_Vec3<float> ,   const NCollection_Vec3<float>  ) >(&OpenGl_View::GraduatedTrihedronMinMaxValues),
             R"#(Sets minimum and maximum points of scene bounding box for Graduated Trihedron stored in graphic view object.)#"  , py::arg("theMin"),  py::arg("theMax")
          )
        .def("ToFlipOutput",
             (bool (OpenGl_View::*)() const) static_cast<bool (OpenGl_View::*)() const>(&OpenGl_View::ToFlipOutput),
             R"#(Returns necessity to flip OY in projection matrix)#" 
          )
        .def("SetToFlipOutput",
             (void (OpenGl_View::*)(  const bool  ) ) static_cast<void (OpenGl_View::*)(  const bool  ) >(&OpenGl_View::SetToFlipOutput),
             R"#(Sets state of flip OY necessity in projection matrix)#"  , py::arg("theFlip")
          )
    // methods using call by reference i.s.o. return
        .def("FBORelease",
             []( OpenGl_View &self , Standard_Transient& theFbo ){
                 handle<Standard_Transient>  theFbo_ptr; theFbo_ptr = &theFbo;

                 self.FBORelease(theFbo_ptr);
                 return std::make_tuple(theFbo_ptr); },
             R"#(Remove offscreen FBO from the graphic library)#"  , py::arg("theFbo")
          )
        .def("FBOGetDimensions",
             []( OpenGl_View &self ,  const handle<Standard_Transient> & theFbo ){
                 int  theWidth;
                int  theHeight;
                int  theWidthMax;
                int  theHeightMax;

                 self.FBOGetDimensions(theFbo,theWidth,theHeight,theWidthMax,theHeightMax);
                 return std::make_tuple(theWidth,theHeight,theWidthMax,theHeightMax); },
             R"#(Read offscreen FBO configuration.)#"  , py::arg("theFbo")
          )
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_View::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_View::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Layers",
             ( const NCollection_List<handle<Graphic3d_Layer>> & (OpenGl_View::*)() const) static_cast< const NCollection_List<handle<Graphic3d_Layer>> & (OpenGl_View::*)() const>(&OpenGl_View::Layers),
             R"#(Returns the list of layers.)#"
             
         )
       .def("DepthPeelingFbos",
             ( const handle<OpenGl_DepthPeeling> & (OpenGl_View::*)() const) static_cast< const handle<OpenGl_DepthPeeling> & (OpenGl_View::*)() const>(&OpenGl_View::DepthPeelingFbos),
             R"#(Returns additional buffers for depth peeling OIT.)#"
             
         )
       .def("LocalOrigin",
             ( const gp_XYZ & (OpenGl_View::*)() const) static_cast< const gp_XYZ & (OpenGl_View::*)() const>(&OpenGl_View::LocalOrigin),
             R"#(Returns local camera origin currently set for rendering, might be modified during rendering.)#"
             
         )
       .def("Lights",
             ( const handle<Graphic3d_LightSet> & (OpenGl_View::*)() const) static_cast< const handle<Graphic3d_LightSet> & (OpenGl_View::*)() const>(&OpenGl_View::Lights),
             R"#(Returns list of lights of the view.)#"
             
         )
       .def("ClipPlanes",
             ( const handle<Graphic3d_SequenceOfHClipPlane> & (OpenGl_View::*)() const) static_cast< const handle<Graphic3d_SequenceOfHClipPlane> & (OpenGl_View::*)() const>(&OpenGl_View::ClipPlanes),
             R"#(Returns list of clip planes set for the view.)#"
             
         )
       .def("BackgroundColor",
             ( const Quantity_ColorRGBA & (OpenGl_View::*)() const) static_cast< const Quantity_ColorRGBA & (OpenGl_View::*)() const>(&OpenGl_View::BackgroundColor),
             R"#(Returns background color.)#"
             
         )
       .def("GlWindow",
             ( const handle<OpenGl_Window> & (OpenGl_View::*)() const) static_cast< const handle<OpenGl_Window> & (OpenGl_View::*)() const>(&OpenGl_View::GlWindow),
             R"#(Returns OpenGL window implementation.)#"
             
         )
       .def("GlTextureEnv",
             ( const handle<OpenGl_TextureSet> & (OpenGl_View::*)() const) static_cast< const handle<OpenGl_TextureSet> & (OpenGl_View::*)() const>(&OpenGl_View::GlTextureEnv),
             R"#(Returns OpenGL environment map.)#"
             
         )
       .def("BVHTreeSelector",
             ( const Graphic3d_CullingTool & (OpenGl_View::*)() const) static_cast< const Graphic3d_CullingTool & (OpenGl_View::*)() const>(&OpenGl_View::BVHTreeSelector),
             R"#(Returns selector for BVH tree, providing a possibility to store information about current view volume and to detect which objects are overlapping it.)#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_View::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_View::*)() const>(&OpenGl_View::DynamicType),
             R"#()#"
             
         )
;

    // Class OpenGl_Window from ./opencascade/OpenGl_Window.hxx
    klass = m.attr("OpenGl_Window");


    // nested enums

    static_cast<py::class_<OpenGl_Window ,opencascade::handle<OpenGl_Window>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Init",
             (void (OpenGl_Window::*)(  const handle<OpenGl_GraphicDriver> & ,   const handle<Aspect_Window> & ,   const handle<Aspect_Window> & ,  Aspect_RenderingContext ,   const handle<OpenGl_Caps> & ,   const handle<OpenGl_Context> &  ) ) static_cast<void (OpenGl_Window::*)(  const handle<OpenGl_GraphicDriver> & ,   const handle<Aspect_Window> & ,   const handle<Aspect_Window> & ,  Aspect_RenderingContext ,   const handle<OpenGl_Caps> & ,   const handle<OpenGl_Context> &  ) >(&OpenGl_Window::Init),
             R"#(Initialize the new window - prepare GL context for specified window. Throws exception in case of failure.)#"  , py::arg("theDriver"),  py::arg("thePlatformWindow"),  py::arg("theSizeWindow"),  py::arg("theGContext"),  py::arg("theCaps"),  py::arg("theShareCtx")
          )
        .def("Resize",
             (void (OpenGl_Window::*)() ) static_cast<void (OpenGl_Window::*)() >(&OpenGl_Window::Resize),
             R"#(Resizes the window.)#" 
          )
        .def("Width",
             (int (OpenGl_Window::*)() const) static_cast<int (OpenGl_Window::*)() const>(&OpenGl_Window::Width),
             R"#()#" 
          )
        .def("Height",
             (int (OpenGl_Window::*)() const) static_cast<int (OpenGl_Window::*)() const>(&OpenGl_Window::Height),
             R"#()#" 
          )
        .def("Activate",
             (bool (OpenGl_Window::*)() ) static_cast<bool (OpenGl_Window::*)() >(&OpenGl_Window::Activate),
             R"#(Makes GL context for this window active in current thread)#" 
          )
        .def("SetSwapInterval",
             (void (OpenGl_Window::*)( bool  ) ) static_cast<void (OpenGl_Window::*)( bool  ) >(&OpenGl_Window::SetSwapInterval),
             R"#(Sets swap interval for this window according to the context's settings.)#"  , py::arg("theToForceNoSync")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_Window::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_Window::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_Window::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_Window::*)() const>(&OpenGl_Window::DynamicType),
             R"#()#"
             
         )
       .def("PlatformWindow",
             ( const handle<Aspect_Window> & (OpenGl_Window::*)() ) static_cast< const handle<Aspect_Window> & (OpenGl_Window::*)() >(&OpenGl_Window::PlatformWindow),
             R"#(Return platform window.)#"
             
         )
       .def("SizeWindow",
             ( const handle<Aspect_Window> & (OpenGl_Window::*)() ) static_cast< const handle<Aspect_Window> & (OpenGl_Window::*)() >(&OpenGl_Window::SizeWindow),
             R"#(Return window object defining dimensions.)#"
             
         )
       .def("GetGlContext",
             ( const handle<OpenGl_Context> & (OpenGl_Window::*)() const) static_cast< const handle<OpenGl_Context> & (OpenGl_Window::*)() const>(&OpenGl_Window::GetGlContext),
             R"#(Return OpenGL context.)#"
             
         )
;

    // Class OpenGl_Workspace from ./opencascade/OpenGl_Workspace.hxx
    klass = m.attr("OpenGl_Workspace");


    // nested enums

    static_cast<py::class_<OpenGl_Workspace ,opencascade::handle<OpenGl_Workspace>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init< OpenGl_View *, const handle<OpenGl_Window> & >()  , py::arg("theView"),  py::arg("theWindow") )
    // custom constructors
    // methods
        .def("Activate",
             (bool (OpenGl_Workspace::*)() ) static_cast<bool (OpenGl_Workspace::*)() >(&OpenGl_Workspace::Activate),
             R"#(Activate rendering context.)#" 
          )
        .def("View",
             (OpenGl_View * (OpenGl_Workspace::*)() const) static_cast<OpenGl_View * (OpenGl_Workspace::*)() const>(&OpenGl_Workspace::View),
             R"#()#" 
          )
        .def("FBOCreate",
             (handle<OpenGl_FrameBuffer> (OpenGl_Workspace::*)(  const int ,   const int  ) ) static_cast<handle<OpenGl_FrameBuffer> (OpenGl_Workspace::*)(  const int ,   const int  ) >(&OpenGl_Workspace::FBOCreate),
             R"#()#"  , py::arg("theWidth"),  py::arg("theHeight")
          )
        .def("Width",
             (int (OpenGl_Workspace::*)() const) static_cast<int (OpenGl_Workspace::*)() const>(&OpenGl_Workspace::Width),
             R"#()#" 
          )
        .def("Height",
             (int (OpenGl_Workspace::*)() const) static_cast<int (OpenGl_Workspace::*)() const>(&OpenGl_Workspace::Height),
             R"#()#" 
          )
        .def("SetUseZBuffer",
             (bool (OpenGl_Workspace::*)(  const bool  ) ) static_cast<bool (OpenGl_Workspace::*)(  const bool  ) >(&OpenGl_Workspace::SetUseZBuffer),
             R"#(Setup Z-buffer usage flag (without affecting GL state!). Returns previously set flag.)#"  , py::arg("theToUse")
          )
        .def("SetDefaultPolygonOffset",
             (Graphic3d_PolygonOffset (OpenGl_Workspace::*)(  const Graphic3d_PolygonOffset &  ) ) static_cast<Graphic3d_PolygonOffset (OpenGl_Workspace::*)(  const Graphic3d_PolygonOffset &  ) >(&OpenGl_Workspace::SetDefaultPolygonOffset),
             R"#(Configure default polygon offset parameters. Return previous settings.)#"  , py::arg("theOffset")
          )
        .def("ToAllowFaceCulling",
             (bool (OpenGl_Workspace::*)() const) static_cast<bool (OpenGl_Workspace::*)() const>(&OpenGl_Workspace::ToAllowFaceCulling),
             R"#(Return true if active group might activate face culling (e.g. primitives are closed).)#" 
          )
        .def("SetAllowFaceCulling",
             (bool (OpenGl_Workspace::*)( bool  ) ) static_cast<bool (OpenGl_Workspace::*)( bool  ) >(&OpenGl_Workspace::SetAllowFaceCulling),
             R"#(Allow or disallow face culling. This call does NOT affect current state of back face culling; ApplyAspectFace() should be called to update state.)#"  , py::arg("theToAllow")
          )
        .def("ToHighlight",
             (bool (OpenGl_Workspace::*)() const) static_cast<bool (OpenGl_Workspace::*)() const>(&OpenGl_Workspace::ToHighlight),
             R"#(Return true if following structures should apply highlight color.)#" 
          )
        .def("SetHighlightStyle",
             (void (OpenGl_Workspace::*)(  const handle<Graphic3d_PresentationAttributes> &  ) ) static_cast<void (OpenGl_Workspace::*)(  const handle<Graphic3d_PresentationAttributes> &  ) >(&OpenGl_Workspace::SetHighlightStyle),
             R"#(Set highlight style.)#"  , py::arg("theStyle")
          )
        .def("Aspects",
             ( const OpenGl_Aspects * (OpenGl_Workspace::*)() const) static_cast< const OpenGl_Aspects * (OpenGl_Workspace::*)() const>(&OpenGl_Workspace::Aspects),
             R"#(Currently set aspects (can differ from applied).)#" 
          )
        .def("SetAspects",
             ( const OpenGl_Aspects * (OpenGl_Workspace::*)(  const OpenGl_Aspects *  ) ) static_cast< const OpenGl_Aspects * (OpenGl_Workspace::*)(  const OpenGl_Aspects *  ) >(&OpenGl_Workspace::SetAspects),
             R"#(Assign new aspects (will be applied within ApplyAspects()).)#"  , py::arg("theAspect")
          )
        .def("ApplyAspects",
             ( const OpenGl_Aspects * (OpenGl_Workspace::*)( bool  ) ) static_cast< const OpenGl_Aspects * (OpenGl_Workspace::*)( bool  ) >(&OpenGl_Workspace::ApplyAspects),
             R"#(Apply aspects.)#"  , py::arg("theToBindTextures")=static_cast<bool>(true)
          )
        .def("RenderFilter",
             (int (OpenGl_Workspace::*)() const) static_cast<int (OpenGl_Workspace::*)() const>(&OpenGl_Workspace::RenderFilter),
             R"#(Get rendering filter.)#" 
          )
        .def("SetRenderFilter",
             (void (OpenGl_Workspace::*)( int  ) ) static_cast<void (OpenGl_Workspace::*)( int  ) >(&OpenGl_Workspace::SetRenderFilter),
             R"#(Set filter for restricting rendering of particular elements.)#"  , py::arg("theFilter")
          )
        .def("NbSkippedTransparentElements",
             (int (OpenGl_Workspace::*)() ) static_cast<int (OpenGl_Workspace::*)() >(&OpenGl_Workspace::NbSkippedTransparentElements),
             R"#(Return the number of skipped transparent elements within active OpenGl_RenderFilter_OpaqueOnly filter.)#" 
          )
        .def("ResetSkippedCounter",
             (void (OpenGl_Workspace::*)() ) static_cast<void (OpenGl_Workspace::*)() >(&OpenGl_Workspace::ResetSkippedCounter),
             R"#(Reset skipped transparent elements counter.)#" 
          )
        .def("SetEnvironmentTexture",
             (void (OpenGl_Workspace::*)(  const handle<OpenGl_TextureSet> &  ) ) static_cast<void (OpenGl_Workspace::*)(  const handle<OpenGl_TextureSet> &  ) >(&OpenGl_Workspace::SetEnvironmentTexture),
             R"#(Sets a new environment texture.)#"  , py::arg("theTexture")
          )
        .def("DumpJson",
             (void (OpenGl_Workspace::*)( Standard_OStream & ,  int  ) const) static_cast<void (OpenGl_Workspace::*)( Standard_OStream & ,  int  ) const>(&OpenGl_Workspace::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
        .def("FBORelease",
             []( OpenGl_Workspace &self , OpenGl_FrameBuffer& theFbo ){
                 handle<OpenGl_FrameBuffer>  theFbo_ptr; theFbo_ptr = &theFbo;

                 self.FBORelease(theFbo_ptr);
                 return std::make_tuple(theFbo_ptr); },
             R"#()#"  , py::arg("theFbo")
          )
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_Workspace::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_Workspace::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("GetGlContext",
             ( const handle<OpenGl_Context> & (OpenGl_Workspace::*)() ) static_cast< const handle<OpenGl_Context> & (OpenGl_Workspace::*)() >(&OpenGl_Workspace::GetGlContext),
             R"#()#"
             
         )
       .def_property("UseZBuffer",
                     [](OpenGl_Workspace& self){return self.UseZBuffer();} ,
                     [](OpenGl_Workspace& self, bool  val){self.UseZBuffer() = val;},                      R"#(Returns true if usage of Z buffer is enabled.)#"
         )
       .def_property("UseDepthWrite",
                     [](OpenGl_Workspace& self){return self.UseDepthWrite();} ,
                     [](OpenGl_Workspace& self, bool  val){self.UseDepthWrite() = val;},                      R"#(Returns true if depth writing is enabled.)#"
         )
       .def("HighlightStyle",
             ( const handle<Graphic3d_PresentationAttributes> & (OpenGl_Workspace::*)() const) static_cast< const handle<Graphic3d_PresentationAttributes> & (OpenGl_Workspace::*)() const>(&OpenGl_Workspace::HighlightStyle),
             R"#(Return highlight style.)#"
             
         )
       .def("EdgeColor",
             ( const NCollection_Vec4<float> & (OpenGl_Workspace::*)() const) static_cast< const NCollection_Vec4<float> & (OpenGl_Workspace::*)() const>(&OpenGl_Workspace::EdgeColor),
             R"#(Return edge color taking into account highlight flag.)#"
             
         )
       .def("InteriorColor",
             ( const NCollection_Vec4<float> & (OpenGl_Workspace::*)() const) static_cast< const NCollection_Vec4<float> & (OpenGl_Workspace::*)() const>(&OpenGl_Workspace::InteriorColor),
             R"#(Return Interior color taking into account highlight flag.)#"
             
         )
       .def("BackInteriorColor",
             ( const NCollection_Vec4<float> & (OpenGl_Workspace::*)() const) static_cast< const NCollection_Vec4<float> & (OpenGl_Workspace::*)() const>(&OpenGl_Workspace::BackInteriorColor),
             R"#(Return back interior color taking into account highlight and distinguish flags.)#"
             
         )
       .def("TextColor",
             ( const NCollection_Vec4<float> & (OpenGl_Workspace::*)() const) static_cast< const NCollection_Vec4<float> & (OpenGl_Workspace::*)() const>(&OpenGl_Workspace::TextColor),
             R"#(Return text color taking into account highlight flag.)#"
             
         )
       .def("TextSubtitleColor",
             ( const NCollection_Vec4<float> & (OpenGl_Workspace::*)() const) static_cast< const NCollection_Vec4<float> & (OpenGl_Workspace::*)() const>(&OpenGl_Workspace::TextSubtitleColor),
             R"#(Return text Subtitle color taking into account highlight flag.)#"
             
         )
       .def("TextureSet",
             ( const handle<OpenGl_TextureSet> & (OpenGl_Workspace::*)() const) static_cast< const handle<OpenGl_TextureSet> & (OpenGl_Workspace::*)() const>(&OpenGl_Workspace::TextureSet),
             R"#(Return TextureSet from set Aspects or Environment texture.)#"
             
         )
       .def("NoneCulling",
             ( const OpenGl_Aspects & (OpenGl_Workspace::*)() const) static_cast< const OpenGl_Aspects & (OpenGl_Workspace::*)() const>(&OpenGl_Workspace::NoneCulling),
             R"#(Returns face aspect for none culling mode.)#"
             
         )
       .def("FrontCulling",
             ( const OpenGl_Aspects & (OpenGl_Workspace::*)() const) static_cast< const OpenGl_Aspects & (OpenGl_Workspace::*)() const>(&OpenGl_Workspace::FrontCulling),
             R"#(Returns face aspect for front face culling mode.)#"
             
         )
       .def("EnvironmentTexture",
             ( const handle<OpenGl_TextureSet> & (OpenGl_Workspace::*)() const) static_cast< const handle<OpenGl_TextureSet> & (OpenGl_Workspace::*)() const>(&OpenGl_Workspace::EnvironmentTexture),
             R"#(Returns environment texture.)#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_Workspace::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_Workspace::*)() const>(&OpenGl_Workspace::DynamicType),
             R"#()#"
             
         )
;

    // Class OpenGl_Aspects from ./opencascade/OpenGl_Aspects.hxx
    klass = m.attr("OpenGl_Aspects");


    // nested enums

    static_cast<py::class_<OpenGl_Aspects , shared_ptr<OpenGl_Aspects>  , OpenGl_Element >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<Graphic3d_Aspects> & >()  , py::arg("theAspect") )
    // custom constructors
    // methods
        .def("SetAspect",
             (void (OpenGl_Aspects::*)(  const handle<Graphic3d_Aspects> &  ) ) static_cast<void (OpenGl_Aspects::*)(  const handle<Graphic3d_Aspects> &  ) >(&OpenGl_Aspects::SetAspect),
             R"#(Assign parameters.)#"  , py::arg("theAspect")
          )
        .def("ShadingModel",
             (Graphic3d_TypeOfShadingModel (OpenGl_Aspects::*)() const) static_cast<Graphic3d_TypeOfShadingModel (OpenGl_Aspects::*)() const>(&OpenGl_Aspects::ShadingModel),
             R"#(Returns Shading Model.)#" 
          )
        .def("SetNoLighting",
             (void (OpenGl_Aspects::*)() ) static_cast<void (OpenGl_Aspects::*)() >(&OpenGl_Aspects::SetNoLighting),
             R"#(Set if lighting should be disabled or not.)#" 
          )
        .def("TextureSet",
             ( const handle<OpenGl_TextureSet> & (OpenGl_Aspects::*)(  const handle<OpenGl_Context> & ,  bool  ) const) static_cast< const handle<OpenGl_TextureSet> & (OpenGl_Aspects::*)(  const handle<OpenGl_Context> & ,  bool  ) const>(&OpenGl_Aspects::TextureSet),
             R"#(Returns textures map.)#"  , py::arg("theCtx"),  py::arg("theToHighlight")=static_cast<bool>(false)
          )
        .def("ShaderProgramRes",
             ( const handle<OpenGl_ShaderProgram> & (OpenGl_Aspects::*)(  const handle<OpenGl_Context> &  ) const) static_cast< const handle<OpenGl_ShaderProgram> & (OpenGl_Aspects::*)(  const handle<OpenGl_Context> &  ) const>(&OpenGl_Aspects::ShaderProgramRes),
             R"#(Init and return OpenGl shader program resource.)#"  , py::arg("theCtx")
          )
        .def("MarkerSize",
             (float (OpenGl_Aspects::*)() const) static_cast<float (OpenGl_Aspects::*)() const>(&OpenGl_Aspects::MarkerSize),
             R"#(Returns marker size)#" 
          )
        .def("HasPointSprite",
             (bool (OpenGl_Aspects::*)(  const handle<OpenGl_Context> &  ) const) static_cast<bool (OpenGl_Aspects::*)(  const handle<OpenGl_Context> &  ) const>(&OpenGl_Aspects::HasPointSprite),
             R"#(Return TRUE if OpenGl point sprite resource defines texture.)#"  , py::arg("theCtx")
          )
        .def("IsDisplayListSprite",
             (bool (OpenGl_Aspects::*)(  const handle<OpenGl_Context> &  ) const) static_cast<bool (OpenGl_Aspects::*)(  const handle<OpenGl_Context> &  ) const>(&OpenGl_Aspects::IsDisplayListSprite),
             R"#(Return TRUE if OpenGl point sprite resource defined by obsolete Display List (bitmap).)#"  , py::arg("theCtx")
          )
        .def("SpriteRes",
             ( const handle<OpenGl_PointSprite> & (OpenGl_Aspects::*)(  const handle<OpenGl_Context> & ,  bool  ) const) static_cast< const handle<OpenGl_PointSprite> & (OpenGl_Aspects::*)(  const handle<OpenGl_Context> & ,  bool  ) const>(&OpenGl_Aspects::SpriteRes),
             R"#(Init and return OpenGl point sprite resource.)#"  , py::arg("theCtx"),  py::arg("theIsAlphaSprite")
          )
        .def("Render",
             (void (OpenGl_Aspects::*)(  const handle<OpenGl_Workspace> &  ) const) static_cast<void (OpenGl_Aspects::*)(  const handle<OpenGl_Workspace> &  ) const>(&OpenGl_Aspects::Render),
             R"#()#"  , py::arg("theWorkspace")
          )
        .def("Release",
             (void (OpenGl_Aspects::*)( OpenGl_Context *  ) ) static_cast<void (OpenGl_Aspects::*)( OpenGl_Context *  ) >(&OpenGl_Aspects::Release),
             R"#()#"  , py::arg("theContext")
          )
        .def("SynchronizeAspects",
             (void (OpenGl_Aspects::*)() ) static_cast<void (OpenGl_Aspects::*)() >(&OpenGl_Aspects::SynchronizeAspects),
             R"#(Update presentation aspects parameters after their modification.)#" 
          )
        .def("DumpJson",
             (void (OpenGl_Aspects::*)( Standard_OStream & ,  int  ) const) static_cast<void (OpenGl_Aspects::*)( Standard_OStream & ,  int  ) const>(&OpenGl_Aspects::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Aspect",
             ( const handle<Graphic3d_Aspects> & (OpenGl_Aspects::*)() const) static_cast< const handle<Graphic3d_Aspects> & (OpenGl_Aspects::*)() const>(&OpenGl_Aspects::Aspect),
             R"#(Return aspect.)#"
             
         )
;

    // Class OpenGl_Buffer from ./opencascade/OpenGl_Buffer.hxx
    klass = m.attr("OpenGl_Buffer");


    // nested enums

    static_cast<py::class_<OpenGl_Buffer ,opencascade::handle<OpenGl_Buffer> ,Py_OpenGl_Buffer , OpenGl_Resource >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("GetTarget",
             (unsigned int (OpenGl_Buffer::*)() const) static_cast<unsigned int (OpenGl_Buffer::*)() const>(&OpenGl_Buffer::GetTarget),
             R"#(Return buffer target.)#" 
          )
        .def("IsVirtual",
             (bool (OpenGl_Buffer::*)() const) static_cast<bool (OpenGl_Buffer::*)() const>(&OpenGl_Buffer::IsVirtual),
             R"#(Return TRUE if this is a virtual (for backward compatibility) VBO object.)#" 
          )
        .def("IsValid",
             (bool (OpenGl_Buffer::*)() const) static_cast<bool (OpenGl_Buffer::*)() const>(&OpenGl_Buffer::IsValid),
             R"#(Returns true if current object was initialized)#" 
          )
        .def("GetComponentsNb",
             (unsigned int (OpenGl_Buffer::*)() const) static_cast<unsigned int (OpenGl_Buffer::*)() const>(&OpenGl_Buffer::GetComponentsNb),
             R"#(Returns the number of components per generic vertex attribute.)#" 
          )
        .def("GetElemsNb",
             (int (OpenGl_Buffer::*)() const) static_cast<int (OpenGl_Buffer::*)() const>(&OpenGl_Buffer::GetElemsNb),
             R"#(Returns number of vertex attributes / number of vertices specified within ::Init())#" 
          )
        .def("SetElemsNb",
             (void (OpenGl_Buffer::*)( int  ) ) static_cast<void (OpenGl_Buffer::*)( int  ) >(&OpenGl_Buffer::SetElemsNb),
             R"#(Overrides the number of vertex attributes / number of vertexes. It is up to user specifying this number correct (e.g. below initial value)!)#"  , py::arg("theNbElems")
          )
        .def("GetDataType",
             (unsigned int (OpenGl_Buffer::*)() const) static_cast<unsigned int (OpenGl_Buffer::*)() const>(&OpenGl_Buffer::GetDataType),
             R"#(Returns data type of each component in the array.)#" 
          )
        .def("GetDataOffset",
             (uint8_t * (OpenGl_Buffer::*)() const) static_cast<uint8_t * (OpenGl_Buffer::*)() const>(&OpenGl_Buffer::GetDataOffset),
             R"#(Returns offset to data, NULL by default)#" 
          )
        .def("Create",
             (bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> &  ) ) static_cast<bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> &  ) >(&OpenGl_Buffer::Create),
             R"#(Creates buffer object name (id) if not yet generated. Data should be initialized by another method.)#"  , py::arg("theGlCtx")
          )
        .def("Release",
             (void (OpenGl_Buffer::*)( OpenGl_Context *  ) ) static_cast<void (OpenGl_Buffer::*)( OpenGl_Context *  ) >(&OpenGl_Buffer::Release),
             R"#(Destroy object - will release GPU memory if any.)#"  , py::arg("theGlCtx")
          )
        .def("Bind",
             (void (OpenGl_Buffer::*)(  const handle<OpenGl_Context> &  ) const) static_cast<void (OpenGl_Buffer::*)(  const handle<OpenGl_Context> &  ) const>(&OpenGl_Buffer::Bind),
             R"#(Bind this buffer object.)#"  , py::arg("theGlCtx")
          )
        .def("Unbind",
             (void (OpenGl_Buffer::*)(  const handle<OpenGl_Context> &  ) const) static_cast<void (OpenGl_Buffer::*)(  const handle<OpenGl_Context> &  ) const>(&OpenGl_Buffer::Unbind),
             R"#(Unbind this buffer object.)#"  , py::arg("theGlCtx")
          )
        .def("Init",
             (bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const unsigned int ,   const int ,   const float *  ) ) static_cast<bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const unsigned int ,   const int ,   const float *  ) >(&OpenGl_Buffer::Init),
             R"#(Notice that buffer object will be unbound after this call.)#"  , py::arg("theGlCtx"),  py::arg("theComponentsNb"),  py::arg("theElemsNb"),  py::arg("theData")
          )
        .def("Init",
             (bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const unsigned int ,   const int ,   const unsigned int *  ) ) static_cast<bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const unsigned int ,   const int ,   const unsigned int *  ) >(&OpenGl_Buffer::Init),
             R"#(Notice that buffer object will be unbound after this call.)#"  , py::arg("theGlCtx"),  py::arg("theComponentsNb"),  py::arg("theElemsNb"),  py::arg("theData")
          )
        .def("Init",
             (bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const unsigned int ,   const int ,   const unsigned short *  ) ) static_cast<bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const unsigned int ,   const int ,   const unsigned short *  ) >(&OpenGl_Buffer::Init),
             R"#(Notice that buffer object will be unbound after this call.)#"  , py::arg("theGlCtx"),  py::arg("theComponentsNb"),  py::arg("theElemsNb"),  py::arg("theData")
          )
        .def("Init",
             (bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const unsigned int ,   const int ,   const uint8_t *  ) ) static_cast<bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const unsigned int ,   const int ,   const uint8_t *  ) >(&OpenGl_Buffer::Init),
             R"#(Notice that buffer object will be unbound after this call.)#"  , py::arg("theGlCtx"),  py::arg("theComponentsNb"),  py::arg("theElemsNb"),  py::arg("theData")
          )
        .def("SubData",
             (bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,   const float *  ) ) static_cast<bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,   const float *  ) >(&OpenGl_Buffer::SubData),
             R"#(Notice that buffer object will be unbound after this call. Function replaces portion of data within this buffer object using glBufferSubData(). The buffer object should be initialized before call.)#"  , py::arg("theGlCtx"),  py::arg("theElemFrom"),  py::arg("theElemsNb"),  py::arg("theData")
          )
        .def("GetSubData",
             (bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,  float *  ) ) static_cast<bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,  float *  ) >(&OpenGl_Buffer::GetSubData),
             R"#(Read back buffer sub-range. Notice that buffer object will be unbound after this call. Function reads portion of data from this buffer object using glGetBufferSubData().)#"  , py::arg("theGlCtx"),  py::arg("theElemFrom"),  py::arg("theElemsNb"),  py::arg("theData")
          )
        .def("SubData",
             (bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,   const unsigned int *  ) ) static_cast<bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,   const unsigned int *  ) >(&OpenGl_Buffer::SubData),
             R"#(Notice that buffer object will be unbound after this call. Function replaces portion of data within this buffer object using glBufferSubData(). The buffer object should be initialized before call.)#"  , py::arg("theGlCtx"),  py::arg("theElemFrom"),  py::arg("theElemsNb"),  py::arg("theData")
          )
        .def("GetSubData",
             (bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,  unsigned int *  ) ) static_cast<bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,  unsigned int *  ) >(&OpenGl_Buffer::GetSubData),
             R"#(Read back buffer sub-range. Notice that buffer object will be unbound after this call. Function reads portion of data from this buffer object using glGetBufferSubData().)#"  , py::arg("theGlCtx"),  py::arg("theElemFrom"),  py::arg("theElemsNb"),  py::arg("theData")
          )
        .def("SubData",
             (bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,   const unsigned short *  ) ) static_cast<bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,   const unsigned short *  ) >(&OpenGl_Buffer::SubData),
             R"#(Notice that buffer object will be unbound after this call. Function replaces portion of data within this buffer object using glBufferSubData(). The buffer object should be initialized before call.)#"  , py::arg("theGlCtx"),  py::arg("theElemFrom"),  py::arg("theElemsNb"),  py::arg("theData")
          )
        .def("GetSubData",
             (bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,  unsigned short *  ) ) static_cast<bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,  unsigned short *  ) >(&OpenGl_Buffer::GetSubData),
             R"#(Read back buffer sub-range. Notice that buffer object will be unbound after this call. Function reads portion of data from this buffer object using glGetBufferSubData().)#"  , py::arg("theGlCtx"),  py::arg("theElemFrom"),  py::arg("theElemsNb"),  py::arg("theData")
          )
        .def("SubData",
             (bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,   const uint8_t *  ) ) static_cast<bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,   const uint8_t *  ) >(&OpenGl_Buffer::SubData),
             R"#(Notice that buffer object will be unbound after this call. Function replaces portion of data within this buffer object using glBufferSubData(). The buffer object should be initialized before call.)#"  , py::arg("theGlCtx"),  py::arg("theElemFrom"),  py::arg("theElemsNb"),  py::arg("theData")
          )
        .def("GetSubData",
             (bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,  uint8_t *  ) ) static_cast<bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,  uint8_t *  ) >(&OpenGl_Buffer::GetSubData),
             R"#(Read back buffer sub-range. Notice that buffer object will be unbound after this call. Function reads portion of data from this buffer object using glGetBufferSubData().)#"  , py::arg("theGlCtx"),  py::arg("theElemFrom"),  py::arg("theElemsNb"),  py::arg("theData")
          )
        .def("EstimatedDataSize",
             (size_t (OpenGl_Buffer::*)() const) static_cast<size_t (OpenGl_Buffer::*)() const>(&OpenGl_Buffer::EstimatedDataSize),
             R"#(Returns estimated GPU memory usage for holding data without considering overheads and allocation alignment rules.)#" 
          )
        .def("init",
             (bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const unsigned int ,   const int ,   const void * ,   const unsigned int ,   const int  ) ) static_cast<bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const unsigned int ,   const int ,   const void * ,   const unsigned int ,   const int  ) >(&OpenGl_Buffer::init),
             R"#(Initialize buffer with new data.)#"  , py::arg("theGlCtx"),  py::arg("theComponentsNb"),  py::arg("theElemsNb"),  py::arg("theData"),  py::arg("theDataType"),  py::arg("theStride")
          )
        .def("init",
             (bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const unsigned int ,   const int ,   const void * ,   const unsigned int  ) ) static_cast<bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const unsigned int ,   const int ,   const void * ,   const unsigned int  ) >(&OpenGl_Buffer::init),
             R"#(Initialize buffer with new data.)#"  , py::arg("theGlCtx"),  py::arg("theComponentsNb"),  py::arg("theElemsNb"),  py::arg("theData"),  py::arg("theDataType")
          )
        .def("subData",
             (bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,   const void * ,   const unsigned int  ) ) static_cast<bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,   const void * ,   const unsigned int  ) >(&OpenGl_Buffer::subData),
             R"#(Update part of the buffer with new data.)#"  , py::arg("theGlCtx"),  py::arg("theElemFrom"),  py::arg("theElemsNb"),  py::arg("theData"),  py::arg("theDataType")
          )
        .def("getSubData",
             (bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,  void * ,   const unsigned int  ) ) static_cast<bool (OpenGl_Buffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,  void * ,   const unsigned int  ) >(&OpenGl_Buffer::getSubData),
             R"#(Read back buffer sub-range.)#"  , py::arg("theGlCtx"),  py::arg("theElemFrom"),  py::arg("theElemsNb"),  py::arg("theData"),  py::arg("theDataType")
          )
        .def("DumpJson",
             (void (OpenGl_Buffer::*)( Standard_OStream & ,  int  ) const) static_cast<void (OpenGl_Buffer::*)( Standard_OStream & ,  int  ) const>(&OpenGl_Buffer::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_Buffer::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_Buffer::get_type_descriptor),
                    R"#()#" 
          )
        .def_static("FormatTarget_s",
                    (TCollection_AsciiString (*)( unsigned int  ) ) static_cast<TCollection_AsciiString (*)( unsigned int  ) >(&OpenGl_Buffer::FormatTarget),
                    R"#(Format VBO target enumeration value.)#"  , py::arg("theTarget")
          )
        .def_static("sizeOfGlType_s",
                    (size_t (*)( unsigned int  ) ) static_cast<size_t (*)( unsigned int  ) >(&OpenGl_Buffer::sizeOfGlType),
                    R"#(Returns size of specified GL type)#"  , py::arg("theType")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_Buffer::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_Buffer::*)() const>(&OpenGl_Buffer::DynamicType),
             R"#()#"
             
         )
;

    // Class OpenGl_CappingPlaneResource from ./opencascade/OpenGl_CappingPlaneResource.hxx
    klass = m.attr("OpenGl_CappingPlaneResource");


    // nested enums

    static_cast<py::class_<OpenGl_CappingPlaneResource ,opencascade::handle<OpenGl_CappingPlaneResource>  , OpenGl_Resource >>(klass)
    // constructors
        .def(py::init<  const handle<Graphic3d_ClipPlane> & >()  , py::arg("thePlane") )
    // custom constructors
    // methods
        .def("Update",
             (void (OpenGl_CappingPlaneResource::*)(  const handle<OpenGl_Context> & ,   const handle<Graphic3d_Aspects> &  ) ) static_cast<void (OpenGl_CappingPlaneResource::*)(  const handle<OpenGl_Context> & ,   const handle<Graphic3d_Aspects> &  ) >(&OpenGl_CappingPlaneResource::Update),
             R"#(Update resource data in the passed context.)#"  , py::arg("theContext"),  py::arg("theObjAspect")
          )
        .def("Release",
             (void (OpenGl_CappingPlaneResource::*)( OpenGl_Context *  ) ) static_cast<void (OpenGl_CappingPlaneResource::*)( OpenGl_Context *  ) >(&OpenGl_CappingPlaneResource::Release),
             R"#(Release associated OpenGl resources.)#"  , py::arg("theContext")
          )
        .def("EstimatedDataSize",
             (size_t (OpenGl_CappingPlaneResource::*)() const) static_cast<size_t (OpenGl_CappingPlaneResource::*)() const>(&OpenGl_CappingPlaneResource::EstimatedDataSize),
             R"#(Returns estimated GPU memory usage - not implemented.)#" 
          )
        .def("AspectFace",
             ( const OpenGl_Aspects * (OpenGl_CappingPlaneResource::*)() const) static_cast< const OpenGl_Aspects * (OpenGl_CappingPlaneResource::*)() const>(&OpenGl_CappingPlaneResource::AspectFace),
             R"#(Returns aspect face for rendering capping surface.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_CappingPlaneResource::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_CappingPlaneResource::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Plane",
             ( const handle<Graphic3d_ClipPlane> & (OpenGl_CappingPlaneResource::*)() const) static_cast< const handle<Graphic3d_ClipPlane> & (OpenGl_CappingPlaneResource::*)() const>(&OpenGl_CappingPlaneResource::Plane),
             R"#(Return parent clipping plane structure.)#"
             
         )
       .def("Orientation",
             ( const NCollection_Mat4<float> & (OpenGl_CappingPlaneResource::*)() const) static_cast< const NCollection_Mat4<float> & (OpenGl_CappingPlaneResource::*)() const>(&OpenGl_CappingPlaneResource::Orientation),
             R"#(Returns evaluated orientation matrix to transform infinite plane.)#"
             
         )
       .def("Primitives",
             ( const OpenGl_PrimitiveArray & (OpenGl_CappingPlaneResource::*)() const) static_cast< const OpenGl_PrimitiveArray & (OpenGl_CappingPlaneResource::*)() const>(&OpenGl_CappingPlaneResource::Primitives),
             R"#(Returns primitive array of vertices to render infinite plane.)#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_CappingPlaneResource::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_CappingPlaneResource::*)() const>(&OpenGl_CappingPlaneResource::DynamicType),
             R"#()#"
             
         )
;

    // Class OpenGl_Flipper from ./opencascade/OpenGl_Flipper.hxx
    klass = m.attr("OpenGl_Flipper");


    // nested enums

    static_cast<py::class_<OpenGl_Flipper , shared_ptr<OpenGl_Flipper>  , OpenGl_Element >>(klass)
    // constructors
        .def(py::init<  const gp_Ax2 & >()  , py::arg("theReferenceSystem") )
    // custom constructors
    // methods
        .def("SetOptions",
             (void (OpenGl_Flipper::*)(  const bool  ) ) static_cast<void (OpenGl_Flipper::*)(  const bool  ) >(&OpenGl_Flipper::SetOptions),
             R"#(Set options for the element.)#"  , py::arg("theIsEnabled")
          )
        .def("Render",
             (void (OpenGl_Flipper::*)(  const handle<OpenGl_Workspace> &  ) const) static_cast<void (OpenGl_Flipper::*)(  const handle<OpenGl_Workspace> &  ) const>(&OpenGl_Flipper::Render),
             R"#()#"  , py::arg("theWorkspace")
          )
        .def("Release",
             (void (OpenGl_Flipper::*)( OpenGl_Context *  ) ) static_cast<void (OpenGl_Flipper::*)( OpenGl_Context *  ) >(&OpenGl_Flipper::Release),
             R"#()#"  , py::arg("theCtx")
          )
        .def("DumpJson",
             (void (OpenGl_Flipper::*)( Standard_OStream & ,  int  ) const) static_cast<void (OpenGl_Flipper::*)( Standard_OStream & ,  int  ) const>(&OpenGl_Flipper::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_Font from ./opencascade/OpenGl_Font.hxx
    klass = m.attr("OpenGl_Font");


    // nested enums

    static_cast<py::class_<OpenGl_Font ,opencascade::handle<OpenGl_Font>  , OpenGl_Resource >>(klass)
    // constructors
        .def(py::init<  const handle<Font_FTFont> &, const TCollection_AsciiString & >()  , py::arg("theFont"),  py::arg("theKey")=static_cast< const TCollection_AsciiString &>("") )
    // custom constructors
    // methods
        .def("Release",
             (void (OpenGl_Font::*)( OpenGl_Context *  ) ) static_cast<void (OpenGl_Font::*)( OpenGl_Context *  ) >(&OpenGl_Font::Release),
             R"#(Destroy object - will release GPU memory if any)#"  , py::arg("theCtx")
          )
        .def("EstimatedDataSize",
             (size_t (OpenGl_Font::*)() const) static_cast<size_t (OpenGl_Font::*)() const>(&OpenGl_Font::EstimatedDataSize),
             R"#(Returns estimated GPU memory usage.)#" 
          )
        .def("IsValid",
             (bool (OpenGl_Font::*)() const) static_cast<bool (OpenGl_Font::*)() const>(&OpenGl_Font::IsValid),
             R"#(Returns true if font was loaded successfully.)#" 
          )
        .def("WasInitialized",
             (bool (OpenGl_Font::*)() const) static_cast<bool (OpenGl_Font::*)() const>(&OpenGl_Font::WasInitialized),
             R"#(Notice that this method doesn't return initialization success state. Use IsValid() instead.)#" 
          )
        .def("Init",
             (bool (OpenGl_Font::*)(  const handle<OpenGl_Context> &  ) ) static_cast<bool (OpenGl_Font::*)(  const handle<OpenGl_Context> &  ) >(&OpenGl_Font::Init),
             R"#(Initialize GL resources. FreeType font instance should be already initialized!)#"  , py::arg("theCtx")
          )
        .def("Ascender",
             (float (OpenGl_Font::*)() const) static_cast<float (OpenGl_Font::*)() const>(&OpenGl_Font::Ascender),
             R"#(Returns vertical distance from the horizontal baseline to the highest character coordinate)#" 
          )
        .def("Descender",
             (float (OpenGl_Font::*)() const) static_cast<float (OpenGl_Font::*)() const>(&OpenGl_Font::Descender),
             R"#(Returns vertical distance from the horizontal baseline to the lowest character coordinate)#" 
          )
        .def("RenderGlyph",
             (bool (OpenGl_Font::*)(  const handle<OpenGl_Context> & ,   const char32_t ,  OpenGl_Font::Tile &  ) ) static_cast<bool (OpenGl_Font::*)(  const handle<OpenGl_Context> & ,   const char32_t ,  OpenGl_Font::Tile &  ) >(&OpenGl_Font::RenderGlyph),
             R"#(Render glyph to texture if not already.)#"  , py::arg("theCtx"),  py::arg("theUChar"),  py::arg("theGlyph")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_Font::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_Font::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("ResourceKey",
             ( const TCollection_AsciiString & (OpenGl_Font::*)() const) static_cast< const TCollection_AsciiString & (OpenGl_Font::*)() const>(&OpenGl_Font::ResourceKey),
             R"#(Returns key of shared resource)#"
             
         )
       .def("FTFont",
             ( const handle<Font_FTFont> & (OpenGl_Font::*)() const) static_cast< const handle<Font_FTFont> & (OpenGl_Font::*)() const>(&OpenGl_Font::FTFont),
             R"#(Returns FreeType font instance specified on construction.)#"
             
         )
       .def("Texture",
             ( const handle<OpenGl_Texture> & (OpenGl_Font::*)() const) static_cast< const handle<OpenGl_Texture> & (OpenGl_Font::*)() const>(&OpenGl_Font::Texture),
             R"#(Returns first texture.)#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_Font::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_Font::*)() const>(&OpenGl_Font::DynamicType),
             R"#()#"
             
         )
;

    // Class OpenGl_FrameStatsPrs from ./opencascade/OpenGl_FrameStatsPrs.hxx
    klass = m.attr("OpenGl_FrameStatsPrs");


    // nested enums

    static_cast<py::class_<OpenGl_FrameStatsPrs , shared_ptr<OpenGl_FrameStatsPrs>  , OpenGl_Element >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Render",
             (void (OpenGl_FrameStatsPrs::*)(  const handle<OpenGl_Workspace> &  ) const) static_cast<void (OpenGl_FrameStatsPrs::*)(  const handle<OpenGl_Workspace> &  ) const>(&OpenGl_FrameStatsPrs::Render),
             R"#(Render element.)#"  , py::arg("theWorkspace")
          )
        .def("Release",
             (void (OpenGl_FrameStatsPrs::*)( OpenGl_Context *  ) ) static_cast<void (OpenGl_FrameStatsPrs::*)( OpenGl_Context *  ) >(&OpenGl_FrameStatsPrs::Release),
             R"#(Release OpenGL resources.)#"  , py::arg("theCtx")
          )
        .def("Update",
             (void (OpenGl_FrameStatsPrs::*)(  const handle<OpenGl_Workspace> &  ) ) static_cast<void (OpenGl_FrameStatsPrs::*)(  const handle<OpenGl_Workspace> &  ) >(&OpenGl_FrameStatsPrs::Update),
             R"#(Update text.)#"  , py::arg("theWorkspace")
          )
        .def("SetTextAspect",
             (void (OpenGl_FrameStatsPrs::*)(  const handle<Graphic3d_AspectText3d> &  ) ) static_cast<void (OpenGl_FrameStatsPrs::*)(  const handle<Graphic3d_AspectText3d> &  ) >(&OpenGl_FrameStatsPrs::SetTextAspect),
             R"#(Assign text aspect.)#"  , py::arg("theAspect")
          )
        .def("DumpJson",
             (void (OpenGl_FrameStatsPrs::*)( Standard_OStream & ,  int  ) const) static_cast<void (OpenGl_FrameStatsPrs::*)( Standard_OStream & ,  int  ) const>(&OpenGl_FrameStatsPrs::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_LightSourceState from ./opencascade/OpenGl_ShaderStates.hxx
    klass = m.attr("OpenGl_LightSourceState");


    // nested enums

    static_cast<py::class_<OpenGl_LightSourceState , shared_ptr<OpenGl_LightSourceState>  , OpenGl_StateInterface >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Set",
             (void (OpenGl_LightSourceState::*)(  const handle<Graphic3d_LightSet> &  ) ) static_cast<void (OpenGl_LightSourceState::*)(  const handle<Graphic3d_LightSet> &  ) >(&OpenGl_LightSourceState::Set),
             R"#(Sets new light sources.)#"  , py::arg("theLightSources")
          )
        .def("SpecIBLMapLevels",
             (int (OpenGl_LightSourceState::*)() const) static_cast<int (OpenGl_LightSourceState::*)() const>(&OpenGl_LightSourceState::SpecIBLMapLevels),
             R"#(Returns number of mipmap levels used in specular IBL map. 0 by default or in case of using non-PBR shading model.)#" 
          )
        .def("SetSpecIBLMapLevels",
             (void (OpenGl_LightSourceState::*)( int  ) ) static_cast<void (OpenGl_LightSourceState::*)( int  ) >(&OpenGl_LightSourceState::SetSpecIBLMapLevels),
             R"#(Sets number of mipmap levels used in specular IBL map.)#"  , py::arg("theSpecIBLMapLevels")
          )
        .def("HasShadowMaps",
             (bool (OpenGl_LightSourceState::*)() const) static_cast<bool (OpenGl_LightSourceState::*)() const>(&OpenGl_LightSourceState::HasShadowMaps),
             R"#(Returns TRUE if shadowmap is set.)#" 
          )
        .def("SetShadowMaps",
             (void (OpenGl_LightSourceState::*)(  const handle<OpenGl_ShadowMapArray> &  ) ) static_cast<void (OpenGl_LightSourceState::*)(  const handle<OpenGl_ShadowMapArray> &  ) >(&OpenGl_LightSourceState::SetShadowMaps),
             R"#(Sets shadowmap.)#"  , py::arg("theMap")
          )
        .def("ToCastShadows",
             (bool (OpenGl_LightSourceState::*)() const) static_cast<bool (OpenGl_LightSourceState::*)() const>(&OpenGl_LightSourceState::ToCastShadows),
             R"#(Returns TRUE if shadowmap should be enabled when available; TRUE by default.)#" 
          )
        .def("SetCastShadows",
             (void (OpenGl_LightSourceState::*)( bool  ) ) static_cast<void (OpenGl_LightSourceState::*)( bool  ) >(&OpenGl_LightSourceState::SetCastShadows),
             R"#(Set if shadowmap should be enabled when available.)#"  , py::arg("theToCast")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("LightSources",
             ( const handle<Graphic3d_LightSet> & (OpenGl_LightSourceState::*)() const) static_cast< const handle<Graphic3d_LightSet> & (OpenGl_LightSourceState::*)() const>(&OpenGl_LightSourceState::LightSources),
             R"#(Returns current list of light sources.)#"
             
         )
       .def("ShadowMaps",
             ( const handle<OpenGl_ShadowMapArray> & (OpenGl_LightSourceState::*)() const) static_cast< const handle<OpenGl_ShadowMapArray> & (OpenGl_LightSourceState::*)() const>(&OpenGl_LightSourceState::ShadowMaps),
             R"#(Returns shadowmap.)#"
             
         )
;

    // Class OpenGl_LineAttributes from ./opencascade/OpenGl_LineAttributes.hxx
    klass = m.attr("OpenGl_LineAttributes");


    // nested enums

    static_cast<py::class_<OpenGl_LineAttributes ,opencascade::handle<OpenGl_LineAttributes>  , OpenGl_Resource >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Release",
             (void (OpenGl_LineAttributes::*)( OpenGl_Context *  ) ) static_cast<void (OpenGl_LineAttributes::*)( OpenGl_Context *  ) >(&OpenGl_LineAttributes::Release),
             R"#(Release GL resources.)#"  , py::arg("theGlCtx")
          )
        .def("EstimatedDataSize",
             (size_t (OpenGl_LineAttributes::*)() const) static_cast<size_t (OpenGl_LineAttributes::*)() const>(&OpenGl_LineAttributes::EstimatedDataSize),
             R"#(Returns estimated GPU memory usage - not implemented.)#" 
          )
        .def("SetTypeOfHatch",
             (bool (OpenGl_LineAttributes::*)(  const OpenGl_Context * ,   const handle<Graphic3d_HatchStyle> &  ) ) static_cast<bool (OpenGl_LineAttributes::*)(  const OpenGl_Context * ,   const handle<Graphic3d_HatchStyle> &  ) >(&OpenGl_LineAttributes::SetTypeOfHatch),
             R"#(Sets type of the hatch.)#"  , py::arg("theGlCtx"),  py::arg("theStyle")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_LineAttributes::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_LineAttributes::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_LineAttributes::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_LineAttributes::*)() const>(&OpenGl_LineAttributes::DynamicType),
             R"#()#"
             
         )
;

    // Class OpenGl_MaterialState from ./opencascade/OpenGl_MaterialState.hxx
    klass = m.attr("OpenGl_MaterialState");


    // nested enums

    static_cast<py::class_<OpenGl_MaterialState , shared_ptr<OpenGl_MaterialState>  , OpenGl_StateInterface >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Set",
             (void (OpenGl_MaterialState::*)(  const OpenGl_Material & ,   const float ,   const bool ,   const bool  ) ) static_cast<void (OpenGl_MaterialState::*)(  const OpenGl_Material & ,   const float ,   const bool ,   const bool  ) >(&OpenGl_MaterialState::Set),
             R"#(Sets new material aspect.)#"  , py::arg("theMat"),  py::arg("theAlphaCutoff"),  py::arg("theToDistinguish"),  py::arg("theToMapTexture")
          )
        .def("AlphaCutoff",
             (float (OpenGl_MaterialState::*)() const) static_cast<float (OpenGl_MaterialState::*)() const>(&OpenGl_MaterialState::AlphaCutoff),
             R"#(Alpha cutoff value.)#" 
          )
        .def("HasAlphaCutoff",
             (bool (OpenGl_MaterialState::*)() const) static_cast<bool (OpenGl_MaterialState::*)() const>(&OpenGl_MaterialState::HasAlphaCutoff),
             R"#(Return TRUE if alpha test should be enabled.)#" 
          )
        .def("ToDistinguish",
             (bool (OpenGl_MaterialState::*)() const) static_cast<bool (OpenGl_MaterialState::*)() const>(&OpenGl_MaterialState::ToDistinguish),
             R"#(Distinguish front/back flag.)#" 
          )
        .def("ToMapTexture",
             (bool (OpenGl_MaterialState::*)() const) static_cast<bool (OpenGl_MaterialState::*)() const>(&OpenGl_MaterialState::ToMapTexture),
             R"#(Flag for mapping a texture.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Material",
             ( const OpenGl_Material & (OpenGl_MaterialState::*)() const) static_cast< const OpenGl_Material & (OpenGl_MaterialState::*)() const>(&OpenGl_MaterialState::Material),
             R"#(Return front material.)#"
             
         )
;

    // Class OpenGl_ModelWorldState from ./opencascade/OpenGl_ShaderStates.hxx
    klass = m.attr("OpenGl_ModelWorldState");


    // nested enums

    static_cast<py::class_<OpenGl_ModelWorldState , shared_ptr<OpenGl_ModelWorldState>  , OpenGl_StateInterface >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Set",
             (void (OpenGl_ModelWorldState::*)(  const NCollection_Mat4<float> &  ) ) static_cast<void (OpenGl_ModelWorldState::*)(  const NCollection_Mat4<float> &  ) >(&OpenGl_ModelWorldState::Set),
             R"#(Sets new model-world matrix.)#"  , py::arg("theModelWorldMatrix")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("ModelWorldMatrix",
             ( const NCollection_Mat4<float> & (OpenGl_ModelWorldState::*)() const) static_cast< const NCollection_Mat4<float> & (OpenGl_ModelWorldState::*)() const>(&OpenGl_ModelWorldState::ModelWorldMatrix),
             R"#(Returns current model-world matrix.)#"
             
         )
       .def("ModelWorldMatrixInverse",
             ( const NCollection_Mat4<float> & (OpenGl_ModelWorldState::*)() const) static_cast< const NCollection_Mat4<float> & (OpenGl_ModelWorldState::*)() const>(&OpenGl_ModelWorldState::ModelWorldMatrixInverse),
             R"#(Returns inverse of current model-world matrix.)#"
             
         )
;

    // Class OpenGl_NamedResource from ./opencascade/OpenGl_NamedResource.hxx
    klass = m.attr("OpenGl_NamedResource");


    // nested enums

    static_cast<py::class_<OpenGl_NamedResource ,opencascade::handle<OpenGl_NamedResource> ,Py_OpenGl_NamedResource , OpenGl_Resource >>(klass)
    // constructors
        .def(py::init<  const TCollection_AsciiString & >()  , py::arg("theId") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_NamedResource::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_NamedResource::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_NamedResource::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_NamedResource::*)() const>(&OpenGl_NamedResource::DynamicType),
             R"#()#"
             
         )
       .def("ResourceId",
             ( const TCollection_AsciiString & (OpenGl_NamedResource::*)() const) static_cast< const TCollection_AsciiString & (OpenGl_NamedResource::*)() const>(&OpenGl_NamedResource::ResourceId),
             R"#(Return resource name.)#"
             
         )
;

    // Class OpenGl_OitState from ./opencascade/OpenGl_ShaderStates.hxx
    klass = m.attr("OpenGl_OitState");


    // nested enums

    static_cast<py::class_<OpenGl_OitState , shared_ptr<OpenGl_OitState>  , OpenGl_StateInterface >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Set",
             (void (OpenGl_OitState::*)( Graphic3d_RenderTransparentMethod ,   const float  ) ) static_cast<void (OpenGl_OitState::*)( Graphic3d_RenderTransparentMethod ,   const float  ) >(&OpenGl_OitState::Set),
             R"#(Sets the uniform values.)#"  , py::arg("theMode"),  py::arg("theDepthFactor")
          )
        .def("ActiveMode",
             (Graphic3d_RenderTransparentMethod (OpenGl_OitState::*)() const) static_cast<Graphic3d_RenderTransparentMethod (OpenGl_OitState::*)() const>(&OpenGl_OitState::ActiveMode),
             R"#(Returns flag indicating whether writing of output for OIT processing should be enabled/disabled.)#" 
          )
        .def("DepthFactor",
             (float (OpenGl_OitState::*)() const) static_cast<float (OpenGl_OitState::*)() const>(&OpenGl_OitState::DepthFactor),
             R"#(Returns factor defining influence of depth component of a fragment to its final coverage coefficient.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_PrimitiveArray from ./opencascade/OpenGl_PrimitiveArray.hxx
    klass = m.attr("OpenGl_PrimitiveArray");


    // nested enums
        klass.attr("DRAW_MODE_NONE") = py::cast(int(OpenGl_PrimitiveArray::DRAW_MODE_NONE));

    static_cast<py::class_<OpenGl_PrimitiveArray , shared_ptr<OpenGl_PrimitiveArray>  , OpenGl_Element >>(klass)
    // constructors
        .def(py::init<  const OpenGl_GraphicDriver * >()  , py::arg("theDriver") )
        .def(py::init<  const OpenGl_GraphicDriver *, const Graphic3d_TypeOfPrimitiveArray, const handle<Graphic3d_IndexBuffer> &, const handle<Graphic3d_Buffer> &, const handle<Graphic3d_BoundBuffer> & >()  , py::arg("theDriver"),  py::arg("theType"),  py::arg("theIndices"),  py::arg("theAttribs"),  py::arg("theBounds") )
    // custom constructors
    // methods
        .def("Render",
             (void (OpenGl_PrimitiveArray::*)(  const handle<OpenGl_Workspace> &  ) const) static_cast<void (OpenGl_PrimitiveArray::*)(  const handle<OpenGl_Workspace> &  ) const>(&OpenGl_PrimitiveArray::Render),
             R"#(Render primitives to the window)#"  , py::arg("theWorkspace")
          )
        .def("Release",
             (void (OpenGl_PrimitiveArray::*)( OpenGl_Context *  ) ) static_cast<void (OpenGl_PrimitiveArray::*)( OpenGl_Context *  ) >(&OpenGl_PrimitiveArray::Release),
             R"#(Release OpenGL resources (VBOs))#"  , py::arg("theContext")
          )
        .def("EstimatedDataSize",
             (size_t (OpenGl_PrimitiveArray::*)() const) static_cast<size_t (OpenGl_PrimitiveArray::*)() const>(&OpenGl_PrimitiveArray::EstimatedDataSize),
             R"#(Returns estimated GPU memory usage for holding data without considering overheads and allocation alignment rules.)#" 
          )
        .def("UpdateDrawStats",
             (void (OpenGl_PrimitiveArray::*)( Graphic3d_FrameStatsDataTmp & ,  bool  ) const) static_cast<void (OpenGl_PrimitiveArray::*)( Graphic3d_FrameStatsDataTmp & ,  bool  ) const>(&OpenGl_PrimitiveArray::UpdateDrawStats),
             R"#(Increment draw calls statistics.)#"  , py::arg("theStats"),  py::arg("theIsDetailed")
          )
        .def("IsInitialized",
             (bool (OpenGl_PrimitiveArray::*)() const) static_cast<bool (OpenGl_PrimitiveArray::*)() const>(&OpenGl_PrimitiveArray::IsInitialized),
             R"#(Return true if VBOs initialization has been performed. VBO initialization is performed during first Render() call. Notice that this flag does not indicate VBOs validity.)#" 
          )
        .def("Invalidate",
             (void (OpenGl_PrimitiveArray::*)() const) static_cast<void (OpenGl_PrimitiveArray::*)() const>(&OpenGl_PrimitiveArray::Invalidate),
             R"#(Invalidate VBO content without destruction.)#" 
          )
        .def("DrawMode",
             (int (OpenGl_PrimitiveArray::*)() const) static_cast<int (OpenGl_PrimitiveArray::*)() const>(&OpenGl_PrimitiveArray::DrawMode),
             R"#(Returns primitive type (GL_LINES, GL_TRIANGLES and others))#" 
          )
        .def("IsFillDrawMode",
             (bool (OpenGl_PrimitiveArray::*)() const) static_cast<bool (OpenGl_PrimitiveArray::*)() const>(&OpenGl_PrimitiveArray::IsFillDrawMode),
             R"#(Return TRUE if primitive type generates shaded triangulation.)#" 
          )
        .def("GetUID",
             (size_t (OpenGl_PrimitiveArray::*)() const) static_cast<size_t (OpenGl_PrimitiveArray::*)() const>(&OpenGl_PrimitiveArray::GetUID),
             R"#(Returns unique ID of primitive array.)#" 
          )
        .def("InitBuffers",
             (void (OpenGl_PrimitiveArray::*)(  const handle<OpenGl_Context> & ,   const Graphic3d_TypeOfPrimitiveArray ,   const handle<Graphic3d_IndexBuffer> & ,   const handle<Graphic3d_Buffer> & ,   const handle<Graphic3d_BoundBuffer> &  ) ) static_cast<void (OpenGl_PrimitiveArray::*)(  const handle<OpenGl_Context> & ,   const Graphic3d_TypeOfPrimitiveArray ,   const handle<Graphic3d_IndexBuffer> & ,   const handle<Graphic3d_Buffer> & ,   const handle<Graphic3d_BoundBuffer> &  ) >(&OpenGl_PrimitiveArray::InitBuffers),
             R"#(Initialize indices, attributes and bounds with new data.)#"  , py::arg("theContext"),  py::arg("theType"),  py::arg("theIndices"),  py::arg("theAttribs"),  py::arg("theBounds")
          )
        .def("DumpJson",
             (void (OpenGl_PrimitiveArray::*)( Standard_OStream & ,  int  ) const) static_cast<void (OpenGl_PrimitiveArray::*)( Standard_OStream & ,  int  ) const>(&OpenGl_PrimitiveArray::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Indices",
             ( const handle<Graphic3d_IndexBuffer> & (OpenGl_PrimitiveArray::*)() const) static_cast< const handle<Graphic3d_IndexBuffer> & (OpenGl_PrimitiveArray::*)() const>(&OpenGl_PrimitiveArray::Indices),
             R"#(Returns indices array)#"
             
         )
       .def("Attributes",
             ( const handle<Graphic3d_Buffer> & (OpenGl_PrimitiveArray::*)() const) static_cast< const handle<Graphic3d_Buffer> & (OpenGl_PrimitiveArray::*)() const>(&OpenGl_PrimitiveArray::Attributes),
             R"#(Returns attributes array)#"
             
         )
       .def("Bounds",
             ( const handle<Graphic3d_BoundBuffer> & (OpenGl_PrimitiveArray::*)() const) static_cast< const handle<Graphic3d_BoundBuffer> & (OpenGl_PrimitiveArray::*)() const>(&OpenGl_PrimitiveArray::Bounds),
             R"#(Returns bounds array)#"
             
         )
       .def("IndexVbo",
             ( const handle<OpenGl_IndexBuffer> & (OpenGl_PrimitiveArray::*)() const) static_cast< const handle<OpenGl_IndexBuffer> & (OpenGl_PrimitiveArray::*)() const>(&OpenGl_PrimitiveArray::IndexVbo),
             R"#(Returns index VBO.)#"
             
         )
       .def("AttributesVbo",
             ( const handle<OpenGl_VertexBuffer> & (OpenGl_PrimitiveArray::*)() const) static_cast< const handle<OpenGl_VertexBuffer> & (OpenGl_PrimitiveArray::*)() const>(&OpenGl_PrimitiveArray::AttributesVbo),
             R"#(Returns attributes VBO.)#"
             
         )
;

    // Class OpenGl_ProjectionState from ./opencascade/OpenGl_ShaderStates.hxx
    klass = m.attr("OpenGl_ProjectionState");


    // nested enums

    static_cast<py::class_<OpenGl_ProjectionState , shared_ptr<OpenGl_ProjectionState>  , OpenGl_StateInterface >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Set",
             (void (OpenGl_ProjectionState::*)(  const NCollection_Mat4<float> &  ) ) static_cast<void (OpenGl_ProjectionState::*)(  const NCollection_Mat4<float> &  ) >(&OpenGl_ProjectionState::Set),
             R"#(Sets new projection matrix.)#"  , py::arg("theProjectionMatrix")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("ProjectionMatrix",
             ( const NCollection_Mat4<float> & (OpenGl_ProjectionState::*)() const) static_cast< const NCollection_Mat4<float> & (OpenGl_ProjectionState::*)() const>(&OpenGl_ProjectionState::ProjectionMatrix),
             R"#(Returns current projection matrix.)#"
             
         )
       .def("ProjectionMatrixInverse",
             ( const NCollection_Mat4<float> & (OpenGl_ProjectionState::*)() const) static_cast< const NCollection_Mat4<float> & (OpenGl_ProjectionState::*)() const>(&OpenGl_ProjectionState::ProjectionMatrixInverse),
             R"#(Returns inverse of current projection matrix.)#"
             
         )
;

    // Class OpenGl_Sampler from ./opencascade/OpenGl_Sampler.hxx
    klass = m.attr("OpenGl_Sampler");


    // nested enums

    static_cast<py::class_<OpenGl_Sampler ,opencascade::handle<OpenGl_Sampler>  , OpenGl_Resource >>(klass)
    // constructors
        .def(py::init<  const handle<Graphic3d_TextureParams> & >()  , py::arg("theParams") )
    // custom constructors
    // methods
        .def("Release",
             (void (OpenGl_Sampler::*)( OpenGl_Context *  ) ) static_cast<void (OpenGl_Sampler::*)( OpenGl_Context *  ) >(&OpenGl_Sampler::Release),
             R"#(Destroys object - will release GPU memory if any.)#"  , py::arg("theContext")
          )
        .def("EstimatedDataSize",
             (size_t (OpenGl_Sampler::*)() const) static_cast<size_t (OpenGl_Sampler::*)() const>(&OpenGl_Sampler::EstimatedDataSize),
             R"#(Returns estimated GPU memory usage - not implemented.)#" 
          )
        .def("Create",
             (bool (OpenGl_Sampler::*)(  const handle<OpenGl_Context> &  ) ) static_cast<bool (OpenGl_Sampler::*)(  const handle<OpenGl_Context> &  ) >(&OpenGl_Sampler::Create),
             R"#(Creates an uninitialized sampler object.)#"  , py::arg("theContext")
          )
        .def("Init",
             (bool (OpenGl_Sampler::*)(  const handle<OpenGl_Context> & ,   const OpenGl_Texture &  ) ) static_cast<bool (OpenGl_Sampler::*)(  const handle<OpenGl_Context> & ,   const OpenGl_Texture &  ) >(&OpenGl_Sampler::Init),
             R"#(Creates and initializes sampler object. Existing object will be reused if possible, however if existing Sampler Object has Immutable flag and texture parameters should be re-initialized, then Sampler Object will be recreated.)#"  , py::arg("theContext"),  py::arg("theTexture")
          )
        .def("IsValid",
             (bool (OpenGl_Sampler::*)() const) static_cast<bool (OpenGl_Sampler::*)() const>(&OpenGl_Sampler::IsValid),
             R"#(Returns true if current object was initialized.)#" 
          )
        .def("Bind",
             (void (OpenGl_Sampler::*)(  const handle<OpenGl_Context> &  ) ) static_cast<void (OpenGl_Sampler::*)(  const handle<OpenGl_Context> &  ) >(&OpenGl_Sampler::Bind),
             R"#(Binds sampler object to texture unit specified in parameters.)#"  , py::arg("theCtx")
          )
        .def("Unbind",
             (void (OpenGl_Sampler::*)(  const handle<OpenGl_Context> &  ) ) static_cast<void (OpenGl_Sampler::*)(  const handle<OpenGl_Context> &  ) >(&OpenGl_Sampler::Unbind),
             R"#(Unbinds sampler object from texture unit specified in parameters.)#"  , py::arg("theCtx")
          )
        .def("Bind",
             (void (OpenGl_Sampler::*)(  const handle<OpenGl_Context> & ,   const Graphic3d_TextureUnit  ) ) static_cast<void (OpenGl_Sampler::*)(  const handle<OpenGl_Context> & ,   const Graphic3d_TextureUnit  ) >(&OpenGl_Sampler::Bind),
             R"#(Binds sampler object to the given texture unit.)#"  , py::arg("theCtx"),  py::arg("theUnit")
          )
        .def("Unbind",
             (void (OpenGl_Sampler::*)(  const handle<OpenGl_Context> & ,   const Graphic3d_TextureUnit  ) ) static_cast<void (OpenGl_Sampler::*)(  const handle<OpenGl_Context> & ,   const Graphic3d_TextureUnit  ) >(&OpenGl_Sampler::Unbind),
             R"#(Unbinds sampler object from the given texture unit.)#"  , py::arg("theCtx"),  py::arg("theUnit")
          )
        .def("SetParameter",
             (void (OpenGl_Sampler::*)(  const handle<OpenGl_Context> & ,  unsigned int ,  unsigned int ,  int  ) ) static_cast<void (OpenGl_Sampler::*)(  const handle<OpenGl_Context> & ,  unsigned int ,  unsigned int ,  int  ) >(&OpenGl_Sampler::SetParameter),
             R"#(Sets specific sampler parameter.)#"  , py::arg("theCtx"),  py::arg("theTarget"),  py::arg("theParam"),  py::arg("theValue")
          )
        .def("SamplerID",
             (unsigned int (OpenGl_Sampler::*)() const) static_cast<unsigned int (OpenGl_Sampler::*)() const>(&OpenGl_Sampler::SamplerID),
             R"#(Returns OpenGL sampler ID.)#" 
          )
        .def("IsImmutable",
             (bool (OpenGl_Sampler::*)() const) static_cast<bool (OpenGl_Sampler::*)() const>(&OpenGl_Sampler::IsImmutable),
             R"#(Return immutable flag preventing further modifications of sampler parameters, FALSE by default. Immutable flag might be set when Sampler Object is used within Bindless Texture.)#" 
          )
        .def("SetImmutable",
             (void (OpenGl_Sampler::*)() ) static_cast<void (OpenGl_Sampler::*)() >(&OpenGl_Sampler::SetImmutable),
             R"#(Setup immutable flag. It is not possible unsetting this flag without Sampler destruction.)#" 
          )
        .def("SetParameters",
             (void (OpenGl_Sampler::*)(  const handle<Graphic3d_TextureParams> &  ) ) static_cast<void (OpenGl_Sampler::*)(  const handle<Graphic3d_TextureParams> &  ) >(&OpenGl_Sampler::SetParameters),
             R"#(Sets texture parameters.)#"  , py::arg("theParams")
          )
        .def("ToUpdateParameters",
             (bool (OpenGl_Sampler::*)() const) static_cast<bool (OpenGl_Sampler::*)() const>(&OpenGl_Sampler::ToUpdateParameters),
             R"#(Returns texture parameters initialization state.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_Sampler::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_Sampler::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_Sampler::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_Sampler::*)() const>(&OpenGl_Sampler::DynamicType),
             R"#()#"
             
         )
       .def("Parameters",
             ( const handle<Graphic3d_TextureParams> & (OpenGl_Sampler::*)() ) static_cast< const handle<Graphic3d_TextureParams> & (OpenGl_Sampler::*)() >(&OpenGl_Sampler::Parameters),
             R"#(Returns texture parameters.)#"
             
         )
;

    // Class OpenGl_ShaderObject from ./opencascade/OpenGl_ShaderObject.hxx
    klass = m.attr("OpenGl_ShaderObject");


    // nested enums

    static_cast<py::class_<OpenGl_ShaderObject ,opencascade::handle<OpenGl_ShaderObject>  , OpenGl_Resource >>(klass)
    // constructors
        .def(py::init< GLenum >()  , py::arg("theType") )
    // custom constructors
    // methods
        .def("LoadSource",
             (bool (OpenGl_ShaderObject::*)(  const handle<OpenGl_Context> & ,   const TCollection_AsciiString &  ) ) static_cast<bool (OpenGl_ShaderObject::*)(  const handle<OpenGl_Context> & ,   const TCollection_AsciiString &  ) >(&OpenGl_ShaderObject::LoadSource),
             R"#(Loads shader source code.)#"  , py::arg("theCtx"),  py::arg("theSource")
          )
        .def("Compile",
             (bool (OpenGl_ShaderObject::*)(  const handle<OpenGl_Context> &  ) ) static_cast<bool (OpenGl_ShaderObject::*)(  const handle<OpenGl_Context> &  ) >(&OpenGl_ShaderObject::Compile),
             R"#(Compiles the shader object.)#"  , py::arg("theCtx")
          )
        .def("LoadAndCompile",
             (bool (OpenGl_ShaderObject::*)(  const handle<OpenGl_Context> & ,   const TCollection_AsciiString & ,   const TCollection_AsciiString & ,  bool ,  bool  ) ) static_cast<bool (OpenGl_ShaderObject::*)(  const handle<OpenGl_Context> & ,   const TCollection_AsciiString & ,   const TCollection_AsciiString & ,  bool ,  bool  ) >(&OpenGl_ShaderObject::LoadAndCompile),
             R"#(Wrapper for compiling shader object with verbose printing on error.)#"  , py::arg("theCtx"),  py::arg("theId"),  py::arg("theSource"),  py::arg("theIsVerbose")=static_cast<bool>(true),  py::arg("theToPrintSource")=static_cast<bool>(true)
          )
        .def("DumpSourceCode",
             (void (OpenGl_ShaderObject::*)(  const handle<OpenGl_Context> & ,   const TCollection_AsciiString & ,   const TCollection_AsciiString &  ) const) static_cast<void (OpenGl_ShaderObject::*)(  const handle<OpenGl_Context> & ,   const TCollection_AsciiString & ,   const TCollection_AsciiString &  ) const>(&OpenGl_ShaderObject::DumpSourceCode),
             R"#(Print source code of this shader object to messenger.)#"  , py::arg("theCtx"),  py::arg("theId"),  py::arg("theSource")
          )
        .def("FetchInfoLog",
             (bool (OpenGl_ShaderObject::*)(  const handle<OpenGl_Context> & ,  TCollection_AsciiString &  ) ) static_cast<bool (OpenGl_ShaderObject::*)(  const handle<OpenGl_Context> & ,  TCollection_AsciiString &  ) >(&OpenGl_ShaderObject::FetchInfoLog),
             R"#(Fetches information log of the last compile operation.)#"  , py::arg("theCtx"),  py::arg("theLog")
          )
        .def("Create",
             (bool (OpenGl_ShaderObject::*)(  const handle<OpenGl_Context> &  ) ) static_cast<bool (OpenGl_ShaderObject::*)(  const handle<OpenGl_Context> &  ) >(&OpenGl_ShaderObject::Create),
             R"#(Creates new empty shader object of specified type.)#"  , py::arg("theCtx")
          )
        .def("Release",
             (void (OpenGl_ShaderObject::*)( OpenGl_Context *  ) ) static_cast<void (OpenGl_ShaderObject::*)( OpenGl_Context *  ) >(&OpenGl_ShaderObject::Release),
             R"#(Destroys shader object.)#"  , py::arg("theCtx")
          )
        .def("EstimatedDataSize",
             (size_t (OpenGl_ShaderObject::*)() const) static_cast<size_t (OpenGl_ShaderObject::*)() const>(&OpenGl_ShaderObject::EstimatedDataSize),
             R"#(Returns estimated GPU memory usage - not implemented.)#" 
          )
        .def("Type",
             (GLenum (OpenGl_ShaderObject::*)() const) static_cast<GLenum (OpenGl_ShaderObject::*)() const>(&OpenGl_ShaderObject::Type),
             R"#(Returns type of shader object.)#" 
          )
        .def("updateDebugDump",
             (bool (OpenGl_ShaderObject::*)(  const handle<OpenGl_Context> & ,   const TCollection_AsciiString & ,   const TCollection_AsciiString & ,  bool ,  bool  ) ) static_cast<bool (OpenGl_ShaderObject::*)(  const handle<OpenGl_Context> & ,   const TCollection_AsciiString & ,   const TCollection_AsciiString & ,  bool ,  bool  ) >(&OpenGl_ShaderObject::updateDebugDump),
             R"#(Update the shader object from external file in the following way: 1) If external file does not exist, then it will be created (current source code will be dumped, no recompilation) and FALSE will be returned. 2) If external file exists and it has the same timestamp as myDumpDate, nothing will be done and FALSE will be returned. 3) If external file exists and it has newer timestamp than myDumpDate, shader will be recompiled and TRUE will be returned.)#"  , py::arg("theCtx"),  py::arg("theId"),  py::arg("theFolder"),  py::arg("theToBeautify"),  py::arg("theToReset")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_ShaderObject::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_ShaderObject::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_ShaderObject::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_ShaderObject::*)() const>(&OpenGl_ShaderObject::DynamicType),
             R"#()#"
             
         )
;

    // Class OpenGl_StencilTest from ./opencascade/OpenGl_StencilTest.hxx
    klass = m.attr("OpenGl_StencilTest");


    // nested enums

    static_cast<py::class_<OpenGl_StencilTest , shared_ptr_nodelete<OpenGl_StencilTest>  , OpenGl_Element >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Render",
             (void (OpenGl_StencilTest::*)(  const handle<OpenGl_Workspace> &  ) const) static_cast<void (OpenGl_StencilTest::*)(  const handle<OpenGl_Workspace> &  ) const>(&OpenGl_StencilTest::Render),
             R"#(Render primitives to the window)#"  , py::arg("theWorkspace")
          )
        .def("Release",
             (void (OpenGl_StencilTest::*)( OpenGl_Context *  ) ) static_cast<void (OpenGl_StencilTest::*)( OpenGl_Context *  ) >(&OpenGl_StencilTest::Release),
             R"#()#"  , py::arg("theContext")
          )
        .def("SetOptions",
             (void (OpenGl_StencilTest::*)(  const bool  ) ) static_cast<void (OpenGl_StencilTest::*)(  const bool  ) >(&OpenGl_StencilTest::SetOptions),
             R"#()#"  , py::arg("theIsEnabled")
          )
        .def("DumpJson",
             (void (OpenGl_StencilTest::*)( Standard_OStream & ,  int  ) const) static_cast<void (OpenGl_StencilTest::*)( Standard_OStream & ,  int  ) const>(&OpenGl_StencilTest::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_StructureShadow from ./opencascade/OpenGl_StructureShadow.hxx
    klass = m.attr("OpenGl_StructureShadow");


    // nested enums

    static_cast<py::class_<OpenGl_StructureShadow ,opencascade::handle<OpenGl_StructureShadow>  , OpenGl_Structure >>(klass)
    // constructors
        .def(py::init<  const handle<Graphic3d_StructureManager> &, const handle<OpenGl_Structure> & >()  , py::arg("theManager"),  py::arg("theStructure") )
    // custom constructors
    // methods
        .def("Connect",
             (void (OpenGl_StructureShadow::*)( Graphic3d_CStructure &  ) ) static_cast<void (OpenGl_StructureShadow::*)( Graphic3d_CStructure &  ) >(&OpenGl_StructureShadow::Connect),
             R"#(Raise exception on API misuse.)#"  , py::arg("arg0")
          )
        .def("Disconnect",
             (void (OpenGl_StructureShadow::*)( Graphic3d_CStructure &  ) ) static_cast<void (OpenGl_StructureShadow::*)( Graphic3d_CStructure &  ) >(&OpenGl_StructureShadow::Disconnect),
             R"#(Raise exception on API misuse.)#"  , py::arg("arg0")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_StructureShadow::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_StructureShadow::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_StructureShadow::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_StructureShadow::*)() const>(&OpenGl_StructureShadow::DynamicType),
             R"#()#"
             
         )
;

    // Class OpenGl_Text from ./opencascade/OpenGl_Text.hxx
    klass = m.attr("OpenGl_Text");


    // nested enums

    static_cast<py::class_<OpenGl_Text , shared_ptr<OpenGl_Text>  , OpenGl_Element >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<Graphic3d_Text> & >()  , py::arg("theTextParams") )
    // custom constructors
    // methods
        .def("Reset",
             (void (OpenGl_Text::*)(  const handle<OpenGl_Context> &  ) ) static_cast<void (OpenGl_Text::*)(  const handle<OpenGl_Context> &  ) >(&OpenGl_Text::Reset),
             R"#(Release cached VBO resources and the previous font if height changed. Cached structures will be refilled by the next render. Call Reset after modifying text parameters.)#"  , py::arg("theCtx")
          )
        .def("SetText",
             (void (OpenGl_Text::*)(  const handle<Graphic3d_Text> &  ) ) static_cast<void (OpenGl_Text::*)(  const handle<Graphic3d_Text> &  ) >(&OpenGl_Text::SetText),
             R"#(Sets text parameters)#"  , py::arg("theText")
          )
        .def("Is2D",
             (bool (OpenGl_Text::*)() const) static_cast<bool (OpenGl_Text::*)() const>(&OpenGl_Text::Is2D),
             R"#(Return true if text is 2D)#" 
          )
        .def("Set2D",
             (void (OpenGl_Text::*)(  const bool  ) ) static_cast<void (OpenGl_Text::*)(  const bool  ) >(&OpenGl_Text::Set2D),
             R"#(Set true if text is 2D)#"  , py::arg("theEnable")
          )
        .def("SetFontSize",
             (void (OpenGl_Text::*)(  const handle<OpenGl_Context> & ,   const int  ) ) static_cast<void (OpenGl_Text::*)(  const handle<OpenGl_Context> & ,   const int  ) >(&OpenGl_Text::SetFontSize),
             R"#(Setup new font size)#"  , py::arg("theContext"),  py::arg("theFontSize")
          )
        .def("Render",
             (void (OpenGl_Text::*)(  const handle<OpenGl_Workspace> &  ) const) static_cast<void (OpenGl_Text::*)(  const handle<OpenGl_Workspace> &  ) const>(&OpenGl_Text::Render),
             R"#()#"  , py::arg("theWorkspace")
          )
        .def("Release",
             (void (OpenGl_Text::*)( OpenGl_Context *  ) ) static_cast<void (OpenGl_Text::*)( OpenGl_Context *  ) >(&OpenGl_Text::Release),
             R"#()#"  , py::arg("theContext")
          )
        .def("EstimatedDataSize",
             (size_t (OpenGl_Text::*)() const) static_cast<size_t (OpenGl_Text::*)() const>(&OpenGl_Text::EstimatedDataSize),
             R"#(Returns estimated GPU memory usage for holding data without considering overheads and allocation alignment rules.)#" 
          )
        .def("UpdateDrawStats",
             (void (OpenGl_Text::*)( Graphic3d_FrameStatsDataTmp & ,  bool  ) const) static_cast<void (OpenGl_Text::*)( Graphic3d_FrameStatsDataTmp & ,  bool  ) const>(&OpenGl_Text::UpdateDrawStats),
             R"#(Increment draw calls statistics.)#"  , py::arg("theStats"),  py::arg("theIsDetailed")
          )
        .def("Render",
             (void (OpenGl_Text::*)(  const handle<OpenGl_Context> & ,   const OpenGl_Aspects & ,  unsigned int ,  Font_Hinting  ) const) static_cast<void (OpenGl_Text::*)(  const handle<OpenGl_Context> & ,   const OpenGl_Aspects & ,  unsigned int ,  Font_Hinting  ) const>(&OpenGl_Text::Render),
             R"#(Perform rendering)#"  , py::arg("theCtx"),  py::arg("theTextAspect"),  py::arg("theResolution")=static_cast<unsigned int>(Graphic3d_RenderingParams :: THE_DEFAULT_RESOLUTION),  py::arg("theFontHinting")=static_cast<Font_Hinting>(Font_Hinting_Off)
          )
        .def("DumpJson",
             (void (OpenGl_Text::*)( Standard_OStream & ,  int  ) const) static_cast<void (OpenGl_Text::*)( Standard_OStream & ,  int  ) const>(&OpenGl_Text::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
        .def("Init",
             (void (OpenGl_Text::*)(  const handle<OpenGl_Context> & ,   const char * ,   const NCollection_Vec3<float> &  ) ) static_cast<void (OpenGl_Text::*)(  const handle<OpenGl_Context> & ,   const char * ,   const NCollection_Vec3<float> &  ) >(&OpenGl_Text::Init),
             R"#(Setup new string and position)#"  , py::arg("theCtx"),  py::arg("theText"),  py::arg("thePoint")
          )
        .def("SetPosition",
             (void (OpenGl_Text::*)(  const NCollection_Vec3<float> &  ) ) static_cast<void (OpenGl_Text::*)(  const NCollection_Vec3<float> &  ) >(&OpenGl_Text::SetPosition),
             R"#(Setup new position)#"  , py::arg("thePoint")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("FontKey_s",
                    (TCollection_AsciiString (*)(  const OpenGl_Aspects & ,  int ,  unsigned int ,  Font_Hinting  ) ) static_cast<TCollection_AsciiString (*)(  const OpenGl_Aspects & ,  int ,  unsigned int ,  Font_Hinting  ) >(&OpenGl_Text::FontKey),
                    R"#(Create key for shared resource)#"  , py::arg("theAspect"),  py::arg("theHeight"),  py::arg("theResolution"),  py::arg("theFontHinting")
          )
        .def_static("FindFont_s",
                    (handle<OpenGl_Font> (*)(  const handle<OpenGl_Context> & ,   const OpenGl_Aspects & ,  int ,  unsigned int ,  Font_Hinting ,   const TCollection_AsciiString &  ) ) static_cast<handle<OpenGl_Font> (*)(  const handle<OpenGl_Context> & ,   const OpenGl_Aspects & ,  int ,  unsigned int ,  Font_Hinting ,   const TCollection_AsciiString &  ) >(&OpenGl_Text::FindFont),
                    R"#(Find shared resource for specified font or initialize new one)#"  , py::arg("theCtx"),  py::arg("theAspect"),  py::arg("theHeight"),  py::arg("theResolution"),  py::arg("theFontHinting"),  py::arg("theKey")
          )
    // static methods using call by reference i.s.o. return
        .def_static("StringSize_s",
            []( const handle<OpenGl_Context> & theCtx, const NCollection_String & theText, const OpenGl_Aspects & theTextAspect, const float theHeight, const unsigned int theResolution, const Font_Hinting theFontHinting ){
                float  theWidth;
                float  theAscent;
                float  theDescent;

                OpenGl_Text::StringSize(theCtx,theText,theTextAspect,theHeight,theResolution,theFontHinting,theWidth,theAscent,theDescent);
                
return std::make_tuple(theWidth,theAscent,theDescent); },
            R"#(Compute text width)#"  , py::arg("theCtx"),  py::arg("theText"),  py::arg("theTextAspect"),  py::arg("theHeight"),  py::arg("theResolution"),  py::arg("theFontHinting")
          )
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Text",
             ( const handle<Graphic3d_Text> & (OpenGl_Text::*)() const) static_cast< const handle<Graphic3d_Text> & (OpenGl_Text::*)() const>(&OpenGl_Text::Text),
             R"#(Returns text parameters)#"
             
         )
;

    // Class OpenGl_WorldViewState from ./opencascade/OpenGl_ShaderStates.hxx
    klass = m.attr("OpenGl_WorldViewState");


    // nested enums

    static_cast<py::class_<OpenGl_WorldViewState , shared_ptr<OpenGl_WorldViewState>  , OpenGl_StateInterface >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Set",
             (void (OpenGl_WorldViewState::*)(  const NCollection_Mat4<float> &  ) ) static_cast<void (OpenGl_WorldViewState::*)(  const NCollection_Mat4<float> &  ) >(&OpenGl_WorldViewState::Set),
             R"#(Sets new world-view matrix.)#"  , py::arg("theWorldViewMatrix")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("WorldViewMatrix",
             ( const NCollection_Mat4<float> & (OpenGl_WorldViewState::*)() const) static_cast< const NCollection_Mat4<float> & (OpenGl_WorldViewState::*)() const>(&OpenGl_WorldViewState::WorldViewMatrix),
             R"#(Returns current world-view matrix.)#"
             
         )
       .def("WorldViewMatrixInverse",
             ( const NCollection_Mat4<float> & (OpenGl_WorldViewState::*)() const) static_cast< const NCollection_Mat4<float> & (OpenGl_WorldViewState::*)() const>(&OpenGl_WorldViewState::WorldViewMatrixInverse),
             R"#(Returns inverse of current world-view matrix.)#"
             
         )
;

    // Class OpenGl_BackgroundArray from ./opencascade/OpenGl_BackgroundArray.hxx
    klass = m.attr("OpenGl_BackgroundArray");


    // nested enums

    static_cast<py::class_<OpenGl_BackgroundArray , shared_ptr<OpenGl_BackgroundArray>  , OpenGl_PrimitiveArray >>(klass)
    // constructors
        .def(py::init<  const Graphic3d_TypeOfBackground >()  , py::arg("theType") )
    // custom constructors
    // methods
        .def("Render",
             (void (OpenGl_BackgroundArray::*)(  const handle<OpenGl_Workspace> & ,  Graphic3d_Camera::Projection  ) const) static_cast<void (OpenGl_BackgroundArray::*)(  const handle<OpenGl_Workspace> & ,  Graphic3d_Camera::Projection  ) const>(&OpenGl_BackgroundArray::Render),
             R"#(Render primitives to the window)#"  , py::arg("theWorkspace"),  py::arg("theProjection")
          )
        .def("IsDefined",
             (bool (OpenGl_BackgroundArray::*)() const) static_cast<bool (OpenGl_BackgroundArray::*)() const>(&OpenGl_BackgroundArray::IsDefined),
             R"#(Check if background parameters are set properly)#" 
          )
        .def("SetTextureParameters",
             (void (OpenGl_BackgroundArray::*)(  const Aspect_FillMethod  ) ) static_cast<void (OpenGl_BackgroundArray::*)(  const Aspect_FillMethod  ) >(&OpenGl_BackgroundArray::SetTextureParameters),
             R"#(Sets background texture parameters)#"  , py::arg("theFillMethod")
          )
        .def("SetTextureFillMethod",
             (void (OpenGl_BackgroundArray::*)(  const Aspect_FillMethod  ) ) static_cast<void (OpenGl_BackgroundArray::*)(  const Aspect_FillMethod  ) >(&OpenGl_BackgroundArray::SetTextureFillMethod),
             R"#(Sets texture fill method)#"  , py::arg("theFillMethod")
          )
        .def("TextureFillMethod",
             (Aspect_FillMethod (OpenGl_BackgroundArray::*)() const) static_cast<Aspect_FillMethod (OpenGl_BackgroundArray::*)() const>(&OpenGl_BackgroundArray::TextureFillMethod),
             R"#(Gets background texture fill method)#" 
          )
        .def("GradientFillMethod",
             (Aspect_GradientFillMethod (OpenGl_BackgroundArray::*)() const) static_cast<Aspect_GradientFillMethod (OpenGl_BackgroundArray::*)() const>(&OpenGl_BackgroundArray::GradientFillMethod),
             R"#(Gets background gradient fill method)#" 
          )
        .def("GradientColor",
             ( const NCollection_Vec4<float> & (OpenGl_BackgroundArray::*)(  const int  ) const) static_cast< const NCollection_Vec4<float> & (OpenGl_BackgroundArray::*)(  const int  ) const>(&OpenGl_BackgroundArray::GradientColor),
             R"#(Returns color of gradient background for the given index.)#"  , py::arg("theIndex")
          )
        .def("SetGradientFillMethod",
             (void (OpenGl_BackgroundArray::*)(  const Aspect_GradientFillMethod  ) ) static_cast<void (OpenGl_BackgroundArray::*)(  const Aspect_GradientFillMethod  ) >(&OpenGl_BackgroundArray::SetGradientFillMethod),
             R"#(Sets type of gradient fill method)#"  , py::arg("theType")
          )
        .def("SetGradientParameters",
             (void (OpenGl_BackgroundArray::*)(  const Quantity_Color & ,   const Quantity_Color & ,   const Aspect_GradientFillMethod  ) ) static_cast<void (OpenGl_BackgroundArray::*)(  const Quantity_Color & ,   const Quantity_Color & ,   const Aspect_GradientFillMethod  ) >(&OpenGl_BackgroundArray::SetGradientParameters),
             R"#(Sets background gradient parameters)#"  , py::arg("theColor1"),  py::arg("theColor2"),  py::arg("theType")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class OpenGl_DepthPeeling from ./opencascade/OpenGl_DepthPeeling.hxx
    klass = m.attr("OpenGl_DepthPeeling");


    // nested enums

    static_cast<py::class_<OpenGl_DepthPeeling ,opencascade::handle<OpenGl_DepthPeeling>  , OpenGl_NamedResource >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Release",
             (void (OpenGl_DepthPeeling::*)( OpenGl_Context *  ) ) static_cast<void (OpenGl_DepthPeeling::*)( OpenGl_Context *  ) >(&OpenGl_DepthPeeling::Release),
             R"#(Release OpenGL resources)#"  , py::arg("theGlCtx")
          )
        .def("EstimatedDataSize",
             (size_t (OpenGl_DepthPeeling::*)() const) static_cast<size_t (OpenGl_DepthPeeling::*)() const>(&OpenGl_DepthPeeling::EstimatedDataSize),
             R"#(Returns estimated GPU memory usage for holding data without considering overheads and allocation alignment rules.)#" 
          )
        .def("AttachDepthTexture",
             (void (OpenGl_DepthPeeling::*)(  const handle<OpenGl_Context> & ,   const handle<OpenGl_Texture> &  ) ) static_cast<void (OpenGl_DepthPeeling::*)(  const handle<OpenGl_Context> & ,   const handle<OpenGl_Texture> &  ) >(&OpenGl_DepthPeeling::AttachDepthTexture),
             R"#(Attach a texture image. Resets the active FBO to 0.)#"  , py::arg("theCtx"),  py::arg("theDepthStencilTexture")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_DepthPeeling::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_DepthPeeling::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_DepthPeeling::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_DepthPeeling::*)() const>(&OpenGl_DepthPeeling::DynamicType),
             R"#()#"
             
         )
       .def("BlendBackFboOit",
             ( const handle<OpenGl_FrameBuffer> & (OpenGl_DepthPeeling::*)() const) static_cast< const handle<OpenGl_FrameBuffer> & (OpenGl_DepthPeeling::*)() const>(&OpenGl_DepthPeeling::BlendBackFboOit),
             R"#(Returns additional FBO for depth peeling)#"
             
         )
;

    // Class OpenGl_FrameBuffer from ./opencascade/OpenGl_FrameBuffer.hxx
    klass = m.attr("OpenGl_FrameBuffer");


    // nested enums

    static_cast<py::class_<OpenGl_FrameBuffer ,opencascade::handle<OpenGl_FrameBuffer>  , OpenGl_NamedResource >>(klass)
    // constructors
        .def(py::init<  const TCollection_AsciiString & >()  , py::arg("theResourceId")=static_cast< const TCollection_AsciiString &>(TCollection_AsciiString :: EmptyString ( )) )
    // custom constructors
    // methods
        .def("Release",
             (void (OpenGl_FrameBuffer::*)( OpenGl_Context *  ) ) static_cast<void (OpenGl_FrameBuffer::*)( OpenGl_Context *  ) >(&OpenGl_FrameBuffer::Release),
             R"#(Destroy object - will release GPU memory if any.)#"  , py::arg("theGlCtx")
          )
        .def("NbSamples",
             (int (OpenGl_FrameBuffer::*)() const) static_cast<int (OpenGl_FrameBuffer::*)() const>(&OpenGl_FrameBuffer::NbSamples),
             R"#(Number of multisampling samples.)#" 
          )
        .def("NbColorBuffers",
             (int (OpenGl_FrameBuffer::*)() const) static_cast<int (OpenGl_FrameBuffer::*)() const>(&OpenGl_FrameBuffer::NbColorBuffers),
             R"#(Number of color buffers.)#" 
          )
        .def("HasColor",
             (bool (OpenGl_FrameBuffer::*)() const) static_cast<bool (OpenGl_FrameBuffer::*)() const>(&OpenGl_FrameBuffer::HasColor),
             R"#(Return true if FBO has been created with color attachment.)#" 
          )
        .def("HasDepth",
             (bool (OpenGl_FrameBuffer::*)() const) static_cast<bool (OpenGl_FrameBuffer::*)() const>(&OpenGl_FrameBuffer::HasDepth),
             R"#(Return true if FBO has been created with depth attachment.)#" 
          )
        .def("GetSize",
             (NCollection_Vec2<int> (OpenGl_FrameBuffer::*)() const) static_cast<NCollection_Vec2<int> (OpenGl_FrameBuffer::*)() const>(&OpenGl_FrameBuffer::GetSize),
             R"#(Return textures width x height.)#" 
          )
        .def("GetSizeX",
             (int (OpenGl_FrameBuffer::*)() const) static_cast<int (OpenGl_FrameBuffer::*)() const>(&OpenGl_FrameBuffer::GetSizeX),
             R"#(Textures width.)#" 
          )
        .def("GetSizeY",
             (int (OpenGl_FrameBuffer::*)() const) static_cast<int (OpenGl_FrameBuffer::*)() const>(&OpenGl_FrameBuffer::GetSizeY),
             R"#(Textures height.)#" 
          )
        .def("GetVPSize",
             (NCollection_Vec2<int> (OpenGl_FrameBuffer::*)() const) static_cast<NCollection_Vec2<int> (OpenGl_FrameBuffer::*)() const>(&OpenGl_FrameBuffer::GetVPSize),
             R"#(Return viewport width x height.)#" 
          )
        .def("GetVPSizeX",
             (int (OpenGl_FrameBuffer::*)() const) static_cast<int (OpenGl_FrameBuffer::*)() const>(&OpenGl_FrameBuffer::GetVPSizeX),
             R"#(Viewport width.)#" 
          )
        .def("GetVPSizeY",
             (int (OpenGl_FrameBuffer::*)() const) static_cast<int (OpenGl_FrameBuffer::*)() const>(&OpenGl_FrameBuffer::GetVPSizeY),
             R"#(Viewport height.)#" 
          )
        .def("GetInitVPSize",
             (NCollection_Vec2<int> (OpenGl_FrameBuffer::*)() const) static_cast<NCollection_Vec2<int> (OpenGl_FrameBuffer::*)() const>(&OpenGl_FrameBuffer::GetInitVPSize),
             R"#(Return viewport width x height.)#" 
          )
        .def("GetInitVPSizeX",
             (int (OpenGl_FrameBuffer::*)() const) static_cast<int (OpenGl_FrameBuffer::*)() const>(&OpenGl_FrameBuffer::GetInitVPSizeX),
             R"#(Viewport width.)#" 
          )
        .def("GetInitVPSizeY",
             (int (OpenGl_FrameBuffer::*)() const) static_cast<int (OpenGl_FrameBuffer::*)() const>(&OpenGl_FrameBuffer::GetInitVPSizeY),
             R"#(Viewport height.)#" 
          )
        .def("IsValid",
             (bool (OpenGl_FrameBuffer::*)() const) static_cast<bool (OpenGl_FrameBuffer::*)() const>(&OpenGl_FrameBuffer::IsValid),
             R"#(Returns true if current object was initialized)#" 
          )
        .def("Init",
             (bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const NCollection_Vec2<int> & ,   const NCollection_DynamicArray<int> & ,   const handle<OpenGl_Texture> & ,   const int  ) ) static_cast<bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const NCollection_Vec2<int> & ,   const NCollection_DynamicArray<int> & ,   const handle<OpenGl_Texture> & ,   const int  ) >(&OpenGl_FrameBuffer::Init),
             R"#(Initialize FBO for rendering into single/multiple color buffer and depth textures.)#"  , py::arg("theGlCtx"),  py::arg("theSize"),  py::arg("theColorFormats"),  py::arg("theDepthStencilTexture"),  py::arg("theNbSamples")=static_cast< const int>(0)
          )
        .def("Init",
             (bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const NCollection_Vec2<int> & ,   const int ,   const int ,   const int  ) ) static_cast<bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const NCollection_Vec2<int> & ,   const int ,   const int ,   const int  ) >(&OpenGl_FrameBuffer::Init),
             R"#(Initialize FBO for rendering into textures.)#"  , py::arg("theGlCtx"),  py::arg("theSize"),  py::arg("theColorFormat"),  py::arg("theDepthFormat"),  py::arg("theNbSamples")=static_cast< const int>(0)
          )
        .def("Init",
             (bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const NCollection_Vec2<int> & ,   const NCollection_DynamicArray<int> & ,   const int ,   const int  ) ) static_cast<bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const NCollection_Vec2<int> & ,   const NCollection_DynamicArray<int> & ,   const int ,   const int  ) >(&OpenGl_FrameBuffer::Init),
             R"#(Initialize FBO for rendering into single/multiple color buffer and depth textures.)#"  , py::arg("theGlCtx"),  py::arg("theSize"),  py::arg("theColorFormats"),  py::arg("theDepthFormat"),  py::arg("theNbSamples")=static_cast< const int>(0)
          )
        .def("InitLazy",
             (bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const NCollection_Vec2<int> & ,   const int ,   const int ,   const int  ) ) static_cast<bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const NCollection_Vec2<int> & ,   const int ,   const int ,   const int  ) >(&OpenGl_FrameBuffer::InitLazy),
             R"#((Re-)initialize FBO with specified dimensions.)#"  , py::arg("theGlCtx"),  py::arg("theViewportSize"),  py::arg("theColorFormat"),  py::arg("theDepthFormat"),  py::arg("theNbSamples")=static_cast< const int>(0)
          )
        .def("InitLazy",
             (bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const NCollection_Vec2<int> & ,   const NCollection_DynamicArray<int> & ,   const int ,   const int  ) ) static_cast<bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const NCollection_Vec2<int> & ,   const NCollection_DynamicArray<int> & ,   const int ,   const int  ) >(&OpenGl_FrameBuffer::InitLazy),
             R"#((Re-)initialize FBO with specified dimensions.)#"  , py::arg("theGlCtx"),  py::arg("theViewportSize"),  py::arg("theColorFormats"),  py::arg("theDepthFormat"),  py::arg("theNbSamples")=static_cast< const int>(0)
          )
        .def("InitLazy",
             (bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const OpenGl_FrameBuffer & ,   const bool  ) ) static_cast<bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const OpenGl_FrameBuffer & ,   const bool  ) >(&OpenGl_FrameBuffer::InitLazy),
             R"#((Re-)initialize FBO with properties taken from another FBO.)#"  , py::arg("theGlCtx"),  py::arg("theFbo"),  py::arg("theToKeepMsaa")=static_cast< const bool>(true)
          )
        .def("InitRenderBuffer",
             (bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const NCollection_Vec2<int> & ,   const NCollection_DynamicArray<int> & ,   const int ,   const int  ) ) static_cast<bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const NCollection_Vec2<int> & ,   const NCollection_DynamicArray<int> & ,   const int ,   const int  ) >(&OpenGl_FrameBuffer::InitRenderBuffer),
             R"#((Re-)initialize FBO with specified dimensions. The Render Buffer Objects will be used for Color, Depth and Stencil attachments (as opposite to textures).)#"  , py::arg("theGlCtx"),  py::arg("theSize"),  py::arg("theColorFormats"),  py::arg("theDepthFormat"),  py::arg("theNbSamples")=static_cast< const int>(0)
          )
        .def("InitWithRB",
             (bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const NCollection_Vec2<int> & ,   const int ,   const int ,   const unsigned int  ) ) static_cast<bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const NCollection_Vec2<int> & ,   const int ,   const int ,   const unsigned int  ) >(&OpenGl_FrameBuffer::InitWithRB),
             R"#((Re-)initialize FBO with specified dimensions. The Render Buffer Objects will be used for Color, Depth and Stencil attachments (as opposite to textures).)#"  , py::arg("theGlCtx"),  py::arg("theSize"),  py::arg("theColorFormat"),  py::arg("theDepthFormat"),  py::arg("theColorRBufferFromWindow")
          )
        .def("InitWrapper",
             (bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> &  ) ) static_cast<bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> &  ) >(&OpenGl_FrameBuffer::InitWrapper),
             R"#(Initialize class from currently bound FBO. Retrieved OpenGL objects will not be destroyed on Release.)#"  , py::arg("theGlCtx")
          )
        .def("InitWrapper",
             (bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const NCollection_Sequence<handle<OpenGl_Texture>> & ,   const handle<OpenGl_Texture> &  ) ) static_cast<bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const NCollection_Sequence<handle<OpenGl_Texture>> & ,   const handle<OpenGl_Texture> &  ) >(&OpenGl_FrameBuffer::InitWrapper),
             R"#(Wrap existing color textures.)#"  , py::arg("theGlContext"),  py::arg("theColorTextures"),  py::arg("theDepthTexture")=static_cast< const handle<OpenGl_Texture> &>(occ :: handle < OpenGl_Texture > ( ))
          )
        .def("SetupViewport",
             (void (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> &  ) ) static_cast<void (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> &  ) >(&OpenGl_FrameBuffer::SetupViewport),
             R"#(Setup viewport to render into FBO)#"  , py::arg("theGlCtx")
          )
        .def("ChangeViewport",
             (void (OpenGl_FrameBuffer::*)(  const int ,   const int  ) ) static_cast<void (OpenGl_FrameBuffer::*)(  const int ,   const int  ) >(&OpenGl_FrameBuffer::ChangeViewport),
             R"#(Override viewport settings)#"  , py::arg("theVPSizeX"),  py::arg("theVPSizeY")
          )
        .def("BindBuffer",
             (void (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> &  ) ) static_cast<void (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> &  ) >(&OpenGl_FrameBuffer::BindBuffer),
             R"#(Bind frame buffer for drawing and reading (to render into the texture).)#"  , py::arg("theGlCtx")
          )
        .def("BindDrawBuffer",
             (void (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> &  ) ) static_cast<void (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> &  ) >(&OpenGl_FrameBuffer::BindDrawBuffer),
             R"#(Bind frame buffer for drawing GL_DRAW_FRAMEBUFFER (to render into the texture).)#"  , py::arg("theGlCtx")
          )
        .def("BindReadBuffer",
             (void (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> &  ) ) static_cast<void (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> &  ) >(&OpenGl_FrameBuffer::BindReadBuffer),
             R"#(Bind frame buffer for reading GL_READ_FRAMEBUFFER)#"  , py::arg("theGlCtx")
          )
        .def("UnbindBuffer",
             (void (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> &  ) ) static_cast<void (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> &  ) >(&OpenGl_FrameBuffer::UnbindBuffer),
             R"#(Unbind frame buffer.)#"  , py::arg("theGlCtx")
          )
        .def("ColorTexture",
             ( const handle<OpenGl_Texture> & (OpenGl_FrameBuffer::*)(  const int  ) const) static_cast< const handle<OpenGl_Texture> & (OpenGl_FrameBuffer::*)(  const int  ) const>(&OpenGl_FrameBuffer::ColorTexture),
             R"#(Returns the color texture for the given color buffer index.)#"  , py::arg("theColorBufferIndex")=static_cast< const int>(0)
          )
        .def("IsColorRenderBuffer",
             (bool (OpenGl_FrameBuffer::*)() const) static_cast<bool (OpenGl_FrameBuffer::*)() const>(&OpenGl_FrameBuffer::IsColorRenderBuffer),
             R"#(Returns TRUE if color Render Buffer is defined.)#" 
          )
        .def("ColorRenderBuffer",
             (unsigned int (OpenGl_FrameBuffer::*)() const) static_cast<unsigned int (OpenGl_FrameBuffer::*)() const>(&OpenGl_FrameBuffer::ColorRenderBuffer),
             R"#(Returns the color Render Buffer.)#" 
          )
        .def("IsDepthStencilRenderBuffer",
             (bool (OpenGl_FrameBuffer::*)() const) static_cast<bool (OpenGl_FrameBuffer::*)() const>(&OpenGl_FrameBuffer::IsDepthStencilRenderBuffer),
             R"#(Returns TRUE if depth Render Buffer is defined.)#" 
          )
        .def("DepthStencilRenderBuffer",
             (unsigned int (OpenGl_FrameBuffer::*)() const) static_cast<unsigned int (OpenGl_FrameBuffer::*)() const>(&OpenGl_FrameBuffer::DepthStencilRenderBuffer),
             R"#(Returns the depth Render Buffer.)#" 
          )
        .def("EstimatedDataSize",
             (size_t (OpenGl_FrameBuffer::*)() const) static_cast<size_t (OpenGl_FrameBuffer::*)() const>(&OpenGl_FrameBuffer::EstimatedDataSize),
             R"#(Returns estimated GPU memory usage for holding data without considering overheads and allocation alignment rules.)#" 
          )
        .def("initRenderBuffer",
             (bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const NCollection_Vec2<int> & ,   const NCollection_DynamicArray<int> & ,   const int ,   const int ,   const unsigned int  ) ) static_cast<bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const NCollection_Vec2<int> & ,   const NCollection_DynamicArray<int> & ,   const int ,   const int ,   const unsigned int  ) >(&OpenGl_FrameBuffer::initRenderBuffer),
             R"#((Re-)initialize FBO with specified dimensions. The Render Buffer Objects will be used for Color, Depth and Stencil attachments (as opposite to textures).)#"  , py::arg("theGlCtx"),  py::arg("theSize"),  py::arg("theColorFormats"),  py::arg("theDepthFormat"),  py::arg("theNbSamples"),  py::arg("theColorRBufferFromWindow")
          )
        .def("Init",
             (bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,   const NCollection_DynamicArray<int> & ,   const handle<OpenGl_Texture> & ,   const int  ) ) static_cast<bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,   const NCollection_DynamicArray<int> & ,   const handle<OpenGl_Texture> & ,   const int  ) >(&OpenGl_FrameBuffer::Init),
             R"#(Initialize FBO for rendering into single/multiple color buffer and depth textures.)#"  , py::arg("theGlCtx"),  py::arg("theSizeX"),  py::arg("theSizeY"),  py::arg("theColorFormats"),  py::arg("theDepthStencilTexture"),  py::arg("theNbSamples")=static_cast< const int>(0)
          )
        .def("Init",
             (bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,   const int ,   const int ,   const int  ) ) static_cast<bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,   const int ,   const int ,   const int  ) >(&OpenGl_FrameBuffer::Init),
             R"#(Initialize FBO for rendering into textures.)#"  , py::arg("theGlCtx"),  py::arg("theSizeX"),  py::arg("theSizeY"),  py::arg("theColorFormat"),  py::arg("theDepthFormat"),  py::arg("theNbSamples")=static_cast< const int>(0)
          )
        .def("Init",
             (bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,   const NCollection_DynamicArray<int> & ,   const int ,   const int  ) ) static_cast<bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,   const NCollection_DynamicArray<int> & ,   const int ,   const int  ) >(&OpenGl_FrameBuffer::Init),
             R"#(Initialize FBO for rendering into single/multiple color buffer and depth textures.)#"  , py::arg("theGlCtx"),  py::arg("theSizeX"),  py::arg("theSizeY"),  py::arg("theColorFormats"),  py::arg("theDepthFormat"),  py::arg("theNbSamples")=static_cast< const int>(0)
          )
        .def("InitLazy",
             (bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,   const int ,   const int ,   const int  ) ) static_cast<bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,   const int ,   const int ,   const int  ) >(&OpenGl_FrameBuffer::InitLazy),
             R"#((Re-)initialize FBO with specified dimensions.)#"  , py::arg("theGlCtx"),  py::arg("theViewportSizeX"),  py::arg("theViewportSizeY"),  py::arg("theColorFormat"),  py::arg("theDepthFormat"),  py::arg("theNbSamples")=static_cast< const int>(0)
          )
        .def("InitLazy",
             (bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,   const NCollection_DynamicArray<int> & ,   const int ,   const int  ) ) static_cast<bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,   const NCollection_DynamicArray<int> & ,   const int ,   const int  ) >(&OpenGl_FrameBuffer::InitLazy),
             R"#((Re-)initialize FBO with specified dimensions.)#"  , py::arg("theGlCtx"),  py::arg("theViewportSizeX"),  py::arg("theViewportSizeY"),  py::arg("theColorFormats"),  py::arg("theDepthFormat"),  py::arg("theNbSamples")=static_cast< const int>(0)
          )
        .def("InitWithRB",
             (bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,   const int ,   const int ,   const unsigned int  ) ) static_cast<bool (OpenGl_FrameBuffer::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,   const int ,   const int ,   const unsigned int  ) >(&OpenGl_FrameBuffer::InitWithRB),
             R"#((Re-)initialize FBO with specified dimensions. The Render Buffer Objects will be used for Color, Depth and Stencil attachments (as opposite to textures).)#"  , py::arg("theGlCtx"),  py::arg("theSizeX"),  py::arg("theSizeY"),  py::arg("theColorFormat"),  py::arg("theDepthFormat"),  py::arg("theColorRBufferFromWindow")=static_cast< const unsigned int>(0)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_FrameBuffer::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_FrameBuffer::get_type_descriptor),
                    R"#()#" 
          )
        .def_static("BufferDump_s",
                    (bool (*)(  const handle<OpenGl_Context> & ,   const handle<OpenGl_FrameBuffer> & ,  Image_PixMap & ,  Graphic3d_BufferType  ) ) static_cast<bool (*)(  const handle<OpenGl_Context> & ,   const handle<OpenGl_FrameBuffer> & ,  Image_PixMap & ,  Graphic3d_BufferType  ) >(&OpenGl_FrameBuffer::BufferDump),
                    R"#(Dump content into image.)#"  , py::arg("theGlCtx"),  py::arg("theFbo"),  py::arg("theImage"),  py::arg("theBufferType")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_FrameBuffer::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_FrameBuffer::*)() const>(&OpenGl_FrameBuffer::DynamicType),
             R"#()#"
             
         )
       .def("DepthStencilTexture",
             ( const handle<OpenGl_Texture> & (OpenGl_FrameBuffer::*)() const) static_cast< const handle<OpenGl_Texture> & (OpenGl_FrameBuffer::*)() const>(&OpenGl_FrameBuffer::DepthStencilTexture),
             R"#(Returns the depth-stencil texture.)#"
             
         )
;

    // Class OpenGl_IndexBuffer from ./opencascade/OpenGl_IndexBuffer.hxx
    klass = m.attr("OpenGl_IndexBuffer");


    // nested enums

    static_cast<py::class_<OpenGl_IndexBuffer ,opencascade::handle<OpenGl_IndexBuffer>  , OpenGl_Buffer >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("GetTarget",
             (unsigned int (OpenGl_IndexBuffer::*)() const) static_cast<unsigned int (OpenGl_IndexBuffer::*)() const>(&OpenGl_IndexBuffer::GetTarget),
             R"#(Return buffer object target (GL_ELEMENT_ARRAY_BUFFER).)#" 
          )
        .def("DumpJson",
             (void (OpenGl_IndexBuffer::*)( Standard_OStream & ,  int  ) const) static_cast<void (OpenGl_IndexBuffer::*)( Standard_OStream & ,  int  ) const>(&OpenGl_IndexBuffer::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_IndexBuffer::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_IndexBuffer::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_IndexBuffer::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_IndexBuffer::*)() const>(&OpenGl_IndexBuffer::DynamicType),
             R"#()#"
             
         )
;

    // Class OpenGl_PBREnvironment from ./opencascade/OpenGl_PBREnvironment.hxx
    klass = m.attr("OpenGl_PBREnvironment");


    // nested enums

    static_cast<py::class_<OpenGl_PBREnvironment ,opencascade::handle<OpenGl_PBREnvironment>  , OpenGl_NamedResource >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("Bind",
             (void (OpenGl_PBREnvironment::*)(  const handle<OpenGl_Context> &  ) ) static_cast<void (OpenGl_PBREnvironment::*)(  const handle<OpenGl_Context> &  ) >(&OpenGl_PBREnvironment::Bind),
             R"#(Binds diffuse and specular IBL maps to the corresponding texture units.)#"  , py::arg("theCtx")
          )
        .def("Unbind",
             (void (OpenGl_PBREnvironment::*)(  const handle<OpenGl_Context> &  ) ) static_cast<void (OpenGl_PBREnvironment::*)(  const handle<OpenGl_Context> &  ) >(&OpenGl_PBREnvironment::Unbind),
             R"#(Unbinds diffuse and specular IBL maps.)#"  , py::arg("theCtx")
          )
        .def("Clear",
             (void (OpenGl_PBREnvironment::*)(  const handle<OpenGl_Context> & ,   const NCollection_Vec3<float> &  ) ) static_cast<void (OpenGl_PBREnvironment::*)(  const handle<OpenGl_Context> & ,   const NCollection_Vec3<float> &  ) >(&OpenGl_PBREnvironment::Clear),
             R"#(Fills all mipmaps of specular IBL map and diffuse IBL map with one color. So that environment illumination will be constant.)#"  , py::arg("theCtx"),  py::arg("theColor")=static_cast< const NCollection_Vec3<float> &>(NCollection_Vec3 < float > ( 1.f ))
          )
        .def("Bake",
             (void (OpenGl_PBREnvironment::*)(  const handle<OpenGl_Context> & ,   const handle<OpenGl_Texture> & ,  bool ,  bool ,  size_t ,  size_t ,  float  ) ) static_cast<void (OpenGl_PBREnvironment::*)(  const handle<OpenGl_Context> & ,   const handle<OpenGl_Texture> & ,  bool ,  bool ,  size_t ,  size_t ,  float  ) >(&OpenGl_PBREnvironment::Bake),
             R"#(Generates specular and diffuse (irradiance) IBL maps.)#"  , py::arg("theCtx"),  py::arg("theEnvMap"),  py::arg("theZIsInverted")=static_cast<bool>(false),  py::arg("theIsTopDown")=static_cast<bool>(true),  py::arg("theDiffMapNbSamples")=static_cast<size_t>(1024),  py::arg("theSpecMapNbSamples")=static_cast<size_t>(256),  py::arg("theProbability")=static_cast<float>(0.99f)
          )
        .def("SpecMapLevelsNumber",
             (unsigned int (OpenGl_PBREnvironment::*)() const) static_cast<unsigned int (OpenGl_PBREnvironment::*)() const>(&OpenGl_PBREnvironment::SpecMapLevelsNumber),
             R"#(Returns number of mipmap levels used in specular IBL map. It can be different from value passed to creation method.)#" 
          )
        .def("Pow2Size",
             (unsigned int (OpenGl_PBREnvironment::*)() const) static_cast<unsigned int (OpenGl_PBREnvironment::*)() const>(&OpenGl_PBREnvironment::Pow2Size),
             R"#(Returns size of IBL maps sides as power of 2. So that the real size can be calculated as 2^Pow2Size())#" 
          )
        .def("SizesAreDifferent",
             (bool (OpenGl_PBREnvironment::*)( unsigned int ,  unsigned int  ) const) static_cast<bool (OpenGl_PBREnvironment::*)( unsigned int ,  unsigned int  ) const>(&OpenGl_PBREnvironment::SizesAreDifferent),
             R"#(Checks whether the given sizes affects to the current ones. It can be imagined as creation of new PBR environment. If creation method with this values returns the PBR environment having real sizes which are equals to current ones then this method will return false. It is handful when sizes are required to be changed. If this method returns false there is no reason to recreate PBR environment in order to change sizes.)#"  , py::arg("thePow2Size"),  py::arg("theSpecMapLevelsNumber")
          )
        .def("IsNeededToBeBound",
             (bool (OpenGl_PBREnvironment::*)() const) static_cast<bool (OpenGl_PBREnvironment::*)() const>(&OpenGl_PBREnvironment::IsNeededToBeBound),
             R"#(Indicates whether IBL map's textures have to be bound or it is not obligate.)#" 
          )
        .def("Release",
             (void (OpenGl_PBREnvironment::*)( OpenGl_Context *  ) ) static_cast<void (OpenGl_PBREnvironment::*)( OpenGl_Context *  ) >(&OpenGl_PBREnvironment::Release),
             R"#(Releases all OpenGL resources. It must be called before destruction.)#"  , py::arg("theCtx")
          )
        .def("EstimatedDataSize",
             (size_t (OpenGl_PBREnvironment::*)() const) static_cast<size_t (OpenGl_PBREnvironment::*)() const>(&OpenGl_PBREnvironment::EstimatedDataSize),
             R"#(Returns estimated GPU memory usage for holding data without considering overheads and allocation alignment rules.)#" 
          )
        .def("IsComplete",
             (bool (OpenGl_PBREnvironment::*)() const) static_cast<bool (OpenGl_PBREnvironment::*)() const>(&OpenGl_PBREnvironment::IsComplete),
             R"#(Checks completeness of PBR environment. Creation method returns only completed objects or null handles otherwise.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_PBREnvironment::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_PBREnvironment::get_type_descriptor),
                    R"#()#" 
          )
        .def_static("Create_s",
                    (handle<OpenGl_PBREnvironment> (*)(  const handle<OpenGl_Context> & ,  unsigned int ,  unsigned int ,   const TCollection_AsciiString &  ) ) static_cast<handle<OpenGl_PBREnvironment> (*)(  const handle<OpenGl_Context> & ,  unsigned int ,  unsigned int ,   const TCollection_AsciiString &  ) >(&OpenGl_PBREnvironment::Create),
                    R"#(Creates and initializes new PBR environment. It is the only way to create OpenGl_PBREnvironment.)#"  , py::arg("theCtx"),  py::arg("thePow2Size")=static_cast<unsigned int>(9),  py::arg("theSpecMapLevelsNum")=static_cast<unsigned int>(6),  py::arg("theId")=static_cast< const TCollection_AsciiString &>("PBREnvironment")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_PBREnvironment::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_PBREnvironment::*)() const>(&OpenGl_PBREnvironment::DynamicType),
             R"#()#"
             
         )
;

    // Class OpenGl_ShaderProgram from ./opencascade/OpenGl_ShaderProgram.hxx
    klass = m.attr("OpenGl_ShaderProgram");


    // nested enums

    static_cast<py::class_<OpenGl_ShaderProgram ,opencascade::handle<OpenGl_ShaderProgram>  , OpenGl_NamedResource >>(klass)
    // constructors
        .def(py::init<  const handle<Graphic3d_ShaderProgram> &, const TCollection_AsciiString & >()  , py::arg("theProxy")=static_cast< const handle<Graphic3d_ShaderProgram> &>(nullptr),  py::arg("theId")=static_cast< const TCollection_AsciiString &>("") )
    // custom constructors
    // methods
        .def("Create",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> &  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> &  ) >(&OpenGl_ShaderProgram::Create),
             R"#(Creates new empty shader program of specified type.)#"  , py::arg("theCtx")
          )
        .def("Release",
             (void (OpenGl_ShaderProgram::*)( OpenGl_Context *  ) ) static_cast<void (OpenGl_ShaderProgram::*)( OpenGl_Context *  ) >(&OpenGl_ShaderProgram::Release),
             R"#(Destroys shader program.)#"  , py::arg("theCtx")
          )
        .def("EstimatedDataSize",
             (size_t (OpenGl_ShaderProgram::*)() const) static_cast<size_t (OpenGl_ShaderProgram::*)() const>(&OpenGl_ShaderProgram::EstimatedDataSize),
             R"#(Returns estimated GPU memory usage - cannot be easily estimated.)#" 
          )
        .def("AttachShader",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,   const handle<OpenGl_ShaderObject> &  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,   const handle<OpenGl_ShaderObject> &  ) >(&OpenGl_ShaderProgram::AttachShader),
             R"#(Attaches shader object to the program object.)#"  , py::arg("theCtx"),  py::arg("theShader")
          )
        .def("DetachShader",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,   const handle<OpenGl_ShaderObject> &  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,   const handle<OpenGl_ShaderObject> &  ) >(&OpenGl_ShaderProgram::DetachShader),
             R"#(Detaches shader object to the program object.)#"  , py::arg("theCtx"),  py::arg("theShader")
          )
        .def("Initialize",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,   const NCollection_Sequence<handle<Graphic3d_ShaderObject>> &  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,   const NCollection_Sequence<handle<Graphic3d_ShaderObject>> &  ) >(&OpenGl_ShaderProgram::Initialize),
             R"#(Initializes program object with the list of shader objects.)#"  , py::arg("theCtx"),  py::arg("theShaders")
          )
        .def("Link",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  bool  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  bool  ) >(&OpenGl_ShaderProgram::Link),
             R"#(Links the program object.)#"  , py::arg("theCtx"),  py::arg("theIsVerbose")=static_cast<bool>(true)
          )
        .def("FetchInfoLog",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  TCollection_AsciiString &  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  TCollection_AsciiString &  ) >(&OpenGl_ShaderProgram::FetchInfoLog),
             R"#(Fetches information log of the last link operation.)#"  , py::arg("theCtx"),  py::arg("theLog")
          )
        .def("ApplyVariables",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> &  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> &  ) >(&OpenGl_ShaderProgram::ApplyVariables),
             R"#(Fetches uniform variables from proxy shader program.)#"  , py::arg("theCtx")
          )
        .def("IsValid",
             (bool (OpenGl_ShaderProgram::*)() const) static_cast<bool (OpenGl_ShaderProgram::*)() const>(&OpenGl_ShaderProgram::IsValid),
             R"#(Returns true if current object was initialized)#" 
          )
        .def("ProgramId",
             (GLuint (OpenGl_ShaderProgram::*)() const) static_cast<GLuint (OpenGl_ShaderProgram::*)() const>(&OpenGl_ShaderProgram::ProgramId),
             R"#(Returns program ID)#" 
          )
        .def("HasTessellationStage",
             (bool (OpenGl_ShaderProgram::*)() const) static_cast<bool (OpenGl_ShaderProgram::*)() const>(&OpenGl_ShaderProgram::HasTessellationStage),
             R"#(Return TRUE if program defines tessellation stage.)#" 
          )
        .def("NbLightsMax",
             (int (OpenGl_ShaderProgram::*)() const) static_cast<int (OpenGl_ShaderProgram::*)() const>(&OpenGl_ShaderProgram::NbLightsMax),
             R"#(Return the length of array of light sources (THE_MAX_LIGHTS), to be used for initialization occLightSources (OpenGl_OCC_LIGHT_SOURCE_PARAMS).)#" 
          )
        .def("NbShadowMaps",
             (int (OpenGl_ShaderProgram::*)() const) static_cast<int (OpenGl_ShaderProgram::*)() const>(&OpenGl_ShaderProgram::NbShadowMaps),
             R"#(Return the length of array of shadow maps (THE_NB_SHADOWMAPS); 0 by default.)#" 
          )
        .def("NbClipPlanesMax",
             (int (OpenGl_ShaderProgram::*)() const) static_cast<int (OpenGl_ShaderProgram::*)() const>(&OpenGl_ShaderProgram::NbClipPlanesMax),
             R"#(Return the length of array of clipping planes (THE_MAX_CLIP_PLANES), to be used for initialization occClipPlaneEquations (OpenGl_OCC_CLIP_PLANE_EQUATIONS) and occClipPlaneChains (OpenGl_OCC_CLIP_PLANE_CHAINS).)#" 
          )
        .def("NbFragmentOutputs",
             (int (OpenGl_ShaderProgram::*)() const) static_cast<int (OpenGl_ShaderProgram::*)() const>(&OpenGl_ShaderProgram::NbFragmentOutputs),
             R"#(Return the length of array of Fragment Shader outputs (THE_NB_FRAG_OUTPUTS), to be used for initialization occFragColorArray/occFragColorN.)#" 
          )
        .def("HasAlphaTest",
             (bool (OpenGl_ShaderProgram::*)() const) static_cast<bool (OpenGl_ShaderProgram::*)() const>(&OpenGl_ShaderProgram::HasAlphaTest),
             R"#(Return true if Fragment Shader should perform alpha test; FALSE by default.)#" 
          )
        .def("OitOutput",
             (Graphic3d_RenderTransparentMethod (OpenGl_ShaderProgram::*)() const) static_cast<Graphic3d_RenderTransparentMethod (OpenGl_ShaderProgram::*)() const>(&OpenGl_ShaderProgram::OitOutput),
             R"#(Return if Fragment Shader color should output the OIT values; OFF by default.)#" 
          )
        .def("TextureSetBits",
             (int (OpenGl_ShaderProgram::*)() const) static_cast<int (OpenGl_ShaderProgram::*)() const>(&OpenGl_ShaderProgram::TextureSetBits),
             R"#(Return texture units declared within the program,)#" 
          )
        .def("GetUniformLocation",
             (OpenGl_ShaderUniformLocation (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,   const GLchar *  ) const) static_cast<OpenGl_ShaderUniformLocation (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,   const GLchar *  ) const>(&OpenGl_ShaderProgram::GetUniformLocation),
             R"#(Returns location of the specific uniform variable.)#"  , py::arg("theCtx"),  py::arg("theName")
          )
        .def("GetAttributeLocation",
             (GLint (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,   const GLchar *  ) const) static_cast<GLint (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,   const GLchar *  ) const>(&OpenGl_ShaderProgram::GetAttributeLocation),
             R"#(Returns index of the generic vertex attribute by variable name.)#"  , py::arg("theCtx"),  py::arg("theName")
          )
        .def("GetStateLocation",
             ( const OpenGl_ShaderUniformLocation & (OpenGl_ShaderProgram::*)( OpenGl_StateVariable  ) const) static_cast< const OpenGl_ShaderUniformLocation & (OpenGl_ShaderProgram::*)( OpenGl_StateVariable  ) const>(&OpenGl_ShaderProgram::GetStateLocation),
             R"#(Returns location of the OCCT state uniform variable.)#"  , py::arg("theVariable")
          )
        .def("GetUniform",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  NCollection_Vec4<int> &  ) const) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  NCollection_Vec4<int> &  ) const>(&OpenGl_ShaderProgram::GetUniform),
             R"#(Returns the value of the integer uniform variable. Wrapper for glGetUniformiv())#"  , py::arg("theCtx"),  py::arg("theLocation"),  py::arg("theValue")
          )
        .def("GetUniform",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  NCollection_Vec4<float> &  ) const) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  NCollection_Vec4<float> &  ) const>(&OpenGl_ShaderProgram::GetUniform),
             R"#(Returns the value of the float uniform variable. Wrapper for glGetUniformfv())#"  , py::arg("theCtx"),  py::arg("theLocation"),  py::arg("theValue")
          )
        .def("GetAttribute",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  NCollection_Vec4<int> &  ) const) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  NCollection_Vec4<int> &  ) const>(&OpenGl_ShaderProgram::GetAttribute),
             R"#(Returns the integer vertex attribute. Wrapper for glGetVertexAttribiv())#"  , py::arg("theCtx"),  py::arg("theIndex"),  py::arg("theValue")
          )
        .def("GetAttribute",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  NCollection_Vec4<float> &  ) const) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  NCollection_Vec4<float> &  ) const>(&OpenGl_ShaderProgram::GetAttribute),
             R"#(Returns the float vertex attribute. Wrapper for glGetVertexAttribfv())#"  , py::arg("theCtx"),  py::arg("theIndex"),  py::arg("theValue")
          )
        .def("SetAttributeName",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,   const GLchar *  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,   const GLchar *  ) >(&OpenGl_ShaderProgram::SetAttributeName),
             R"#(Wrapper for glBindAttribLocation())#"  , py::arg("theCtx"),  py::arg("theIndex"),  py::arg("theName")
          )
        .def("SetAttribute",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  GLfloat  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  GLfloat  ) >(&OpenGl_ShaderProgram::SetAttribute),
             R"#(Wrapper for glVertexAttrib1f())#"  , py::arg("theCtx"),  py::arg("theIndex"),  py::arg("theValue")
          )
        .def("SetAttribute",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,   const NCollection_Vec2<float> &  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,   const NCollection_Vec2<float> &  ) >(&OpenGl_ShaderProgram::SetAttribute),
             R"#(Wrapper for glVertexAttrib2fv())#"  , py::arg("theCtx"),  py::arg("theIndex"),  py::arg("theValue")
          )
        .def("SetAttribute",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,   const NCollection_Vec3<float> &  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,   const NCollection_Vec3<float> &  ) >(&OpenGl_ShaderProgram::SetAttribute),
             R"#(Wrapper for glVertexAttrib3fv())#"  , py::arg("theCtx"),  py::arg("theIndex"),  py::arg("theValue")
          )
        .def("SetAttribute",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,   const NCollection_Vec4<float> &  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,   const NCollection_Vec4<float> &  ) >(&OpenGl_ShaderProgram::SetAttribute),
             R"#(Wrapper for glVertexAttrib4fv())#"  , py::arg("theCtx"),  py::arg("theIndex"),  py::arg("theValue")
          )
        .def("SetUniform",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  GLint  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  GLint  ) >(&OpenGl_ShaderProgram::SetUniform),
             R"#(Specifies the value of the integer uniform variable. Wrapper for glUniform1i())#"  , py::arg("theCtx"),  py::arg("theLocation"),  py::arg("theValue")
          )
        .def("SetUniform",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,   const NCollection_Vec2<int> &  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,   const NCollection_Vec2<int> &  ) >(&OpenGl_ShaderProgram::SetUniform),
             R"#(Specifies the value of the integer uniform 2D vector. Wrapper for glUniform2iv())#"  , py::arg("theCtx"),  py::arg("theLocation"),  py::arg("theValue")
          )
        .def("SetUniform",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,   const NCollection_Vec3<int> &  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,   const NCollection_Vec3<int> &  ) >(&OpenGl_ShaderProgram::SetUniform),
             R"#(Specifies the value of the integer uniform 3D vector. Wrapper for glUniform3iv())#"  , py::arg("theCtx"),  py::arg("theLocation"),  py::arg("theValue")
          )
        .def("SetUniform",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,   const NCollection_Vec4<int> &  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,   const NCollection_Vec4<int> &  ) >(&OpenGl_ShaderProgram::SetUniform),
             R"#(Specifies the value of the integer uniform 4D vector. Wrapper for glUniform4iv())#"  , py::arg("theCtx"),  py::arg("theLocation"),  py::arg("theValue")
          )
        .def("SetUniform",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,   const NCollection_Vec2<unsigned int> &  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,   const NCollection_Vec2<unsigned int> &  ) >(&OpenGl_ShaderProgram::SetUniform),
             R"#(Specifies the value of the unsigned integer uniform 2D vector (uvec2). Wrapper for glUniform2uiv())#"  , py::arg("theCtx"),  py::arg("theLocation"),  py::arg("theValue")
          )
        .def("SetUniform",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,   const GLchar * ,   const GLsizei ,   const NCollection_Vec2<unsigned int> *  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,   const GLchar * ,   const GLsizei ,   const NCollection_Vec2<unsigned int> *  ) >(&OpenGl_ShaderProgram::SetUniform),
             R"#(Specifies the value of the uvec2 uniform array Wrapper for glUniform2uiv())#"  , py::arg("theCtx"),  py::arg("theName"),  py::arg("theCount"),  py::arg("theValue")
          )
        .def("SetUniform",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,   const GLsizei ,   const NCollection_Vec2<unsigned int> *  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,   const GLsizei ,   const NCollection_Vec2<unsigned int> *  ) >(&OpenGl_ShaderProgram::SetUniform),
             R"#(Specifies the value of the uvec2 uniform array Wrapper for glUniform2uiv())#"  , py::arg("theCtx"),  py::arg("theLocation"),  py::arg("theCount"),  py::arg("theValue")
          )
        .def("SetUniform",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  GLfloat  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  GLfloat  ) >(&OpenGl_ShaderProgram::SetUniform),
             R"#(Specifies the value of the float uniform variable. Wrapper for glUniform1f())#"  , py::arg("theCtx"),  py::arg("theLocation"),  py::arg("theValue")
          )
        .def("SetUniform",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,   const NCollection_Vec2<float> &  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,   const NCollection_Vec2<float> &  ) >(&OpenGl_ShaderProgram::SetUniform),
             R"#(Specifies the value of the float uniform 2D vector. Wrapper for glUniform2fv())#"  , py::arg("theCtx"),  py::arg("theLocation"),  py::arg("theValue")
          )
        .def("SetUniform",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,   const NCollection_Vec3<float> &  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,   const NCollection_Vec3<float> &  ) >(&OpenGl_ShaderProgram::SetUniform),
             R"#(Specifies the value of the float uniform 3D vector. Wrapper for glUniform3fv())#"  , py::arg("theCtx"),  py::arg("theLocation"),  py::arg("theValue")
          )
        .def("SetUniform",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,   const NCollection_Vec4<float> &  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,   const NCollection_Vec4<float> &  ) >(&OpenGl_ShaderProgram::SetUniform),
             R"#(Specifies the value of the float uniform 4D vector. Wrapper for glUniform4fv())#"  , py::arg("theCtx"),  py::arg("theLocation"),  py::arg("theValue")
          )
        .def("SetUniform",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  GLuint ,   const NCollection_Mat3<float> *  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  GLuint ,   const NCollection_Mat3<float> *  ) >(&OpenGl_ShaderProgram::SetUniform),
             R"#(Specifies the value of the array of float uniform 3x3 matrices. Wrapper over glUniformMatrix3fv().)#"  , py::arg("theCtx"),  py::arg("theLocation"),  py::arg("theCount"),  py::arg("theData")
          )
        .def("SetUniform",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,   const GLchar * ,   const NCollection_Mat3<float> & ,  GLboolean  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,   const GLchar * ,   const NCollection_Mat3<float> & ,  GLboolean  ) >(&OpenGl_ShaderProgram::SetUniform),
             R"#(Specifies the value of the float uniform 3x3 matrix. Wrapper for glUniformMatrix3fv())#"  , py::arg("theCtx"),  py::arg("theName"),  py::arg("theValue"),  py::arg("theTranspose")=static_cast<GLboolean>(GL_FALSE)
          )
        .def("SetUniform",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,   const NCollection_Mat3<float> & ,  GLboolean  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,   const NCollection_Mat3<float> & ,  GLboolean  ) >(&OpenGl_ShaderProgram::SetUniform),
             R"#(Specifies the value of the float uniform 3x3 matrix. Wrapper for glUniformMatrix3fv())#"  , py::arg("theCtx"),  py::arg("theLocation"),  py::arg("theValue"),  py::arg("theTranspose")=static_cast<GLboolean>(GL_FALSE)
          )
        .def("SetUniform",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,   const GLchar * ,   const NCollection_Mat4<float> & ,  GLboolean  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,   const GLchar * ,   const NCollection_Mat4<float> & ,  GLboolean  ) >(&OpenGl_ShaderProgram::SetUniform),
             R"#(Specifies the value of the float uniform 4x4 matrix. Wrapper for glUniformMatrix4fv())#"  , py::arg("theCtx"),  py::arg("theName"),  py::arg("theValue"),  py::arg("theTranspose")=static_cast<GLboolean>(GL_FALSE)
          )
        .def("SetUniform",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,   const NCollection_Mat4<float> & ,  GLboolean  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,   const NCollection_Mat4<float> & ,  GLboolean  ) >(&OpenGl_ShaderProgram::SetUniform),
             R"#(Specifies the value of the float uniform 4x4 matrix. Wrapper for glUniformMatrix4fv())#"  , py::arg("theCtx"),  py::arg("theLocation"),  py::arg("theValue"),  py::arg("theTranspose")=static_cast<GLboolean>(GL_FALSE)
          )
        .def("SetUniform",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  GLuint ,   const NCollection_Mat4<float> *  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  GLuint ,   const NCollection_Mat4<float> *  ) >(&OpenGl_ShaderProgram::SetUniform),
             R"#(Specifies the value of the array of float uniform 4x4 matrices. Wrapper over glUniformMatrix4fv().)#"  , py::arg("theCtx"),  py::arg("theLocation"),  py::arg("theCount"),  py::arg("theData")
          )
        .def("SetUniform",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  GLuint ,   const float *  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  GLuint ,   const float *  ) >(&OpenGl_ShaderProgram::SetUniform),
             R"#(Specifies the value of the float uniform array Wrapper over glUniform1fv())#"  , py::arg("theCtx"),  py::arg("theLocation"),  py::arg("theCount"),  py::arg("theData")
          )
        .def("SetUniform",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  GLuint ,   const NCollection_Vec2<float> *  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  GLuint ,   const NCollection_Vec2<float> *  ) >(&OpenGl_ShaderProgram::SetUniform),
             R"#(Specifies the value of the float2 uniform array Wrapper over glUniform2fv())#"  , py::arg("theCtx"),  py::arg("theLocation"),  py::arg("theCount"),  py::arg("theData")
          )
        .def("SetUniform",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  GLuint ,   const NCollection_Vec3<float> *  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  GLuint ,   const NCollection_Vec3<float> *  ) >(&OpenGl_ShaderProgram::SetUniform),
             R"#(Specifies the value of the float3 uniform array Wrapper over glUniform3fv())#"  , py::arg("theCtx"),  py::arg("theLocation"),  py::arg("theCount"),  py::arg("theData")
          )
        .def("SetUniform",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  GLuint ,   const NCollection_Vec4<float> *  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  GLuint ,   const NCollection_Vec4<float> *  ) >(&OpenGl_ShaderProgram::SetUniform),
             R"#(Specifies the value of the float4 uniform array Wrapper over glUniform4fv())#"  , py::arg("theCtx"),  py::arg("theLocation"),  py::arg("theCount"),  py::arg("theData")
          )
        .def("SetUniform",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  GLuint ,   const int *  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  GLuint ,   const int *  ) >(&OpenGl_ShaderProgram::SetUniform),
             R"#(Specifies the value of the integer uniform array Wrapper over glUniform1iv())#"  , py::arg("theCtx"),  py::arg("theLocation"),  py::arg("theCount"),  py::arg("theData")
          )
        .def("SetUniform",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  GLuint ,   const NCollection_Vec2<int> *  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  GLuint ,   const NCollection_Vec2<int> *  ) >(&OpenGl_ShaderProgram::SetUniform),
             R"#(Specifies the value of the int2 uniform array Wrapper over glUniform2iv())#"  , py::arg("theCtx"),  py::arg("theLocation"),  py::arg("theCount"),  py::arg("theData")
          )
        .def("SetUniform",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  GLuint ,   const NCollection_Vec3<int> *  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  GLuint ,   const NCollection_Vec3<int> *  ) >(&OpenGl_ShaderProgram::SetUniform),
             R"#(Specifies the value of the int3 uniform array Wrapper over glUniform3iv())#"  , py::arg("theCtx"),  py::arg("theLocation"),  py::arg("theCount"),  py::arg("theData")
          )
        .def("SetUniform",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  GLuint ,   const NCollection_Vec4<int> *  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,  GLuint ,   const NCollection_Vec4<int> *  ) >(&OpenGl_ShaderProgram::SetUniform),
             R"#(Specifies the value of the int4 uniform array Wrapper over glUniform4iv())#"  , py::arg("theCtx"),  py::arg("theLocation"),  py::arg("theCount"),  py::arg("theData")
          )
        .def("SetSampler",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,   const GLchar * ,   const Graphic3d_TextureUnit  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,   const GLchar * ,   const Graphic3d_TextureUnit  ) >(&OpenGl_ShaderProgram::SetSampler),
             R"#(Specifies the value of the sampler uniform variable.)#"  , py::arg("theCtx"),  py::arg("theName"),  py::arg("theTextureUnit")
          )
        .def("SetSampler",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,   const Graphic3d_TextureUnit  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,  GLint ,   const Graphic3d_TextureUnit  ) >(&OpenGl_ShaderProgram::SetSampler),
             R"#(Specifies the value of the sampler uniform variable.)#"  , py::arg("theCtx"),  py::arg("theLocation"),  py::arg("theTextureUnit")
          )
        .def("UpdateDebugDump",
             (bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,   const TCollection_AsciiString & ,  bool ,  bool  ) ) static_cast<bool (OpenGl_ShaderProgram::*)(  const handle<OpenGl_Context> & ,   const TCollection_AsciiString & ,  bool ,  bool  ) >(&OpenGl_ShaderProgram::UpdateDebugDump),
             R"#(Update the shader program from external files (per shader stage) in the following way: 1) If external file does not exist, then it will be created (current source code will be dumped, no recompilation) and FALSE will be returned. 2) If external file exists and it has the same timestamp as myDumpDate, nothing will be done and FALSE will be returned. 3) If external file exists and it has newer timestamp than myDumpDate, shader will be recompiled and relinked and TRUE will be returned.)#"  , py::arg("theCtx"),  py::arg("theFolder")=static_cast< const TCollection_AsciiString &>(""),  py::arg("theToBeautify")=static_cast<bool>(false),  py::arg("theToReset")=static_cast<bool>(false)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_ShaderProgram::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_ShaderProgram::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_ShaderProgram::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_ShaderProgram::*)() const>(&OpenGl_ShaderProgram::DynamicType),
             R"#()#"
             
         )
       .def("Proxy",
             ( const handle<Graphic3d_ShaderProgram> & (OpenGl_ShaderProgram::*)() const) static_cast< const handle<Graphic3d_ShaderProgram> & (OpenGl_ShaderProgram::*)() const>(&OpenGl_ShaderProgram::Proxy),
             R"#(Returns proxy shader program.)#"
             
         )
;

    // Class OpenGl_ShadowMap from ./opencascade/OpenGl_ShadowMap.hxx
    klass = m.attr("OpenGl_ShadowMap");


    // nested enums

    static_cast<py::class_<OpenGl_ShadowMap ,opencascade::handle<OpenGl_ShadowMap>  , OpenGl_NamedResource >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("Release",
             (void (OpenGl_ShadowMap::*)( OpenGl_Context *  ) ) static_cast<void (OpenGl_ShadowMap::*)( OpenGl_Context *  ) >(&OpenGl_ShadowMap::Release),
             R"#(Releases all OpenGL resources.)#"  , py::arg("theCtx")
          )
        .def("EstimatedDataSize",
             (size_t (OpenGl_ShadowMap::*)() const) static_cast<size_t (OpenGl_ShadowMap::*)() const>(&OpenGl_ShadowMap::EstimatedDataSize),
             R"#(Returns estimated GPU memory usage for holding data without considering overheads and allocation alignment rules.)#" 
          )
        .def("IsValid",
             (bool (OpenGl_ShadowMap::*)() const) static_cast<bool (OpenGl_ShadowMap::*)() const>(&OpenGl_ShadowMap::IsValid),
             R"#(Return TRUE if defined.)#" 
          )
        .def("SetLightSource",
             (void (OpenGl_ShadowMap::*)(  const handle<Graphic3d_CLight> &  ) ) static_cast<void (OpenGl_ShadowMap::*)(  const handle<Graphic3d_CLight> &  ) >(&OpenGl_ShadowMap::SetLightSource),
             R"#(Set light source casting the shadow.)#"  , py::arg("theLight")
          )
        .def("SetLightSourceMatrix",
             (void (OpenGl_ShadowMap::*)(  const NCollection_Mat4<float> &  ) ) static_cast<void (OpenGl_ShadowMap::*)(  const NCollection_Mat4<float> &  ) >(&OpenGl_ShadowMap::SetLightSourceMatrix),
             R"#(Set light source mapping matrix.)#"  , py::arg("theMat")
          )
        .def("ShadowMapBias",
             (float (OpenGl_ShadowMap::*)() const) static_cast<float (OpenGl_ShadowMap::*)() const>(&OpenGl_ShadowMap::ShadowMapBias),
             R"#(Returns shadowmap bias.)#" 
          )
        .def("SetShadowMapBias",
             (void (OpenGl_ShadowMap::*)( float  ) ) static_cast<void (OpenGl_ShadowMap::*)( float  ) >(&OpenGl_ShadowMap::SetShadowMapBias),
             R"#(Sets shadowmap bias.)#"  , py::arg("theBias")
          )
        .def("UpdateCamera",
             (bool (OpenGl_ShadowMap::*)(  const Graphic3d_CView & ,   const gp_XYZ *  ) ) static_cast<bool (OpenGl_ShadowMap::*)(  const Graphic3d_CView & ,   const gp_XYZ *  ) >(&OpenGl_ShadowMap::UpdateCamera),
             R"#(Compute camera.)#"  , py::arg("theView"),  py::arg("theOrigin")=static_cast< const gp_XYZ *>(nullptr)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_ShadowMap::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_ShadowMap::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_ShadowMap::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_ShadowMap::*)() const>(&OpenGl_ShadowMap::DynamicType),
             R"#()#"
             
         )
       .def("FrameBuffer",
             ( const handle<OpenGl_FrameBuffer> & (OpenGl_ShadowMap::*)() const) static_cast< const handle<OpenGl_FrameBuffer> & (OpenGl_ShadowMap::*)() const>(&OpenGl_ShadowMap::FrameBuffer),
             R"#(Return framebuffer.)#"
             
         )
       .def("Texture",
             ( const handle<OpenGl_Texture> & (OpenGl_ShadowMap::*)() const) static_cast< const handle<OpenGl_Texture> & (OpenGl_ShadowMap::*)() const>(&OpenGl_ShadowMap::Texture),
             R"#(Return depth texture.)#"
             
         )
       .def("LightSource",
             ( const handle<Graphic3d_CLight> & (OpenGl_ShadowMap::*)() const) static_cast< const handle<Graphic3d_CLight> & (OpenGl_ShadowMap::*)() const>(&OpenGl_ShadowMap::LightSource),
             R"#(Return light source casting the shadow or NULL if undefined.)#"
             
         )
       .def("Camera",
             ( const handle<Graphic3d_Camera> & (OpenGl_ShadowMap::*)() const) static_cast< const handle<Graphic3d_Camera> & (OpenGl_ShadowMap::*)() const>(&OpenGl_ShadowMap::Camera),
             R"#(Return rendering camera.)#"
             
         )
       .def("LightSourceMatrix",
             ( const NCollection_Mat4<float> & (OpenGl_ShadowMap::*)() const) static_cast< const NCollection_Mat4<float> & (OpenGl_ShadowMap::*)() const>(&OpenGl_ShadowMap::LightSourceMatrix),
             R"#(Return light source mapping matrix.)#"
             
         )
;

    // Class OpenGl_Texture from ./opencascade/OpenGl_Texture.hxx
    klass = m.attr("OpenGl_Texture");


    // nested enums

    static_cast<py::class_<OpenGl_Texture ,opencascade::handle<OpenGl_Texture>  , OpenGl_NamedResource >>(klass)
    // constructors
        .def(py::init<  const TCollection_AsciiString &, const handle<Graphic3d_TextureParams> & >()  , py::arg("theResourceId")=static_cast< const TCollection_AsciiString &>(TCollection_AsciiString :: EmptyString ( )),  py::arg("theParams")=static_cast< const handle<Graphic3d_TextureParams> &>(occ :: handle < Graphic3d_TextureParams > ( )) )
    // custom constructors
    // methods
        .def("IsValid",
             (bool (OpenGl_Texture::*)() const) static_cast<bool (OpenGl_Texture::*)() const>(&OpenGl_Texture::IsValid),
             R"#(Returns true if current object was initialized)#" 
          )
        .def("GetTarget",
             (unsigned int (OpenGl_Texture::*)() const) static_cast<unsigned int (OpenGl_Texture::*)() const>(&OpenGl_Texture::GetTarget),
             R"#(Returns target to which the texture is bound (GL_TEXTURE_1D, GL_TEXTURE_2D))#" 
          )
        .def("SizeX",
             (int (OpenGl_Texture::*)() const) static_cast<int (OpenGl_Texture::*)() const>(&OpenGl_Texture::SizeX),
             R"#(Return texture width (0 LOD))#" 
          )
        .def("SizeY",
             (int (OpenGl_Texture::*)() const) static_cast<int (OpenGl_Texture::*)() const>(&OpenGl_Texture::SizeY),
             R"#(Return texture height (0 LOD))#" 
          )
        .def("SizeZ",
             (int (OpenGl_Texture::*)() const) static_cast<int (OpenGl_Texture::*)() const>(&OpenGl_Texture::SizeZ),
             R"#(Return texture depth (0 LOD))#" 
          )
        .def("TextureId",
             (unsigned int (OpenGl_Texture::*)() const) static_cast<unsigned int (OpenGl_Texture::*)() const>(&OpenGl_Texture::TextureId),
             R"#(Returns texture ID)#" 
          )
        .def("GetFormat",
             (unsigned int (OpenGl_Texture::*)() const) static_cast<unsigned int (OpenGl_Texture::*)() const>(&OpenGl_Texture::GetFormat),
             R"#(Returns texture format (not sized))#" 
          )
        .def("SizedFormat",
             (int (OpenGl_Texture::*)() const) static_cast<int (OpenGl_Texture::*)() const>(&OpenGl_Texture::SizedFormat),
             R"#(Returns texture format (sized))#" 
          )
        .def("IsAlpha",
             (bool (OpenGl_Texture::*)() const) static_cast<bool (OpenGl_Texture::*)() const>(&OpenGl_Texture::IsAlpha),
             R"#(Return true for GL_RED and GL_ALPHA formats.)#" 
          )
        .def("SetAlpha",
             (void (OpenGl_Texture::*)(  const bool  ) ) static_cast<void (OpenGl_Texture::*)(  const bool  ) >(&OpenGl_Texture::SetAlpha),
             R"#(Setup to interpret the format as Alpha by Shader Manager (should be GL_ALPHA within compatible context or GL_RED otherwise).)#"  , py::arg("theValue")
          )
        .def("IsTopDown",
             (bool (OpenGl_Texture::*)() const) static_cast<bool (OpenGl_Texture::*)() const>(&OpenGl_Texture::IsTopDown),
             R"#(Return if 2D surface is defined top-down (TRUE) or bottom-up (FALSE). Normally set from Image_PixMap::IsTopDown() within texture initialization.)#" 
          )
        .def("SetTopDown",
             (void (OpenGl_Texture::*)( bool  ) ) static_cast<void (OpenGl_Texture::*)( bool  ) >(&OpenGl_Texture::SetTopDown),
             R"#(Set if 2D surface is defined top-down (TRUE) or bottom-up (FALSE).)#"  , py::arg("theIsTopDown")
          )
        .def("Create",
             (bool (OpenGl_Texture::*)(  const handle<OpenGl_Context> &  ) ) static_cast<bool (OpenGl_Texture::*)(  const handle<OpenGl_Context> &  ) >(&OpenGl_Texture::Create),
             R"#(Creates Texture id if not yet generated. Data should be initialized by another method.)#"  , py::arg("theCtx")
          )
        .def("Release",
             (void (OpenGl_Texture::*)( OpenGl_Context *  ) ) static_cast<void (OpenGl_Texture::*)( OpenGl_Context *  ) >(&OpenGl_Texture::Release),
             R"#(Destroy object - will release GPU memory if any.)#"  , py::arg("theCtx")
          )
        .def("SetSampler",
             (void (OpenGl_Texture::*)(  const handle<OpenGl_Sampler> &  ) ) static_cast<void (OpenGl_Texture::*)(  const handle<OpenGl_Sampler> &  ) >(&OpenGl_Texture::SetSampler),
             R"#(Set texture sampler.)#"  , py::arg("theSampler")
          )
        .def("InitSamplerObject",
             (bool (OpenGl_Texture::*)(  const handle<OpenGl_Context> &  ) ) static_cast<bool (OpenGl_Texture::*)(  const handle<OpenGl_Context> &  ) >(&OpenGl_Texture::InitSamplerObject),
             R"#(Initialize the Sampler Object (as OpenGL object).)#"  , py::arg("theCtx")
          )
        .def("Bind",
             (void (OpenGl_Texture::*)(  const handle<OpenGl_Context> &  ) const) static_cast<void (OpenGl_Texture::*)(  const handle<OpenGl_Context> &  ) const>(&OpenGl_Texture::Bind),
             R"#(Bind this Texture to the unit specified in sampler parameters. Also binds Sampler Object if it is allocated.)#"  , py::arg("theCtx")
          )
        .def("Unbind",
             (void (OpenGl_Texture::*)(  const handle<OpenGl_Context> &  ) const) static_cast<void (OpenGl_Texture::*)(  const handle<OpenGl_Context> &  ) const>(&OpenGl_Texture::Unbind),
             R"#(Unbind texture from the unit specified in sampler parameters. Also unbinds Sampler Object if it is allocated.)#"  , py::arg("theCtx")
          )
        .def("Bind",
             (void (OpenGl_Texture::*)(  const handle<OpenGl_Context> & ,   const Graphic3d_TextureUnit  ) const) static_cast<void (OpenGl_Texture::*)(  const handle<OpenGl_Context> & ,   const Graphic3d_TextureUnit  ) const>(&OpenGl_Texture::Bind),
             R"#(Bind this Texture to specified unit. Also binds Sampler Object if it is allocated.)#"  , py::arg("theCtx"),  py::arg("theTextureUnit")
          )
        .def("Unbind",
             (void (OpenGl_Texture::*)(  const handle<OpenGl_Context> & ,   const Graphic3d_TextureUnit  ) const) static_cast<void (OpenGl_Texture::*)(  const handle<OpenGl_Context> & ,   const Graphic3d_TextureUnit  ) const>(&OpenGl_Texture::Unbind),
             R"#(Unbind texture from specified unit. Also unbinds Sampler Object if it is allocated.)#"  , py::arg("theCtx"),  py::arg("theTextureUnit")
          )
        .def("Revision",
             (size_t (OpenGl_Texture::*)() const) static_cast<size_t (OpenGl_Texture::*)() const>(&OpenGl_Texture::Revision),
             R"#(Revision of associated data source.)#" 
          )
        .def("SetRevision",
             (void (OpenGl_Texture::*)(  const size_t  ) ) static_cast<void (OpenGl_Texture::*)(  const size_t  ) >(&OpenGl_Texture::SetRevision),
             R"#(Set revision of associated data source.)#"  , py::arg("theRevision")
          )
        .def("Init",
             (bool (OpenGl_Texture::*)(  const handle<OpenGl_Context> & ,   const Image_PixMap & ,   const Graphic3d_TypeOfTexture ,   const bool  ) ) static_cast<bool (OpenGl_Texture::*)(  const handle<OpenGl_Context> & ,   const Image_PixMap & ,   const Graphic3d_TypeOfTexture ,   const bool  ) >(&OpenGl_Texture::Init),
             R"#(Notice that texture will be unbound after this call.)#"  , py::arg("theCtx"),  py::arg("theImage"),  py::arg("theType"),  py::arg("theIsColorMap")
          )
        .def("Init",
             (bool (OpenGl_Texture::*)(  const handle<OpenGl_Context> & ,   const OpenGl_TextureFormat & ,   const NCollection_Vec3<int> & ,   const Graphic3d_TypeOfTexture ,   const Image_PixMap *  ) ) static_cast<bool (OpenGl_Texture::*)(  const handle<OpenGl_Context> & ,   const OpenGl_TextureFormat & ,   const NCollection_Vec3<int> & ,   const Graphic3d_TypeOfTexture ,   const Image_PixMap *  ) >(&OpenGl_Texture::Init),
             R"#(Initialize the texture with specified format, size and texture type. If theImage is empty the texture data will contain trash. Notice that texture will be unbound after this call.)#"  , py::arg("theCtx"),  py::arg("theFormat"),  py::arg("theSizeXYZ"),  py::arg("theType"),  py::arg("theImage")=static_cast< const Image_PixMap *>(nullptr)
          )
        .def("Init",
             (bool (OpenGl_Texture::*)(  const handle<OpenGl_Context> & ,   const OpenGl_TextureFormat & ,   const NCollection_Vec2<int> & ,   const Graphic3d_TypeOfTexture ,   const Image_PixMap *  ) ) static_cast<bool (OpenGl_Texture::*)(  const handle<OpenGl_Context> & ,   const OpenGl_TextureFormat & ,   const NCollection_Vec2<int> & ,   const Graphic3d_TypeOfTexture ,   const Image_PixMap *  ) >(&OpenGl_Texture::Init),
             R"#(Initialize the 2D texture with specified format, size and texture type. If theImage is empty the texture data will contain trash. Notice that texture will be unbound after this call.)#"  , py::arg("theCtx"),  py::arg("theFormat"),  py::arg("theSizeXY"),  py::arg("theType"),  py::arg("theImage")=static_cast< const Image_PixMap *>(nullptr)
          )
        .def("Init",
             (bool (OpenGl_Texture::*)(  const handle<OpenGl_Context> & ,   const handle<Graphic3d_TextureRoot> &  ) ) static_cast<bool (OpenGl_Texture::*)(  const handle<OpenGl_Context> & ,   const handle<Graphic3d_TextureRoot> &  ) >(&OpenGl_Texture::Init),
             R"#(Initialize the texture with Graphic3d_TextureMap. It is an universal way to initialize. Suitable initialization method will be chosen.)#"  , py::arg("theCtx"),  py::arg("theTextureMap")
          )
        .def("GenerateMipmaps",
             (bool (OpenGl_Texture::*)(  const handle<OpenGl_Context> &  ) ) static_cast<bool (OpenGl_Texture::*)(  const handle<OpenGl_Context> &  ) >(&OpenGl_Texture::GenerateMipmaps),
             R"#(Generate mipmaps.)#"  , py::arg("theCtx")
          )
        .def("InitCompressed",
             (bool (OpenGl_Texture::*)(  const handle<OpenGl_Context> & ,   const Image_CompressedPixMap & ,   const bool  ) ) static_cast<bool (OpenGl_Texture::*)(  const handle<OpenGl_Context> & ,   const Image_CompressedPixMap & ,   const bool  ) >(&OpenGl_Texture::InitCompressed),
             R"#(Initialize the texture with Image_CompressedPixMap.)#"  , py::arg("theCtx"),  py::arg("theImage"),  py::arg("theIsColorMap")
          )
        .def("Init2DMultisample",
             (bool (OpenGl_Texture::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,   const int ,   const int  ) ) static_cast<bool (OpenGl_Texture::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,   const int ,   const int  ) >(&OpenGl_Texture::Init2DMultisample),
             R"#(Initialize the 2D multisampling texture using glTexImage2DMultisample().)#"  , py::arg("theCtx"),  py::arg("theNbSamples"),  py::arg("theTextFormat"),  py::arg("theSizeX"),  py::arg("theSizeY")
          )
        .def("InitRectangle",
             (bool (OpenGl_Texture::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,   const OpenGl_TextureFormat &  ) ) static_cast<bool (OpenGl_Texture::*)(  const handle<OpenGl_Context> & ,   const int ,   const int ,   const OpenGl_TextureFormat &  ) >(&OpenGl_Texture::InitRectangle),
             R"#(Allocates texture rectangle with specified format and size.)#"  , py::arg("theCtx"),  py::arg("theSizeX"),  py::arg("theSizeY"),  py::arg("theFormat")
          )
        .def("Init3D",
             (bool (OpenGl_Texture::*)(  const handle<OpenGl_Context> & ,   const OpenGl_TextureFormat & ,   const NCollection_Vec3<int> & ,   const void *  ) ) static_cast<bool (OpenGl_Texture::*)(  const handle<OpenGl_Context> & ,   const OpenGl_TextureFormat & ,   const NCollection_Vec3<int> & ,   const void *  ) >(&OpenGl_Texture::Init3D),
             R"#(Initializes 3D texture rectangle with specified format and size.)#"  , py::arg("theCtx"),  py::arg("theFormat"),  py::arg("theSizeXYZ"),  py::arg("thePixels")
          )
        .def("HasMipmaps",
             (bool (OpenGl_Texture::*)() const) static_cast<bool (OpenGl_Texture::*)() const>(&OpenGl_Texture::HasMipmaps),
             R"#(Returns true if texture was generated within mipmaps)#" 
          )
        .def("MaxMipmapLevel",
             (int (OpenGl_Texture::*)() const) static_cast<int (OpenGl_Texture::*)() const>(&OpenGl_Texture::MaxMipmapLevel),
             R"#(Return upper mipmap level index (0 means no mipmaps).)#" 
          )
        .def("NbSamples",
             (int (OpenGl_Texture::*)() const) static_cast<int (OpenGl_Texture::*)() const>(&OpenGl_Texture::NbSamples),
             R"#(Return number of MSAA samples.)#" 
          )
        .def("EstimatedDataSize",
             (size_t (OpenGl_Texture::*)() const) static_cast<size_t (OpenGl_Texture::*)() const>(&OpenGl_Texture::EstimatedDataSize),
             R"#(Returns estimated GPU memory usage for holding data without considering overheads and allocation alignment rules.)#" 
          )
        .def("IsPointSprite",
             (bool (OpenGl_Texture::*)() const) static_cast<bool (OpenGl_Texture::*)() const>(&OpenGl_Texture::IsPointSprite),
             R"#(Returns TRUE for point sprite texture.)#" 
          )
        .def("ImageDump",
             (bool (OpenGl_Texture::*)( Image_PixMap & ,   const handle<OpenGl_Context> & ,  Graphic3d_TextureUnit ,  int ,  int  ) const) static_cast<bool (OpenGl_Texture::*)( Image_PixMap & ,   const handle<OpenGl_Context> & ,  Graphic3d_TextureUnit ,  int ,  int  ) const>(&OpenGl_Texture::ImageDump),
             R"#(Auxiliary method for making an image dump from texture data.)#"  , py::arg("theImage"),  py::arg("theCtx"),  py::arg("theTexUnit"),  py::arg("theLevel")=static_cast<int>(0),  py::arg("theCubeSide")=static_cast<int>(0)
          )
        .def("Init",
             (bool (OpenGl_Texture::*)(  const handle<OpenGl_Context> & ,   const int ,   const unsigned int ,   const unsigned int ,   const int ,   const int ,   const Graphic3d_TypeOfTexture ,   const Image_PixMap *  ) ) static_cast<bool (OpenGl_Texture::*)(  const handle<OpenGl_Context> & ,   const int ,   const unsigned int ,   const unsigned int ,   const int ,   const int ,   const Graphic3d_TypeOfTexture ,   const Image_PixMap *  ) >(&OpenGl_Texture::Init),
             R"#()#"  , py::arg("theCtx"),  py::arg("theTextFormat"),  py::arg("thePixelFormat"),  py::arg("theDataType"),  py::arg("theSizeX"),  py::arg("theSizeY"),  py::arg("theType"),  py::arg("theImage")=static_cast< const Image_PixMap *>(nullptr)
          )
        .def("Init",
             (bool (OpenGl_Texture::*)(  const handle<OpenGl_Context> & ,   const Image_PixMap & ,   const Graphic3d_TypeOfTexture  ) ) static_cast<bool (OpenGl_Texture::*)(  const handle<OpenGl_Context> & ,   const Image_PixMap & ,   const Graphic3d_TypeOfTexture  ) >(&OpenGl_Texture::Init),
             R"#()#"  , py::arg("theCtx"),  py::arg("theImage"),  py::arg("theType")
          )
        .def("Init3D",
             (bool (OpenGl_Texture::*)(  const handle<OpenGl_Context> & ,   const int ,   const unsigned int ,   const unsigned int ,   const int ,   const int ,   const int ,   const void *  ) ) static_cast<bool (OpenGl_Texture::*)(  const handle<OpenGl_Context> & ,   const int ,   const unsigned int ,   const unsigned int ,   const int ,   const int ,   const int ,   const void *  ) >(&OpenGl_Texture::Init3D),
             R"#()#"  , py::arg("theCtx"),  py::arg("theTextFormat"),  py::arg("thePixelFormat"),  py::arg("theDataType"),  py::arg("theSizeX"),  py::arg("theSizeY"),  py::arg("theSizeZ"),  py::arg("thePixels")
          )
        .def("InitCubeMap",
             (bool (OpenGl_Texture::*)(  const handle<OpenGl_Context> & ,   const handle<Graphic3d_CubeMap> & ,  size_t ,  Image_Format ,  bool ,  bool  ) ) static_cast<bool (OpenGl_Texture::*)(  const handle<OpenGl_Context> & ,   const handle<Graphic3d_CubeMap> & ,  size_t ,  Image_Format ,  bool ,  bool  ) >(&OpenGl_Texture::InitCubeMap),
             R"#(Initializes 6 sides of cubemap. If theCubeMap is not NULL then size and format will be taken from it and corresponding arguments will be ignored. Otherwise this parameters will be taken from arguments.)#"  , py::arg("theCtx"),  py::arg("theCubeMap"),  py::arg("theSize"),  py::arg("theFormat"),  py::arg("theToGenMipmap"),  py::arg("theIsColorMap")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_Texture::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_Texture::get_type_descriptor),
                    R"#()#" 
          )
        .def_static("PixelSizeOfPixelFormat_s",
                    (size_t (*)( int  ) ) static_cast<size_t (*)( int  ) >(&OpenGl_Texture::PixelSizeOfPixelFormat),
                    R"#(Return pixel size of pixel format in bytes. Note that this method considers that OpenGL natively supports this pixel format, which might be not the case - in the latter case, actual pixel size might differ!)#"  , py::arg("theInternalFormat")
          )
        .def_static("GetDataFormat_s",
                    (bool (*)(  const handle<OpenGl_Context> & ,   const Image_Format ,  int & ,  unsigned int & ,  unsigned int &  ) ) static_cast<bool (*)(  const handle<OpenGl_Context> & ,   const Image_Format ,  int & ,  unsigned int & ,  unsigned int &  ) >(&OpenGl_Texture::GetDataFormat),
                    R"#()#"  , py::arg("theCtx"),  py::arg("theFormat"),  py::arg("theTextFormat"),  py::arg("thePixelFormat"),  py::arg("theDataType")
          )
        .def_static("GetDataFormat_s",
                    (bool (*)(  const handle<OpenGl_Context> & ,   const Image_PixMap & ,  int & ,  unsigned int & ,  unsigned int &  ) ) static_cast<bool (*)(  const handle<OpenGl_Context> & ,   const Image_PixMap & ,  int & ,  unsigned int & ,  unsigned int &  ) >(&OpenGl_Texture::GetDataFormat),
                    R"#()#"  , py::arg("theCtx"),  py::arg("theData"),  py::arg("theTextFormat"),  py::arg("thePixelFormat"),  py::arg("theDataType")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_Texture::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_Texture::*)() const>(&OpenGl_Texture::DynamicType),
             R"#()#"
             
         )
       .def("Size",
             ( const NCollection_Vec3<int> & (OpenGl_Texture::*)() const) static_cast< const NCollection_Vec3<int> & (OpenGl_Texture::*)() const>(&OpenGl_Texture::Size),
             R"#(Return texture dimensions (0 LOD))#"
             
         )
       .def("Sampler",
             ( const handle<OpenGl_Sampler> & (OpenGl_Texture::*)() const) static_cast< const handle<OpenGl_Sampler> & (OpenGl_Texture::*)() const>(&OpenGl_Texture::Sampler),
             R"#(Return texture sampler.)#"
             
         )
;

    // Class OpenGl_TextureBuffer from ./opencascade/OpenGl_TextureBuffer.hxx
    klass = m.attr("OpenGl_TextureBuffer");


    // nested enums

    static_cast<py::class_<OpenGl_TextureBuffer ,opencascade::handle<OpenGl_TextureBuffer>  , OpenGl_Buffer >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("GetTarget",
             (unsigned int (OpenGl_TextureBuffer::*)() const) static_cast<unsigned int (OpenGl_TextureBuffer::*)() const>(&OpenGl_TextureBuffer::GetTarget),
             R"#(Override VBO target)#" 
          )
        .def("IsValid",
             (bool (OpenGl_TextureBuffer::*)() const) static_cast<bool (OpenGl_TextureBuffer::*)() const>(&OpenGl_TextureBuffer::IsValid),
             R"#(Returns true if TBO is valid. Notice that no any real GL call is performed!)#" 
          )
        .def("Release",
             (void (OpenGl_TextureBuffer::*)( OpenGl_Context *  ) ) static_cast<void (OpenGl_TextureBuffer::*)( OpenGl_Context *  ) >(&OpenGl_TextureBuffer::Release),
             R"#(Destroy object - will release GPU memory if any.)#"  , py::arg("theGlCtx")
          )
        .def("Create",
             (bool (OpenGl_TextureBuffer::*)(  const handle<OpenGl_Context> &  ) ) static_cast<bool (OpenGl_TextureBuffer::*)(  const handle<OpenGl_Context> &  ) >(&OpenGl_TextureBuffer::Create),
             R"#(Creates VBO and Texture names (ids) if not yet generated. Data should be initialized by another method.)#"  , py::arg("theGlCtx")
          )
        .def("Init",
             (bool (OpenGl_TextureBuffer::*)(  const handle<OpenGl_Context> & ,   const unsigned int ,   const int ,   const float *  ) ) static_cast<bool (OpenGl_TextureBuffer::*)(  const handle<OpenGl_Context> & ,   const unsigned int ,   const int ,   const float *  ) >(&OpenGl_TextureBuffer::Init),
             R"#(Perform TBO initialization with specified data. Existing data will be deleted.)#"  , py::arg("theGlCtx"),  py::arg("theComponentsNb"),  py::arg("theElemsNb"),  py::arg("theData")
          )
        .def("Init",
             (bool (OpenGl_TextureBuffer::*)(  const handle<OpenGl_Context> & ,   const unsigned int ,   const int ,   const unsigned int *  ) ) static_cast<bool (OpenGl_TextureBuffer::*)(  const handle<OpenGl_Context> & ,   const unsigned int ,   const int ,   const unsigned int *  ) >(&OpenGl_TextureBuffer::Init),
             R"#(Perform TBO initialization with specified data. Existing data will be deleted.)#"  , py::arg("theGlCtx"),  py::arg("theComponentsNb"),  py::arg("theElemsNb"),  py::arg("theData")
          )
        .def("Init",
             (bool (OpenGl_TextureBuffer::*)(  const handle<OpenGl_Context> & ,   const unsigned int ,   const int ,   const unsigned short *  ) ) static_cast<bool (OpenGl_TextureBuffer::*)(  const handle<OpenGl_Context> & ,   const unsigned int ,   const int ,   const unsigned short *  ) >(&OpenGl_TextureBuffer::Init),
             R"#(Perform TBO initialization with specified data. Existing data will be deleted.)#"  , py::arg("theGlCtx"),  py::arg("theComponentsNb"),  py::arg("theElemsNb"),  py::arg("theData")
          )
        .def("Init",
             (bool (OpenGl_TextureBuffer::*)(  const handle<OpenGl_Context> & ,   const unsigned int ,   const int ,   const uint8_t *  ) ) static_cast<bool (OpenGl_TextureBuffer::*)(  const handle<OpenGl_Context> & ,   const unsigned int ,   const int ,   const uint8_t *  ) >(&OpenGl_TextureBuffer::Init),
             R"#(Perform TBO initialization with specified data. Existing data will be deleted.)#"  , py::arg("theGlCtx"),  py::arg("theComponentsNb"),  py::arg("theElemsNb"),  py::arg("theData")
          )
        .def("BindTexture",
             (void (OpenGl_TextureBuffer::*)(  const handle<OpenGl_Context> & ,   const Graphic3d_TextureUnit  ) const) static_cast<void (OpenGl_TextureBuffer::*)(  const handle<OpenGl_Context> & ,   const Graphic3d_TextureUnit  ) const>(&OpenGl_TextureBuffer::BindTexture),
             R"#(Bind TBO to specified Texture Unit.)#"  , py::arg("theGlCtx"),  py::arg("theTextureUnit")
          )
        .def("UnbindTexture",
             (void (OpenGl_TextureBuffer::*)(  const handle<OpenGl_Context> & ,   const Graphic3d_TextureUnit  ) const) static_cast<void (OpenGl_TextureBuffer::*)(  const handle<OpenGl_Context> & ,   const Graphic3d_TextureUnit  ) const>(&OpenGl_TextureBuffer::UnbindTexture),
             R"#(Unbind TBO.)#"  , py::arg("theGlCtx"),  py::arg("theTextureUnit")
          )
        .def("TextureId",
             (unsigned int (OpenGl_TextureBuffer::*)() const) static_cast<unsigned int (OpenGl_TextureBuffer::*)() const>(&OpenGl_TextureBuffer::TextureId),
             R"#(Returns name of TBO.)#" 
          )
        .def("TextureFormat",
             (unsigned int (OpenGl_TextureBuffer::*)() const) static_cast<unsigned int (OpenGl_TextureBuffer::*)() const>(&OpenGl_TextureBuffer::TextureFormat),
             R"#(Returns internal texture format.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_TextureBuffer::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_TextureBuffer::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_TextureBuffer::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_TextureBuffer::*)() const>(&OpenGl_TextureBuffer::DynamicType),
             R"#()#"
             
         )
;

    // Class OpenGl_UniformBuffer from ./opencascade/OpenGl_UniformBuffer.hxx
    klass = m.attr("OpenGl_UniformBuffer");


    // nested enums

    static_cast<py::class_<OpenGl_UniformBuffer ,opencascade::handle<OpenGl_UniformBuffer>  , OpenGl_Buffer >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("GetTarget",
             (unsigned int (OpenGl_UniformBuffer::*)() const) static_cast<unsigned int (OpenGl_UniformBuffer::*)() const>(&OpenGl_UniformBuffer::GetTarget),
             R"#(Return buffer object target (GL_UNIFORM_BUFFER).)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_UniformBuffer::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_UniformBuffer::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_UniformBuffer::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_UniformBuffer::*)() const>(&OpenGl_UniformBuffer::DynamicType),
             R"#()#"
             
         )
;

    // Class OpenGl_VertexBuffer from ./opencascade/OpenGl_VertexBuffer.hxx
    klass = m.attr("OpenGl_VertexBuffer");


    // nested enums

    static_cast<py::class_<OpenGl_VertexBuffer ,opencascade::handle<OpenGl_VertexBuffer>  , OpenGl_Buffer >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("GetTarget",
             (unsigned int (OpenGl_VertexBuffer::*)() const) static_cast<unsigned int (OpenGl_VertexBuffer::*)() const>(&OpenGl_VertexBuffer::GetTarget),
             R"#(Return buffer target GL_ARRAY_BUFFER.)#" 
          )
        .def("BindVertexAttrib",
             (void (OpenGl_VertexBuffer::*)(  const handle<OpenGl_Context> & ,   const unsigned int  ) const) static_cast<void (OpenGl_VertexBuffer::*)(  const handle<OpenGl_Context> & ,   const unsigned int  ) const>(&OpenGl_VertexBuffer::BindVertexAttrib),
             R"#(Bind this VBO to active GLSL program.)#"  , py::arg("theGlCtx"),  py::arg("theAttribLoc")
          )
        .def("UnbindVertexAttrib",
             (void (OpenGl_VertexBuffer::*)(  const handle<OpenGl_Context> & ,   const unsigned int  ) const) static_cast<void (OpenGl_VertexBuffer::*)(  const handle<OpenGl_Context> & ,   const unsigned int  ) const>(&OpenGl_VertexBuffer::UnbindVertexAttrib),
             R"#(Unbind any VBO from active GLSL program.)#"  , py::arg("theGlCtx"),  py::arg("theAttribLoc")
          )
        .def("BindAttribute",
             (void (OpenGl_VertexBuffer::*)(  const handle<OpenGl_Context> & ,   const Graphic3d_TypeOfAttribute  ) const) static_cast<void (OpenGl_VertexBuffer::*)(  const handle<OpenGl_Context> & ,   const Graphic3d_TypeOfAttribute  ) const>(&OpenGl_VertexBuffer::BindAttribute),
             R"#(Bind this VBO and enable specified attribute in OpenGl_Context::ActiveProgram() or FFP.)#"  , py::arg("theCtx"),  py::arg("theMode")
          )
        .def("UnbindAttribute",
             (void (OpenGl_VertexBuffer::*)(  const handle<OpenGl_Context> & ,   const Graphic3d_TypeOfAttribute  ) const) static_cast<void (OpenGl_VertexBuffer::*)(  const handle<OpenGl_Context> & ,   const Graphic3d_TypeOfAttribute  ) const>(&OpenGl_VertexBuffer::UnbindAttribute),
             R"#(Unbind this VBO and disable specified attribute in OpenGl_Context::ActiveProgram() or FFP.)#"  , py::arg("theCtx"),  py::arg("theMode")
          )
        .def("HasColorAttribute",
             (bool (OpenGl_VertexBuffer::*)() const) static_cast<bool (OpenGl_VertexBuffer::*)() const>(&OpenGl_VertexBuffer::HasColorAttribute),
             R"#(Returns true if buffer contains per-vertex color attribute)#" 
          )
        .def("HasNormalAttribute",
             (bool (OpenGl_VertexBuffer::*)() const) static_cast<bool (OpenGl_VertexBuffer::*)() const>(&OpenGl_VertexBuffer::HasNormalAttribute),
             R"#(Returns true if buffer contains per-vertex normal attribute)#" 
          )
        .def("BindAllAttributes",
             (void (OpenGl_VertexBuffer::*)(  const handle<OpenGl_Context> &  ) const) static_cast<void (OpenGl_VertexBuffer::*)(  const handle<OpenGl_Context> &  ) const>(&OpenGl_VertexBuffer::BindAllAttributes),
             R"#(Bind all vertex attributes to active program OpenGl_Context::ActiveProgram() or for FFP. Default implementation does nothing.)#"  , py::arg("theGlCtx")
          )
        .def("BindPositionAttribute",
             (void (OpenGl_VertexBuffer::*)(  const handle<OpenGl_Context> &  ) const) static_cast<void (OpenGl_VertexBuffer::*)(  const handle<OpenGl_Context> &  ) const>(&OpenGl_VertexBuffer::BindPositionAttribute),
             R"#(Bind vertex position attribute only. Default implementation does nothing.)#"  , py::arg("theGlCtx")
          )
        .def("UnbindAllAttributes",
             (void (OpenGl_VertexBuffer::*)(  const handle<OpenGl_Context> &  ) const) static_cast<void (OpenGl_VertexBuffer::*)(  const handle<OpenGl_Context> &  ) const>(&OpenGl_VertexBuffer::UnbindAllAttributes),
             R"#(Unbind all vertex attributes. Default implementation does nothing.)#"  , py::arg("theGlCtx")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("bindAttribute_s",
                    (void (*)(  const handle<OpenGl_Context> & ,   const Graphic3d_TypeOfAttribute ,   const int ,   const unsigned int ,   const int ,   const void *  ) ) static_cast<void (*)(  const handle<OpenGl_Context> & ,   const Graphic3d_TypeOfAttribute ,   const int ,   const unsigned int ,   const int ,   const void *  ) >(&OpenGl_VertexBuffer::bindAttribute),
                    R"#(Setup array pointer - either for active GLSL program OpenGl_Context::ActiveProgram() or for FFP using bindFixed() when no program bound.)#"  , py::arg("theGlCtx"),  py::arg("theMode"),  py::arg("theNbComp"),  py::arg("theDataType"),  py::arg("theStride"),  py::arg("theOffset")
          )
        .def_static("unbindAttribute_s",
                    (void (*)(  const handle<OpenGl_Context> & ,   const Graphic3d_TypeOfAttribute  ) ) static_cast<void (*)(  const handle<OpenGl_Context> & ,   const Graphic3d_TypeOfAttribute  ) >(&OpenGl_VertexBuffer::unbindAttribute),
                    R"#(Disable GLSL array pointer - either for active GLSL program OpenGl_Context::ActiveProgram() or for FFP using unbindFixed() when no program bound.)#"  , py::arg("theGlCtx"),  py::arg("theMode")
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_VertexBuffer::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_VertexBuffer::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_VertexBuffer::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_VertexBuffer::*)() const>(&OpenGl_VertexBuffer::DynamicType),
             R"#()#"
             
         )
;

    // Class OpenGl_PointSprite from ./opencascade/OpenGl_PointSprite.hxx
    klass = m.attr("OpenGl_PointSprite");


    // nested enums

    static_cast<py::class_<OpenGl_PointSprite ,opencascade::handle<OpenGl_PointSprite>  , OpenGl_Texture >>(klass)
    // constructors
        .def(py::init<  const TCollection_AsciiString & >()  , py::arg("theResourceId") )
    // custom constructors
    // methods
        .def("Release",
             (void (OpenGl_PointSprite::*)( OpenGl_Context *  ) ) static_cast<void (OpenGl_PointSprite::*)( OpenGl_Context *  ) >(&OpenGl_PointSprite::Release),
             R"#(Destroy object - will release GPU memory if any.)#"  , py::arg("theCtx")
          )
        .def("IsPointSprite",
             (bool (OpenGl_PointSprite::*)() const) static_cast<bool (OpenGl_PointSprite::*)() const>(&OpenGl_PointSprite::IsPointSprite),
             R"#(Returns TRUE for point sprite texture.)#" 
          )
        .def("IsValid",
             (bool (OpenGl_PointSprite::*)() const) static_cast<bool (OpenGl_PointSprite::*)() const>(&OpenGl_PointSprite::IsValid),
             R"#(Returns true if current object was initialized)#" 
          )
        .def("IsDisplayList",
             (bool (OpenGl_PointSprite::*)() const) static_cast<bool (OpenGl_PointSprite::*)() const>(&OpenGl_PointSprite::IsDisplayList),
             R"#(Returns true if this is display list bitmap)#" 
          )
        .def("DrawBitmap",
             (void (OpenGl_PointSprite::*)(  const handle<OpenGl_Context> &  ) const) static_cast<void (OpenGl_PointSprite::*)(  const handle<OpenGl_Context> &  ) const>(&OpenGl_PointSprite::DrawBitmap),
             R"#(Draw sprite using glBitmap. Please call glRasterPos3fv() before to setup sprite position.)#"  , py::arg("theCtx")
          )
        .def("SetDisplayList",
             (void (OpenGl_PointSprite::*)(  const handle<OpenGl_Context> & ,   const GLuint  ) ) static_cast<void (OpenGl_PointSprite::*)(  const handle<OpenGl_Context> & ,   const GLuint  ) >(&OpenGl_PointSprite::SetDisplayList),
             R"#(Initialize point sprite as display list)#"  , py::arg("theCtx"),  py::arg("theBitmapList")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&OpenGl_PointSprite::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&OpenGl_PointSprite::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (OpenGl_PointSprite::*)() const) static_cast< const handle<Standard_Type> & (OpenGl_PointSprite::*)() const>(&OpenGl_PointSprite::DynamicType),
             R"#()#"
             
         )
;

// functions
auto mOpenGl_Raytrace = static_cast<py::module>(m.attr("OpenGl_Raytrace"));

// ./opencascade/OpenGl_ArbDbg.hxx
// ./opencascade/OpenGl_ArbFBO.hxx
// ./opencascade/OpenGl_ArbIns.hxx
// ./opencascade/OpenGl_ArbSamplerObject.hxx
// ./opencascade/OpenGl_ArbTBO.hxx
// ./opencascade/OpenGl_ArbTexBindless.hxx
// ./opencascade/OpenGl_Aspects.hxx
// ./opencascade/OpenGl_AspectsProgram.hxx
// ./opencascade/OpenGl_AspectsSprite.hxx
// ./opencascade/OpenGl_AspectsTextureSet.hxx
// ./opencascade/OpenGl_BackgroundArray.hxx
// ./opencascade/OpenGl_Buffer.hxx
// ./opencascade/OpenGl_BufferCompatT.hxx
// ./opencascade/OpenGl_CappingAlgo.hxx
// ./opencascade/OpenGl_CappingPlaneResource.hxx
// ./opencascade/OpenGl_Caps.hxx
// ./opencascade/OpenGl_Clipping.hxx
// ./opencascade/OpenGl_ClippingIterator.hxx
// ./opencascade/OpenGl_Context.hxx
// ./opencascade/OpenGl_DepthPeeling.hxx
// ./opencascade/OpenGl_Element.hxx
// ./opencascade/OpenGl_ExtGS.hxx
// ./opencascade/OpenGl_Flipper.hxx
// ./opencascade/OpenGl_Font.hxx
// ./opencascade/OpenGl_FrameBuffer.hxx
// ./opencascade/OpenGl_FrameStats.hxx
// ./opencascade/OpenGl_FrameStatsPrs.hxx
// ./opencascade/OpenGl_GlCore11.hxx
// ./opencascade/OpenGl_GlCore11Fwd.hxx
// ./opencascade/OpenGl_GlCore12.hxx
// ./opencascade/OpenGl_GlCore13.hxx
// ./opencascade/OpenGl_GlCore14.hxx
// ./opencascade/OpenGl_GlCore15.hxx
// ./opencascade/OpenGl_GlCore20.hxx
// ./opencascade/OpenGl_GlCore21.hxx
// ./opencascade/OpenGl_GlCore30.hxx
// ./opencascade/OpenGl_GlCore31.hxx
// ./opencascade/OpenGl_GlCore32.hxx
// ./opencascade/OpenGl_GlCore33.hxx
// ./opencascade/OpenGl_GlCore40.hxx
// ./opencascade/OpenGl_GlCore41.hxx
// ./opencascade/OpenGl_GlCore42.hxx
// ./opencascade/OpenGl_GlCore43.hxx
// ./opencascade/OpenGl_GlCore44.hxx
// ./opencascade/OpenGl_GlCore45.hxx
// ./opencascade/OpenGl_GlCore46.hxx
// ./opencascade/OpenGl_GlFunctions.hxx
// ./opencascade/OpenGl_GlNative.hxx
// ./opencascade/OpenGl_GlTypes.hxx
// ./opencascade/OpenGl_GraduatedTrihedron.hxx
// ./opencascade/OpenGl_GraphicDriver.hxx
// ./opencascade/OpenGl_GraphicDriverFactory.hxx
// ./opencascade/OpenGl_Group.hxx
// ./opencascade/OpenGl_HaltonSampler.hxx
// ./opencascade/OpenGl_IndexBuffer.hxx
// ./opencascade/OpenGl_Layer.hxx
// ./opencascade/OpenGl_LayerFilter.hxx
// ./opencascade/OpenGl_LayerList.hxx
// ./opencascade/OpenGl_LineAttributes.hxx
// ./opencascade/OpenGl_Material.hxx
// ./opencascade/OpenGl_MaterialState.hxx
// ./opencascade/OpenGl_MatrixState.hxx
// ./opencascade/OpenGl_NamedResource.hxx
// ./opencascade/OpenGl_PBREnvironment.hxx
// ./opencascade/OpenGl_PointSprite.hxx
// ./opencascade/OpenGl_PrimitiveArray.hxx
// ./opencascade/OpenGl_RenderFilter.hxx
// ./opencascade/OpenGl_Resource.hxx
// ./opencascade/OpenGl_Sampler.hxx
// ./opencascade/OpenGl_SceneGeometry.hxx
    mOpenGl_Raytrace.def("IsRaytracedGroup",
          (bool (*)(  const OpenGl_Group *  ))  static_cast<bool (*)(  const OpenGl_Group *  )>(&OpenGl_Raytrace::IsRaytracedGroup),
          R"#(Checks to see if the group contains ray-trace geometry.)#"  , py::arg("theGroup")
          );
    mOpenGl_Raytrace.def("IsRaytracedElement",
          (bool (*)(  const OpenGl_ElementNode *  ))  static_cast<bool (*)(  const OpenGl_ElementNode *  )>(&OpenGl_Raytrace::IsRaytracedElement),
          R"#(Checks to see if the element contains ray-trace geometry.)#"  , py::arg("theNode")
          );
    mOpenGl_Raytrace.def("IsRaytracedElement",
          (bool (*)(  const OpenGl_Element *  ))  static_cast<bool (*)(  const OpenGl_Element *  )>(&OpenGl_Raytrace::IsRaytracedElement),
          R"#(Checks to see if the element contains ray-trace geometry.)#"  , py::arg("theElement")
          );
// ./opencascade/OpenGl_SetOfShaderPrograms.hxx
// ./opencascade/OpenGl_ShaderGrid.hxx
// ./opencascade/OpenGl_ShaderManager.hxx
// ./opencascade/OpenGl_ShaderObject.hxx
// ./opencascade/OpenGl_ShaderProgram.hxx
// ./opencascade/OpenGl_ShaderProgramDumpLevel.hxx
// ./opencascade/OpenGl_ShaderStates.hxx
// ./opencascade/OpenGl_ShadowMap.hxx
// ./opencascade/OpenGl_StencilTest.hxx
// ./opencascade/OpenGl_Structure.hxx
// ./opencascade/OpenGl_StructureShadow.hxx
// ./opencascade/OpenGl_Text.hxx
// ./opencascade/OpenGl_TextBuilder.hxx
// ./opencascade/OpenGl_Texture.hxx
// ./opencascade/OpenGl_TextureBuffer.hxx
// ./opencascade/OpenGl_TextureFormat.hxx
// ./opencascade/OpenGl_TextureSet.hxx
// ./opencascade/OpenGl_TextureSetPairIterator.hxx
// ./opencascade/OpenGl_TileSampler.hxx
// ./opencascade/OpenGl_UniformBuffer.hxx
// ./opencascade/OpenGl_Vec.hxx
// ./opencascade/OpenGl_VertexBuffer.hxx
// ./opencascade/OpenGl_VertexBufferCompat.hxx
// ./opencascade/OpenGl_VertexBufferEditor.hxx
// ./opencascade/OpenGl_View.hxx
// ./opencascade/OpenGl_Window.hxx
// ./opencascade/OpenGl_Workspace.hxx

// Additional functions


// operators

// register typdefs
    register_template_BVH_Triangulation<float, 3>(m,"OpenGl_BVHTriangulation3f");
    register_template_OpenGl_BufferCompatT<OpenGl_VertexBuffer>(m,"OpenGl_VertexBufferCompat");
    register_template_OpenGl_BufferCompatT<OpenGl_IndexBuffer>(m,"OpenGl_IndexBufferCompat");

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
