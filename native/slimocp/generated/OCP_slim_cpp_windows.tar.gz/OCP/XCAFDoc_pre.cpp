
// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;


// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Attribute.hxx>
#include <Standard_GUID.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDocStd_Document.hxx>
#include <XCAFDoc_ShapeTool.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDocStd_Document.hxx>
#include <XCAFDoc_ShapeTool.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDocStd_Document.hxx>
#include <XCAFDoc_ShapeTool.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_GUID.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_GUID.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <XCAFDoc_ShapeTool.hxx>
#include <Standard_GUID.hxx>
#include <Quantity_Color.hxx>
#include <Quantity_ColorRGBA.hxx>
#include <TopoDS_Shape.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_HAsciiString.hxx>
#include <Standard_GUID.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_HAsciiString.hxx>
#include <Standard_GUID.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <XCAFDoc_ShapeTool.hxx>
#include <Standard_GUID.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_GUID.hxx>
#include <TDF_Label.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_GUID.hxx>
#include <TDF_Label.hxx>
#include <TDocStd_Document.hxx>
#include <XCAFDoc_ShapeTool.hxx>
#include <XCAFDoc_ColorTool.hxx>
#include <XCAFDoc_ClippingPlaneTool.hxx>
#include <XCAFDoc_LayerTool.hxx>
#include <XCAFDoc_DimTolTool.hxx>
#include <XCAFDoc_MaterialTool.hxx>
#include <XCAFDoc_NotesTool.hxx>
#include <XCAFDoc_ViewTool.hxx>
#include <XCAFDoc_VisMaterialTool.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <XCAFDoc_VisMaterial.hxx>
#include <XCAFDoc_ShapeTool.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_GUID.hxx>
#include <TDF_Label.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <TDF_DataSet.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <XCAFDoc_ShapeTool.hxx>
#include <Standard_GUID.hxx>
#include <TopoDS_Shape.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_GUID.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_HAsciiString.hxx>
#include <Standard_GUID.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <XCAFDoc_ShapeTool.hxx>
#include <Standard_GUID.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OSD_File.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <OSD_File.hxx>
#include <Standard_GUID.hxx>
#include <XCAFDoc_Note.hxx>
#include <XCAFDoc_AssemblyItemId.hxx>
#include <XCAFDoc_AssemblyItemRef.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_GUID.hxx>
#include <TDF_Label.hxx>
#include <TDF_RelocationTable.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_GUID.hxx>
#include <XCAFDoc_GraphNode.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_GUID.hxx>
#include <TDF_Label.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_GUID.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_Aspects.hxx>
#include <Graphic3d_MaterialAspect.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_Aspects.hxx>
#include <Graphic3d_MaterialAspect.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TopoDS_Shape.hxx>
#include <XCAFDoc_ShapeTool.hxx>
#include <XCAFDoc_VisMaterial.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TDF_Label.hxx>

// module includes
#include <XCAFDoc.hxx>
#include <XCAFDoc_Area.hxx>
#include <XCAFDoc_AssemblyGraph.hxx>
#include <XCAFDoc_AssemblyItemId.hxx>
#include <XCAFDoc_AssemblyItemRef.hxx>
#include <XCAFDoc_AssemblyIterator.hxx>
#include <XCAFDoc_AssemblyTool.hxx>
#include <XCAFDoc_Centroid.hxx>
#include <XCAFDoc_ClippingPlaneTool.hxx>
#include <XCAFDoc_Color.hxx>
#include <XCAFDoc_ColorTool.hxx>
#include <XCAFDoc_ColorType.hxx>
#include <XCAFDoc_Datum.hxx>
#include <XCAFDoc_Dimension.hxx>
#include <XCAFDoc_DimTol.hxx>
#include <XCAFDoc_DimTolTool.hxx>
#include <XCAFDoc_DocumentTool.hxx>
#include <XCAFDoc_Editor.hxx>
#include <XCAFDoc_GeomTolerance.hxx>
#include <XCAFDoc_GraphNode.hxx>
#include <XCAFDoc_LayerTool.hxx>
#include <XCAFDoc_LengthUnit.hxx>
#include <XCAFDoc_Location.hxx>
#include <XCAFDoc_Material.hxx>
#include <XCAFDoc_MaterialTool.hxx>
#include <XCAFDoc_Note.hxx>
#include <XCAFDoc_NoteBalloon.hxx>
#include <XCAFDoc_NoteBinData.hxx>
#include <XCAFDoc_NoteComment.hxx>
#include <XCAFDoc_NotesTool.hxx>
#include <XCAFDoc_PartId.hxx>
#include <XCAFDoc_ShapeMapTool.hxx>
#include <XCAFDoc_ShapeTool.hxx>
#include <XCAFDoc_View.hxx>
#include <XCAFDoc_ViewTool.hxx>
#include <XCAFDoc_VisMaterial.hxx>
#include <XCAFDoc_VisMaterialCommon.hxx>
#include <XCAFDoc_VisMaterialPBR.hxx>
#include <XCAFDoc_VisMaterialTool.hxx>
#include <XCAFDoc_Volume.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_XCAFDoc_enums(py::module &main_module) {


py::module m = main_module.def_submodule("XCAFDoc", R"#()#");

// add namespaces as submodules

// user-defined inclusion per module in the body

// enums
    py::enum_<XCAFDoc_ColorType>(m, "XCAFDoc_ColorType",R"#(Defines types of color assignments Color of shape is defined following way in dependance with type of color. If type of color is XCAFDoc_ColorGen - then this color defines default color for surfaces and curves. If for shape color with types XCAFDoc_ColorSurf or XCAFDoc_ColorCurv is specified then such color overrides generic color. simple color color of surfaces color of curves)#")
        .value("XCAFDoc_ColorGen",XCAFDoc_ColorType::XCAFDoc_ColorGen)
        .value("XCAFDoc_ColorSurf",XCAFDoc_ColorType::XCAFDoc_ColorSurf)
        .value("XCAFDoc_ColorCurv",XCAFDoc_ColorType::XCAFDoc_ColorCurv).export_values();

//Python trampoline classes
    class Py_XCAFDoc_Note : public XCAFDoc_Note{
    public:
        using XCAFDoc_Note::XCAFDoc_Note;


        // public pure virtual

         const Standard_GUID & ID() const  override { using return_type =  const Standard_GUID &;
    PYBIND11_OVERLOAD_PURE(return_type,TDF_Attribute,ID,) };
        handle<TDF_Attribute> NewEmpty() const  override { using return_type = handle<TDF_Attribute>;
    PYBIND11_OVERLOAD_PURE(return_type,TDF_Attribute,NewEmpty,) };

        // protected pure virtual


        // private pure virtual

    };

// pre-register typdefs+classes (topologically sorted)
    py::class_<XCAFDoc , shared_ptr<XCAFDoc>  >(
      m,
      "XCAFDoc",R"#(Definition of general structure of DECAF document and tools to work with it)#"
    );
    py::class_<XCAFDoc_AssemblyItemId , shared_ptr<XCAFDoc_AssemblyItemId>  >(
      m,
      "XCAFDoc_AssemblyItemId",R"#(Unique item identifier in the hierarchical product structure. A full path to an assembly component in the "part-of" graph starting from the root node.)#"
    );
    py::class_<XCAFDoc_AssemblyIterator , shared_ptr<XCAFDoc_AssemblyIterator>  >(
      m,
      "XCAFDoc_AssemblyIterator",R"#(Iterator in depth along the assembly tree.)#"
    );
    py::class_<XCAFDoc_AssemblyTool , shared_ptr<XCAFDoc_AssemblyTool>  >(
      m,
      "XCAFDoc_AssemblyTool",R"#(Provides generic methods for traversing assembly tree and graph)#"
    );
    py::class_<XCAFDoc_Editor , shared_ptr<XCAFDoc_Editor>  >(
      m,
      "XCAFDoc_Editor",R"#(Tool for edit structure of document.)#"
    );
    py::class_<XCAFDoc_VisMaterialCommon , shared_ptr<XCAFDoc_VisMaterialCommon>  >(
      m,
      "XCAFDoc_VisMaterialCommon",R"#(Common (obsolete) material definition.)#"
    );
    py::class_<XCAFDoc_VisMaterialPBR , shared_ptr<XCAFDoc_VisMaterialPBR>  >(
      m,
      "XCAFDoc_VisMaterialPBR",R"#(Metallic-roughness PBR material definition.)#"
    );
    py::class_<XCAFDoc_Area ,opencascade::handle<XCAFDoc_Area>  , TDataStd_Real >(
      m,
      "XCAFDoc_Area",R"#(attribute to store area)#"
    );
    py::class_<XCAFDoc_AssemblyGraph ,opencascade::handle<XCAFDoc_AssemblyGraph>  , Standard_Transient >(
      m,
      "XCAFDoc_AssemblyGraph",R"#()#"
    );
    py::class_<XCAFDoc_AssemblyItemRef ,opencascade::handle<XCAFDoc_AssemblyItemRef>  , TDF_Attribute >(
      m,
      "XCAFDoc_AssemblyItemRef",R"#(An attribute that describes a weak reference to an assembly item or to a subshape or to an assembly label attribute.)#"
    );
    py::class_<XCAFDoc_Centroid ,opencascade::handle<XCAFDoc_Centroid>  , TDF_Attribute >(
      m,
      "XCAFDoc_Centroid",R"#(attribute to store centroid)#"
    );
    py::class_<XCAFDoc_ClippingPlaneTool ,opencascade::handle<XCAFDoc_ClippingPlaneTool>  , TDataStd_GenericEmpty >(
      m,
      "XCAFDoc_ClippingPlaneTool",R"#(Provide tool for management of ClippingPlane section of document. Provide tool to store, retrieve, remove and modify clipping planes. Each clipping plane consists of gp_Pln and its name.)#"
    );
    py::class_<XCAFDoc_Color ,opencascade::handle<XCAFDoc_Color>  , TDF_Attribute >(
      m,
      "XCAFDoc_Color",R"#(attribute to store color)#"
    );
    py::class_<XCAFDoc_ColorTool ,opencascade::handle<XCAFDoc_ColorTool>  , TDataStd_GenericEmpty >(
      m,
      "XCAFDoc_ColorTool",R"#(Provides tools to store and retrieve attributes (colors) of TopoDS_Shape in and from TDocStd_Document A Document is intended to hold different attributes of ONE shape and it's sub-shapes Provide tools for management of Colors section of document.)#"
    );
    py::class_<XCAFDoc_Datum ,opencascade::handle<XCAFDoc_Datum>  , TDF_Attribute >(
      m,
      "XCAFDoc_Datum",R"#(attribute to store datum)#"
    );
    py::class_<XCAFDoc_DimTol ,opencascade::handle<XCAFDoc_DimTol>  , TDF_Attribute >(
      m,
      "XCAFDoc_DimTol",R"#(attribute to store dimension and tolerance)#"
    );
    py::class_<XCAFDoc_DimTolTool ,opencascade::handle<XCAFDoc_DimTolTool>  , TDataStd_GenericEmpty >(
      m,
      "XCAFDoc_DimTolTool",R"#(Attribute containing GD&T section of XCAF document. Provide tools for GD&T section management.)#"
    );
    py::class_<XCAFDoc_Dimension ,opencascade::handle<XCAFDoc_Dimension>  , TDataStd_GenericEmpty >(
      m,
      "XCAFDoc_Dimension",R"#(Attribute that identifies a dimension in the GD&T table. Its parent label is used as a container to store data provided by XCAFDimTolObjects_DimensionObject.)#"
    );
    py::class_<XCAFDoc_DocumentTool ,opencascade::handle<XCAFDoc_DocumentTool>  , TDataStd_GenericEmpty >(
      m,
      "XCAFDoc_DocumentTool",R"#(Defines sections structure of an XDE document. attribute marking CAF document as being DECAF document. Creates the sections structure of the document.)#"
    );
    py::class_<XCAFDoc_GeomTolerance ,opencascade::handle<XCAFDoc_GeomTolerance>  , TDataStd_GenericEmpty >(
      m,
      "XCAFDoc_GeomTolerance",R"#(Attribute to store dimension and tolerance)#"
    );
    py::class_<XCAFDoc_GraphNode ,opencascade::handle<XCAFDoc_GraphNode>  , TDF_Attribute >(
      m,
      "XCAFDoc_GraphNode",R"#(This attribute allow user multirelation tree of labels. This GraphNode is experimental Graph that not control looping and redundance. Attribute containing sequence of father's and child's labels. Provide create and work with Graph in XCAFDocument.This attribute allow user multirelation tree of labels. This GraphNode is experimental Graph that not control looping and redundance. Attribute containing sequence of father's and child's labels. Provide create and work with Graph in XCAFDocument.)#"
    );
    py::class_<XCAFDoc_LayerTool ,opencascade::handle<XCAFDoc_LayerTool>  , TDataStd_GenericEmpty >(
      m,
      "XCAFDoc_LayerTool",R"#(Provides tools to store and retrieve attributes (Layers) of TopoDS_Shape in and from TDocStd_Document A Document is intended to hold different attributes of ONE shape and it's sub-shapes Provide tools for management of Layers section of document.)#"
    );
    py::class_<XCAFDoc_LengthUnit ,opencascade::handle<XCAFDoc_LengthUnit>  , TDF_Attribute >(
      m,
      "XCAFDoc_LengthUnit",R"#(Used to define a Length Unit attribute containing a length unit info)#"
    );
    py::class_<XCAFDoc_Location ,opencascade::handle<XCAFDoc_Location>  , TDF_Attribute >(
      m,
      "XCAFDoc_Location",R"#(attribute to store TopLoc_Location)#"
    );
    py::class_<XCAFDoc_Material ,opencascade::handle<XCAFDoc_Material>  , TDF_Attribute >(
      m,
      "XCAFDoc_Material",R"#(attribute to store material)#"
    );
    py::class_<XCAFDoc_MaterialTool ,opencascade::handle<XCAFDoc_MaterialTool>  , TDataStd_GenericEmpty >(
      m,
      "XCAFDoc_MaterialTool",R"#(Provides tools to store and retrieve attributes (materials) of TopoDS_Shape in and from TDocStd_Document A Document is intended to hold different attributes of ONE shape and it's sub-shapes Provide tools for management of Materialss section of document.)#"
    );
    py::class_<XCAFDoc_Note ,opencascade::handle<XCAFDoc_Note> ,Py_XCAFDoc_Note , TDF_Attribute >(
      m,
      "XCAFDoc_Note",R"#(A base note attribute. Any note contains the name of the user created the note and the creation timestamp.)#"
    );
    py::class_<XCAFDoc_NotesTool ,opencascade::handle<XCAFDoc_NotesTool>  , TDataStd_GenericEmpty >(
      m,
      "XCAFDoc_NotesTool",R"#(A tool to annotate items in the hierarchical product structure. There are two basic entities, which operates the notes tool: notes and annotated items. A note is a user defined data structure derived from XCAFDoc_Note attribute that is attached to a separate label under the notes hive. An annotated item is represented by XCAFDoc_AssemblyItemRef attribute attached to a separate label under the annotated items hive. Notes are linked with annotated items by means of XCAFDoc_GraphNode attribute. Notes play parent roles and annotated items - child roles.)#"
    );
    py::class_<XCAFDoc_ShapeMapTool ,opencascade::handle<XCAFDoc_ShapeMapTool>  , TDF_Attribute >(
      m,
      "XCAFDoc_ShapeMapTool",R"#(attribute containing map of sub shapes)#"
    );
    py::class_<XCAFDoc_ShapeTool ,opencascade::handle<XCAFDoc_ShapeTool>  , TDataStd_GenericEmpty >(
      m,
      "XCAFDoc_ShapeTool",R"#(A tool to store shapes in an XDE document in the form of assembly structure, and to maintain this structure. Attribute containing Shapes section of DECAF document. Provide tools for management of Shapes section. The API provided by this class allows to work with this structure regardless of its low-level implementation. All the shapes are stored on child labels of a main label which is XCAFDoc_DocumentTool::LabelShapes(). The label for assembly also has sub-labels, each of which represents the instance of another shape in that assembly (component). Such sub-label stores reference to the label of the original shape in the form of TDataStd_TreeNode with GUID XCAFDoc::ShapeRefGUID(), and its location encapsulated into the NamedShape. For correct work with an XDE document, it is necessary to use methods for analysis and methods for working with shapes. For example: if ( STool->IsAssembly(aLabel) ) { bool subchilds = false; (default) int nbc = STool->NbComponents (aLabel[,subchilds]); } If subchilds is True, commands also consider sub-levels. By default, only level one is checked. In this example, number of children from the first level of assembly will be returned. Methods for creation and initialization: Constructor: XCAFDoc_ShapeTool::XCAFDoc_ShapeTool() Getting a guid: Standard_GUID GetID (); Creation (if does not exist) of ShapeTool on label L: occ::handle<XCAFDoc_ShapeTool> XCAFDoc_ShapeTool::Set(const TDF_Label& L) Analyze whether shape is a simple shape or an instance or a component of an assembly or it is an assembly ( methods of analysis). For example: STool->IsShape(aLabel) ; Analyze that the label represents a shape (simple shape, assembly or reference) or STool->IsTopLevel(aLabel); Analyze that the label is a label of a top-level shape. Work with simple shapes, assemblies and instances ( methods for work with shapes). For example: Add shape: bool makeAssembly; // True to interpret a Compound as an Assembly, False to take it as a whole aLabel = STool->AddShape(aShape, makeAssembly); Get shape: TDF_Label aLabel... // A label must be present if (aLabel.IsNull()) { ... no such label : abandon .. } TopoDS_Shape aShape; aShape = STool->GetShape(aLabel); if (aShape.IsNull()) { ... this label is not for a Shape ... } To get a label from shape. bool findInstance = false; (this is default value) aLabel = STool->FindShape(aShape [,findInstance]); if (aLabel.IsNull()) { ... no label found for this shape ... })#"
    );
    py::class_<XCAFDoc_View ,opencascade::handle<XCAFDoc_View>  , TDataStd_GenericEmpty >(
      m,
      "XCAFDoc_View",R"#(Attribute to store view)#"
    );
    py::class_<XCAFDoc_ViewTool ,opencascade::handle<XCAFDoc_ViewTool>  , TDataStd_GenericEmpty >(
      m,
      "XCAFDoc_ViewTool",R"#(Provides tools to store and retrieve Views in and from TDocStd_Document Each View contains parts XCAFDoc_View attribute with all information about camera and view window. Also each view contain information of displayed shapes and GDTs as sets of shape and GDT labels.)#"
    );
    py::class_<XCAFDoc_VisMaterial ,opencascade::handle<XCAFDoc_VisMaterial>  , TDF_Attribute >(
      m,
      "XCAFDoc_VisMaterial",R"#(Attribute storing Material definition for visualization purposes.)#"
    );
    py::class_<XCAFDoc_VisMaterialTool ,opencascade::handle<XCAFDoc_VisMaterialTool>  , TDF_Attribute >(
      m,
      "XCAFDoc_VisMaterialTool",R"#(Provides tools to store and retrieve attributes (visualization materials) of TopoDS_Shape in and from TDocStd_Document.)#"
    );
    py::class_<XCAFDoc_Volume ,opencascade::handle<XCAFDoc_Volume>  , TDataStd_Real >(
      m,
      "XCAFDoc_Volume",R"#(attribute to store volume)#"
    );
    py::class_<XCAFDoc_NoteBinData ,opencascade::handle<XCAFDoc_NoteBinData>  , XCAFDoc_Note >(
      m,
      "XCAFDoc_NoteBinData",R"#()#"
    );
    py::class_<XCAFDoc_NoteComment ,opencascade::handle<XCAFDoc_NoteComment>  , XCAFDoc_Note >(
      m,
      "XCAFDoc_NoteComment",R"#(A comment note attribute. Contains a textual comment.)#"
    );
    py::class_<XCAFDoc_NoteBalloon ,opencascade::handle<XCAFDoc_NoteBalloon>  , XCAFDoc_NoteComment >(
      m,
      "XCAFDoc_NoteBalloon",R"#(A comment note attribute. Contains a textual comment.)#"
    );

// preregister user-defined template specializations

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
