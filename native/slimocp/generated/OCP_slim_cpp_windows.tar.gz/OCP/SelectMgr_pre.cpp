
// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;


// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_Structure.hxx>
#include <Graphic3d_TransformPers.hxx>
#include <SelectMgr_Selection.hxx>
#include <gp_Trsf.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <SelectMgr_EntityOwner.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_Camera.hxx>
#include <SelectMgr_FrustumBuilder.hxx>
#include <SelectMgr_ViewClipRange.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <V3d_Viewer.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <SelectMgr_EntityOwner.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <SelectMgr_EntityOwner.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <SelectMgr_EntityOwner.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <SelectMgr_ViewerSelector.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Ax1.hxx>
#include <Graphic3d_SequenceOfHClipPlane.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <SelectMgr_SensitiveEntitySet.hxx>
#include <V3d_View.hxx>

// module includes
#include <SelectMgr.hxx>
#include <SelectMgr_AndFilter.hxx>
#include <SelectMgr_AndOrFilter.hxx>
#include <SelectMgr_AxisIntersector.hxx>
#include <SelectMgr_BaseFrustum.hxx>
#include <SelectMgr_BaseIntersector.hxx>
#include <SelectMgr_BVHThreadPool.hxx>
#include <SelectMgr_CompositionFilter.hxx>
#include <SelectMgr_EntityOwner.hxx>
#include <SelectMgr_Filter.hxx>
#include <SelectMgr_FilterType.hxx>
#include <SelectMgr_Frustum.hxx>
#include <SelectMgr_FrustumBuilder.hxx>
#include <SelectMgr_OrFilter.hxx>
#include <SelectMgr_PickingStrategy.hxx>
#include <SelectMgr_RectangularFrustum.hxx>
#include <SelectMgr_SelectableObject.hxx>
#include <SelectMgr_SelectableObjectSet.hxx>
#include <SelectMgr_SelectingVolumeManager.hxx>
#include <SelectMgr_Selection.hxx>
#include <SelectMgr_SelectionImageFiller.hxx>
#include <SelectMgr_SelectionManager.hxx>
#include <SelectMgr_SelectionType.hxx>
#include <SelectMgr_SensitiveEntity.hxx>
#include <SelectMgr_SensitiveEntitySet.hxx>
#include <SelectMgr_SortCriterion.hxx>
#include <SelectMgr_StateOfSelection.hxx>
#include <SelectMgr_ToleranceMap.hxx>
#include <SelectMgr_TriangularFrustum.hxx>
#include <SelectMgr_TriangularFrustumSet.hxx>
#include <SelectMgr_TypeOfBVHUpdate.hxx>
#include <SelectMgr_TypeOfDepthTolerance.hxx>
#include <SelectMgr_TypeOfUpdate.hxx>
#include <SelectMgr_ViewClipRange.hxx>
#include <SelectMgr_ViewerSelector.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_SelectMgr_enums(py::module &main_module) {


py::module m = main_module.def_submodule("SelectMgr", R"#()#");

// add namespaces as submodules

// user-defined inclusion per module in the body

// enums
    py::enum_<SelectMgr_TypeOfUpdate>(m, "SelectMgr_TypeOfUpdate",R"#(Provides values for types of update, including - full - partial - none.)#")
        .value("SelectMgr_TOU_Full",SelectMgr_TypeOfUpdate::SelectMgr_TOU_Full)
        .value("SelectMgr_TOU_Partial",SelectMgr_TypeOfUpdate::SelectMgr_TOU_Partial)
        .value("SelectMgr_TOU_None",SelectMgr_TypeOfUpdate::SelectMgr_TOU_None).export_values();
    py::enum_<SelectMgr_SelectionType>(m, "SelectMgr_SelectionType",R"#(Possible selection types)#")
        .value("SelectMgr_SelectionType_Unknown",SelectMgr_SelectionType::SelectMgr_SelectionType_Unknown)
        .value("SelectMgr_SelectionType_Point",SelectMgr_SelectionType::SelectMgr_SelectionType_Point)
        .value("SelectMgr_SelectionType_Box",SelectMgr_SelectionType::SelectMgr_SelectionType_Box)
        .value("SelectMgr_SelectionType_Polyline",SelectMgr_SelectionType::SelectMgr_SelectionType_Polyline).export_values();
    py::enum_<SelectMgr_FilterType>(m, "SelectMgr_FilterType",R"#(Enumeration defines the filter type.)#")
        .value("SelectMgr_FilterType_AND",SelectMgr_FilterType::SelectMgr_FilterType_AND)
        .value("SelectMgr_FilterType_OR",SelectMgr_FilterType::SelectMgr_FilterType_OR).export_values();
    py::enum_<SelectMgr_StateOfSelection>(m, "SelectMgr_StateOfSelection",R"#(different state of a Selection in a ViewerSelector...)#")
        .value("SelectMgr_SOS_Any",SelectMgr_StateOfSelection::SelectMgr_SOS_Any)
        .value("SelectMgr_SOS_Unknown",SelectMgr_StateOfSelection::SelectMgr_SOS_Unknown)
        .value("SelectMgr_SOS_Deactivated",SelectMgr_StateOfSelection::SelectMgr_SOS_Deactivated)
        .value("SelectMgr_SOS_Activated",SelectMgr_StateOfSelection::SelectMgr_SOS_Activated).export_values();
    py::enum_<SelectMgr_PickingStrategy>(m, "SelectMgr_PickingStrategy",R"#(Enumeration defines picking strategy - which entities detected by picking line will be accepted, considering selection filters.)#")
        .value("SelectMgr_PickingStrategy_FirstAcceptable",SelectMgr_PickingStrategy::SelectMgr_PickingStrategy_FirstAcceptable)
        .value("SelectMgr_PickingStrategy_OnlyTopmost",SelectMgr_PickingStrategy::SelectMgr_PickingStrategy_OnlyTopmost).export_values();
    py::enum_<SelectMgr_TypeOfDepthTolerance>(m, "SelectMgr_TypeOfDepthTolerance",R"#(Define the type of depth tolerance for considering picked entities to lie on the same depth (distance from eye to entity).)#")
        .value("SelectMgr_TypeOfDepthTolerance_Uniform",SelectMgr_TypeOfDepthTolerance::SelectMgr_TypeOfDepthTolerance_Uniform)
        .value("SelectMgr_TypeOfDepthTolerance_UniformPixels",SelectMgr_TypeOfDepthTolerance::SelectMgr_TypeOfDepthTolerance_UniformPixels)
        .value("SelectMgr_TypeOfDepthTolerance_SensitivityFactor",SelectMgr_TypeOfDepthTolerance::SelectMgr_TypeOfDepthTolerance_SensitivityFactor).export_values();
    py::enum_<SelectMgr_TypeOfBVHUpdate>(m, "SelectMgr_TypeOfBVHUpdate",R"#(Keeps track for BVH update state for each SelectMgr_Selection entity in a following way: - Add : 2nd level BVH does not contain any of the selection's sensitive entities and they must be added; - Remove : all sensitive entities of the selection must be removed from 2nd level BVH; - Renew : 2nd level BVH already contains sensitives of the selection, but the its complete update and removal is required. Therefore, sensitives of the selection with this type of update must be removed from 2nd level BVH and added after recomputation. - Invalidate : the 2nd level BVH needs to be rebuilt; - None : entities of the selection are up to date.)#")
        .value("SelectMgr_TBU_Add",SelectMgr_TypeOfBVHUpdate::SelectMgr_TBU_Add)
        .value("SelectMgr_TBU_Remove",SelectMgr_TypeOfBVHUpdate::SelectMgr_TBU_Remove)
        .value("SelectMgr_TBU_Renew",SelectMgr_TypeOfBVHUpdate::SelectMgr_TBU_Renew)
        .value("SelectMgr_TBU_Invalidate",SelectMgr_TypeOfBVHUpdate::SelectMgr_TBU_Invalidate)
        .value("SelectMgr_TBU_None",SelectMgr_TypeOfBVHUpdate::SelectMgr_TBU_None).export_values();

//Python trampoline classes
    class Py_SelectMgr_BaseIntersector : public SelectMgr_BaseIntersector{
    public:
        using SelectMgr_BaseIntersector::SelectMgr_BaseIntersector;


        // public pure virtual
        void Build() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,SelectMgr_BaseIntersector,Build,) };
        bool IsScalable() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,SelectMgr_BaseIntersector,IsScalable,) };
        handle<SelectMgr_BaseIntersector> ScaleAndTransform( const int theScaleFactor, const gp_GTrsf & theTrsf, const handle<SelectMgr_FrustumBuilder> & theBuilder) const  override { using return_type = handle<SelectMgr_BaseIntersector>;
    PYBIND11_OVERLOAD_PURE(return_type,SelectMgr_BaseIntersector,ScaleAndTransform,theScaleFactor,theTrsf,theBuilder) };
        handle<SelectMgr_BaseIntersector> CopyWithBuilder( const handle<SelectMgr_FrustumBuilder> & theBuilder) const  override { using return_type = handle<SelectMgr_BaseIntersector>;
    PYBIND11_OVERLOAD_PURE(return_type,SelectMgr_BaseIntersector,CopyWithBuilder,theBuilder) };
        bool OverlapsBox( const NCollection_Vec3<double> & theBoxMin, const NCollection_Vec3<double> & theBoxMax,bool * theInside) const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,SelectMgr_BaseIntersector,OverlapsBox,theBoxMin,theBoxMax,theInside) };
        bool OverlapsPoint( const gp_Pnt & thePnt) const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,SelectMgr_BaseIntersector,OverlapsPoint,thePnt) };
        bool OverlapsSphere( const gp_Pnt & theCenter, const double theRadius,bool * theInside) const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,SelectMgr_BaseIntersector,OverlapsSphere,theCenter,theRadius,theInside) };
        bool OverlapsCylinder( const double theBottomRad, const double theTopRad, const double theHeight, const gp_Trsf & theTrsf, const bool theIsHollow,bool * theInside) const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,SelectMgr_BaseIntersector,OverlapsCylinder,theBottomRad,theTopRad,theHeight,theTrsf,theIsHollow,theInside) };
        bool OverlapsCircle( const double theBottomRad, const gp_Trsf & theTrsf, const bool theIsFilled,bool * theInside) const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,SelectMgr_BaseIntersector,OverlapsCircle,theBottomRad,theTrsf,theIsFilled,theInside) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_SelectMgr_Filter : public SelectMgr_Filter{
    public:
        using SelectMgr_Filter::SelectMgr_Filter;


        // public pure virtual
        bool IsOk( const handle<SelectMgr_EntityOwner> & anObj) const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,SelectMgr_Filter,IsOk,anObj) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_SelectMgr_SelectableObject : public SelectMgr_SelectableObject{
    public:
        using SelectMgr_SelectableObject::SelectMgr_SelectableObject;


        // public pure virtual
        void ComputeSelection( const handle<SelectMgr_Selection> & theSelection, const int theMode) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,SelectMgr_SelectableObject,ComputeSelection,theSelection,theMode) };


        // protected pure virtual

        void Compute( const handle<PrsMgr_PresentationManager> & thePrsMgr, const handle<Prs3d_Presentation> & thePrs, const int theMode) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,PrsMgr_PresentableObject,Compute,thePrsMgr,thePrs,theMode) };

        // private pure virtual

    };
    class Py_SelectMgr_SelectionImageFiller : public SelectMgr_SelectionImageFiller{
    public:
        using SelectMgr_SelectionImageFiller::SelectMgr_SelectionImageFiller;


        // public pure virtual
        void Fill( const int theCol, const int theRow, const int thePicked) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,SelectMgr_SelectionImageFiller,Fill,theCol,theRow,thePicked) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_SelectMgr_BaseFrustum : public SelectMgr_BaseFrustum{
    public:
        using SelectMgr_BaseFrustum::SelectMgr_BaseFrustum;


        // public pure virtual

        void Build() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,SelectMgr_BaseIntersector,Build,) };
        bool IsScalable() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,SelectMgr_BaseIntersector,IsScalable,) };
        handle<SelectMgr_BaseIntersector> ScaleAndTransform( const int theScaleFactor, const gp_GTrsf & theTrsf, const handle<SelectMgr_FrustumBuilder> & theBuilder) const  override { using return_type = handle<SelectMgr_BaseIntersector>;
    PYBIND11_OVERLOAD_PURE(return_type,SelectMgr_BaseIntersector,ScaleAndTransform,theScaleFactor,theTrsf,theBuilder) };
        handle<SelectMgr_BaseIntersector> CopyWithBuilder( const handle<SelectMgr_FrustumBuilder> & theBuilder) const  override { using return_type = handle<SelectMgr_BaseIntersector>;
    PYBIND11_OVERLOAD_PURE(return_type,SelectMgr_BaseIntersector,CopyWithBuilder,theBuilder) };
        bool OverlapsBox( const NCollection_Vec3<double> & theBoxMin, const NCollection_Vec3<double> & theBoxMax,bool * theInside) const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,SelectMgr_BaseIntersector,OverlapsBox,theBoxMin,theBoxMax,theInside) };
        bool OverlapsPoint( const gp_Pnt & thePnt) const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,SelectMgr_BaseIntersector,OverlapsPoint,thePnt) };
        bool OverlapsSphere( const gp_Pnt & theCenter, const double theRadius,bool * theInside) const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,SelectMgr_BaseIntersector,OverlapsSphere,theCenter,theRadius,theInside) };
        bool OverlapsCylinder( const double theBottomRad, const double theTopRad, const double theHeight, const gp_Trsf & theTrsf, const bool theIsHollow,bool * theInside) const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,SelectMgr_BaseIntersector,OverlapsCylinder,theBottomRad,theTopRad,theHeight,theTrsf,theIsHollow,theInside) };
        bool OverlapsCircle( const double theBottomRad, const gp_Trsf & theTrsf, const bool theIsFilled,bool * theInside) const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,SelectMgr_BaseIntersector,OverlapsCircle,theBottomRad,theTrsf,theIsFilled,theInside) };

        // protected pure virtual


        // private pure virtual

    };
    class Py_SelectMgr_CompositionFilter : public SelectMgr_CompositionFilter{
    public:
        using SelectMgr_CompositionFilter::SelectMgr_CompositionFilter;


        // public pure virtual

        bool IsOk( const handle<SelectMgr_EntityOwner> & anObj) const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,SelectMgr_Filter,IsOk,anObj) };

        // protected pure virtual


        // private pure virtual

    };

// pre-register typdefs+classes (topologically sorted)
    py::class_<SelectMgr , shared_ptr<SelectMgr>  >(
      m,
      "SelectMgr",R"#(Auxiliary tools for SelectMgr package.)#"
    );
    py::class_<SelectMgr_SelectableObjectSet , shared_ptr<SelectMgr_SelectableObjectSet>  >(
      m,
      "SelectMgr_SelectableObjectSet",R"#(The purpose of this class is to organize all selectable objects into data structure, allowing to build set of BVH trees for each transformation persistence subclass of selectable objects. This allow to minify number of updates for BVH trees - for example 2D persistent object subclass depends only on camera's projection and the corresponding BVH tree needs to be updated when camera's projection parameters change, while another tree for non-persistent objects can be left unchanged in this case.)#"
    );
    py::class_<SelectMgr_SortCriterion , shared_ptr<SelectMgr_SortCriterion>  >(
      m,
      "SelectMgr_SortCriterion",R"#(This class provides data and criterion for sorting candidate entities in the process of interactive selection by mouse click)#"
    );
    py::class_<SelectMgr_ToleranceMap , shared_ptr<SelectMgr_ToleranceMap>  >(
      m,
      "SelectMgr_ToleranceMap",R"#(An internal class for calculation of current largest tolerance value which will be applied for creation of selecting frustum by default. Each time the selection set is deactivated, maximum tolerance value will be recalculated. If a user enables custom precision using StdSelect_ViewerSelector3d::SetPixelTolerance, it will be applied to all sensitive entities without any checks.)#"
    );
    py::class_<SelectMgr_ViewClipRange , shared_ptr<SelectMgr_ViewClipRange>  >(
      m,
      "SelectMgr_ViewClipRange",R"#(Class for handling depth clipping range. It is used to perform checks in case if global (for the whole view) clipping planes are defined inside of SelectMgr_RectangularFrustum class methods.)#"
    );
    py::class_<SelectMgr_BVHThreadPool ,opencascade::handle<SelectMgr_BVHThreadPool>  , Standard_Transient >(
      m,
      "SelectMgr_BVHThreadPool",R"#(Class defining a thread pool for building BVH for the list of Select3D_SensitiveEntity within background thread(s).)#"
    );
    py::class_<SelectMgr_BaseIntersector ,opencascade::handle<SelectMgr_BaseIntersector> ,Py_SelectMgr_BaseIntersector , Standard_Transient >(
      m,
      "SelectMgr_BaseIntersector",R"#(This class is an interface for different types of selecting intersector, defining different selection types, like point, box or polyline selection. It contains signatures of functions for detection of overlap by sensitive entity and initializes some data for building the selecting intersector)#"
    );
    py::class_<SelectMgr_EntityOwner ,opencascade::handle<SelectMgr_EntityOwner>  , Standard_Transient >(
      m,
      "SelectMgr_EntityOwner",R"#(A framework to define classes of owners of sensitive primitives. The owner is the link between application and selection data structures. For the application to make its own objects selectable, it must define owner classes inheriting this framework.)#"
    );
    py::class_<SelectMgr_Filter ,opencascade::handle<SelectMgr_Filter> ,Py_SelectMgr_Filter , Standard_Transient >(
      m,
      "SelectMgr_Filter",R"#(The root class to define filter objects for selection. Advance handling of objects requires the services of filters. These only allow dynamic detection and selection of objects which correspond to the criteria defined in each. Eight standard filters inheriting SelectMgr_Filter are defined in Open CASCADE. You can create your own filters by defining new filter classes inheriting this framework. You use these filters by loading them into an AIS interactive context.)#"
    );
    py::class_<SelectMgr_FrustumBuilder ,opencascade::handle<SelectMgr_FrustumBuilder>  , Standard_Transient >(
      m,
      "SelectMgr_FrustumBuilder",R"#(The purpose of this class is to provide unified interface for building selecting frustum depending on current camera projection and orientation matrices, window size and viewport parameters.)#"
    );
    py::class_<SelectMgr_RectangularFrustum , shared_ptr<SelectMgr_RectangularFrustum>  >(
      m,
      "SelectMgr_RectangularFrustum",R"#(This class contains representation of rectangular selecting frustum, created in case of point and box selection, and algorithms for overlap detection between selecting frustum and sensitive entities. The principle of frustum calculation: - for point selection: on a near view frustum plane rectangular neighborhood of user-picked point is created according to the pixel tolerance given and then this rectangle is projected onto far view frustum plane. This rectangles define the parallel bases of selecting frustum; - for box selection: box points are projected onto near and far view frustum planes. These 2 projected rectangles define parallel bases of selecting frustum. Overlap detection tests are implemented according to the terms of separating axis theorem (SAT).)#"
    );
    py::class_<SelectMgr_SelectableObject ,opencascade::handle<SelectMgr_SelectableObject> ,Py_SelectMgr_SelectableObject , PrsMgr_PresentableObject >(
      m,
      "SelectMgr_SelectableObject",R"#(A framework to supply the structure of the object to be selected. At the first pick, this structure is created by calling the appropriate algorithm and retaining this framework for further picking. This abstract framework is inherited in Application Interactive Services (AIS), notably in AIS_InteractiveObject. Consequently, 3D selection should be handled by the relevant daughter classes and their member functions in AIS. This is particularly true in the creation of new interactive objects.)#"
    );
    py::class_<SelectMgr_SelectingVolumeManager , shared_ptr<SelectMgr_SelectingVolumeManager>  >(
      m,
      "SelectMgr_SelectingVolumeManager",R"#(This class is used to switch between active selecting volumes depending on selection type chosen by the user. The sample of correct selection volume initialization procedure:)#"
    );
    py::class_<SelectMgr_Selection ,opencascade::handle<SelectMgr_Selection>  , Standard_Transient >(
      m,
      "SelectMgr_Selection",R"#(Represents the state of a given selection mode for a Selectable Object. Contains all the sensitive entities available for this mode. An interactive object can have an indefinite number of modes of selection, each representing a "decomposition" into sensitive primitives; each primitive has an Owner (SelectMgr_EntityOwner) which allows us to identify the exact entity which has been detected. Each Selection mode is identified by an index. The set of sensitive primitives which correspond to a given mode is stocked in a SelectMgr_Selection object. By Convention, the default selection mode which allows us to grasp the Interactive object in its entirety will be mode 0. AIS_Trihedron : 4 selection modes - mode 0 : selection of a trihedron - mode 1 : selection of the origin of the trihedron - mode 2 : selection of the axes - mode 3 : selection of the planes XOY, YOZ, XOZ when you activate one of modes 1 2 3 4 , you pick AIS objects of type: - AIS_Point - AIS_Axis (and information on the type of axis) - AIS_Plane (and information on the type of plane). AIS_PlaneTrihedron offers 3 selection modes: - mode 0 : selection of the whole trihedron - mode 1 : selection of the origin of the trihedron - mode 2 : selection of the axes - same remarks as for the Trihedron. AIS_Shape : 7 maximum selection modes, depending on the complexity of the shape : - mode 0 : selection of the AIS_Shape - mode 1 : selection of the vertices - mode 2 : selection of the edges - mode 3 : selection of the wires - mode 4 : selection of the faces - mode 5 : selection of the shells - mode 6 : selection of the constituent solids.)#"
    );
    py::class_<SelectMgr_SelectionImageFiller ,opencascade::handle<SelectMgr_SelectionImageFiller> ,Py_SelectMgr_SelectionImageFiller , Standard_Transient >(
      m,
      "SelectMgr_SelectionImageFiller",R"#(Abstract class for filling pixel with color. This is internal tool for SelectMgr_ViewerSelector::ToPixMap().)#"
    );
    py::class_<SelectMgr_SelectionManager ,opencascade::handle<SelectMgr_SelectionManager>  , Standard_Transient >(
      m,
      "SelectMgr_SelectionManager",R"#(A framework to manage selection from the point of view of viewer selectors. These can be added and removed, and selection modes can be activated and deactivated. In addition, objects may be known to all selectors or only to some.)#"
    );
    py::class_<SelectMgr_SensitiveEntity ,opencascade::handle<SelectMgr_SensitiveEntity>  , Standard_Transient >(
      m,
      "SelectMgr_SensitiveEntity",R"#(The purpose of this class is to mark sensitive entities selectable or not depending on current active selection of parent object for proper BVH traverse)#"
    );
    py::class_<SelectMgr_SensitiveEntitySet , shared_ptr<SelectMgr_SensitiveEntitySet>  >(
      m,
      "SelectMgr_SensitiveEntitySet",R"#(This class is used to store all calculated sensitive entities of one selectable object. It provides an interface for building BVH tree which is used to speed-up the performance of searching for overlap among sensitives of one selectable object)#"
    );
    py::class_<SelectMgr_TriangularFrustum , shared_ptr<SelectMgr_TriangularFrustum>  >(
      m,
      "SelectMgr_TriangularFrustum",R"#(This class contains representation of triangular selecting frustum, created in case of polyline selection, and algorithms for overlap detection between selecting frustum and sensitive entities. Overlap detection tests are implemented according to the terms of separating axis theorem (SAT). NOTE: the object of this class can be created only as part of SelectMgr_TriangularFrustumSet.)#"
    );
    py::class_<SelectMgr_ViewerSelector ,opencascade::handle<SelectMgr_ViewerSelector>  , Standard_Transient >(
      m,
      "SelectMgr_ViewerSelector",R"#(A framework to define finding, sorting the sensitive primitives in a view. Services are also provided to define the return of the owners of those primitives selected. The primitives are sorted by criteria such as priority of the primitive or its depth in the view relative to that of other primitives. Note that in 3D, the inheriting framework StdSelect_ViewerSelector3d is only to be used if you do not want to use the services provided by AIS. Two tools are available to find and select objects found at a given position in the view. If you want to select the owners of all the objects detected at point x,y,z you use the Init - More - Next - Picked loop. If, on the other hand, you want to select only one object detected at that point, you use the Init - More - OnePicked loop. In this iteration, More is used to see if an object was picked and OnePicked, to get the object closest to the pick position. Viewer selectors are driven by SelectMgr_SelectionManager, and manipulate the SelectMgr_Selection objects given to them by the selection manager.)#"
    );
    py::class_<SelectMgr_AxisIntersector ,opencascade::handle<SelectMgr_AxisIntersector>  , SelectMgr_BaseIntersector >(
      m,
      "SelectMgr_AxisIntersector",R"#(This class contains representation of selecting axis, created in case of point selection and algorithms for overlap detection between this axis and sensitive entities.)#"
    );
    py::class_<SelectMgr_BaseFrustum ,opencascade::handle<SelectMgr_BaseFrustum> ,Py_SelectMgr_BaseFrustum , SelectMgr_BaseIntersector >(
      m,
      "SelectMgr_BaseFrustum",R"#(This class is an interface for different types of selecting frustums, defining different selection types, like point, box or polyline selection. It contains signatures of functions for detection of overlap by sensitive entity and initializes some data for building the selecting frustum)#"
    );
    py::class_<SelectMgr_CompositionFilter ,opencascade::handle<SelectMgr_CompositionFilter> ,Py_SelectMgr_CompositionFilter , SelectMgr_Filter >(
      m,
      "SelectMgr_CompositionFilter",R"#(A framework to define a compound filter composed of two or more simple filters.)#"
    );
    py::class_<SelectMgr_AndFilter ,opencascade::handle<SelectMgr_AndFilter>  , SelectMgr_CompositionFilter >(
      m,
      "SelectMgr_AndFilter",R"#(A framework to define a selection filter for two or more types of entity.)#"
    );
    py::class_<SelectMgr_AndOrFilter ,opencascade::handle<SelectMgr_AndOrFilter>  , SelectMgr_CompositionFilter >(
      m,
      "SelectMgr_AndOrFilter",R"#(A framework to define an OR or AND selection filter. To use an AND selection filter call SetUseOrFilter with False parameter. By default the OR selection filter is used.)#"
    );
    py::class_<SelectMgr_OrFilter ,opencascade::handle<SelectMgr_OrFilter>  , SelectMgr_CompositionFilter >(
      m,
      "SelectMgr_OrFilter",R"#(A framework to define an or selection filter. This selects one or another type of sensitive entity.)#"
    );
    py::class_<SelectMgr_TriangularFrustumSet ,opencascade::handle<SelectMgr_TriangularFrustumSet>  , SelectMgr_BaseFrustum >(
      m,
      "SelectMgr_TriangularFrustumSet",R"#(This class is used to handle polyline selection. The main principle of polyline selection algorithm is to split the polygon defined by polyline onto triangles. Than each of them is considered as a base for triangular frustum building. In other words, each triangle vertex will be projected from 2d screen space to 3d world space onto near and far view frustum planes. Thus, the projected triangles make up the bases of selecting frustum. When the set of such frustums is created, the function determining selection iterates through triangular frustum set and searches for overlap with any frustum.)#"
    );

// preregister user-defined template specializations

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
