
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <TColStd_HPackedMapOfInteger.hxx>
#include <TColStd_PackedMapOfInteger.hxx>

// template related includes

// ./opencascade/TColStd_PackedMapOfInteger.hxx
#include "NCollection_tmpl.hxx"


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module
        #include  "NCollection_tmpl.hxx"
        

// Module definiiton
void register_TColStd(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("TColStd"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes

// classes

    // Class TColStd_HPackedMapOfInteger from ./opencascade/TColStd_HPackedMapOfInteger.hxx
    klass = m.attr("TColStd_HPackedMapOfInteger");


    // nested enums

    static_cast<py::class_<TColStd_HPackedMapOfInteger ,opencascade::handle<TColStd_HPackedMapOfInteger>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const TColStd_PackedMapOfInteger & >()  , py::arg("theOther") )
        .def(py::init<  const int >()  , py::arg("theNbBuckets")=static_cast< const int>(1) )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&TColStd_HPackedMapOfInteger::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&TColStd_HPackedMapOfInteger::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Map",
             ( const TColStd_PackedMapOfInteger & (TColStd_HPackedMapOfInteger::*)() const) static_cast< const TColStd_PackedMapOfInteger & (TColStd_HPackedMapOfInteger::*)() const>(&TColStd_HPackedMapOfInteger::Map),
             R"#(Returns const reference to the underlying map.)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("ChangeMap",
             (TColStd_PackedMapOfInteger & (TColStd_HPackedMapOfInteger::*)() ) static_cast<TColStd_PackedMapOfInteger & (TColStd_HPackedMapOfInteger::*)() >(&TColStd_HPackedMapOfInteger::ChangeMap),
             R"#(Returns mutable reference to the underlying map.)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (TColStd_HPackedMapOfInteger::*)() const) static_cast< const handle<Standard_Type> & (TColStd_HPackedMapOfInteger::*)() const>(&TColStd_HPackedMapOfInteger::DynamicType),
             R"#()#"
             
         )
;

// functions

// ./opencascade/TColStd_HPackedMapOfInteger.hxx
// ./opencascade/TColStd_PackedMapOfInteger.hxx

// Additional functions


// operators

// register typdefs
    register_template_NCollection_PackedMap<int>(m,"TColStd_PackedMapOfInteger");

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
