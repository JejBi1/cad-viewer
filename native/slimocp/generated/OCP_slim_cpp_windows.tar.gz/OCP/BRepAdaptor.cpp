
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Geom_BezierCurve.hxx>
#include <Geom_BSplineCurve.hxx>
#include <TopoDS_Face.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Geom_BezierSurface.hxx>
#include <Geom_BSplineSurface.hxx>

// module includes
#include <BRepAdaptor_CompCurve.hxx>
#include <BRepAdaptor_Curve.hxx>
#include <BRepAdaptor_Curve2d.hxx>
#include <BRepAdaptor_Surface.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_BRepAdaptor(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("BRepAdaptor"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes

// classes

    // Class BRepAdaptor_CompCurve from ./opencascade/BRepAdaptor_CompCurve.hxx
    klass = m.attr("BRepAdaptor_CompCurve");


    // nested enums

    static_cast<py::class_<BRepAdaptor_CompCurve ,opencascade::handle<BRepAdaptor_CompCurve>  , Adaptor3d_Curve >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const TopoDS_Wire &, const bool >()  , py::arg("W"),  py::arg("KnotByCurvilinearAbcissa")=static_cast< const bool>(false) )
        .def(py::init<  const TopoDS_Wire &, const bool, const double, const double, const double >()  , py::arg("W"),  py::arg("KnotByCurvilinearAbcissa"),  py::arg("First"),  py::arg("Last"),  py::arg("Tol") )
    // custom constructors
    // methods
        .def("ShallowCopy",
             (handle<Adaptor3d_Curve> (BRepAdaptor_CompCurve::*)() const) static_cast<handle<Adaptor3d_Curve> (BRepAdaptor_CompCurve::*)() const>(&BRepAdaptor_CompCurve::ShallowCopy),
             R"#(Shallow copy of adaptor.)#" 
          )
        .def("Initialize",
             (void (BRepAdaptor_CompCurve::*)(  const TopoDS_Wire & ,   const bool  ) ) static_cast<void (BRepAdaptor_CompCurve::*)(  const TopoDS_Wire & ,   const bool  ) >(&BRepAdaptor_CompCurve::Initialize),
             R"#(Sets the wire <W>.)#"  , py::arg("W"),  py::arg("KnotByCurvilinearAbcissa")
          )
        .def("Initialize",
             (void (BRepAdaptor_CompCurve::*)(  const TopoDS_Wire & ,   const bool ,   const double ,   const double ,   const double  ) ) static_cast<void (BRepAdaptor_CompCurve::*)(  const TopoDS_Wire & ,   const bool ,   const double ,   const double ,   const double  ) >(&BRepAdaptor_CompCurve::Initialize),
             R"#(Sets wire <W> and trimmed parameter.)#"  , py::arg("W"),  py::arg("KnotByCurvilinearAbcissa"),  py::arg("First"),  py::arg("Last"),  py::arg("Tol")
          )
        .def("FirstParameter",
             (double (BRepAdaptor_CompCurve::*)() const) static_cast<double (BRepAdaptor_CompCurve::*)() const>(&BRepAdaptor_CompCurve::FirstParameter),
             R"#()#" 
          )
        .def("LastParameter",
             (double (BRepAdaptor_CompCurve::*)() const) static_cast<double (BRepAdaptor_CompCurve::*)() const>(&BRepAdaptor_CompCurve::LastParameter),
             R"#()#" 
          )
        .def("Continuity",
             (GeomAbs_Shape (BRepAdaptor_CompCurve::*)() const) static_cast<GeomAbs_Shape (BRepAdaptor_CompCurve::*)() const>(&BRepAdaptor_CompCurve::Continuity),
             R"#()#" 
          )
        .def("NbIntervals",
             (int (BRepAdaptor_CompCurve::*)(  const GeomAbs_Shape  ) const) static_cast<int (BRepAdaptor_CompCurve::*)(  const GeomAbs_Shape  ) const>(&BRepAdaptor_CompCurve::NbIntervals),
             R"#(Returns the number of intervals for continuity <S>. May be one if Continuity(me) >= <S>)#"  , py::arg("S")
          )
        .def("Intervals",
             (void (BRepAdaptor_CompCurve::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const) static_cast<void (BRepAdaptor_CompCurve::*)( NCollection_Array1<double> & ,   const GeomAbs_Shape  ) const>(&BRepAdaptor_CompCurve::Intervals),
             R"#(Stores in <T> the parameters bounding the intervals of continuity <S>.)#"  , py::arg("T"),  py::arg("S")
          )
        .def("Trim",
             (handle<Adaptor3d_Curve> (BRepAdaptor_CompCurve::*)(  const double ,   const double ,   const double  ) const) static_cast<handle<Adaptor3d_Curve> (BRepAdaptor_CompCurve::*)(  const double ,   const double ,   const double  ) const>(&BRepAdaptor_CompCurve::Trim),
             R"#(Returns a curve equivalent of <me> between parameters <First> and <Last>. <Tol> is used to test for 3d points confusion. If <First> >= <Last>)#"  , py::arg("First"),  py::arg("Last"),  py::arg("Tol")
          )
        .def("IsClosed",
             (bool (BRepAdaptor_CompCurve::*)() const) static_cast<bool (BRepAdaptor_CompCurve::*)() const>(&BRepAdaptor_CompCurve::IsClosed),
             R"#()#" 
          )
        .def("IsPeriodic",
             (bool (BRepAdaptor_CompCurve::*)() const) static_cast<bool (BRepAdaptor_CompCurve::*)() const>(&BRepAdaptor_CompCurve::IsPeriodic),
             R"#()#" 
          )
        .def("Period",
             (double (BRepAdaptor_CompCurve::*)() const) static_cast<double (BRepAdaptor_CompCurve::*)() const>(&BRepAdaptor_CompCurve::Period),
             R"#()#" 
          )
        .def("EvalD0",
             (gp_Pnt (BRepAdaptor_CompCurve::*)(  const double  ) const) static_cast<gp_Pnt (BRepAdaptor_CompCurve::*)(  const double  ) const>(&BRepAdaptor_CompCurve::EvalD0),
             R"#(Computes the point of parameter theU on the curve.)#"  , py::arg("theU")
          )
        .def("EvalD1",
             (Geom_Curve::ResD1 (BRepAdaptor_CompCurve::*)(  const double  ) const) static_cast<Geom_Curve::ResD1 (BRepAdaptor_CompCurve::*)(  const double  ) const>(&BRepAdaptor_CompCurve::EvalD1),
             R"#(Computes the point of parameter theU on the curve with its first derivative. Raised if the continuity of the current interval is not C1.)#"  , py::arg("theU")
          )
        .def("EvalD2",
             (Geom_Curve::ResD2 (BRepAdaptor_CompCurve::*)(  const double  ) const) static_cast<Geom_Curve::ResD2 (BRepAdaptor_CompCurve::*)(  const double  ) const>(&BRepAdaptor_CompCurve::EvalD2),
             R"#(Returns the point and the first and second derivatives at parameter theU. Raised if the continuity of the current interval is not C2.)#"  , py::arg("theU")
          )
        .def("EvalD3",
             (Geom_Curve::ResD3 (BRepAdaptor_CompCurve::*)(  const double  ) const) static_cast<Geom_Curve::ResD3 (BRepAdaptor_CompCurve::*)(  const double  ) const>(&BRepAdaptor_CompCurve::EvalD3),
             R"#(Returns the point and the first, second and third derivatives at parameter theU. Raised if the continuity of the current interval is not C3.)#"  , py::arg("theU")
          )
        .def("EvalDN",
             (gp_Vec (BRepAdaptor_CompCurve::*)(  const double ,   const int  ) const) static_cast<gp_Vec (BRepAdaptor_CompCurve::*)(  const double ,   const int  ) const>(&BRepAdaptor_CompCurve::EvalDN),
             R"#(Returns the derivative of order theN at parameter theU. Raised if the continuity of the current interval is not CN. Raised if theN < 1.)#"  , py::arg("theU"),  py::arg("theN")
          )
        .def("Resolution",
             (double (BRepAdaptor_CompCurve::*)(  const double  ) const) static_cast<double (BRepAdaptor_CompCurve::*)(  const double  ) const>(&BRepAdaptor_CompCurve::Resolution),
             R"#(returns the parametric resolution)#"  , py::arg("R3d")
          )
        .def("GetType",
             (GeomAbs_CurveType (BRepAdaptor_CompCurve::*)() const) static_cast<GeomAbs_CurveType (BRepAdaptor_CompCurve::*)() const>(&BRepAdaptor_CompCurve::GetType),
             R"#()#" 
          )
        .def("Line",
             (gp_Lin (BRepAdaptor_CompCurve::*)() const) static_cast<gp_Lin (BRepAdaptor_CompCurve::*)() const>(&BRepAdaptor_CompCurve::Line),
             R"#()#" 
          )
        .def("Circle",
             (gp_Circ (BRepAdaptor_CompCurve::*)() const) static_cast<gp_Circ (BRepAdaptor_CompCurve::*)() const>(&BRepAdaptor_CompCurve::Circle),
             R"#()#" 
          )
        .def("Ellipse",
             (gp_Elips (BRepAdaptor_CompCurve::*)() const) static_cast<gp_Elips (BRepAdaptor_CompCurve::*)() const>(&BRepAdaptor_CompCurve::Ellipse),
             R"#()#" 
          )
        .def("Hyperbola",
             (gp_Hypr (BRepAdaptor_CompCurve::*)() const) static_cast<gp_Hypr (BRepAdaptor_CompCurve::*)() const>(&BRepAdaptor_CompCurve::Hyperbola),
             R"#()#" 
          )
        .def("Parabola",
             (gp_Parab (BRepAdaptor_CompCurve::*)() const) static_cast<gp_Parab (BRepAdaptor_CompCurve::*)() const>(&BRepAdaptor_CompCurve::Parabola),
             R"#()#" 
          )
        .def("Degree",
             (int (BRepAdaptor_CompCurve::*)() const) static_cast<int (BRepAdaptor_CompCurve::*)() const>(&BRepAdaptor_CompCurve::Degree),
             R"#()#" 
          )
        .def("IsRational",
             (bool (BRepAdaptor_CompCurve::*)() const) static_cast<bool (BRepAdaptor_CompCurve::*)() const>(&BRepAdaptor_CompCurve::IsRational),
             R"#()#" 
          )
        .def("NbPoles",
             (int (BRepAdaptor_CompCurve::*)() const) static_cast<int (BRepAdaptor_CompCurve::*)() const>(&BRepAdaptor_CompCurve::NbPoles),
             R"#()#" 
          )
        .def("NbKnots",
             (int (BRepAdaptor_CompCurve::*)() const) static_cast<int (BRepAdaptor_CompCurve::*)() const>(&BRepAdaptor_CompCurve::NbKnots),
             R"#()#" 
          )
        .def("Bezier",
             (handle<Geom_BezierCurve> (BRepAdaptor_CompCurve::*)() const) static_cast<handle<Geom_BezierCurve> (BRepAdaptor_CompCurve::*)() const>(&BRepAdaptor_CompCurve::Bezier),
             R"#()#" 
          )
        .def("BSpline",
             (handle<Geom_BSplineCurve> (BRepAdaptor_CompCurve::*)() const) static_cast<handle<Geom_BSplineCurve> (BRepAdaptor_CompCurve::*)() const>(&BRepAdaptor_CompCurve::BSpline),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
        .def("Edge",
             []( BRepAdaptor_CompCurve &self ,  const double U,TopoDS_Edge & E ){
                 double  UonE;

                 self.Edge(U,E,UonE);
                 return std::make_tuple(UonE); },
             R"#(returns an edge and one parameter on them corresponding to the parameter U.)#"  , py::arg("U"),  py::arg("E")
          )
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepAdaptor_CompCurve::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepAdaptor_CompCurve::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepAdaptor_CompCurve::*)() const) static_cast< const handle<Standard_Type> & (BRepAdaptor_CompCurve::*)() const>(&BRepAdaptor_CompCurve::DynamicType),
             R"#()#"
             
         )
       .def("Wire",
             ( const TopoDS_Wire & (BRepAdaptor_CompCurve::*)() const) static_cast< const TopoDS_Wire & (BRepAdaptor_CompCurve::*)() const>(&BRepAdaptor_CompCurve::Wire),
             R"#(Returns the wire.)#"
             
         )
;

    // Class BRepAdaptor_Curve from ./opencascade/BRepAdaptor_Curve.hxx
    klass = m.attr("BRepAdaptor_Curve");


    // nested enums

    static_cast<py::class_<BRepAdaptor_Curve ,opencascade::handle<BRepAdaptor_Curve>  , GeomAdaptor_TransformedCurve >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const TopoDS_Edge & >()  , py::arg("E") )
        .def(py::init<  const TopoDS_Edge &, const TopoDS_Face & >()  , py::arg("E"),  py::arg("F") )
    // custom constructors
    // methods
        .def("ShallowCopy",
             (handle<Adaptor3d_Curve> (BRepAdaptor_Curve::*)() const) static_cast<handle<Adaptor3d_Curve> (BRepAdaptor_Curve::*)() const>(&BRepAdaptor_Curve::ShallowCopy),
             R"#(Shallow copy of adaptor)#" 
          )
        .def("Reset",
             (void (BRepAdaptor_Curve::*)() ) static_cast<void (BRepAdaptor_Curve::*)() >(&BRepAdaptor_Curve::Reset),
             R"#(Reset currently loaded curve (undone Load()).)#" 
          )
        .def("Initialize",
             (void (BRepAdaptor_Curve::*)(  const TopoDS_Edge &  ) ) static_cast<void (BRepAdaptor_Curve::*)(  const TopoDS_Edge &  ) >(&BRepAdaptor_Curve::Initialize),
             R"#(Sets the Curve <me> to access the geometry of edge <E>.)#"  , py::arg("E")
          )
        .def("Initialize",
             (void (BRepAdaptor_Curve::*)(  const TopoDS_Edge & ,   const TopoDS_Face &  ) ) static_cast<void (BRepAdaptor_Curve::*)(  const TopoDS_Edge & ,   const TopoDS_Face &  ) >(&BRepAdaptor_Curve::Initialize),
             R"#(Sets the Curve <me> to access the geometry of edge <E>. The geometry will be computed using the parametric curve of <E> on the face <F>. An Error is raised if the edge does not have a pcurve on the face.)#"  , py::arg("E"),  py::arg("F")
          )
        .def("Tolerance",
             (double (BRepAdaptor_Curve::*)() const) static_cast<double (BRepAdaptor_Curve::*)() const>(&BRepAdaptor_Curve::Tolerance),
             R"#(Returns the edge tolerance.)#" 
          )
        .def("Trim",
             (handle<Adaptor3d_Curve> (BRepAdaptor_Curve::*)(  const double ,   const double ,   const double  ) const) static_cast<handle<Adaptor3d_Curve> (BRepAdaptor_Curve::*)(  const double ,   const double ,   const double  ) const>(&BRepAdaptor_Curve::Trim),
             R"#(Returns a curve equivalent of <me> between parameters <First> and <Last>. <Tol> is used to test for 3d points confusion.)#"  , py::arg("First"),  py::arg("Last"),  py::arg("Tol")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepAdaptor_Curve::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepAdaptor_Curve::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepAdaptor_Curve::*)() const) static_cast< const handle<Standard_Type> & (BRepAdaptor_Curve::*)() const>(&BRepAdaptor_Curve::DynamicType),
             R"#()#"
             
         )
       .def("Edge",
             ( const TopoDS_Edge & (BRepAdaptor_Curve::*)() const) static_cast< const TopoDS_Edge & (BRepAdaptor_Curve::*)() const>(&BRepAdaptor_Curve::Edge),
             R"#(Returns the edge.)#"
             
         )
;

    // Class BRepAdaptor_Curve2d from ./opencascade/BRepAdaptor_Curve2d.hxx
    klass = m.attr("BRepAdaptor_Curve2d");


    // nested enums

    static_cast<py::class_<BRepAdaptor_Curve2d ,opencascade::handle<BRepAdaptor_Curve2d>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const TopoDS_Edge &, const TopoDS_Face & >()  , py::arg("E"),  py::arg("F") )
    // custom constructors
    // methods
        .def("ShallowCopy",
             (handle<Adaptor2d_Curve2d> (BRepAdaptor_Curve2d::*)() const) static_cast<handle<Adaptor2d_Curve2d> (BRepAdaptor_Curve2d::*)() const>(&BRepAdaptor_Curve2d::ShallowCopy),
             R"#(Shallow copy of adaptor)#" 
          )
        .def("Initialize",
             (void (BRepAdaptor_Curve2d::*)(  const TopoDS_Edge & ,   const TopoDS_Face &  ) ) static_cast<void (BRepAdaptor_Curve2d::*)(  const TopoDS_Edge & ,   const TopoDS_Face &  ) >(&BRepAdaptor_Curve2d::Initialize),
             R"#(Initialize with the pcurve of <E> on <F>.)#"  , py::arg("E"),  py::arg("F")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepAdaptor_Curve2d::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepAdaptor_Curve2d::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepAdaptor_Curve2d::*)() const) static_cast< const handle<Standard_Type> & (BRepAdaptor_Curve2d::*)() const>(&BRepAdaptor_Curve2d::DynamicType),
             R"#()#"
             
         )
       .def("Edge",
             ( const TopoDS_Edge & (BRepAdaptor_Curve2d::*)() const) static_cast< const TopoDS_Edge & (BRepAdaptor_Curve2d::*)() const>(&BRepAdaptor_Curve2d::Edge),
             R"#(Returns the Edge.)#"
             
         )
       .def("Face",
             ( const TopoDS_Face & (BRepAdaptor_Curve2d::*)() const) static_cast< const TopoDS_Face & (BRepAdaptor_Curve2d::*)() const>(&BRepAdaptor_Curve2d::Face),
             R"#(Returns the Face.)#"
             
         )
;

    // Class BRepAdaptor_Surface from ./opencascade/BRepAdaptor_Surface.hxx
    klass = m.attr("BRepAdaptor_Surface");


    // nested enums

    static_cast<py::class_<BRepAdaptor_Surface ,opencascade::handle<BRepAdaptor_Surface>  , GeomAdaptor_TransformedSurface >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const TopoDS_Face &, const bool >()  , py::arg("F"),  py::arg("R")=static_cast< const bool>(true) )
    // custom constructors
    // methods
        .def("ShallowCopy",
             (handle<Adaptor3d_Surface> (BRepAdaptor_Surface::*)() const) static_cast<handle<Adaptor3d_Surface> (BRepAdaptor_Surface::*)() const>(&BRepAdaptor_Surface::ShallowCopy),
             R"#(Shallow copy of adaptor.)#" 
          )
        .def("Initialize",
             (void (BRepAdaptor_Surface::*)(  const TopoDS_Face & ,   const bool  ) ) static_cast<void (BRepAdaptor_Surface::*)(  const TopoDS_Face & ,   const bool  ) >(&BRepAdaptor_Surface::Initialize),
             R"#(Sets the surface to the geometry of <F>.)#"  , py::arg("F"),  py::arg("Restriction")=static_cast< const bool>(true)
          )
        .def("Tolerance",
             (double (BRepAdaptor_Surface::*)() const) static_cast<double (BRepAdaptor_Surface::*)() const>(&BRepAdaptor_Surface::Tolerance),
             R"#(Returns the face tolerance.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BRepAdaptor_Surface::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BRepAdaptor_Surface::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BRepAdaptor_Surface::*)() const) static_cast< const handle<Standard_Type> & (BRepAdaptor_Surface::*)() const>(&BRepAdaptor_Surface::DynamicType),
             R"#()#"
             
         )
       .def("Face",
             ( const TopoDS_Face & (BRepAdaptor_Surface::*)() const) static_cast< const TopoDS_Face & (BRepAdaptor_Surface::*)() const>(&BRepAdaptor_Surface::Face),
             R"#(Returns the face.)#"
             
         )
;

// functions

// ./opencascade/BRepAdaptor_CompCurve.hxx
// ./opencascade/BRepAdaptor_Curve.hxx
// ./opencascade/BRepAdaptor_Curve2d.hxx
// ./opencascade/BRepAdaptor_Surface.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
