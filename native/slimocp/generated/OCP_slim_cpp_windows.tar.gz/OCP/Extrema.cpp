
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Extrema_ExtElC.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Extrema_ExtElC2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Lin.hxx>
#include <gp_Circ.hxx>
#include <gp_Elips.hxx>
#include <gp_Hypr.hxx>
#include <gp_Parab.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Lin2d.hxx>
#include <gp_Circ2d.hxx>
#include <gp_Elips2d.hxx>
#include <gp_Hypr2d.hxx>
#include <gp_Parab2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Lin.hxx>
#include <gp_Pln.hxx>
#include <gp_Cylinder.hxx>
#include <gp_Cone.hxx>
#include <gp_Sphere.hxx>
#include <gp_Torus.hxx>
#include <gp_Circ.hxx>
#include <gp_Hypr.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Pln.hxx>
#include <gp_Sphere.hxx>
#include <gp_Cylinder.hxx>
#include <gp_Cone.hxx>
#include <gp_Torus.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Lin.hxx>
#include <gp_Circ.hxx>
#include <gp_Elips.hxx>
#include <gp_Hypr.hxx>
#include <gp_Parab.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Lin2d.hxx>
#include <gp_Circ2d.hxx>
#include <gp_Elips2d.hxx>
#include <gp_Hypr2d.hxx>
#include <gp_Parab2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Cylinder.hxx>
#include <gp_Pln.hxx>
#include <gp_Cone.hxx>
#include <gp_Torus.hxx>
#include <gp_Sphere.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Extrema_ExtPExtS.hxx>
#include <Extrema_ExtPRevS.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <Extrema_CCLocFOfLocECC.hxx>
#include <Extrema_CCLocFOfLocECC2d.hxx>
#include <Extrema_Curve2dTool.hxx>
#include <Extrema_CurveTool.hxx>
#include <Extrema_ECC.hxx>
#include <Extrema_ECC2d.hxx>
#include <Extrema_ElementType.hxx>
#include <Extrema_ELPCOfLocateExtPC.hxx>
#include <Extrema_ELPCOfLocateExtPC2d.hxx>
#include <Extrema_EPCOfELPCOfLocateExtPC.hxx>
#include <Extrema_EPCOfELPCOfLocateExtPC2d.hxx>
#include <Extrema_EPCOfExtPC.hxx>
#include <Extrema_EPCOfExtPC2d.hxx>
#include <Extrema_ExtAlgo.hxx>
#include <Extrema_ExtCC.hxx>
#include <Extrema_ExtCC2d.hxx>
#include <Extrema_ExtCS.hxx>
#include <Extrema_ExtElC.hxx>
#include <Extrema_ExtElC2d.hxx>
#include <Extrema_ExtElCS.hxx>
#include <Extrema_ExtElSS.hxx>
#include <Extrema_ExtFlag.hxx>
#include <Extrema_ExtPC.hxx>
#include <Extrema_ExtPC2d.hxx>
#include <Extrema_ExtPElC.hxx>
#include <Extrema_ExtPElC2d.hxx>
#include <Extrema_ExtPElS.hxx>
#include <Extrema_ExtPExtS.hxx>
#include <Extrema_ExtPRevS.hxx>
#include <Extrema_ExtPS.hxx>
#include <Extrema_ExtSS.hxx>
#include <Extrema_FuncExtCS.hxx>
#include <Extrema_FuncExtSS.hxx>
#include <Extrema_FuncPSDist.hxx>
#include <Extrema_FuncPSNorm.hxx>
#include <Extrema_GCurveLocator.hxx>
#include <Extrema_GenExtCS.hxx>
#include <Extrema_GenExtPS.hxx>
#include <Extrema_GenExtSS.hxx>
#include <Extrema_GenLocateExtCC.hxx>
#include <Extrema_GenLocateExtCS.hxx>
#include <Extrema_GenLocateExtPC.hxx>
#include <Extrema_GenLocateExtPS.hxx>
#include <Extrema_GenLocateExtSS.hxx>
#include <Extrema_GFuncExtCC.hxx>
#include <Extrema_GFuncExtPC.hxx>
#include <Extrema_GGenExtPC.hxx>
#include <Extrema_GGExtPC.hxx>
#include <Extrema_GlobOptFuncCC.hxx>
#include <Extrema_GlobOptFuncConicS.hxx>
#include <Extrema_GlobOptFuncCQuadric.hxx>
#include <Extrema_GlobOptFuncCS.hxx>
#include <Extrema_GLocateExtPC.hxx>
#include <Extrema_LocateExtCC.hxx>
#include <Extrema_LocateExtCC2d.hxx>
#include <Extrema_LocateExtPC.hxx>
#include <Extrema_LocateExtPC2d.hxx>
#include <Extrema_LocECC.hxx>
#include <Extrema_LocECC2d.hxx>
#include <Extrema_LocEPCOfLocateExtPC.hxx>
#include <Extrema_LocEPCOfLocateExtPC2d.hxx>
#include <Extrema_PCFOfEPCOfELPCOfLocateExtPC.hxx>
#include <Extrema_PCFOfEPCOfELPCOfLocateExtPC2d.hxx>
#include <Extrema_PCFOfEPCOfExtPC.hxx>
#include <Extrema_PCFOfEPCOfExtPC2d.hxx>
#include <Extrema_PCLocFOfLocEPCOfLocateExtPC.hxx>
#include <Extrema_PCLocFOfLocEPCOfLocateExtPC2d.hxx>
#include <Extrema_POnCurv.hxx>
#include <Extrema_POnCurv2d.hxx>
#include <Extrema_POnSurf.hxx>
#include <Extrema_POnSurfParams.hxx>

// template related includes

// ./opencascade/Extrema_CCLocFOfLocECC.hxx
#include "Extrema_tmpl.hxx"

// ./opencascade/Extrema_CCLocFOfLocECC2d.hxx
#include "Extrema_tmpl.hxx"

// ./opencascade/Extrema_EPCOfExtPC.hxx
#include "Extrema_tmpl.hxx"

// ./opencascade/Extrema_EPCOfExtPC2d.hxx
#include "Extrema_tmpl.hxx"

// ./opencascade/Extrema_ExtPC.hxx
#include "Extrema_tmpl.hxx"

// ./opencascade/Extrema_ExtPC2d.hxx
#include "Extrema_tmpl.hxx"

// ./opencascade/Extrema_FuncPSDist.hxx
#include "math_tmpl.hxx"

// ./opencascade/Extrema_LocECC.hxx
#include "Extrema_tmpl.hxx"

// ./opencascade/Extrema_LocECC2d.hxx
#include "Extrema_tmpl.hxx"

// ./opencascade/Extrema_LocEPCOfLocateExtPC.hxx
#include "Extrema_tmpl.hxx"

// ./opencascade/Extrema_LocEPCOfLocateExtPC2d.hxx
#include "Extrema_tmpl.hxx"

// ./opencascade/Extrema_LocateExtPC.hxx
#include "Extrema_tmpl.hxx"

// ./opencascade/Extrema_LocateExtPC2d.hxx
#include "Extrema_tmpl.hxx"

// ./opencascade/Extrema_PCFOfEPCOfELPCOfLocateExtPC.hxx
#include "Extrema_tmpl.hxx"

// ./opencascade/Extrema_PCFOfEPCOfELPCOfLocateExtPC2d.hxx
#include "Extrema_tmpl.hxx"


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_Extrema(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("Extrema"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes

// classes

    // Class Extrema_Curve2dTool from ./opencascade/Extrema_Curve2dTool.hxx
    klass = m.attr("Extrema_Curve2dTool");

    // default constructor
    register_default_constructor<Extrema_Curve2dTool , shared_ptr<Extrema_Curve2dTool>>(m,"Extrema_Curve2dTool");

    // nested enums

    static_cast<py::class_<Extrema_Curve2dTool , shared_ptr<Extrema_Curve2dTool>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("FirstParameter_s",
                    (double (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<double (*)(  const Adaptor2d_Curve2d &  ) >(&Extrema_Curve2dTool::FirstParameter),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("LastParameter_s",
                    (double (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<double (*)(  const Adaptor2d_Curve2d &  ) >(&Extrema_Curve2dTool::LastParameter),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("Continuity_s",
                    (GeomAbs_Shape (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<GeomAbs_Shape (*)(  const Adaptor2d_Curve2d &  ) >(&Extrema_Curve2dTool::Continuity),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("NbIntervals_s",
                    (int (*)(  const Adaptor2d_Curve2d & ,   const GeomAbs_Shape  ) ) static_cast<int (*)(  const Adaptor2d_Curve2d & ,   const GeomAbs_Shape  ) >(&Extrema_Curve2dTool::NbIntervals),
                    R"#(If necessary, breaks the curve in intervals of continuity <S>. And returns the number of intervals.)#"  , py::arg("theC"),  py::arg("theS")
          )
        .def_static("Intervals_s",
                    (void (*)(  const Adaptor2d_Curve2d & ,  NCollection_Array1<double> & ,   const GeomAbs_Shape  ) ) static_cast<void (*)(  const Adaptor2d_Curve2d & ,  NCollection_Array1<double> & ,   const GeomAbs_Shape  ) >(&Extrema_Curve2dTool::Intervals),
                    R"#(Stores in <T> the parameters bounding the intervals of continuity <S>.)#"  , py::arg("theC"),  py::arg("theT"),  py::arg("theS")
          )
        .def_static("DeflCurvIntervals_s",
                    (handle<NCollection_HArray1<double>> (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<handle<NCollection_HArray1<double>> (*)(  const Adaptor2d_Curve2d &  ) >(&Extrema_Curve2dTool::DeflCurvIntervals),
                    R"#(Returns the parameters bounding the intervals of subdivision of curve according to Curvature deflection. Value of deflection is defined in method.)#"  , py::arg("theC")
          )
        .def_static("IsClosed_s",
                    (bool (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<bool (*)(  const Adaptor2d_Curve2d &  ) >(&Extrema_Curve2dTool::IsClosed),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("IsPeriodic_s",
                    (bool (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<bool (*)(  const Adaptor2d_Curve2d &  ) >(&Extrema_Curve2dTool::IsPeriodic),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("Period_s",
                    (double (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<double (*)(  const Adaptor2d_Curve2d &  ) >(&Extrema_Curve2dTool::Period),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("Value_s",
                    (gp_Pnt2d (*)(  const Adaptor2d_Curve2d & ,   const double  ) ) static_cast<gp_Pnt2d (*)(  const Adaptor2d_Curve2d & ,   const double  ) >(&Extrema_Curve2dTool::Value),
                    R"#(Computes the point of parameter U on the curve.)#"  , py::arg("theC"),  py::arg("theU")
          )
        .def_static("D0_s",
                    (void (*)(  const Adaptor2d_Curve2d & ,   const double ,  gp_Pnt2d &  ) ) static_cast<void (*)(  const Adaptor2d_Curve2d & ,   const double ,  gp_Pnt2d &  ) >(&Extrema_Curve2dTool::D0),
                    R"#(Computes the point of parameter U on the curve.)#"  , py::arg("theC"),  py::arg("theU"),  py::arg("theP")
          )
        .def_static("D1_s",
                    (void (*)(  const Adaptor2d_Curve2d & ,   const double ,  gp_Pnt2d & ,  gp_Vec2d &  ) ) static_cast<void (*)(  const Adaptor2d_Curve2d & ,   const double ,  gp_Pnt2d & ,  gp_Vec2d &  ) >(&Extrema_Curve2dTool::D1),
                    R"#(Computes the point of parameter U on the curve with its first derivative.)#"  , py::arg("theC"),  py::arg("theU"),  py::arg("theP"),  py::arg("theV")
          )
        .def_static("D2_s",
                    (void (*)(  const Adaptor2d_Curve2d & ,   const double ,  gp_Pnt2d & ,  gp_Vec2d & ,  gp_Vec2d &  ) ) static_cast<void (*)(  const Adaptor2d_Curve2d & ,   const double ,  gp_Pnt2d & ,  gp_Vec2d & ,  gp_Vec2d &  ) >(&Extrema_Curve2dTool::D2),
                    R"#(Returns the point P of parameter U, the first and second derivatives V1 and V2.)#"  , py::arg("theC"),  py::arg("theU"),  py::arg("theP"),  py::arg("theV1"),  py::arg("theV2")
          )
        .def_static("D3_s",
                    (void (*)(  const Adaptor2d_Curve2d & ,   const double ,  gp_Pnt2d & ,  gp_Vec2d & ,  gp_Vec2d & ,  gp_Vec2d &  ) ) static_cast<void (*)(  const Adaptor2d_Curve2d & ,   const double ,  gp_Pnt2d & ,  gp_Vec2d & ,  gp_Vec2d & ,  gp_Vec2d &  ) >(&Extrema_Curve2dTool::D3),
                    R"#(Returns the point P of parameter U, the first, the second and the third derivative.)#"  , py::arg("theC"),  py::arg("theU"),  py::arg("theP"),  py::arg("theV1"),  py::arg("theV2"),  py::arg("theV3")
          )
        .def_static("DN_s",
                    (gp_Vec2d (*)(  const Adaptor2d_Curve2d & ,   const double ,   const int  ) ) static_cast<gp_Vec2d (*)(  const Adaptor2d_Curve2d & ,   const double ,   const int  ) >(&Extrema_Curve2dTool::DN),
                    R"#(The returned vector gives the value of the derivative for the order of derivation N.)#"  , py::arg("theC"),  py::arg("theU"),  py::arg("theN")
          )
        .def_static("Resolution_s",
                    (double (*)(  const Adaptor2d_Curve2d & ,   const double  ) ) static_cast<double (*)(  const Adaptor2d_Curve2d & ,   const double  ) >(&Extrema_Curve2dTool::Resolution),
                    R"#(Returns the parametric resolution corresponding to the real space resolution <R3d>.)#"  , py::arg("theC"),  py::arg("theR3d")
          )
        .def_static("GetType_s",
                    (GeomAbs_CurveType (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<GeomAbs_CurveType (*)(  const Adaptor2d_Curve2d &  ) >(&Extrema_Curve2dTool::GetType),
                    R"#(Returns the type of the curve in the current interval: Line, Circle, Ellipse, Hyperbola, Parabola, BezierCurve, BSplineCurve, OtherCurve.)#"  , py::arg("theC")
          )
        .def_static("Line_s",
                    (gp_Lin2d (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<gp_Lin2d (*)(  const Adaptor2d_Curve2d &  ) >(&Extrema_Curve2dTool::Line),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("Circle_s",
                    (gp_Circ2d (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<gp_Circ2d (*)(  const Adaptor2d_Curve2d &  ) >(&Extrema_Curve2dTool::Circle),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("Ellipse_s",
                    (gp_Elips2d (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<gp_Elips2d (*)(  const Adaptor2d_Curve2d &  ) >(&Extrema_Curve2dTool::Ellipse),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("Hyperbola_s",
                    (gp_Hypr2d (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<gp_Hypr2d (*)(  const Adaptor2d_Curve2d &  ) >(&Extrema_Curve2dTool::Hyperbola),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("Parabola_s",
                    (gp_Parab2d (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<gp_Parab2d (*)(  const Adaptor2d_Curve2d &  ) >(&Extrema_Curve2dTool::Parabola),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("Degree_s",
                    (int (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<int (*)(  const Adaptor2d_Curve2d &  ) >(&Extrema_Curve2dTool::Degree),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("IsRational_s",
                    (bool (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<bool (*)(  const Adaptor2d_Curve2d &  ) >(&Extrema_Curve2dTool::IsRational),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("NbPoles_s",
                    (int (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<int (*)(  const Adaptor2d_Curve2d &  ) >(&Extrema_Curve2dTool::NbPoles),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("NbKnots_s",
                    (int (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<int (*)(  const Adaptor2d_Curve2d &  ) >(&Extrema_Curve2dTool::NbKnots),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("Bezier_s",
                    (handle<Geom2d_BezierCurve> (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<handle<Geom2d_BezierCurve> (*)(  const Adaptor2d_Curve2d &  ) >(&Extrema_Curve2dTool::Bezier),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("BSpline_s",
                    (handle<Geom2d_BSplineCurve> (*)(  const Adaptor2d_Curve2d &  ) ) static_cast<handle<Geom2d_BSplineCurve> (*)(  const Adaptor2d_Curve2d &  ) >(&Extrema_Curve2dTool::BSpline),
                    R"#()#"  , py::arg("theC")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Extrema_CurveTool from ./opencascade/Extrema_CurveTool.hxx
    klass = m.attr("Extrema_CurveTool");

    // default constructor
    register_default_constructor<Extrema_CurveTool , shared_ptr<Extrema_CurveTool>>(m,"Extrema_CurveTool");

    // nested enums

    static_cast<py::class_<Extrema_CurveTool , shared_ptr<Extrema_CurveTool>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("FirstParameter_s",
                    (double (*)(  const Adaptor3d_Curve &  ) ) static_cast<double (*)(  const Adaptor3d_Curve &  ) >(&Extrema_CurveTool::FirstParameter),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("LastParameter_s",
                    (double (*)(  const Adaptor3d_Curve &  ) ) static_cast<double (*)(  const Adaptor3d_Curve &  ) >(&Extrema_CurveTool::LastParameter),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("Continuity_s",
                    (GeomAbs_Shape (*)(  const Adaptor3d_Curve &  ) ) static_cast<GeomAbs_Shape (*)(  const Adaptor3d_Curve &  ) >(&Extrema_CurveTool::Continuity),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("NbIntervals_s",
                    (int (*)( Adaptor3d_Curve & ,   const GeomAbs_Shape  ) ) static_cast<int (*)( Adaptor3d_Curve & ,   const GeomAbs_Shape  ) >(&Extrema_CurveTool::NbIntervals),
                    R"#(Returns the number of intervals for continuity <S>. May be one if Continuity(me) >= <S>)#"  , py::arg("theC"),  py::arg("theS")
          )
        .def_static("Intervals_s",
                    (void (*)( Adaptor3d_Curve & ,  NCollection_Array1<double> & ,   const GeomAbs_Shape  ) ) static_cast<void (*)( Adaptor3d_Curve & ,  NCollection_Array1<double> & ,   const GeomAbs_Shape  ) >(&Extrema_CurveTool::Intervals),
                    R"#(Stores in <T> the parameters bounding the intervals of continuity <S>. The array must provide enough room to accommodate for the parameters. i.e. T.Length() > NbIntervals())#"  , py::arg("theC"),  py::arg("theT"),  py::arg("theS")
          )
        .def_static("DeflCurvIntervals_s",
                    (handle<NCollection_HArray1<double>> (*)(  const Adaptor3d_Curve &  ) ) static_cast<handle<NCollection_HArray1<double>> (*)(  const Adaptor3d_Curve &  ) >(&Extrema_CurveTool::DeflCurvIntervals),
                    R"#(Returns the parameters bounding the intervals of subdivision of curve according to Curvature deflection. Value of deflection is defined in method.)#"  , py::arg("theC")
          )
        .def_static("IsPeriodic_s",
                    (bool (*)(  const Adaptor3d_Curve &  ) ) static_cast<bool (*)(  const Adaptor3d_Curve &  ) >(&Extrema_CurveTool::IsPeriodic),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("Period_s",
                    (double (*)(  const Adaptor3d_Curve &  ) ) static_cast<double (*)(  const Adaptor3d_Curve &  ) >(&Extrema_CurveTool::Period),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("Resolution_s",
                    (double (*)(  const Adaptor3d_Curve & ,   const double  ) ) static_cast<double (*)(  const Adaptor3d_Curve & ,   const double  ) >(&Extrema_CurveTool::Resolution),
                    R"#()#"  , py::arg("theC"),  py::arg("theR3d")
          )
        .def_static("GetType_s",
                    (GeomAbs_CurveType (*)(  const Adaptor3d_Curve &  ) ) static_cast<GeomAbs_CurveType (*)(  const Adaptor3d_Curve &  ) >(&Extrema_CurveTool::GetType),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("Value_s",
                    (gp_Pnt (*)(  const Adaptor3d_Curve & ,   const double  ) ) static_cast<gp_Pnt (*)(  const Adaptor3d_Curve & ,   const double  ) >(&Extrema_CurveTool::Value),
                    R"#()#"  , py::arg("theC"),  py::arg("theU")
          )
        .def_static("D0_s",
                    (void (*)(  const Adaptor3d_Curve & ,   const double ,  gp_Pnt &  ) ) static_cast<void (*)(  const Adaptor3d_Curve & ,   const double ,  gp_Pnt &  ) >(&Extrema_CurveTool::D0),
                    R"#()#"  , py::arg("theC"),  py::arg("theU"),  py::arg("theP")
          )
        .def_static("D1_s",
                    (void (*)(  const Adaptor3d_Curve & ,   const double ,  gp_Pnt & ,  gp_Vec &  ) ) static_cast<void (*)(  const Adaptor3d_Curve & ,   const double ,  gp_Pnt & ,  gp_Vec &  ) >(&Extrema_CurveTool::D1),
                    R"#()#"  , py::arg("theC"),  py::arg("theU"),  py::arg("theP"),  py::arg("theV")
          )
        .def_static("D2_s",
                    (void (*)(  const Adaptor3d_Curve & ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec &  ) ) static_cast<void (*)(  const Adaptor3d_Curve & ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec &  ) >(&Extrema_CurveTool::D2),
                    R"#()#"  , py::arg("theC"),  py::arg("theU"),  py::arg("theP"),  py::arg("theV1"),  py::arg("theV2")
          )
        .def_static("D3_s",
                    (void (*)(  const Adaptor3d_Curve & ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) ) static_cast<void (*)(  const Adaptor3d_Curve & ,   const double ,  gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) >(&Extrema_CurveTool::D3),
                    R"#()#"  , py::arg("theC"),  py::arg("theU"),  py::arg("theP"),  py::arg("theV1"),  py::arg("theV2"),  py::arg("theV3")
          )
        .def_static("DN_s",
                    (gp_Vec (*)(  const Adaptor3d_Curve & ,   const double ,   const int  ) ) static_cast<gp_Vec (*)(  const Adaptor3d_Curve & ,   const double ,   const int  ) >(&Extrema_CurveTool::DN),
                    R"#()#"  , py::arg("theC"),  py::arg("theU"),  py::arg("theN")
          )
        .def_static("Line_s",
                    (gp_Lin (*)(  const Adaptor3d_Curve &  ) ) static_cast<gp_Lin (*)(  const Adaptor3d_Curve &  ) >(&Extrema_CurveTool::Line),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("Circle_s",
                    (gp_Circ (*)(  const Adaptor3d_Curve &  ) ) static_cast<gp_Circ (*)(  const Adaptor3d_Curve &  ) >(&Extrema_CurveTool::Circle),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("Ellipse_s",
                    (gp_Elips (*)(  const Adaptor3d_Curve &  ) ) static_cast<gp_Elips (*)(  const Adaptor3d_Curve &  ) >(&Extrema_CurveTool::Ellipse),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("Hyperbola_s",
                    (gp_Hypr (*)(  const Adaptor3d_Curve &  ) ) static_cast<gp_Hypr (*)(  const Adaptor3d_Curve &  ) >(&Extrema_CurveTool::Hyperbola),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("Parabola_s",
                    (gp_Parab (*)(  const Adaptor3d_Curve &  ) ) static_cast<gp_Parab (*)(  const Adaptor3d_Curve &  ) >(&Extrema_CurveTool::Parabola),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("Degree_s",
                    (int (*)(  const Adaptor3d_Curve &  ) ) static_cast<int (*)(  const Adaptor3d_Curve &  ) >(&Extrema_CurveTool::Degree),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("IsRational_s",
                    (bool (*)(  const Adaptor3d_Curve &  ) ) static_cast<bool (*)(  const Adaptor3d_Curve &  ) >(&Extrema_CurveTool::IsRational),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("NbPoles_s",
                    (int (*)(  const Adaptor3d_Curve &  ) ) static_cast<int (*)(  const Adaptor3d_Curve &  ) >(&Extrema_CurveTool::NbPoles),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("NbKnots_s",
                    (int (*)(  const Adaptor3d_Curve &  ) ) static_cast<int (*)(  const Adaptor3d_Curve &  ) >(&Extrema_CurveTool::NbKnots),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("Bezier_s",
                    (handle<Geom_BezierCurve> (*)(  const Adaptor3d_Curve &  ) ) static_cast<handle<Geom_BezierCurve> (*)(  const Adaptor3d_Curve &  ) >(&Extrema_CurveTool::Bezier),
                    R"#()#"  , py::arg("theC")
          )
        .def_static("BSpline_s",
                    (handle<Geom_BSplineCurve> (*)(  const Adaptor3d_Curve &  ) ) static_cast<handle<Geom_BSplineCurve> (*)(  const Adaptor3d_Curve &  ) >(&Extrema_CurveTool::BSpline),
                    R"#()#"  , py::arg("theC")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Extrema_ExtCC from ./opencascade/Extrema_ExtCC.hxx
    klass = m.attr("Extrema_ExtCC");


    // nested enums

    static_cast<py::class_<Extrema_ExtCC , shared_ptr<Extrema_ExtCC>  >>(klass)
    // constructors
        .def(py::init<  const Adaptor3d_Curve &, const Adaptor3d_Curve &, const double, const double >()  , py::arg("C1"),  py::arg("C2"),  py::arg("TolC1")=static_cast< const double>(1.0e-10),  py::arg("TolC2")=static_cast< const double>(1.0e-10) )
        .def(py::init<  const Adaptor3d_Curve &, const Adaptor3d_Curve &, const double, const double, const double, const double, const double, const double >()  , py::arg("C1"),  py::arg("C2"),  py::arg("U1"),  py::arg("U2"),  py::arg("V1"),  py::arg("V2"),  py::arg("TolC1")=static_cast< const double>(1.0e-10),  py::arg("TolC2")=static_cast< const double>(1.0e-10) )
        .def(py::init<  const double, const double >()  , py::arg("TolC1")=static_cast< const double>(1.0e-10),  py::arg("TolC2")=static_cast< const double>(1.0e-10) )
    // custom constructors
    // methods
        .def("Initialize",
             (void (Extrema_ExtCC::*)(  const Adaptor3d_Curve & ,   const Adaptor3d_Curve & ,   const double ,   const double  ) ) static_cast<void (Extrema_ExtCC::*)(  const Adaptor3d_Curve & ,   const Adaptor3d_Curve & ,   const double ,   const double  ) >(&Extrema_ExtCC::Initialize),
             R"#(Initializes but does not perform algorithm.)#"  , py::arg("C1"),  py::arg("C2"),  py::arg("TolC1")=static_cast< const double>(1.0e-10),  py::arg("TolC2")=static_cast< const double>(1.0e-10)
          )
        .def("Initialize",
             (void (Extrema_ExtCC::*)(  const Adaptor3d_Curve & ,   const Adaptor3d_Curve & ,   const double ,   const double ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<void (Extrema_ExtCC::*)(  const Adaptor3d_Curve & ,   const Adaptor3d_Curve & ,   const double ,   const double ,   const double ,   const double ,   const double ,   const double  ) >(&Extrema_ExtCC::Initialize),
             R"#(Initializes but does not perform algorithm.)#"  , py::arg("C1"),  py::arg("C2"),  py::arg("U1"),  py::arg("U2"),  py::arg("V1"),  py::arg("V2"),  py::arg("TolC1")=static_cast< const double>(1.0e-10),  py::arg("TolC2")=static_cast< const double>(1.0e-10)
          )
        .def("SetCurve",
             (void (Extrema_ExtCC::*)(  const int ,   const Adaptor3d_Curve &  ) ) static_cast<void (Extrema_ExtCC::*)(  const int ,   const Adaptor3d_Curve &  ) >(&Extrema_ExtCC::SetCurve),
             R"#()#"  , py::arg("theRank"),  py::arg("C")
          )
        .def("SetCurve",
             (void (Extrema_ExtCC::*)(  const int ,   const Adaptor3d_Curve & ,   const double ,   const double  ) ) static_cast<void (Extrema_ExtCC::*)(  const int ,   const Adaptor3d_Curve & ,   const double ,   const double  ) >(&Extrema_ExtCC::SetCurve),
             R"#()#"  , py::arg("theRank"),  py::arg("C"),  py::arg("Uinf"),  py::arg("Usup")
          )
        .def("SetRange",
             (void (Extrema_ExtCC::*)(  const int ,   const double ,   const double  ) ) static_cast<void (Extrema_ExtCC::*)(  const int ,   const double ,   const double  ) >(&Extrema_ExtCC::SetRange),
             R"#()#"  , py::arg("theRank"),  py::arg("Uinf"),  py::arg("Usup")
          )
        .def("SetTolerance",
             (void (Extrema_ExtCC::*)(  const int ,   const double  ) ) static_cast<void (Extrema_ExtCC::*)(  const int ,   const double  ) >(&Extrema_ExtCC::SetTolerance),
             R"#()#"  , py::arg("theRank"),  py::arg("Tol")
          )
        .def("Perform",
             (void (Extrema_ExtCC::*)() ) static_cast<void (Extrema_ExtCC::*)() >(&Extrema_ExtCC::Perform),
             R"#()#" 
          )
        .def("IsDone",
             (bool (Extrema_ExtCC::*)() const) static_cast<bool (Extrema_ExtCC::*)() const>(&Extrema_ExtCC::IsDone),
             R"#(Returns True if the distances are found.)#" 
          )
        .def("NbExt",
             (int (Extrema_ExtCC::*)() const) static_cast<int (Extrema_ExtCC::*)() const>(&Extrema_ExtCC::NbExt),
             R"#(Returns the number of extremum distances.)#" 
          )
        .def("IsParallel",
             (bool (Extrema_ExtCC::*)() const) static_cast<bool (Extrema_ExtCC::*)() const>(&Extrema_ExtCC::IsParallel),
             R"#(Returns True if the two curves are parallel.)#" 
          )
        .def("SquareDistance",
             (double (Extrema_ExtCC::*)(  const int  ) const) static_cast<double (Extrema_ExtCC::*)(  const int  ) const>(&Extrema_ExtCC::SquareDistance),
             R"#(Returns the value of the Nth extremum square distance.)#"  , py::arg("N")=static_cast< const int>(1)
          )
        .def("Points",
             (void (Extrema_ExtCC::*)(  const int ,  Extrema_POnCurv & ,  Extrema_POnCurv &  ) const) static_cast<void (Extrema_ExtCC::*)(  const int ,  Extrema_POnCurv & ,  Extrema_POnCurv &  ) const>(&Extrema_ExtCC::Points),
             R"#(Returns the points of the Nth extremum distance. P1 is on the first curve, P2 on the second one.)#"  , py::arg("N"),  py::arg("P1"),  py::arg("P2")
          )
        .def("SetSingleSolutionFlag",
             (void (Extrema_ExtCC::*)(  const bool  ) ) static_cast<void (Extrema_ExtCC::*)(  const bool  ) >(&Extrema_ExtCC::SetSingleSolutionFlag),
             R"#(Set flag for single extrema computation. Works on parametric solver only.)#"  , py::arg("theSingleSolutionFlag")
          )
        .def("GetSingleSolutionFlag",
             (bool (Extrema_ExtCC::*)() const) static_cast<bool (Extrema_ExtCC::*)() const>(&Extrema_ExtCC::GetSingleSolutionFlag),
             R"#(Get flag for single extrema computation. Works on parametric solver only.)#" 
          )
    // methods using call by reference i.s.o. return
        .def("TrimmedSquareDistances",
             []( Extrema_ExtCC &self , gp_Pnt & P11,gp_Pnt & P12,gp_Pnt & P21,gp_Pnt & P22 ){
                 double  dist11;
                double  distP12;
                double  distP21;
                double  distP22;

                 self.TrimmedSquareDistances(dist11,distP12,distP21,distP22,P11,P12,P21,P22);
                 return std::make_tuple(dist11,distP12,distP21,distP22); },
             R"#(if the curve is a trimmed curve, dist11 is a square distance between the point on C1 of parameter FirstParameter and the point of parameter FirstParameter on C2.)#"  , py::arg("P11"),  py::arg("P12"),  py::arg("P21"),  py::arg("P22")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Extrema_ExtCC2d from ./opencascade/Extrema_ExtCC2d.hxx
    klass = m.attr("Extrema_ExtCC2d");


    // nested enums

    static_cast<py::class_<Extrema_ExtCC2d , shared_ptr<Extrema_ExtCC2d>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const Adaptor2d_Curve2d &, const Adaptor2d_Curve2d &, const double, const double >()  , py::arg("C1"),  py::arg("C2"),  py::arg("TolC1")=static_cast< const double>(1.0e-10),  py::arg("TolC2")=static_cast< const double>(1.0e-10) )
        .def(py::init<  const Adaptor2d_Curve2d &, const Adaptor2d_Curve2d &, const double, const double, const double, const double, const double, const double >()  , py::arg("C1"),  py::arg("C2"),  py::arg("U1"),  py::arg("U2"),  py::arg("V1"),  py::arg("V2"),  py::arg("TolC1")=static_cast< const double>(1.0e-10),  py::arg("TolC2")=static_cast< const double>(1.0e-10) )
    // custom constructors
    // methods
        .def("Initialize",
             (void (Extrema_ExtCC2d::*)(  const Adaptor2d_Curve2d & ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<void (Extrema_ExtCC2d::*)(  const Adaptor2d_Curve2d & ,   const double ,   const double ,   const double ,   const double  ) >(&Extrema_ExtCC2d::Initialize),
             R"#(initializes the fields.)#"  , py::arg("C2"),  py::arg("V1"),  py::arg("V2"),  py::arg("TolC1")=static_cast< const double>(1.0e-10),  py::arg("TolC2")=static_cast< const double>(1.0e-10)
          )
        .def("Perform",
             (void (Extrema_ExtCC2d::*)(  const Adaptor2d_Curve2d & ,   const double ,   const double  ) ) static_cast<void (Extrema_ExtCC2d::*)(  const Adaptor2d_Curve2d & ,   const double ,   const double  ) >(&Extrema_ExtCC2d::Perform),
             R"#()#"  , py::arg("C1"),  py::arg("U1"),  py::arg("U2")
          )
        .def("IsDone",
             (bool (Extrema_ExtCC2d::*)() const) static_cast<bool (Extrema_ExtCC2d::*)() const>(&Extrema_ExtCC2d::IsDone),
             R"#(Returns True if the distances are found.)#" 
          )
        .def("NbExt",
             (int (Extrema_ExtCC2d::*)() const) static_cast<int (Extrema_ExtCC2d::*)() const>(&Extrema_ExtCC2d::NbExt),
             R"#(Returns the number of extremum distances.)#" 
          )
        .def("IsParallel",
             (bool (Extrema_ExtCC2d::*)() const) static_cast<bool (Extrema_ExtCC2d::*)() const>(&Extrema_ExtCC2d::IsParallel),
             R"#(Returns True if the two curves are parallel.)#" 
          )
        .def("SquareDistance",
             (double (Extrema_ExtCC2d::*)(  const int  ) const) static_cast<double (Extrema_ExtCC2d::*)(  const int  ) const>(&Extrema_ExtCC2d::SquareDistance),
             R"#(Returns the value of the Nth extremum square distance.)#"  , py::arg("N")=static_cast< const int>(1)
          )
        .def("Points",
             (void (Extrema_ExtCC2d::*)(  const int ,  Extrema_POnCurv2d & ,  Extrema_POnCurv2d &  ) const) static_cast<void (Extrema_ExtCC2d::*)(  const int ,  Extrema_POnCurv2d & ,  Extrema_POnCurv2d &  ) const>(&Extrema_ExtCC2d::Points),
             R"#(Returns the points of the Nth extremum distance. P1 is on the first curve, P2 on the second one.)#"  , py::arg("N"),  py::arg("P1"),  py::arg("P2")
          )
        .def("SetSingleSolutionFlag",
             (void (Extrema_ExtCC2d::*)(  const bool  ) ) static_cast<void (Extrema_ExtCC2d::*)(  const bool  ) >(&Extrema_ExtCC2d::SetSingleSolutionFlag),
             R"#(Set flag for single extrema computation. Works on parametric solver only.)#"  , py::arg("theSingleSolutionFlag")
          )
        .def("GetSingleSolutionFlag",
             (bool (Extrema_ExtCC2d::*)() const) static_cast<bool (Extrema_ExtCC2d::*)() const>(&Extrema_ExtCC2d::GetSingleSolutionFlag),
             R"#(Get flag for single extrema computation. Works on parametric solver only.)#" 
          )
    // methods using call by reference i.s.o. return
        .def("TrimmedSquareDistances",
             []( Extrema_ExtCC2d &self , gp_Pnt2d & P11,gp_Pnt2d & P12,gp_Pnt2d & P21,gp_Pnt2d & P22 ){
                 double  dist11;
                double  distP12;
                double  distP21;
                double  distP22;

                 self.TrimmedSquareDistances(dist11,distP12,distP21,distP22,P11,P12,P21,P22);
                 return std::make_tuple(dist11,distP12,distP21,distP22); },
             R"#(if the curve is a trimmed curve, dist11 is a square distance between the point on C1 of parameter FirstParameter and the point of parameter FirstParameter on C2.)#"  , py::arg("P11"),  py::arg("P12"),  py::arg("P21"),  py::arg("P22")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Extrema_ExtCS from ./opencascade/Extrema_ExtCS.hxx
    klass = m.attr("Extrema_ExtCS");


    // nested enums

    static_cast<py::class_<Extrema_ExtCS , shared_ptr<Extrema_ExtCS>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const Adaptor3d_Curve &, const Adaptor3d_Surface &, const double, const double >()  , py::arg("C"),  py::arg("S"),  py::arg("TolC"),  py::arg("TolS") )
        .def(py::init<  const Adaptor3d_Curve &, const Adaptor3d_Surface &, const double, const double, const double, const double, const double, const double, const double, const double >()  , py::arg("C"),  py::arg("S"),  py::arg("UCinf"),  py::arg("UCsup"),  py::arg("Uinf"),  py::arg("Usup"),  py::arg("Vinf"),  py::arg("Vsup"),  py::arg("TolC"),  py::arg("TolS") )
    // custom constructors
    // methods
        .def("Initialize",
             (void (Extrema_ExtCS::*)(  const Adaptor3d_Surface & ,   const double ,   const double  ) ) static_cast<void (Extrema_ExtCS::*)(  const Adaptor3d_Surface & ,   const double ,   const double  ) >(&Extrema_ExtCS::Initialize),
             R"#(Initializes the fields of the algorithm.)#"  , py::arg("S"),  py::arg("TolC"),  py::arg("TolS")
          )
        .def("Initialize",
             (void (Extrema_ExtCS::*)(  const Adaptor3d_Surface & ,   const double ,   const double ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<void (Extrema_ExtCS::*)(  const Adaptor3d_Surface & ,   const double ,   const double ,   const double ,   const double ,   const double ,   const double  ) >(&Extrema_ExtCS::Initialize),
             R"#(Initializes the fields of the algorithm.)#"  , py::arg("S"),  py::arg("Uinf"),  py::arg("Usup"),  py::arg("Vinf"),  py::arg("Vsup"),  py::arg("TolC"),  py::arg("TolS")
          )
        .def("Perform",
             (void (Extrema_ExtCS::*)(  const Adaptor3d_Curve & ,   const double ,   const double  ) ) static_cast<void (Extrema_ExtCS::*)(  const Adaptor3d_Curve & ,   const double ,   const double  ) >(&Extrema_ExtCS::Perform),
             R"#(Computes the distances. An exception is raised if the fields have not been initialized.)#"  , py::arg("C"),  py::arg("Uinf"),  py::arg("Usup")
          )
        .def("IsDone",
             (bool (Extrema_ExtCS::*)() const) static_cast<bool (Extrema_ExtCS::*)() const>(&Extrema_ExtCS::IsDone),
             R"#(Returns True if the distances are found.)#" 
          )
        .def("IsParallel",
             (bool (Extrema_ExtCS::*)() const) static_cast<bool (Extrema_ExtCS::*)() const>(&Extrema_ExtCS::IsParallel),
             R"#(Returns True if the curve is on a parallel surface.)#" 
          )
        .def("NbExt",
             (int (Extrema_ExtCS::*)() const) static_cast<int (Extrema_ExtCS::*)() const>(&Extrema_ExtCS::NbExt),
             R"#(Returns the number of extremum distances.)#" 
          )
        .def("SquareDistance",
             (double (Extrema_ExtCS::*)(  const int  ) const) static_cast<double (Extrema_ExtCS::*)(  const int  ) const>(&Extrema_ExtCS::SquareDistance),
             R"#(Returns the value of the Nth resulting square distance.)#"  , py::arg("N")
          )
        .def("Points",
             (void (Extrema_ExtCS::*)(  const int ,  Extrema_POnCurv & ,  Extrema_POnSurf &  ) const) static_cast<void (Extrema_ExtCS::*)(  const int ,  Extrema_POnCurv & ,  Extrema_POnSurf &  ) const>(&Extrema_ExtCS::Points),
             R"#(Returns the point of the Nth resulting distance.)#"  , py::arg("N"),  py::arg("P1"),  py::arg("P2")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Extrema_ExtElC from ./opencascade/Extrema_ExtElC.hxx
    klass = m.attr("Extrema_ExtElC");


    // nested enums

    static_cast<py::class_<Extrema_ExtElC , shared_ptr<Extrema_ExtElC>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const gp_Circ &, const gp_Circ & >()  , py::arg("C1"),  py::arg("C2") )
        .def(py::init<  const gp_Lin &, const gp_Circ &, const double >()  , py::arg("C1"),  py::arg("C2"),  py::arg("Tol") )
        .def(py::init<  const gp_Lin &, const gp_Elips & >()  , py::arg("C1"),  py::arg("C2") )
        .def(py::init<  const gp_Lin &, const gp_Hypr & >()  , py::arg("C1"),  py::arg("C2") )
        .def(py::init<  const gp_Lin &, const gp_Lin &, const double >()  , py::arg("C1"),  py::arg("C2"),  py::arg("AngTol") )
        .def(py::init<  const gp_Lin &, const gp_Parab & >()  , py::arg("C1"),  py::arg("C2") )
    // custom constructors
    // methods
        .def("IsDone",
             (bool (Extrema_ExtElC::*)() const) static_cast<bool (Extrema_ExtElC::*)() const>(&Extrema_ExtElC::IsDone),
             R"#(Returns True if the distances are found.)#" 
          )
        .def("IsParallel",
             (bool (Extrema_ExtElC::*)() const) static_cast<bool (Extrema_ExtElC::*)() const>(&Extrema_ExtElC::IsParallel),
             R"#(Returns True if the two curves are parallel.)#" 
          )
        .def("NbExt",
             (int (Extrema_ExtElC::*)() const) static_cast<int (Extrema_ExtElC::*)() const>(&Extrema_ExtElC::NbExt),
             R"#(Returns the number of extremum distances.)#" 
          )
        .def("SquareDistance",
             (double (Extrema_ExtElC::*)(  const int  ) const) static_cast<double (Extrema_ExtElC::*)(  const int  ) const>(&Extrema_ExtElC::SquareDistance),
             R"#(Returns the value of the Nth extremum square distance.)#"  , py::arg("N")=static_cast< const int>(1)
          )
        .def("Points",
             (void (Extrema_ExtElC::*)(  const int ,  Extrema_POnCurv & ,  Extrema_POnCurv &  ) const) static_cast<void (Extrema_ExtElC::*)(  const int ,  Extrema_POnCurv & ,  Extrema_POnCurv &  ) const>(&Extrema_ExtElC::Points),
             R"#(Returns the points of the Nth extremum distance. P1 is on the first curve, P2 on the second one.)#"  , py::arg("N"),  py::arg("P1"),  py::arg("P2")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Extrema_ExtElC2d from ./opencascade/Extrema_ExtElC2d.hxx
    klass = m.attr("Extrema_ExtElC2d");


    // nested enums

    static_cast<py::class_<Extrema_ExtElC2d , shared_ptr<Extrema_ExtElC2d>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const gp_Circ2d &, const gp_Circ2d & >()  , py::arg("C1"),  py::arg("C2") )
        .def(py::init<  const gp_Circ2d &, const gp_Elips2d & >()  , py::arg("C1"),  py::arg("C2") )
        .def(py::init<  const gp_Circ2d &, const gp_Hypr2d & >()  , py::arg("C1"),  py::arg("C2") )
        .def(py::init<  const gp_Circ2d &, const gp_Parab2d & >()  , py::arg("C1"),  py::arg("C2") )
        .def(py::init<  const gp_Lin2d &, const gp_Circ2d &, const double >()  , py::arg("C1"),  py::arg("C2"),  py::arg("Tol") )
        .def(py::init<  const gp_Lin2d &, const gp_Elips2d & >()  , py::arg("C1"),  py::arg("C2") )
        .def(py::init<  const gp_Lin2d &, const gp_Hypr2d & >()  , py::arg("C1"),  py::arg("C2") )
        .def(py::init<  const gp_Lin2d &, const gp_Lin2d &, const double >()  , py::arg("C1"),  py::arg("C2"),  py::arg("AngTol") )
        .def(py::init<  const gp_Lin2d &, const gp_Parab2d & >()  , py::arg("C1"),  py::arg("C2") )
    // custom constructors
    // methods
        .def("IsDone",
             (bool (Extrema_ExtElC2d::*)() const) static_cast<bool (Extrema_ExtElC2d::*)() const>(&Extrema_ExtElC2d::IsDone),
             R"#(Returns True if the distances are found.)#" 
          )
        .def("IsParallel",
             (bool (Extrema_ExtElC2d::*)() const) static_cast<bool (Extrema_ExtElC2d::*)() const>(&Extrema_ExtElC2d::IsParallel),
             R"#(Returns True if the two curves are parallel.)#" 
          )
        .def("NbExt",
             (int (Extrema_ExtElC2d::*)() const) static_cast<int (Extrema_ExtElC2d::*)() const>(&Extrema_ExtElC2d::NbExt),
             R"#(Returns the number of extremum distances.)#" 
          )
        .def("SquareDistance",
             (double (Extrema_ExtElC2d::*)(  const int  ) const) static_cast<double (Extrema_ExtElC2d::*)(  const int  ) const>(&Extrema_ExtElC2d::SquareDistance),
             R"#(Returns the value of the Nth extremum square distance.)#"  , py::arg("N")=static_cast< const int>(1)
          )
        .def("Points",
             (void (Extrema_ExtElC2d::*)(  const int ,  Extrema_POnCurv2d & ,  Extrema_POnCurv2d &  ) const) static_cast<void (Extrema_ExtElC2d::*)(  const int ,  Extrema_POnCurv2d & ,  Extrema_POnCurv2d &  ) const>(&Extrema_ExtElC2d::Points),
             R"#(Returns the points of the Nth extremum distance. P1 is on the first curve, P2 on the second one.)#"  , py::arg("N"),  py::arg("P1"),  py::arg("P2")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Extrema_ExtElCS from ./opencascade/Extrema_ExtElCS.hxx
    klass = m.attr("Extrema_ExtElCS");


    // nested enums

    static_cast<py::class_<Extrema_ExtElCS , shared_ptr<Extrema_ExtElCS>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const gp_Circ &, const gp_Cone & >()  , py::arg("C"),  py::arg("S") )
        .def(py::init<  const gp_Circ &, const gp_Cylinder & >()  , py::arg("C"),  py::arg("S") )
        .def(py::init<  const gp_Circ &, const gp_Pln & >()  , py::arg("C"),  py::arg("S") )
        .def(py::init<  const gp_Circ &, const gp_Sphere & >()  , py::arg("C"),  py::arg("S") )
        .def(py::init<  const gp_Circ &, const gp_Torus & >()  , py::arg("C"),  py::arg("S") )
        .def(py::init<  const gp_Hypr &, const gp_Pln & >()  , py::arg("C"),  py::arg("S") )
        .def(py::init<  const gp_Lin &, const gp_Cone & >()  , py::arg("C"),  py::arg("S") )
        .def(py::init<  const gp_Lin &, const gp_Cylinder & >()  , py::arg("C"),  py::arg("S") )
        .def(py::init<  const gp_Lin &, const gp_Pln & >()  , py::arg("C"),  py::arg("S") )
        .def(py::init<  const gp_Lin &, const gp_Sphere & >()  , py::arg("C"),  py::arg("S") )
        .def(py::init<  const gp_Lin &, const gp_Torus & >()  , py::arg("C"),  py::arg("S") )
    // custom constructors
    // methods
        .def("Perform",
             (void (Extrema_ExtElCS::*)(  const gp_Lin & ,   const gp_Pln &  ) ) static_cast<void (Extrema_ExtElCS::*)(  const gp_Lin & ,   const gp_Pln &  ) >(&Extrema_ExtElCS::Perform),
             R"#()#"  , py::arg("C"),  py::arg("S")
          )
        .def("Perform",
             (void (Extrema_ExtElCS::*)(  const gp_Lin & ,   const gp_Cylinder &  ) ) static_cast<void (Extrema_ExtElCS::*)(  const gp_Lin & ,   const gp_Cylinder &  ) >(&Extrema_ExtElCS::Perform),
             R"#()#"  , py::arg("C"),  py::arg("S")
          )
        .def("Perform",
             (void (Extrema_ExtElCS::*)(  const gp_Lin & ,   const gp_Cone &  ) ) static_cast<void (Extrema_ExtElCS::*)(  const gp_Lin & ,   const gp_Cone &  ) >(&Extrema_ExtElCS::Perform),
             R"#()#"  , py::arg("C"),  py::arg("S")
          )
        .def("Perform",
             (void (Extrema_ExtElCS::*)(  const gp_Lin & ,   const gp_Sphere &  ) ) static_cast<void (Extrema_ExtElCS::*)(  const gp_Lin & ,   const gp_Sphere &  ) >(&Extrema_ExtElCS::Perform),
             R"#()#"  , py::arg("C"),  py::arg("S")
          )
        .def("Perform",
             (void (Extrema_ExtElCS::*)(  const gp_Lin & ,   const gp_Torus &  ) ) static_cast<void (Extrema_ExtElCS::*)(  const gp_Lin & ,   const gp_Torus &  ) >(&Extrema_ExtElCS::Perform),
             R"#()#"  , py::arg("C"),  py::arg("S")
          )
        .def("Perform",
             (void (Extrema_ExtElCS::*)(  const gp_Circ & ,   const gp_Pln &  ) ) static_cast<void (Extrema_ExtElCS::*)(  const gp_Circ & ,   const gp_Pln &  ) >(&Extrema_ExtElCS::Perform),
             R"#()#"  , py::arg("C"),  py::arg("S")
          )
        .def("Perform",
             (void (Extrema_ExtElCS::*)(  const gp_Circ & ,   const gp_Cylinder &  ) ) static_cast<void (Extrema_ExtElCS::*)(  const gp_Circ & ,   const gp_Cylinder &  ) >(&Extrema_ExtElCS::Perform),
             R"#()#"  , py::arg("C"),  py::arg("S")
          )
        .def("Perform",
             (void (Extrema_ExtElCS::*)(  const gp_Circ & ,   const gp_Cone &  ) ) static_cast<void (Extrema_ExtElCS::*)(  const gp_Circ & ,   const gp_Cone &  ) >(&Extrema_ExtElCS::Perform),
             R"#()#"  , py::arg("C"),  py::arg("S")
          )
        .def("Perform",
             (void (Extrema_ExtElCS::*)(  const gp_Circ & ,   const gp_Sphere &  ) ) static_cast<void (Extrema_ExtElCS::*)(  const gp_Circ & ,   const gp_Sphere &  ) >(&Extrema_ExtElCS::Perform),
             R"#()#"  , py::arg("C"),  py::arg("S")
          )
        .def("Perform",
             (void (Extrema_ExtElCS::*)(  const gp_Circ & ,   const gp_Torus &  ) ) static_cast<void (Extrema_ExtElCS::*)(  const gp_Circ & ,   const gp_Torus &  ) >(&Extrema_ExtElCS::Perform),
             R"#()#"  , py::arg("C"),  py::arg("S")
          )
        .def("Perform",
             (void (Extrema_ExtElCS::*)(  const gp_Hypr & ,   const gp_Pln &  ) ) static_cast<void (Extrema_ExtElCS::*)(  const gp_Hypr & ,   const gp_Pln &  ) >(&Extrema_ExtElCS::Perform),
             R"#()#"  , py::arg("C"),  py::arg("S")
          )
        .def("IsDone",
             (bool (Extrema_ExtElCS::*)() const) static_cast<bool (Extrema_ExtElCS::*)() const>(&Extrema_ExtElCS::IsDone),
             R"#(Returns True if the distances are found.)#" 
          )
        .def("IsParallel",
             (bool (Extrema_ExtElCS::*)() const) static_cast<bool (Extrema_ExtElCS::*)() const>(&Extrema_ExtElCS::IsParallel),
             R"#(Returns True if the curve is on a parallel surface.)#" 
          )
        .def("NbExt",
             (int (Extrema_ExtElCS::*)() const) static_cast<int (Extrema_ExtElCS::*)() const>(&Extrema_ExtElCS::NbExt),
             R"#(Returns the number of extremum distances.)#" 
          )
        .def("SquareDistance",
             (double (Extrema_ExtElCS::*)(  const int  ) const) static_cast<double (Extrema_ExtElCS::*)(  const int  ) const>(&Extrema_ExtElCS::SquareDistance),
             R"#(Returns the value of the Nth extremum square distance.)#"  , py::arg("N")=static_cast< const int>(1)
          )
        .def("Points",
             (void (Extrema_ExtElCS::*)(  const int ,  Extrema_POnCurv & ,  Extrema_POnSurf &  ) const) static_cast<void (Extrema_ExtElCS::*)(  const int ,  Extrema_POnCurv & ,  Extrema_POnSurf &  ) const>(&Extrema_ExtElCS::Points),
             R"#(Returns the points of the Nth extremum distance. P1 is on the curve, P2 on the surface.)#"  , py::arg("N"),  py::arg("P1"),  py::arg("P2")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Extrema_ExtElSS from ./opencascade/Extrema_ExtElSS.hxx
    klass = m.attr("Extrema_ExtElSS");


    // nested enums

    static_cast<py::class_<Extrema_ExtElSS , shared_ptr<Extrema_ExtElSS>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const gp_Pln &, const gp_Pln & >()  , py::arg("S1"),  py::arg("S2") )
        .def(py::init<  const gp_Pln &, const gp_Sphere & >()  , py::arg("S1"),  py::arg("S2") )
        .def(py::init<  const gp_Sphere &, const gp_Cone & >()  , py::arg("S1"),  py::arg("S2") )
        .def(py::init<  const gp_Sphere &, const gp_Cylinder & >()  , py::arg("S1"),  py::arg("S2") )
        .def(py::init<  const gp_Sphere &, const gp_Sphere & >()  , py::arg("S1"),  py::arg("S2") )
        .def(py::init<  const gp_Sphere &, const gp_Torus & >()  , py::arg("S1"),  py::arg("S2") )
    // custom constructors
    // methods
        .def("Perform",
             (void (Extrema_ExtElSS::*)(  const gp_Pln & ,   const gp_Pln &  ) ) static_cast<void (Extrema_ExtElSS::*)(  const gp_Pln & ,   const gp_Pln &  ) >(&Extrema_ExtElSS::Perform),
             R"#()#"  , py::arg("S1"),  py::arg("S2")
          )
        .def("Perform",
             (void (Extrema_ExtElSS::*)(  const gp_Pln & ,   const gp_Sphere &  ) ) static_cast<void (Extrema_ExtElSS::*)(  const gp_Pln & ,   const gp_Sphere &  ) >(&Extrema_ExtElSS::Perform),
             R"#()#"  , py::arg("S1"),  py::arg("S2")
          )
        .def("Perform",
             (void (Extrema_ExtElSS::*)(  const gp_Sphere & ,   const gp_Sphere &  ) ) static_cast<void (Extrema_ExtElSS::*)(  const gp_Sphere & ,   const gp_Sphere &  ) >(&Extrema_ExtElSS::Perform),
             R"#()#"  , py::arg("S1"),  py::arg("S2")
          )
        .def("Perform",
             (void (Extrema_ExtElSS::*)(  const gp_Sphere & ,   const gp_Cylinder &  ) ) static_cast<void (Extrema_ExtElSS::*)(  const gp_Sphere & ,   const gp_Cylinder &  ) >(&Extrema_ExtElSS::Perform),
             R"#()#"  , py::arg("S1"),  py::arg("S2")
          )
        .def("Perform",
             (void (Extrema_ExtElSS::*)(  const gp_Sphere & ,   const gp_Cone &  ) ) static_cast<void (Extrema_ExtElSS::*)(  const gp_Sphere & ,   const gp_Cone &  ) >(&Extrema_ExtElSS::Perform),
             R"#()#"  , py::arg("S1"),  py::arg("S2")
          )
        .def("Perform",
             (void (Extrema_ExtElSS::*)(  const gp_Sphere & ,   const gp_Torus &  ) ) static_cast<void (Extrema_ExtElSS::*)(  const gp_Sphere & ,   const gp_Torus &  ) >(&Extrema_ExtElSS::Perform),
             R"#()#"  , py::arg("S1"),  py::arg("S2")
          )
        .def("IsDone",
             (bool (Extrema_ExtElSS::*)() const) static_cast<bool (Extrema_ExtElSS::*)() const>(&Extrema_ExtElSS::IsDone),
             R"#(Returns True if the distances are found.)#" 
          )
        .def("IsParallel",
             (bool (Extrema_ExtElSS::*)() const) static_cast<bool (Extrema_ExtElSS::*)() const>(&Extrema_ExtElSS::IsParallel),
             R"#(Returns True if the two surfaces are parallel.)#" 
          )
        .def("NbExt",
             (int (Extrema_ExtElSS::*)() const) static_cast<int (Extrema_ExtElSS::*)() const>(&Extrema_ExtElSS::NbExt),
             R"#(Returns the number of extremum distances.)#" 
          )
        .def("SquareDistance",
             (double (Extrema_ExtElSS::*)(  const int  ) const) static_cast<double (Extrema_ExtElSS::*)(  const int  ) const>(&Extrema_ExtElSS::SquareDistance),
             R"#(Returns the value of the Nth extremum square distance.)#"  , py::arg("N")=static_cast< const int>(1)
          )
        .def("Points",
             (void (Extrema_ExtElSS::*)(  const int ,  Extrema_POnSurf & ,  Extrema_POnSurf &  ) const) static_cast<void (Extrema_ExtElSS::*)(  const int ,  Extrema_POnSurf & ,  Extrema_POnSurf &  ) const>(&Extrema_ExtElSS::Points),
             R"#(Returns the points for the Nth resulting distance. P1 is on the first surface, P2 on the second one.)#"  , py::arg("N"),  py::arg("P1"),  py::arg("P2")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Extrema_ExtPElC from ./opencascade/Extrema_ExtPElC.hxx
    klass = m.attr("Extrema_ExtPElC");


    // nested enums

    static_cast<py::class_<Extrema_ExtPElC , shared_ptr<Extrema_ExtPElC>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const gp_Pnt &, const gp_Circ &, const double, const double, const double >()  , py::arg("P"),  py::arg("C"),  py::arg("Tol"),  py::arg("Uinf"),  py::arg("Usup") )
        .def(py::init<  const gp_Pnt &, const gp_Elips &, const double, const double, const double >()  , py::arg("P"),  py::arg("C"),  py::arg("Tol"),  py::arg("Uinf"),  py::arg("Usup") )
        .def(py::init<  const gp_Pnt &, const gp_Hypr &, const double, const double, const double >()  , py::arg("P"),  py::arg("C"),  py::arg("Tol"),  py::arg("Uinf"),  py::arg("Usup") )
        .def(py::init<  const gp_Pnt &, const gp_Lin &, const double, const double, const double >()  , py::arg("P"),  py::arg("C"),  py::arg("Tol"),  py::arg("Uinf"),  py::arg("Usup") )
        .def(py::init<  const gp_Pnt &, const gp_Parab &, const double, const double, const double >()  , py::arg("P"),  py::arg("C"),  py::arg("Tol"),  py::arg("Uinf"),  py::arg("Usup") )
    // custom constructors
    // methods
        .def("Perform",
             (void (Extrema_ExtPElC::*)(  const gp_Pnt & ,   const gp_Lin & ,   const double ,   const double ,   const double  ) ) static_cast<void (Extrema_ExtPElC::*)(  const gp_Pnt & ,   const gp_Lin & ,   const double ,   const double ,   const double  ) >(&Extrema_ExtPElC::Perform),
             R"#()#"  , py::arg("P"),  py::arg("C"),  py::arg("Tol"),  py::arg("Uinf"),  py::arg("Usup")
          )
        .def("Perform",
             (void (Extrema_ExtPElC::*)(  const gp_Pnt & ,   const gp_Circ & ,   const double ,   const double ,   const double  ) ) static_cast<void (Extrema_ExtPElC::*)(  const gp_Pnt & ,   const gp_Circ & ,   const double ,   const double ,   const double  ) >(&Extrema_ExtPElC::Perform),
             R"#()#"  , py::arg("P"),  py::arg("C"),  py::arg("Tol"),  py::arg("Uinf"),  py::arg("Usup")
          )
        .def("Perform",
             (void (Extrema_ExtPElC::*)(  const gp_Pnt & ,   const gp_Elips & ,   const double ,   const double ,   const double  ) ) static_cast<void (Extrema_ExtPElC::*)(  const gp_Pnt & ,   const gp_Elips & ,   const double ,   const double ,   const double  ) >(&Extrema_ExtPElC::Perform),
             R"#()#"  , py::arg("P"),  py::arg("C"),  py::arg("Tol"),  py::arg("Uinf"),  py::arg("Usup")
          )
        .def("Perform",
             (void (Extrema_ExtPElC::*)(  const gp_Pnt & ,   const gp_Hypr & ,   const double ,   const double ,   const double  ) ) static_cast<void (Extrema_ExtPElC::*)(  const gp_Pnt & ,   const gp_Hypr & ,   const double ,   const double ,   const double  ) >(&Extrema_ExtPElC::Perform),
             R"#()#"  , py::arg("P"),  py::arg("C"),  py::arg("Tol"),  py::arg("Uinf"),  py::arg("Usup")
          )
        .def("Perform",
             (void (Extrema_ExtPElC::*)(  const gp_Pnt & ,   const gp_Parab & ,   const double ,   const double ,   const double  ) ) static_cast<void (Extrema_ExtPElC::*)(  const gp_Pnt & ,   const gp_Parab & ,   const double ,   const double ,   const double  ) >(&Extrema_ExtPElC::Perform),
             R"#()#"  , py::arg("P"),  py::arg("C"),  py::arg("Tol"),  py::arg("Uinf"),  py::arg("Usup")
          )
        .def("IsDone",
             (bool (Extrema_ExtPElC::*)() const) static_cast<bool (Extrema_ExtPElC::*)() const>(&Extrema_ExtPElC::IsDone),
             R"#(True if the distances are found.)#" 
          )
        .def("NbExt",
             (int (Extrema_ExtPElC::*)() const) static_cast<int (Extrema_ExtPElC::*)() const>(&Extrema_ExtPElC::NbExt),
             R"#(Returns the number of extremum distances.)#" 
          )
        .def("SquareDistance",
             (double (Extrema_ExtPElC::*)(  const int  ) const) static_cast<double (Extrema_ExtPElC::*)(  const int  ) const>(&Extrema_ExtPElC::SquareDistance),
             R"#(Returns the value of the Nth extremum square distance.)#"  , py::arg("N")
          )
        .def("IsMin",
             (bool (Extrema_ExtPElC::*)(  const int  ) const) static_cast<bool (Extrema_ExtPElC::*)(  const int  ) const>(&Extrema_ExtPElC::IsMin),
             R"#(Returns True if the Nth extremum distance is a minimum.)#"  , py::arg("N")
          )
        .def("Point",
             ( const Extrema_POnCurv & (Extrema_ExtPElC::*)(  const int  ) const) static_cast< const Extrema_POnCurv & (Extrema_ExtPElC::*)(  const int  ) const>(&Extrema_ExtPElC::Point),
             R"#(Returns the point of the Nth extremum distance.)#"  , py::arg("N")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Extrema_ExtPElC2d from ./opencascade/Extrema_ExtPElC2d.hxx
    klass = m.attr("Extrema_ExtPElC2d");


    // nested enums

    static_cast<py::class_<Extrema_ExtPElC2d , shared_ptr<Extrema_ExtPElC2d>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const gp_Pnt2d &, const gp_Circ2d &, const double, const double, const double >()  , py::arg("P"),  py::arg("C"),  py::arg("Tol"),  py::arg("Uinf"),  py::arg("Usup") )
        .def(py::init<  const gp_Pnt2d &, const gp_Elips2d &, const double, const double, const double >()  , py::arg("P"),  py::arg("C"),  py::arg("Tol"),  py::arg("Uinf"),  py::arg("Usup") )
        .def(py::init<  const gp_Pnt2d &, const gp_Hypr2d &, const double, const double, const double >()  , py::arg("P"),  py::arg("C"),  py::arg("Tol"),  py::arg("Uinf"),  py::arg("Usup") )
        .def(py::init<  const gp_Pnt2d &, const gp_Lin2d &, const double, const double, const double >()  , py::arg("P"),  py::arg("C"),  py::arg("Tol"),  py::arg("Uinf"),  py::arg("Usup") )
        .def(py::init<  const gp_Pnt2d &, const gp_Parab2d &, const double, const double, const double >()  , py::arg("P"),  py::arg("C"),  py::arg("Tol"),  py::arg("Uinf"),  py::arg("Usup") )
    // custom constructors
    // methods
        .def("Perform",
             (void (Extrema_ExtPElC2d::*)(  const gp_Pnt2d & ,   const gp_Lin2d & ,   const double ,   const double ,   const double  ) ) static_cast<void (Extrema_ExtPElC2d::*)(  const gp_Pnt2d & ,   const gp_Lin2d & ,   const double ,   const double ,   const double  ) >(&Extrema_ExtPElC2d::Perform),
             R"#()#"  , py::arg("P"),  py::arg("L"),  py::arg("Tol"),  py::arg("Uinf"),  py::arg("Usup")
          )
        .def("Perform",
             (void (Extrema_ExtPElC2d::*)(  const gp_Pnt2d & ,   const gp_Circ2d & ,   const double ,   const double ,   const double  ) ) static_cast<void (Extrema_ExtPElC2d::*)(  const gp_Pnt2d & ,   const gp_Circ2d & ,   const double ,   const double ,   const double  ) >(&Extrema_ExtPElC2d::Perform),
             R"#()#"  , py::arg("P"),  py::arg("C"),  py::arg("Tol"),  py::arg("Uinf"),  py::arg("Usup")
          )
        .def("Perform",
             (void (Extrema_ExtPElC2d::*)(  const gp_Pnt2d & ,   const gp_Elips2d & ,   const double ,   const double ,   const double  ) ) static_cast<void (Extrema_ExtPElC2d::*)(  const gp_Pnt2d & ,   const gp_Elips2d & ,   const double ,   const double ,   const double  ) >(&Extrema_ExtPElC2d::Perform),
             R"#()#"  , py::arg("P"),  py::arg("C"),  py::arg("Tol"),  py::arg("Uinf"),  py::arg("Usup")
          )
        .def("Perform",
             (void (Extrema_ExtPElC2d::*)(  const gp_Pnt2d & ,   const gp_Hypr2d & ,   const double ,   const double ,   const double  ) ) static_cast<void (Extrema_ExtPElC2d::*)(  const gp_Pnt2d & ,   const gp_Hypr2d & ,   const double ,   const double ,   const double  ) >(&Extrema_ExtPElC2d::Perform),
             R"#()#"  , py::arg("P"),  py::arg("C"),  py::arg("Tol"),  py::arg("Uinf"),  py::arg("Usup")
          )
        .def("Perform",
             (void (Extrema_ExtPElC2d::*)(  const gp_Pnt2d & ,   const gp_Parab2d & ,   const double ,   const double ,   const double  ) ) static_cast<void (Extrema_ExtPElC2d::*)(  const gp_Pnt2d & ,   const gp_Parab2d & ,   const double ,   const double ,   const double  ) >(&Extrema_ExtPElC2d::Perform),
             R"#()#"  , py::arg("P"),  py::arg("C"),  py::arg("Tol"),  py::arg("Uinf"),  py::arg("Usup")
          )
        .def("IsDone",
             (bool (Extrema_ExtPElC2d::*)() const) static_cast<bool (Extrema_ExtPElC2d::*)() const>(&Extrema_ExtPElC2d::IsDone),
             R"#(True if the distances are found.)#" 
          )
        .def("NbExt",
             (int (Extrema_ExtPElC2d::*)() const) static_cast<int (Extrema_ExtPElC2d::*)() const>(&Extrema_ExtPElC2d::NbExt),
             R"#(Returns the number of extremum distances.)#" 
          )
        .def("SquareDistance",
             (double (Extrema_ExtPElC2d::*)(  const int  ) const) static_cast<double (Extrema_ExtPElC2d::*)(  const int  ) const>(&Extrema_ExtPElC2d::SquareDistance),
             R"#(Returns the value of the Nth extremum square distance.)#"  , py::arg("N")
          )
        .def("IsMin",
             (bool (Extrema_ExtPElC2d::*)(  const int  ) const) static_cast<bool (Extrema_ExtPElC2d::*)(  const int  ) const>(&Extrema_ExtPElC2d::IsMin),
             R"#(Returns True if the Nth extremum distance is a minimum.)#"  , py::arg("N")
          )
        .def("Point",
             ( const Extrema_POnCurv2d & (Extrema_ExtPElC2d::*)(  const int  ) const) static_cast< const Extrema_POnCurv2d & (Extrema_ExtPElC2d::*)(  const int  ) const>(&Extrema_ExtPElC2d::Point),
             R"#(Returns the point of the Nth extremum distance.)#"  , py::arg("N")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Extrema_ExtPElS from ./opencascade/Extrema_ExtPElS.hxx
    klass = m.attr("Extrema_ExtPElS");


    // nested enums

    static_cast<py::class_<Extrema_ExtPElS , shared_ptr<Extrema_ExtPElS>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const gp_Pnt &, const gp_Cone &, const double >()  , py::arg("P"),  py::arg("S"),  py::arg("Tol") )
        .def(py::init<  const gp_Pnt &, const gp_Cylinder &, const double >()  , py::arg("P"),  py::arg("S"),  py::arg("Tol") )
        .def(py::init<  const gp_Pnt &, const gp_Pln &, const double >()  , py::arg("P"),  py::arg("S"),  py::arg("Tol") )
        .def(py::init<  const gp_Pnt &, const gp_Sphere &, const double >()  , py::arg("P"),  py::arg("S"),  py::arg("Tol") )
        .def(py::init<  const gp_Pnt &, const gp_Torus &, const double >()  , py::arg("P"),  py::arg("S"),  py::arg("Tol") )
    // custom constructors
    // methods
        .def("Perform",
             (void (Extrema_ExtPElS::*)(  const gp_Pnt & ,   const gp_Cylinder & ,   const double  ) ) static_cast<void (Extrema_ExtPElS::*)(  const gp_Pnt & ,   const gp_Cylinder & ,   const double  ) >(&Extrema_ExtPElS::Perform),
             R"#()#"  , py::arg("P"),  py::arg("S"),  py::arg("Tol")
          )
        .def("Perform",
             (void (Extrema_ExtPElS::*)(  const gp_Pnt & ,   const gp_Pln & ,   const double  ) ) static_cast<void (Extrema_ExtPElS::*)(  const gp_Pnt & ,   const gp_Pln & ,   const double  ) >(&Extrema_ExtPElS::Perform),
             R"#()#"  , py::arg("P"),  py::arg("S"),  py::arg("Tol")
          )
        .def("Perform",
             (void (Extrema_ExtPElS::*)(  const gp_Pnt & ,   const gp_Cone & ,   const double  ) ) static_cast<void (Extrema_ExtPElS::*)(  const gp_Pnt & ,   const gp_Cone & ,   const double  ) >(&Extrema_ExtPElS::Perform),
             R"#()#"  , py::arg("P"),  py::arg("S"),  py::arg("Tol")
          )
        .def("Perform",
             (void (Extrema_ExtPElS::*)(  const gp_Pnt & ,   const gp_Torus & ,   const double  ) ) static_cast<void (Extrema_ExtPElS::*)(  const gp_Pnt & ,   const gp_Torus & ,   const double  ) >(&Extrema_ExtPElS::Perform),
             R"#()#"  , py::arg("P"),  py::arg("S"),  py::arg("Tol")
          )
        .def("Perform",
             (void (Extrema_ExtPElS::*)(  const gp_Pnt & ,   const gp_Sphere & ,   const double  ) ) static_cast<void (Extrema_ExtPElS::*)(  const gp_Pnt & ,   const gp_Sphere & ,   const double  ) >(&Extrema_ExtPElS::Perform),
             R"#()#"  , py::arg("P"),  py::arg("S"),  py::arg("Tol")
          )
        .def("IsDone",
             (bool (Extrema_ExtPElS::*)() const) static_cast<bool (Extrema_ExtPElS::*)() const>(&Extrema_ExtPElS::IsDone),
             R"#(Returns True if the distances are found.)#" 
          )
        .def("NbExt",
             (int (Extrema_ExtPElS::*)() const) static_cast<int (Extrema_ExtPElS::*)() const>(&Extrema_ExtPElS::NbExt),
             R"#(Returns the number of extremum distances.)#" 
          )
        .def("SquareDistance",
             (double (Extrema_ExtPElS::*)(  const int  ) const) static_cast<double (Extrema_ExtPElS::*)(  const int  ) const>(&Extrema_ExtPElS::SquareDistance),
             R"#(Returns the value of the Nth resulting square distance.)#"  , py::arg("N")
          )
        .def("Point",
             ( const Extrema_POnSurf & (Extrema_ExtPElS::*)(  const int  ) const) static_cast< const Extrema_POnSurf & (Extrema_ExtPElS::*)(  const int  ) const>(&Extrema_ExtPElS::Point),
             R"#(Returns the point of the Nth resulting distance.)#"  , py::arg("N")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Extrema_ExtPExtS from ./opencascade/Extrema_ExtPExtS.hxx
    klass = m.attr("Extrema_ExtPExtS");


    // nested enums

    static_cast<py::class_<Extrema_ExtPExtS ,opencascade::handle<Extrema_ExtPExtS>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const gp_Pnt &, const handle<GeomAdaptor_SurfaceOfLinearExtrusion> &, const double, const double >()  , py::arg("P"),  py::arg("S"),  py::arg("TolU"),  py::arg("TolV") )
        .def(py::init<  const gp_Pnt &, const handle<GeomAdaptor_SurfaceOfLinearExtrusion> &, const double, const double, const double, const double, const double, const double >()  , py::arg("P"),  py::arg("S"),  py::arg("Umin"),  py::arg("Usup"),  py::arg("Vmin"),  py::arg("Vsup"),  py::arg("TolU"),  py::arg("TolV") )
    // custom constructors
    // methods
        .def("Initialize",
             (void (Extrema_ExtPExtS::*)(  const handle<GeomAdaptor_SurfaceOfLinearExtrusion> & ,   const double ,   const double ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<void (Extrema_ExtPExtS::*)(  const handle<GeomAdaptor_SurfaceOfLinearExtrusion> & ,   const double ,   const double ,   const double ,   const double ,   const double ,   const double  ) >(&Extrema_ExtPExtS::Initialize),
             R"#(Initializes the fields of the algorithm.)#"  , py::arg("S"),  py::arg("Uinf"),  py::arg("Usup"),  py::arg("Vinf"),  py::arg("Vsup"),  py::arg("TolU"),  py::arg("TolV")
          )
        .def("Perform",
             (void (Extrema_ExtPExtS::*)(  const gp_Pnt &  ) ) static_cast<void (Extrema_ExtPExtS::*)(  const gp_Pnt &  ) >(&Extrema_ExtPExtS::Perform),
             R"#()#"  , py::arg("P")
          )
        .def("IsDone",
             (bool (Extrema_ExtPExtS::*)() const) static_cast<bool (Extrema_ExtPExtS::*)() const>(&Extrema_ExtPExtS::IsDone),
             R"#(Returns True if the distances are found.)#" 
          )
        .def("NbExt",
             (int (Extrema_ExtPExtS::*)() const) static_cast<int (Extrema_ExtPExtS::*)() const>(&Extrema_ExtPExtS::NbExt),
             R"#(Returns the number of extremum distances.)#" 
          )
        .def("SquareDistance",
             (double (Extrema_ExtPExtS::*)(  const int  ) const) static_cast<double (Extrema_ExtPExtS::*)(  const int  ) const>(&Extrema_ExtPExtS::SquareDistance),
             R"#(Returns the value of the Nth resulting square distance.)#"  , py::arg("N")
          )
        .def("Point",
             ( const Extrema_POnSurf & (Extrema_ExtPExtS::*)(  const int  ) const) static_cast< const Extrema_POnSurf & (Extrema_ExtPExtS::*)(  const int  ) const>(&Extrema_ExtPExtS::Point),
             R"#(Returns the point of the Nth resulting distance.)#"  , py::arg("N")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&Extrema_ExtPExtS::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&Extrema_ExtPExtS::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (Extrema_ExtPExtS::*)() const) static_cast< const handle<Standard_Type> & (Extrema_ExtPExtS::*)() const>(&Extrema_ExtPExtS::DynamicType),
             R"#()#"
             
         )
;

    // Class Extrema_ExtPRevS from ./opencascade/Extrema_ExtPRevS.hxx
    klass = m.attr("Extrema_ExtPRevS");


    // nested enums

    static_cast<py::class_<Extrema_ExtPRevS ,opencascade::handle<Extrema_ExtPRevS>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const gp_Pnt &, const handle<GeomAdaptor_SurfaceOfRevolution> &, const double, const double >()  , py::arg("P"),  py::arg("S"),  py::arg("TolU"),  py::arg("TolV") )
        .def(py::init<  const gp_Pnt &, const handle<GeomAdaptor_SurfaceOfRevolution> &, const double, const double, const double, const double, const double, const double >()  , py::arg("P"),  py::arg("S"),  py::arg("Umin"),  py::arg("Usup"),  py::arg("Vmin"),  py::arg("Vsup"),  py::arg("TolU"),  py::arg("TolV") )
    // custom constructors
    // methods
        .def("Initialize",
             (void (Extrema_ExtPRevS::*)(  const handle<GeomAdaptor_SurfaceOfRevolution> & ,   const double ,   const double ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<void (Extrema_ExtPRevS::*)(  const handle<GeomAdaptor_SurfaceOfRevolution> & ,   const double ,   const double ,   const double ,   const double ,   const double ,   const double  ) >(&Extrema_ExtPRevS::Initialize),
             R"#()#"  , py::arg("S"),  py::arg("Umin"),  py::arg("Usup"),  py::arg("Vmin"),  py::arg("Vsup"),  py::arg("TolU"),  py::arg("TolV")
          )
        .def("Perform",
             (void (Extrema_ExtPRevS::*)(  const gp_Pnt &  ) ) static_cast<void (Extrema_ExtPRevS::*)(  const gp_Pnt &  ) >(&Extrema_ExtPRevS::Perform),
             R"#()#"  , py::arg("P")
          )
        .def("IsDone",
             (bool (Extrema_ExtPRevS::*)() const) static_cast<bool (Extrema_ExtPRevS::*)() const>(&Extrema_ExtPRevS::IsDone),
             R"#(Returns True if the distances are found.)#" 
          )
        .def("NbExt",
             (int (Extrema_ExtPRevS::*)() const) static_cast<int (Extrema_ExtPRevS::*)() const>(&Extrema_ExtPRevS::NbExt),
             R"#(Returns the number of extremum distances.)#" 
          )
        .def("SquareDistance",
             (double (Extrema_ExtPRevS::*)(  const int  ) const) static_cast<double (Extrema_ExtPRevS::*)(  const int  ) const>(&Extrema_ExtPRevS::SquareDistance),
             R"#(Returns the value of the Nth resulting square distance.)#"  , py::arg("N")
          )
        .def("Point",
             ( const Extrema_POnSurf & (Extrema_ExtPRevS::*)(  const int  ) const) static_cast< const Extrema_POnSurf & (Extrema_ExtPRevS::*)(  const int  ) const>(&Extrema_ExtPRevS::Point),
             R"#(Returns the point of the Nth resulting distance.)#"  , py::arg("N")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&Extrema_ExtPRevS::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&Extrema_ExtPRevS::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (Extrema_ExtPRevS::*)() const) static_cast< const handle<Standard_Type> & (Extrema_ExtPRevS::*)() const>(&Extrema_ExtPRevS::DynamicType),
             R"#()#"
             
         )
;

    // Class Extrema_ExtPS from ./opencascade/Extrema_ExtPS.hxx
    klass = m.attr("Extrema_ExtPS");


    // nested enums

    static_cast<py::class_<Extrema_ExtPS , shared_ptr<Extrema_ExtPS>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const gp_Pnt &, const Adaptor3d_Surface &, const double, const double, const Extrema_ExtFlag, const Extrema_ExtAlgo >()  , py::arg("P"),  py::arg("S"),  py::arg("TolU"),  py::arg("TolV"),  py::arg("F")=static_cast< const Extrema_ExtFlag>(Extrema_ExtFlag_MINMAX),  py::arg("A")=static_cast< const Extrema_ExtAlgo>(Extrema_ExtAlgo_Grad) )
        .def(py::init<  const gp_Pnt &, const Adaptor3d_Surface &, const double, const double, const double, const double, const double, const double, const Extrema_ExtFlag, const Extrema_ExtAlgo >()  , py::arg("P"),  py::arg("S"),  py::arg("Uinf"),  py::arg("Usup"),  py::arg("Vinf"),  py::arg("Vsup"),  py::arg("TolU"),  py::arg("TolV"),  py::arg("F")=static_cast< const Extrema_ExtFlag>(Extrema_ExtFlag_MINMAX),  py::arg("A")=static_cast< const Extrema_ExtAlgo>(Extrema_ExtAlgo_Grad) )
    // custom constructors
    // methods
        .def("Initialize",
             (void (Extrema_ExtPS::*)(  const Adaptor3d_Surface & ,   const double ,   const double ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<void (Extrema_ExtPS::*)(  const Adaptor3d_Surface & ,   const double ,   const double ,   const double ,   const double ,   const double ,   const double  ) >(&Extrema_ExtPS::Initialize),
             R"#(Initializes the fields of the algorithm.)#"  , py::arg("S"),  py::arg("Uinf"),  py::arg("Usup"),  py::arg("Vinf"),  py::arg("Vsup"),  py::arg("TolU"),  py::arg("TolV")
          )
        .def("Perform",
             (void (Extrema_ExtPS::*)(  const gp_Pnt &  ) ) static_cast<void (Extrema_ExtPS::*)(  const gp_Pnt &  ) >(&Extrema_ExtPS::Perform),
             R"#(Computes the distances. An exception is raised if the fields have not been initialized.)#"  , py::arg("P")
          )
        .def("IsDone",
             (bool (Extrema_ExtPS::*)() const) static_cast<bool (Extrema_ExtPS::*)() const>(&Extrema_ExtPS::IsDone),
             R"#(Returns True if the distances are found.)#" 
          )
        .def("NbExt",
             (int (Extrema_ExtPS::*)() const) static_cast<int (Extrema_ExtPS::*)() const>(&Extrema_ExtPS::NbExt),
             R"#(Returns the number of extremum distances.)#" 
          )
        .def("SquareDistance",
             (double (Extrema_ExtPS::*)(  const int  ) const) static_cast<double (Extrema_ExtPS::*)(  const int  ) const>(&Extrema_ExtPS::SquareDistance),
             R"#(Returns the value of the Nth resulting square distance.)#"  , py::arg("N")
          )
        .def("Point",
             ( const Extrema_POnSurf & (Extrema_ExtPS::*)(  const int  ) const) static_cast< const Extrema_POnSurf & (Extrema_ExtPS::*)(  const int  ) const>(&Extrema_ExtPS::Point),
             R"#(Returns the point of the Nth resulting distance.)#"  , py::arg("N")
          )
        .def("SetFlag",
             (void (Extrema_ExtPS::*)(  const Extrema_ExtFlag  ) ) static_cast<void (Extrema_ExtPS::*)(  const Extrema_ExtFlag  ) >(&Extrema_ExtPS::SetFlag),
             R"#()#"  , py::arg("F")
          )
        .def("SetAlgo",
             (void (Extrema_ExtPS::*)(  const Extrema_ExtAlgo  ) ) static_cast<void (Extrema_ExtPS::*)(  const Extrema_ExtAlgo  ) >(&Extrema_ExtPS::SetAlgo),
             R"#()#"  , py::arg("A")
          )
    // methods using call by reference i.s.o. return
        .def("TrimmedSquareDistances",
             []( Extrema_ExtPS &self , gp_Pnt & PUfVf,gp_Pnt & PUfVl,gp_Pnt & PUlVf,gp_Pnt & PUlVl ){
                 double  dUfVf;
                double  dUfVl;
                double  dUlVf;
                double  dUlVl;

                 self.TrimmedSquareDistances(dUfVf,dUfVl,dUlVf,dUlVl,PUfVf,PUfVl,PUlVf,PUlVl);
                 return std::make_tuple(dUfVf,dUfVl,dUlVf,dUlVl); },
             R"#(if the surface is a trimmed surface, dUfVf is a square distance between <P> and the point of parameter FirstUParameter and FirstVParameter <PUfVf>. dUfVl is a square distance between <P> and the point of parameter FirstUParameter and LastVParameter <PUfVl>. dUlVf is a square distance between <P> and the point of parameter LastUParameter and FirstVParameter <PUlVf>. dUlVl is a square distance between <P> and the point of parameter LastUParameter and LastVParameter <PUlVl>.)#"  , py::arg("PUfVf"),  py::arg("PUfVl"),  py::arg("PUlVf"),  py::arg("PUlVl")
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Extrema_ExtSS from ./opencascade/Extrema_ExtSS.hxx
    klass = m.attr("Extrema_ExtSS");


    // nested enums

    static_cast<py::class_<Extrema_ExtSS , shared_ptr<Extrema_ExtSS>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const Adaptor3d_Surface &, const Adaptor3d_Surface &, const double, const double >()  , py::arg("S1"),  py::arg("S2"),  py::arg("TolS1"),  py::arg("TolS2") )
        .def(py::init<  const Adaptor3d_Surface &, const Adaptor3d_Surface &, const double, const double, const double, const double, const double, const double, const double, const double, const double, const double >()  , py::arg("S1"),  py::arg("S2"),  py::arg("Uinf1"),  py::arg("Usup1"),  py::arg("Vinf1"),  py::arg("Vsup1"),  py::arg("Uinf2"),  py::arg("Usup2"),  py::arg("Vinf2"),  py::arg("Vsup2"),  py::arg("TolS1"),  py::arg("TolS2") )
    // custom constructors
    // methods
        .def("Initialize",
             (void (Extrema_ExtSS::*)(  const Adaptor3d_Surface & ,   const double ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<void (Extrema_ExtSS::*)(  const Adaptor3d_Surface & ,   const double ,   const double ,   const double ,   const double ,   const double  ) >(&Extrema_ExtSS::Initialize),
             R"#(Initializes the fields of the algorithm.)#"  , py::arg("S2"),  py::arg("Uinf2"),  py::arg("Usup2"),  py::arg("Vinf2"),  py::arg("Vsup2"),  py::arg("TolS1")
          )
        .def("Perform",
             (void (Extrema_ExtSS::*)(  const Adaptor3d_Surface & ,   const double ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<void (Extrema_ExtSS::*)(  const Adaptor3d_Surface & ,   const double ,   const double ,   const double ,   const double ,   const double  ) >(&Extrema_ExtSS::Perform),
             R"#(Computes the distances. An exception is raised if the fields have not been initialized.)#"  , py::arg("S1"),  py::arg("Uinf1"),  py::arg("Usup1"),  py::arg("Vinf1"),  py::arg("Vsup1"),  py::arg("TolS1")
          )
        .def("IsDone",
             (bool (Extrema_ExtSS::*)() const) static_cast<bool (Extrema_ExtSS::*)() const>(&Extrema_ExtSS::IsDone),
             R"#(Returns True if the distances are found.)#" 
          )
        .def("IsParallel",
             (bool (Extrema_ExtSS::*)() const) static_cast<bool (Extrema_ExtSS::*)() const>(&Extrema_ExtSS::IsParallel),
             R"#(Returns True if the surfaces are parallel)#" 
          )
        .def("NbExt",
             (int (Extrema_ExtSS::*)() const) static_cast<int (Extrema_ExtSS::*)() const>(&Extrema_ExtSS::NbExt),
             R"#(Returns the number of extremum distances.)#" 
          )
        .def("SquareDistance",
             (double (Extrema_ExtSS::*)(  const int  ) const) static_cast<double (Extrema_ExtSS::*)(  const int  ) const>(&Extrema_ExtSS::SquareDistance),
             R"#(Returns the value of the Nth resulting square distance.)#"  , py::arg("N")
          )
        .def("Points",
             (void (Extrema_ExtSS::*)(  const int ,  Extrema_POnSurf & ,  Extrema_POnSurf &  ) const) static_cast<void (Extrema_ExtSS::*)(  const int ,  Extrema_POnSurf & ,  Extrema_POnSurf &  ) const>(&Extrema_ExtSS::Points),
             R"#(Returns the point of the Nth resulting distance.)#"  , py::arg("N"),  py::arg("P1"),  py::arg("P2")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Extrema_FuncExtCS from ./opencascade/Extrema_FuncExtCS.hxx
    klass = m.attr("Extrema_FuncExtCS");


    // nested enums

    static_cast<py::class_<Extrema_FuncExtCS , shared_ptr<Extrema_FuncExtCS>  , math_FunctionSetWithDerivatives >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const Adaptor3d_Curve &, const Adaptor3d_Surface & >()  , py::arg("C"),  py::arg("S") )
    // custom constructors
    // methods
        .def("Initialize",
             (void (Extrema_FuncExtCS::*)(  const Adaptor3d_Curve & ,   const Adaptor3d_Surface &  ) ) static_cast<void (Extrema_FuncExtCS::*)(  const Adaptor3d_Curve & ,   const Adaptor3d_Surface &  ) >(&Extrema_FuncExtCS::Initialize),
             R"#(sets the field mysurf of the function.)#"  , py::arg("C"),  py::arg("S")
          )
        .def("NbVariables",
             (int (Extrema_FuncExtCS::*)() const) static_cast<int (Extrema_FuncExtCS::*)() const>(&Extrema_FuncExtCS::NbVariables),
             R"#()#" 
          )
        .def("NbEquations",
             (int (Extrema_FuncExtCS::*)() const) static_cast<int (Extrema_FuncExtCS::*)() const>(&Extrema_FuncExtCS::NbEquations),
             R"#()#" 
          )
        .def("Value",
             (bool (Extrema_FuncExtCS::*)(  const math_Vector & ,  math_Vector &  ) ) static_cast<bool (Extrema_FuncExtCS::*)(  const math_Vector & ,  math_Vector &  ) >(&Extrema_FuncExtCS::Value),
             R"#(Calculation of Fi(U,V).)#"  , py::arg("UV"),  py::arg("F")
          )
        .def("Derivatives",
             (bool (Extrema_FuncExtCS::*)(  const math_Vector & ,  math_Matrix &  ) ) static_cast<bool (Extrema_FuncExtCS::*)(  const math_Vector & ,  math_Matrix &  ) >(&Extrema_FuncExtCS::Derivatives),
             R"#(Calculation of Fi'(U,V).)#"  , py::arg("UV"),  py::arg("DF")
          )
        .def("Values",
             (bool (Extrema_FuncExtCS::*)(  const math_Vector & ,  math_Vector & ,  math_Matrix &  ) ) static_cast<bool (Extrema_FuncExtCS::*)(  const math_Vector & ,  math_Vector & ,  math_Matrix &  ) >(&Extrema_FuncExtCS::Values),
             R"#(Calculation of Fi(U,V) and Fi'(U,V).)#"  , py::arg("UV"),  py::arg("F"),  py::arg("DF")
          )
        .def("GetStateNumber",
             (int (Extrema_FuncExtCS::*)() ) static_cast<int (Extrema_FuncExtCS::*)() >(&Extrema_FuncExtCS::GetStateNumber),
             R"#(Save the found extremum.)#" 
          )
        .def("NbExt",
             (int (Extrema_FuncExtCS::*)() const) static_cast<int (Extrema_FuncExtCS::*)() const>(&Extrema_FuncExtCS::NbExt),
             R"#(Return the number of found extrema.)#" 
          )
        .def("SquareDistance",
             (double (Extrema_FuncExtCS::*)(  const int  ) const) static_cast<double (Extrema_FuncExtCS::*)(  const int  ) const>(&Extrema_FuncExtCS::SquareDistance),
             R"#(Return the value of the Nth distance.)#"  , py::arg("N")
          )
        .def("PointOnCurve",
             ( const Extrema_POnCurv & (Extrema_FuncExtCS::*)(  const int  ) const) static_cast< const Extrema_POnCurv & (Extrema_FuncExtCS::*)(  const int  ) const>(&Extrema_FuncExtCS::PointOnCurve),
             R"#(Returns the Nth extremum on C.)#"  , py::arg("N")
          )
        .def("PointOnSurface",
             ( const Extrema_POnSurf & (Extrema_FuncExtCS::*)(  const int  ) const) static_cast< const Extrema_POnSurf & (Extrema_FuncExtCS::*)(  const int  ) const>(&Extrema_FuncExtCS::PointOnSurface),
             R"#(Return the Nth extremum on S.)#"  , py::arg("N")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("SquareDistances",
             (NCollection_Sequence<double> & (Extrema_FuncExtCS::*)() ) static_cast<NCollection_Sequence<double> & (Extrema_FuncExtCS::*)() >(&Extrema_FuncExtCS::SquareDistances),
             R"#(Change Sequence of SquareDistance)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("PointsOnCurve",
             (NCollection_Sequence<Extrema_POnCurv> & (Extrema_FuncExtCS::*)() ) static_cast<NCollection_Sequence<Extrema_POnCurv> & (Extrema_FuncExtCS::*)() >(&Extrema_FuncExtCS::PointsOnCurve),
             R"#(Change Sequence of PointOnCurv)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("PointsOnSurf",
             (NCollection_Sequence<Extrema_POnSurf> & (Extrema_FuncExtCS::*)() ) static_cast<NCollection_Sequence<Extrema_POnSurf> & (Extrema_FuncExtCS::*)() >(&Extrema_FuncExtCS::PointsOnSurf),
             R"#(Change Sequence of PointOnSurf)#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class Extrema_FuncExtSS from ./opencascade/Extrema_FuncExtSS.hxx
    klass = m.attr("Extrema_FuncExtSS");


    // nested enums

    static_cast<py::class_<Extrema_FuncExtSS , shared_ptr<Extrema_FuncExtSS>  , math_FunctionSetWithDerivatives >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const Adaptor3d_Surface &, const Adaptor3d_Surface & >()  , py::arg("S1"),  py::arg("S2") )
    // custom constructors
    // methods
        .def("Initialize",
             (void (Extrema_FuncExtSS::*)(  const Adaptor3d_Surface & ,   const Adaptor3d_Surface &  ) ) static_cast<void (Extrema_FuncExtSS::*)(  const Adaptor3d_Surface & ,   const Adaptor3d_Surface &  ) >(&Extrema_FuncExtSS::Initialize),
             R"#(sets the field mysurf of the function.)#"  , py::arg("S1"),  py::arg("S2")
          )
        .def("NbVariables",
             (int (Extrema_FuncExtSS::*)() const) static_cast<int (Extrema_FuncExtSS::*)() const>(&Extrema_FuncExtSS::NbVariables),
             R"#()#" 
          )
        .def("NbEquations",
             (int (Extrema_FuncExtSS::*)() const) static_cast<int (Extrema_FuncExtSS::*)() const>(&Extrema_FuncExtSS::NbEquations),
             R"#()#" 
          )
        .def("Value",
             (bool (Extrema_FuncExtSS::*)(  const math_Vector & ,  math_Vector &  ) ) static_cast<bool (Extrema_FuncExtSS::*)(  const math_Vector & ,  math_Vector &  ) >(&Extrema_FuncExtSS::Value),
             R"#(Calculate Fi(U,V).)#"  , py::arg("UV"),  py::arg("F")
          )
        .def("Derivatives",
             (bool (Extrema_FuncExtSS::*)(  const math_Vector & ,  math_Matrix &  ) ) static_cast<bool (Extrema_FuncExtSS::*)(  const math_Vector & ,  math_Matrix &  ) >(&Extrema_FuncExtSS::Derivatives),
             R"#(Calculate Fi'(U,V).)#"  , py::arg("UV"),  py::arg("DF")
          )
        .def("Values",
             (bool (Extrema_FuncExtSS::*)(  const math_Vector & ,  math_Vector & ,  math_Matrix &  ) ) static_cast<bool (Extrema_FuncExtSS::*)(  const math_Vector & ,  math_Vector & ,  math_Matrix &  ) >(&Extrema_FuncExtSS::Values),
             R"#(Calculate Fi(U,V) and Fi'(U,V).)#"  , py::arg("UV"),  py::arg("F"),  py::arg("DF")
          )
        .def("GetStateNumber",
             (int (Extrema_FuncExtSS::*)() ) static_cast<int (Extrema_FuncExtSS::*)() >(&Extrema_FuncExtSS::GetStateNumber),
             R"#(Save the found extremum.)#" 
          )
        .def("NbExt",
             (int (Extrema_FuncExtSS::*)() const) static_cast<int (Extrema_FuncExtSS::*)() const>(&Extrema_FuncExtSS::NbExt),
             R"#(Return the number of found extrema.)#" 
          )
        .def("SquareDistance",
             (double (Extrema_FuncExtSS::*)(  const int  ) const) static_cast<double (Extrema_FuncExtSS::*)(  const int  ) const>(&Extrema_FuncExtSS::SquareDistance),
             R"#(Return the value of the Nth distance.)#"  , py::arg("N")
          )
        .def("PointOnS1",
             ( const Extrema_POnSurf & (Extrema_FuncExtSS::*)(  const int  ) const) static_cast< const Extrema_POnSurf & (Extrema_FuncExtSS::*)(  const int  ) const>(&Extrema_FuncExtSS::PointOnS1),
             R"#(Return the Nth extremum on S1.)#"  , py::arg("N")
          )
        .def("PointOnS2",
             ( const Extrema_POnSurf & (Extrema_FuncExtSS::*)(  const int  ) const) static_cast< const Extrema_POnSurf & (Extrema_FuncExtSS::*)(  const int  ) const>(&Extrema_FuncExtSS::PointOnS2),
             R"#(Renvoie le Nieme extremum sur S2.)#"  , py::arg("N")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Extrema_FuncPSDist from ./opencascade/Extrema_FuncPSDist.hxx
    klass = m.attr("Extrema_FuncPSDist");


    // nested enums

    static_cast<py::class_<Extrema_FuncPSDist , shared_ptr<Extrema_FuncPSDist>  , math_MultipleVarFunctionWithGradient >>(klass)
    // constructors
        .def(py::init<  const Adaptor3d_Surface &, const gp_Pnt & >()  , py::arg("theS"),  py::arg("theP") )
    // custom constructors
    // methods
        .def("NbVariables",
             (int (Extrema_FuncPSDist::*)() const) static_cast<int (Extrema_FuncPSDist::*)() const>(&Extrema_FuncPSDist::NbVariables),
             R"#(Number of variables.)#" 
          )
        .def("Value",
             (bool (Extrema_FuncPSDist::*)(  const math_Vector & ,  double &  ) ) static_cast<bool (Extrema_FuncPSDist::*)(  const math_Vector & ,  double &  ) >(&Extrema_FuncPSDist::Value),
             R"#(Value.)#"  , py::arg("X"),  py::arg("F")
          )
        .def("Gradient",
             (bool (Extrema_FuncPSDist::*)(  const math_Vector & ,  math_Vector &  ) ) static_cast<bool (Extrema_FuncPSDist::*)(  const math_Vector & ,  math_Vector &  ) >(&Extrema_FuncPSDist::Gradient),
             R"#(Gradient.)#"  , py::arg("X"),  py::arg("G")
          )
        .def("Values",
             (bool (Extrema_FuncPSDist::*)(  const math_Vector & ,  double & ,  math_Vector &  ) ) static_cast<bool (Extrema_FuncPSDist::*)(  const math_Vector & ,  double & ,  math_Vector &  ) >(&Extrema_FuncPSDist::Values),
             R"#(Value and gradient.)#"  , py::arg("X"),  py::arg("F"),  py::arg("G")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Extrema_FuncPSNorm from ./opencascade/Extrema_FuncPSNorm.hxx
    klass = m.attr("Extrema_FuncPSNorm");


    // nested enums

    static_cast<py::class_<Extrema_FuncPSNorm , shared_ptr<Extrema_FuncPSNorm>  , math_FunctionSetWithDerivatives >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const gp_Pnt &, const Adaptor3d_Surface & >()  , py::arg("P"),  py::arg("S") )
    // custom constructors
    // methods
        .def("Initialize",
             (void (Extrema_FuncPSNorm::*)(  const Adaptor3d_Surface &  ) ) static_cast<void (Extrema_FuncPSNorm::*)(  const Adaptor3d_Surface &  ) >(&Extrema_FuncPSNorm::Initialize),
             R"#(sets the field mysurf of the function.)#"  , py::arg("S")
          )
        .def("SetPoint",
             (void (Extrema_FuncPSNorm::*)(  const gp_Pnt &  ) ) static_cast<void (Extrema_FuncPSNorm::*)(  const gp_Pnt &  ) >(&Extrema_FuncPSNorm::SetPoint),
             R"#(sets the field mysurf of the function.)#"  , py::arg("P")
          )
        .def("NbVariables",
             (int (Extrema_FuncPSNorm::*)() const) static_cast<int (Extrema_FuncPSNorm::*)() const>(&Extrema_FuncPSNorm::NbVariables),
             R"#()#" 
          )
        .def("NbEquations",
             (int (Extrema_FuncPSNorm::*)() const) static_cast<int (Extrema_FuncPSNorm::*)() const>(&Extrema_FuncPSNorm::NbEquations),
             R"#()#" 
          )
        .def("Value",
             (bool (Extrema_FuncPSNorm::*)(  const math_Vector & ,  math_Vector &  ) ) static_cast<bool (Extrema_FuncPSNorm::*)(  const math_Vector & ,  math_Vector &  ) >(&Extrema_FuncPSNorm::Value),
             R"#(Calculate Fi(U,V).)#"  , py::arg("UV"),  py::arg("F")
          )
        .def("Derivatives",
             (bool (Extrema_FuncPSNorm::*)(  const math_Vector & ,  math_Matrix &  ) ) static_cast<bool (Extrema_FuncPSNorm::*)(  const math_Vector & ,  math_Matrix &  ) >(&Extrema_FuncPSNorm::Derivatives),
             R"#(Calculate Fi'(U,V).)#"  , py::arg("UV"),  py::arg("DF")
          )
        .def("Values",
             (bool (Extrema_FuncPSNorm::*)(  const math_Vector & ,  math_Vector & ,  math_Matrix &  ) ) static_cast<bool (Extrema_FuncPSNorm::*)(  const math_Vector & ,  math_Vector & ,  math_Matrix &  ) >(&Extrema_FuncPSNorm::Values),
             R"#(Calculate Fi(U,V) and Fi'(U,V).)#"  , py::arg("UV"),  py::arg("F"),  py::arg("DF")
          )
        .def("GetStateNumber",
             (int (Extrema_FuncPSNorm::*)() ) static_cast<int (Extrema_FuncPSNorm::*)() >(&Extrema_FuncPSNorm::GetStateNumber),
             R"#(Save the found extremum.)#" 
          )
        .def("NbExt",
             (int (Extrema_FuncPSNorm::*)() const) static_cast<int (Extrema_FuncPSNorm::*)() const>(&Extrema_FuncPSNorm::NbExt),
             R"#(Return the number of found extrema.)#" 
          )
        .def("SquareDistance",
             (double (Extrema_FuncPSNorm::*)(  const int  ) const) static_cast<double (Extrema_FuncPSNorm::*)(  const int  ) const>(&Extrema_FuncPSNorm::SquareDistance),
             R"#(Return the value of the Nth distance.)#"  , py::arg("N")
          )
        .def("Point",
             ( const Extrema_POnSurf & (Extrema_FuncPSNorm::*)(  const int  ) const) static_cast< const Extrema_POnSurf & (Extrema_FuncPSNorm::*)(  const int  ) const>(&Extrema_FuncPSNorm::Point),
             R"#(Returns the Nth extremum.)#"  , py::arg("N")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Extrema_GenExtCS from ./opencascade/Extrema_GenExtCS.hxx
    klass = m.attr("Extrema_GenExtCS");


    // nested enums

    static_cast<py::class_<Extrema_GenExtCS , shared_ptr<Extrema_GenExtCS>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const Adaptor3d_Curve &, const Adaptor3d_Surface &, const int, const int, const int, const double, const double >()  , py::arg("C"),  py::arg("S"),  py::arg("NbT"),  py::arg("NbU"),  py::arg("NbV"),  py::arg("Tol1"),  py::arg("Tol2") )
        .def(py::init<  const Adaptor3d_Curve &, const Adaptor3d_Surface &, const int, const int, const int, const double, const double, const double, const double, const double, const double, const double, const double >()  , py::arg("C"),  py::arg("S"),  py::arg("NbT"),  py::arg("NbU"),  py::arg("NbV"),  py::arg("tmin"),  py::arg("tsup"),  py::arg("Umin"),  py::arg("Usup"),  py::arg("Vmin"),  py::arg("Vsup"),  py::arg("Tol1"),  py::arg("Tol2") )
    // custom constructors
    // methods
        .def("Initialize",
             (void (Extrema_GenExtCS::*)(  const Adaptor3d_Surface & ,   const int ,   const int ,   const double  ) ) static_cast<void (Extrema_GenExtCS::*)(  const Adaptor3d_Surface & ,   const int ,   const int ,   const double  ) >(&Extrema_GenExtCS::Initialize),
             R"#()#"  , py::arg("S"),  py::arg("NbU"),  py::arg("NbV"),  py::arg("Tol2")
          )
        .def("Initialize",
             (void (Extrema_GenExtCS::*)(  const Adaptor3d_Surface & ,   const int ,   const int ,   const double ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<void (Extrema_GenExtCS::*)(  const Adaptor3d_Surface & ,   const int ,   const int ,   const double ,   const double ,   const double ,   const double ,   const double  ) >(&Extrema_GenExtCS::Initialize),
             R"#()#"  , py::arg("S"),  py::arg("NbU"),  py::arg("NbV"),  py::arg("Umin"),  py::arg("Usup"),  py::arg("Vmin"),  py::arg("Vsup"),  py::arg("Tol2")
          )
        .def("Perform",
             (void (Extrema_GenExtCS::*)(  const Adaptor3d_Curve & ,   const int ,   const double  ) ) static_cast<void (Extrema_GenExtCS::*)(  const Adaptor3d_Curve & ,   const int ,   const double  ) >(&Extrema_GenExtCS::Perform),
             R"#(the algorithm is done with S An exception is raised if the fields have not been initialized.)#"  , py::arg("C"),  py::arg("NbT"),  py::arg("Tol1")
          )
        .def("Perform",
             (void (Extrema_GenExtCS::*)(  const Adaptor3d_Curve & ,   const int ,   const double ,   const double ,   const double  ) ) static_cast<void (Extrema_GenExtCS::*)(  const Adaptor3d_Curve & ,   const int ,   const double ,   const double ,   const double  ) >(&Extrema_GenExtCS::Perform),
             R"#(the algorithm is done with C An exception is raised if the fields have not been initialized.)#"  , py::arg("C"),  py::arg("NbT"),  py::arg("tmin"),  py::arg("tsup"),  py::arg("Tol1")
          )
        .def("IsDone",
             (bool (Extrema_GenExtCS::*)() const) static_cast<bool (Extrema_GenExtCS::*)() const>(&Extrema_GenExtCS::IsDone),
             R"#(Returns True if the distances are found.)#" 
          )
        .def("NbExt",
             (int (Extrema_GenExtCS::*)() const) static_cast<int (Extrema_GenExtCS::*)() const>(&Extrema_GenExtCS::NbExt),
             R"#(Returns the number of extremum distances.)#" 
          )
        .def("SquareDistance",
             (double (Extrema_GenExtCS::*)(  const int  ) const) static_cast<double (Extrema_GenExtCS::*)(  const int  ) const>(&Extrema_GenExtCS::SquareDistance),
             R"#(Returns the value of the Nth resulting square distance.)#"  , py::arg("N")
          )
        .def("PointOnCurve",
             ( const Extrema_POnCurv & (Extrema_GenExtCS::*)(  const int  ) const) static_cast< const Extrema_POnCurv & (Extrema_GenExtCS::*)(  const int  ) const>(&Extrema_GenExtCS::PointOnCurve),
             R"#(Returns the point of the Nth resulting distance.)#"  , py::arg("N")
          )
        .def("PointOnSurface",
             ( const Extrema_POnSurf & (Extrema_GenExtCS::*)(  const int  ) const) static_cast< const Extrema_POnSurf & (Extrema_GenExtCS::*)(  const int  ) const>(&Extrema_GenExtCS::PointOnSurface),
             R"#(Returns the point of the Nth resulting distance.)#"  , py::arg("N")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Extrema_GenExtPS from ./opencascade/Extrema_GenExtPS.hxx
    klass = m.attr("Extrema_GenExtPS");


    // nested enums

    static_cast<py::class_<Extrema_GenExtPS , shared_ptr<Extrema_GenExtPS>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const gp_Pnt &, const Adaptor3d_Surface &, const int, const int, const double, const double, const Extrema_ExtFlag, const Extrema_ExtAlgo >()  , py::arg("P"),  py::arg("S"),  py::arg("NbU"),  py::arg("NbV"),  py::arg("TolU"),  py::arg("TolV"),  py::arg("F")=static_cast< const Extrema_ExtFlag>(Extrema_ExtFlag_MINMAX),  py::arg("A")=static_cast< const Extrema_ExtAlgo>(Extrema_ExtAlgo_Grad) )
        .def(py::init<  const gp_Pnt &, const Adaptor3d_Surface &, const int, const int, const double, const double, const double, const double, const double, const double, const Extrema_ExtFlag, const Extrema_ExtAlgo >()  , py::arg("P"),  py::arg("S"),  py::arg("NbU"),  py::arg("NbV"),  py::arg("Umin"),  py::arg("Usup"),  py::arg("Vmin"),  py::arg("Vsup"),  py::arg("TolU"),  py::arg("TolV"),  py::arg("F")=static_cast< const Extrema_ExtFlag>(Extrema_ExtFlag_MINMAX),  py::arg("A")=static_cast< const Extrema_ExtAlgo>(Extrema_ExtAlgo_Grad) )
    // custom constructors
    // methods
        .def("Initialize",
             (void (Extrema_GenExtPS::*)(  const Adaptor3d_Surface & ,   const int ,   const int ,   const double ,   const double  ) ) static_cast<void (Extrema_GenExtPS::*)(  const Adaptor3d_Surface & ,   const int ,   const int ,   const double ,   const double  ) >(&Extrema_GenExtPS::Initialize),
             R"#()#"  , py::arg("S"),  py::arg("NbU"),  py::arg("NbV"),  py::arg("TolU"),  py::arg("TolV")
          )
        .def("Initialize",
             (void (Extrema_GenExtPS::*)(  const Adaptor3d_Surface & ,   const int ,   const int ,   const double ,   const double ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<void (Extrema_GenExtPS::*)(  const Adaptor3d_Surface & ,   const int ,   const int ,   const double ,   const double ,   const double ,   const double ,   const double ,   const double  ) >(&Extrema_GenExtPS::Initialize),
             R"#()#"  , py::arg("S"),  py::arg("NbU"),  py::arg("NbV"),  py::arg("Umin"),  py::arg("Usup"),  py::arg("Vmin"),  py::arg("Vsup"),  py::arg("TolU"),  py::arg("TolV")
          )
        .def("Perform",
             (void (Extrema_GenExtPS::*)(  const gp_Pnt &  ) ) static_cast<void (Extrema_GenExtPS::*)(  const gp_Pnt &  ) >(&Extrema_GenExtPS::Perform),
             R"#(the algorithm is done with the point P. An exception is raised if the fields have not been initialized.)#"  , py::arg("P")
          )
        .def("SetFlag",
             (void (Extrema_GenExtPS::*)(  const Extrema_ExtFlag  ) ) static_cast<void (Extrema_GenExtPS::*)(  const Extrema_ExtFlag  ) >(&Extrema_GenExtPS::SetFlag),
             R"#()#"  , py::arg("F")
          )
        .def("SetAlgo",
             (void (Extrema_GenExtPS::*)(  const Extrema_ExtAlgo  ) ) static_cast<void (Extrema_GenExtPS::*)(  const Extrema_ExtAlgo  ) >(&Extrema_GenExtPS::SetAlgo),
             R"#()#"  , py::arg("A")
          )
        .def("IsDone",
             (bool (Extrema_GenExtPS::*)() const) static_cast<bool (Extrema_GenExtPS::*)() const>(&Extrema_GenExtPS::IsDone),
             R"#(Returns True if the distances are found.)#" 
          )
        .def("NbExt",
             (int (Extrema_GenExtPS::*)() const) static_cast<int (Extrema_GenExtPS::*)() const>(&Extrema_GenExtPS::NbExt),
             R"#(Returns the number of extremum distances.)#" 
          )
        .def("SquareDistance",
             (double (Extrema_GenExtPS::*)(  const int  ) const) static_cast<double (Extrema_GenExtPS::*)(  const int  ) const>(&Extrema_GenExtPS::SquareDistance),
             R"#(Returns the value of the Nth resulting square distance.)#"  , py::arg("N")
          )
        .def("Point",
             ( const Extrema_POnSurf & (Extrema_GenExtPS::*)(  const int  ) const) static_cast< const Extrema_POnSurf & (Extrema_GenExtPS::*)(  const int  ) const>(&Extrema_GenExtPS::Point),
             R"#(Returns the point of the Nth resulting distance.)#"  , py::arg("N")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Extrema_GenExtSS from ./opencascade/Extrema_GenExtSS.hxx
    klass = m.attr("Extrema_GenExtSS");


    // nested enums

    static_cast<py::class_<Extrema_GenExtSS , shared_ptr<Extrema_GenExtSS>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const Adaptor3d_Surface &, const Adaptor3d_Surface &, const int, const int, const double, const double >()  , py::arg("S1"),  py::arg("S2"),  py::arg("NbU"),  py::arg("NbV"),  py::arg("Tol1"),  py::arg("Tol2") )
        .def(py::init<  const Adaptor3d_Surface &, const Adaptor3d_Surface &, const int, const int, const double, const double, const double, const double, const double, const double, const double, const double, const double, const double >()  , py::arg("S1"),  py::arg("S2"),  py::arg("NbU"),  py::arg("NbV"),  py::arg("U1min"),  py::arg("U1sup"),  py::arg("V1min"),  py::arg("V1sup"),  py::arg("U2min"),  py::arg("U2sup"),  py::arg("V2min"),  py::arg("V2sup"),  py::arg("Tol1"),  py::arg("Tol2") )
    // custom constructors
    // methods
        .def("Initialize",
             (void (Extrema_GenExtSS::*)(  const Adaptor3d_Surface & ,   const int ,   const int ,   const double  ) ) static_cast<void (Extrema_GenExtSS::*)(  const Adaptor3d_Surface & ,   const int ,   const int ,   const double  ) >(&Extrema_GenExtSS::Initialize),
             R"#()#"  , py::arg("S2"),  py::arg("NbU"),  py::arg("NbV"),  py::arg("Tol2")
          )
        .def("Initialize",
             (void (Extrema_GenExtSS::*)(  const Adaptor3d_Surface & ,   const int ,   const int ,   const double ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<void (Extrema_GenExtSS::*)(  const Adaptor3d_Surface & ,   const int ,   const int ,   const double ,   const double ,   const double ,   const double ,   const double  ) >(&Extrema_GenExtSS::Initialize),
             R"#()#"  , py::arg("S2"),  py::arg("NbU"),  py::arg("NbV"),  py::arg("U2min"),  py::arg("U2sup"),  py::arg("V2min"),  py::arg("V2sup"),  py::arg("Tol2")
          )
        .def("Perform",
             (void (Extrema_GenExtSS::*)(  const Adaptor3d_Surface & ,   const double  ) ) static_cast<void (Extrema_GenExtSS::*)(  const Adaptor3d_Surface & ,   const double  ) >(&Extrema_GenExtSS::Perform),
             R"#(the algorithm is done with S1 An exception is raised if the fields have not been initialized.)#"  , py::arg("S1"),  py::arg("Tol1")
          )
        .def("Perform",
             (void (Extrema_GenExtSS::*)(  const Adaptor3d_Surface & ,   const double ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<void (Extrema_GenExtSS::*)(  const Adaptor3d_Surface & ,   const double ,   const double ,   const double ,   const double ,   const double  ) >(&Extrema_GenExtSS::Perform),
             R"#(the algorithm is done withS1 An exception is raised if the fields have not been initialized.)#"  , py::arg("S1"),  py::arg("U1min"),  py::arg("U1sup"),  py::arg("V1min"),  py::arg("V1sup"),  py::arg("Tol1")
          )
        .def("IsDone",
             (bool (Extrema_GenExtSS::*)() const) static_cast<bool (Extrema_GenExtSS::*)() const>(&Extrema_GenExtSS::IsDone),
             R"#(Returns True if the distances are found.)#" 
          )
        .def("NbExt",
             (int (Extrema_GenExtSS::*)() const) static_cast<int (Extrema_GenExtSS::*)() const>(&Extrema_GenExtSS::NbExt),
             R"#(Returns the number of extremum distances.)#" 
          )
        .def("SquareDistance",
             (double (Extrema_GenExtSS::*)(  const int  ) const) static_cast<double (Extrema_GenExtSS::*)(  const int  ) const>(&Extrema_GenExtSS::SquareDistance),
             R"#(Returns the value of the Nth resulting square distance.)#"  , py::arg("N")
          )
        .def("PointOnS1",
             ( const Extrema_POnSurf & (Extrema_GenExtSS::*)(  const int  ) const) static_cast< const Extrema_POnSurf & (Extrema_GenExtSS::*)(  const int  ) const>(&Extrema_GenExtSS::PointOnS1),
             R"#(Returns the point of the Nth resulting distance.)#"  , py::arg("N")
          )
        .def("PointOnS2",
             ( const Extrema_POnSurf & (Extrema_GenExtSS::*)(  const int  ) const) static_cast< const Extrema_POnSurf & (Extrema_GenExtSS::*)(  const int  ) const>(&Extrema_GenExtSS::PointOnS2),
             R"#(Returns the point of the Nth resulting distance.)#"  , py::arg("N")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Extrema_GenLocateExtCS from ./opencascade/Extrema_GenLocateExtCS.hxx
    klass = m.attr("Extrema_GenLocateExtCS");


    // nested enums

    static_cast<py::class_<Extrema_GenLocateExtCS , shared_ptr<Extrema_GenLocateExtCS>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const Adaptor3d_Curve &, const Adaptor3d_Surface &, const double, const double, const double, const double, const double >()  , py::arg("C"),  py::arg("S"),  py::arg("T"),  py::arg("U"),  py::arg("V"),  py::arg("Tol1"),  py::arg("Tol2") )
    // custom constructors
    // methods
        .def("Perform",
             (void (Extrema_GenLocateExtCS::*)(  const Adaptor3d_Curve & ,   const Adaptor3d_Surface & ,   const double ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<void (Extrema_GenLocateExtCS::*)(  const Adaptor3d_Curve & ,   const Adaptor3d_Surface & ,   const double ,   const double ,   const double ,   const double ,   const double  ) >(&Extrema_GenLocateExtCS::Perform),
             R"#()#"  , py::arg("C"),  py::arg("S"),  py::arg("T"),  py::arg("U"),  py::arg("V"),  py::arg("Tol1"),  py::arg("Tol2")
          )
        .def("IsDone",
             (bool (Extrema_GenLocateExtCS::*)() const) static_cast<bool (Extrema_GenLocateExtCS::*)() const>(&Extrema_GenLocateExtCS::IsDone),
             R"#(Returns True if the distance is found.)#" 
          )
        .def("SquareDistance",
             (double (Extrema_GenLocateExtCS::*)() const) static_cast<double (Extrema_GenLocateExtCS::*)() const>(&Extrema_GenLocateExtCS::SquareDistance),
             R"#(Returns the value of the extremum square distance.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("PointOnCurve",
             ( const Extrema_POnCurv & (Extrema_GenLocateExtCS::*)() const) static_cast< const Extrema_POnCurv & (Extrema_GenLocateExtCS::*)() const>(&Extrema_GenLocateExtCS::PointOnCurve),
             R"#(Returns the point of the extremum distance on C.)#"
             
         )
       .def("PointOnSurface",
             ( const Extrema_POnSurf & (Extrema_GenLocateExtCS::*)() const) static_cast< const Extrema_POnSurf & (Extrema_GenLocateExtCS::*)() const>(&Extrema_GenLocateExtCS::PointOnSurface),
             R"#(Returns the point of the extremum distance on S.)#"
             
         )
;

    // Class Extrema_GenLocateExtPS from ./opencascade/Extrema_GenLocateExtPS.hxx
    klass = m.attr("Extrema_GenLocateExtPS");


    // nested enums

    static_cast<py::class_<Extrema_GenLocateExtPS , shared_ptr<Extrema_GenLocateExtPS>  >>(klass)
    // constructors
        .def(py::init<  const Adaptor3d_Surface &, const double, const double >()  , py::arg("theS"),  py::arg("theTolU")=static_cast< const double>(Precision :: PConfusion ( )),  py::arg("theTolV")=static_cast< const double>(Precision :: PConfusion ( )) )
    // custom constructors
    // methods
        .def("Perform",
             (void (Extrema_GenLocateExtPS::*)(  const gp_Pnt & ,   const double ,   const double ,   const bool  ) ) static_cast<void (Extrema_GenLocateExtPS::*)(  const gp_Pnt & ,   const double ,   const double ,   const bool  ) >(&Extrema_GenLocateExtPS::Perform),
             R"#(Calculates the extrema between the point and the surface using a close point. The close point is defined by the parameter values theU0 and theV0. Type of the algorithm depends on the isDistanceCriteria flag. If flag value is false - normal projection criteria will be used. If flag value is true - distance criteria will be used.)#"  , py::arg("theP"),  py::arg("theU0"),  py::arg("theV0"),  py::arg("isDistanceCriteria")=static_cast< const bool>(false)
          )
        .def("IsDone",
             (bool (Extrema_GenLocateExtPS::*)() const) static_cast<bool (Extrema_GenLocateExtPS::*)() const>(&Extrema_GenLocateExtPS::IsDone),
             R"#(Returns True if the distance is found.)#" 
          )
        .def("SquareDistance",
             (double (Extrema_GenLocateExtPS::*)() const) static_cast<double (Extrema_GenLocateExtPS::*)() const>(&Extrema_GenLocateExtPS::SquareDistance),
             R"#(Returns the value of the extremum square distance.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("IsMinDist_s",
                    (bool (*)(  const gp_Pnt & ,   const Adaptor3d_Surface & ,   const double ,   const double  ) ) static_cast<bool (*)(  const gp_Pnt & ,   const Adaptor3d_Surface & ,   const double ,   const double  ) >(&Extrema_GenLocateExtPS::IsMinDist),
                    R"#(Returns True if UV point theU0, theV0 is point of local minimum of square distance between point theP and points theS(U, V), U, V are in small area around theU0, theV0)#"  , py::arg("theP"),  py::arg("theS"),  py::arg("theU0"),  py::arg("theV0")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Point",
             ( const Extrema_POnSurf & (Extrema_GenLocateExtPS::*)() const) static_cast< const Extrema_POnSurf & (Extrema_GenLocateExtPS::*)() const>(&Extrema_GenLocateExtPS::Point),
             R"#(Returns the point of the extremum distance.)#"
             
         )
;

    // Class Extrema_GenLocateExtSS from ./opencascade/Extrema_GenLocateExtSS.hxx
    klass = m.attr("Extrema_GenLocateExtSS");


    // nested enums

    static_cast<py::class_<Extrema_GenLocateExtSS , shared_ptr<Extrema_GenLocateExtSS>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const Adaptor3d_Surface &, const Adaptor3d_Surface &, const double, const double, const double, const double, const double, const double >()  , py::arg("S1"),  py::arg("S2"),  py::arg("U1"),  py::arg("V1"),  py::arg("U2"),  py::arg("V2"),  py::arg("Tol1"),  py::arg("Tol2") )
    // custom constructors
    // methods
        .def("Perform",
             (void (Extrema_GenLocateExtSS::*)(  const Adaptor3d_Surface & ,   const Adaptor3d_Surface & ,   const double ,   const double ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<void (Extrema_GenLocateExtSS::*)(  const Adaptor3d_Surface & ,   const Adaptor3d_Surface & ,   const double ,   const double ,   const double ,   const double ,   const double ,   const double  ) >(&Extrema_GenLocateExtSS::Perform),
             R"#()#"  , py::arg("S1"),  py::arg("S2"),  py::arg("U1"),  py::arg("V1"),  py::arg("U2"),  py::arg("V2"),  py::arg("Tol1"),  py::arg("Tol2")
          )
        .def("IsDone",
             (bool (Extrema_GenLocateExtSS::*)() const) static_cast<bool (Extrema_GenLocateExtSS::*)() const>(&Extrema_GenLocateExtSS::IsDone),
             R"#(Returns True if the distance is found.)#" 
          )
        .def("SquareDistance",
             (double (Extrema_GenLocateExtSS::*)() const) static_cast<double (Extrema_GenLocateExtSS::*)() const>(&Extrema_GenLocateExtSS::SquareDistance),
             R"#(Returns the value of the extremum square distance.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("PointOnS1",
             ( const Extrema_POnSurf & (Extrema_GenLocateExtSS::*)() const) static_cast< const Extrema_POnSurf & (Extrema_GenLocateExtSS::*)() const>(&Extrema_GenLocateExtSS::PointOnS1),
             R"#(Returns the point of the extremum distance on S1.)#"
             
         )
       .def("PointOnS2",
             ( const Extrema_POnSurf & (Extrema_GenLocateExtSS::*)() const) static_cast< const Extrema_POnSurf & (Extrema_GenLocateExtSS::*)() const>(&Extrema_GenLocateExtSS::PointOnS2),
             R"#(Returns the point of the extremum distance on S2.)#"
             
         )
;

    // Class Extrema_GlobOptFuncCCC0 from ./opencascade/Extrema_GlobOptFuncCC.hxx
    klass = m.attr("Extrema_GlobOptFuncCCC0");


    // nested enums

    static_cast<py::class_<Extrema_GlobOptFuncCCC0 , shared_ptr<Extrema_GlobOptFuncCCC0>  , math_MultipleVarFunction >>(klass)
    // constructors
        .def(py::init<  const Adaptor2d_Curve2d &, const Adaptor2d_Curve2d & >()  , py::arg("C1"),  py::arg("C2") )
        .def(py::init<  const Adaptor3d_Curve &, const Adaptor3d_Curve & >()  , py::arg("C1"),  py::arg("C2") )
    // custom constructors
    // methods
        .def("NbVariables",
             (int (Extrema_GlobOptFuncCCC0::*)() const) static_cast<int (Extrema_GlobOptFuncCCC0::*)() const>(&Extrema_GlobOptFuncCCC0::NbVariables),
             R"#()#" 
          )
        .def("Value",
             (bool (Extrema_GlobOptFuncCCC0::*)(  const math_Vector & ,  double &  ) ) static_cast<bool (Extrema_GlobOptFuncCCC0::*)(  const math_Vector & ,  double &  ) >(&Extrema_GlobOptFuncCCC0::Value),
             R"#()#"  , py::arg("X"),  py::arg("F")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Extrema_GlobOptFuncCCC1 from ./opencascade/Extrema_GlobOptFuncCC.hxx
    klass = m.attr("Extrema_GlobOptFuncCCC1");


    // nested enums

    static_cast<py::class_<Extrema_GlobOptFuncCCC1 , shared_ptr<Extrema_GlobOptFuncCCC1>  , math_MultipleVarFunctionWithGradient >>(klass)
    // constructors
        .def(py::init<  const Adaptor2d_Curve2d &, const Adaptor2d_Curve2d & >()  , py::arg("C1"),  py::arg("C2") )
        .def(py::init<  const Adaptor3d_Curve &, const Adaptor3d_Curve & >()  , py::arg("C1"),  py::arg("C2") )
    // custom constructors
    // methods
        .def("NbVariables",
             (int (Extrema_GlobOptFuncCCC1::*)() const) static_cast<int (Extrema_GlobOptFuncCCC1::*)() const>(&Extrema_GlobOptFuncCCC1::NbVariables),
             R"#()#" 
          )
        .def("Value",
             (bool (Extrema_GlobOptFuncCCC1::*)(  const math_Vector & ,  double &  ) ) static_cast<bool (Extrema_GlobOptFuncCCC1::*)(  const math_Vector & ,  double &  ) >(&Extrema_GlobOptFuncCCC1::Value),
             R"#()#"  , py::arg("X"),  py::arg("F")
          )
        .def("Gradient",
             (bool (Extrema_GlobOptFuncCCC1::*)(  const math_Vector & ,  math_Vector &  ) ) static_cast<bool (Extrema_GlobOptFuncCCC1::*)(  const math_Vector & ,  math_Vector &  ) >(&Extrema_GlobOptFuncCCC1::Gradient),
             R"#()#"  , py::arg("X"),  py::arg("G")
          )
        .def("Values",
             (bool (Extrema_GlobOptFuncCCC1::*)(  const math_Vector & ,  double & ,  math_Vector &  ) ) static_cast<bool (Extrema_GlobOptFuncCCC1::*)(  const math_Vector & ,  double & ,  math_Vector &  ) >(&Extrema_GlobOptFuncCCC1::Values),
             R"#()#"  , py::arg("X"),  py::arg("F"),  py::arg("G")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Extrema_GlobOptFuncCCC2 from ./opencascade/Extrema_GlobOptFuncCC.hxx
    klass = m.attr("Extrema_GlobOptFuncCCC2");


    // nested enums

    static_cast<py::class_<Extrema_GlobOptFuncCCC2 , shared_ptr<Extrema_GlobOptFuncCCC2>  , math_MultipleVarFunctionWithHessian >>(klass)
    // constructors
        .def(py::init<  const Adaptor2d_Curve2d &, const Adaptor2d_Curve2d & >()  , py::arg("C1"),  py::arg("C2") )
        .def(py::init<  const Adaptor3d_Curve &, const Adaptor3d_Curve & >()  , py::arg("C1"),  py::arg("C2") )
    // custom constructors
    // methods
        .def("NbVariables",
             (int (Extrema_GlobOptFuncCCC2::*)() const) static_cast<int (Extrema_GlobOptFuncCCC2::*)() const>(&Extrema_GlobOptFuncCCC2::NbVariables),
             R"#()#" 
          )
        .def("Value",
             (bool (Extrema_GlobOptFuncCCC2::*)(  const math_Vector & ,  double &  ) ) static_cast<bool (Extrema_GlobOptFuncCCC2::*)(  const math_Vector & ,  double &  ) >(&Extrema_GlobOptFuncCCC2::Value),
             R"#()#"  , py::arg("X"),  py::arg("F")
          )
        .def("Gradient",
             (bool (Extrema_GlobOptFuncCCC2::*)(  const math_Vector & ,  math_Vector &  ) ) static_cast<bool (Extrema_GlobOptFuncCCC2::*)(  const math_Vector & ,  math_Vector &  ) >(&Extrema_GlobOptFuncCCC2::Gradient),
             R"#()#"  , py::arg("X"),  py::arg("G")
          )
        .def("Values",
             (bool (Extrema_GlobOptFuncCCC2::*)(  const math_Vector & ,  double & ,  math_Vector &  ) ) static_cast<bool (Extrema_GlobOptFuncCCC2::*)(  const math_Vector & ,  double & ,  math_Vector &  ) >(&Extrema_GlobOptFuncCCC2::Values),
             R"#()#"  , py::arg("X"),  py::arg("F"),  py::arg("G")
          )
        .def("Values",
             (bool (Extrema_GlobOptFuncCCC2::*)(  const math_Vector & ,  double & ,  math_Vector & ,  math_Matrix &  ) ) static_cast<bool (Extrema_GlobOptFuncCCC2::*)(  const math_Vector & ,  double & ,  math_Vector & ,  math_Matrix &  ) >(&Extrema_GlobOptFuncCCC2::Values),
             R"#()#"  , py::arg("X"),  py::arg("F"),  py::arg("G"),  py::arg("H")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Extrema_GlobOptFuncCQuadric from ./opencascade/Extrema_GlobOptFuncCQuadric.hxx
    klass = m.attr("Extrema_GlobOptFuncCQuadric");


    // nested enums

    static_cast<py::class_<Extrema_GlobOptFuncCQuadric , shared_ptr<Extrema_GlobOptFuncCQuadric>  , math_MultipleVarFunction >>(klass)
    // constructors
        .def(py::init<  const Adaptor3d_Curve * >()  , py::arg("C") )
        .def(py::init<  const Adaptor3d_Curve *, const Adaptor3d_Surface * >()  , py::arg("C"),  py::arg("S") )
        .def(py::init<  const Adaptor3d_Curve *, const double, const double >()  , py::arg("C"),  py::arg("theTf"),  py::arg("theTl") )
    // custom constructors
    // methods
        .def("LoadQuad",
             (void (Extrema_GlobOptFuncCQuadric::*)(  const Adaptor3d_Surface * ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<void (Extrema_GlobOptFuncCQuadric::*)(  const Adaptor3d_Surface * ,   const double ,   const double ,   const double ,   const double  ) >(&Extrema_GlobOptFuncCQuadric::LoadQuad),
             R"#()#"  , py::arg("S"),  py::arg("theUf"),  py::arg("theUl"),  py::arg("theVf"),  py::arg("theVl")
          )
        .def("NbVariables",
             (int (Extrema_GlobOptFuncCQuadric::*)() const) static_cast<int (Extrema_GlobOptFuncCQuadric::*)() const>(&Extrema_GlobOptFuncCQuadric::NbVariables),
             R"#()#" 
          )
        .def("Value",
             (bool (Extrema_GlobOptFuncCQuadric::*)(  const math_Vector & ,  double &  ) ) static_cast<bool (Extrema_GlobOptFuncCQuadric::*)(  const math_Vector & ,  double &  ) >(&Extrema_GlobOptFuncCQuadric::Value),
             R"#()#"  , py::arg("theX"),  py::arg("theF")
          )
        .def("QuadricParameters",
             (void (Extrema_GlobOptFuncCQuadric::*)(  const math_Vector & ,  math_Vector &  ) const) static_cast<void (Extrema_GlobOptFuncCQuadric::*)(  const math_Vector & ,  math_Vector &  ) const>(&Extrema_GlobOptFuncCQuadric::QuadricParameters),
             R"#(Parameters of quadric for point on curve defined by theCT)#"  , py::arg("theCT"),  py::arg("theUV")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Extrema_GlobOptFuncCS from ./opencascade/Extrema_GlobOptFuncCS.hxx
    klass = m.attr("Extrema_GlobOptFuncCS");


    // nested enums

    static_cast<py::class_<Extrema_GlobOptFuncCS , shared_ptr<Extrema_GlobOptFuncCS>  , math_MultipleVarFunctionWithHessian >>(klass)
    // constructors
        .def(py::init<  const Adaptor3d_Curve *, const Adaptor3d_Surface * >()  , py::arg("C"),  py::arg("S") )
    // custom constructors
    // methods
        .def("NbVariables",
             (int (Extrema_GlobOptFuncCS::*)() const) static_cast<int (Extrema_GlobOptFuncCS::*)() const>(&Extrema_GlobOptFuncCS::NbVariables),
             R"#()#" 
          )
        .def("Value",
             (bool (Extrema_GlobOptFuncCS::*)(  const math_Vector & ,  double &  ) ) static_cast<bool (Extrema_GlobOptFuncCS::*)(  const math_Vector & ,  double &  ) >(&Extrema_GlobOptFuncCS::Value),
             R"#()#"  , py::arg("theX"),  py::arg("theF")
          )
        .def("Gradient",
             (bool (Extrema_GlobOptFuncCS::*)(  const math_Vector & ,  math_Vector &  ) ) static_cast<bool (Extrema_GlobOptFuncCS::*)(  const math_Vector & ,  math_Vector &  ) >(&Extrema_GlobOptFuncCS::Gradient),
             R"#()#"  , py::arg("theX"),  py::arg("theG")
          )
        .def("Values",
             (bool (Extrema_GlobOptFuncCS::*)(  const math_Vector & ,  double & ,  math_Vector &  ) ) static_cast<bool (Extrema_GlobOptFuncCS::*)(  const math_Vector & ,  double & ,  math_Vector &  ) >(&Extrema_GlobOptFuncCS::Values),
             R"#()#"  , py::arg("theX"),  py::arg("theF"),  py::arg("theG")
          )
        .def("Values",
             (bool (Extrema_GlobOptFuncCS::*)(  const math_Vector & ,  double & ,  math_Vector & ,  math_Matrix &  ) ) static_cast<bool (Extrema_GlobOptFuncCS::*)(  const math_Vector & ,  double & ,  math_Vector & ,  math_Matrix &  ) >(&Extrema_GlobOptFuncCS::Values),
             R"#()#"  , py::arg("theX"),  py::arg("theF"),  py::arg("theG"),  py::arg("theH")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Extrema_GlobOptFuncConicS from ./opencascade/Extrema_GlobOptFuncConicS.hxx
    klass = m.attr("Extrema_GlobOptFuncConicS");


    // nested enums

    static_cast<py::class_<Extrema_GlobOptFuncConicS , shared_ptr<Extrema_GlobOptFuncConicS>  , math_MultipleVarFunction >>(klass)
    // constructors
        .def(py::init<  const Adaptor3d_Curve *, const Adaptor3d_Surface * >()  , py::arg("C"),  py::arg("S") )
        .def(py::init<  const Adaptor3d_Surface * >()  , py::arg("S") )
        .def(py::init<  const Adaptor3d_Surface *, const double, const double, const double, const double >()  , py::arg("S"),  py::arg("theUf"),  py::arg("theUl"),  py::arg("theVf"),  py::arg("theVl") )
    // custom constructors
    // methods
        .def("LoadConic",
             (void (Extrema_GlobOptFuncConicS::*)(  const Adaptor3d_Curve * ,   const double ,   const double  ) ) static_cast<void (Extrema_GlobOptFuncConicS::*)(  const Adaptor3d_Curve * ,   const double ,   const double  ) >(&Extrema_GlobOptFuncConicS::LoadConic),
             R"#()#"  , py::arg("S"),  py::arg("theTf"),  py::arg("theTl")
          )
        .def("NbVariables",
             (int (Extrema_GlobOptFuncConicS::*)() const) static_cast<int (Extrema_GlobOptFuncConicS::*)() const>(&Extrema_GlobOptFuncConicS::NbVariables),
             R"#()#" 
          )
        .def("Value",
             (bool (Extrema_GlobOptFuncConicS::*)(  const math_Vector & ,  double &  ) ) static_cast<bool (Extrema_GlobOptFuncConicS::*)(  const math_Vector & ,  double &  ) >(&Extrema_GlobOptFuncConicS::Value),
             R"#()#"  , py::arg("theX"),  py::arg("theF")
          )
        .def("ConicParameter",
             (double (Extrema_GlobOptFuncConicS::*)(  const math_Vector &  ) const) static_cast<double (Extrema_GlobOptFuncConicS::*)(  const math_Vector &  ) const>(&Extrema_GlobOptFuncConicS::ConicParameter),
             R"#(Parameter of conic for point on surface defined by theUV)#"  , py::arg("theUV")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Extrema_LocateExtCC from ./opencascade/Extrema_LocateExtCC.hxx
    klass = m.attr("Extrema_LocateExtCC");


    // nested enums

    static_cast<py::class_<Extrema_LocateExtCC , shared_ptr<Extrema_LocateExtCC>  >>(klass)
    // constructors
        .def(py::init<  const Adaptor3d_Curve &, const Adaptor3d_Curve &, const double, const double >()  , py::arg("C1"),  py::arg("C2"),  py::arg("U0"),  py::arg("V0") )
    // custom constructors
    // methods
        .def("IsDone",
             (bool (Extrema_LocateExtCC::*)() const) static_cast<bool (Extrema_LocateExtCC::*)() const>(&Extrema_LocateExtCC::IsDone),
             R"#(Returns True if the distance is found.)#" 
          )
        .def("SquareDistance",
             (double (Extrema_LocateExtCC::*)() const) static_cast<double (Extrema_LocateExtCC::*)() const>(&Extrema_LocateExtCC::SquareDistance),
             R"#(Returns the value of the extremum square distance.)#" 
          )
        .def("Point",
             (void (Extrema_LocateExtCC::*)( Extrema_POnCurv & ,  Extrema_POnCurv &  ) const) static_cast<void (Extrema_LocateExtCC::*)( Extrema_POnCurv & ,  Extrema_POnCurv &  ) const>(&Extrema_LocateExtCC::Point),
             R"#(Returns the points of the extremum distance. P1 is on the first curve, P2 on the second one.)#"  , py::arg("P1"),  py::arg("P2")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Extrema_LocateExtCC2d from ./opencascade/Extrema_LocateExtCC2d.hxx
    klass = m.attr("Extrema_LocateExtCC2d");


    // nested enums

    static_cast<py::class_<Extrema_LocateExtCC2d , shared_ptr<Extrema_LocateExtCC2d>  >>(klass)
    // constructors
        .def(py::init<  const Adaptor2d_Curve2d &, const Adaptor2d_Curve2d &, const double, const double >()  , py::arg("C1"),  py::arg("C2"),  py::arg("U0"),  py::arg("V0") )
    // custom constructors
    // methods
        .def("IsDone",
             (bool (Extrema_LocateExtCC2d::*)() const) static_cast<bool (Extrema_LocateExtCC2d::*)() const>(&Extrema_LocateExtCC2d::IsDone),
             R"#(Returns True if the distance is found.)#" 
          )
        .def("SquareDistance",
             (double (Extrema_LocateExtCC2d::*)() const) static_cast<double (Extrema_LocateExtCC2d::*)() const>(&Extrema_LocateExtCC2d::SquareDistance),
             R"#(Returns the value of the extremum square distance.)#" 
          )
        .def("Point",
             (void (Extrema_LocateExtCC2d::*)( Extrema_POnCurv2d & ,  Extrema_POnCurv2d &  ) const) static_cast<void (Extrema_LocateExtCC2d::*)( Extrema_POnCurv2d & ,  Extrema_POnCurv2d &  ) const>(&Extrema_LocateExtCC2d::Point),
             R"#(Returns the points of the extremum distance. P1 is on the first curve, P2 on the second one.)#"  , py::arg("P1"),  py::arg("P2")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Extrema_POnCurv from ./opencascade/Extrema_POnCurv.hxx
    klass = m.attr("Extrema_POnCurv");


    // nested enums

    static_cast<py::class_<Extrema_POnCurv , shared_ptr<Extrema_POnCurv>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const double, const gp_Pnt & >()  , py::arg("theU"),  py::arg("theP") )
    // custom constructors
    // methods
        .def("SetValues",
             (void (Extrema_POnCurv::*)(  const double ,   const gp_Pnt &  ) ) static_cast<void (Extrema_POnCurv::*)(  const double ,   const gp_Pnt &  ) >(&Extrema_POnCurv::SetValues),
             R"#(Sets the point and parameter values.)#"  , py::arg("theU"),  py::arg("theP")
          )
        .def("Parameter",
             (double (Extrema_POnCurv::*)() const) static_cast<double (Extrema_POnCurv::*)() const>(&Extrema_POnCurv::Parameter),
             R"#(Returns the parameter on the curve.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const gp_Pnt & (Extrema_POnCurv::*)() const) static_cast< const gp_Pnt & (Extrema_POnCurv::*)() const>(&Extrema_POnCurv::Value),
             R"#(Returns the point.)#"
             
         )
;

    // Class Extrema_POnCurv2d from ./opencascade/Extrema_POnCurv2d.hxx
    klass = m.attr("Extrema_POnCurv2d");


    // nested enums

    static_cast<py::class_<Extrema_POnCurv2d , shared_ptr<Extrema_POnCurv2d>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const double, const gp_Pnt2d & >()  , py::arg("theU"),  py::arg("theP") )
    // custom constructors
    // methods
        .def("SetValues",
             (void (Extrema_POnCurv2d::*)(  const double ,   const gp_Pnt2d &  ) ) static_cast<void (Extrema_POnCurv2d::*)(  const double ,   const gp_Pnt2d &  ) >(&Extrema_POnCurv2d::SetValues),
             R"#(Sets the point and parameter values.)#"  , py::arg("theU"),  py::arg("theP")
          )
        .def("Parameter",
             (double (Extrema_POnCurv2d::*)() const) static_cast<double (Extrema_POnCurv2d::*)() const>(&Extrema_POnCurv2d::Parameter),
             R"#(Returns the parameter on the curve.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const gp_Pnt2d & (Extrema_POnCurv2d::*)() const) static_cast< const gp_Pnt2d & (Extrema_POnCurv2d::*)() const>(&Extrema_POnCurv2d::Value),
             R"#(Returns the point.)#"
             
         )
;

    // Class Extrema_POnSurf from ./opencascade/Extrema_POnSurf.hxx
    klass = m.attr("Extrema_POnSurf");


    // nested enums

    static_cast<py::class_<Extrema_POnSurf , shared_ptr<Extrema_POnSurf>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const double, const double, const gp_Pnt & >()  , py::arg("theU"),  py::arg("theV"),  py::arg("theP") )
    // custom constructors
    // methods
        .def("SetParameters",
             (void (Extrema_POnSurf::*)(  const double ,   const double ,   const gp_Pnt &  ) ) static_cast<void (Extrema_POnSurf::*)(  const double ,   const double ,   const gp_Pnt &  ) >(&Extrema_POnSurf::SetParameters),
             R"#(Sets the params of current POnSurf instance. (e.g. to the point to be projected).)#"  , py::arg("theU"),  py::arg("theV"),  py::arg("thePnt")
          )
    // methods using call by reference i.s.o. return
        .def("Parameter",
             []( Extrema_POnSurf &self   ){
                 double  theU;
                double  theV;

                 self.Parameter(theU,theV);
                 return std::make_tuple(theU,theV); },
             R"#(Returns the parameter values on the surface.)#" 
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const gp_Pnt & (Extrema_POnSurf::*)() const) static_cast< const gp_Pnt & (Extrema_POnSurf::*)() const>(&Extrema_POnSurf::Value),
             R"#(Returns the 3d point.)#"
             
         )
;

    // Class Extrema_POnSurfParams from ./opencascade/Extrema_POnSurfParams.hxx
    klass = m.attr("Extrema_POnSurfParams");


    // nested enums

    static_cast<py::class_<Extrema_POnSurfParams , shared_ptr<Extrema_POnSurfParams>  , Extrema_POnSurf >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const double, const double, const gp_Pnt & >()  , py::arg("theU"),  py::arg("theV"),  py::arg("thePnt") )
    // custom constructors
    // methods
        .def("SetSqrDistance",
             (void (Extrema_POnSurfParams::*)(  const double  ) ) static_cast<void (Extrema_POnSurfParams::*)(  const double  ) >(&Extrema_POnSurfParams::SetSqrDistance),
             R"#(Sets the square distance from this point to another one (e.g. to the point to be projected).)#"  , py::arg("theSqrDistance")
          )
        .def("GetSqrDistance",
             (double (Extrema_POnSurfParams::*)() const) static_cast<double (Extrema_POnSurfParams::*)() const>(&Extrema_POnSurfParams::GetSqrDistance),
             R"#(Query the square distance from this point to another one.)#" 
          )
        .def("SetElementType",
             (void (Extrema_POnSurfParams::*)(  const Extrema_ElementType  ) ) static_cast<void (Extrema_POnSurfParams::*)(  const Extrema_ElementType  ) >(&Extrema_POnSurfParams::SetElementType),
             R"#(Sets the element type on which this point is situated.)#"  , py::arg("theElementType")
          )
        .def("GetElementType",
             (Extrema_ElementType (Extrema_POnSurfParams::*)() const) static_cast<Extrema_ElementType (Extrema_POnSurfParams::*)() const>(&Extrema_POnSurfParams::GetElementType),
             R"#(Query the element type on which this point is situated.)#" 
          )
        .def("SetIndices",
             (void (Extrema_POnSurfParams::*)(  const int ,   const int  ) ) static_cast<void (Extrema_POnSurfParams::*)(  const int ,   const int  ) >(&Extrema_POnSurfParams::SetIndices),
             R"#(Sets the U and V indices of an element that contains this point.)#"  , py::arg("theIndexU"),  py::arg("theIndexV")
          )
    // methods using call by reference i.s.o. return
        .def("GetIndices",
             []( Extrema_POnSurfParams &self   ){
                 int  theIndexU;
                int  theIndexV;

                 self.GetIndices(theIndexU,theIndexV);
                 return std::make_tuple(theIndexU,theIndexV); },
             R"#(Query the U and V indices of an element that contains this point.)#" 
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

// functions

// ./opencascade/Extrema_CCLocFOfLocECC.hxx
// ./opencascade/Extrema_CCLocFOfLocECC2d.hxx
// ./opencascade/Extrema_Curve2dTool.hxx
// ./opencascade/Extrema_CurveTool.hxx
// ./opencascade/Extrema_ECC.hxx
// ./opencascade/Extrema_ECC2d.hxx
// ./opencascade/Extrema_ELPCOfLocateExtPC.hxx
// ./opencascade/Extrema_ELPCOfLocateExtPC2d.hxx
// ./opencascade/Extrema_EPCOfELPCOfLocateExtPC.hxx
// ./opencascade/Extrema_EPCOfELPCOfLocateExtPC2d.hxx
// ./opencascade/Extrema_EPCOfExtPC.hxx
// ./opencascade/Extrema_EPCOfExtPC2d.hxx
// ./opencascade/Extrema_ElementType.hxx
// ./opencascade/Extrema_ExtAlgo.hxx
// ./opencascade/Extrema_ExtCC.hxx
// ./opencascade/Extrema_ExtCC2d.hxx
// ./opencascade/Extrema_ExtCS.hxx
// ./opencascade/Extrema_ExtElC.hxx
// ./opencascade/Extrema_ExtElC2d.hxx
// ./opencascade/Extrema_ExtElCS.hxx
// ./opencascade/Extrema_ExtElSS.hxx
// ./opencascade/Extrema_ExtFlag.hxx
// ./opencascade/Extrema_ExtPC.hxx
// ./opencascade/Extrema_ExtPC2d.hxx
// ./opencascade/Extrema_ExtPElC.hxx
// ./opencascade/Extrema_ExtPElC2d.hxx
// ./opencascade/Extrema_ExtPElS.hxx
// ./opencascade/Extrema_ExtPExtS.hxx
// ./opencascade/Extrema_ExtPRevS.hxx
// ./opencascade/Extrema_ExtPS.hxx
// ./opencascade/Extrema_ExtSS.hxx
// ./opencascade/Extrema_FuncExtCS.hxx
// ./opencascade/Extrema_FuncExtSS.hxx
// ./opencascade/Extrema_FuncPSDist.hxx
// ./opencascade/Extrema_FuncPSNorm.hxx
// ./opencascade/Extrema_GCurveLocator.hxx
// ./opencascade/Extrema_GFuncExtCC.hxx
// ./opencascade/Extrema_GFuncExtPC.hxx
// ./opencascade/Extrema_GGExtPC.hxx
// ./opencascade/Extrema_GGenExtPC.hxx
// ./opencascade/Extrema_GLocateExtPC.hxx
// ./opencascade/Extrema_GenExtCS.hxx
// ./opencascade/Extrema_GenExtPS.hxx
// ./opencascade/Extrema_GenExtSS.hxx
// ./opencascade/Extrema_GenLocateExtCC.hxx
// ./opencascade/Extrema_GenLocateExtCS.hxx
// ./opencascade/Extrema_GenLocateExtPC.hxx
// ./opencascade/Extrema_GenLocateExtPS.hxx
// ./opencascade/Extrema_GenLocateExtSS.hxx
// ./opencascade/Extrema_GlobOptFuncCC.hxx
// ./opencascade/Extrema_GlobOptFuncCQuadric.hxx
// ./opencascade/Extrema_GlobOptFuncCS.hxx
// ./opencascade/Extrema_GlobOptFuncConicS.hxx
// ./opencascade/Extrema_LocECC.hxx
// ./opencascade/Extrema_LocECC2d.hxx
// ./opencascade/Extrema_LocEPCOfLocateExtPC.hxx
// ./opencascade/Extrema_LocEPCOfLocateExtPC2d.hxx
// ./opencascade/Extrema_LocateExtCC.hxx
// ./opencascade/Extrema_LocateExtCC2d.hxx
// ./opencascade/Extrema_LocateExtPC.hxx
// ./opencascade/Extrema_LocateExtPC2d.hxx
// ./opencascade/Extrema_PCFOfEPCOfELPCOfLocateExtPC.hxx
// ./opencascade/Extrema_PCFOfEPCOfELPCOfLocateExtPC2d.hxx
// ./opencascade/Extrema_PCFOfEPCOfExtPC.hxx
// ./opencascade/Extrema_PCFOfEPCOfExtPC2d.hxx
// ./opencascade/Extrema_PCLocFOfLocEPCOfLocateExtPC.hxx
// ./opencascade/Extrema_PCLocFOfLocEPCOfLocateExtPC2d.hxx
// ./opencascade/Extrema_POnCurv.hxx
// ./opencascade/Extrema_POnCurv2d.hxx
// ./opencascade/Extrema_POnSurf.hxx
// ./opencascade/Extrema_POnSurfParams.hxx

// Additional functions


// operators

// register typdefs
    register_template_Extrema_GFuncExtCC<Adaptor3d_Curve, Extrema_CurveTool, Adaptor3d_Curve, Extrema_CurveTool, Extrema_POnCurv, gp_Pnt, gp_Vec, NCollection_Sequence<Extrema_POnCurv>>(m,"Extrema_CCLocFOfLocECC");
    register_template_Extrema_GFuncExtCC<Adaptor2d_Curve2d, Extrema_Curve2dTool, Adaptor2d_Curve2d, Extrema_Curve2dTool, Extrema_POnCurv2d, gp_Pnt2d, gp_Vec2d, NCollection_Sequence<Extrema_POnCurv2d>>(m,"Extrema_CCLocFOfLocECC2d");
    register_template_Extrema_GGenExtPC<Adaptor3d_Curve, Extrema_CurveTool, Extrema_POnCurv, gp_Pnt, Extrema_PCFOfEPCOfExtPC>(m,"Extrema_EPCOfExtPC");
    register_template_Extrema_GGenExtPC<Adaptor2d_Curve2d, Extrema_Curve2dTool, Extrema_POnCurv2d, gp_Pnt2d, Extrema_PCFOfEPCOfExtPC2d>(m,"Extrema_EPCOfExtPC2d");
    register_template_Extrema_GGExtPC<Adaptor3d_Curve, Extrema_CurveTool, Extrema_ExtPElC, gp_Pnt, gp_Vec, Extrema_POnCurv, NCollection_Sequence<Extrema_POnCurv>, Extrema_EPCOfExtPC>(m,"Extrema_ExtPC");
    register_template_Extrema_GGExtPC<Adaptor2d_Curve2d, Extrema_Curve2dTool, Extrema_ExtPElC2d, gp_Pnt2d, gp_Vec2d, Extrema_POnCurv2d, NCollection_Sequence<Extrema_POnCurv2d>, Extrema_EPCOfExtPC2d>(m,"Extrema_ExtPC2d");
    register_template_math_VectorBase<double>(m,"math_Vector");
    register_template_Extrema_GenLocateExtCC<Adaptor3d_Curve, Extrema_CurveTool, Extrema_POnCurv, Extrema_CCLocFOfLocECC>(m,"Extrema_LocECC");
    register_template_Extrema_GenLocateExtCC<Adaptor2d_Curve2d, Extrema_Curve2dTool, Extrema_POnCurv2d, Extrema_CCLocFOfLocECC2d>(m,"Extrema_LocECC2d");
    register_template_Extrema_GenLocateExtPC<Adaptor3d_Curve, Extrema_CurveTool, Extrema_POnCurv, gp_Pnt, Extrema_PCLocFOfLocEPCOfLocateExtPC>(m,"Extrema_LocEPCOfLocateExtPC");
    register_template_Extrema_GenLocateExtPC<Adaptor2d_Curve2d, Extrema_Curve2dTool, Extrema_POnCurv2d, gp_Pnt2d, Extrema_PCLocFOfLocEPCOfLocateExtPC2d>(m,"Extrema_LocEPCOfLocateExtPC2d");
    register_template_Extrema_GLocateExtPC<Adaptor3d_Curve, Extrema_CurveTool, gp_Pnt, gp_Vec, Extrema_POnCurv, Extrema_ELPCOfLocateExtPC, Extrema_LocEPCOfLocateExtPC>(m,"Extrema_LocateExtPC");
    register_template_Extrema_GLocateExtPC<Adaptor2d_Curve2d, Extrema_Curve2dTool, gp_Pnt2d, gp_Vec2d, Extrema_POnCurv2d, Extrema_ELPCOfLocateExtPC2d, Extrema_LocEPCOfLocateExtPC2d>(m,"Extrema_LocateExtPC2d");
    register_template_Extrema_GFuncExtPC<Adaptor3d_Curve, Extrema_CurveTool, Extrema_POnCurv, gp_Pnt, gp_Vec, NCollection_Sequence<Extrema_POnCurv>>(m,"Extrema_PCFOfEPCOfELPCOfLocateExtPC");
    register_template_Extrema_GFuncExtPC<Adaptor2d_Curve2d, Extrema_Curve2dTool, Extrema_POnCurv2d, gp_Pnt2d, gp_Vec2d, NCollection_Sequence<Extrema_POnCurv2d>>(m,"Extrema_PCFOfEPCOfELPCOfLocateExtPC2d");

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
