#pragma once

#include <initializer_list>
using std::initializer_list;

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <math_MultipleVarFunctionWithGradient.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <math_FunctionWithDerivative.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <math_Function.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <math_Function.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <math_Function.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <math_MultipleVarFunctionWithGradient.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <math_FunctionWithDerivative.hxx>
#include <math_FunctionSample.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <math_FunctionWithDerivative.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <math_FunctionWithDerivative.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <math_FunctionSetWithDerivatives.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <math_MultipleVarFunction.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <math_FunctionSet.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <math_Function.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <math_Function.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <math_FunctionWithDerivative.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <math_FunctionSetWithDerivatives.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <math_MultipleVarFunctionWithHessian.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <math_PSOParticlesPool.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <math_MultipleVarFunction.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <math_Matrix.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <math.hxx>
#include <math_BFGS.hxx>
#include <math_BissecNewton.hxx>
#include <math_BracketMinimum.hxx>
#include <math_BracketedRoot.hxx>
#include <math_BrentMinimum.hxx>
#include <math_BullardGenerator.hxx>
#include <math_ComputeGaussPointsAndWeights.hxx>
#include <math_ComputeKronrodPointsAndWeights.hxx>
#include <math_Crout.hxx>
#include <math_DirectPolynomialRoots.hxx>
#include <math_DoubleTab.hxx>
#include <math_EigenValuesSearcher.hxx>
#include <math_FRPR.hxx>
#include <math_Function.hxx>
#include <math_FunctionAllRoots.hxx>
#include <math_FunctionRoot.hxx>
#include <math_FunctionRoots.hxx>
#include <math_FunctionSample.hxx>
#include <math_FunctionSet.hxx>
#include <math_FunctionSetRoot.hxx>
#include <math_FunctionSetWithDerivatives.hxx>
#include <math_FunctionWithDerivative.hxx>
#include <math_Gauss.hxx>
#include <math_GaussLeastSquare.hxx>
#include <math_GaussMultipleIntegration.hxx>
#include <math_GaussSetIntegration.hxx>
#include <math_GaussSingleIntegration.hxx>
#include <math_GlobOptMin.hxx>
#include <math_Householder.hxx>
#include <math_IntegerVector.hxx>
#include <math_Jacobi.hxx>
#include <math_KronrodSingleIntegration.hxx>
#include <math_Matrix.hxx>
#include <math_MultipleVarFunction.hxx>
#include <math_MultipleVarFunctionWithGradient.hxx>
#include <math_MultipleVarFunctionWithHessian.hxx>
#include <math_NewtonFunctionRoot.hxx>
#include <math_NewtonFunctionSetRoot.hxx>
#include <math_NewtonMinimum.hxx>
#include <math_NotSquare.hxx>
#include <math_PSO.hxx>
#include <math_PSOParticlesPool.hxx>
#include <math_Powell.hxx>
#include <math_Recipes.hxx>
#include <math_SVD.hxx>
#include <math_SingularMatrix.hxx>
#include <math_Status.hxx>
#include <math_TrigonometricEquationFunction.hxx>
#include <math_TrigonometricFunctionRoots.hxx>
#include <math_Uzawa.hxx>
#include <math_ValueAndWeight.hxx>
#include <math_Vector.hxx>
#include <math_VectorBase.hxx>

// user-defined pre
#include "OCP_specific.inc"

// Class template handling functions

template <typename TheItemType>
void preregister_template_math_VectorBase(py::object &m, const char *name){
    py::class_<math_VectorBase<TheItemType> , shared_ptr<math_VectorBase<TheItemType>> >(m,name,R"#(This class implements the real vector abstract data type. Vectors can have an arbitrary range which must be defined at the declaration and cannot be changed after this declaration.)#");
}

template <typename TheItemType>
void register_template_math_VectorBase(py::object &m, const char *name){
    static_cast<py::class_<math_VectorBase<TheItemType> , shared_ptr<math_VectorBase<TheItemType>> >>(m.attr(name))
        .def(py::init<  const int, const int >() ,py::arg("theLower"), py::arg("theUpper") )
        .def(py::init<  const int, const int, const TheItemType >() ,py::arg("theLower"), py::arg("theUpper"), py::arg("theInitialValue") )
        .def(py::init<  const TheItemType *, const int, const int >() ,py::arg("theTab"), py::arg("theLower"), py::arg("theUpper") )
        .def(py::init<  const gp_XY & >() ,py::arg("Other") )
        .def(py::init<  const gp_XYZ & >() ,py::arg("Other") )
        .def(py::init<  const math_VectorBase<TheItemType> & >() ,py::arg("theOther") )
        .def("Init",
             (void (math_VectorBase<TheItemType>::*)(  const TheItemType  ) ) &math_VectorBase<TheItemType>::Init,
             R"#(Initialize all the elements of a vector with "theInitialValue".)#" ,py::arg("theInitialValue"))
        .def("Length",
             (int (math_VectorBase<TheItemType>::*)() const) &math_VectorBase<TheItemType>::Length,
             R"#(Returns the length of a vector)#" )
        .def("Lower",
             (int (math_VectorBase<TheItemType>::*)() const) &math_VectorBase<TheItemType>::Lower,
             R"#(Returns the lower index of the vector)#" )
        .def("Upper",
             (int (math_VectorBase<TheItemType>::*)() const) &math_VectorBase<TheItemType>::Upper,
             R"#(Returns the upper index of the vector)#" )
        .def("Norm",
             (double (math_VectorBase<TheItemType>::*)() const) &math_VectorBase<TheItemType>::Norm,
             R"#(Returns the value or the square of the norm of this vector.)#" )
        .def("Norm2",
             (double (math_VectorBase<TheItemType>::*)() const) &math_VectorBase<TheItemType>::Norm2,
             R"#(Returns the value of the square of the norm of a vector.)#" )
        .def("Max",
             (int (math_VectorBase<TheItemType>::*)() const) &math_VectorBase<TheItemType>::Max,
             R"#(Returns the index of the maximum element of a vector. (first found))#" )
        .def("Min",
             (int (math_VectorBase<TheItemType>::*)() const) &math_VectorBase<TheItemType>::Min,
             R"#(Returns the index of the minimum element of a vector. (first found))#" )
        .def("Normalize",
             (void (math_VectorBase<TheItemType>::*)() ) &math_VectorBase<TheItemType>::Normalize,
             R"#(Normalizes this vector (the norm of the result is equal to 1.0) and assigns the result to this vector Exceptions Standard_NullValue if this vector is null (i.e. if its norm is less than or equal to double::RealEpsilon().)#" )
        .def("Normalized",
             (math_VectorBase<TheItemType> (math_VectorBase<TheItemType>::*)() const) &math_VectorBase<TheItemType>::Normalized,
             R"#(Normalizes this vector (the norm of the result is equal to 1.0) and creates a new vector Exceptions Standard_NullValue if this vector is null (i.e. if its norm is less than or equal to double::RealEpsilon().)#" )
        .def("Invert",
             (void (math_VectorBase<TheItemType>::*)() ) &math_VectorBase<TheItemType>::Invert,
             R"#(Inverts this vector and assigns the result to this vector.)#" )
        .def("Inverse",
             (math_VectorBase<TheItemType> (math_VectorBase<TheItemType>::*)() const) &math_VectorBase<TheItemType>::Inverse,
             R"#(Inverts this vector and creates a new vector.)#" )
        .def("Set",
             (void (math_VectorBase<TheItemType>::*)(  const int ,   const int ,   const math_VectorBase<TheItemType> &  ) ) &math_VectorBase<TheItemType>::Set,
             R"#(sets a vector from "theI1" to "theI2" to the vector "theV"; An exception is raised if "theI1" is less than "LowerIndex" or "theI2" is greater than "UpperIndex" or "theI1" is greater than "theI2". An exception is raised if "theI2-theI1+1" is different from the "Length" of "theV".)#" ,py::arg("theI1"), py::arg("theI2"), py::arg("theV"))
        .def("Slice",
             (math_VectorBase<TheItemType> (math_VectorBase<TheItemType>::*)(  const int ,   const int  ) const) &math_VectorBase<TheItemType>::Slice,
             R"#(Creates a new vector by inverting the values of this vector between indexes "theI1" and "theI2". If the values of this vector were (1., 2., 3., 4.,5., 6.), by slicing it between indexes 2 and 5 the values of the resulting vector are (1., 5., 4., 3., 2., 6.))#" ,py::arg("theI1"), py::arg("theI2"))
        .def("Multiply",
             (void (math_VectorBase<TheItemType>::*)(  const TheItemType  ) ) &math_VectorBase<TheItemType>::Multiply,
             R"#(Updates current vector by multiplying each element on current value.)#" ,py::arg("theRight"))
        .def("Multiplied",
             (math_VectorBase<TheItemType> (math_VectorBase<TheItemType>::*)(  const TheItemType  ) const) &math_VectorBase<TheItemType>::Multiplied,
             R"#(returns the product of a vector and a real value.)#" ,py::arg("theRight"))
        .def("TMultiplied",
             (math_VectorBase<TheItemType> (math_VectorBase<TheItemType>::*)(  const TheItemType  ) const) &math_VectorBase<TheItemType>::TMultiplied,
             R"#(returns the product of a vector and a real value.)#" ,py::arg("theRight"))
        .def("Divide",
             (void (math_VectorBase<TheItemType>::*)(  const TheItemType  ) ) &math_VectorBase<TheItemType>::Divide,
             R"#(divides a vector by the value "theRight". An exception is raised if "theRight" = 0.)#" ,py::arg("theRight"))
        .def("Divided",
             (math_VectorBase<TheItemType> (math_VectorBase<TheItemType>::*)(  const TheItemType  ) const) &math_VectorBase<TheItemType>::Divided,
             R"#(Returns new vector as dividing current vector with the value "theRight". An exception is raised if "theRight" = 0.)#" ,py::arg("theRight"))
        .def("Add",
             (void (math_VectorBase<TheItemType>::*)(  const math_VectorBase<TheItemType> &  ) ) &math_VectorBase<TheItemType>::Add,
             R"#(adds the vector "theRight" to a vector. An exception is raised if the vectors have not the same length. Warning In order to avoid time-consuming copying of vectors, it is preferable to use operator += or the function Add whenever possible.)#" ,py::arg("theRight"))
        .def("Added",
             (math_VectorBase<TheItemType> (math_VectorBase<TheItemType>::*)(  const math_VectorBase<TheItemType> &  ) const) &math_VectorBase<TheItemType>::Added,
             R"#(Returns new vector as adding current vector with the value "theRight". An exception is raised if the vectors do not have the same length. An exception is raised if the lengths are not equal.)#" ,py::arg("theRight"))
        .def("Multiply",
             (void (math_VectorBase<TheItemType>::*)(  const math_VectorBase<TheItemType> & ,   const math_Matrix &  ) ) &math_VectorBase<TheItemType>::Multiply,
             R"#(sets a vector to the product of the vector "theLeft" with the matrix "theRight".)#" ,py::arg("theLeft"), py::arg("theRight"))
        .def("Multiply",
             (void (math_VectorBase<TheItemType>::*)(  const math_Matrix & ,   const math_VectorBase<TheItemType> &  ) ) &math_VectorBase<TheItemType>::Multiply,
             R"#(sets a vector to the product of the matrix "theLeft" with the vector "theRight".)#" ,py::arg("theLeft"), py::arg("theRight"))
        .def("TMultiply",
             (void (math_VectorBase<TheItemType>::*)(  const math_Matrix & ,   const math_VectorBase<TheItemType> &  ) ) &math_VectorBase<TheItemType>::TMultiply,
             R"#(sets a vector to the product of the transpose of the matrix "theTLeft" by the vector "theRight".)#" ,py::arg("theTLeft"), py::arg("theRight"))
        .def("TMultiply",
             (void (math_VectorBase<TheItemType>::*)(  const math_VectorBase<TheItemType> & ,   const math_Matrix &  ) ) &math_VectorBase<TheItemType>::TMultiply,
             R"#(sets a vector to the product of the vector "theLeft" by the transpose of the matrix "theTRight".)#" ,py::arg("theLeft"), py::arg("theTRight"))
        .def("Add",
             (void (math_VectorBase<TheItemType>::*)(  const math_VectorBase<TheItemType> & ,   const math_VectorBase<TheItemType> &  ) ) &math_VectorBase<TheItemType>::Add,
             R"#(sets a vector to the sum of the vector "theLeft" and the vector "theRight". An exception is raised if the lengths are different.)#" ,py::arg("theLeft"), py::arg("theRight"))
        .def("Subtract",
             (void (math_VectorBase<TheItemType>::*)(  const math_VectorBase<TheItemType> & ,   const math_VectorBase<TheItemType> &  ) ) &math_VectorBase<TheItemType>::Subtract,
             R"#(sets a vector to the Subtraction of the vector theRight from the vector theLeft. An exception is raised if the vectors have not the same length. Warning In order to avoid time-consuming copying of vectors, it is preferable to use operator -= or the function Subtract whenever possible.)#" ,py::arg("theLeft"), py::arg("theRight"))
        .def("Value",
             ( const TheItemType & (math_VectorBase<TheItemType>::*)(  const int  ) const) &math_VectorBase<TheItemType>::Value,
             R"#(accesses the value of index "theNum" of a vector.)#" ,py::arg("theNum"))
        .def("Value",
             (TheItemType & (math_VectorBase<TheItemType>::*)(  const int  ) ) &math_VectorBase<TheItemType>::Value,
             R"#(accesses (in read or write mode) the value of index "theNum" of a vector.)#" ,py::arg("theNum"))
        .def("Initialized",
             (math_VectorBase<TheItemType> & (math_VectorBase<TheItemType>::*)(  const math_VectorBase<TheItemType> &  ) ) &math_VectorBase<TheItemType>::Initialized,
             R"#(Initialises a vector by copying "theOther". An exception is raised if the Lengths are different.)#" ,py::arg("theOther"))
        .def("Multiplied",
             (TheItemType (math_VectorBase<TheItemType>::*)(  const math_VectorBase<TheItemType> &  ) const) &math_VectorBase<TheItemType>::Multiplied,
             R"#(returns the inner product of 2 vectors. An exception is raised if the lengths are not equal.)#" ,py::arg("theRight"))
        .def("Multiplied",
             (math_VectorBase<TheItemType> (math_VectorBase<TheItemType>::*)(  const math_Matrix &  ) const) &math_VectorBase<TheItemType>::Multiplied,
             R"#(returns the product of a vector by a matrix.)#" ,py::arg("theRight"))
        .def("Opposite",
             (math_VectorBase<TheItemType> (math_VectorBase<TheItemType>::*)() ) &math_VectorBase<TheItemType>::Opposite,
             R"#(returns the opposite of a vector.)#" )
        .def("Subtract",
             (void (math_VectorBase<TheItemType>::*)(  const math_VectorBase<TheItemType> &  ) ) &math_VectorBase<TheItemType>::Subtract,
             R"#(returns the subtraction of "theRight" from "me". An exception is raised if the vectors have not the same length.)#" ,py::arg("theRight"))
        .def("Subtracted",
             (math_VectorBase<TheItemType> (math_VectorBase<TheItemType>::*)(  const math_VectorBase<TheItemType> &  ) const) &math_VectorBase<TheItemType>::Subtracted,
             R"#(returns the subtraction of "theRight" from "me". An exception is raised if the vectors have not the same length.)#" ,py::arg("theRight"))
        .def("Multiply",
             (void (math_VectorBase<TheItemType>::*)(  const TheItemType ,   const math_VectorBase<TheItemType> &  ) ) &math_VectorBase<TheItemType>::Multiply,
             R"#(returns the multiplication of a real by a vector. "me" = "theLeft" * "theRight")#" ,py::arg("theLeft"), py::arg("theRight"))
        .def("Dump",
             (void (math_VectorBase<TheItemType>::*)( Standard_OStream &  ) const) &math_VectorBase<TheItemType>::Dump,
             R"#(Prints information on the current state of the object. Is used to redefine the operator <<.)#" ,py::arg("theO"))
        .def("Array1",
             ( const NCollection_Array1<TheItemType> & (math_VectorBase<TheItemType>::*)() const) &math_VectorBase<TheItemType>::Array1,
             R"#(Returns the underlying array for interoperability with legacy APIs. Allows passing math_Vector data to functions expecting NCollection_Array1.)#" )
        .def("Resize",
             (void (math_VectorBase<TheItemType>::*)(  const int  ) ) &math_VectorBase<TheItemType>::Resize,
             R"#(Resizes the vector to a new size, keeping the same lower bound. Existing data within the new range is preserved. The method optimizes memory usage: - If new size fits in stack buffer (<=32), uses stack allocation - If new size requires heap and was already on heap, resizes in place - Transitions between stack and heap as needed)#" ,py::arg("theSize"))
        .def("__imul__",
             (void (math_VectorBase<TheItemType>::*)(  const TheItemType  ) ) &math_VectorBase<TheItemType>::operator*=,
             py::is_operator(),
             R"#()#" ,py::arg("theRight"))
        .def("__mul__",
             (math_VectorBase<TheItemType> (math_VectorBase<TheItemType>::*)(  const TheItemType  ) const) &math_VectorBase<TheItemType>::operator*,
             py::is_operator(),
             R"#()#" ,py::arg("theRight"))
        .def("__rmul__",
             (math_VectorBase<TheItemType> (math_VectorBase<TheItemType>::*)(  const TheItemType  ) const) &math_VectorBase<TheItemType>::operator*,
             py::is_operator(),
             R"#()#" ,py::arg("theRight"))
        .def("__itruediv__",
             (void (math_VectorBase<TheItemType>::*)(  const TheItemType  ) ) &math_VectorBase<TheItemType>::operator/=,
             py::is_operator(),
             R"#()#" ,py::arg("theRight"))
        .def("__truediv__",
             (math_VectorBase<TheItemType> (math_VectorBase<TheItemType>::*)(  const TheItemType  ) const) &math_VectorBase<TheItemType>::operator/,
             py::is_operator(),
             R"#()#" ,py::arg("theRight"))
        .def("__iadd__",
             (void (math_VectorBase<TheItemType>::*)(  const math_VectorBase<TheItemType> &  ) ) &math_VectorBase<TheItemType>::operator+=,
             py::is_operator(),
             R"#()#" ,py::arg("theRight"))
        .def("__add__",
             (math_VectorBase<TheItemType> (math_VectorBase<TheItemType>::*)(  const math_VectorBase<TheItemType> &  ) const) &math_VectorBase<TheItemType>::operator+,
             py::is_operator(),
             R"#()#" ,py::arg("theRight"))
        .def("__call__",
             ( const TheItemType & (math_VectorBase<TheItemType>::*)(  const int  ) const) &math_VectorBase<TheItemType>::operator(),
             py::is_operator(),
             R"#()#" ,py::arg("theNum"))
        .def("__call__",
             (TheItemType & (math_VectorBase<TheItemType>::*)(  const int  ) ) &math_VectorBase<TheItemType>::operator(),
             py::is_operator(),
             R"#()#" ,py::arg("theNum"))
        .def("__mul__",
             (TheItemType (math_VectorBase<TheItemType>::*)(  const math_VectorBase<TheItemType> &  ) const) &math_VectorBase<TheItemType>::operator*,
             py::is_operator(),
             R"#()#" ,py::arg("theRight"))
        .def("__rmul__",
             (TheItemType (math_VectorBase<TheItemType>::*)(  const math_VectorBase<TheItemType> &  ) const) &math_VectorBase<TheItemType>::operator*,
             py::is_operator(),
             R"#()#" ,py::arg("theRight"))
        .def("__mul__",
             (math_VectorBase<TheItemType> (math_VectorBase<TheItemType>::*)(  const math_Matrix &  ) const) &math_VectorBase<TheItemType>::operator*,
             py::is_operator(),
             R"#()#" ,py::arg("theRight"))
        .def("__rmul__",
             (math_VectorBase<TheItemType> (math_VectorBase<TheItemType>::*)(  const math_Matrix &  ) const) &math_VectorBase<TheItemType>::operator*,
             py::is_operator(),
             R"#()#" ,py::arg("theRight"))
        .def("__neg__",
             (math_VectorBase<TheItemType> (math_VectorBase<TheItemType>::*)() ) &math_VectorBase<TheItemType>::operator-,
             py::is_operator(),
             R"#()#" )
        .def("__isub__",
             (void (math_VectorBase<TheItemType>::*)(  const math_VectorBase<TheItemType> &  ) ) &math_VectorBase<TheItemType>::operator-=,
             py::is_operator(),
             R"#()#" ,py::arg("theRight"))
        .def("__sub__",
             (math_VectorBase<TheItemType> (math_VectorBase<TheItemType>::*)(  const math_VectorBase<TheItemType> &  ) const) &math_VectorBase<TheItemType>::operator-,
             py::is_operator(),
             R"#()#" ,py::arg("theRight"))
    ;
};


// user-defined post

