
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_WorkSession.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_SessionPilot.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_SessionFile.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_GeneralModifier.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_AppliedModifiers.hxx>
#include <IFSelect_GeneralModifier.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_IntParam.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_IntParam.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_SignCounter.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_HAsciiString.hxx>
#include <IFSelect_Selection.hxx>
#include <IFSelect_SelectionIterator.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_Editor.hxx>
#include <IFSelect_ListEditor.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_EditForm.hxx>
#include <IFSelect_ListEditor.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_WorkSession.hxx>
#include <IFSelect_Dispatch.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_Selection.hxx>
#include <IFSelect_Dispatch.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_SelectDeduct.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_ShareOut.hxx>
#include <IFSelect_ShareOutResult.hxx>
#include <IFSelect_WorkLibrary.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_EditForm.hxx>
#include <IFSelect_ContextModif.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_ContextModif.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_ContextModif.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_EditForm.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_IntParam.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_SelectionIterator.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_SelectionIterator.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_SelectionIterator.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_SelectPointed.hxx>
#include <IFSelect_SelectionIterator.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_IntParam.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_Transformer.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_IntParam.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_Signature.hxx>
#include <IFSelect_SignCounter.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_Signature.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_Signature.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_SelectionIterator.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_SessionFile.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_WorkSession.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_WorkSession.hxx>
#include <IFSelect_WorkLibrary.hxx>
#include <IFSelect_SignCounter.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_HAsciiString.hxx>
#include <IFSelect_Modifier.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_ShareOut.hxx>
#include <IFSelect_Dispatch.hxx>
#include <IFSelect_PacketList.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_Signature.hxx>
#include <IFSelect_Selection.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_Selection.hxx>
#include <IFSelect_Modifier.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TCollection_AsciiString.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_ContextWrite.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <IFSelect_ShareOut.hxx>
#include <IFSelect_WorkLibrary.hxx>
#include <IFSelect_ModelCopier.hxx>
#include <IFSelect_Signature.hxx>
#include <IFSelect_IntParam.hxx>
#include <IFSelect_Selection.hxx>
#include <IFSelect_SelectionIterator.hxx>
#include <IFSelect_SignCounter.hxx>
#include <IFSelect_Dispatch.hxx>
#include <IFSelect_GeneralModifier.hxx>
#include <IFSelect_Modifier.hxx>
#include <IFSelect_Transformer.hxx>
#include <IFSelect_PacketList.hxx>
#include <IFSelect_SignatureList.hxx>

// module includes
#include <IFSelect.hxx>
#include <IFSelect_Act.hxx>
#include <IFSelect_ActFunc.hxx>
#include <IFSelect_Activator.hxx>
#include <IFSelect_AppliedModifiers.hxx>
#include <IFSelect_BasicDumper.hxx>
#include <IFSelect_CheckCounter.hxx>
#include <IFSelect_ContextModif.hxx>
#include <IFSelect_ContextWrite.hxx>
#include <IFSelect_Dispatch.hxx>
#include <IFSelect_DispGlobal.hxx>
#include <IFSelect_DispPerCount.hxx>
#include <IFSelect_DispPerFiles.hxx>
#include <IFSelect_DispPerOne.hxx>
#include <IFSelect_DispPerSignature.hxx>
#include <IFSelect_EditForm.hxx>
#include <IFSelect_Editor.hxx>
#include <IFSelect_EditValue.hxx>
#include <IFSelect_Functions.hxx>
#include <IFSelect_GeneralModifier.hxx>
#include <IFSelect_GraphCounter.hxx>
#include <IFSelect_IntParam.hxx>
#include <IFSelect_ListEditor.hxx>
#include <IFSelect_ModelCopier.hxx>
#include <IFSelect_ModifEditForm.hxx>
#include <IFSelect_Modifier.hxx>
#include <IFSelect_ModifReorder.hxx>
#include <IFSelect_PacketList.hxx>
#include <IFSelect_ParamEditor.hxx>
#include <IFSelect_PrintCount.hxx>
#include <IFSelect_PrintFail.hxx>
#include <IFSelect_RemainMode.hxx>
#include <IFSelect_ReturnStatus.hxx>
#include <IFSelect_SelectAnyList.hxx>
#include <IFSelect_SelectAnyType.hxx>
#include <IFSelect_SelectBase.hxx>
#include <IFSelect_SelectCombine.hxx>
#include <IFSelect_SelectControl.hxx>
#include <IFSelect_SelectDeduct.hxx>
#include <IFSelect_SelectDiff.hxx>
#include <IFSelect_SelectEntityNumber.hxx>
#include <IFSelect_SelectErrorEntities.hxx>
#include <IFSelect_SelectExplore.hxx>
#include <IFSelect_SelectExtract.hxx>
#include <IFSelect_SelectFlag.hxx>
#include <IFSelect_SelectIncorrectEntities.hxx>
#include <IFSelect_SelectInList.hxx>
#include <IFSelect_SelectIntersection.hxx>
#include <IFSelect_Selection.hxx>
#include <IFSelect_SelectionIterator.hxx>
#include <IFSelect_SelectModelEntities.hxx>
#include <IFSelect_SelectModelRoots.hxx>
#include <IFSelect_SelectPointed.hxx>
#include <IFSelect_SelectRange.hxx>
#include <IFSelect_SelectRootComps.hxx>
#include <IFSelect_SelectRoots.hxx>
#include <IFSelect_SelectSent.hxx>
#include <IFSelect_SelectShared.hxx>
#include <IFSelect_SelectSharing.hxx>
#include <IFSelect_SelectSignature.hxx>
#include <IFSelect_SelectSignedShared.hxx>
#include <IFSelect_SelectSignedSharing.hxx>
#include <IFSelect_SelectSuite.hxx>
#include <IFSelect_SelectType.hxx>
#include <IFSelect_SelectUnion.hxx>
#include <IFSelect_SelectUnknownEntities.hxx>
#include <IFSelect_SessionDumper.hxx>
#include <IFSelect_SessionFile.hxx>
#include <IFSelect_SessionPilot.hxx>
#include <IFSelect_ShareOut.hxx>
#include <IFSelect_ShareOutResult.hxx>
#include <IFSelect_SignAncestor.hxx>
#include <IFSelect_Signature.hxx>
#include <IFSelect_SignatureList.hxx>
#include <IFSelect_SignCategory.hxx>
#include <IFSelect_SignCounter.hxx>
#include <IFSelect_SignMultiple.hxx>
#include <IFSelect_SignType.hxx>
#include <IFSelect_SignValidity.hxx>
#include <IFSelect_Transformer.hxx>
#include <IFSelect_TransformStandard.hxx>
#include <IFSelect_WorkLibrary.hxx>
#include <IFSelect_WorkSession.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module
#include <istream>
using std::basic_istream;
using std::char_traits;

// Module definiiton
void register_IFSelect(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("IFSelect"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes
    class Py_IFSelect_Activator : public IFSelect_Activator{
    public:
        using IFSelect_Activator::IFSelect_Activator;


        // public pure virtual
        IFSelect_ReturnStatus Do( const int number, const handle<IFSelect_SessionPilot> & pilot) override { using return_type = IFSelect_ReturnStatus;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_Activator,Do,number,pilot) };
         const char * Help( const int number) const  override { using return_type =  const char *;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_Activator,Help,number) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_IFSelect_Dispatch : public IFSelect_Dispatch{
    public:
        using IFSelect_Dispatch::IFSelect_Dispatch;


        // public pure virtual
        TCollection_AsciiString Label() const  override { using return_type = TCollection_AsciiString;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_Dispatch,Label,) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_IFSelect_Editor : public IFSelect_Editor{
    public:
        using IFSelect_Editor::IFSelect_Editor;


        // public pure virtual
        TCollection_AsciiString Label() const  override { using return_type = TCollection_AsciiString;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_Editor,Label,) };
        bool Recognize( const handle<IFSelect_EditForm> & form) const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_Editor,Recognize,form) };
        handle<TCollection_HAsciiString> StringValue( const handle<IFSelect_EditForm> & form, const int num) const  override { using return_type = handle<TCollection_HAsciiString>;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_Editor,StringValue,form,num) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_IFSelect_GeneralModifier : public IFSelect_GeneralModifier{
    public:
        using IFSelect_GeneralModifier::IFSelect_GeneralModifier;


        // public pure virtual
        TCollection_AsciiString Label() const  override { using return_type = TCollection_AsciiString;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_GeneralModifier,Label,) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_IFSelect_Selection : public IFSelect_Selection{
    public:
        using IFSelect_Selection::IFSelect_Selection;


        // public pure virtual
        void FillIterator(IFSelect_SelectionIterator & iter) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_Selection,FillIterator,iter) };
        TCollection_AsciiString Label() const  override { using return_type = TCollection_AsciiString;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_Selection,Label,) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_IFSelect_SessionDumper : public IFSelect_SessionDumper{
    public:
        using IFSelect_SessionDumper::IFSelect_SessionDumper;


        // public pure virtual
        bool WriteOwn(IFSelect_SessionFile & file, const handle<Standard_Transient> & item) const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_SessionDumper,WriteOwn,file,item) };
        bool ReadOwn(IFSelect_SessionFile & file, const TCollection_AsciiString & type,handle<Standard_Transient> & item) const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_SessionDumper,ReadOwn,file,type,item) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_IFSelect_Signature : public IFSelect_Signature{
    public:
        using IFSelect_Signature::IFSelect_Signature;


        // public pure virtual


        // protected pure virtual


        // private pure virtual

    };
    class Py_IFSelect_Transformer : public IFSelect_Transformer{
    public:
        using IFSelect_Transformer::IFSelect_Transformer;


        // public pure virtual
        bool Updated( const handle<Standard_Transient> & entfrom,handle<Standard_Transient> & entto) const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_Transformer,Updated,entfrom,entto) };
        TCollection_AsciiString Label() const  override { using return_type = TCollection_AsciiString;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_Transformer,Label,) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_IFSelect_WorkLibrary : public IFSelect_WorkLibrary{
    public:
        using IFSelect_WorkLibrary::IFSelect_WorkLibrary;


        // public pure virtual
        bool WriteFile(IFSelect_ContextWrite & ctx) const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_WorkLibrary,WriteFile,ctx) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_IFSelect_Modifier : public IFSelect_Modifier{
    public:
        using IFSelect_Modifier::IFSelect_Modifier;


        // public pure virtual

        TCollection_AsciiString Label() const  override { using return_type = TCollection_AsciiString;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_GeneralModifier,Label,) };

        // protected pure virtual


        // private pure virtual

    };
    class Py_IFSelect_SelectBase : public IFSelect_SelectBase{
    public:
        using IFSelect_SelectBase::IFSelect_SelectBase;


        // public pure virtual

        TCollection_AsciiString Label() const  override { using return_type = TCollection_AsciiString;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_Selection,Label,) };

        // protected pure virtual


        // private pure virtual

    };
    class Py_IFSelect_SelectCombine : public IFSelect_SelectCombine{
    public:
        using IFSelect_SelectCombine::IFSelect_SelectCombine;


        // public pure virtual

        TCollection_AsciiString Label() const  override { using return_type = TCollection_AsciiString;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_Selection,Label,) };

        // protected pure virtual


        // private pure virtual

    };
    class Py_IFSelect_SelectControl : public IFSelect_SelectControl{
    public:
        using IFSelect_SelectControl::IFSelect_SelectControl;


        // public pure virtual

        TCollection_AsciiString Label() const  override { using return_type = TCollection_AsciiString;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_Selection,Label,) };

        // protected pure virtual


        // private pure virtual

    };
    class Py_IFSelect_SelectDeduct : public IFSelect_SelectDeduct{
    public:
        using IFSelect_SelectDeduct::IFSelect_SelectDeduct;


        // public pure virtual

        TCollection_AsciiString Label() const  override { using return_type = TCollection_AsciiString;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_Selection,Label,) };

        // protected pure virtual


        // private pure virtual

    };
    class Py_IFSelect_SelectAnyList : public IFSelect_SelectAnyList{
    public:
        using IFSelect_SelectAnyList::IFSelect_SelectAnyList;


        // public pure virtual
        int NbItems( const handle<Standard_Transient> & ent) const  override { using return_type = int;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_SelectAnyList,NbItems,ent) };
        TCollection_AsciiString ListLabel() const  override { using return_type = TCollection_AsciiString;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_SelectAnyList,ListLabel,) };

        void FillIterator(IFSelect_SelectionIterator & iter) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_Selection,FillIterator,iter) };

        // protected pure virtual


        // private pure virtual

    };
    class Py_IFSelect_SelectExplore : public IFSelect_SelectExplore{
    public:
        using IFSelect_SelectExplore::IFSelect_SelectExplore;


        // public pure virtual
        TCollection_AsciiString ExploreLabel() const  override { using return_type = TCollection_AsciiString;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_SelectExplore,ExploreLabel,) };

        void FillIterator(IFSelect_SelectionIterator & iter) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_Selection,FillIterator,iter) };

        // protected pure virtual


        // private pure virtual

    };
    class Py_IFSelect_SelectExtract : public IFSelect_SelectExtract{
    public:
        using IFSelect_SelectExtract::IFSelect_SelectExtract;


        // public pure virtual
        TCollection_AsciiString ExtractLabel() const  override { using return_type = TCollection_AsciiString;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_SelectExtract,ExtractLabel,) };

        void FillIterator(IFSelect_SelectionIterator & iter) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_Selection,FillIterator,iter) };

        // protected pure virtual


        // private pure virtual

    };
    class Py_IFSelect_SelectAnyType : public IFSelect_SelectAnyType{
    public:
        using IFSelect_SelectAnyType::IFSelect_SelectAnyType;


        // public pure virtual
        handle<Standard_Type> TypeForMatch() const  override { using return_type = handle<Standard_Type>;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_SelectAnyType,TypeForMatch,) };

        TCollection_AsciiString ExtractLabel() const  override { using return_type = TCollection_AsciiString;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_SelectExtract,ExtractLabel,) };
        void FillIterator(IFSelect_SelectionIterator & iter) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_Selection,FillIterator,iter) };
        TCollection_AsciiString Label() const  override { using return_type = TCollection_AsciiString;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_Selection,Label,) };

        // protected pure virtual


        // private pure virtual

    };
    class Py_IFSelect_SelectInList : public IFSelect_SelectInList{
    public:
        using IFSelect_SelectInList::IFSelect_SelectInList;


        // public pure virtual
        handle<Standard_Transient> ListedEntity( const int num, const handle<Standard_Transient> & ent) const  override { using return_type = handle<Standard_Transient>;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_SelectInList,ListedEntity,num,ent) };

        int NbItems( const handle<Standard_Transient> & ent) const  override { using return_type = int;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_SelectAnyList,NbItems,ent) };
        TCollection_AsciiString ListLabel() const  override { using return_type = TCollection_AsciiString;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_SelectAnyList,ListLabel,) };
        void FillIterator(IFSelect_SelectionIterator & iter) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_Selection,FillIterator,iter) };
        TCollection_AsciiString Label() const  override { using return_type = TCollection_AsciiString;
    PYBIND11_OVERLOAD_PURE(return_type,IFSelect_Selection,Label,) };

        // protected pure virtual


        // private pure virtual

    };

// classes

    // Class IFSelect from ./opencascade/IFSelect.hxx
    klass = m.attr("IFSelect");

    // default constructor
    register_default_constructor<IFSelect , shared_ptr<IFSelect>>(m,"IFSelect");

    // nested enums

    static_cast<py::class_<IFSelect , shared_ptr<IFSelect>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("SaveSession_s",
                    (bool (*)(  const handle<IFSelect_WorkSession> & ,   const char * const   ) ) static_cast<bool (*)(  const handle<IFSelect_WorkSession> & ,   const char * const   ) >(&IFSelect::SaveSession),
                    R"#(Saves the state of a WorkSession from IFSelect, by using a SessionFile from IFSelect. Returns True if Done, False in case of Error on Writing. <file> gives the name of the File to be produced (this avoids to export the class SessionFile).)#"  , py::arg("WS"),  py::arg("file")
          )
        .def_static("RestoreSession_s",
                    (bool (*)(  const handle<IFSelect_WorkSession> & ,   const char * const   ) ) static_cast<bool (*)(  const handle<IFSelect_WorkSession> & ,   const char * const   ) >(&IFSelect::RestoreSession),
                    R"#(Restore the state of a WorkSession from IFSelect, by using a SessionFile from IFSelect. Returns True if Done, False in case of Error on Writing. <file> gives the name of the File to be used (this avoids to export the class SessionFile).)#"  , py::arg("WS"),  py::arg("file")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IFSelect_Activator from ./opencascade/IFSelect_Activator.hxx
    klass = m.attr("IFSelect_Activator");


    // nested enums

    static_cast<py::class_<IFSelect_Activator ,opencascade::handle<IFSelect_Activator> ,Py_IFSelect_Activator , Standard_Transient >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("Add",
             (void (IFSelect_Activator::*)(  const int ,   const char * const   ) const) static_cast<void (IFSelect_Activator::*)(  const int ,   const char * const   ) const>(&IFSelect_Activator::Add),
             R"#(Allows a self-definition by an Activator of the Commands it processes, call the class method Adding (mode 0))#"  , py::arg("number"),  py::arg("command")
          )
        .def("AddSet",
             (void (IFSelect_Activator::*)(  const int ,   const char * const   ) const) static_cast<void (IFSelect_Activator::*)(  const int ,   const char * const   ) const>(&IFSelect_Activator::AddSet),
             R"#(Same as Add but specifies that this command is candidate for xset (creation of items, xset : named items; mode 1))#"  , py::arg("number"),  py::arg("command")
          )
        .def("Do",
             (IFSelect_ReturnStatus (IFSelect_Activator::*)(  const int ,   const handle<IFSelect_SessionPilot> &  ) ) static_cast<IFSelect_ReturnStatus (IFSelect_Activator::*)(  const int ,   const handle<IFSelect_SessionPilot> &  ) >(&IFSelect_Activator::Do),
             R"#(Tries to execute a Command Line. <number> is the number of the command for this Activator. It Must forecast to record the result of the execution, for need of Undo-Redo Must Returns : 0 for a void command (not to be recorded), 1 if execution OK, -1 if command incorrect, -2 if error on execution)#"  , py::arg("number"),  py::arg("pilot")
          )
        .def("Help",
             ( const char * (IFSelect_Activator::*)(  const int  ) const) static_cast< const char * (IFSelect_Activator::*)(  const int  ) const>(&IFSelect_Activator::Help),
             R"#(Sends a short help message for a given command identified by it number for this Activator (must take one line max))#"  , py::arg("number")
          )
        .def("Group",
             ( const char * (IFSelect_Activator::*)() const) static_cast< const char * (IFSelect_Activator::*)() const>(&IFSelect_Activator::Group),
             R"#()#" 
          )
        .def("File",
             ( const char * (IFSelect_Activator::*)() const) static_cast< const char * (IFSelect_Activator::*)() const>(&IFSelect_Activator::File),
             R"#()#" 
          )
        .def("SetForGroup",
             (void (IFSelect_Activator::*)(  const char * const  ,   const char * const   ) ) static_cast<void (IFSelect_Activator::*)(  const char * const  ,   const char * const   ) >(&IFSelect_Activator::SetForGroup),
             R"#(Group and SetGroup define a "Group of commands" which correspond to an Activator. Default is "XSTEP" Also a file may be attached)#"  , py::arg("group"),  py::arg("file")=static_cast< const char * const >("")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Adding_s",
                    (void (*)(  const handle<IFSelect_Activator> & ,   const int ,   const char * const  ,   const int  ) ) static_cast<void (*)(  const handle<IFSelect_Activator> & ,   const int ,   const char * const  ,   const int  ) >(&IFSelect_Activator::Adding),
                    R"#(Records, in a Dictionary available for all the Activators, the command title an Activator can process, attached with its number, proper for this Activator <mode> allows to distinguish various execution modes 0: default mode; 1 : for xset)#"  , py::arg("actor"),  py::arg("number"),  py::arg("command"),  py::arg("mode")
          )
        .def_static("Remove_s",
                    (void (*)(  const char * const   ) ) static_cast<void (*)(  const char * const   ) >(&IFSelect_Activator::Remove),
                    R"#(Removes a Command, if it is recorded (else, does nothing))#"  , py::arg("command")
          )
        .def_static("Select_s",
                    (bool (*)(  const char * const  ,  int & ,  handle<IFSelect_Activator> &  ) ) static_cast<bool (*)(  const char * const  ,  int & ,  handle<IFSelect_Activator> &  ) >(&IFSelect_Activator::Select),
                    R"#(Selects, for a Command given by its title, an actor with its command number. Returns True if found, False else)#"  , py::arg("command"),  py::arg("number"),  py::arg("actor")
          )
        .def_static("Mode_s",
                    (int (*)(  const char * const   ) ) static_cast<int (*)(  const char * const   ) >(&IFSelect_Activator::Mode),
                    R"#(Returns mode recorded for a command. -1 if not found)#"  , py::arg("command")
          )
        .def_static("Commands_s",
                    (handle<NCollection_HSequence<TCollection_AsciiString>> (*)(  const int ,   const char * const   ) ) static_cast<handle<NCollection_HSequence<TCollection_AsciiString>> (*)(  const int ,   const char * const   ) >(&IFSelect_Activator::Commands),
                    R"#(Returns, for a root of command title, the list of possible commands. <mode> : -1 (D) for all commands if <commands> is empty -1 + command : about a Group , >= 0 see Adding By default, it returns the whole list of known commands.)#"  , py::arg("mode")=static_cast< const int>(- 1),  py::arg("command")=static_cast< const char * const >("")
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_Activator::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_Activator::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_Activator::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_Activator::*)() const>(&IFSelect_Activator::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_AppliedModifiers from ./opencascade/IFSelect_AppliedModifiers.hxx
    klass = m.attr("IFSelect_AppliedModifiers");


    // nested enums

    static_cast<py::class_<IFSelect_AppliedModifiers ,opencascade::handle<IFSelect_AppliedModifiers>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const int, const int >()  , py::arg("nbmax"),  py::arg("nbent") )
    // custom constructors
    // methods
        .def("AddModif",
             (bool (IFSelect_AppliedModifiers::*)(  const handle<IFSelect_GeneralModifier> &  ) ) static_cast<bool (IFSelect_AppliedModifiers::*)(  const handle<IFSelect_GeneralModifier> &  ) >(&IFSelect_AppliedModifiers::AddModif),
             R"#(Records a modifier. By default, it is to apply on all a produced file. Further calls to AddNum will restrict this. Returns True if done, False if too many modifiers are already recorded)#"  , py::arg("modif")
          )
        .def("AddNum",
             (bool (IFSelect_AppliedModifiers::*)(  const int  ) ) static_cast<bool (IFSelect_AppliedModifiers::*)(  const int  ) >(&IFSelect_AppliedModifiers::AddNum),
             R"#(Adds a number of entity of the output file to be applied on. If a sequence of AddNum is called after AddModif, this Modifier will be applied on the list of designated entities. Else, it will be applied on all the file Returns True if done, False if no modifier has yet been added)#"  , py::arg("nument")
          )
        .def("Count",
             (int (IFSelect_AppliedModifiers::*)() const) static_cast<int (IFSelect_AppliedModifiers::*)() const>(&IFSelect_AppliedModifiers::Count),
             R"#(Returns the count of recorded modifiers)#" 
          )
        .def("Item",
             (bool (IFSelect_AppliedModifiers::*)(  const int ,  handle<IFSelect_GeneralModifier> & ,  int &  ) ) static_cast<bool (IFSelect_AppliedModifiers::*)(  const int ,  handle<IFSelect_GeneralModifier> & ,  int &  ) >(&IFSelect_AppliedModifiers::Item),
             R"#(Returns the description for applied modifier n0 <num> : the modifier itself, and the count of entities to be applied on. If no specific list of number has been defined, returns the total count of entities of the file If this count is zero, then the modifier applies to all the file (see below). Else, the numbers are then queried by calls to ItemNum between 1 and <entcount> Returns True if OK, False if <num> is out of range)#"  , py::arg("num"),  py::arg("modif"),  py::arg("entcount")
          )
        .def("ItemNum",
             (int (IFSelect_AppliedModifiers::*)(  const int  ) const) static_cast<int (IFSelect_AppliedModifiers::*)(  const int  ) const>(&IFSelect_AppliedModifiers::ItemNum),
             R"#(Returns a numero of entity to be applied on, given its rank in the list. If no list is defined (i.e. for all the file), returns <nument> itself, to give all the entities of the file Returns 0 if <nument> out of range)#"  , py::arg("nument")
          )
        .def("ItemList",
             (handle<NCollection_HSequence<int>> (IFSelect_AppliedModifiers::*)() const) static_cast<handle<NCollection_HSequence<int>> (IFSelect_AppliedModifiers::*)() const>(&IFSelect_AppliedModifiers::ItemList),
             R"#(Returns the list of entities to be applied on (see Item) as a HSequence (IsForAll produces the complete list of all the entity numbers of the file)#" 
          )
        .def("IsForAll",
             (bool (IFSelect_AppliedModifiers::*)() const) static_cast<bool (IFSelect_AppliedModifiers::*)() const>(&IFSelect_AppliedModifiers::IsForAll),
             R"#(Returns True if the applied modifier queried by last call to Item is to be applied to all the produced file. Else, <entcount> returned by Item gives the count of entity numbers, each one is queried by ItemNum)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_AppliedModifiers::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_AppliedModifiers::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_AppliedModifiers::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_AppliedModifiers::*)() const>(&IFSelect_AppliedModifiers::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_ContextModif from ./opencascade/IFSelect_ContextModif.hxx
    klass = m.attr("IFSelect_ContextModif");

    // default constructor
    register_default_constructor<IFSelect_ContextModif , shared_ptr<IFSelect_ContextModif>>(m,"IFSelect_ContextModif");

    // nested enums

    static_cast<py::class_<IFSelect_ContextModif , shared_ptr<IFSelect_ContextModif>  >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("HasFileName",
             (bool (IFSelect_ContextModif::*)() const) static_cast<bool (IFSelect_ContextModif::*)() const>(&IFSelect_ContextModif::HasFileName),
             R"#(Returns True if a non empty file name has been defined)#" 
          )
        .def("FileName",
             ( const char * (IFSelect_ContextModif::*)() const) static_cast< const char * (IFSelect_ContextModif::*)() const>(&IFSelect_ContextModif::FileName),
             R"#(Returns File Name (can be empty))#" 
          )
        .def("IsForNone",
             (bool (IFSelect_ContextModif::*)() const) static_cast<bool (IFSelect_ContextModif::*)() const>(&IFSelect_ContextModif::IsForNone),
             R"#(Returns True if Select has determined that a Modifier may not be run (filter defined and empty))#" 
          )
        .def("IsForAll",
             (bool (IFSelect_ContextModif::*)() const) static_cast<bool (IFSelect_ContextModif::*)() const>(&IFSelect_ContextModif::IsForAll),
             R"#(Returns True if no filter is defined : a Modifier has to work on all entities of the resulting (target) model)#" 
          )
        .def("IsTransferred",
             (bool (IFSelect_ContextModif::*)(  const handle<Standard_Transient> &  ) const) static_cast<bool (IFSelect_ContextModif::*)(  const handle<Standard_Transient> &  ) const>(&IFSelect_ContextModif::IsTransferred),
             R"#(Returns True if a starting item has been transferred)#"  , py::arg("ent")
          )
        .def("IsSelected",
             (bool (IFSelect_ContextModif::*)(  const handle<Standard_Transient> &  ) const) static_cast<bool (IFSelect_ContextModif::*)(  const handle<Standard_Transient> &  ) const>(&IFSelect_ContextModif::IsSelected),
             R"#(Returns True if a starting item has been transferred and selected)#"  , py::arg("ent")
          )
        .def("SelectedCount",
             (int (IFSelect_ContextModif::*)() const) static_cast<int (IFSelect_ContextModif::*)() const>(&IFSelect_ContextModif::SelectedCount),
             R"#(Returns the count of selected and transferred items)#" 
          )
        .def("Start",
             (void (IFSelect_ContextModif::*)() ) static_cast<void (IFSelect_ContextModif::*)() >(&IFSelect_ContextModif::Start),
             R"#(Starts an iteration on selected items. It takes into account IsForAll/IsForNone, by really iterating on all selected items.)#" 
          )
        .def("More",
             (bool (IFSelect_ContextModif::*)() const) static_cast<bool (IFSelect_ContextModif::*)() const>(&IFSelect_ContextModif::More),
             R"#(Returns True until the iteration has finished)#" 
          )
        .def("Next",
             (void (IFSelect_ContextModif::*)() ) static_cast<void (IFSelect_ContextModif::*)() >(&IFSelect_ContextModif::Next),
             R"#(Advances the iteration)#" 
          )
        .def("ValueOriginal",
             (handle<Standard_Transient> (IFSelect_ContextModif::*)() const) static_cast<handle<Standard_Transient> (IFSelect_ContextModif::*)() const>(&IFSelect_ContextModif::ValueOriginal),
             R"#(Returns the current selected item in the original model)#" 
          )
        .def("ValueResult",
             (handle<Standard_Transient> (IFSelect_ContextModif::*)() const) static_cast<handle<Standard_Transient> (IFSelect_ContextModif::*)() const>(&IFSelect_ContextModif::ValueResult),
             R"#(Returns the result counterpart of current selected item (in the target model))#" 
          )
        .def("TraceModifier",
             (void (IFSelect_ContextModif::*)(  const handle<IFSelect_GeneralModifier> &  ) ) static_cast<void (IFSelect_ContextModif::*)(  const handle<IFSelect_GeneralModifier> &  ) >(&IFSelect_ContextModif::TraceModifier),
             R"#(Traces the application of a Modifier. Works with default trace File and Level. Fills the trace if default trace level is at least 1. Traces the Modifier (its Label) and its Selection if there is one (its Label). To be called after Select (because status IsForAll is printed) Worths to trace a global modification. See also Trace below)#"  , py::arg("modif")
          )
        .def("Trace",
             (void (IFSelect_ContextModif::*)(  const char * const   ) ) static_cast<void (IFSelect_ContextModif::*)(  const char * const   ) >(&IFSelect_ContextModif::Trace),
             R"#(Traces the modification of the current entity (see above, ValueOriginal and ValueResult) for default trace level >= 2. To be called on each individual entity really modified <mess> is an optional additional message)#"  , py::arg("mess")=static_cast< const char * const >("")
          )
        .def("AddWarning",
             (void (IFSelect_ContextModif::*)(  const handle<Standard_Transient> & ,   const char * const  ,   const char * const   ) ) static_cast<void (IFSelect_ContextModif::*)(  const handle<Standard_Transient> & ,   const char * const  ,   const char * const   ) >(&IFSelect_ContextModif::AddWarning),
             R"#(Adds a Warning Message for an Entity from the original Model If <start> is not an Entity from the original model (e.g. the model itself) this message is added to Global Check.)#"  , py::arg("start"),  py::arg("mess"),  py::arg("orig")=static_cast< const char * const >("")
          )
        .def("AddFail",
             (void (IFSelect_ContextModif::*)(  const handle<Standard_Transient> & ,   const char * const  ,   const char * const   ) ) static_cast<void (IFSelect_ContextModif::*)(  const handle<Standard_Transient> & ,   const char * const  ,   const char * const   ) >(&IFSelect_ContextModif::AddFail),
             R"#(Adds a Fail Message for an Entity from the original Model If <start> is not an Entity from the original model (e.g. the model itself) this message is added to Global Check.)#"  , py::arg("start"),  py::arg("mess"),  py::arg("orig")=static_cast< const char * const >("")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IFSelect_ContextWrite from ./opencascade/IFSelect_ContextWrite.hxx
    klass = m.attr("IFSelect_ContextWrite");

    // default constructor
    register_default_constructor<IFSelect_ContextWrite , shared_ptr<IFSelect_ContextWrite>>(m,"IFSelect_ContextWrite");

    // nested enums

    static_cast<py::class_<IFSelect_ContextWrite , shared_ptr<IFSelect_ContextWrite>  >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("FileName",
             ( const char * (IFSelect_ContextWrite::*)() const) static_cast< const char * (IFSelect_ContextWrite::*)() const>(&IFSelect_ContextWrite::FileName),
             R"#(Returns the File Name)#" 
          )
        .def("AppliedModifiers",
             (handle<IFSelect_AppliedModifiers> (IFSelect_ContextWrite::*)() const) static_cast<handle<IFSelect_AppliedModifiers> (IFSelect_ContextWrite::*)() const>(&IFSelect_ContextWrite::AppliedModifiers),
             R"#(Returns the object AppliedModifiers)#" 
          )
        .def("NbModifiers",
             (int (IFSelect_ContextWrite::*)() const) static_cast<int (IFSelect_ContextWrite::*)() const>(&IFSelect_ContextWrite::NbModifiers),
             R"#(Returns the count of recorded File Modifiers)#" 
          )
        .def("SetModifier",
             (bool (IFSelect_ContextWrite::*)(  const int  ) ) static_cast<bool (IFSelect_ContextWrite::*)(  const int  ) >(&IFSelect_ContextWrite::SetModifier),
             R"#(Sets active the File Modifier n0 <numod> Then, it prepares the list of entities to consider, if any Returns False if <numod> out of range)#"  , py::arg("numod")
          )
        .def("FileModifier",
             (handle<IFSelect_GeneralModifier> (IFSelect_ContextWrite::*)() const) static_cast<handle<IFSelect_GeneralModifier> (IFSelect_ContextWrite::*)() const>(&IFSelect_ContextWrite::FileModifier),
             R"#(Returns the currently active File Modifier. Cast to be done Null if not properly set : must be test IsNull after casting)#" 
          )
        .def("IsForNone",
             (bool (IFSelect_ContextWrite::*)() const) static_cast<bool (IFSelect_ContextWrite::*)() const>(&IFSelect_ContextWrite::IsForNone),
             R"#(Returns True if no modifier is currently set)#" 
          )
        .def("IsForAll",
             (bool (IFSelect_ContextWrite::*)() const) static_cast<bool (IFSelect_ContextWrite::*)() const>(&IFSelect_ContextWrite::IsForAll),
             R"#(Returns True if the current modifier is to be applied to the whole model. Else, a restricted list of selected entities is defined, it can be exploited by the File Modifier)#" 
          )
        .def("NbEntities",
             (int (IFSelect_ContextWrite::*)() const) static_cast<int (IFSelect_ContextWrite::*)() const>(&IFSelect_ContextWrite::NbEntities),
             R"#(Returns the total count of selected entities)#" 
          )
        .def("Start",
             (void (IFSelect_ContextWrite::*)() ) static_cast<void (IFSelect_ContextWrite::*)() >(&IFSelect_ContextWrite::Start),
             R"#(Starts an iteration on selected items. It takes into account IsForAll/IsForNone, by really iterating on all selected items.)#" 
          )
        .def("More",
             (bool (IFSelect_ContextWrite::*)() const) static_cast<bool (IFSelect_ContextWrite::*)() const>(&IFSelect_ContextWrite::More),
             R"#(Returns True until the iteration has finished)#" 
          )
        .def("Next",
             (void (IFSelect_ContextWrite::*)() ) static_cast<void (IFSelect_ContextWrite::*)() >(&IFSelect_ContextWrite::Next),
             R"#(Advances the iteration)#" 
          )
        .def("Value",
             (handle<Standard_Transient> (IFSelect_ContextWrite::*)() const) static_cast<handle<Standard_Transient> (IFSelect_ContextWrite::*)() const>(&IFSelect_ContextWrite::Value),
             R"#(Returns the current selected entity in the model)#" 
          )
        .def("AddWarning",
             (void (IFSelect_ContextWrite::*)(  const handle<Standard_Transient> & ,   const char * const  ,   const char * const   ) ) static_cast<void (IFSelect_ContextWrite::*)(  const handle<Standard_Transient> & ,   const char * const  ,   const char * const   ) >(&IFSelect_ContextWrite::AddWarning),
             R"#(Adds a Warning Message for an Entity from the Model If <start> is not an Entity from the model (e.g. the model itself) this message is added to Global Check.)#"  , py::arg("start"),  py::arg("mess"),  py::arg("orig")=static_cast< const char * const >("")
          )
        .def("AddFail",
             (void (IFSelect_ContextWrite::*)(  const handle<Standard_Transient> & ,   const char * const  ,   const char * const   ) ) static_cast<void (IFSelect_ContextWrite::*)(  const handle<Standard_Transient> & ,   const char * const  ,   const char * const   ) >(&IFSelect_ContextWrite::AddFail),
             R"#(Adds a Fail Message for an Entity from the Model If <start> is not an Entity from the model (e.g. the model itself) this message is added to Global Check.)#"  , py::arg("start"),  py::arg("mess"),  py::arg("orig")=static_cast< const char * const >("")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IFSelect_Dispatch from ./opencascade/IFSelect_Dispatch.hxx
    klass = m.attr("IFSelect_Dispatch");


    // nested enums

    static_cast<py::class_<IFSelect_Dispatch ,opencascade::handle<IFSelect_Dispatch> ,Py_IFSelect_Dispatch , Standard_Transient >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("SetRootName",
             (void (IFSelect_Dispatch::*)(  const handle<TCollection_HAsciiString> &  ) ) static_cast<void (IFSelect_Dispatch::*)(  const handle<TCollection_HAsciiString> &  ) >(&IFSelect_Dispatch::SetRootName),
             R"#(Sets a Root Name as an HAsciiString To reset it, give a Null Handle (then, a ShareOut will have to define the Default Root Name))#"  , py::arg("name")
          )
        .def("HasRootName",
             (bool (IFSelect_Dispatch::*)() const) static_cast<bool (IFSelect_Dispatch::*)() const>(&IFSelect_Dispatch::HasRootName),
             R"#(Returns True if a specific Root Name has been set (else, the Default Root Name has to be used))#" 
          )
        .def("SetFinalSelection",
             (void (IFSelect_Dispatch::*)(  const handle<IFSelect_Selection> &  ) ) static_cast<void (IFSelect_Dispatch::*)(  const handle<IFSelect_Selection> &  ) >(&IFSelect_Dispatch::SetFinalSelection),
             R"#(Stores (or Changes) the Final Selection for a Dispatch)#"  , py::arg("sel")
          )
        .def("FinalSelection",
             (handle<IFSelect_Selection> (IFSelect_Dispatch::*)() const) static_cast<handle<IFSelect_Selection> (IFSelect_Dispatch::*)() const>(&IFSelect_Dispatch::FinalSelection),
             R"#(Returns the Final Selection of a Dispatch we 'd like : C++ : return const &)#" 
          )
        .def("Selections",
             (IFSelect_SelectionIterator (IFSelect_Dispatch::*)() const) static_cast<IFSelect_SelectionIterator (IFSelect_Dispatch::*)() const>(&IFSelect_Dispatch::Selections),
             R"#(Returns the complete list of source Selections (starting from FinalSelection))#" 
          )
        .def("CanHaveRemainder",
             (bool (IFSelect_Dispatch::*)() const) static_cast<bool (IFSelect_Dispatch::*)() const>(&IFSelect_Dispatch::CanHaveRemainder),
             R"#(Returns True if a Dispatch can have a Remainder, i.e. if its criterium can let entities apart. It is a potential answer, remainder can be empty at run-time even if answer is True. (to attach a RemainderFromDispatch Selection is not allowed if answer is True). Default answer given here is False (can be redefined))#" 
          )
        .def("LimitedMax",
             (bool (IFSelect_Dispatch::*)(  const int ,  int &  ) const) static_cast<bool (IFSelect_Dispatch::*)(  const int ,  int &  ) const>(&IFSelect_Dispatch::LimitedMax),
             R"#(Returns True if a Dispatch generates a count of Packets always less than or equal to a maximum value : it can be computed from the total count of Entities to be dispatched : <nbent>. If answer is False, no limited maximum is expected for account If answer is True, expected maximum is given in argument <max> Default answer given here is False (can be redefined))#"  , py::arg("nbent"),  py::arg("max")
          )
        .def("Label",
             (TCollection_AsciiString (IFSelect_Dispatch::*)() const) static_cast<TCollection_AsciiString (IFSelect_Dispatch::*)() const>(&IFSelect_Dispatch::Label),
             R"#(Returns a text which defines the way a Dispatch produces packets (which will become files) from its Input)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_Dispatch::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_Dispatch::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("RootName",
             ( const handle<TCollection_HAsciiString> & (IFSelect_Dispatch::*)() const) static_cast< const handle<TCollection_HAsciiString> & (IFSelect_Dispatch::*)() const>(&IFSelect_Dispatch::RootName),
             R"#(Returns the Root Name for files produced by this dispatch It is empty if it has not been set or if it has been reset)#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_Dispatch::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_Dispatch::*)() const>(&IFSelect_Dispatch::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_EditForm from ./opencascade/IFSelect_EditForm.hxx
    klass = m.attr("IFSelect_EditForm");


    // nested enums

    static_cast<py::class_<IFSelect_EditForm ,opencascade::handle<IFSelect_EditForm>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const handle<IFSelect_Editor> &, const NCollection_Sequence<int> &, const bool, const bool, const char * const  >()  , py::arg("editor"),  py::arg("nums"),  py::arg("readonly"),  py::arg("undoable"),  py::arg("label")=static_cast< const char * const >("") )
        .def(py::init<  const handle<IFSelect_Editor> &, const bool, const bool, const char * const  >()  , py::arg("editor"),  py::arg("readonly"),  py::arg("undoable"),  py::arg("label")=static_cast< const char * const >("") )
    // custom constructors
    // methods
        .def("Label",
             ( const char * (IFSelect_EditForm::*)() const) static_cast< const char * (IFSelect_EditForm::*)() const>(&IFSelect_EditForm::Label),
             R"#()#" 
          )
        .def("IsLoaded",
             (bool (IFSelect_EditForm::*)() const) static_cast<bool (IFSelect_EditForm::*)() const>(&IFSelect_EditForm::IsLoaded),
             R"#(Tells if the EditForm is loaded now)#" 
          )
        .def("ClearData",
             (void (IFSelect_EditForm::*)() ) static_cast<void (IFSelect_EditForm::*)() >(&IFSelect_EditForm::ClearData),
             R"#()#" 
          )
        .def("SetEntity",
             (void (IFSelect_EditForm::*)(  const handle<Standard_Transient> &  ) ) static_cast<void (IFSelect_EditForm::*)(  const handle<Standard_Transient> &  ) >(&IFSelect_EditForm::SetEntity),
             R"#()#"  , py::arg("ent")
          )
        .def("Entity",
             (handle<Standard_Transient> (IFSelect_EditForm::*)() const) static_cast<handle<Standard_Transient> (IFSelect_EditForm::*)() const>(&IFSelect_EditForm::Entity),
             R"#()#" 
          )
        .def("Editor",
             (handle<IFSelect_Editor> (IFSelect_EditForm::*)() const) static_cast<handle<IFSelect_Editor> (IFSelect_EditForm::*)() const>(&IFSelect_EditForm::Editor),
             R"#()#" 
          )
        .def("IsComplete",
             (bool (IFSelect_EditForm::*)() const) static_cast<bool (IFSelect_EditForm::*)() const>(&IFSelect_EditForm::IsComplete),
             R"#(Tells if an EditForm is complete or is an extract from Editor)#" 
          )
        .def("NbValues",
             (int (IFSelect_EditForm::*)(  const bool  ) const) static_cast<int (IFSelect_EditForm::*)(  const bool  ) const>(&IFSelect_EditForm::NbValues),
             R"#(Returns the count of values <editable> True : count of editable values, i.e. For a complete EditForm, it is given by the Editor Else, it is the length of the extraction map <editable> False : all the values from the Editor)#"  , py::arg("editable")
          )
        .def("NumberFromRank",
             (int (IFSelect_EditForm::*)(  const int  ) const) static_cast<int (IFSelect_EditForm::*)(  const int  ) const>(&IFSelect_EditForm::NumberFromRank),
             R"#(Returns the Value Number in the Editor from a given Rank in the EditForm For a complete EditForm, both are equal Else, it is given by the extraction map Returns 0 if <rank> exceeds the count of editable values,)#"  , py::arg("rank")
          )
        .def("RankFromNumber",
             (int (IFSelect_EditForm::*)(  const int  ) const) static_cast<int (IFSelect_EditForm::*)(  const int  ) const>(&IFSelect_EditForm::RankFromNumber),
             R"#(Returns the Rank in the EditForm from a given Number of Value for the Editor For a complete EditForm, both are equal Else, it is given by the extraction map Returns 0 if <number> is not forecast to be edited, or is out of range)#"  , py::arg("number")
          )
        .def("NameNumber",
             (int (IFSelect_EditForm::*)(  const char * const   ) const) static_cast<int (IFSelect_EditForm::*)(  const char * const   ) const>(&IFSelect_EditForm::NameNumber),
             R"#(Returns the Value Number in the Editor for a given Name i.e. the true ValueNumber which can be used in various methods of EditForm If it is not complete, for a recorded (in the Editor) but non-loaded name, returns negative value (- number))#"  , py::arg("name")
          )
        .def("NameRank",
             (int (IFSelect_EditForm::*)(  const char * const   ) const) static_cast<int (IFSelect_EditForm::*)(  const char * const   ) const>(&IFSelect_EditForm::NameRank),
             R"#(Returns the Rank of Value in the EditForm for a given Name i.e. if it is not complete, for a recorded (in the Editor) but non-loaded name, returns 0)#"  , py::arg("name")
          )
        .def("LoadDefault",
             (void (IFSelect_EditForm::*)() ) static_cast<void (IFSelect_EditForm::*)() >(&IFSelect_EditForm::LoadDefault),
             R"#(For a read-write undoable EditForm, loads original values from defaults stored in the Editor)#" 
          )
        .def("LoadEntity",
             (bool (IFSelect_EditForm::*)(  const handle<Standard_Transient> &  ) ) static_cast<bool (IFSelect_EditForm::*)(  const handle<Standard_Transient> &  ) >(&IFSelect_EditForm::LoadEntity),
             R"#(Shortcut for LoadData when <model> is not used)#"  , py::arg("ent")
          )
        .def("LoadData",
             (bool (IFSelect_EditForm::*)() ) static_cast<bool (IFSelect_EditForm::*)() >(&IFSelect_EditForm::LoadData),
             R"#(Shortcut when both <ent> and <model> are not used (when the Editor works on fully static or global data))#" 
          )
        .def("ListEditor",
             (handle<IFSelect_ListEditor> (IFSelect_EditForm::*)(  const int  ) const) static_cast<handle<IFSelect_ListEditor> (IFSelect_EditForm::*)(  const int  ) const>(&IFSelect_EditForm::ListEditor),
             R"#(Returns a ListEditor to edit the parameter <num> of the EditForm, if it is a List The Editor created it (by ListEditor) then loads it (by ListValue) For a single parameter, returns a Null Handle ...)#"  , py::arg("num")
          )
        .def("LoadValue",
             (void (IFSelect_EditForm::*)(  const int ,   const handle<TCollection_HAsciiString> &  ) ) static_cast<void (IFSelect_EditForm::*)(  const int ,   const handle<TCollection_HAsciiString> &  ) >(&IFSelect_EditForm::LoadValue),
             R"#(Loads an original value (single). Called by the Editor only)#"  , py::arg("num"),  py::arg("val")
          )
        .def("LoadList",
             (void (IFSelect_EditForm::*)(  const int ,   const handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> &  ) ) static_cast<void (IFSelect_EditForm::*)(  const int ,   const handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> &  ) >(&IFSelect_EditForm::LoadList),
             R"#(Loads an original value as a list. Called by the Editor only)#"  , py::arg("num"),  py::arg("list")
          )
        .def("OriginalValue",
             (handle<TCollection_HAsciiString> (IFSelect_EditForm::*)(  const int  ) const) static_cast<handle<TCollection_HAsciiString> (IFSelect_EditForm::*)(  const int  ) const>(&IFSelect_EditForm::OriginalValue),
             R"#(From an edited value, returns its ... value (original one) Null means that this value is not defined <num> is for the EditForm, not the Editor It is for a single parameter. For a list, gives a Null Handle)#"  , py::arg("num")
          )
        .def("OriginalList",
             (handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> (IFSelect_EditForm::*)(  const int  ) const) static_cast<handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> (IFSelect_EditForm::*)(  const int  ) const>(&IFSelect_EditForm::OriginalList),
             R"#(Returns an original value, as a list <num> is for the EditForm, not the Editor For a single parameter, gives a Null Handle)#"  , py::arg("num")
          )
        .def("EditedValue",
             (handle<TCollection_HAsciiString> (IFSelect_EditForm::*)(  const int  ) const) static_cast<handle<TCollection_HAsciiString> (IFSelect_EditForm::*)(  const int  ) const>(&IFSelect_EditForm::EditedValue),
             R"#(Returns the Edited (i.e. Modified) Value (string for single) <num> reports to the EditForm If IsModified is False, returns OriginalValue Null with IsModified True : means that this value is not defined or has been removed It is for a single parameter. For a list, gives a Null Handle)#"  , py::arg("num")
          )
        .def("EditedList",
             (handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> (IFSelect_EditForm::*)(  const int  ) const) static_cast<handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> (IFSelect_EditForm::*)(  const int  ) const>(&IFSelect_EditForm::EditedList),
             R"#(Returns the Edited Value as a list If IsModified is False, returns OriginalValue Null with IsModified True : means that this value is not defined or has been removed For a single parameter, gives a Null Handle)#"  , py::arg("num")
          )
        .def("IsModified",
             (bool (IFSelect_EditForm::*)(  const int  ) const) static_cast<bool (IFSelect_EditForm::*)(  const int  ) const>(&IFSelect_EditForm::IsModified),
             R"#(Tells if a Value (of the EditForm) is modified (directly or through touching by Update))#"  , py::arg("num")
          )
        .def("IsTouched",
             (bool (IFSelect_EditForm::*)(  const int  ) const) static_cast<bool (IFSelect_EditForm::*)(  const int  ) const>(&IFSelect_EditForm::IsTouched),
             R"#(Tells if a Value (of the EditForm) has been touched, i.e. not modified directly but by the modification of another one (by method Update from the Editor))#"  , py::arg("num")
          )
        .def("Modify",
             (bool (IFSelect_EditForm::*)(  const int ,   const handle<TCollection_HAsciiString> & ,   const bool  ) ) static_cast<bool (IFSelect_EditForm::*)(  const int ,   const handle<TCollection_HAsciiString> & ,   const bool  ) >(&IFSelect_EditForm::Modify),
             R"#(Gives a new value for the item <num> of the EditForm, if it is a single parameter (for a list, just returns False) Null means to Remove it <enforce> True to overpass Protected or Computed Access Mode Calls the method Update from the Editor, which can touch other parameters (see NbTouched) Returns True if well recorded, False if this value is not allowed Warning : Does not apply immediately : will be applied by the method Apply)#"  , py::arg("num"),  py::arg("newval"),  py::arg("enforce")=static_cast< const bool>(false)
          )
        .def("ModifyList",
             (bool (IFSelect_EditForm::*)(  const int ,   const handle<IFSelect_ListEditor> & ,   const bool  ) ) static_cast<bool (IFSelect_EditForm::*)(  const int ,   const handle<IFSelect_ListEditor> & ,   const bool  ) >(&IFSelect_EditForm::ModifyList),
             R"#(Changes the value of an item of the EditForm, if it is a List (else, just returns False) The ListEditor contains the edited values of the list If no edition was recorded, just returns False Calls the method Update from the Editor, which can touch other parameters (see NbTouched) Returns True if well recorded, False if this value is not allowed Warning : Does not apply immediately : will be applied by the method Apply)#"  , py::arg("num"),  py::arg("edited"),  py::arg("enforce")=static_cast< const bool>(false)
          )
        .def("ModifyListValue",
             (bool (IFSelect_EditForm::*)(  const int ,   const handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> & ,   const bool  ) ) static_cast<bool (IFSelect_EditForm::*)(  const int ,   const handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> & ,   const bool  ) >(&IFSelect_EditForm::ModifyListValue),
             R"#(As ModifyList but the new value is given as such Creates a ListEditor, Loads it, then calls ModifyList)#"  , py::arg("num"),  py::arg("list"),  py::arg("enforce")=static_cast< const bool>(false)
          )
        .def("Touch",
             (bool (IFSelect_EditForm::*)(  const int ,   const handle<TCollection_HAsciiString> &  ) ) static_cast<bool (IFSelect_EditForm::*)(  const int ,   const handle<TCollection_HAsciiString> &  ) >(&IFSelect_EditForm::Touch),
             R"#(Gives a new value computed by the Editor, if another parameter commands the value of <num> It is generally the case for a Computed Parameter for instance Increments the counter of touched parameters Warning : it gives no protection for ReadOnly etc... while it is the internal way of touching parameters Does not work (returns False) if <num> is for a list)#"  , py::arg("num"),  py::arg("newval")
          )
        .def("TouchList",
             (bool (IFSelect_EditForm::*)(  const int ,   const handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> &  ) ) static_cast<bool (IFSelect_EditForm::*)(  const int ,   const handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> &  ) >(&IFSelect_EditForm::TouchList),
             R"#(Acts as Touch but for a list Does not work (returns False) if <num> is for a single param)#"  , py::arg("num"),  py::arg("newlist")
          )
        .def("ClearEdit",
             (void (IFSelect_EditForm::*)(  const int  ) ) static_cast<void (IFSelect_EditForm::*)(  const int  ) >(&IFSelect_EditForm::ClearEdit),
             R"#(Clears modification status : by default all, or one by its numbers (in the Editor))#"  , py::arg("num")=static_cast< const int>(0)
          )
        .def("PrintDefs",
             (void (IFSelect_EditForm::*)( Standard_OStream &  ) const) static_cast<void (IFSelect_EditForm::*)( Standard_OStream &  ) const>(&IFSelect_EditForm::PrintDefs),
             R"#(Prints Definitions, relative to the Editor)#"  , py::arg("S")
          )
        .def("PrintValues",
             (void (IFSelect_EditForm::*)( Standard_OStream & ,   const int ,   const bool ,   const bool  ) const) static_cast<void (IFSelect_EditForm::*)( Standard_OStream & ,   const int ,   const bool ,   const bool  ) const>(&IFSelect_EditForm::PrintValues),
             R"#(Prints Values, according to what and alsolist <names> True : prints Long Names; False : prints Short Names <what> < 0 : prints Original Values (+ flag Modified) <what> > 0 : prints Final Values (+flag Modified) <what> = 0 : prints Modified Values (Original + Edited) <alsolist> False (D) : lists are printed only as their count <alsolist> True : lists are printed for all their items)#"  , py::arg("S"),  py::arg("what"),  py::arg("names"),  py::arg("alsolist")=static_cast< const bool>(false)
          )
        .def("Apply",
             (bool (IFSelect_EditForm::*)() ) static_cast<bool (IFSelect_EditForm::*)() >(&IFSelect_EditForm::Apply),
             R"#(Applies modifications to own data Calls ApplyData then Clears Status according EditKeepStatus)#" 
          )
        .def("Recognize",
             (bool (IFSelect_EditForm::*)() const) static_cast<bool (IFSelect_EditForm::*)() const>(&IFSelect_EditForm::Recognize),
             R"#(Tells if this EditForm can work with its Editor and its actual Data (Entity and Model) Default uses Editor. Can be redefined)#" 
          )
        .def("Undo",
             (bool (IFSelect_EditForm::*)() ) static_cast<bool (IFSelect_EditForm::*)() >(&IFSelect_EditForm::Undo),
             R"#(For an undoable EditForm, Applies ... origibal values ! and clears modified ones Can be run only once)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_EditForm::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_EditForm::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def_property("EditKeepStatus",
                     [](IFSelect_EditForm& self){return self.EditKeepStatus();} ,
                     [](IFSelect_EditForm& self, bool  val){self.EditKeepStatus() = val;},                      R"#(Returns and may change the keep status on modif It starts as False If it is True, Apply does not clear modification status and the EditForm can be loaded again, modified value remain and may be applied again Remark that ApplyData does not clear the modification status, a call to ClearEdit does)#"
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_EditForm::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_EditForm::*)() const>(&IFSelect_EditForm::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_Editor from ./opencascade/IFSelect_Editor.hxx
    klass = m.attr("IFSelect_Editor");


    // nested enums

    static_cast<py::class_<IFSelect_Editor ,opencascade::handle<IFSelect_Editor> ,Py_IFSelect_Editor , Standard_Transient >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("SetList",
             (void (IFSelect_Editor::*)(  const int ,   const int  ) ) static_cast<void (IFSelect_Editor::*)(  const int ,   const int  ) >(&IFSelect_Editor::SetList),
             R"#(Sets a parameter to be a List max < 0 : not for a list (set when starting) max = 0 : list with no length limit (default for SetList) max > 0 : list limited to <max> items)#"  , py::arg("num"),  py::arg("max")=static_cast< const int>(0)
          )
        .def("NbValues",
             (int (IFSelect_Editor::*)() const) static_cast<int (IFSelect_Editor::*)() const>(&IFSelect_Editor::NbValues),
             R"#(Returns the count of Typed Values)#" 
          )
        .def("IsList",
             (bool (IFSelect_Editor::*)(  const int  ) const) static_cast<bool (IFSelect_Editor::*)(  const int  ) const>(&IFSelect_Editor::IsList),
             R"#(Tells if a parameter is a list)#"  , py::arg("num")
          )
        .def("MaxList",
             (int (IFSelect_Editor::*)(  const int  ) const) static_cast<int (IFSelect_Editor::*)(  const int  ) const>(&IFSelect_Editor::MaxList),
             R"#(Returns max length allowed for a list = 0 means : list with no limit < 0 means : not a list)#"  , py::arg("num")
          )
        .def("Name",
             ( const char * (IFSelect_Editor::*)(  const int ,   const bool  ) const) static_cast< const char * (IFSelect_Editor::*)(  const int ,   const bool  ) const>(&IFSelect_Editor::Name),
             R"#(Returns the name of a Value (complete or short) from its ident Short Name can be empty)#"  , py::arg("num"),  py::arg("isshort")=static_cast< const bool>(false)
          )
        .def("EditMode",
             (IFSelect_EditValue (IFSelect_Editor::*)(  const int  ) const) static_cast<IFSelect_EditValue (IFSelect_Editor::*)(  const int  ) const>(&IFSelect_Editor::EditMode),
             R"#(Returns the edit mode of a Value)#"  , py::arg("num")
          )
        .def("NameNumber",
             (int (IFSelect_Editor::*)(  const char * const   ) const) static_cast<int (IFSelect_Editor::*)(  const char * const   ) const>(&IFSelect_Editor::NameNumber),
             R"#(Returns the number (ident) of a Value, from its name, short or complete. If not found, returns 0)#"  , py::arg("name")
          )
        .def("PrintNames",
             (void (IFSelect_Editor::*)( Standard_OStream &  ) const) static_cast<void (IFSelect_Editor::*)( Standard_OStream &  ) const>(&IFSelect_Editor::PrintNames),
             R"#()#"  , py::arg("S")
          )
        .def("PrintDefs",
             (void (IFSelect_Editor::*)( Standard_OStream & ,   const bool  ) const) static_cast<void (IFSelect_Editor::*)( Standard_OStream & ,   const bool  ) const>(&IFSelect_Editor::PrintDefs),
             R"#()#"  , py::arg("S"),  py::arg("labels")=static_cast< const bool>(false)
          )
        .def("MaxNameLength",
             (int (IFSelect_Editor::*)(  const int  ) const) static_cast<int (IFSelect_Editor::*)(  const int  ) const>(&IFSelect_Editor::MaxNameLength),
             R"#(Returns the MaxLength of, according to what : <what> = -1 : length of short names <what> = 0 : length of complete names <what> = 1 : length of values labels)#"  , py::arg("what")
          )
        .def("Label",
             (TCollection_AsciiString (IFSelect_Editor::*)() const) static_cast<TCollection_AsciiString (IFSelect_Editor::*)() const>(&IFSelect_Editor::Label),
             R"#(Returns the specific label)#" 
          )
        .def("Form",
             (handle<IFSelect_EditForm> (IFSelect_Editor::*)(  const bool ,   const bool  ) const) static_cast<handle<IFSelect_EditForm> (IFSelect_Editor::*)(  const bool ,   const bool  ) const>(&IFSelect_Editor::Form),
             R"#(Builds and Returns an EditForm, empty (no data yet) Can be redefined to return a specific type of EditForm)#"  , py::arg("readonly"),  py::arg("undoable")=static_cast< const bool>(true)
          )
        .def("Recognize",
             (bool (IFSelect_Editor::*)(  const handle<IFSelect_EditForm> &  ) const) static_cast<bool (IFSelect_Editor::*)(  const handle<IFSelect_EditForm> &  ) const>(&IFSelect_Editor::Recognize),
             R"#(Tells if this Editor can work on this EditForm and its content (model, entity ?))#"  , py::arg("form")
          )
        .def("StringValue",
             (handle<TCollection_HAsciiString> (IFSelect_Editor::*)(  const handle<IFSelect_EditForm> & ,   const int  ) const) static_cast<handle<TCollection_HAsciiString> (IFSelect_Editor::*)(  const handle<IFSelect_EditForm> & ,   const int  ) const>(&IFSelect_Editor::StringValue),
             R"#(Returns the value of an EditForm, for a given item (if not a list. for a list, a Null String may be returned))#"  , py::arg("form"),  py::arg("num")
          )
        .def("ListEditor",
             (handle<IFSelect_ListEditor> (IFSelect_Editor::*)(  const int  ) const) static_cast<handle<IFSelect_ListEditor> (IFSelect_Editor::*)(  const int  ) const>(&IFSelect_Editor::ListEditor),
             R"#(Returns a ListEditor for a parameter which is a List Default returns a basic ListEditor for a List, a Null Handle if <num> is not for a List. Can be redefined)#"  , py::arg("num")
          )
        .def("ListValue",
             (handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> (IFSelect_Editor::*)(  const handle<IFSelect_EditForm> & ,   const int  ) const) static_cast<handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> (IFSelect_Editor::*)(  const handle<IFSelect_EditForm> & ,   const int  ) const>(&IFSelect_Editor::ListValue),
             R"#(Returns the value of an EditForm as a List, for a given item If not a list, a Null Handle should be returned Default returns a Null Handle, because many Editors have no list to edit. To be redefined as required)#"  , py::arg("form"),  py::arg("num")
          )
        .def("Update",
             (bool (IFSelect_Editor::*)(  const handle<IFSelect_EditForm> & ,   const int ,   const handle<TCollection_HAsciiString> & ,   const bool  ) const) static_cast<bool (IFSelect_Editor::*)(  const handle<IFSelect_EditForm> & ,   const int ,   const handle<TCollection_HAsciiString> & ,   const bool  ) const>(&IFSelect_Editor::Update),
             R"#(Updates the EditForm when a parameter is modified I.E. default does nothing, can be redefined, as follows : Returns True when done (even if does nothing), False in case of refuse (for instance, if the new value is not suitable) <num> is the rank of the parameter for the EDITOR itself <enforce> True means that protected parameters can be touched)#"  , py::arg("form"),  py::arg("num"),  py::arg("newval"),  py::arg("enforce")
          )
        .def("UpdateList",
             (bool (IFSelect_Editor::*)(  const handle<IFSelect_EditForm> & ,   const int ,   const handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> & ,   const bool  ) const) static_cast<bool (IFSelect_Editor::*)(  const handle<IFSelect_EditForm> & ,   const int ,   const handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> & ,   const bool  ) const>(&IFSelect_Editor::UpdateList),
             R"#(Acts as Update, but when the value is a list)#"  , py::arg("form"),  py::arg("num"),  py::arg("newlist"),  py::arg("enforce")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_Editor::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_Editor::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_Editor::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_Editor::*)() const>(&IFSelect_Editor::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_Functions from ./opencascade/IFSelect_Functions.hxx
    klass = m.attr("IFSelect_Functions");

    // default constructor
    register_default_constructor<IFSelect_Functions , shared_ptr<IFSelect_Functions>>(m,"IFSelect_Functions");

    // nested enums

    static_cast<py::class_<IFSelect_Functions , shared_ptr<IFSelect_Functions>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("GiveEntity_s",
                    (handle<Standard_Transient> (*)(  const handle<IFSelect_WorkSession> & ,   const char * const   ) ) static_cast<handle<Standard_Transient> (*)(  const handle<IFSelect_WorkSession> & ,   const char * const   ) >(&IFSelect_Functions::GiveEntity),
                    R"#(Takes the name of an entity, either as argument, or (if <name> is empty) on keyboard, and returns the entity name can be a label or a number (in alphanumeric), it is searched by NumberFromLabel from WorkSession. If <name> doesn't match en entity, a Null Handle is returned)#"  , py::arg("WS"),  py::arg("name")=static_cast< const char * const >("")
          )
        .def_static("GiveEntityNumber_s",
                    (int (*)(  const handle<IFSelect_WorkSession> & ,   const char * const   ) ) static_cast<int (*)(  const handle<IFSelect_WorkSession> & ,   const char * const   ) >(&IFSelect_Functions::GiveEntityNumber),
                    R"#(Same as GetEntity, but returns the number in the model of the entity. Returns 0 for null handle)#"  , py::arg("WS"),  py::arg("name")=static_cast< const char * const >("")
          )
        .def_static("GiveList_s",
                    (handle<NCollection_HSequence<handle<Standard_Transient>>> (*)(  const handle<IFSelect_WorkSession> & ,   const char * const  ,   const char * const   ) ) static_cast<handle<NCollection_HSequence<handle<Standard_Transient>>> (*)(  const handle<IFSelect_WorkSession> & ,   const char * const  ,   const char * const   ) >(&IFSelect_Functions::GiveList),
                    R"#(Computes a List of entities from a WorkSession and two idents, first and second, as follows : if <first> is a Number or Label of an entity : this entity if <first> is the name of a Selection in <WS>, and <second> not defined, the standard result of this Selection if <first> is for a Selection and <second> is defined, the standard result of this selection from the list computed with <second> (an entity or a selection) If <second> is erroneous, it is ignored)#"  , py::arg("WS"),  py::arg("first")=static_cast< const char * const >(""),  py::arg("second")=static_cast< const char * const >("")
          )
        .def_static("GiveDispatch_s",
                    (handle<IFSelect_Dispatch> (*)(  const handle<IFSelect_WorkSession> & ,   const char * const  ,   const bool  ) ) static_cast<handle<IFSelect_Dispatch> (*)(  const handle<IFSelect_WorkSession> & ,   const char * const  ,   const bool  ) >(&IFSelect_Functions::GiveDispatch),
                    R"#(Evaluates and returns a Dispatch, from data of a WorkSession if <mode> is False, searches for exact name of Dispatch in WS Else (D), allows a parameter between brackets : ex.: dispatch_name(parameter) The parameter can be: an integer for DispPerCount or DispPerFiles or the name of a Signature for DispPerSignature Returns Null Handle if not found not well evaluated)#"  , py::arg("WS"),  py::arg("name"),  py::arg("mode")=static_cast< const bool>(true)
          )
        .def_static("Init_s",
                    (void (*)() ) static_cast<void (*)() >(&IFSelect_Functions::Init),
                    R"#(Defines and loads all basic functions (as ActFunc))#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IFSelect_GeneralModifier from ./opencascade/IFSelect_GeneralModifier.hxx
    klass = m.attr("IFSelect_GeneralModifier");


    // nested enums

    static_cast<py::class_<IFSelect_GeneralModifier ,opencascade::handle<IFSelect_GeneralModifier> ,Py_IFSelect_GeneralModifier , Standard_Transient >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("MayChangeGraph",
             (bool (IFSelect_GeneralModifier::*)() const) static_cast<bool (IFSelect_GeneralModifier::*)() const>(&IFSelect_GeneralModifier::MayChangeGraph),
             R"#(Returns True if this modifier may change the graph of dependences (acknowledged at creation time))#" 
          )
        .def("SetDispatch",
             (void (IFSelect_GeneralModifier::*)(  const handle<IFSelect_Dispatch> &  ) ) static_cast<void (IFSelect_GeneralModifier::*)(  const handle<IFSelect_Dispatch> &  ) >(&IFSelect_GeneralModifier::SetDispatch),
             R"#(Attaches to a Dispatch. If <disp> is Null, Resets it (to apply the Modifier on every Dispatch))#"  , py::arg("disp")
          )
        .def("Dispatch",
             (handle<IFSelect_Dispatch> (IFSelect_GeneralModifier::*)() const) static_cast<handle<IFSelect_Dispatch> (IFSelect_GeneralModifier::*)() const>(&IFSelect_GeneralModifier::Dispatch),
             R"#(Returns the Dispatch to be matched, Null if not set)#" 
          )
        .def("Applies",
             (bool (IFSelect_GeneralModifier::*)(  const handle<IFSelect_Dispatch> &  ) const) static_cast<bool (IFSelect_GeneralModifier::*)(  const handle<IFSelect_Dispatch> &  ) const>(&IFSelect_GeneralModifier::Applies),
             R"#(Returns True if a Model obtained from the Dispatch <disp> is to be treated (apart from the Selection criterium) If Dispatch(me) is Null, returns True. Else, checks <disp>)#"  , py::arg("disp")
          )
        .def("SetSelection",
             (void (IFSelect_GeneralModifier::*)(  const handle<IFSelect_Selection> &  ) ) static_cast<void (IFSelect_GeneralModifier::*)(  const handle<IFSelect_Selection> &  ) >(&IFSelect_GeneralModifier::SetSelection),
             R"#(Sets a Selection : a Model is treated if it contains one or more Entities designated by the Selection)#"  , py::arg("sel")
          )
        .def("ResetSelection",
             (void (IFSelect_GeneralModifier::*)() ) static_cast<void (IFSelect_GeneralModifier::*)() >(&IFSelect_GeneralModifier::ResetSelection),
             R"#(Resets the Selection : this criterium is not longer active)#" 
          )
        .def("HasSelection",
             (bool (IFSelect_GeneralModifier::*)() const) static_cast<bool (IFSelect_GeneralModifier::*)() const>(&IFSelect_GeneralModifier::HasSelection),
             R"#(Returns True if a Selection is set as an additional criterium)#" 
          )
        .def("Selection",
             (handle<IFSelect_Selection> (IFSelect_GeneralModifier::*)() const) static_cast<handle<IFSelect_Selection> (IFSelect_GeneralModifier::*)() const>(&IFSelect_GeneralModifier::Selection),
             R"#(Returns the Selection, or a Null Handle if not set)#" 
          )
        .def("Label",
             (TCollection_AsciiString (IFSelect_GeneralModifier::*)() const) static_cast<TCollection_AsciiString (IFSelect_GeneralModifier::*)() const>(&IFSelect_GeneralModifier::Label),
             R"#(Returns a short text which defines the operation performed)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_GeneralModifier::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_GeneralModifier::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_GeneralModifier::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_GeneralModifier::*)() const>(&IFSelect_GeneralModifier::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_IntParam from ./opencascade/IFSelect_IntParam.hxx
    klass = m.attr("IFSelect_IntParam");


    // nested enums

    static_cast<py::class_<IFSelect_IntParam ,opencascade::handle<IFSelect_IntParam>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetStaticName",
             (void (IFSelect_IntParam::*)(  const char * const   ) ) static_cast<void (IFSelect_IntParam::*)(  const char * const   ) >(&IFSelect_IntParam::SetStaticName),
             R"#(Commands this IntParam to be bound to a Static Hence, Value will return the value if this Static if it is set Else, Value works on the locally stored value SetValue also will set the value of the Static This works only for a present static of type integer or enum Else, it is ignored)#"  , py::arg("statname")
          )
        .def("Value",
             (int (IFSelect_IntParam::*)() const) static_cast<int (IFSelect_IntParam::*)() const>(&IFSelect_IntParam::Value),
             R"#(Reads Integer Value of the IntParam. If a StaticName is defined and the Static is set, looks in priority the value of the static)#" 
          )
        .def("SetValue",
             (void (IFSelect_IntParam::*)(  const int  ) ) static_cast<void (IFSelect_IntParam::*)(  const int  ) >(&IFSelect_IntParam::SetValue),
             R"#(Sets a new Integer Value for the IntParam. If a StaticName is defined and the Static is set, also sets the value of the static)#"  , py::arg("val")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_IntParam::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_IntParam::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_IntParam::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_IntParam::*)() const>(&IFSelect_IntParam::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_ListEditor from ./opencascade/IFSelect_ListEditor.hxx
    klass = m.attr("IFSelect_ListEditor");


    // nested enums

    static_cast<py::class_<IFSelect_ListEditor ,opencascade::handle<IFSelect_ListEditor>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("LoadValues",
             (void (IFSelect_ListEditor::*)(  const handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> &  ) ) static_cast<void (IFSelect_ListEditor::*)(  const handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> &  ) >(&IFSelect_ListEditor::LoadValues),
             R"#(Loads the original values for the list. Remark : If its length is more then MaxLength, editions remain allowed, except Add)#"  , py::arg("vals")
          )
        .def("SetTouched",
             (void (IFSelect_ListEditor::*)() ) static_cast<void (IFSelect_ListEditor::*)() >(&IFSelect_ListEditor::SetTouched),
             R"#(Declares this ListEditor to have been touched (whatever action))#" 
          )
        .def("ClearEdit",
             (void (IFSelect_ListEditor::*)() ) static_cast<void (IFSelect_ListEditor::*)() >(&IFSelect_ListEditor::ClearEdit),
             R"#(Clears all editions already recorded)#" 
          )
        .def("LoadEdited",
             (bool (IFSelect_ListEditor::*)(  const handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> &  ) ) static_cast<bool (IFSelect_ListEditor::*)(  const handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> &  ) >(&IFSelect_ListEditor::LoadEdited),
             R"#(Loads a new list to replace the older one, in once ! By default (can be redefined) checks the length of the list and the value of each item according to the def Items are all recorded as Modified)#"  , py::arg("list")
          )
        .def("SetValue",
             (bool (IFSelect_ListEditor::*)(  const int ,   const handle<TCollection_HAsciiString> &  ) ) static_cast<bool (IFSelect_ListEditor::*)(  const int ,   const handle<TCollection_HAsciiString> &  ) >(&IFSelect_ListEditor::SetValue),
             R"#(Sets a new value for the item <num> (in edited list) <val> may be a Null Handle, then the value will be cleared but not removed Returns True when done. False if <num> is out of range or if <val> does not satisfy the definition)#"  , py::arg("num"),  py::arg("val")
          )
        .def("AddValue",
             (bool (IFSelect_ListEditor::*)(  const handle<TCollection_HAsciiString> & ,   const int  ) ) static_cast<bool (IFSelect_ListEditor::*)(  const handle<TCollection_HAsciiString> & ,   const int  ) >(&IFSelect_ListEditor::AddValue),
             R"#(Adds a new item. By default appends (at the end of the list) Can insert before a given rank <num>, if positive Returns True when done. False if MaxLength may be overpassed or if <val> does not satisfy the definition)#"  , py::arg("val"),  py::arg("atnum")=static_cast< const int>(0)
          )
        .def("Remove",
             (bool (IFSelect_ListEditor::*)(  const int ,   const int  ) ) static_cast<bool (IFSelect_ListEditor::*)(  const int ,   const int  ) >(&IFSelect_ListEditor::Remove),
             R"#(Removes items from the list By default removes one item. Else, count given by <howmany> Remove from rank <num> included. By default, from the end Returns True when done, False (and does not work) if case of out of range of if <howmany> is greater than current length)#"  , py::arg("num")=static_cast< const int>(0),  py::arg("howmany")=static_cast< const int>(1)
          )
        .def("OriginalValues",
             (handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> (IFSelect_ListEditor::*)() const) static_cast<handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> (IFSelect_ListEditor::*)() const>(&IFSelect_ListEditor::OriginalValues),
             R"#(Returns the value from which the edition started)#" 
          )
        .def("EditedValues",
             (handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> (IFSelect_ListEditor::*)() const) static_cast<handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> (IFSelect_ListEditor::*)() const>(&IFSelect_ListEditor::EditedValues),
             R"#(Returns the result of the edition)#" 
          )
        .def("NbValues",
             (int (IFSelect_ListEditor::*)(  const bool  ) const) static_cast<int (IFSelect_ListEditor::*)(  const bool  ) const>(&IFSelect_ListEditor::NbValues),
             R"#(Returns count of values, edited (D) or original)#"  , py::arg("edited")=static_cast< const bool>(true)
          )
        .def("Value",
             (handle<TCollection_HAsciiString> (IFSelect_ListEditor::*)(  const int ,   const bool  ) const) static_cast<handle<TCollection_HAsciiString> (IFSelect_ListEditor::*)(  const int ,   const bool  ) const>(&IFSelect_ListEditor::Value),
             R"#(Returns a value given its rank. Edited (D) or Original A Null String means the value is cleared but not removed)#"  , py::arg("num"),  py::arg("edited")=static_cast< const bool>(true)
          )
        .def("IsChanged",
             (bool (IFSelect_ListEditor::*)(  const int  ) const) static_cast<bool (IFSelect_ListEditor::*)(  const int  ) const>(&IFSelect_ListEditor::IsChanged),
             R"#(Tells if a value (in edited list) has been changed, i.e. either modified-value, or added)#"  , py::arg("num")
          )
        .def("IsModified",
             (bool (IFSelect_ListEditor::*)(  const int  ) const) static_cast<bool (IFSelect_ListEditor::*)(  const int  ) const>(&IFSelect_ListEditor::IsModified),
             R"#(Tells if a value (in edited list) has been modified-value (not added))#"  , py::arg("num")
          )
        .def("IsAdded",
             (bool (IFSelect_ListEditor::*)(  const int  ) const) static_cast<bool (IFSelect_ListEditor::*)(  const int  ) const>(&IFSelect_ListEditor::IsAdded),
             R"#(Tells if a value (in edited list) has been added (new one))#"  , py::arg("num")
          )
        .def("IsTouched",
             (bool (IFSelect_ListEditor::*)() const) static_cast<bool (IFSelect_ListEditor::*)() const>(&IFSelect_ListEditor::IsTouched),
             R"#(Tells if at least one edition (SetValue-AddValue-Remove) has been recorded)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_ListEditor::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_ListEditor::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_ListEditor::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_ListEditor::*)() const>(&IFSelect_ListEditor::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_ModelCopier from ./opencascade/IFSelect_ModelCopier.hxx
    klass = m.attr("IFSelect_ModelCopier");


    // nested enums

    static_cast<py::class_<IFSelect_ModelCopier ,opencascade::handle<IFSelect_ModelCopier>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetShareOut",
             (void (IFSelect_ModelCopier::*)(  const handle<IFSelect_ShareOut> &  ) ) static_cast<void (IFSelect_ModelCopier::*)(  const handle<IFSelect_ShareOut> &  ) >(&IFSelect_ModelCopier::SetShareOut),
             R"#(Sets the ShareOut, which is used to define Modifiers to apply)#"  , py::arg("sho")
          )
        .def("ClearResult",
             (void (IFSelect_ModelCopier::*)() ) static_cast<void (IFSelect_ModelCopier::*)() >(&IFSelect_ModelCopier::ClearResult),
             R"#(Clears the list of produced Models)#" 
          )
        .def("NameFile",
             (bool (IFSelect_ModelCopier::*)(  const int ,   const TCollection_AsciiString &  ) ) static_cast<bool (IFSelect_ModelCopier::*)(  const int ,   const TCollection_AsciiString &  ) >(&IFSelect_ModelCopier::NameFile),
             R"#(Changes the Name attached to a File which was formerly defined by a call to AddFile Returns True if Done, False else : if <num> out of range or if the new <filename> is already attached to another File Remark : Giving an empty File Name is equivalent to ClearFile)#"  , py::arg("num"),  py::arg("filename")
          )
        .def("ClearFile",
             (bool (IFSelect_ModelCopier::*)(  const int  ) ) static_cast<bool (IFSelect_ModelCopier::*)(  const int  ) >(&IFSelect_ModelCopier::ClearFile),
             R"#(Clears the Name attached to a File which was formerly defined by a call to AddFile. This Clearing can be undone by a call to NameFile (with same <num>) Returns True if Done, False else : if <num> is out of range)#"  , py::arg("num")
          )
        .def("SetAppliedModifiers",
             (bool (IFSelect_ModelCopier::*)(  const int ,   const handle<IFSelect_AppliedModifiers> &  ) ) static_cast<bool (IFSelect_ModelCopier::*)(  const int ,   const handle<IFSelect_AppliedModifiers> &  ) >(&IFSelect_ModelCopier::SetAppliedModifiers),
             R"#(Sets a list of File Modifiers to be applied on a file)#"  , py::arg("num"),  py::arg("applied")
          )
        .def("ClearAppliedModifiers",
             (bool (IFSelect_ModelCopier::*)(  const int  ) ) static_cast<bool (IFSelect_ModelCopier::*)(  const int  ) >(&IFSelect_ModelCopier::ClearAppliedModifiers),
             R"#(Clears the list of File Modifiers to be applied on a file)#"  , py::arg("num")
          )
        .def("NbFiles",
             (int (IFSelect_ModelCopier::*)() const) static_cast<int (IFSelect_ModelCopier::*)() const>(&IFSelect_ModelCopier::NbFiles),
             R"#(Returns the count of Files produced, i.e. the count of Models memorized (produced by the mmethod Copy) with their file names)#" 
          )
        .def("FileName",
             (TCollection_AsciiString (IFSelect_ModelCopier::*)(  const int  ) const) static_cast<TCollection_AsciiString (IFSelect_ModelCopier::*)(  const int  ) const>(&IFSelect_ModelCopier::FileName),
             R"#(Returns the File Name for a file given its rank It is empty after a call to ClearFile on same <num>)#"  , py::arg("num")
          )
        .def("AppliedModifiers",
             (handle<IFSelect_AppliedModifiers> (IFSelect_ModelCopier::*)(  const int  ) const) static_cast<handle<IFSelect_AppliedModifiers> (IFSelect_ModelCopier::*)(  const int  ) const>(&IFSelect_ModelCopier::AppliedModifiers),
             R"#(Returns the list of File Modifiers to be applied on a file when it will be sent, as computed by CopiedModel : If it is a null handle, no File Modifier has to be applied.)#"  , py::arg("num")
          )
        .def("BeginSentFiles",
             (void (IFSelect_ModelCopier::*)(  const handle<IFSelect_ShareOut> & ,   const bool  ) ) static_cast<void (IFSelect_ModelCopier::*)(  const handle<IFSelect_ShareOut> & ,   const bool  ) >(&IFSelect_ModelCopier::BeginSentFiles),
             R"#(Begins a sequence of recording the really sent files <sho> : the default file numbering is cleared If <record> is False, clears the list and stops recording If <record> is True, clears the list and commands recording Creation time corresponds to "stop recording")#"  , py::arg("sho"),  py::arg("record")
          )
        .def("AddSentFile",
             (void (IFSelect_ModelCopier::*)(  const char * const   ) ) static_cast<void (IFSelect_ModelCopier::*)(  const char * const   ) >(&IFSelect_ModelCopier::AddSentFile),
             R"#(Adds the name of a just sent file, if BeginSentFiles has commanded recording; else does nothing It is called by methods SendCopied Sending)#"  , py::arg("filename")
          )
        .def("SentFiles",
             (handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> (IFSelect_ModelCopier::*)() const) static_cast<handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> (IFSelect_ModelCopier::*)() const>(&IFSelect_ModelCopier::SentFiles),
             R"#(Returns the list of recorded names of sent files. Can be empty (if no file has been sent). Returns a Null Handle if BeginSentFiles has stopped recording.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_ModelCopier::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_ModelCopier::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_ModelCopier::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_ModelCopier::*)() const>(&IFSelect_ModelCopier::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_PacketList from ./opencascade/IFSelect_PacketList.hxx
    klass = m.attr("IFSelect_PacketList");

    // default constructor
    register_default_constructor<IFSelect_PacketList ,opencascade::handle<IFSelect_PacketList>>(m,"IFSelect_PacketList");

    // nested enums

    static_cast<py::class_<IFSelect_PacketList ,opencascade::handle<IFSelect_PacketList>  , Standard_Transient >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("SetName",
             (void (IFSelect_PacketList::*)(  const char * const   ) ) static_cast<void (IFSelect_PacketList::*)(  const char * const   ) >(&IFSelect_PacketList::SetName),
             R"#(Sets a name to a packet list : this makes easier a general routine to print it. Default is "Packets")#"  , py::arg("name")
          )
        .def("Name",
             ( const char * (IFSelect_PacketList::*)() const) static_cast< const char * (IFSelect_PacketList::*)() const>(&IFSelect_PacketList::Name),
             R"#(Returns the recorded name for a packet list)#" 
          )
        .def("AddPacket",
             (void (IFSelect_PacketList::*)() ) static_cast<void (IFSelect_PacketList::*)() >(&IFSelect_PacketList::AddPacket),
             R"#(Declares a new Packet, ready to be filled The entities to be added will be added to this Packet)#" 
          )
        .def("Add",
             (void (IFSelect_PacketList::*)(  const handle<Standard_Transient> &  ) ) static_cast<void (IFSelect_PacketList::*)(  const handle<Standard_Transient> &  ) >(&IFSelect_PacketList::Add),
             R"#(Adds an entity from the Model into the current packet for Add)#"  , py::arg("ent")
          )
        .def("AddList",
             (void (IFSelect_PacketList::*)(  const handle<NCollection_HSequence<handle<Standard_Transient>>> &  ) ) static_cast<void (IFSelect_PacketList::*)(  const handle<NCollection_HSequence<handle<Standard_Transient>>> &  ) >(&IFSelect_PacketList::AddList),
             R"#(Adds an list of entities into the current packet for Add)#"  , py::arg("list")
          )
        .def("NbPackets",
             (int (IFSelect_PacketList::*)() const) static_cast<int (IFSelect_PacketList::*)() const>(&IFSelect_PacketList::NbPackets),
             R"#(Returns the count of non-empty packets)#" 
          )
        .def("NbEntities",
             (int (IFSelect_PacketList::*)(  const int  ) const) static_cast<int (IFSelect_PacketList::*)(  const int  ) const>(&IFSelect_PacketList::NbEntities),
             R"#(Returns the count of entities in a Packet given its rank, or 0)#"  , py::arg("numpack")
          )
        .def("HighestDuplicationCount",
             (int (IFSelect_PacketList::*)() const) static_cast<int (IFSelect_PacketList::*)() const>(&IFSelect_PacketList::HighestDuplicationCount),
             R"#(Returns the highest number of packets which know a same entity For no duplication, should be one)#" 
          )
        .def("NbDuplicated",
             (int (IFSelect_PacketList::*)(  const int ,   const bool  ) const) static_cast<int (IFSelect_PacketList::*)(  const int ,   const bool  ) const>(&IFSelect_PacketList::NbDuplicated),
             R"#(Returns the count of entities duplicated : <count> times, if <andmore> is False, or <count> or more times, if <andmore> is True See Duplicated for more details)#"  , py::arg("count"),  py::arg("andmore")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_PacketList::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_PacketList::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_PacketList::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_PacketList::*)() const>(&IFSelect_PacketList::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_Selection from ./opencascade/IFSelect_Selection.hxx
    klass = m.attr("IFSelect_Selection");


    // nested enums

    static_cast<py::class_<IFSelect_Selection ,opencascade::handle<IFSelect_Selection> ,Py_IFSelect_Selection , Standard_Transient >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("FillIterator",
             (void (IFSelect_Selection::*)( IFSelect_SelectionIterator &  ) const) static_cast<void (IFSelect_Selection::*)( IFSelect_SelectionIterator &  ) const>(&IFSelect_Selection::FillIterator),
             R"#(Puts in an Iterator the Selections from which "me" depends (there can be zero, or one, or a list). Specific to each class of Selection)#"  , py::arg("iter")
          )
        .def("Label",
             (TCollection_AsciiString (IFSelect_Selection::*)() const) static_cast<TCollection_AsciiString (IFSelect_Selection::*)() const>(&IFSelect_Selection::Label),
             R"#(Returns a text which defines the criterium applied by a Selection (can be used to be printed, displayed ...) Specific to each class)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_Selection::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_Selection::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_Selection::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_Selection::*)() const>(&IFSelect_Selection::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectionIterator from ./opencascade/IFSelect_SelectionIterator.hxx
    klass = m.attr("IFSelect_SelectionIterator");


    // nested enums

    static_cast<py::class_<IFSelect_SelectionIterator , shared_ptr<IFSelect_SelectionIterator>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<IFSelect_Selection> & >()  , py::arg("sel") )
    // custom constructors
    // methods
        .def("AddFromIter",
             (void (IFSelect_SelectionIterator::*)( IFSelect_SelectionIterator &  ) ) static_cast<void (IFSelect_SelectionIterator::*)( IFSelect_SelectionIterator &  ) >(&IFSelect_SelectionIterator::AddFromIter),
             R"#(Adds to an iterator the content of another one (each selection is present only once in the result))#"  , py::arg("iter")
          )
        .def("AddItem",
             (void (IFSelect_SelectionIterator::*)(  const handle<IFSelect_Selection> &  ) ) static_cast<void (IFSelect_SelectionIterator::*)(  const handle<IFSelect_Selection> &  ) >(&IFSelect_SelectionIterator::AddItem),
             R"#(Adds a Selection to an iterator (if not yet noted))#"  , py::arg("sel")
          )
        .def("AddList",
             (void (IFSelect_SelectionIterator::*)(  const NCollection_Sequence<handle<IFSelect_Selection>> &  ) ) static_cast<void (IFSelect_SelectionIterator::*)(  const NCollection_Sequence<handle<IFSelect_Selection>> &  ) >(&IFSelect_SelectionIterator::AddList),
             R"#(Adds a list of Selections to an iterator (this list comes from the description of a Selection or a Dispatch, etc...))#"  , py::arg("list")
          )
        .def("More",
             (bool (IFSelect_SelectionIterator::*)() const) static_cast<bool (IFSelect_SelectionIterator::*)() const>(&IFSelect_SelectionIterator::More),
             R"#(Returns True if there are more Selections to get)#" 
          )
        .def("Next",
             (void (IFSelect_SelectionIterator::*)() ) static_cast<void (IFSelect_SelectionIterator::*)() >(&IFSelect_SelectionIterator::Next),
             R"#(Sets iterator to the next item)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Value",
             ( const handle<IFSelect_Selection> & (IFSelect_SelectionIterator::*)() const) static_cast< const handle<IFSelect_Selection> & (IFSelect_SelectionIterator::*)() const>(&IFSelect_SelectionIterator::Value),
             R"#(Returns the current Selection being iterated Error if count of Selection has been passed)#"
             
         )
;

    // Class IFSelect_SessionDumper from ./opencascade/IFSelect_SessionDumper.hxx
    klass = m.attr("IFSelect_SessionDumper");


    // nested enums

    static_cast<py::class_<IFSelect_SessionDumper ,opencascade::handle<IFSelect_SessionDumper> ,Py_IFSelect_SessionDumper , Standard_Transient >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("Next",
             (handle<IFSelect_SessionDumper> (IFSelect_SessionDumper::*)() const) static_cast<handle<IFSelect_SessionDumper> (IFSelect_SessionDumper::*)() const>(&IFSelect_SessionDumper::Next),
             R"#(Returns the Next SesionDumper in the Library. Returns a Null Handle at the End.)#" 
          )
        .def("WriteOwn",
             (bool (IFSelect_SessionDumper::*)( IFSelect_SessionFile & ,   const handle<Standard_Transient> &  ) const) static_cast<bool (IFSelect_SessionDumper::*)( IFSelect_SessionFile & ,   const handle<Standard_Transient> &  ) const>(&IFSelect_SessionDumper::WriteOwn),
             R"#(Writes the Own Parameters of a given Item, if it forecast to manage its Type. Returns True if it has recognized the Type of the Item (in this case, it is assumed to have written the Own Parameters if there are some), False else : in that case, SessionFile will try another SessionDumper in the Library. WriteOwn can use these methods from SessionFile : SendVoid, SendItem, SendText, and if necessary, WorkSession.)#"  , py::arg("file"),  py::arg("item")
          )
        .def("ReadOwn",
             (bool (IFSelect_SessionDumper::*)( IFSelect_SessionFile & ,   const TCollection_AsciiString & ,  handle<Standard_Transient> &  ) const) static_cast<bool (IFSelect_SessionDumper::*)( IFSelect_SessionFile & ,   const TCollection_AsciiString & ,  handle<Standard_Transient> &  ) const>(&IFSelect_SessionDumper::ReadOwn),
             R"#(Recognizes a Type (given as <type>) then Creates an Item of this Type with the Own Parameter, as required. Returns True if it has recognized the Type (in this case, it is assumed to have created the Item, returned as <item>), False else : in that case, SessionFile will try another SessionDumper in the Library. ReadOwn can use these methods from SessionFile to access Own Parameters : NbOwnParams, IsVoid, IsText, TextValue, ItemValue)#"  , py::arg("file"),  py::arg("type"),  py::arg("item")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("First_s",
                    (handle<IFSelect_SessionDumper> (*)() ) static_cast<handle<IFSelect_SessionDumper> (*)() >(&IFSelect_SessionDumper::First),
                    R"#(Returns the First item of the Library of Dumper. The Next ones are then obtained by Next on the returned items)#" 
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SessionDumper::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SessionDumper::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SessionDumper::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SessionDumper::*)() const>(&IFSelect_SessionDumper::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SessionFile from ./opencascade/IFSelect_SessionFile.hxx
    klass = m.attr("IFSelect_SessionFile");


    // nested enums

    static_cast<py::class_<IFSelect_SessionFile , shared_ptr<IFSelect_SessionFile>  >>(klass)
    // constructors
        .def(py::init<  const handle<IFSelect_WorkSession> & >()  , py::arg("WS") )
        .def(py::init<  const handle<IFSelect_WorkSession> &, const char * const  >()  , py::arg("WS"),  py::arg("filename") )
    // custom constructors
    // methods
        .def("ClearLines",
             (void (IFSelect_SessionFile::*)() ) static_cast<void (IFSelect_SessionFile::*)() >(&IFSelect_SessionFile::ClearLines),
             R"#(Clears the lines recorded whatever for writing or for reading)#" 
          )
        .def("NbLines",
             (int (IFSelect_SessionFile::*)() const) static_cast<int (IFSelect_SessionFile::*)() const>(&IFSelect_SessionFile::NbLines),
             R"#(Returns the count of recorded lines)#" 
          )
        .def("Line",
             ( const TCollection_AsciiString & (IFSelect_SessionFile::*)(  const int  ) const) static_cast< const TCollection_AsciiString & (IFSelect_SessionFile::*)(  const int  ) const>(&IFSelect_SessionFile::Line),
             R"#(Returns a line given its rank in the list of recorded lines)#"  , py::arg("num")
          )
        .def("AddLine",
             (void (IFSelect_SessionFile::*)(  const char * const   ) ) static_cast<void (IFSelect_SessionFile::*)(  const char * const   ) >(&IFSelect_SessionFile::AddLine),
             R"#(Adds a line to the list of recorded lines)#"  , py::arg("line")
          )
        .def("RemoveLastLine",
             (void (IFSelect_SessionFile::*)() ) static_cast<void (IFSelect_SessionFile::*)() >(&IFSelect_SessionFile::RemoveLastLine),
             R"#(Removes the last line. Can be called recursively. Does nothing if the list is empty)#" 
          )
        .def("WriteFile",
             (bool (IFSelect_SessionFile::*)(  const char * const   ) ) static_cast<bool (IFSelect_SessionFile::*)(  const char * const   ) >(&IFSelect_SessionFile::WriteFile),
             R"#(Writes the recorded lines to a file named <name> then clears the list of lines. Returns False (with no clearing) if the file could not be created)#"  , py::arg("name")
          )
        .def("ReadFile",
             (bool (IFSelect_SessionFile::*)(  const char * const   ) ) static_cast<bool (IFSelect_SessionFile::*)(  const char * const   ) >(&IFSelect_SessionFile::ReadFile),
             R"#(Reads the recorded lines from a file named <name>, after having cleared the list (stops if RecognizeFile fails) Returns False (with no clearing) if the file could not be read)#"  , py::arg("name")
          )
        .def("RecognizeFile",
             (bool (IFSelect_SessionFile::*)(  const char * const   ) ) static_cast<bool (IFSelect_SessionFile::*)(  const char * const   ) >(&IFSelect_SessionFile::RecognizeFile),
             R"#(Recognizes the header line. returns True if OK, False else)#"  , py::arg("headerline")
          )
        .def("Write",
             (int (IFSelect_SessionFile::*)(  const char * const   ) ) static_cast<int (IFSelect_SessionFile::*)(  const char * const   ) >(&IFSelect_SessionFile::Write),
             R"#(Performs a Write Operation from a WorkSession to a File i.e. calls WriteSession then WriteEnd, and WriteFile Returned Value is : 0 for OK, -1 File could not be created, >0 Error during Write (see WriteSession) IsDone can be called too (will return True for OK))#"  , py::arg("filename")
          )
        .def("Read",
             (int (IFSelect_SessionFile::*)(  const char * const   ) ) static_cast<int (IFSelect_SessionFile::*)(  const char * const   ) >(&IFSelect_SessionFile::Read),
             R"#(Performs a Read Operation from a file to a WorkSession i.e. calls ReadFile, then ReadSession and ReadEnd Returned Value is : 0 for OK, -1 File could not be opened, >0 Error during Read (see WriteSession) IsDone can be called too (will return True for OK))#"  , py::arg("filename")
          )
        .def("WriteSession",
             (int (IFSelect_SessionFile::*)() ) static_cast<int (IFSelect_SessionFile::*)() >(&IFSelect_SessionFile::WriteSession),
             R"#(Prepares the Write operation from a WorkSession (IFSelect) to a File, i.e. fills the list of lines (the file itself remains to be written; or NbLines/Line may be called) Important Remark : this excludes the reading of the last line, which is performed by WriteEnd Returns 0 if OK, status > 0 in case of error)#" 
          )
        .def("WriteEnd",
             (int (IFSelect_SessionFile::*)() ) static_cast<int (IFSelect_SessionFile::*)() >(&IFSelect_SessionFile::WriteEnd),
             R"#(Writes the trailing line. It is separate from WriteSession, in order to allow to redefine WriteSession without touching WriteEnd (WriteSession defines the body of the file) WriteEnd fills the list of lines. Returns a status of error, 0 if OK, >0 else)#" 
          )
        .def("WriteLine",
             (void (IFSelect_SessionFile::*)(  const char * const  ,   const char  ) ) static_cast<void (IFSelect_SessionFile::*)(  const char * const  ,   const char  ) >(&IFSelect_SessionFile::WriteLine),
             R"#(Writes a line to the File. If <follow> is given, it is added at the following of the line. '' must be added for the end.)#"  , py::arg("line"),  py::arg("follow")=static_cast< const char>(0)
          )
        .def("WriteOwn",
             (bool (IFSelect_SessionFile::*)(  const handle<Standard_Transient> &  ) ) static_cast<bool (IFSelect_SessionFile::*)(  const handle<Standard_Transient> &  ) >(&IFSelect_SessionFile::WriteOwn),
             R"#(Writes the Parameters own to each type of Item. Uses the Library of SessionDumpers Returns True if Done, False if <item> could not be treated (hence it remains written with no Own Parameter))#"  , py::arg("item")
          )
        .def("ReadSession",
             (int (IFSelect_SessionFile::*)() ) static_cast<int (IFSelect_SessionFile::*)() >(&IFSelect_SessionFile::ReadSession),
             R"#(Performs a Read Operation from a File to a WorkSession, i.e. reads the list of line (which must have already been loaded, by ReadFile or by calls to AddLine) Important Remark : this excludes the reading of the last line, which is performed by ReadEnd Returns 0 for OK, >0 status for Read Error (not a suitable File, or WorkSession given as Immutable at Creation Time) IsDone can be called too (will return True for OK))#" 
          )
        .def("ReadEnd",
             (int (IFSelect_SessionFile::*)() ) static_cast<int (IFSelect_SessionFile::*)() >(&IFSelect_SessionFile::ReadEnd),
             R"#(Reads the end of a file (its last line). Returns 0 if OK, status >0 in case of error (not a suitable end line).)#" 
          )
        .def("ReadLine",
             (bool (IFSelect_SessionFile::*)() ) static_cast<bool (IFSelect_SessionFile::*)() >(&IFSelect_SessionFile::ReadLine),
             R"#(Reads a Line and splits it into a set of alphanumeric items, which can then be queried by NbParams/ParamValue ...)#" 
          )
        .def("SplitLine",
             (void (IFSelect_SessionFile::*)(  const char * const   ) ) static_cast<void (IFSelect_SessionFile::*)(  const char * const   ) >(&IFSelect_SessionFile::SplitLine),
             R"#(Internal routine which processes a line into words and prepares its exploration)#"  , py::arg("line")
          )
        .def("ReadOwn",
             (bool (IFSelect_SessionFile::*)( handle<Standard_Transient> &  ) ) static_cast<bool (IFSelect_SessionFile::*)( handle<Standard_Transient> &  ) >(&IFSelect_SessionFile::ReadOwn),
             R"#(Tries to Read an Item, by calling the Library of Dumpers Sets the list of parameters of the line to be read from the first own one)#"  , py::arg("item")
          )
        .def("AddItem",
             (void (IFSelect_SessionFile::*)(  const handle<Standard_Transient> & ,   const bool  ) ) static_cast<void (IFSelect_SessionFile::*)(  const handle<Standard_Transient> & ,   const bool  ) >(&IFSelect_SessionFile::AddItem),
             R"#(Adds an Item to the WorkSession, taken as Name the first item of the read Line. If this Name is not a Name but a Number or if this Name is already recorded in the WorkSession, it adds the Item but with no Name. Then the Name is recorded in order to be used by the method ItemValue <active> commands to make <item> active or not in the session)#"  , py::arg("item"),  py::arg("active")=static_cast< const bool>(true)
          )
        .def("IsDone",
             (bool (IFSelect_SessionFile::*)() const) static_cast<bool (IFSelect_SessionFile::*)() const>(&IFSelect_SessionFile::IsDone),
             R"#(Returns True if the last Read or Write operation has been correctly performed. Else returns False.)#" 
          )
        .def("WorkSession",
             (handle<IFSelect_WorkSession> (IFSelect_SessionFile::*)() const) static_cast<handle<IFSelect_WorkSession> (IFSelect_SessionFile::*)() const>(&IFSelect_SessionFile::WorkSession),
             R"#(Returns the WorkSession on which a SessionFile works. Remark that it is returned as Immutable.)#" 
          )
        .def("NewItem",
             (void (IFSelect_SessionFile::*)(  const int ,   const handle<Standard_Transient> &  ) ) static_cast<void (IFSelect_SessionFile::*)(  const int ,   const handle<Standard_Transient> &  ) >(&IFSelect_SessionFile::NewItem),
             R"#(At beginning of writing an Item, writes its basics : - either its name in the session if it has one - or its relative number of item in the file, else (preceded by a '_') - then, its Dynamic Type (in the sense of cdl : pk_class) This basic description can be followed by the parameters which are used in the definition of the item.)#"  , py::arg("ident"),  py::arg("par")
          )
        .def("SetOwn",
             (void (IFSelect_SessionFile::*)(  const bool  ) ) static_cast<void (IFSelect_SessionFile::*)(  const bool  ) >(&IFSelect_SessionFile::SetOwn),
             R"#(Sets Parameters to be sent as Own if <mode> is True (their Name or Number or Void Mark or Text Value is preceded by a Column sign ':') else they are sent normally Hence, the Own Parameter are clearly identified in the File)#"  , py::arg("mode")
          )
        .def("SendVoid",
             (void (IFSelect_SessionFile::*)() ) static_cast<void (IFSelect_SessionFile::*)() >(&IFSelect_SessionFile::SendVoid),
             R"#(During a Write action, commands to send a Void Parameter i.e. a Parameter which is present but undefined Its form will be the dollar sign : $)#" 
          )
        .def("SendItem",
             (void (IFSelect_SessionFile::*)(  const handle<Standard_Transient> &  ) ) static_cast<void (IFSelect_SessionFile::*)(  const handle<Standard_Transient> &  ) >(&IFSelect_SessionFile::SendItem),
             R"#(During a Write action, commands to send the identification of a Parameter : if it is Null (undefined) it is send as Void ($) if it is Named in the WorkSession, its Name is sent preceded by ':', else a relative Ident Number is sent preceded by '#' (relative to the present Write, i.e. starting at one, without skip, and counted part from Named Items))#"  , py::arg("par")
          )
        .def("SendText",
             (void (IFSelect_SessionFile::*)(  const char * const   ) ) static_cast<void (IFSelect_SessionFile::*)(  const char * const   ) >(&IFSelect_SessionFile::SendText),
             R"#(During a Write action, commands to send a Text without interpretation. It will be sent as well)#"  , py::arg("text")
          )
        .def("SetLastGeneral",
             (void (IFSelect_SessionFile::*)(  const int  ) ) static_cast<void (IFSelect_SessionFile::*)(  const int  ) >(&IFSelect_SessionFile::SetLastGeneral),
             R"#(Sets the rank of Last General Parameter to a new value. It is followed by the Fist Own Parameter of the item. Used by SessionFile after reading general parameters.)#"  , py::arg("lastgen")
          )
        .def("NbParams",
             (int (IFSelect_SessionFile::*)() const) static_cast<int (IFSelect_SessionFile::*)() const>(&IFSelect_SessionFile::NbParams),
             R"#(During a Read operation, SessionFile processes sequentially the Items to read. For each one, it gives access to the list of its Parameters : they were defined by calls to SendVoid/SendParam/SendText during Writing the File. NbParams returns the count of Parameters for the line currently read.)#" 
          )
        .def("IsVoid",
             (bool (IFSelect_SessionFile::*)(  const int  ) const) static_cast<bool (IFSelect_SessionFile::*)(  const int  ) const>(&IFSelect_SessionFile::IsVoid),
             R"#(Returns True if a Parameter, given its rank in the Own List (see NbOwnParams), is Void. Returns also True if <num> is out of range (undefined parameters))#"  , py::arg("num")
          )
        .def("IsText",
             (bool (IFSelect_SessionFile::*)(  const int  ) const) static_cast<bool (IFSelect_SessionFile::*)(  const int  ) const>(&IFSelect_SessionFile::IsText),
             R"#(Returns True if a Parameter, in the Own List (see NbOwnParams) is a Text (between "..."). Else it is an Item (Parameter, Selection, Dispatch ...), which can be Void.)#"  , py::arg("num")
          )
        .def("ParamValue",
             ( const TCollection_AsciiString & (IFSelect_SessionFile::*)(  const int  ) const) static_cast< const TCollection_AsciiString & (IFSelect_SessionFile::*)(  const int  ) const>(&IFSelect_SessionFile::ParamValue),
             R"#(Returns a Parameter (alphanumeric item of a line) as it has been read)#"  , py::arg("num")
          )
        .def("TextValue",
             (TCollection_AsciiString (IFSelect_SessionFile::*)(  const int  ) const) static_cast<TCollection_AsciiString (IFSelect_SessionFile::*)(  const int  ) const>(&IFSelect_SessionFile::TextValue),
             R"#(Returns the content of a Text Parameter (without the quotes). Returns an empty string if the Parameter is not a Text.)#"  , py::arg("num")
          )
        .def("ItemValue",
             (handle<Standard_Transient> (IFSelect_SessionFile::*)(  const int  ) const) static_cast<handle<Standard_Transient> (IFSelect_SessionFile::*)(  const int  ) const>(&IFSelect_SessionFile::ItemValue),
             R"#(Returns a Parameter as an Item. Returns a Null Handle if the Parameter is a Text, or if it is defined as Void)#"  , py::arg("num")
          )
        .def("Destroy",
             (void (IFSelect_SessionFile::*)() ) static_cast<void (IFSelect_SessionFile::*)() >(&IFSelect_SessionFile::Destroy),
             R"#(Specific Destructor (closes the File if not yet done))#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IFSelect_ShareOut from ./opencascade/IFSelect_ShareOut.hxx
    klass = m.attr("IFSelect_ShareOut");


    // nested enums

    static_cast<py::class_<IFSelect_ShareOut ,opencascade::handle<IFSelect_ShareOut>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Clear",
             (void (IFSelect_ShareOut::*)(  const bool  ) ) static_cast<void (IFSelect_ShareOut::*)(  const bool  ) >(&IFSelect_ShareOut::Clear),
             R"#(Removes in one operation all the Dispatches with their Idents Also clears all information about Names, and all Results but naming information which are : - kept if <onlydisp> is True. - cleared if <onlydisp> is False (complete clearing) If <onlydisp> is True, that's all. Else, clears also Modifiers)#"  , py::arg("onlydisp")
          )
        .def("ClearResult",
             (void (IFSelect_ShareOut::*)(  const bool  ) ) static_cast<void (IFSelect_ShareOut::*)(  const bool  ) >(&IFSelect_ShareOut::ClearResult),
             R"#(Clears all data produced (apart from Dispatches, etc...) if <alsoname> is True, all is cleared. Else, information about produced Names are kept (to maintain unicity of naming across clearings))#"  , py::arg("alsoname")
          )
        .def("RemoveItem",
             (bool (IFSelect_ShareOut::*)(  const handle<Standard_Transient> &  ) ) static_cast<bool (IFSelect_ShareOut::*)(  const handle<Standard_Transient> &  ) >(&IFSelect_ShareOut::RemoveItem),
             R"#(Removes an item, which can be, either a Dispatch (removed from the list of Dispatches), or a GeneralModifier (removed from the list of Model Modifiers or from the list of File Modifiers according to its type). Returns True if done, False if has not been found or if it is neither a Dispatch, nor a Modifier.)#"  , py::arg("item")
          )
        .def("LastRun",
             (int (IFSelect_ShareOut::*)() const) static_cast<int (IFSelect_ShareOut::*)() const>(&IFSelect_ShareOut::LastRun),
             R"#(Returns the rank of last run item (ClearResult resets it to 0))#" 
          )
        .def("SetLastRun",
             (void (IFSelect_ShareOut::*)(  const int  ) ) static_cast<void (IFSelect_ShareOut::*)(  const int  ) >(&IFSelect_ShareOut::SetLastRun),
             R"#(Records a new value for the rank of last run item)#"  , py::arg("last")
          )
        .def("NbDispatches",
             (int (IFSelect_ShareOut::*)() const) static_cast<int (IFSelect_ShareOut::*)() const>(&IFSelect_ShareOut::NbDispatches),
             R"#(Returns the count of Dispatches)#" 
          )
        .def("DispatchRank",
             (int (IFSelect_ShareOut::*)(  const handle<IFSelect_Dispatch> &  ) const) static_cast<int (IFSelect_ShareOut::*)(  const handle<IFSelect_Dispatch> &  ) const>(&IFSelect_ShareOut::DispatchRank),
             R"#(Returns the Rank of a Dispatch, given its Value (Handle). Returns 0 if the Dispatch is unknown in the ShareOut)#"  , py::arg("disp")
          )
        .def("Dispatch",
             ( const handle<IFSelect_Dispatch> & (IFSelect_ShareOut::*)(  const int  ) const) static_cast< const handle<IFSelect_Dispatch> & (IFSelect_ShareOut::*)(  const int  ) const>(&IFSelect_ShareOut::Dispatch),
             R"#(Returns a Dispatch, given its rank in the list)#"  , py::arg("num")
          )
        .def("AddDispatch",
             (void (IFSelect_ShareOut::*)(  const handle<IFSelect_Dispatch> &  ) ) static_cast<void (IFSelect_ShareOut::*)(  const handle<IFSelect_Dispatch> &  ) >(&IFSelect_ShareOut::AddDispatch),
             R"#(Adds a Dispatch to the list)#"  , py::arg("disp")
          )
        .def("RemoveDispatch",
             (bool (IFSelect_ShareOut::*)(  const int  ) ) static_cast<bool (IFSelect_ShareOut::*)(  const int  ) >(&IFSelect_ShareOut::RemoveDispatch),
             R"#(Removes a Dispatch, given its rank in the list Returns True if done, False if rank is not between (LastRun + 1) and (NbDispatches))#"  , py::arg("rank")
          )
        .def("AddModifier",
             (void (IFSelect_ShareOut::*)(  const handle<IFSelect_GeneralModifier> & ,   const int  ) ) static_cast<void (IFSelect_ShareOut::*)(  const handle<IFSelect_GeneralModifier> & ,   const int  ) >(&IFSelect_ShareOut::AddModifier),
             R"#(Sets a Modifier to be applied on all Dispatches to be run If <modifier> is a ModelModifier, adds it to the list of Model Modifiers; else to the list of File Modifiers By default (atnum = 0) at the end of the list, else at <atnum> Each Modifier is used, after each copy of a packet of Entities into a Model : its criteria are checked and if they are OK, the method Perform of this Modifier is run.)#"  , py::arg("modifier"),  py::arg("atnum")
          )
        .def("AddModifier",
             (void (IFSelect_ShareOut::*)(  const handle<IFSelect_GeneralModifier> & ,   const int ,   const int  ) ) static_cast<void (IFSelect_ShareOut::*)(  const handle<IFSelect_GeneralModifier> & ,   const int ,   const int  ) >(&IFSelect_ShareOut::AddModifier),
             R"#(Sets a Modifier to be applied on the Dispatch <dispnum> If <modifier> is a ModelModifier, adds it to the list of Model Modifiers; else to the list of File Modifiers This is the same list as for all Dispatches, but the Modifier is qualified to be applied to one Dispatch only Then, <atnum> refers to the entire list By default (atnum = 0) at the end of the list, else at <atnum> Remark : if the Modifier was already in the list and if <atnum> = 0, the Modifier is not moved, but only qualified for a Dispatch)#"  , py::arg("modifier"),  py::arg("dispnum"),  py::arg("atnum")
          )
        .def("AddModif",
             (void (IFSelect_ShareOut::*)(  const handle<IFSelect_GeneralModifier> & ,   const bool ,   const int  ) ) static_cast<void (IFSelect_ShareOut::*)(  const handle<IFSelect_GeneralModifier> & ,   const bool ,   const int  ) >(&IFSelect_ShareOut::AddModif),
             R"#(Adds a Modifier to the list of Modifiers : Model Modifiers if <formodel> is True, File Modifiers else (internal).)#"  , py::arg("modifier"),  py::arg("formodel"),  py::arg("atnum")=static_cast< const int>(0)
          )
        .def("NbModifiers",
             (int (IFSelect_ShareOut::*)(  const bool  ) const) static_cast<int (IFSelect_ShareOut::*)(  const bool  ) const>(&IFSelect_ShareOut::NbModifiers),
             R"#(Returns count of Modifiers (which apply to complete Models) : Model Modifiers if <formodel> is True, File Modifiers else)#"  , py::arg("formodel")
          )
        .def("GeneralModifier",
             (handle<IFSelect_GeneralModifier> (IFSelect_ShareOut::*)(  const bool ,   const int  ) const) static_cast<handle<IFSelect_GeneralModifier> (IFSelect_ShareOut::*)(  const bool ,   const int  ) const>(&IFSelect_ShareOut::GeneralModifier),
             R"#(Returns a Modifier of the list, given its rank : Model Modifiers if <formodel> is True, File Modifiers else)#"  , py::arg("formodel"),  py::arg("num")
          )
        .def("ModelModifier",
             (handle<IFSelect_Modifier> (IFSelect_ShareOut::*)(  const int  ) const) static_cast<handle<IFSelect_Modifier> (IFSelect_ShareOut::*)(  const int  ) const>(&IFSelect_ShareOut::ModelModifier),
             R"#(Returns a Modifier of the list of Model Modifiers, duely casted)#"  , py::arg("num")
          )
        .def("ModifierRank",
             (int (IFSelect_ShareOut::*)(  const handle<IFSelect_GeneralModifier> &  ) const) static_cast<int (IFSelect_ShareOut::*)(  const handle<IFSelect_GeneralModifier> &  ) const>(&IFSelect_ShareOut::ModifierRank),
             R"#(Gives the rank of a Modifier in the list, 0 if not in the list Model Modifiers if <modifier> is kind of ModelModifer, File Modifiers else)#"  , py::arg("modifier")
          )
        .def("RemoveModifier",
             (bool (IFSelect_ShareOut::*)(  const bool ,   const int  ) ) static_cast<bool (IFSelect_ShareOut::*)(  const bool ,   const int  ) >(&IFSelect_ShareOut::RemoveModifier),
             R"#(Removes a Modifier, given it rank in the list : Model Modifiers if <formodel> is True, File Modifiers else Returns True if done, False if <num> is out of range)#"  , py::arg("formodel"),  py::arg("num")
          )
        .def("ChangeModifierRank",
             (bool (IFSelect_ShareOut::*)(  const bool ,   const int ,   const int  ) ) static_cast<bool (IFSelect_ShareOut::*)(  const bool ,   const int ,   const int  ) >(&IFSelect_ShareOut::ChangeModifierRank),
             R"#(Changes the rank of a modifier in the list : Model Modifiers if <formodel> is True, File Modifiers else from <before> to <after> Returns True if done, False else (before or after out of range))#"  , py::arg("formodel"),  py::arg("befor"),  py::arg("after")
          )
        .def("SetRootName",
             (bool (IFSelect_ShareOut::*)(  const int ,   const handle<TCollection_HAsciiString> &  ) ) static_cast<bool (IFSelect_ShareOut::*)(  const int ,   const handle<TCollection_HAsciiString> &  ) >(&IFSelect_ShareOut::SetRootName),
             R"#(Attaches a Root Name to a Dispatch given its rank, as an HAsciiString (standard form). A Null Handle resets this name. Returns True if OK, False if this Name is already attached, for a Dispatch or for Default, or <num> out of range)#"  , py::arg("num"),  py::arg("name")
          )
        .def("HasRootName",
             (bool (IFSelect_ShareOut::*)(  const int  ) const) static_cast<bool (IFSelect_ShareOut::*)(  const int  ) const>(&IFSelect_ShareOut::HasRootName),
             R"#(Returns True if the Dispatch of rank <num> has an attached Root Name. False else, or if num is out of range)#"  , py::arg("num")
          )
        .def("RootName",
             (handle<TCollection_HAsciiString> (IFSelect_ShareOut::*)(  const int  ) const) static_cast<handle<TCollection_HAsciiString> (IFSelect_ShareOut::*)(  const int  ) const>(&IFSelect_ShareOut::RootName),
             R"#(Returns the Root bound to a Dispatch, given its rank Returns a Null Handle if not defined)#"  , py::arg("num")
          )
        .def("RootNumber",
             (int (IFSelect_ShareOut::*)(  const handle<TCollection_HAsciiString> &  ) const) static_cast<int (IFSelect_ShareOut::*)(  const handle<TCollection_HAsciiString> &  ) const>(&IFSelect_ShareOut::RootNumber),
             R"#(Returns an integer value about a given root name : - positive : it's the rank of the Dispatch which has this name - null : this root name is unknown - negative (-1) : this root name is the default root name)#"  , py::arg("name")
          )
        .def("SetPrefix",
             (void (IFSelect_ShareOut::*)(  const handle<TCollection_HAsciiString> &  ) ) static_cast<void (IFSelect_ShareOut::*)(  const handle<TCollection_HAsciiString> &  ) >(&IFSelect_ShareOut::SetPrefix),
             R"#(Defines or Changes the general Prefix (which is prepended to complete file name generated). If this method is not call, Prefix remains empty)#"  , py::arg("pref")
          )
        .def("SetDefaultRootName",
             (bool (IFSelect_ShareOut::*)(  const handle<TCollection_HAsciiString> &  ) ) static_cast<bool (IFSelect_ShareOut::*)(  const handle<TCollection_HAsciiString> &  ) >(&IFSelect_ShareOut::SetDefaultRootName),
             R"#(Defines or Changes the Default Root Name to a new value (which is used for dispatches which have no attached root name). If this method is not called, DefaultRootName remains empty Returns True if OK, False if this Name is already attached, for a Dispatch or for Default)#"  , py::arg("defrt")
          )
        .def("SetExtension",
             (void (IFSelect_ShareOut::*)(  const handle<TCollection_HAsciiString> &  ) ) static_cast<void (IFSelect_ShareOut::*)(  const handle<TCollection_HAsciiString> &  ) >(&IFSelect_ShareOut::SetExtension),
             R"#(Defines or Changes the general Extension (which is appended to complete file name generated). If this method is not call, Extension remains empty)#"  , py::arg("ext")
          )
        .def("Prefix",
             (handle<TCollection_HAsciiString> (IFSelect_ShareOut::*)() const) static_cast<handle<TCollection_HAsciiString> (IFSelect_ShareOut::*)() const>(&IFSelect_ShareOut::Prefix),
             R"#(Returns the general Prefix. Can be empty.)#" 
          )
        .def("DefaultRootName",
             (handle<TCollection_HAsciiString> (IFSelect_ShareOut::*)() const) static_cast<handle<TCollection_HAsciiString> (IFSelect_ShareOut::*)() const>(&IFSelect_ShareOut::DefaultRootName),
             R"#(Returns the Default Root Name. Can be empty.)#" 
          )
        .def("Extension",
             (handle<TCollection_HAsciiString> (IFSelect_ShareOut::*)() const) static_cast<handle<TCollection_HAsciiString> (IFSelect_ShareOut::*)() const>(&IFSelect_ShareOut::Extension),
             R"#(Returns the general Extension. Can be empty (not recommended))#" 
          )
        .def("FileName",
             (TCollection_AsciiString (IFSelect_ShareOut::*)(  const int ,   const int ,   const int  ) ) static_cast<TCollection_AsciiString (IFSelect_ShareOut::*)(  const int ,   const int ,   const int  ) >(&IFSelect_ShareOut::FileName),
             R"#(Computes the complete file name for a Packet of a Dispatch, given Dispatch Number (Rank), Packet Number, and Count of Packets generated by this Dispatch (0 if unknown))#"  , py::arg("dnum"),  py::arg("pnum"),  py::arg("nbpack")=static_cast< const int>(0)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_ShareOut::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_ShareOut::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_ShareOut::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_ShareOut::*)() const>(&IFSelect_ShareOut::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_ShareOutResult from ./opencascade/IFSelect_ShareOutResult.hxx
    klass = m.attr("IFSelect_ShareOutResult");

    // default constructor
    register_default_constructor<IFSelect_ShareOutResult , shared_ptr<IFSelect_ShareOutResult>>(m,"IFSelect_ShareOutResult");

    // nested enums

    static_cast<py::class_<IFSelect_ShareOutResult , shared_ptr<IFSelect_ShareOutResult>  >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("ShareOut",
             (handle<IFSelect_ShareOut> (IFSelect_ShareOutResult::*)() const) static_cast<handle<IFSelect_ShareOut> (IFSelect_ShareOutResult::*)() const>(&IFSelect_ShareOutResult::ShareOut),
             R"#(Returns the ShareOut used to create the ShareOutResult if creation from a Dispatch, returns a Null Handle)#" 
          )
        .def("Reset",
             (void (IFSelect_ShareOutResult::*)() ) static_cast<void (IFSelect_ShareOutResult::*)() >(&IFSelect_ShareOutResult::Reset),
             R"#(Erases computed data, in order to command a new Evaluation)#" 
          )
        .def("Evaluate",
             (void (IFSelect_ShareOutResult::*)() ) static_cast<void (IFSelect_ShareOutResult::*)() >(&IFSelect_ShareOutResult::Evaluate),
             R"#(Evaluates the result of a ShareOut : determines Entities to be forgotten by the ShareOut, Entities to be transferred several times (duplicated), prepares an iteration on the packets to be produced Called the first time anyone question is asked, or after a call to Reset. Works by calling the method Prepare.)#" 
          )
        .def("Packets",
             (handle<IFSelect_PacketList> (IFSelect_ShareOutResult::*)(  const bool  ) ) static_cast<handle<IFSelect_PacketList> (IFSelect_ShareOutResult::*)(  const bool  ) >(&IFSelect_ShareOutResult::Packets),
             R"#(Returns the list of recorded Packets, under two modes : - <complete> = False, the strict definition of Packets, i.e. for each one, the Root Entities, to be explicitly sent - <complete> = True (Default), the completely evaluated list, i.e. which really gives the destination of each entity : this mode allows to evaluate duplications Remark that to send packets, iteration remains preferable (file names are managed))#"  , py::arg("complete")=static_cast< const bool>(true)
          )
        .def("NbPackets",
             (int (IFSelect_ShareOutResult::*)() ) static_cast<int (IFSelect_ShareOutResult::*)() >(&IFSelect_ShareOutResult::NbPackets),
             R"#(Returns the total count of produced non empty packets (in out : calls Evaluate as necessary))#" 
          )
        .def("Prepare",
             (void (IFSelect_ShareOutResult::*)() ) static_cast<void (IFSelect_ShareOutResult::*)() >(&IFSelect_ShareOutResult::Prepare),
             R"#(Prepares the iteration on the packets This method is called by Evaluate, but can be called anytime The iteration consists in taking each Dispatch of the ShareOut beginning by the first one, compute its packets, then iterate on these packets. Once all these packets are iterated, the iteration passes to the next Dispatch, or stops. For a creation from a unique Dispatch, same but with only this Dispatch. Each packet can be listed, or really transferred (producing a derived Model, from which a file can be generated))#" 
          )
        .def("More",
             (bool (IFSelect_ShareOutResult::*)() ) static_cast<bool (IFSelect_ShareOutResult::*)() >(&IFSelect_ShareOutResult::More),
             R"#(Returns True if there is more packets in the current Dispatch, else if there is more Dispatch in the ShareOut)#" 
          )
        .def("Next",
             (void (IFSelect_ShareOutResult::*)() ) static_cast<void (IFSelect_ShareOutResult::*)() >(&IFSelect_ShareOutResult::Next),
             R"#(Passes to the next Packet in the current Dispatch, or if there is none, to the next Dispatch in the ShareOut)#" 
          )
        .def("NextDispatch",
             (void (IFSelect_ShareOutResult::*)() ) static_cast<void (IFSelect_ShareOutResult::*)() >(&IFSelect_ShareOutResult::NextDispatch),
             R"#(Passes to the next Dispatch, regardless about remaining packets)#" 
          )
        .def("Dispatch",
             (handle<IFSelect_Dispatch> (IFSelect_ShareOutResult::*)() const) static_cast<handle<IFSelect_Dispatch> (IFSelect_ShareOutResult::*)() const>(&IFSelect_ShareOutResult::Dispatch),
             R"#(Returns the current Dispatch)#" 
          )
        .def("DispatchRank",
             (int (IFSelect_ShareOutResult::*)() const) static_cast<int (IFSelect_ShareOutResult::*)() const>(&IFSelect_ShareOutResult::DispatchRank),
             R"#(Returns the Rank of the current Dispatch in the ShareOut Returns Zero if there is none (iteration finished))#" 
          )
        .def("FileName",
             (TCollection_AsciiString (IFSelect_ShareOutResult::*)() const) static_cast<TCollection_AsciiString (IFSelect_ShareOutResult::*)() const>(&IFSelect_ShareOutResult::FileName),
             R"#(Returns the File Name which corresponds to current Packet (computed by ShareOut) If current Packet has no associated name (see ShareOut), the returned value is Null)#" 
          )
    // methods using call by reference i.s.o. return
        .def("PacketsInDispatch",
             []( IFSelect_ShareOutResult &self   ){
                 int  numpack;
                int  nbpacks;

                 self.PacketsInDispatch(numpack,nbpacks);
                 return std::make_tuple(numpack,nbpacks); },
             R"#(Returns Number (rank) of current Packet in current Dispatch, and total count of Packets in current Dispatch, as arguments)#" 
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class IFSelect_Signature from ./opencascade/IFSelect_Signature.hxx
    klass = m.attr("IFSelect_Signature");


    // nested enums

    static_cast<py::class_<IFSelect_Signature ,opencascade::handle<IFSelect_Signature> ,Py_IFSelect_Signature >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("SetIntCase",
             (void (IFSelect_Signature::*)(  const bool ,   const int ,   const bool ,   const int  ) ) static_cast<void (IFSelect_Signature::*)(  const bool ,   const int ,   const bool ,   const int  ) >(&IFSelect_Signature::SetIntCase),
             R"#(Sets the information data to tell "integer cases" with possible min and max values To be called when creating)#"  , py::arg("hasmin"),  py::arg("valmin"),  py::arg("hasmax"),  py::arg("valmax")
          )
        .def("IsIntCase",
             (bool (IFSelect_Signature::*)( bool & ,  int & ,  bool & ,  int &  ) const) static_cast<bool (IFSelect_Signature::*)( bool & ,  int & ,  bool & ,  int &  ) const>(&IFSelect_Signature::IsIntCase),
             R"#(Tells if this Signature gives integer values and returns values from SetIntCase if True)#"  , py::arg("hasmin"),  py::arg("valmin"),  py::arg("hasmax"),  py::arg("valmax")
          )
        .def("AddCase",
             (void (IFSelect_Signature::*)(  const char * const   ) ) static_cast<void (IFSelect_Signature::*)(  const char * const   ) >(&IFSelect_Signature::AddCase),
             R"#(Adds a possible case To be called when creating, IF the list of possible cases for Value is known when starting For instance, for CDL types, rather do not fill this, but for a specific enumeration (such as a status), can be used)#"  , py::arg("acase")
          )
        .def("CaseList",
             (handle<NCollection_HSequence<TCollection_AsciiString>> (IFSelect_Signature::*)() const) static_cast<handle<NCollection_HSequence<TCollection_AsciiString>> (IFSelect_Signature::*)() const>(&IFSelect_Signature::CaseList),
             R"#(Returns the predefined list of possible cases, filled by AddCase Null Handle if no predefined list (hence, to be counted) Useful to filter on really possible vase, for instance, or for a help)#" 
          )
        .def("Name",
             ( const char * (IFSelect_Signature::*)() const) static_cast< const char * (IFSelect_Signature::*)() const>(&IFSelect_Signature::Name),
             R"#(Returns an identification of the Signature (a word), given at initialization time Returns the Signature for a Transient object. It is specific of each sub-class of Signature. For a Null Handle, it should provide "" It can work with the model which contains the entity)#" 
          )
        .def("Label",
             (TCollection_AsciiString (IFSelect_Signature::*)() const) static_cast<TCollection_AsciiString (IFSelect_Signature::*)() const>(&IFSelect_Signature::Label),
             R"#(The label of a Signature uses its name as follow : "Signature : <name>")#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("MatchValue_s",
                    (bool (*)(  const char * const  ,   const TCollection_AsciiString & ,   const bool  ) ) static_cast<bool (*)(  const char * const  ,   const TCollection_AsciiString & ,   const bool  ) >(&IFSelect_Signature::MatchValue),
                    R"#(Default procedure to tell if a value <val> matches a text with a criterium <exact>. <exact> = True requires equality, else only contained (no reg-exp))#"  , py::arg("val"),  py::arg("text"),  py::arg("exact")
          )
        .def_static("IntValue_s",
                    ( const char * (*)(  const int  ) ) static_cast< const char * (*)(  const int  ) >(&IFSelect_Signature::IntValue),
                    R"#(This procedure converts an Integer to a CString It is a convenient way when the value of a signature has the form of a simple integer value The value is to be used immediately (one buffer only, no copy))#"  , py::arg("val")
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_Signature::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_Signature::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_Signature::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_Signature::*)() const>(&IFSelect_Signature::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SignatureList from ./opencascade/IFSelect_SignatureList.hxx
    klass = m.attr("IFSelect_SignatureList");


    // nested enums

    static_cast<py::class_<IFSelect_SignatureList ,opencascade::handle<IFSelect_SignatureList>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const bool >()  , py::arg("withlist")=static_cast< const bool>(false) )
    // custom constructors
    // methods
        .def("SetList",
             (void (IFSelect_SignatureList::*)(  const bool  ) ) static_cast<void (IFSelect_SignatureList::*)(  const bool  ) >(&IFSelect_SignatureList::SetList),
             R"#(Changes the record-list status. The list is not cleared but its use changes)#"  , py::arg("withlist")
          )
        .def("Clear",
             (void (IFSelect_SignatureList::*)() ) static_cast<void (IFSelect_SignatureList::*)() >(&IFSelect_SignatureList::Clear),
             R"#()#" 
          )
        .def("Add",
             (void (IFSelect_SignatureList::*)(  const handle<Standard_Transient> & ,   const char * const   ) ) static_cast<void (IFSelect_SignatureList::*)(  const handle<Standard_Transient> & ,   const char * const   ) >(&IFSelect_SignatureList::Add),
             R"#(Adds an entity with its signature, i.e. : - counts an item more for <sign> - if record-list status is set, records the entity Accepts a null entity (the signature is then for the global model). But if the string is empty, counts a Null item.)#"  , py::arg("ent"),  py::arg("sign")
          )
        .def("LastValue",
             ( const char * (IFSelect_SignatureList::*)() const) static_cast< const char * (IFSelect_SignatureList::*)() const>(&IFSelect_SignatureList::LastValue),
             R"#(Returns the last value recorded by Add (only if SignMode set) Cleared by Clear or Init)#" 
          )
        .def("Init",
             (void (IFSelect_SignatureList::*)(  const char * const  ,   const NCollection_IndexedDataMap<TCollection_AsciiString, int> & ,   const NCollection_IndexedDataMap<TCollection_AsciiString, handle<Standard_Transient>> & ,   const int  ) ) static_cast<void (IFSelect_SignatureList::*)(  const char * const  ,   const NCollection_IndexedDataMap<TCollection_AsciiString, int> & ,   const NCollection_IndexedDataMap<TCollection_AsciiString, handle<Standard_Transient>> & ,   const int  ) >(&IFSelect_SignatureList::Init),
             R"#(Acknowledges the list in once. Name identifies the Signature)#"  , py::arg("name"),  py::arg("count"),  py::arg("list"),  py::arg("nbnuls")
          )
        .def("List",
             (handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> (IFSelect_SignatureList::*)(  const char * const   ) const) static_cast<handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> (IFSelect_SignatureList::*)(  const char * const   ) const>(&IFSelect_SignatureList::List),
             R"#(Returns the list of signatures, as a sequence of strings (but without their respective counts). It is ordered. By default, for all the signatures. If <root> is given non empty, for the signatures which begin by <root>)#"  , py::arg("root")=static_cast< const char * const >("")
          )
        .def("HasEntities",
             (bool (IFSelect_SignatureList::*)() const) static_cast<bool (IFSelect_SignatureList::*)() const>(&IFSelect_SignatureList::HasEntities),
             R"#(Returns True if the list of Entities is acknowledged, else the method Entities will always return a Null Handle)#" 
          )
        .def("NbNulls",
             (int (IFSelect_SignatureList::*)() const) static_cast<int (IFSelect_SignatureList::*)() const>(&IFSelect_SignatureList::NbNulls),
             R"#(Returns the count of null entities)#" 
          )
        .def("NbTimes",
             (int (IFSelect_SignatureList::*)(  const char * const   ) const) static_cast<int (IFSelect_SignatureList::*)(  const char * const   ) const>(&IFSelect_SignatureList::NbTimes),
             R"#(Returns the number of times a signature was counted, 0 if it has not been recorded at all)#"  , py::arg("sign")
          )
        .def("Entities",
             (handle<NCollection_HSequence<handle<Standard_Transient>>> (IFSelect_SignatureList::*)(  const char * const   ) const) static_cast<handle<NCollection_HSequence<handle<Standard_Transient>>> (IFSelect_SignatureList::*)(  const char * const   ) const>(&IFSelect_SignatureList::Entities),
             R"#(Returns the list of entities attached to a signature It is empty if <sign> has not been recorded It is a Null Handle if the list of entities is not known)#"  , py::arg("sign")
          )
        .def("SetName",
             (void (IFSelect_SignatureList::*)(  const char * const   ) ) static_cast<void (IFSelect_SignatureList::*)(  const char * const   ) >(&IFSelect_SignatureList::SetName),
             R"#(Defines a name for a SignatureList (used to print it))#"  , py::arg("name")
          )
        .def("Name",
             ( const char * (IFSelect_SignatureList::*)() const) static_cast< const char * (IFSelect_SignatureList::*)() const>(&IFSelect_SignatureList::Name),
             R"#(Returns the recorded Name. Remark : default is "..." (no SetName called))#" 
          )
        .def("PrintCount",
             (void (IFSelect_SignatureList::*)( Standard_OStream &  ) const) static_cast<void (IFSelect_SignatureList::*)( Standard_OStream &  ) const>(&IFSelect_SignatureList::PrintCount),
             R"#(Prints the counts of items (not the list))#"  , py::arg("S")
          )
        .def("PrintSum",
             (void (IFSelect_SignatureList::*)( Standard_OStream &  ) const) static_cast<void (IFSelect_SignatureList::*)( Standard_OStream &  ) const>(&IFSelect_SignatureList::PrintSum),
             R"#(Prints a summary Item which has the greatest count of entities For items which are numeric values : their count, maximum, minimum values, cumul, average)#"  , py::arg("S")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SignatureList::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SignatureList::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def_property("ModeSignOnly",
                     [](IFSelect_SignatureList& self){return self.ModeSignOnly();} ,
                     [](IFSelect_SignatureList& self, bool  val){self.ModeSignOnly() = val;},                      R"#(Returns modifiable the SignOnly Mode If False (D), the counter normally counts If True, the counting work is turned off, Add only fills the LastValue, which can be used as signature, when a counter works from data which are not available from a Signature)#"
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SignatureList::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SignatureList::*)() const>(&IFSelect_SignatureList::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_Transformer from ./opencascade/IFSelect_Transformer.hxx
    klass = m.attr("IFSelect_Transformer");


    // nested enums

    static_cast<py::class_<IFSelect_Transformer ,opencascade::handle<IFSelect_Transformer> ,Py_IFSelect_Transformer , Standard_Transient >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("Updated",
             (bool (IFSelect_Transformer::*)(  const handle<Standard_Transient> & ,  handle<Standard_Transient> &  ) const) static_cast<bool (IFSelect_Transformer::*)(  const handle<Standard_Transient> & ,  handle<Standard_Transient> &  ) const>(&IFSelect_Transformer::Updated),
             R"#(This method allows to know what happened to a starting entity after the last Perform. If <entfrom> (from starting model) has one and only one known item which corresponds in the new produced model, this method must return True and fill the argument <entto>. Else, it returns False.)#"  , py::arg("entfrom"),  py::arg("entto")
          )
        .def("Label",
             (TCollection_AsciiString (IFSelect_Transformer::*)() const) static_cast<TCollection_AsciiString (IFSelect_Transformer::*)() const>(&IFSelect_Transformer::Label),
             R"#(Returns a text which defines the way a Transformer works (to identify the transformation it performs))#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_Transformer::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_Transformer::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_Transformer::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_Transformer::*)() const>(&IFSelect_Transformer::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_WorkLibrary from ./opencascade/IFSelect_WorkLibrary.hxx
    klass = m.attr("IFSelect_WorkLibrary");


    // nested enums

    static_cast<py::class_<IFSelect_WorkLibrary ,opencascade::handle<IFSelect_WorkLibrary> ,Py_IFSelect_WorkLibrary , Standard_Transient >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("WriteFile",
             (bool (IFSelect_WorkLibrary::*)( IFSelect_ContextWrite &  ) const) static_cast<bool (IFSelect_WorkLibrary::*)( IFSelect_ContextWrite &  ) const>(&IFSelect_WorkLibrary::WriteFile),
             R"#(Gives the way to Write a File from a Model. <ctx> contains all necessary information : the model, the protocol, the file name, and the list of File Modifiers to be applied, also with restricted list of selected entities for each one, if required. In return, it brings the produced check-list)#"  , py::arg("ctx")
          )
        .def("SetDumpLevels",
             (void (IFSelect_WorkLibrary::*)(  const int ,   const int  ) ) static_cast<void (IFSelect_WorkLibrary::*)(  const int ,   const int  ) >(&IFSelect_WorkLibrary::SetDumpLevels),
             R"#(Records a default level and a maximum value for level level for DumpEntity can go between 0 and <max> default value will be <def>)#"  , py::arg("def_"),  py::arg("max")
          )
        .def("SetDumpHelp",
             (void (IFSelect_WorkLibrary::*)(  const int ,   const char * const   ) ) static_cast<void (IFSelect_WorkLibrary::*)(  const int ,   const char * const   ) >(&IFSelect_WorkLibrary::SetDumpHelp),
             R"#(Records a short line of help for a level (0 - max))#"  , py::arg("level"),  py::arg("help")
          )
        .def("DumpHelp",
             ( const char * (IFSelect_WorkLibrary::*)(  const int  ) const) static_cast< const char * (IFSelect_WorkLibrary::*)(  const int  ) const>(&IFSelect_WorkLibrary::DumpHelp),
             R"#(Returns the help line recorded for <level>, or an empty string)#"  , py::arg("level")
          )
    // methods using call by reference i.s.o. return
        .def("DumpLevels",
             []( IFSelect_WorkLibrary &self   ){
                 int  def_;
                int  max;

                 self.DumpLevels(def_,max);
                 return std::make_tuple(def_,max); },
             R"#(Returns the recorded default and maximum dump levels If none was recorded, max is returned negative, def as zero)#" 
          )
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_WorkLibrary::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_WorkLibrary::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_WorkLibrary::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_WorkLibrary::*)() const>(&IFSelect_WorkLibrary::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_WorkSession from ./opencascade/IFSelect_WorkSession.hxx
    klass = m.attr("IFSelect_WorkSession");


    // nested enums

    static_cast<py::class_<IFSelect_WorkSession ,opencascade::handle<IFSelect_WorkSession>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetErrorHandle",
             (void (IFSelect_WorkSession::*)(  const bool  ) ) static_cast<void (IFSelect_WorkSession::*)(  const bool  ) >(&IFSelect_WorkSession::SetErrorHandle),
             R"#(Changes the Error Handler status (by default, it is not set))#"  , py::arg("toHandle")
          )
        .def("ErrorHandle",
             (bool (IFSelect_WorkSession::*)() const) static_cast<bool (IFSelect_WorkSession::*)() const>(&IFSelect_WorkSession::ErrorHandle),
             R"#(Returns the Error Handler status)#" 
          )
        .def("SetShareOut",
             (void (IFSelect_WorkSession::*)(  const handle<IFSelect_ShareOut> &  ) ) static_cast<void (IFSelect_WorkSession::*)(  const handle<IFSelect_ShareOut> &  ) >(&IFSelect_WorkSession::SetShareOut),
             R"#(Sets a new ShareOut. Fills Items which its content Warning : data from the former ShareOut are lost)#"  , py::arg("shareout")
          )
        .def("SetModeStat",
             (void (IFSelect_WorkSession::*)(  const bool  ) ) static_cast<void (IFSelect_WorkSession::*)(  const bool  ) >(&IFSelect_WorkSession::SetModeStat),
             R"#(Set value of mode responsible for presence of selections after loading If mode set to true that different selections will be accessible after loading else selections will be not accessible after loading( for economy memory in applications))#"  , py::arg("theMode")
          )
        .def("GetModeStat",
             (bool (IFSelect_WorkSession::*)() const) static_cast<bool (IFSelect_WorkSession::*)() const>(&IFSelect_WorkSession::GetModeStat),
             R"#(Return value of mode defining of filling selection during loading)#" 
          )
        .def("SetLibrary",
             (void (IFSelect_WorkSession::*)(  const handle<IFSelect_WorkLibrary> &  ) ) static_cast<void (IFSelect_WorkSession::*)(  const handle<IFSelect_WorkLibrary> &  ) >(&IFSelect_WorkSession::SetLibrary),
             R"#(Sets a WorkLibrary, which will be used to Read and Write Files)#"  , py::arg("theLib")
          )
        .def("SetSignType",
             (void (IFSelect_WorkSession::*)(  const handle<IFSelect_Signature> &  ) ) static_cast<void (IFSelect_WorkSession::*)(  const handle<IFSelect_Signature> &  ) >(&IFSelect_WorkSession::SetSignType),
             R"#(Sets a specific Signature to be the SignType, i.e. the Signature which will determine TypeName from the Model (basic function). It is recorded in the GTool This Signature is also set as "xst-sign-type" (reserved name))#"  , py::arg("signtype")
          )
        .def("SignType",
             (handle<IFSelect_Signature> (IFSelect_WorkSession::*)() const) static_cast<handle<IFSelect_Signature> (IFSelect_WorkSession::*)() const>(&IFSelect_WorkSession::SignType),
             R"#(Returns the current SignType)#" 
          )
        .def("HasModel",
             (bool (IFSelect_WorkSession::*)() const) static_cast<bool (IFSelect_WorkSession::*)() const>(&IFSelect_WorkSession::HasModel),
             R"#(Returns True is a Model has been set)#" 
          )
        .def("SetLoadedFile",
             (void (IFSelect_WorkSession::*)(  const char * const   ) ) static_cast<void (IFSelect_WorkSession::*)(  const char * const   ) >(&IFSelect_WorkSession::SetLoadedFile),
             R"#(Stores the filename used for read for setting the model It is cleared by SetModel and ClearData(1))#"  , py::arg("theFileName")
          )
        .def("LoadedFile",
             ( const char * (IFSelect_WorkSession::*)() const) static_cast< const char * (IFSelect_WorkSession::*)() const>(&IFSelect_WorkSession::LoadedFile),
             R"#(Returns the filename used to load current model empty if unknown)#" 
          )
        .def("ReadFile",
             (IFSelect_ReturnStatus (IFSelect_WorkSession::*)(  const char * const   ) ) static_cast<IFSelect_ReturnStatus (IFSelect_WorkSession::*)(  const char * const   ) >(&IFSelect_WorkSession::ReadFile),
             R"#(Reads a file with the WorkLibrary (sets Model and LoadedFile) Returns a integer status which can be : RetDone if OK, RetVoid if no Protocol not defined, RetError for file not found, RetFail if fail during read)#"  , py::arg("filename")
          )
        .def("ReadStream",
             (IFSelect_ReturnStatus (IFSelect_WorkSession::*)(  const char * const  ,  typename std::istream &  ) ) static_cast<IFSelect_ReturnStatus (IFSelect_WorkSession::*)(  const char * const  ,  typename std::istream &  ) >(&IFSelect_WorkSession::ReadStream),
             R"#(Reads a file from stream with the WorkLibrary (sets Model and LoadedFile) Returns a integer status which can be : RetDone if OK, RetVoid if no Protocol not defined, RetError for file not found, RetFail if fail during read)#"  , py::arg("theName"),  py::arg("theIStream")
          )
        .def("NbStartingEntities",
             (int (IFSelect_WorkSession::*)() const) static_cast<int (IFSelect_WorkSession::*)() const>(&IFSelect_WorkSession::NbStartingEntities),
             R"#(Returns the count of Entities stored in the Model, or 0)#" 
          )
        .def("StartingEntity",
             (handle<Standard_Transient> (IFSelect_WorkSession::*)(  const int  ) const) static_cast<handle<Standard_Transient> (IFSelect_WorkSession::*)(  const int  ) const>(&IFSelect_WorkSession::StartingEntity),
             R"#(Returns an Entity stored in the Model of the WorkSession (Null Handle is no Model or num out of range))#"  , py::arg("num")
          )
        .def("StartingNumber",
             (int (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) const) static_cast<int (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) const>(&IFSelect_WorkSession::StartingNumber),
             R"#(Returns the Number of an Entity in the Model (0 if no Model set or <ent> not in the Model))#"  , py::arg("ent")
          )
        .def("NumberFromLabel",
             (int (IFSelect_WorkSession::*)(  const char * const  ,   const int  ) const) static_cast<int (IFSelect_WorkSession::*)(  const char * const  ,   const int  ) const>(&IFSelect_WorkSession::NumberFromLabel),
             R"#(From a given label in Model, returns the corresponding number Starts from first entity by Default, may start after a given number : this number may be given negative, its absolute value is then considered. Hence a loop on NumberFromLabel may be programmed (stop test is : returned value positive or null))#"  , py::arg("val"),  py::arg("afternum")=static_cast< const int>(0)
          )
        .def("EntityLabel",
             (handle<TCollection_HAsciiString> (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) const) static_cast<handle<TCollection_HAsciiString> (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) const>(&IFSelect_WorkSession::EntityLabel),
             R"#(Returns the label for <ent>, as the Model does If <ent> is not in the Model or if no Model is loaded, a Null Handle is returned)#"  , py::arg("ent")
          )
        .def("EntityName",
             (handle<TCollection_HAsciiString> (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) const) static_cast<handle<TCollection_HAsciiString> (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) const>(&IFSelect_WorkSession::EntityName),
             R"#(Returns the Name of an Entity This Name is computed by the general service Name Returns a Null Handle if fails)#"  , py::arg("ent")
          )
        .def("CategoryNumber",
             (int (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) const) static_cast<int (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) const>(&IFSelect_WorkSession::CategoryNumber),
             R"#(Returns the Category Number determined for an entity it is computed by the class Category An unknown entity (number 0) gives a value -1)#"  , py::arg("ent")
          )
        .def("CategoryName",
             ( const char * (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) const) static_cast< const char * (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) const>(&IFSelect_WorkSession::CategoryName),
             R"#(Returns the Category Name determined for an entity it is computed by the class Category Remark : an unknown entity gives an empty string)#"  , py::arg("ent")
          )
        .def("ValidityName",
             ( const char * (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) const) static_cast< const char * (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) const>(&IFSelect_WorkSession::ValidityName),
             R"#(Returns the Validity Name determined for an entity it is computed by the class SignValidity Remark : an unknown entity gives an empty string)#"  , py::arg("ent")
          )
        .def("ClearData",
             (void (IFSelect_WorkSession::*)(  const int  ) ) static_cast<void (IFSelect_WorkSession::*)(  const int  ) >(&IFSelect_WorkSession::ClearData),
             R"#(Clears recorded data (not the items) according mode : 1 : all Data : Model, Graph, CheckList, + ClearData 4 2 : Graph and CheckList (they will then be recomputed later) 3 : CheckList (it will be recomputed by ComputeCheck) 4 : just content of SelectPointed and Counters Plus 0 : does nothing but called by SetModel ClearData is virtual, hence it can be redefined to clear other data of a specialised Work Session)#"  , py::arg("mode")
          )
        .def("ComputeGraph",
             (bool (IFSelect_WorkSession::*)(  const bool  ) ) static_cast<bool (IFSelect_WorkSession::*)(  const bool  ) >(&IFSelect_WorkSession::ComputeGraph),
             R"#(Computes the Graph used for Selections, Displays ... If a HGraph is already set, with same model as given by method Model, does nothing. Else, computes a new Graph. If <enforce> is given True, computes a new Graph anyway. Remark that a call to ClearGraph will cause ComputeGraph to really compute a new Graph Returns True if Graph is OK, False else (i.e. if no Protocol is set, or if Model is absent or empty).)#"  , py::arg("enforce")=static_cast< const bool>(false)
          )
        .def("Shareds",
             (handle<NCollection_HSequence<handle<Standard_Transient>>> (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) ) static_cast<handle<NCollection_HSequence<handle<Standard_Transient>>> (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) >(&IFSelect_WorkSession::Shareds),
             R"#(Returns the list of entities shared by <ent> (can be empty) Returns a null Handle if <ent> is unknown)#"  , py::arg("ent")
          )
        .def("Sharings",
             (handle<NCollection_HSequence<handle<Standard_Transient>>> (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) ) static_cast<handle<NCollection_HSequence<handle<Standard_Transient>>> (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) >(&IFSelect_WorkSession::Sharings),
             R"#(Returns the list of entities sharing <ent> (can be empty) Returns a null Handle if <ent> is unknown)#"  , py::arg("ent")
          )
        .def("IsLoaded",
             (bool (IFSelect_WorkSession::*)() const) static_cast<bool (IFSelect_WorkSession::*)() const>(&IFSelect_WorkSession::IsLoaded),
             R"#(Returns True if a Model is defined and really loaded (not empty), a Protocol is set and a Graph has been computed. In this case, the WorkSession can start to work)#" 
          )
        .def("ComputeCheck",
             (bool (IFSelect_WorkSession::*)(  const bool  ) ) static_cast<bool (IFSelect_WorkSession::*)(  const bool  ) >(&IFSelect_WorkSession::ComputeCheck),
             R"#(Computes the CheckList for the Model currently loaded It can then be used for displays, queries ... Returns True if OK, False else (i.e. no Protocol set, or Model absent). If <enforce> is False, works only if not already done or if a new Model has been loaded from last call. Remark : computation is enforced by every call to SetModel or RunTransformer)#"  , py::arg("enforce")=static_cast< const bool>(false)
          )
        .def("MaxIdent",
             (int (IFSelect_WorkSession::*)() const) static_cast<int (IFSelect_WorkSession::*)() const>(&IFSelect_WorkSession::MaxIdent),
             R"#(Returns the Maximum Value for an Item Identifier. It can be greater to the count of known Items, because some can have been removed)#" 
          )
        .def("Item",
             (handle<Standard_Transient> (IFSelect_WorkSession::*)(  const int  ) const) static_cast<handle<Standard_Transient> (IFSelect_WorkSession::*)(  const int  ) const>(&IFSelect_WorkSession::Item),
             R"#(Returns an Item, given its Ident. Returns a Null Handle if no Item corresponds to this Ident.)#"  , py::arg("id")
          )
        .def("ItemIdent",
             (int (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) const) static_cast<int (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) const>(&IFSelect_WorkSession::ItemIdent),
             R"#(Returns the Ident attached to an Item in the WorkSession, or Zero if it is unknown)#"  , py::arg("item")
          )
        .def("NamedItem",
             (handle<Standard_Transient> (IFSelect_WorkSession::*)(  const char * const   ) const) static_cast<handle<Standard_Transient> (IFSelect_WorkSession::*)(  const char * const   ) const>(&IFSelect_WorkSession::NamedItem),
             R"#(Returns the Item which corresponds to a Variable, given its Name (whatever the type of this Item). Returns a Null Handle if this Name is not recorded)#"  , py::arg("name")
          )
        .def("NamedItem",
             (handle<Standard_Transient> (IFSelect_WorkSession::*)(  const handle<TCollection_HAsciiString> &  ) const) static_cast<handle<Standard_Transient> (IFSelect_WorkSession::*)(  const handle<TCollection_HAsciiString> &  ) const>(&IFSelect_WorkSession::NamedItem),
             R"#(Same as above, but <name> is given through a Handle Especially useful with methods SelectionNames, etc...)#"  , py::arg("name")
          )
        .def("NameIdent",
             (int (IFSelect_WorkSession::*)(  const char * const   ) const) static_cast<int (IFSelect_WorkSession::*)(  const char * const   ) const>(&IFSelect_WorkSession::NameIdent),
             R"#(Returns the Ident attached to a Name, 0 if name not recorded)#"  , py::arg("name")
          )
        .def("HasName",
             (bool (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) const) static_cast<bool (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) const>(&IFSelect_WorkSession::HasName),
             R"#(Returns True if an Item of the WorkSession has an attached Name)#"  , py::arg("item")
          )
        .def("Name",
             (handle<TCollection_HAsciiString> (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) const) static_cast<handle<TCollection_HAsciiString> (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) const>(&IFSelect_WorkSession::Name),
             R"#(Returns the Name attached to an Item as a Variable of this WorkSession. If <item> is Null or not recorded, returns an empty string.)#"  , py::arg("item")
          )
        .def("AddItem",
             (int (IFSelect_WorkSession::*)(  const handle<Standard_Transient> & ,   const bool  ) ) static_cast<int (IFSelect_WorkSession::*)(  const handle<Standard_Transient> & ,   const bool  ) >(&IFSelect_WorkSession::AddItem),
             R"#(Adds an Item and returns its attached Ident. Does nothing if <item> is already recorded (and returns its attached Ident) <active> if True commands call to SetActive (see below) Remark : the determined Ident is used if <item> is a Dispatch, to fill the ShareOut)#"  , py::arg("item"),  py::arg("active")=static_cast< const bool>(true)
          )
        .def("AddNamedItem",
             (int (IFSelect_WorkSession::*)(  const char * const  ,   const handle<Standard_Transient> & ,   const bool  ) ) static_cast<int (IFSelect_WorkSession::*)(  const char * const  ,   const handle<Standard_Transient> & ,   const bool  ) >(&IFSelect_WorkSession::AddNamedItem),
             R"#(Adds an Item with an attached Name. If the Name is already known in the WorkSession, the older item losts it Returns Ident if Done, 0 else, i.e. if <item> is null If <name> is empty, works as AddItem (i.e. with no name) If <item> is already known but with no attached Name, this method tries to attached a Name to it <active> if True commands call to SetActive (see below))#"  , py::arg("name"),  py::arg("item"),  py::arg("active")=static_cast< const bool>(true)
          )
        .def("SetActive",
             (bool (IFSelect_WorkSession::*)(  const handle<Standard_Transient> & ,   const bool  ) ) static_cast<bool (IFSelect_WorkSession::*)(  const handle<Standard_Transient> & ,   const bool  ) >(&IFSelect_WorkSession::SetActive),
             R"#(Following the type of <item> : - Dispatch : Adds or Removes it in the ShareOut & FileNaming - GeneralModifier : Adds or Removes it for final sending (i.e. in the ModelCopier) Returns True if it did something, False else (state unchanged))#"  , py::arg("item"),  py::arg("mode")
          )
        .def("RemoveNamedItem",
             (bool (IFSelect_WorkSession::*)(  const char * const   ) ) static_cast<bool (IFSelect_WorkSession::*)(  const char * const   ) >(&IFSelect_WorkSession::RemoveNamedItem),
             R"#(Removes an Item from the Session, given its Name Returns True if Done, False else (Name not recorded) (Applies only on Item which are Named))#"  , py::arg("name")
          )
        .def("RemoveName",
             (bool (IFSelect_WorkSession::*)(  const char * const   ) ) static_cast<bool (IFSelect_WorkSession::*)(  const char * const   ) >(&IFSelect_WorkSession::RemoveName),
             R"#(Removes a Name without removing the Item Returns True if Done, False else (Name not recorded))#"  , py::arg("name")
          )
        .def("RemoveItem",
             (bool (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) ) static_cast<bool (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) >(&IFSelect_WorkSession::RemoveItem),
             R"#(Removes an Item given its Ident. Returns False if <id> is attached to no Item in the WorkSession. For a Named Item, also removes its Name.)#"  , py::arg("item")
          )
        .def("ClearItems",
             (void (IFSelect_WorkSession::*)() ) static_cast<void (IFSelect_WorkSession::*)() >(&IFSelect_WorkSession::ClearItems),
             R"#(Clears all the recorded Items : Selections, Dispatches, Modifiers, and Strings & IntParams, with their Idents & Names. Remark that if a Model has been loaded, it is not cleared.)#" 
          )
        .def("ItemLabel",
             (handle<TCollection_HAsciiString> (IFSelect_WorkSession::*)(  const int  ) const) static_cast<handle<TCollection_HAsciiString> (IFSelect_WorkSession::*)(  const int  ) const>(&IFSelect_WorkSession::ItemLabel),
             R"#(Returns a Label which illustrates the content of an Item, given its Ident. This Label is : - for a Text Parameter, "Text:<text value>" - for an Integer Parameter, "Integer:<integer value>" - for a Selection, a Dispatch or a Modifier, its Label (see these classes) - for any other kind of Variable, its cdl type)#"  , py::arg("id")
          )
        .def("ItemIdents",
             (handle<NCollection_HSequence<int>> (IFSelect_WorkSession::*)(  const handle<Standard_Type> &  ) const) static_cast<handle<NCollection_HSequence<int>> (IFSelect_WorkSession::*)(  const handle<Standard_Type> &  ) const>(&IFSelect_WorkSession::ItemIdents),
             R"#(Fills a Sequence with the List of Idents attached to the Items of which Type complies with (IsKind) <type> (alphabetic order) Remark : <type> = TYPE(Standard_Transient) gives all the Idents which are suitable in the WorkSession)#"  , py::arg("type")
          )
        .def("ItemNames",
             (handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> (IFSelect_WorkSession::*)(  const handle<Standard_Type> &  ) const) static_cast<handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> (IFSelect_WorkSession::*)(  const handle<Standard_Type> &  ) const>(&IFSelect_WorkSession::ItemNames),
             R"#(Fills a Sequence with the list of the Names attached to Items of which Type complies with (IsKind) <type> (alphabetic order) Remark : <type> = TYPE(Standard_Transient) gives all the Names)#"  , py::arg("type")
          )
        .def("ItemNamesForLabel",
             (handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> (IFSelect_WorkSession::*)(  const char * const   ) const) static_cast<handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> (IFSelect_WorkSession::*)(  const char * const   ) const>(&IFSelect_WorkSession::ItemNamesForLabel),
             R"#(Fills a Sequence with the NAMES of the control items, of which the label matches <label> (contain it) : see NextIdentForLabel Search mode is fixed to "contained" If <label> is empty, returns all Names)#"  , py::arg("label")
          )
        .def("NextIdentForLabel",
             (int (IFSelect_WorkSession::*)(  const char * const  ,   const int ,   const int  ) const) static_cast<int (IFSelect_WorkSession::*)(  const char * const  ,   const int ,   const int  ) const>(&IFSelect_WorkSession::NextIdentForLabel),
             R"#(For query by Label with possible iterations Searches the Ident of which Item has a Label which matches a given one, the search starts from an initial Ident. Returns the first found Ident which follows <id>, or ZERO)#"  , py::arg("label"),  py::arg("id"),  py::arg("mode")=static_cast< const int>(0)
          )
        .def("NewParamFromStatic",
             (handle<Standard_Transient> (IFSelect_WorkSession::*)(  const char * const  ,   const char * const   ) ) static_cast<handle<Standard_Transient> (IFSelect_WorkSession::*)(  const char * const  ,   const char * const   ) >(&IFSelect_WorkSession::NewParamFromStatic),
             R"#(Creates a parameter as being bound to a Static If the Static is Integer, this creates an IntParam bound to it by its name. Else this creates a String which is the value of the Static. Returns a null handle if <statname> is unknown as a Static)#"  , py::arg("statname"),  py::arg("name")=static_cast< const char * const >("")
          )
        .def("IntParam",
             (handle<IFSelect_IntParam> (IFSelect_WorkSession::*)(  const int  ) const) static_cast<handle<IFSelect_IntParam> (IFSelect_WorkSession::*)(  const int  ) const>(&IFSelect_WorkSession::IntParam),
             R"#(Returns an IntParam, given its Ident in the Session Null result if <id> is not suitable for an IntParam (undefined, or defined for another kind of variable))#"  , py::arg("id")
          )
        .def("IntValue",
             (int (IFSelect_WorkSession::*)(  const handle<IFSelect_IntParam> &  ) const) static_cast<int (IFSelect_WorkSession::*)(  const handle<IFSelect_IntParam> &  ) const>(&IFSelect_WorkSession::IntValue),
             R"#(Returns Integer Value of an IntParam)#"  , py::arg("it")
          )
        .def("NewIntParam",
             (handle<IFSelect_IntParam> (IFSelect_WorkSession::*)(  const char * const   ) ) static_cast<handle<IFSelect_IntParam> (IFSelect_WorkSession::*)(  const char * const   ) >(&IFSelect_WorkSession::NewIntParam),
             R"#(Creates a new IntParam. A Name can be set (Optional) Returns the created IntParam, or a Null Handle in case of Failure (see AddItem/AddNamedItem))#"  , py::arg("name")=static_cast< const char * const >("")
          )
        .def("SetIntValue",
             (bool (IFSelect_WorkSession::*)(  const handle<IFSelect_IntParam> & ,   const int  ) ) static_cast<bool (IFSelect_WorkSession::*)(  const handle<IFSelect_IntParam> & ,   const int  ) >(&IFSelect_WorkSession::SetIntValue),
             R"#(Changes the Integer Value of an IntParam Returns True if Done, False if <it> is not in the WorkSession)#"  , py::arg("it"),  py::arg("val")
          )
        .def("TextParam",
             (handle<TCollection_HAsciiString> (IFSelect_WorkSession::*)(  const int  ) const) static_cast<handle<TCollection_HAsciiString> (IFSelect_WorkSession::*)(  const int  ) const>(&IFSelect_WorkSession::TextParam),
             R"#(Returns a TextParam, given its Ident in the Session Null result if <id> is not suitable for a TextParam (undefined, or defined for another kind of variable))#"  , py::arg("id")
          )
        .def("TextValue",
             (TCollection_AsciiString (IFSelect_WorkSession::*)(  const handle<TCollection_HAsciiString> &  ) const) static_cast<TCollection_AsciiString (IFSelect_WorkSession::*)(  const handle<TCollection_HAsciiString> &  ) const>(&IFSelect_WorkSession::TextValue),
             R"#(Returns Text Value of a TextParam (a String) or an empty string if <it> is not in the WorkSession)#"  , py::arg("par")
          )
        .def("NewTextParam",
             (handle<TCollection_HAsciiString> (IFSelect_WorkSession::*)(  const char * const   ) ) static_cast<handle<TCollection_HAsciiString> (IFSelect_WorkSession::*)(  const char * const   ) >(&IFSelect_WorkSession::NewTextParam),
             R"#(Creates a new (empty) TextParam. A Name can be set (Optional) Returns the created TextParam (as an HAsciiString), or a Null Handle in case of Failure (see AddItem/AddNamedItem))#"  , py::arg("name")=static_cast< const char * const >("")
          )
        .def("SetTextValue",
             (bool (IFSelect_WorkSession::*)(  const handle<TCollection_HAsciiString> & ,   const char * const   ) ) static_cast<bool (IFSelect_WorkSession::*)(  const handle<TCollection_HAsciiString> & ,   const char * const   ) >(&IFSelect_WorkSession::SetTextValue),
             R"#(Changes the Text Value of a TextParam (an HAsciiString) Returns True if Done, False if <it> is not in the WorkSession)#"  , py::arg("par"),  py::arg("val")
          )
        .def("Signature",
             (handle<IFSelect_Signature> (IFSelect_WorkSession::*)(  const int  ) const) static_cast<handle<IFSelect_Signature> (IFSelect_WorkSession::*)(  const int  ) const>(&IFSelect_WorkSession::Signature),
             R"#(Returns a Signature, given its Ident in the Session Null result if <id> is not suitable for a Signature (undefined, or defined for another kind of variable))#"  , py::arg("id")
          )
        .def("SignValue",
             ( const char * (IFSelect_WorkSession::*)(  const handle<IFSelect_Signature> & ,   const handle<Standard_Transient> &  ) const) static_cast< const char * (IFSelect_WorkSession::*)(  const handle<IFSelect_Signature> & ,   const handle<Standard_Transient> &  ) const>(&IFSelect_WorkSession::SignValue),
             R"#(Returns the Value computed by a Signature for an Entity Returns an empty string if the entity does not belong to the loaded model)#"  , py::arg("sign"),  py::arg("ent")
          )
        .def("Selection",
             (handle<IFSelect_Selection> (IFSelect_WorkSession::*)(  const int  ) const) static_cast<handle<IFSelect_Selection> (IFSelect_WorkSession::*)(  const int  ) const>(&IFSelect_WorkSession::Selection),
             R"#(Returns a Selection, given its Ident in the Session Null result if <id> is not suitable for a Selection (undefined, or defined for another kind of variable))#"  , py::arg("id")
          )
        .def("Sources",
             (IFSelect_SelectionIterator (IFSelect_WorkSession::*)(  const handle<IFSelect_Selection> &  ) const) static_cast<IFSelect_SelectionIterator (IFSelect_WorkSession::*)(  const handle<IFSelect_Selection> &  ) const>(&IFSelect_WorkSession::Sources),
             R"#(Returns the Selections which are source of Selection, given its rank in the List of Selections (see SelectionIterator) Returned value is empty if <num> is out of range or if <sel> is not in the WorkSession)#"  , py::arg("sel")
          )
        .def("SelectionResult",
             (handle<NCollection_HSequence<handle<Standard_Transient>>> (IFSelect_WorkSession::*)(  const handle<IFSelect_Selection> &  ) const) static_cast<handle<NCollection_HSequence<handle<Standard_Transient>>> (IFSelect_WorkSession::*)(  const handle<IFSelect_Selection> &  ) const>(&IFSelect_WorkSession::SelectionResult),
             R"#(Returns the result of a Selection, computed by EvalSelection (see above) under the form of a HSequence (hence, it can be used by a frontal-engine logic). It can be empty Returns a Null Handle if <sel> is not in the WorkSession)#"  , py::arg("sel")
          )
        .def("SelectionResultFromList",
             (handle<NCollection_HSequence<handle<Standard_Transient>>> (IFSelect_WorkSession::*)(  const handle<IFSelect_Selection> & ,   const handle<NCollection_HSequence<handle<Standard_Transient>>> &  ) const) static_cast<handle<NCollection_HSequence<handle<Standard_Transient>>> (IFSelect_WorkSession::*)(  const handle<IFSelect_Selection> & ,   const handle<NCollection_HSequence<handle<Standard_Transient>>> &  ) const>(&IFSelect_WorkSession::SelectionResultFromList),
             R"#(Returns the result of a Selection, by forcing its input with a given list <list> (unless <list> is Null). RULES : <list> applies only for a SelectDeduct kind Selection : its Input is considered : if it is a SelectDeduct kind Selection, its Input is considered, etc... until an Input is not a Deduct/Extract : its result is replaced by <list> and all the chain of deductions is applied)#"  , py::arg("sel"),  py::arg("list")
          )
        .def("SetItemSelection",
             (bool (IFSelect_WorkSession::*)(  const handle<Standard_Transient> & ,   const handle<IFSelect_Selection> &  ) ) static_cast<bool (IFSelect_WorkSession::*)(  const handle<Standard_Transient> & ,   const handle<IFSelect_Selection> &  ) >(&IFSelect_WorkSession::SetItemSelection),
             R"#(Sets a Selection as input for an item, according its type : if <item> is a Dispatch : as Final Selection if <item> is a GeneralModifier (i.e. any kind of Modifier) : as Selection used to filter entities to modify <sel> Null causes this Selection to be nullified Returns False if <item> is not of a suitable type, or <item> or <sel> is not in the WorkSession)#"  , py::arg("item"),  py::arg("sel")
          )
        .def("ResetItemSelection",
             (bool (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) ) static_cast<bool (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) >(&IFSelect_WorkSession::ResetItemSelection),
             R"#(Resets input Selection which was set by SetItemSelection Same conditions as for SetItemSelection Returns True if done, False if <item> is not in the WorkSession)#"  , py::arg("item")
          )
        .def("ItemSelection",
             (handle<IFSelect_Selection> (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) const) static_cast<handle<IFSelect_Selection> (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) const>(&IFSelect_WorkSession::ItemSelection),
             R"#(Returns the Selection of a Dispatch or a GeneralModifier. Returns a Null Handle if none is defined or <item> not good type)#"  , py::arg("item")
          )
        .def("SignCounter",
             (handle<IFSelect_SignCounter> (IFSelect_WorkSession::*)(  const int  ) const) static_cast<handle<IFSelect_SignCounter> (IFSelect_WorkSession::*)(  const int  ) const>(&IFSelect_WorkSession::SignCounter),
             R"#(Returns a SignCounter from its ident in the Session Null result if <id> is not suitable for a SignCounter (undefined, or defined for another kind of variable))#"  , py::arg("id")
          )
        .def("ComputeCounter",
             (bool (IFSelect_WorkSession::*)(  const handle<IFSelect_SignCounter> & ,   const bool  ) ) static_cast<bool (IFSelect_WorkSession::*)(  const handle<IFSelect_SignCounter> & ,   const bool  ) >(&IFSelect_WorkSession::ComputeCounter),
             R"#(Computes the content of a SignCounter when it is defined with a Selection, then returns True Returns False if the SignCounter is not defined with a Selection, or if its Selection Mode is inhibited <forced> to work around optimisations)#"  , py::arg("counter"),  py::arg("forced")=static_cast< const bool>(false)
          )
        .def("ComputeCounterFromList",
             (bool (IFSelect_WorkSession::*)(  const handle<IFSelect_SignCounter> & ,   const handle<NCollection_HSequence<handle<Standard_Transient>>> & ,   const bool  ) ) static_cast<bool (IFSelect_WorkSession::*)(  const handle<IFSelect_SignCounter> & ,   const handle<NCollection_HSequence<handle<Standard_Transient>>> & ,   const bool  ) >(&IFSelect_WorkSession::ComputeCounterFromList),
             R"#(Computes the content of a SignCounter from an input list If <list> is Null, uses internal definition of the Counter : a Selection, else the whole Model (recomputation forced) If <clear> is True (D), starts from scratch Else, cumulates computations)#"  , py::arg("counter"),  py::arg("list"),  py::arg("clear")=static_cast< const bool>(true)
          )
        .def("AppliedDispatches",
             (handle<NCollection_HSequence<int>> (IFSelect_WorkSession::*)() const) static_cast<handle<NCollection_HSequence<int>> (IFSelect_WorkSession::*)() const>(&IFSelect_WorkSession::AppliedDispatches),
             R"#(Returns the ordered list of dispatches stored by the ShareOut)#" 
          )
        .def("ClearShareOut",
             (void (IFSelect_WorkSession::*)(  const bool  ) ) static_cast<void (IFSelect_WorkSession::*)(  const bool  ) >(&IFSelect_WorkSession::ClearShareOut),
             R"#(Clears the list of Dispatches recorded by the ShareOut if <only> disp is True, tha's all. Else, clears also the lists of Modifiers recorded by the ShareOut)#"  , py::arg("onlydisp")
          )
        .def("Dispatch",
             (handle<IFSelect_Dispatch> (IFSelect_WorkSession::*)(  const int  ) const) static_cast<handle<IFSelect_Dispatch> (IFSelect_WorkSession::*)(  const int  ) const>(&IFSelect_WorkSession::Dispatch),
             R"#(Returns a Dispatch, given its Ident in the Session Null result if <id> is not suitable for a Dispatch (undefined, or defined for another kind of variable))#"  , py::arg("id")
          )
        .def("DispatchRank",
             (int (IFSelect_WorkSession::*)(  const handle<IFSelect_Dispatch> &  ) const) static_cast<int (IFSelect_WorkSession::*)(  const handle<IFSelect_Dispatch> &  ) const>(&IFSelect_WorkSession::DispatchRank),
             R"#(Returns the rank of a Dispatch in the ShareOut, or 0 if <disp> is not in the ShareOut or not in the WorkSession)#"  , py::arg("disp")
          )
        .def("SetModelCopier",
             (void (IFSelect_WorkSession::*)(  const handle<IFSelect_ModelCopier> &  ) ) static_cast<void (IFSelect_WorkSession::*)(  const handle<IFSelect_ModelCopier> &  ) >(&IFSelect_WorkSession::SetModelCopier),
             R"#(Sets a new ModelCopier. Fills Items which its content)#"  , py::arg("copier")
          )
        .def("NbFinalModifiers",
             (int (IFSelect_WorkSession::*)(  const bool  ) const) static_cast<int (IFSelect_WorkSession::*)(  const bool  ) const>(&IFSelect_WorkSession::NbFinalModifiers),
             R"#(Returns the count of Modifiers applied to final sending Model Modifiers if <formodel> is True, File Modifiers else (i.e. Modifiers which apply once the Models have been filled))#"  , py::arg("formodel")
          )
        .def("FinalModifierIdents",
             (handle<NCollection_HSequence<int>> (IFSelect_WorkSession::*)(  const bool  ) const) static_cast<handle<NCollection_HSequence<int>> (IFSelect_WorkSession::*)(  const bool  ) const>(&IFSelect_WorkSession::FinalModifierIdents),
             R"#(Fills a Sequence with a list of Idents, those attached to the Modifiers applied to final sending. Model Modifiers if <formodel> is True, File Modifiers else This list is given in the order in which they will be applied (which takes into account the Changes to Modifier Ranks))#"  , py::arg("formodel")
          )
        .def("GeneralModifier",
             (handle<IFSelect_GeneralModifier> (IFSelect_WorkSession::*)(  const int  ) const) static_cast<handle<IFSelect_GeneralModifier> (IFSelect_WorkSession::*)(  const int  ) const>(&IFSelect_WorkSession::GeneralModifier),
             R"#(Returns a Modifier, given its Ident in the Session Null result if <id> is not suitable for a Modifier (undefined, or defined for another kind of variable))#"  , py::arg("id")
          )
        .def("ModelModifier",
             (handle<IFSelect_Modifier> (IFSelect_WorkSession::*)(  const int  ) const) static_cast<handle<IFSelect_Modifier> (IFSelect_WorkSession::*)(  const int  ) const>(&IFSelect_WorkSession::ModelModifier),
             R"#(Returns a Model Modifier, given its Ident in the Session, i.e. typed as a Modifier (not simply a GeneralModifier) Null result if <id> is not suitable for a Modifier (undefined, or defined for another kind of variable))#"  , py::arg("id")
          )
        .def("ModifierRank",
             (int (IFSelect_WorkSession::*)(  const handle<IFSelect_GeneralModifier> &  ) const) static_cast<int (IFSelect_WorkSession::*)(  const handle<IFSelect_GeneralModifier> &  ) const>(&IFSelect_WorkSession::ModifierRank),
             R"#(Returns the Rank of a Modifier given its Ident. Model or File Modifier according its type (ModelModifier or not) Remember that Modifiers are applied sequentially following their Rank : first Model Modifiers then File Modifiers Rank is given by rank of call to AddItem and can be changed by ChangeModifierRank)#"  , py::arg("item")
          )
        .def("ChangeModifierRank",
             (bool (IFSelect_WorkSession::*)(  const bool ,   const int ,   const int  ) ) static_cast<bool (IFSelect_WorkSession::*)(  const bool ,   const int ,   const int  ) >(&IFSelect_WorkSession::ChangeModifierRank),
             R"#(Changes the Rank of a Modifier in the Session : Model Modifiers if <formodel> is True, File Modifiers else the Modifier n0 <before> is put to n0 <after> Return True if Done, False if <before> or <after> out of range)#"  , py::arg("formodel"),  py::arg("before"),  py::arg("after")
          )
        .def("ClearFinalModifiers",
             (void (IFSelect_WorkSession::*)() ) static_cast<void (IFSelect_WorkSession::*)() >(&IFSelect_WorkSession::ClearFinalModifiers),
             R"#(Removes all the Modifiers active in the ModelCopier : they become inactive and they are removed from the Session)#" 
          )
        .def("SetAppliedModifier",
             (bool (IFSelect_WorkSession::*)(  const handle<IFSelect_GeneralModifier> & ,   const handle<Standard_Transient> &  ) ) static_cast<bool (IFSelect_WorkSession::*)(  const handle<IFSelect_GeneralModifier> & ,   const handle<Standard_Transient> &  ) >(&IFSelect_WorkSession::SetAppliedModifier),
             R"#(Sets a GeneralModifier to be applied to an item : - item = ShareOut : applies for final sending (all dispatches) - item is a Dispatch : applies for this dispatch only Returns True if done, False if <modif> or <item> not in <me>)#"  , py::arg("modif"),  py::arg("item")
          )
        .def("ResetAppliedModifier",
             (bool (IFSelect_WorkSession::*)(  const handle<IFSelect_GeneralModifier> &  ) ) static_cast<bool (IFSelect_WorkSession::*)(  const handle<IFSelect_GeneralModifier> &  ) >(&IFSelect_WorkSession::ResetAppliedModifier),
             R"#(Resets a GeneralModifier to be applied Returns True if done, False if <modif> was not applied)#"  , py::arg("modif")
          )
        .def("UsesAppliedModifier",
             (handle<Standard_Transient> (IFSelect_WorkSession::*)(  const handle<IFSelect_GeneralModifier> &  ) const) static_cast<handle<Standard_Transient> (IFSelect_WorkSession::*)(  const handle<IFSelect_GeneralModifier> &  ) const>(&IFSelect_WorkSession::UsesAppliedModifier),
             R"#(Returns the item on which a GeneralModifier is applied : the ShareOut, or a given Dispatch Returns a Null Handle if <modif> is not applied)#"  , py::arg("modif")
          )
        .def("Transformer",
             (handle<IFSelect_Transformer> (IFSelect_WorkSession::*)(  const int  ) const) static_cast<handle<IFSelect_Transformer> (IFSelect_WorkSession::*)(  const int  ) const>(&IFSelect_WorkSession::Transformer),
             R"#(Returns a Transformer, given its Ident in the Session Null result if <id> is not suitable for a Transformer (undefined, or defined for another kind of variable))#"  , py::arg("id")
          )
        .def("RunTransformer",
             (int (IFSelect_WorkSession::*)(  const handle<IFSelect_Transformer> &  ) ) static_cast<int (IFSelect_WorkSession::*)(  const handle<IFSelect_Transformer> &  ) >(&IFSelect_WorkSession::RunTransformer),
             R"#(Runs a Transformer on starting Model, which can then be edited or replaced by a new one. The Protocol can also be changed. Fills LastRunCheckList)#"  , py::arg("transf")
          )
        .def("RunModifier",
             (int (IFSelect_WorkSession::*)(  const handle<IFSelect_Modifier> & ,   const bool  ) ) static_cast<int (IFSelect_WorkSession::*)(  const handle<IFSelect_Modifier> & ,   const bool  ) >(&IFSelect_WorkSession::RunModifier),
             R"#(Runs a Modifier on Starting Model. It can modify entities, or add new ones. But the Model or the Protocol is unchanged. The Modifier is applied on each entity of the Model. See also RunModifierSelected Fills LastRunCheckList)#"  , py::arg("modif"),  py::arg("copy")
          )
        .def("RunModifierSelected",
             (int (IFSelect_WorkSession::*)(  const handle<IFSelect_Modifier> & ,   const handle<IFSelect_Selection> & ,   const bool  ) ) static_cast<int (IFSelect_WorkSession::*)(  const handle<IFSelect_Modifier> & ,   const handle<IFSelect_Selection> & ,   const bool  ) >(&IFSelect_WorkSession::RunModifierSelected),
             R"#(Acts as RunModifier, but the Modifier is applied on the list determined by a Selection, rather than on the whole Model If the selection is a null handle, the whole model is taken)#"  , py::arg("modif"),  py::arg("sel"),  py::arg("copy")
          )
        .def("NewTransformStandard",
             (handle<IFSelect_Transformer> (IFSelect_WorkSession::*)(  const bool ,   const char * const   ) ) static_cast<handle<IFSelect_Transformer> (IFSelect_WorkSession::*)(  const bool ,   const char * const   ) >(&IFSelect_WorkSession::NewTransformStandard),
             R"#(Creates and returns a TransformStandard, empty, with its Copy Option (True = Copy, False = On the Spot) and an optional name. To a TransformStandard, the method SetAppliedModifier applies)#"  , py::arg("copy"),  py::arg("name")=static_cast< const char * const >("")
          )
        .def("SetModelContent",
             (bool (IFSelect_WorkSession::*)(  const handle<IFSelect_Selection> & ,   const bool  ) ) static_cast<bool (IFSelect_WorkSession::*)(  const handle<IFSelect_Selection> & ,   const bool  ) >(&IFSelect_WorkSession::SetModelContent),
             R"#(Defines a new content from the former one If <keep> is True, it is given by entities selected by Selection <sel> (and all shared entities) Else, it is given by all the former content but entities selected by the Selection <sel> (and properly shared ones) Returns True if done. Returns False if the selected list (from <sel>) is empty, hence nothing is done)#"  , py::arg("sel"),  py::arg("keep")
          )
        .def("FilePrefix",
             (handle<TCollection_HAsciiString> (IFSelect_WorkSession::*)() const) static_cast<handle<TCollection_HAsciiString> (IFSelect_WorkSession::*)() const>(&IFSelect_WorkSession::FilePrefix),
             R"#(Returns the defined File Prefix. Null Handle if not defined)#" 
          )
        .def("DefaultFileRoot",
             (handle<TCollection_HAsciiString> (IFSelect_WorkSession::*)() const) static_cast<handle<TCollection_HAsciiString> (IFSelect_WorkSession::*)() const>(&IFSelect_WorkSession::DefaultFileRoot),
             R"#(Returns the defined Default File Root. It is used for Dispatches which have no specific root attached. Null Handle if not defined)#" 
          )
        .def("FileExtension",
             (handle<TCollection_HAsciiString> (IFSelect_WorkSession::*)() const) static_cast<handle<TCollection_HAsciiString> (IFSelect_WorkSession::*)() const>(&IFSelect_WorkSession::FileExtension),
             R"#(Returns the defined File Extension. Null Handle if not defined)#" 
          )
        .def("FileRoot",
             (handle<TCollection_HAsciiString> (IFSelect_WorkSession::*)(  const handle<IFSelect_Dispatch> &  ) const) static_cast<handle<TCollection_HAsciiString> (IFSelect_WorkSession::*)(  const handle<IFSelect_Dispatch> &  ) const>(&IFSelect_WorkSession::FileRoot),
             R"#(Returns the File Root defined for a Dispatch. Null if no Root Name is defined for it (hence, no File will be produced))#"  , py::arg("disp")
          )
        .def("SetFilePrefix",
             (void (IFSelect_WorkSession::*)(  const char * const   ) ) static_cast<void (IFSelect_WorkSession::*)(  const char * const   ) >(&IFSelect_WorkSession::SetFilePrefix),
             R"#(Defines a File Prefix)#"  , py::arg("name")
          )
        .def("SetDefaultFileRoot",
             (bool (IFSelect_WorkSession::*)(  const char * const   ) ) static_cast<bool (IFSelect_WorkSession::*)(  const char * const   ) >(&IFSelect_WorkSession::SetDefaultFileRoot),
             R"#(Defines a Default File Root Name. Clears it is <name> = "" Returns True if OK, False if <name> already set for a Dispatch)#"  , py::arg("name")
          )
        .def("SetFileExtension",
             (void (IFSelect_WorkSession::*)(  const char * const   ) ) static_cast<void (IFSelect_WorkSession::*)(  const char * const   ) >(&IFSelect_WorkSession::SetFileExtension),
             R"#(Defines a File Extension)#"  , py::arg("name")
          )
        .def("SetFileRoot",
             (bool (IFSelect_WorkSession::*)(  const handle<IFSelect_Dispatch> & ,   const char * const   ) ) static_cast<bool (IFSelect_WorkSession::*)(  const handle<IFSelect_Dispatch> & ,   const char * const   ) >(&IFSelect_WorkSession::SetFileRoot),
             R"#(Defines a Root for a Dispatch If <name> is empty, clears Root Name This has as effect to inhibit the production of File by <disp> Returns False if <disp> is not in the WorkSession or if a root name is already defined for it)#"  , py::arg("disp"),  py::arg("name")
          )
        .def("GiveFileRoot",
             ( const char * (IFSelect_WorkSession::*)(  const char * const   ) const) static_cast< const char * (IFSelect_WorkSession::*)(  const char * const   ) const>(&IFSelect_WorkSession::GiveFileRoot),
             R"#(Extracts File Root Name from a given complete file name (uses OSD_Path))#"  , py::arg("file")
          )
        .def("GiveFileComplete",
             ( const char * (IFSelect_WorkSession::*)(  const char * const   ) const) static_cast< const char * (IFSelect_WorkSession::*)(  const char * const   ) const>(&IFSelect_WorkSession::GiveFileComplete),
             R"#(Completes a file name as required, with Prefix and Extension (if defined; for a non-defined item, completes nothing))#"  , py::arg("file")
          )
        .def("ClearFile",
             (void (IFSelect_WorkSession::*)() ) static_cast<void (IFSelect_WorkSession::*)() >(&IFSelect_WorkSession::ClearFile),
             R"#(Erases all stored data from the File Evaluation (i.e. ALL former naming information are lost))#" 
          )
        .def("EvaluateFile",
             (void (IFSelect_WorkSession::*)() ) static_cast<void (IFSelect_WorkSession::*)() >(&IFSelect_WorkSession::EvaluateFile),
             R"#(Performs and stores a File Evaluation. The Results are a List of produced Models and a List of names (Strings), in parallel Fills LastRunCheckList)#" 
          )
        .def("NbFiles",
             (int (IFSelect_WorkSession::*)() const) static_cast<int (IFSelect_WorkSession::*)() const>(&IFSelect_WorkSession::NbFiles),
             R"#(Returns the count of produced Models)#" 
          )
        .def("FileName",
             (TCollection_AsciiString (IFSelect_WorkSession::*)(  const int  ) const) static_cast<TCollection_AsciiString (IFSelect_WorkSession::*)(  const int  ) const>(&IFSelect_WorkSession::FileName),
             R"#(Returns the name of a file corresponding to a produced Model, given its rank in the Evaluation List)#"  , py::arg("num")
          )
        .def("BeginSentFiles",
             (void (IFSelect_WorkSession::*)(  const bool  ) ) static_cast<void (IFSelect_WorkSession::*)(  const bool  ) >(&IFSelect_WorkSession::BeginSentFiles),
             R"#(Commands file sending to clear the list of already sent files, commands to record a new one if <record> is True This list is managed by the ModelCopier when SendSplit is called It allows a global exploitation of the set of sent files)#"  , py::arg("record")
          )
        .def("SentFiles",
             (handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> (IFSelect_WorkSession::*)() const) static_cast<handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> (IFSelect_WorkSession::*)() const>(&IFSelect_WorkSession::SentFiles),
             R"#(Returns the list of recorded sent files, or a Null Handle is recording has not been enabled)#" 
          )
        .def("SendSplit",
             (bool (IFSelect_WorkSession::*)() ) static_cast<bool (IFSelect_WorkSession::*)() >(&IFSelect_WorkSession::SendSplit),
             R"#(Performs creation of derived files from the input Model Takes its data (sub-models and names), from result EvaluateFile if active, else by dynamic Evaluation (not stored) After SendSplit, result of EvaluateFile is Cleared Fills LastRunCheckList)#" 
          )
        .def("EvalSplit",
             (handle<IFSelect_PacketList> (IFSelect_WorkSession::*)() const) static_cast<handle<IFSelect_PacketList> (IFSelect_WorkSession::*)() const>(&IFSelect_WorkSession::EvalSplit),
             R"#(Returns an Evaluation of the whole ShareOut definition : i.e. how the entities of the starting model are forecast to be sent to various files : list of packets according the dispatches, effective lists of roots for each packet (which determine the content of the corresponding file); plus evaluation of which entities are : forgotten (sent into no file), duplicated (sent into more than one file), sent into a given file. See the class PacketList for more details.)#" 
          )
        .def("MaxSendingCount",
             (int (IFSelect_WorkSession::*)() const) static_cast<int (IFSelect_WorkSession::*)() const>(&IFSelect_WorkSession::MaxSendingCount),
             R"#(Returns the greater count of different files in which any of the starting entities could be sent. Before any file output, this count is 0. Ideal count is 1. More than 1 means that duplications occur.)#" 
          )
        .def("SetRemaining",
             (bool (IFSelect_WorkSession::*)(  const IFSelect_RemainMode  ) ) static_cast<bool (IFSelect_WorkSession::*)(  const IFSelect_RemainMode  ) >(&IFSelect_WorkSession::SetRemaining),
             R"#(Processes Remaining data (after having sent files), mode : Forget : forget remaining info (i.e. clear all "Sent" status) Compute : compute and keep remaining (does nothing if : remaining is empty or if no files has been sent) Display : display entities recorded as remaining Undo : restore former state of data (after Remaining(1) ) Returns True if OK, False else (i.e. mode = 2 and Remaining List is either empty or takes all the entities, or mode = 3 and no former computation of remaining data was done))#"  , py::arg("mode")
          )
        .def("SendAll",
             (IFSelect_ReturnStatus (IFSelect_WorkSession::*)(  const char * const  ,   const bool  ) ) static_cast<IFSelect_ReturnStatus (IFSelect_WorkSession::*)(  const char * const  ,   const bool  ) >(&IFSelect_WorkSession::SendAll),
             R"#(Sends the starting Model into one file, without splitting, managing remaining data or anything else. <computegraph> true commands the Graph to be recomputed before sending : required when a Model is filled in several steps)#"  , py::arg("filename"),  py::arg("computegraph")=static_cast< const bool>(false)
          )
        .def("SendSelected",
             (IFSelect_ReturnStatus (IFSelect_WorkSession::*)(  const char * const  ,   const handle<IFSelect_Selection> & ,   const bool  ) ) static_cast<IFSelect_ReturnStatus (IFSelect_WorkSession::*)(  const char * const  ,   const handle<IFSelect_Selection> & ,   const bool  ) >(&IFSelect_WorkSession::SendSelected),
             R"#(Sends a part of the starting Model into one file, without splitting. But remaining data are managed. <computegraph> true commands the Graph to be recomputed before sending : required when a Model is filled in several steps)#"  , py::arg("filename"),  py::arg("sel"),  py::arg("computegraph")=static_cast< const bool>(false)
          )
        .def("WriteFile",
             (IFSelect_ReturnStatus (IFSelect_WorkSession::*)(  const char * const   ) ) static_cast<IFSelect_ReturnStatus (IFSelect_WorkSession::*)(  const char * const   ) >(&IFSelect_WorkSession::WriteFile),
             R"#(Writes the current Interface Model globally to a File, and returns a write status which can be : Done OK, Fail file could not be written, Error no norm is selected Remark : It is a simple, one-file writing, other operations are available (such as splitting ...) which calls SendAll)#"  , py::arg("filename")
          )
        .def("WriteFile",
             (IFSelect_ReturnStatus (IFSelect_WorkSession::*)(  const char * const  ,   const handle<IFSelect_Selection> &  ) ) static_cast<IFSelect_ReturnStatus (IFSelect_WorkSession::*)(  const char * const  ,   const handle<IFSelect_Selection> &  ) >(&IFSelect_WorkSession::WriteFile),
             R"#(Writes a sub-part of the current Interface Model to a File, as defined by a Selection <sel>, recomputes the Graph, and returns a write status which can be : Done OK, Fail file could not be written, Error no norm is selected Remark : It is a simple, one-file writing, other operations are available (such as splitting ...) which calls SendSelected)#"  , py::arg("filename"),  py::arg("sel")
          )
        .def("NbSources",
             (int (IFSelect_WorkSession::*)(  const handle<IFSelect_Selection> &  ) const) static_cast<int (IFSelect_WorkSession::*)(  const handle<IFSelect_Selection> &  ) const>(&IFSelect_WorkSession::NbSources),
             R"#(Returns the count of Input Selections known for a Selection, or 0 if <sel> not in the WorkSession. This count is one for a SelectDeduct / SelectExtract kind, two for SelectControl kind, variable for a SelectCombine (Union/Intersection), zero else)#"  , py::arg("sel")
          )
        .def("Source",
             (handle<IFSelect_Selection> (IFSelect_WorkSession::*)(  const handle<IFSelect_Selection> & ,   const int  ) const) static_cast<handle<IFSelect_Selection> (IFSelect_WorkSession::*)(  const handle<IFSelect_Selection> & ,   const int  ) const>(&IFSelect_WorkSession::Source),
             R"#(Returns the <num>th Input Selection of a Selection (see NbSources). Returns a Null Handle if <sel> is not in the WorkSession or if <num> is out of the range <1-NbSources> To obtain more details, see the method Sources)#"  , py::arg("sel"),  py::arg("num")=static_cast< const int>(1)
          )
        .def("IsReversedSelectExtract",
             (bool (IFSelect_WorkSession::*)(  const handle<IFSelect_Selection> &  ) const) static_cast<bool (IFSelect_WorkSession::*)(  const handle<IFSelect_Selection> &  ) const>(&IFSelect_WorkSession::IsReversedSelectExtract),
             R"#(Returns True if <sel> a Reversed SelectExtract, False else)#"  , py::arg("sel")
          )
        .def("ToggleSelectExtract",
             (bool (IFSelect_WorkSession::*)(  const handle<IFSelect_Selection> &  ) ) static_cast<bool (IFSelect_WorkSession::*)(  const handle<IFSelect_Selection> &  ) >(&IFSelect_WorkSession::ToggleSelectExtract),
             R"#(Toggles the Sense (Direct <-> Reversed) of a SelectExtract Returns True if Done, False if <sel> is not a SelectExtract or is not in the WorkSession)#"  , py::arg("sel")
          )
        .def("SetInputSelection",
             (bool (IFSelect_WorkSession::*)(  const handle<IFSelect_Selection> & ,   const handle<IFSelect_Selection> &  ) ) static_cast<bool (IFSelect_WorkSession::*)(  const handle<IFSelect_Selection> & ,   const handle<IFSelect_Selection> &  ) >(&IFSelect_WorkSession::SetInputSelection),
             R"#(Sets an Input Selection (as <input>) to a SelectExtract or a SelectDeduct (as <sel>). Returns True if Done, False if <sel> is neither a SelectExtract nor a SelectDeduct, or not in the WorkSession)#"  , py::arg("sel"),  py::arg("input")
          )
        .def("SetControl",
             (bool (IFSelect_WorkSession::*)(  const handle<IFSelect_Selection> & ,   const handle<IFSelect_Selection> & ,   const bool  ) ) static_cast<bool (IFSelect_WorkSession::*)(  const handle<IFSelect_Selection> & ,   const handle<IFSelect_Selection> & ,   const bool  ) >(&IFSelect_WorkSession::SetControl),
             R"#(Sets an Input Selection, Main if <formain> is True, Second else (as <sc>) to a SelectControl (as <sel>). Returns True if Done, False if <sel> is not a SelectControl, or <sc> or <sel> is not in the WorkSession)#"  , py::arg("sel"),  py::arg("sc"),  py::arg("formain")=static_cast< const bool>(true)
          )
        .def("CombineAdd",
             (int (IFSelect_WorkSession::*)(  const handle<IFSelect_Selection> & ,   const handle<IFSelect_Selection> & ,   const int  ) ) static_cast<int (IFSelect_WorkSession::*)(  const handle<IFSelect_Selection> & ,   const handle<IFSelect_Selection> & ,   const int  ) >(&IFSelect_WorkSession::CombineAdd),
             R"#(Adds an input selection to a SelectCombine (Union or Inters.). Returns new count of inputs for this SelectCombine if Done or 0 if <sel> is not kind of SelectCombine, or if <seladd> or <sel> is not in the WorkSession By default, adding is done at the end of the list Else, it is an insertion to rank <atnum> (useful for Un-ReDo))#"  , py::arg("selcomb"),  py::arg("seladd"),  py::arg("atnum")=static_cast< const int>(0)
          )
        .def("CombineRemove",
             (bool (IFSelect_WorkSession::*)(  const handle<IFSelect_Selection> & ,   const handle<IFSelect_Selection> &  ) ) static_cast<bool (IFSelect_WorkSession::*)(  const handle<IFSelect_Selection> & ,   const handle<IFSelect_Selection> &  ) >(&IFSelect_WorkSession::CombineRemove),
             R"#(Removes an input selection from a SelectCombine (Union or Intersection). Returns True if done, False if <selcomb> is not kind of SelectCombine or <selrem> is not source of <selcomb>)#"  , py::arg("selcomb"),  py::arg("selrem")
          )
        .def("NewSelectPointed",
             (handle<IFSelect_Selection> (IFSelect_WorkSession::*)(  const handle<NCollection_HSequence<handle<Standard_Transient>>> & ,   const char * const   ) ) static_cast<handle<IFSelect_Selection> (IFSelect_WorkSession::*)(  const handle<NCollection_HSequence<handle<Standard_Transient>>> & ,   const char * const   ) >(&IFSelect_WorkSession::NewSelectPointed),
             R"#(Creates a new Selection, of type SelectPointed, its content starts with <list>. A name must be given (can be empty))#"  , py::arg("list"),  py::arg("name")
          )
        .def("SetSelectPointed",
             (bool (IFSelect_WorkSession::*)(  const handle<IFSelect_Selection> & ,   const handle<NCollection_HSequence<handle<Standard_Transient>>> & ,   const int  ) const) static_cast<bool (IFSelect_WorkSession::*)(  const handle<IFSelect_Selection> & ,   const handle<NCollection_HSequence<handle<Standard_Transient>>> & ,   const int  ) const>(&IFSelect_WorkSession::SetSelectPointed),
             R"#(Changes the content of a Selection of type SelectPointed According <mode> : 0 set <list> as new content (clear former) 1 : adds <list> to actual content -1 : removes <list> from actual content Returns True if done, False if <sel> is not a SelectPointed)#"  , py::arg("sel"),  py::arg("list"),  py::arg("mode")
          )
        .def("GiveSelection",
             (handle<IFSelect_Selection> (IFSelect_WorkSession::*)(  const char * const   ) const) static_cast<handle<IFSelect_Selection> (IFSelect_WorkSession::*)(  const char * const   ) const>(&IFSelect_WorkSession::GiveSelection),
             R"#(Returns a Selection from a Name : - the name of a Selection : this Selection - the name of a Signature + criteria between (..) : a new Selection from this Signature - an entity or a list of entities : a new SelectPointed Else, returns a Null Handle)#"  , py::arg("selname")
          )
        .def("GiveList",
             (handle<NCollection_HSequence<handle<Standard_Transient>>> (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) const) static_cast<handle<NCollection_HSequence<handle<Standard_Transient>>> (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) const>(&IFSelect_WorkSession::GiveList),
             R"#(Determines a list of entities from an object : <obj> already HSequenceOfTransient : returned itself <obj> Selection : its Result of Evaluation is returned <obj> an entity of the Model : a HSequence which contains it else, an empty HSequence <obj> the Model it self : ALL its content (not only the roots))#"  , py::arg("obj")
          )
        .def("GiveList",
             (handle<NCollection_HSequence<handle<Standard_Transient>>> (IFSelect_WorkSession::*)(  const char * const  ,   const char * const   ) const) static_cast<handle<NCollection_HSequence<handle<Standard_Transient>>> (IFSelect_WorkSession::*)(  const char * const  ,   const char * const   ) const>(&IFSelect_WorkSession::GiveList),
             R"#(Computes a List of entities from two alphanums, first and second, as follows : if <first> is a Number or Label of an entity : this entity if <first> is a list of Numbers/Labels : the list of entities if <first> is the name of a Selection in <WS>, and <second> not defined, the standard result of this Selection else, let's consider "first second" : this whole phrase is split by blanks, as follows (RECURSIVE CALL) : - the leftest term is the final selection - the other terms define the result of the selection - and so on (the "leftest minus one" is a selection, of which the input is given by the remaining ...))#"  , py::arg("first"),  py::arg("second")=static_cast< const char * const >("")
          )
        .def("GiveListFromList",
             (handle<NCollection_HSequence<handle<Standard_Transient>>> (IFSelect_WorkSession::*)(  const char * const  ,   const handle<Standard_Transient> &  ) const) static_cast<handle<NCollection_HSequence<handle<Standard_Transient>>> (IFSelect_WorkSession::*)(  const char * const  ,   const handle<Standard_Transient> &  ) const>(&IFSelect_WorkSession::GiveListFromList),
             R"#(Computes a List of entities from the model as follows <first> being a Selection or a combination of Selections, <ent> being an entity or a list of entities (as a HSequenceOfTransient) : the standard result of this selection applied to this list if <ent> is Null, the standard definition of the selection is used (which contains a default input selection) if <selname> is erroneous, a null handle is returned)#"  , py::arg("selname"),  py::arg("ent")
          )
        .def("GiveListCombined",
             (handle<NCollection_HSequence<handle<Standard_Transient>>> (IFSelect_WorkSession::*)(  const handle<NCollection_HSequence<handle<Standard_Transient>>> & ,   const handle<NCollection_HSequence<handle<Standard_Transient>>> & ,   const int  ) const) static_cast<handle<NCollection_HSequence<handle<Standard_Transient>>> (IFSelect_WorkSession::*)(  const handle<NCollection_HSequence<handle<Standard_Transient>>> & ,   const handle<NCollection_HSequence<handle<Standard_Transient>>> & ,   const int  ) const>(&IFSelect_WorkSession::GiveListCombined),
             R"#(Combines two lists and returns the result, according to mode : <mode> < 0 : entities in <l1> AND NOT in <l2> <mode> = 0 : entities in <l1> AND in <l2> <mode> > 0 : entities in <l1> OR in <l2>)#"  , py::arg("l1"),  py::arg("l2"),  py::arg("mode")
          )
        .def("QueryCheckStatus",
             (int (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) const) static_cast<int (IFSelect_WorkSession::*)(  const handle<Standard_Transient> &  ) const>(&IFSelect_WorkSession::QueryCheckStatus),
             R"#(Determines check status for an entity regarding last call to QueryCheckList : -1 : <ent> unknown in the model, ignored 0 : no check at all, immediate or inherited thru Graph 1 : immediate warning (no fail), no inherited check 2 : immediate fail, no inherited check +10 : idem but some inherited warning (no fail) +20 : idem but some inherited fail)#"  , py::arg("ent")
          )
        .def("QueryParent",
             (int (IFSelect_WorkSession::*)(  const handle<Standard_Transient> & ,   const handle<Standard_Transient> &  ) const) static_cast<int (IFSelect_WorkSession::*)(  const handle<Standard_Transient> & ,   const handle<Standard_Transient> &  ) const>(&IFSelect_WorkSession::QueryParent),
             R"#(Determines if <entdad> is parent of <entson> (in the graph), returns : -1 if no; 0 if <entdad> = <entson> 1 if immediate parent, > 1 if parent, gives count of steps)#"  , py::arg("entdad"),  py::arg("entson")
          )
        .def("SetParams",
             (void (IFSelect_WorkSession::*)(  const NCollection_DynamicArray<handle<Standard_Transient>> & ,   const NCollection_DynamicArray<int> &  ) ) static_cast<void (IFSelect_WorkSession::*)(  const NCollection_DynamicArray<handle<Standard_Transient>> & ,   const NCollection_DynamicArray<int> &  ) >(&IFSelect_WorkSession::SetParams),
             R"#(Sets a list of Parameters, i.e. TypedValue, to be handled through an Editor The two lists are parallel, if <params> is longer than <uses>, surnumeral parameters are for general use)#"  , py::arg("params"),  py::arg("uselist")
          )
        .def("TraceStatics",
             (void (IFSelect_WorkSession::*)(  const int ,   const int  ) const) static_cast<void (IFSelect_WorkSession::*)(  const int ,   const int  ) const>(&IFSelect_WorkSession::TraceStatics),
             R"#(Traces the Statics attached to a given use number If <use> is given positive (normal), the trace is embedded with a header and a trailer If <use> is negative, just values are printed (this allows to make compositions) Remark : use number 5 commands use -2 to be traced Remark : use numbers 4 and 6 command use -3 to be traced)#"  , py::arg("use"),  py::arg("mode")=static_cast< const int>(0)
          )
        .def("DumpShare",
             (void (IFSelect_WorkSession::*)() const) static_cast<void (IFSelect_WorkSession::*)() const>(&IFSelect_WorkSession::DumpShare),
             R"#(Dumps contents of the ShareOut (on "cout"))#" 
          )
        .def("ListItems",
             (void (IFSelect_WorkSession::*)(  const char * const   ) const) static_cast<void (IFSelect_WorkSession::*)(  const char * const   ) const>(&IFSelect_WorkSession::ListItems),
             R"#(Lists the Labels of all Items of the WorkSession If <label> is defined, lists labels which contain it)#"  , py::arg("label")=static_cast< const char * const >("")
          )
        .def("ListFinalModifiers",
             (void (IFSelect_WorkSession::*)(  const bool  ) const) static_cast<void (IFSelect_WorkSession::*)(  const bool  ) const>(&IFSelect_WorkSession::ListFinalModifiers),
             R"#(Lists the Modifiers of the session (for each one, displays its Label). Listing is done following Ranks (Modifiers are invoked following their ranks) Model Modifiers if <formodel> is True, File Modifiers else)#"  , py::arg("formodel")
          )
        .def("DumpSelection",
             (void (IFSelect_WorkSession::*)(  const handle<IFSelect_Selection> &  ) const) static_cast<void (IFSelect_WorkSession::*)(  const handle<IFSelect_Selection> &  ) const>(&IFSelect_WorkSession::DumpSelection),
             R"#(Lists a Selection and its Sources (see SelectionIterator), given its rank in the list)#"  , py::arg("sel")
          )
        .def("DumpModel",
             (void (IFSelect_WorkSession::*)(  const int ,  Standard_OStream &  ) ) static_cast<void (IFSelect_WorkSession::*)(  const int ,  Standard_OStream &  ) >(&IFSelect_WorkSession::DumpModel),
             R"#(Lists the content of the Input Model (if there is one) According level : 0 -> gives only count of Entities and Roots 1 -> Lists also Roots; 2 -> Lists all Entities (by TraceType) 3 -> Performs a call to CheckList (Fails) and lists the result 4 -> as 3 but all CheckList (Fails + Warnings) 5,6,7 : as 3 but resp. Count,List,Labels by Fail 8,9,10 : as 4 but resp. Count,List,Labels by message)#"  , py::arg("level"),  py::arg("S")
          )
        .def("TraceDumpModel",
             (void (IFSelect_WorkSession::*)(  const int  ) ) static_cast<void (IFSelect_WorkSession::*)(  const int  ) >(&IFSelect_WorkSession::TraceDumpModel),
             R"#(Dumps the current Model (as inherited DumpModel), on currently defined Default Trace File (default is standard output))#"  , py::arg("mode")
          )
        .def("DumpEntity",
             (void (IFSelect_WorkSession::*)(  const handle<Standard_Transient> & ,   const int ,  Standard_OStream &  ) const) static_cast<void (IFSelect_WorkSession::*)(  const handle<Standard_Transient> & ,   const int ,  Standard_OStream &  ) const>(&IFSelect_WorkSession::DumpEntity),
             R"#(Dumps a starting entity according to the current norm. To do this, it calls DumpEntity from WorkLibrary. <level> is to be interpreted for each norm : see specific classes of WorkLibrary for it. Generally, 0 if for very basic (only type ...), greater values give more and more details.)#"  , py::arg("ent"),  py::arg("level"),  py::arg("S")
          )
        .def("PrintEntityStatus",
             (void (IFSelect_WorkSession::*)(  const handle<Standard_Transient> & ,  Standard_OStream &  ) ) static_cast<void (IFSelect_WorkSession::*)(  const handle<Standard_Transient> & ,  Standard_OStream &  ) >(&IFSelect_WorkSession::PrintEntityStatus),
             R"#(Prints main information about an entity : its number, type, validity (and checks if any), category, shareds and sharings.. mutable because it can recompute checks as necessary)#"  , py::arg("ent"),  py::arg("S")
          )
        .def("TraceDumpEntity",
             (void (IFSelect_WorkSession::*)(  const handle<Standard_Transient> & ,   const int  ) const) static_cast<void (IFSelect_WorkSession::*)(  const handle<Standard_Transient> & ,   const int  ) const>(&IFSelect_WorkSession::TraceDumpEntity),
             R"#(Dumps an entity from the current Model as inherited DumpEntity on currently defined Default Trace File (<level> interpreted according to the Norm, see WorkLibrary))#"  , py::arg("ent"),  py::arg("level")
          )
        .def("PrintSignatureList",
             (void (IFSelect_WorkSession::*)( Standard_OStream & ,   const handle<IFSelect_SignatureList> & ,   const IFSelect_PrintCount  ) const) static_cast<void (IFSelect_WorkSession::*)( Standard_OStream & ,   const handle<IFSelect_SignatureList> & ,   const IFSelect_PrintCount  ) const>(&IFSelect_WorkSession::PrintSignatureList),
             R"#(Prints a SignatureList to the current Trace File, controlled with the current Model <mode> defines the mode of printing (see SignatureList))#"  , py::arg("S"),  py::arg("signlist"),  py::arg("mode")
          )
        .def("EvaluateSelection",
             (void (IFSelect_WorkSession::*)(  const handle<IFSelect_Selection> &  ) const) static_cast<void (IFSelect_WorkSession::*)(  const handle<IFSelect_Selection> &  ) const>(&IFSelect_WorkSession::EvaluateSelection),
             R"#(Displays the list of Entities selected by a Selection (i.e. the result of EvalSelection).)#"  , py::arg("sel")
          )
        .def("EvaluateDispatch",
             (void (IFSelect_WorkSession::*)(  const handle<IFSelect_Dispatch> & ,   const int  ) const) static_cast<void (IFSelect_WorkSession::*)(  const handle<IFSelect_Dispatch> & ,   const int  ) const>(&IFSelect_WorkSession::EvaluateDispatch),
             R"#(Displays the result of applying a Dispatch on the input Model (also shows Remainder if there is) <mode> = 0 (default), displays nothing else <mode> = 1 : displays also duplicated entities (because of this dispatch) <mode> = 2 : displays the entities of the starting Model which are not taken by this dispatch (forgotten entities) <mode> = 3 : displays both duplicated and forgotten entities Remark : EvaluateComplete displays these data evaluated for for all the dispatches, if there are several)#"  , py::arg("disp"),  py::arg("mode")=static_cast< const int>(0)
          )
        .def("EvaluateComplete",
             (void (IFSelect_WorkSession::*)(  const int  ) const) static_cast<void (IFSelect_WorkSession::*)(  const int  ) const>(&IFSelect_WorkSession::EvaluateComplete),
             R"#(Displays the effect of applying the ShareOut on the input Model. <mode> = 0 (default) : displays only roots for each packet, <mode> = 1 : displays all entities for each packet, plus duplicated entities <mode> = 2 : same as <mode> = 1, plus displays forgotten entities (which are in no packet at all))#"  , py::arg("mode")=static_cast< const int>(0)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_WorkSession::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_WorkSession::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("ShareOut",
             ( const handle<IFSelect_ShareOut> & (IFSelect_WorkSession::*)() const) static_cast< const handle<IFSelect_ShareOut> & (IFSelect_WorkSession::*)() const>(&IFSelect_WorkSession::ShareOut),
             R"#(Returns the ShareOut defined at creation time)#"
             
         )
       .def("WorkLibrary",
             ( const handle<IFSelect_WorkLibrary> & (IFSelect_WorkSession::*)() const) static_cast< const handle<IFSelect_WorkLibrary> & (IFSelect_WorkSession::*)() const>(&IFSelect_WorkSession::WorkLibrary),
             R"#(Returns the WorkLibrary. Null Handle if not yet set should be C++ : return const &)#"
             
         )
       .def("ModelCopier",
             ( const handle<IFSelect_ModelCopier> & (IFSelect_WorkSession::*)() const) static_cast< const handle<IFSelect_ModelCopier> & (IFSelect_WorkSession::*)() const>(&IFSelect_WorkSession::ModelCopier),
             R"#(Gives access to the complete ModelCopier)#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_WorkSession::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_WorkSession::*)() const>(&IFSelect_WorkSession::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_Act from ./opencascade/IFSelect_Act.hxx
    klass = m.attr("IFSelect_Act");


    // nested enums

    static_cast<py::class_<IFSelect_Act ,opencascade::handle<IFSelect_Act>  , IFSelect_Activator >>(klass)
    // constructors
        .def(py::init<  const char * const , const char * const , const IFSelect_ActFunc >()  , py::arg("name"),  py::arg("help"),  py::arg("func") )
    // custom constructors
    // methods
        .def("Do",
             (IFSelect_ReturnStatus (IFSelect_Act::*)(  const int ,   const handle<IFSelect_SessionPilot> &  ) ) static_cast<IFSelect_ReturnStatus (IFSelect_Act::*)(  const int ,   const handle<IFSelect_SessionPilot> &  ) >(&IFSelect_Act::Do),
             R"#(Execution of Command Line. remark that <number> is senseless because each Act brings one and only one function)#"  , py::arg("number"),  py::arg("pilot")
          )
        .def("Help",
             ( const char * (IFSelect_Act::*)(  const int  ) const) static_cast< const char * (IFSelect_Act::*)(  const int  ) const>(&IFSelect_Act::Help),
             R"#(Short Help for commands : returns the help given to create)#"  , py::arg("number")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("SetGroup_s",
                    (void (*)(  const char * const  ,   const char * const   ) ) static_cast<void (*)(  const char * const  ,   const char * const   ) >(&IFSelect_Act::SetGroup),
                    R"#(Changes the default group name for the following Acts group empty means to come back to default from Activator Also a file name can be precised (to query by getsource))#"  , py::arg("group"),  py::arg("file")=static_cast< const char * const >("")
          )
        .def_static("AddFunc_s",
                    (void (*)(  const char * const  ,   const char * const  ,   const IFSelect_ActFunc  ) ) static_cast<void (*)(  const char * const  ,   const char * const  ,   const IFSelect_ActFunc  ) >(&IFSelect_Act::AddFunc),
                    R"#(Adds a function with its name and help : creates an Act then records it as normal function)#"  , py::arg("name"),  py::arg("help"),  py::arg("func")
          )
        .def_static("AddFSet_s",
                    (void (*)(  const char * const  ,   const char * const  ,   const IFSelect_ActFunc  ) ) static_cast<void (*)(  const char * const  ,   const char * const  ,   const IFSelect_ActFunc  ) >(&IFSelect_Act::AddFSet),
                    R"#(Adds a function with its name and help : creates an Act then records it as function for XSET (i.e. to create control item))#"  , py::arg("name"),  py::arg("help"),  py::arg("func")
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_Act::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_Act::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_Act::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_Act::*)() const>(&IFSelect_Act::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_BasicDumper from ./opencascade/IFSelect_BasicDumper.hxx
    klass = m.attr("IFSelect_BasicDumper");


    // nested enums

    static_cast<py::class_<IFSelect_BasicDumper ,opencascade::handle<IFSelect_BasicDumper>  , IFSelect_SessionDumper >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("WriteOwn",
             (bool (IFSelect_BasicDumper::*)( IFSelect_SessionFile & ,   const handle<Standard_Transient> &  ) const) static_cast<bool (IFSelect_BasicDumper::*)( IFSelect_SessionFile & ,   const handle<Standard_Transient> &  ) const>(&IFSelect_BasicDumper::WriteOwn),
             R"#(Write the Own Parameters of Types defined in package IFSelect Returns True if <item> has been processed, False else)#"  , py::arg("file"),  py::arg("item")
          )
        .def("ReadOwn",
             (bool (IFSelect_BasicDumper::*)( IFSelect_SessionFile & ,   const TCollection_AsciiString & ,  handle<Standard_Transient> &  ) const) static_cast<bool (IFSelect_BasicDumper::*)( IFSelect_SessionFile & ,   const TCollection_AsciiString & ,  handle<Standard_Transient> &  ) const>(&IFSelect_BasicDumper::ReadOwn),
             R"#(Recognizes and Read Own Parameters for Types of package IFSelect. Returns True if done and <item> created, False else)#"  , py::arg("file"),  py::arg("type"),  py::arg("item")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_BasicDumper::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_BasicDumper::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_BasicDumper::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_BasicDumper::*)() const>(&IFSelect_BasicDumper::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_CheckCounter from ./opencascade/IFSelect_CheckCounter.hxx
    klass = m.attr("IFSelect_CheckCounter");


    // nested enums

    static_cast<py::class_<IFSelect_CheckCounter ,opencascade::handle<IFSelect_CheckCounter>  , IFSelect_SignatureList >>(klass)
    // constructors
        .def(py::init<  const bool >()  , py::arg("withlist")=static_cast< const bool>(false) )
    // custom constructors
    // methods
        .def("SetSignature",
             (void (IFSelect_CheckCounter::*)(  const handle<MoniTool_SignText> &  ) ) static_cast<void (IFSelect_CheckCounter::*)(  const handle<MoniTool_SignText> &  ) >(&IFSelect_CheckCounter::SetSignature),
             R"#(Sets a specific signature Else, the current SignType (in the model) is used)#"  , py::arg("sign")
          )
        .def("Signature",
             (handle<MoniTool_SignText> (IFSelect_CheckCounter::*)() const) static_cast<handle<MoniTool_SignText> (IFSelect_CheckCounter::*)() const>(&IFSelect_CheckCounter::Signature),
             R"#(Returns the Signature;)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_CheckCounter::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_CheckCounter::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_CheckCounter::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_CheckCounter::*)() const>(&IFSelect_CheckCounter::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_DispGlobal from ./opencascade/IFSelect_DispGlobal.hxx
    klass = m.attr("IFSelect_DispGlobal");


    // nested enums

    static_cast<py::class_<IFSelect_DispGlobal ,opencascade::handle<IFSelect_DispGlobal>  , IFSelect_Dispatch >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Label",
             (TCollection_AsciiString (IFSelect_DispGlobal::*)() const) static_cast<TCollection_AsciiString (IFSelect_DispGlobal::*)() const>(&IFSelect_DispGlobal::Label),
             R"#(Returns as Label, "One File for all Input")#" 
          )
        .def("LimitedMax",
             (bool (IFSelect_DispGlobal::*)(  const int ,  int &  ) const) static_cast<bool (IFSelect_DispGlobal::*)(  const int ,  int &  ) const>(&IFSelect_DispGlobal::LimitedMax),
             R"#(Returns True : maximum equates 1)#"  , py::arg("nbent"),  py::arg("max")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_DispGlobal::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_DispGlobal::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_DispGlobal::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_DispGlobal::*)() const>(&IFSelect_DispGlobal::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_DispPerCount from ./opencascade/IFSelect_DispPerCount.hxx
    klass = m.attr("IFSelect_DispPerCount");


    // nested enums

    static_cast<py::class_<IFSelect_DispPerCount ,opencascade::handle<IFSelect_DispPerCount>  , IFSelect_Dispatch >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Count",
             (handle<IFSelect_IntParam> (IFSelect_DispPerCount::*)() const) static_cast<handle<IFSelect_IntParam> (IFSelect_DispPerCount::*)() const>(&IFSelect_DispPerCount::Count),
             R"#(Returns the Count Parameter used for splitting)#" 
          )
        .def("SetCount",
             (void (IFSelect_DispPerCount::*)(  const handle<IFSelect_IntParam> &  ) ) static_cast<void (IFSelect_DispPerCount::*)(  const handle<IFSelect_IntParam> &  ) >(&IFSelect_DispPerCount::SetCount),
             R"#(Sets a new Parameter for Count)#"  , py::arg("count")
          )
        .def("CountValue",
             (int (IFSelect_DispPerCount::*)() const) static_cast<int (IFSelect_DispPerCount::*)() const>(&IFSelect_DispPerCount::CountValue),
             R"#(Returns the effective value of the count parameter (if Count Parameter not Set or value not positive, returns 1))#" 
          )
        .def("Label",
             (TCollection_AsciiString (IFSelect_DispPerCount::*)() const) static_cast<TCollection_AsciiString (IFSelect_DispPerCount::*)() const>(&IFSelect_DispPerCount::Label),
             R"#(Returns as Label, "One File per <count> Input Entities")#" 
          )
        .def("LimitedMax",
             (bool (IFSelect_DispPerCount::*)(  const int ,  int &  ) const) static_cast<bool (IFSelect_DispPerCount::*)(  const int ,  int &  ) const>(&IFSelect_DispPerCount::LimitedMax),
             R"#(Returns True, maximum count is given as <nbent>)#"  , py::arg("nbent"),  py::arg("max")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_DispPerCount::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_DispPerCount::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_DispPerCount::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_DispPerCount::*)() const>(&IFSelect_DispPerCount::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_DispPerFiles from ./opencascade/IFSelect_DispPerFiles.hxx
    klass = m.attr("IFSelect_DispPerFiles");


    // nested enums

    static_cast<py::class_<IFSelect_DispPerFiles ,opencascade::handle<IFSelect_DispPerFiles>  , IFSelect_Dispatch >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Count",
             (handle<IFSelect_IntParam> (IFSelect_DispPerFiles::*)() const) static_cast<handle<IFSelect_IntParam> (IFSelect_DispPerFiles::*)() const>(&IFSelect_DispPerFiles::Count),
             R"#(Returns the Count Parameter used for splitting)#" 
          )
        .def("SetCount",
             (void (IFSelect_DispPerFiles::*)(  const handle<IFSelect_IntParam> &  ) ) static_cast<void (IFSelect_DispPerFiles::*)(  const handle<IFSelect_IntParam> &  ) >(&IFSelect_DispPerFiles::SetCount),
             R"#(Sets a new Parameter for Count)#"  , py::arg("count")
          )
        .def("CountValue",
             (int (IFSelect_DispPerFiles::*)() const) static_cast<int (IFSelect_DispPerFiles::*)() const>(&IFSelect_DispPerFiles::CountValue),
             R"#(Returns the effective value of the count parameter (if Count Parameter not Set or value not positive, returns 1))#" 
          )
        .def("Label",
             (TCollection_AsciiString (IFSelect_DispPerFiles::*)() const) static_cast<TCollection_AsciiString (IFSelect_DispPerFiles::*)() const>(&IFSelect_DispPerFiles::Label),
             R"#(Returns as Label, "Maximum <count> Files")#" 
          )
        .def("LimitedMax",
             (bool (IFSelect_DispPerFiles::*)(  const int ,  int &  ) const) static_cast<bool (IFSelect_DispPerFiles::*)(  const int ,  int &  ) const>(&IFSelect_DispPerFiles::LimitedMax),
             R"#(Returns True, maximum count is given as CountValue)#"  , py::arg("nbent"),  py::arg("max")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_DispPerFiles::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_DispPerFiles::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_DispPerFiles::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_DispPerFiles::*)() const>(&IFSelect_DispPerFiles::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_DispPerOne from ./opencascade/IFSelect_DispPerOne.hxx
    klass = m.attr("IFSelect_DispPerOne");


    // nested enums

    static_cast<py::class_<IFSelect_DispPerOne ,opencascade::handle<IFSelect_DispPerOne>  , IFSelect_Dispatch >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Label",
             (TCollection_AsciiString (IFSelect_DispPerOne::*)() const) static_cast<TCollection_AsciiString (IFSelect_DispPerOne::*)() const>(&IFSelect_DispPerOne::Label),
             R"#(Returns as Label, "One File per Input Entity")#" 
          )
        .def("LimitedMax",
             (bool (IFSelect_DispPerOne::*)(  const int ,  int &  ) const) static_cast<bool (IFSelect_DispPerOne::*)(  const int ,  int &  ) const>(&IFSelect_DispPerOne::LimitedMax),
             R"#(Returns True, maximum limit is given as <nbent>)#"  , py::arg("nbent"),  py::arg("max")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_DispPerOne::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_DispPerOne::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_DispPerOne::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_DispPerOne::*)() const>(&IFSelect_DispPerOne::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_DispPerSignature from ./opencascade/IFSelect_DispPerSignature.hxx
    klass = m.attr("IFSelect_DispPerSignature");


    // nested enums

    static_cast<py::class_<IFSelect_DispPerSignature ,opencascade::handle<IFSelect_DispPerSignature>  , IFSelect_Dispatch >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SignCounter",
             (handle<IFSelect_SignCounter> (IFSelect_DispPerSignature::*)() const) static_cast<handle<IFSelect_SignCounter> (IFSelect_DispPerSignature::*)() const>(&IFSelect_DispPerSignature::SignCounter),
             R"#(Returns the SignCounter used for splitting)#" 
          )
        .def("SetSignCounter",
             (void (IFSelect_DispPerSignature::*)(  const handle<IFSelect_SignCounter> &  ) ) static_cast<void (IFSelect_DispPerSignature::*)(  const handle<IFSelect_SignCounter> &  ) >(&IFSelect_DispPerSignature::SetSignCounter),
             R"#(Sets a SignCounter for sort Remark : it is set to record lists of entities, not only counts)#"  , py::arg("sign")
          )
        .def("SignName",
             ( const char * (IFSelect_DispPerSignature::*)() const) static_cast< const char * (IFSelect_DispPerSignature::*)() const>(&IFSelect_DispPerSignature::SignName),
             R"#(Returns the name of the SignCounter, which characterises the sorting criterium for this Dispatch)#" 
          )
        .def("Label",
             (TCollection_AsciiString (IFSelect_DispPerSignature::*)() const) static_cast<TCollection_AsciiString (IFSelect_DispPerSignature::*)() const>(&IFSelect_DispPerSignature::Label),
             R"#(Returns as Label, "One File per Signature <name>")#" 
          )
        .def("LimitedMax",
             (bool (IFSelect_DispPerSignature::*)(  const int ,  int &  ) const) static_cast<bool (IFSelect_DispPerSignature::*)(  const int ,  int &  ) const>(&IFSelect_DispPerSignature::LimitedMax),
             R"#(Returns True, maximum count is given as <nbent>)#"  , py::arg("nbent"),  py::arg("max")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_DispPerSignature::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_DispPerSignature::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_DispPerSignature::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_DispPerSignature::*)() const>(&IFSelect_DispPerSignature::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_Modifier from ./opencascade/IFSelect_Modifier.hxx
    klass = m.attr("IFSelect_Modifier");


    // nested enums

    static_cast<py::class_<IFSelect_Modifier ,opencascade::handle<IFSelect_Modifier> ,Py_IFSelect_Modifier , IFSelect_GeneralModifier >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_Modifier::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_Modifier::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_Modifier::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_Modifier::*)() const>(&IFSelect_Modifier::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_ParamEditor from ./opencascade/IFSelect_ParamEditor.hxx
    klass = m.attr("IFSelect_ParamEditor");


    // nested enums

    static_cast<py::class_<IFSelect_ParamEditor ,opencascade::handle<IFSelect_ParamEditor>  , IFSelect_Editor >>(klass)
    // constructors
        .def(py::init<  const int, const char * const  >()  , py::arg("nbmax")=static_cast< const int>(100),  py::arg("label")=static_cast< const char * const >("") )
    // custom constructors
    // methods
        .def("AddConstantText",
             (void (IFSelect_ParamEditor::*)(  const char * const  ,   const char * const  ,   const char * const   ) ) static_cast<void (IFSelect_ParamEditor::*)(  const char * const  ,   const char * const  ,   const char * const   ) >(&IFSelect_ParamEditor::AddConstantText),
             R"#(Adds a Constant Text, it will be Read Only By default, its long name equates its shortname)#"  , py::arg("val"),  py::arg("shortname"),  py::arg("completename")=static_cast< const char * const >("")
          )
        .def("Label",
             (TCollection_AsciiString (IFSelect_ParamEditor::*)() const) static_cast<TCollection_AsciiString (IFSelect_ParamEditor::*)() const>(&IFSelect_ParamEditor::Label),
             R"#()#" 
          )
        .def("Recognize",
             (bool (IFSelect_ParamEditor::*)(  const handle<IFSelect_EditForm> &  ) const) static_cast<bool (IFSelect_ParamEditor::*)(  const handle<IFSelect_EditForm> &  ) const>(&IFSelect_ParamEditor::Recognize),
             R"#()#"  , py::arg("form")
          )
        .def("StringValue",
             (handle<TCollection_HAsciiString> (IFSelect_ParamEditor::*)(  const handle<IFSelect_EditForm> & ,   const int  ) const) static_cast<handle<TCollection_HAsciiString> (IFSelect_ParamEditor::*)(  const handle<IFSelect_EditForm> & ,   const int  ) const>(&IFSelect_ParamEditor::StringValue),
             R"#()#"  , py::arg("form"),  py::arg("num")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("StaticEditor_s",
                    (handle<IFSelect_ParamEditor> (*)(  const handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> & ,   const char * const   ) ) static_cast<handle<IFSelect_ParamEditor> (*)(  const handle<NCollection_HSequence<handle<TCollection_HAsciiString>>> & ,   const char * const   ) >(&IFSelect_ParamEditor::StaticEditor),
                    R"#(Returns a ParamEditor to work on the Static Parameters of which names are listed in <list> Null Handle if <list> is null or empty)#"  , py::arg("list"),  py::arg("label")=static_cast< const char * const >("")
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_ParamEditor::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_ParamEditor::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_ParamEditor::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_ParamEditor::*)() const>(&IFSelect_ParamEditor::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectBase from ./opencascade/IFSelect_SelectBase.hxx
    klass = m.attr("IFSelect_SelectBase");


    // nested enums

    static_cast<py::class_<IFSelect_SelectBase ,opencascade::handle<IFSelect_SelectBase> ,Py_IFSelect_SelectBase , IFSelect_Selection >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("FillIterator",
             (void (IFSelect_SelectBase::*)( IFSelect_SelectionIterator &  ) const) static_cast<void (IFSelect_SelectBase::*)( IFSelect_SelectionIterator &  ) const>(&IFSelect_SelectBase::FillIterator),
             R"#(Puts in an Iterator the Selections from which "me" depends This list is empty for all SelectBase type Selections)#"  , py::arg("iter")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectBase::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectBase::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectBase::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectBase::*)() const>(&IFSelect_SelectBase::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectCombine from ./opencascade/IFSelect_SelectCombine.hxx
    klass = m.attr("IFSelect_SelectCombine");


    // nested enums

    static_cast<py::class_<IFSelect_SelectCombine ,opencascade::handle<IFSelect_SelectCombine> ,Py_IFSelect_SelectCombine , IFSelect_Selection >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("NbInputs",
             (int (IFSelect_SelectCombine::*)() const) static_cast<int (IFSelect_SelectCombine::*)() const>(&IFSelect_SelectCombine::NbInputs),
             R"#(Returns the count of Input Selections)#" 
          )
        .def("Input",
             (handle<IFSelect_Selection> (IFSelect_SelectCombine::*)(  const int  ) const) static_cast<handle<IFSelect_Selection> (IFSelect_SelectCombine::*)(  const int  ) const>(&IFSelect_SelectCombine::Input),
             R"#(Returns an Input Selection, given its rank in the list)#"  , py::arg("num")
          )
        .def("InputRank",
             (int (IFSelect_SelectCombine::*)(  const handle<IFSelect_Selection> &  ) const) static_cast<int (IFSelect_SelectCombine::*)(  const handle<IFSelect_Selection> &  ) const>(&IFSelect_SelectCombine::InputRank),
             R"#(Returns the rank of an input Selection, 0 if not in the list. Most generally, its value is meaningless, except for testing the presence of an input Selection : - == 0 if <sel> is not an input for <me> - > 0 if <sel> is an input for <me>)#"  , py::arg("sel")
          )
        .def("Add",
             (void (IFSelect_SelectCombine::*)(  const handle<IFSelect_Selection> & ,   const int  ) ) static_cast<void (IFSelect_SelectCombine::*)(  const handle<IFSelect_Selection> & ,   const int  ) >(&IFSelect_SelectCombine::Add),
             R"#(Adds a Selection to the filling list By default, adds it to the end of the list A Positive rank less then NbInputs gives an insertion rank (InsertBefore : the new <atnum>th item of the list is <sel>))#"  , py::arg("sel"),  py::arg("atnum")=static_cast< const int>(0)
          )
        .def("Remove",
             (bool (IFSelect_SelectCombine::*)(  const handle<IFSelect_Selection> &  ) ) static_cast<bool (IFSelect_SelectCombine::*)(  const handle<IFSelect_Selection> &  ) >(&IFSelect_SelectCombine::Remove),
             R"#(Removes an input Selection. Returns True if Done, False, if <sel> is not an input for <me>)#"  , py::arg("sel")
          )
        .def("Remove",
             (bool (IFSelect_SelectCombine::*)(  const int  ) ) static_cast<bool (IFSelect_SelectCombine::*)(  const int  ) >(&IFSelect_SelectCombine::Remove),
             R"#(Removes an input Selection, given its rank in the list Returns True if Done, False if <num> is out of range)#"  , py::arg("num")
          )
        .def("FillIterator",
             (void (IFSelect_SelectCombine::*)( IFSelect_SelectionIterator &  ) const) static_cast<void (IFSelect_SelectCombine::*)( IFSelect_SelectionIterator &  ) const>(&IFSelect_SelectCombine::FillIterator),
             R"#(Puts in an Iterator the Selections from which "me" depends That is to say, the list of Input Selections)#"  , py::arg("iter")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectCombine::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectCombine::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectCombine::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectCombine::*)() const>(&IFSelect_SelectCombine::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectControl from ./opencascade/IFSelect_SelectControl.hxx
    klass = m.attr("IFSelect_SelectControl");


    // nested enums

    static_cast<py::class_<IFSelect_SelectControl ,opencascade::handle<IFSelect_SelectControl> ,Py_IFSelect_SelectControl , IFSelect_Selection >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("MainInput",
             (handle<IFSelect_Selection> (IFSelect_SelectControl::*)() const) static_cast<handle<IFSelect_Selection> (IFSelect_SelectControl::*)() const>(&IFSelect_SelectControl::MainInput),
             R"#(Returns the Main Input Selection)#" 
          )
        .def("HasSecondInput",
             (bool (IFSelect_SelectControl::*)() const) static_cast<bool (IFSelect_SelectControl::*)() const>(&IFSelect_SelectControl::HasSecondInput),
             R"#(Returns True if a Control Input is defined Thus, Result can be computed differently if there is a Control Input or if there is none)#" 
          )
        .def("SecondInput",
             (handle<IFSelect_Selection> (IFSelect_SelectControl::*)() const) static_cast<handle<IFSelect_Selection> (IFSelect_SelectControl::*)() const>(&IFSelect_SelectControl::SecondInput),
             R"#(Returns the Control Input Selection, or a Null Handle)#" 
          )
        .def("SetMainInput",
             (void (IFSelect_SelectControl::*)(  const handle<IFSelect_Selection> &  ) ) static_cast<void (IFSelect_SelectControl::*)(  const handle<IFSelect_Selection> &  ) >(&IFSelect_SelectControl::SetMainInput),
             R"#(Sets a Selection to be the Main Input)#"  , py::arg("sel")
          )
        .def("SetSecondInput",
             (void (IFSelect_SelectControl::*)(  const handle<IFSelect_Selection> &  ) ) static_cast<void (IFSelect_SelectControl::*)(  const handle<IFSelect_Selection> &  ) >(&IFSelect_SelectControl::SetSecondInput),
             R"#(Sets a Selection to be the Control Input)#"  , py::arg("sel")
          )
        .def("FillIterator",
             (void (IFSelect_SelectControl::*)( IFSelect_SelectionIterator &  ) const) static_cast<void (IFSelect_SelectControl::*)( IFSelect_SelectionIterator &  ) const>(&IFSelect_SelectControl::FillIterator),
             R"#(Puts in an Iterator the Selections from which "me" depends That is to say, the list of Input Selections)#"  , py::arg("iter")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectControl::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectControl::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectControl::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectControl::*)() const>(&IFSelect_SelectControl::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectDeduct from ./opencascade/IFSelect_SelectDeduct.hxx
    klass = m.attr("IFSelect_SelectDeduct");


    // nested enums

    static_cast<py::class_<IFSelect_SelectDeduct ,opencascade::handle<IFSelect_SelectDeduct> ,Py_IFSelect_SelectDeduct , IFSelect_Selection >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("SetInput",
             (void (IFSelect_SelectDeduct::*)(  const handle<IFSelect_Selection> &  ) ) static_cast<void (IFSelect_SelectDeduct::*)(  const handle<IFSelect_Selection> &  ) >(&IFSelect_SelectDeduct::SetInput),
             R"#(Defines or Changes the Input Selection)#"  , py::arg("sel")
          )
        .def("Input",
             (handle<IFSelect_Selection> (IFSelect_SelectDeduct::*)() const) static_cast<handle<IFSelect_Selection> (IFSelect_SelectDeduct::*)() const>(&IFSelect_SelectDeduct::Input),
             R"#(Returns the Input Selection)#" 
          )
        .def("HasInput",
             (bool (IFSelect_SelectDeduct::*)() const) static_cast<bool (IFSelect_SelectDeduct::*)() const>(&IFSelect_SelectDeduct::HasInput),
             R"#(Returns True if the Input Selection is defined, False else)#" 
          )
        .def("HasAlternate",
             (bool (IFSelect_SelectDeduct::*)() const) static_cast<bool (IFSelect_SelectDeduct::*)() const>(&IFSelect_SelectDeduct::HasAlternate),
             R"#(Tells if an Alternate List has been set, i.e. : the Alternate Definition is present and set)#" 
          )
        .def("FillIterator",
             (void (IFSelect_SelectDeduct::*)( IFSelect_SelectionIterator &  ) const) static_cast<void (IFSelect_SelectDeduct::*)( IFSelect_SelectionIterator &  ) const>(&IFSelect_SelectDeduct::FillIterator),
             R"#(Puts in an Iterator the Selections from which "me" depends This list contains one Selection : the InputSelection)#"  , py::arg("iter")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectDeduct::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectDeduct::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Alternate",
             (handle<IFSelect_SelectPointed> & (IFSelect_SelectDeduct::*)() ) static_cast<handle<IFSelect_SelectPointed> & (IFSelect_SelectDeduct::*)() >(&IFSelect_SelectDeduct::Alternate),
             R"#(Returns the Alternate Definition It is returned modifiable, hence an already defined SelectPointed can be used But if it was not yet defined, it is created the first time)#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectDeduct::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectDeduct::*)() const>(&IFSelect_SelectDeduct::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SessionPilot from ./opencascade/IFSelect_SessionPilot.hxx
    klass = m.attr("IFSelect_SessionPilot");


    // nested enums

    static_cast<py::class_<IFSelect_SessionPilot ,opencascade::handle<IFSelect_SessionPilot>  , IFSelect_Activator >>(klass)
    // constructors
        .def(py::init<  const char * const  >()  , py::arg("prompt")=static_cast< const char * const >("") )
    // custom constructors
    // methods
        .def("Session",
             (handle<IFSelect_WorkSession> (IFSelect_SessionPilot::*)() const) static_cast<handle<IFSelect_WorkSession> (IFSelect_SessionPilot::*)() const>(&IFSelect_SessionPilot::Session),
             R"#(Returns the WorkSession which is worked on)#" 
          )
        .def("Library",
             (handle<IFSelect_WorkLibrary> (IFSelect_SessionPilot::*)() const) static_cast<handle<IFSelect_WorkLibrary> (IFSelect_SessionPilot::*)() const>(&IFSelect_SessionPilot::Library),
             R"#(Returns the WorKlibrary (Null if not set). WorkLibrary is used to Read and Write Files, according to the Norm)#" 
          )
        .def("RecordMode",
             (bool (IFSelect_SessionPilot::*)() const) static_cast<bool (IFSelect_SessionPilot::*)() const>(&IFSelect_SessionPilot::RecordMode),
             R"#(Returns the Record Mode for Commands. Default is False.)#" 
          )
        .def("SetSession",
             (void (IFSelect_SessionPilot::*)(  const handle<IFSelect_WorkSession> &  ) ) static_cast<void (IFSelect_SessionPilot::*)(  const handle<IFSelect_WorkSession> &  ) >(&IFSelect_SessionPilot::SetSession),
             R"#(Sets a WorkSession to be worked on)#"  , py::arg("WS")
          )
        .def("SetLibrary",
             (void (IFSelect_SessionPilot::*)(  const handle<IFSelect_WorkLibrary> &  ) ) static_cast<void (IFSelect_SessionPilot::*)(  const handle<IFSelect_WorkLibrary> &  ) >(&IFSelect_SessionPilot::SetLibrary),
             R"#(Sets a WorkLibrary)#"  , py::arg("WL")
          )
        .def("SetRecordMode",
             (void (IFSelect_SessionPilot::*)(  const bool  ) ) static_cast<void (IFSelect_SessionPilot::*)(  const bool  ) >(&IFSelect_SessionPilot::SetRecordMode),
             R"#(Changes the RecordMode.)#"  , py::arg("mode")
          )
        .def("SetCommandLine",
             (void (IFSelect_SessionPilot::*)(  const TCollection_AsciiString &  ) ) static_cast<void (IFSelect_SessionPilot::*)(  const TCollection_AsciiString &  ) >(&IFSelect_SessionPilot::SetCommandLine),
             R"#(Sets the value of the Command Line to be interpreted Also prepares the interpretation (splitting by blanks))#"  , py::arg("command")
          )
        .def("CommandPart",
             ( const char * (IFSelect_SessionPilot::*)(  const int  ) const) static_cast< const char * (IFSelect_SessionPilot::*)(  const int  ) const>(&IFSelect_SessionPilot::CommandPart),
             R"#(Returns the part of the command line which begins at argument <numarg> between 0 and NbWords-1 (by default, all the line) Empty string if out of range)#"  , py::arg("numarg")=static_cast< const int>(0)
          )
        .def("NbWords",
             (int (IFSelect_SessionPilot::*)() const) static_cast<int (IFSelect_SessionPilot::*)() const>(&IFSelect_SessionPilot::NbWords),
             R"#(Returns the count of words of the Command Line, separated by blanks : 0 if empty, one if a command without args, else it gives the count of args minus one. Warning : limited to 10 (command title + 9 args))#" 
          )
        .def("Word",
             ( const TCollection_AsciiString & (IFSelect_SessionPilot::*)(  const int  ) const) static_cast< const TCollection_AsciiString & (IFSelect_SessionPilot::*)(  const int  ) const>(&IFSelect_SessionPilot::Word),
             R"#(Returns a word given its rank in the Command Line. Begins at 0 which is the Command Title, 1 is the 1st arg., etc...)#"  , py::arg("num")
          )
        .def("Arg",
             ( const char * (IFSelect_SessionPilot::*)(  const int  ) const) static_cast< const char * (IFSelect_SessionPilot::*)(  const int  ) const>(&IFSelect_SessionPilot::Arg),
             R"#(Returns a word given its rank, as a CString. As for Word, begins at 0 (the command name), etc...)#"  , py::arg("num")
          )
        .def("RemoveWord",
             (bool (IFSelect_SessionPilot::*)(  const int  ) ) static_cast<bool (IFSelect_SessionPilot::*)(  const int  ) >(&IFSelect_SessionPilot::RemoveWord),
             R"#(Removes a word given its rank. Returns True if Done, False if <num> is out of range)#"  , py::arg("num")
          )
        .def("NbCommands",
             (int (IFSelect_SessionPilot::*)() const) static_cast<int (IFSelect_SessionPilot::*)() const>(&IFSelect_SessionPilot::NbCommands),
             R"#(Returns the count of recorded Commands)#" 
          )
        .def("Command",
             ( const TCollection_AsciiString & (IFSelect_SessionPilot::*)(  const int  ) const) static_cast< const TCollection_AsciiString & (IFSelect_SessionPilot::*)(  const int  ) const>(&IFSelect_SessionPilot::Command),
             R"#(Returns a recorded Command, given its rank (from 1))#"  , py::arg("num")
          )
        .def("RecordItem",
             (IFSelect_ReturnStatus (IFSelect_SessionPilot::*)(  const handle<Standard_Transient> &  ) ) static_cast<IFSelect_ReturnStatus (IFSelect_SessionPilot::*)(  const handle<Standard_Transient> &  ) >(&IFSelect_SessionPilot::RecordItem),
             R"#(Allows to associate a Transient Value with the last execution as a partial result Returns RetDone if item is not Null, RetFail if item is Null Remark : it is nullified for each Perform)#"  , py::arg("item")
          )
        .def("RecordedItem",
             (handle<Standard_Transient> (IFSelect_SessionPilot::*)() const) static_cast<handle<Standard_Transient> (IFSelect_SessionPilot::*)() const>(&IFSelect_SessionPilot::RecordedItem),
             R"#(Returns the Transient Object which was recorded with the current Line Command. If none was, returns a Null Handle)#" 
          )
        .def("Clear",
             (void (IFSelect_SessionPilot::*)() ) static_cast<void (IFSelect_SessionPilot::*)() >(&IFSelect_SessionPilot::Clear),
             R"#(Clears the recorded information (commands, objects))#" 
          )
        .def("ReadScript",
             (IFSelect_ReturnStatus (IFSelect_SessionPilot::*)(  const char * const   ) ) static_cast<IFSelect_ReturnStatus (IFSelect_SessionPilot::*)(  const char * const   ) >(&IFSelect_SessionPilot::ReadScript),
             R"#(Reads commands from a Script File, named <file>. By default (file = ""), reads from standard input with a prompt Else (reading from a file), the read commands are displayed onto standard output. Allows nested reads. Reading is stopped either by command x or exit, or by reaching end of file Return Value follows the rules of Do : RetEnd for normal end, RetFail if script could not be opened)#"  , py::arg("file")=static_cast< const char * const >("")
          )
        .def("Perform",
             (IFSelect_ReturnStatus (IFSelect_SessionPilot::*)() ) static_cast<IFSelect_ReturnStatus (IFSelect_SessionPilot::*)() >(&IFSelect_SessionPilot::Perform),
             R"#(Executes the Command, itself (for built-in commands, which have priority) or by using the list of Activators. The value returned is : RetVoid if nothing done (void command) RetDone if execution OK, RetEnd if END OF SESSION, RetError if command unknown or incorrect, RetFail if error on execution If execution is OK and RecordMode is set, this Command Line is recorded to the list (see below).)#" 
          )
        .def("ExecuteAlias",
             (IFSelect_ReturnStatus (IFSelect_SessionPilot::*)(  const TCollection_AsciiString &  ) ) static_cast<IFSelect_ReturnStatus (IFSelect_SessionPilot::*)(  const TCollection_AsciiString &  ) >(&IFSelect_SessionPilot::ExecuteAlias),
             R"#(Executes the Commands, except that the command name (word 0) is aliased. The rest of the command line is unchanged If <alias> is empty, Executes with no change)#"  , py::arg("aliasname")
          )
        .def("Execute",
             (IFSelect_ReturnStatus (IFSelect_SessionPilot::*)(  const TCollection_AsciiString &  ) ) static_cast<IFSelect_ReturnStatus (IFSelect_SessionPilot::*)(  const TCollection_AsciiString &  ) >(&IFSelect_SessionPilot::Execute),
             R"#(Sets the Command then tries to execute it. Return value : same as for Perform)#"  , py::arg("command")
          )
        .def("ExecuteCounter",
             (IFSelect_ReturnStatus (IFSelect_SessionPilot::*)(  const handle<IFSelect_SignCounter> & ,   const int ,   const IFSelect_PrintCount  ) ) static_cast<IFSelect_ReturnStatus (IFSelect_SessionPilot::*)(  const handle<IFSelect_SignCounter> & ,   const int ,   const IFSelect_PrintCount  ) >(&IFSelect_SessionPilot::ExecuteCounter),
             R"#(Executes a Counter in a general way If <numword> is greater than count of command words, it counts all the model. Else it considers the word <numword> as the identifier of a Selection <mode> gives the mode of printing results, default is CountByItem)#"  , py::arg("counter"),  py::arg("numword"),  py::arg("mode")=static_cast< const IFSelect_PrintCount>(IFSelect_CountByItem)
          )
        .def("Number",
             (int (IFSelect_SessionPilot::*)(  const char * const   ) const) static_cast<int (IFSelect_SessionPilot::*)(  const char * const   ) const>(&IFSelect_SessionPilot::Number),
             R"#(Interprets a string value as an entity number : if it gives an integer, returns its value else, considers it as ENtityLabel (preferably case sensitive) in case of failure, returns 0)#"  , py::arg("val")
          )
        .def("Do",
             (IFSelect_ReturnStatus (IFSelect_SessionPilot::*)(  const int ,   const handle<IFSelect_SessionPilot> &  ) ) static_cast<IFSelect_ReturnStatus (IFSelect_SessionPilot::*)(  const int ,   const handle<IFSelect_SessionPilot> &  ) >(&IFSelect_SessionPilot::Do),
             R"#(Processes specific commands, which are : x or exit for end of session ? or help for help messages xcommand to control command lines (Record Mode, List, Clear, File Output ...) xsource to execute a command file (no nesting allowed), in case of error, source is stopped and keyword recovers xstep is a simple prefix (useful in a wider environment, to avoid conflicts on command names) xset control commands which create items with names)#"  , py::arg("number"),  py::arg("session")
          )
        .def("Help",
             ( const char * (IFSelect_SessionPilot::*)(  const int  ) const) static_cast< const char * (IFSelect_SessionPilot::*)(  const int  ) const>(&IFSelect_SessionPilot::Help),
             R"#(Help for specific commands (apart from general command help))#"  , py::arg("number")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SessionPilot::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SessionPilot::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("CommandLine",
             ( const TCollection_AsciiString & (IFSelect_SessionPilot::*)() const) static_cast< const TCollection_AsciiString & (IFSelect_SessionPilot::*)() const>(&IFSelect_SessionPilot::CommandLine),
             R"#(Returns the Command Line to be interpreted)#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SessionPilot::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SessionPilot::*)() const>(&IFSelect_SessionPilot::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SignCategory from ./opencascade/IFSelect_SignCategory.hxx
    klass = m.attr("IFSelect_SignCategory");


    // nested enums

    static_cast<py::class_<IFSelect_SignCategory ,opencascade::handle<IFSelect_SignCategory>  , IFSelect_Signature >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SignCategory::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SignCategory::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SignCategory::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SignCategory::*)() const>(&IFSelect_SignCategory::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SignCounter from ./opencascade/IFSelect_SignCounter.hxx
    klass = m.attr("IFSelect_SignCounter");


    // nested enums

    static_cast<py::class_<IFSelect_SignCounter ,opencascade::handle<IFSelect_SignCounter>  , IFSelect_SignatureList >>(klass)
    // constructors
        .def(py::init<  const bool, const bool >()  , py::arg("withmap")=static_cast< const bool>(true),  py::arg("withlist")=static_cast< const bool>(false) )
        .def(py::init<  const handle<IFSelect_Signature> &, const bool, const bool >()  , py::arg("matcher"),  py::arg("withmap")=static_cast< const bool>(true),  py::arg("withlist")=static_cast< const bool>(false) )
    // custom constructors
    // methods
        .def("Signature",
             (handle<IFSelect_Signature> (IFSelect_SignCounter::*)() const) static_cast<handle<IFSelect_Signature> (IFSelect_SignCounter::*)() const>(&IFSelect_SignCounter::Signature),
             R"#(Returns the Signature used to count entities. It can be null.)#" 
          )
        .def("SetMap",
             (void (IFSelect_SignCounter::*)(  const bool  ) ) static_cast<void (IFSelect_SignCounter::*)(  const bool  ) >(&IFSelect_SignCounter::SetMap),
             R"#(Changes the control status. The map is not cleared, simply its use changes)#"  , py::arg("withmap")
          )
        .def("SetSelection",
             (void (IFSelect_SignCounter::*)(  const handle<IFSelect_Selection> &  ) ) static_cast<void (IFSelect_SignCounter::*)(  const handle<IFSelect_Selection> &  ) >(&IFSelect_SignCounter::SetSelection),
             R"#(Sets a Selection as input : this causes content to be cleared then the Selection to be ready to compute (but not immediately))#"  , py::arg("sel")
          )
        .def("Selection",
             (handle<IFSelect_Selection> (IFSelect_SignCounter::*)() const) static_cast<handle<IFSelect_Selection> (IFSelect_SignCounter::*)() const>(&IFSelect_SignCounter::Selection),
             R"#(Returns the selection, or a null Handle)#" 
          )
        .def("SetSelMode",
             (void (IFSelect_SignCounter::*)(  const int  ) ) static_cast<void (IFSelect_SignCounter::*)(  const int  ) >(&IFSelect_SignCounter::SetSelMode),
             R"#(Changes the mode of working with the selection : -1 just clears optimisation data and nothing else 0 clears it 1 inhibits it for computing (but no clearing) 2 sets it active for computing Default at creation is 0, after SetSelection (not null) is 2)#"  , py::arg("selmode")
          )
        .def("SelMode",
             (int (IFSelect_SignCounter::*)() const) static_cast<int (IFSelect_SignCounter::*)() const>(&IFSelect_SignCounter::SelMode),
             R"#(Returns the mode of working with the selection)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SignCounter::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SignCounter::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SignCounter::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SignCounter::*)() const>(&IFSelect_SignCounter::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SignMultiple from ./opencascade/IFSelect_SignMultiple.hxx
    klass = m.attr("IFSelect_SignMultiple");


    // nested enums

    static_cast<py::class_<IFSelect_SignMultiple ,opencascade::handle<IFSelect_SignMultiple>  , IFSelect_Signature >>(klass)
    // constructors
        .def(py::init<  const char * const  >()  , py::arg("name") )
    // custom constructors
    // methods
        .def("Add",
             (void (IFSelect_SignMultiple::*)(  const handle<IFSelect_Signature> & ,   const int ,   const bool  ) ) static_cast<void (IFSelect_SignMultiple::*)(  const handle<IFSelect_Signature> & ,   const int ,   const bool  ) >(&IFSelect_SignMultiple::Add),
             R"#(Adds a Signature. Width, if given, gives the tabulation If <maxi> is True, it is a forced tabulation (overlength is replaced by a final dot) If <maxi> is False, just 3 blanks follow an overlength)#"  , py::arg("subsign"),  py::arg("width")=static_cast< const int>(0),  py::arg("maxi")=static_cast< const bool>(false)
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SignMultiple::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SignMultiple::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SignMultiple::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SignMultiple::*)() const>(&IFSelect_SignMultiple::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SignType from ./opencascade/IFSelect_SignType.hxx
    klass = m.attr("IFSelect_SignType");


    // nested enums

    static_cast<py::class_<IFSelect_SignType ,opencascade::handle<IFSelect_SignType>  , IFSelect_Signature >>(klass)
    // constructors
        .def(py::init<  const bool >()  , py::arg("nopk")=static_cast< const bool>(false) )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SignType::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SignType::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SignType::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SignType::*)() const>(&IFSelect_SignType::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SignValidity from ./opencascade/IFSelect_SignValidity.hxx
    klass = m.attr("IFSelect_SignValidity");


    // nested enums

    static_cast<py::class_<IFSelect_SignValidity ,opencascade::handle<IFSelect_SignValidity>  , IFSelect_Signature >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SignValidity::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SignValidity::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SignValidity::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SignValidity::*)() const>(&IFSelect_SignValidity::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_TransformStandard from ./opencascade/IFSelect_TransformStandard.hxx
    klass = m.attr("IFSelect_TransformStandard");


    // nested enums

    static_cast<py::class_<IFSelect_TransformStandard ,opencascade::handle<IFSelect_TransformStandard>  , IFSelect_Transformer >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetCopyOption",
             (void (IFSelect_TransformStandard::*)(  const bool  ) ) static_cast<void (IFSelect_TransformStandard::*)(  const bool  ) >(&IFSelect_TransformStandard::SetCopyOption),
             R"#(Sets the Copy option to a new value : True for StandardCopy. False for OnTheSpot)#"  , py::arg("option")
          )
        .def("CopyOption",
             (bool (IFSelect_TransformStandard::*)() const) static_cast<bool (IFSelect_TransformStandard::*)() const>(&IFSelect_TransformStandard::CopyOption),
             R"#(Returns the Copy option)#" 
          )
        .def("SetSelection",
             (void (IFSelect_TransformStandard::*)(  const handle<IFSelect_Selection> &  ) ) static_cast<void (IFSelect_TransformStandard::*)(  const handle<IFSelect_Selection> &  ) >(&IFSelect_TransformStandard::SetSelection),
             R"#(Sets a Selection (or unsets if Null) This Selection then defines the list of entities on which the Modifiers will be applied If it is set, it has priority on Selections of Modifiers Else, for each Modifier its Selection is evaluated By default, all the Model is taken)#"  , py::arg("sel")
          )
        .def("Selection",
             (handle<IFSelect_Selection> (IFSelect_TransformStandard::*)() const) static_cast<handle<IFSelect_Selection> (IFSelect_TransformStandard::*)() const>(&IFSelect_TransformStandard::Selection),
             R"#(Returns the Selection, Null by default)#" 
          )
        .def("NbModifiers",
             (int (IFSelect_TransformStandard::*)() const) static_cast<int (IFSelect_TransformStandard::*)() const>(&IFSelect_TransformStandard::NbModifiers),
             R"#(Returns the count of recorded Modifiers)#" 
          )
        .def("Modifier",
             (handle<IFSelect_Modifier> (IFSelect_TransformStandard::*)(  const int  ) const) static_cast<handle<IFSelect_Modifier> (IFSelect_TransformStandard::*)(  const int  ) const>(&IFSelect_TransformStandard::Modifier),
             R"#(Returns a Modifier given its rank in the list)#"  , py::arg("num")
          )
        .def("ModifierRank",
             (int (IFSelect_TransformStandard::*)(  const handle<IFSelect_Modifier> &  ) const) static_cast<int (IFSelect_TransformStandard::*)(  const handle<IFSelect_Modifier> &  ) const>(&IFSelect_TransformStandard::ModifierRank),
             R"#(Returns the rank of a Modifier in the list, 0 if unknown)#"  , py::arg("modif")
          )
        .def("AddModifier",
             (bool (IFSelect_TransformStandard::*)(  const handle<IFSelect_Modifier> & ,   const int  ) ) static_cast<bool (IFSelect_TransformStandard::*)(  const handle<IFSelect_Modifier> & ,   const int  ) >(&IFSelect_TransformStandard::AddModifier),
             R"#(Adds a Modifier to the list : - <atnum> = 0 (default) : at the end of the list - <atnum> > 0 : at rank <atnum> Returns True if done, False if <atnum> is out of range)#"  , py::arg("modif"),  py::arg("atnum")=static_cast< const int>(0)
          )
        .def("RemoveModifier",
             (bool (IFSelect_TransformStandard::*)(  const handle<IFSelect_Modifier> &  ) ) static_cast<bool (IFSelect_TransformStandard::*)(  const handle<IFSelect_Modifier> &  ) >(&IFSelect_TransformStandard::RemoveModifier),
             R"#(Removes a Modifier from the list Returns True if done, False if <modif> not in the list)#"  , py::arg("modif")
          )
        .def("RemoveModifier",
             (bool (IFSelect_TransformStandard::*)(  const int  ) ) static_cast<bool (IFSelect_TransformStandard::*)(  const int  ) >(&IFSelect_TransformStandard::RemoveModifier),
             R"#(Removes a Modifier from the list, given its rank Returns True if done, False if <num> is out of range)#"  , py::arg("num")
          )
        .def("Updated",
             (bool (IFSelect_TransformStandard::*)(  const handle<Standard_Transient> & ,  handle<Standard_Transient> &  ) const) static_cast<bool (IFSelect_TransformStandard::*)(  const handle<Standard_Transient> & ,  handle<Standard_Transient> &  ) const>(&IFSelect_TransformStandard::Updated),
             R"#(This methods allows to know what happened to a starting entity after the last Perform. It reads result from the map which was filled by Perform.)#"  , py::arg("entfrom"),  py::arg("entto")
          )
        .def("Label",
             (TCollection_AsciiString (IFSelect_TransformStandard::*)() const) static_cast<TCollection_AsciiString (IFSelect_TransformStandard::*)() const>(&IFSelect_TransformStandard::Label),
             R"#(Returns a text which defines the way a Transformer works : "On the spot edition" or "Standard Copy" followed by "<nn> Modifiers")#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_TransformStandard::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_TransformStandard::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_TransformStandard::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_TransformStandard::*)() const>(&IFSelect_TransformStandard::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_GraphCounter from ./opencascade/IFSelect_GraphCounter.hxx
    klass = m.attr("IFSelect_GraphCounter");


    // nested enums

    static_cast<py::class_<IFSelect_GraphCounter ,opencascade::handle<IFSelect_GraphCounter>  , IFSelect_SignCounter >>(klass)
    // constructors
        .def(py::init<  const bool, const bool >()  , py::arg("withmap")=static_cast< const bool>(true),  py::arg("withlist")=static_cast< const bool>(false) )
    // custom constructors
    // methods
        .def("Applied",
             (handle<IFSelect_SelectDeduct> (IFSelect_GraphCounter::*)() const) static_cast<handle<IFSelect_SelectDeduct> (IFSelect_GraphCounter::*)() const>(&IFSelect_GraphCounter::Applied),
             R"#(Returns the applied selection)#" 
          )
        .def("SetApplied",
             (void (IFSelect_GraphCounter::*)(  const handle<IFSelect_SelectDeduct> &  ) ) static_cast<void (IFSelect_GraphCounter::*)(  const handle<IFSelect_SelectDeduct> &  ) >(&IFSelect_GraphCounter::SetApplied),
             R"#(Sets a new applied selection)#"  , py::arg("sel")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_GraphCounter::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_GraphCounter::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_GraphCounter::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_GraphCounter::*)() const>(&IFSelect_GraphCounter::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_ModifEditForm from ./opencascade/IFSelect_ModifEditForm.hxx
    klass = m.attr("IFSelect_ModifEditForm");


    // nested enums

    static_cast<py::class_<IFSelect_ModifEditForm ,opencascade::handle<IFSelect_ModifEditForm>  , IFSelect_Modifier >>(klass)
    // constructors
        .def(py::init<  const handle<IFSelect_EditForm> & >()  , py::arg("editform") )
    // custom constructors
    // methods
        .def("EditForm",
             (handle<IFSelect_EditForm> (IFSelect_ModifEditForm::*)() const) static_cast<handle<IFSelect_EditForm> (IFSelect_ModifEditForm::*)() const>(&IFSelect_ModifEditForm::EditForm),
             R"#(Returns the EditForm)#" 
          )
        .def("Label",
             (TCollection_AsciiString (IFSelect_ModifEditForm::*)() const) static_cast<TCollection_AsciiString (IFSelect_ModifEditForm::*)() const>(&IFSelect_ModifEditForm::Label),
             R"#(Returns Label as "Apply EditForm <+ label of EditForm>")#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_ModifEditForm::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_ModifEditForm::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_ModifEditForm::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_ModifEditForm::*)() const>(&IFSelect_ModifEditForm::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_ModifReorder from ./opencascade/IFSelect_ModifReorder.hxx
    klass = m.attr("IFSelect_ModifReorder");


    // nested enums

    static_cast<py::class_<IFSelect_ModifReorder ,opencascade::handle<IFSelect_ModifReorder>  , IFSelect_Modifier >>(klass)
    // constructors
        .def(py::init<  const bool >()  , py::arg("rootlast")=static_cast< const bool>(true) )
    // custom constructors
    // methods
        .def("Label",
             (TCollection_AsciiString (IFSelect_ModifReorder::*)() const) static_cast<TCollection_AsciiString (IFSelect_ModifReorder::*)() const>(&IFSelect_ModifReorder::Label),
             R"#(Returns Label as "Reorder, Roots (last or first)")#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_ModifReorder::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_ModifReorder::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_ModifReorder::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_ModifReorder::*)() const>(&IFSelect_ModifReorder::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectAnyList from ./opencascade/IFSelect_SelectAnyList.hxx
    klass = m.attr("IFSelect_SelectAnyList");


    // nested enums

    static_cast<py::class_<IFSelect_SelectAnyList ,opencascade::handle<IFSelect_SelectAnyList> ,Py_IFSelect_SelectAnyList , IFSelect_SelectDeduct >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("NbItems",
             (int (IFSelect_SelectAnyList::*)(  const handle<Standard_Transient> &  ) const) static_cast<int (IFSelect_SelectAnyList::*)(  const handle<Standard_Transient> &  ) const>(&IFSelect_SelectAnyList::NbItems),
             R"#(Returns count of Items in the list in the Entity <ent> If <ent> has not required type, returned value must be Zero)#"  , py::arg("ent")
          )
        .def("SetRange",
             (void (IFSelect_SelectAnyList::*)(  const handle<IFSelect_IntParam> & ,   const handle<IFSelect_IntParam> &  ) ) static_cast<void (IFSelect_SelectAnyList::*)(  const handle<IFSelect_IntParam> & ,   const handle<IFSelect_IntParam> &  ) >(&IFSelect_SelectAnyList::SetRange),
             R"#(Sets a Range for numbers, with a lower and a upper limits)#"  , py::arg("rankfrom"),  py::arg("rankto")
          )
        .def("SetOne",
             (void (IFSelect_SelectAnyList::*)(  const handle<IFSelect_IntParam> &  ) ) static_cast<void (IFSelect_SelectAnyList::*)(  const handle<IFSelect_IntParam> &  ) >(&IFSelect_SelectAnyList::SetOne),
             R"#(Sets a unique number (only one Entity will be sorted as True))#"  , py::arg("rank")
          )
        .def("SetFrom",
             (void (IFSelect_SelectAnyList::*)(  const handle<IFSelect_IntParam> &  ) ) static_cast<void (IFSelect_SelectAnyList::*)(  const handle<IFSelect_IntParam> &  ) >(&IFSelect_SelectAnyList::SetFrom),
             R"#(Sets a Lower limit but no upper limit)#"  , py::arg("rankfrom")
          )
        .def("SetUntil",
             (void (IFSelect_SelectAnyList::*)(  const handle<IFSelect_IntParam> &  ) ) static_cast<void (IFSelect_SelectAnyList::*)(  const handle<IFSelect_IntParam> &  ) >(&IFSelect_SelectAnyList::SetUntil),
             R"#(Sets an Upper limit but no lower limit (equivalent to lower 1))#"  , py::arg("rankto")
          )
        .def("HasLower",
             (bool (IFSelect_SelectAnyList::*)() const) static_cast<bool (IFSelect_SelectAnyList::*)() const>(&IFSelect_SelectAnyList::HasLower),
             R"#(Returns True if a Lower limit is defined)#" 
          )
        .def("Lower",
             (handle<IFSelect_IntParam> (IFSelect_SelectAnyList::*)() const) static_cast<handle<IFSelect_IntParam> (IFSelect_SelectAnyList::*)() const>(&IFSelect_SelectAnyList::Lower),
             R"#(Returns Lower limit (if there is; else, value is senseless))#" 
          )
        .def("LowerValue",
             (int (IFSelect_SelectAnyList::*)() const) static_cast<int (IFSelect_SelectAnyList::*)() const>(&IFSelect_SelectAnyList::LowerValue),
             R"#(Returns Integer Value of Lower Limit (0 if none))#" 
          )
        .def("HasUpper",
             (bool (IFSelect_SelectAnyList::*)() const) static_cast<bool (IFSelect_SelectAnyList::*)() const>(&IFSelect_SelectAnyList::HasUpper),
             R"#(Returns True if a Lower limit is defined)#" 
          )
        .def("Upper",
             (handle<IFSelect_IntParam> (IFSelect_SelectAnyList::*)() const) static_cast<handle<IFSelect_IntParam> (IFSelect_SelectAnyList::*)() const>(&IFSelect_SelectAnyList::Upper),
             R"#(Returns Upper limit (if there is; else, value is senseless))#" 
          )
        .def("UpperValue",
             (int (IFSelect_SelectAnyList::*)() const) static_cast<int (IFSelect_SelectAnyList::*)() const>(&IFSelect_SelectAnyList::UpperValue),
             R"#(Returns Integer Value of Upper Limit (0 if none))#" 
          )
        .def("Label",
             (TCollection_AsciiString (IFSelect_SelectAnyList::*)() const) static_cast<TCollection_AsciiString (IFSelect_SelectAnyList::*)() const>(&IFSelect_SelectAnyList::Label),
             R"#(Returns a text defining the criterium : "Components of List " then Specific List Label, then, following cases : " From .. Until .." or "From .." or "Until .." or "Rank no .." Specific type is given by deferred method ListLabel)#" 
          )
        .def("ListLabel",
             (TCollection_AsciiString (IFSelect_SelectAnyList::*)() const) static_cast<TCollection_AsciiString (IFSelect_SelectAnyList::*)() const>(&IFSelect_SelectAnyList::ListLabel),
             R"#(Returns the specific label for the list, which is included as a part of Label)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectAnyList::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectAnyList::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectAnyList::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectAnyList::*)() const>(&IFSelect_SelectAnyList::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectDiff from ./opencascade/IFSelect_SelectDiff.hxx
    klass = m.attr("IFSelect_SelectDiff");


    // nested enums

    static_cast<py::class_<IFSelect_SelectDiff ,opencascade::handle<IFSelect_SelectDiff>  , IFSelect_SelectControl >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Label",
             (TCollection_AsciiString (IFSelect_SelectDiff::*)() const) static_cast<TCollection_AsciiString (IFSelect_SelectDiff::*)() const>(&IFSelect_SelectDiff::Label),
             R"#(Returns a text defining the criterium : "Difference")#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectDiff::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectDiff::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectDiff::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectDiff::*)() const>(&IFSelect_SelectDiff::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectEntityNumber from ./opencascade/IFSelect_SelectEntityNumber.hxx
    klass = m.attr("IFSelect_SelectEntityNumber");


    // nested enums

    static_cast<py::class_<IFSelect_SelectEntityNumber ,opencascade::handle<IFSelect_SelectEntityNumber>  , IFSelect_SelectBase >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetNumber",
             (void (IFSelect_SelectEntityNumber::*)(  const handle<IFSelect_IntParam> &  ) ) static_cast<void (IFSelect_SelectEntityNumber::*)(  const handle<IFSelect_IntParam> &  ) >(&IFSelect_SelectEntityNumber::SetNumber),
             R"#(Sets Entity Number to be taken (initially, none is set : 0))#"  , py::arg("num")
          )
        .def("Number",
             (handle<IFSelect_IntParam> (IFSelect_SelectEntityNumber::*)() const) static_cast<handle<IFSelect_IntParam> (IFSelect_SelectEntityNumber::*)() const>(&IFSelect_SelectEntityNumber::Number),
             R"#(Returns specified Number (as a Parameter))#" 
          )
        .def("Label",
             (TCollection_AsciiString (IFSelect_SelectEntityNumber::*)() const) static_cast<TCollection_AsciiString (IFSelect_SelectEntityNumber::*)() const>(&IFSelect_SelectEntityNumber::Label),
             R"#(Returns a text defining the criterium : "Entity Number ...")#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectEntityNumber::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectEntityNumber::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectEntityNumber::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectEntityNumber::*)() const>(&IFSelect_SelectEntityNumber::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectExplore from ./opencascade/IFSelect_SelectExplore.hxx
    klass = m.attr("IFSelect_SelectExplore");


    // nested enums

    static_cast<py::class_<IFSelect_SelectExplore ,opencascade::handle<IFSelect_SelectExplore> ,Py_IFSelect_SelectExplore , IFSelect_SelectDeduct >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("Level",
             (int (IFSelect_SelectExplore::*)() const) static_cast<int (IFSelect_SelectExplore::*)() const>(&IFSelect_SelectExplore::Level),
             R"#(Returns the required exploring level)#" 
          )
        .def("Label",
             (TCollection_AsciiString (IFSelect_SelectExplore::*)() const) static_cast<TCollection_AsciiString (IFSelect_SelectExplore::*)() const>(&IFSelect_SelectExplore::Label),
             R"#(Returns a text saying "(Recursive)" or "(Level nn)" plus specific criterium returned by ExploreLabel (see below))#" 
          )
        .def("ExploreLabel",
             (TCollection_AsciiString (IFSelect_SelectExplore::*)() const) static_cast<TCollection_AsciiString (IFSelect_SelectExplore::*)() const>(&IFSelect_SelectExplore::ExploreLabel),
             R"#(Returns a text defining the way of exploration)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectExplore::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectExplore::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectExplore::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectExplore::*)() const>(&IFSelect_SelectExplore::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectExtract from ./opencascade/IFSelect_SelectExtract.hxx
    klass = m.attr("IFSelect_SelectExtract");


    // nested enums

    static_cast<py::class_<IFSelect_SelectExtract ,opencascade::handle<IFSelect_SelectExtract> ,Py_IFSelect_SelectExtract , IFSelect_SelectDeduct >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("IsDirect",
             (bool (IFSelect_SelectExtract::*)() const) static_cast<bool (IFSelect_SelectExtract::*)() const>(&IFSelect_SelectExtract::IsDirect),
             R"#(Returns True if Sort criterium is Direct, False if Reverse)#" 
          )
        .def("SetDirect",
             (void (IFSelect_SelectExtract::*)(  const bool  ) ) static_cast<void (IFSelect_SelectExtract::*)(  const bool  ) >(&IFSelect_SelectExtract::SetDirect),
             R"#(Sets Sort criterium sense to a new value (True : Direct , False : Reverse))#"  , py::arg("direct")
          )
        .def("Label",
             (TCollection_AsciiString (IFSelect_SelectExtract::*)() const) static_cast<TCollection_AsciiString (IFSelect_SelectExtract::*)() const>(&IFSelect_SelectExtract::Label),
             R"#(Returns a text saying "Picked" or "Removed", plus the specific criterium returned by ExtractLabel (see below))#" 
          )
        .def("ExtractLabel",
             (TCollection_AsciiString (IFSelect_SelectExtract::*)() const) static_cast<TCollection_AsciiString (IFSelect_SelectExtract::*)() const>(&IFSelect_SelectExtract::ExtractLabel),
             R"#(Returns a text defining the criterium for extraction)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectExtract::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectExtract::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectExtract::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectExtract::*)() const>(&IFSelect_SelectExtract::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectIntersection from ./opencascade/IFSelect_SelectIntersection.hxx
    klass = m.attr("IFSelect_SelectIntersection");


    // nested enums

    static_cast<py::class_<IFSelect_SelectIntersection ,opencascade::handle<IFSelect_SelectIntersection>  , IFSelect_SelectCombine >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Label",
             (TCollection_AsciiString (IFSelect_SelectIntersection::*)() const) static_cast<TCollection_AsciiString (IFSelect_SelectIntersection::*)() const>(&IFSelect_SelectIntersection::Label),
             R"#(Returns a text defining the criterium : "Intersection (AND)")#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectIntersection::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectIntersection::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectIntersection::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectIntersection::*)() const>(&IFSelect_SelectIntersection::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectModelEntities from ./opencascade/IFSelect_SelectModelEntities.hxx
    klass = m.attr("IFSelect_SelectModelEntities");


    // nested enums

    static_cast<py::class_<IFSelect_SelectModelEntities ,opencascade::handle<IFSelect_SelectModelEntities>  , IFSelect_SelectBase >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Label",
             (TCollection_AsciiString (IFSelect_SelectModelEntities::*)() const) static_cast<TCollection_AsciiString (IFSelect_SelectModelEntities::*)() const>(&IFSelect_SelectModelEntities::Label),
             R"#(Returns a text defining the criterium : "Model Entities")#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectModelEntities::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectModelEntities::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectModelEntities::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectModelEntities::*)() const>(&IFSelect_SelectModelEntities::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectModelRoots from ./opencascade/IFSelect_SelectModelRoots.hxx
    klass = m.attr("IFSelect_SelectModelRoots");


    // nested enums

    static_cast<py::class_<IFSelect_SelectModelRoots ,opencascade::handle<IFSelect_SelectModelRoots>  , IFSelect_SelectBase >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Label",
             (TCollection_AsciiString (IFSelect_SelectModelRoots::*)() const) static_cast<TCollection_AsciiString (IFSelect_SelectModelRoots::*)() const>(&IFSelect_SelectModelRoots::Label),
             R"#(Returns a text defining the criterium : "Model Roots")#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectModelRoots::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectModelRoots::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectModelRoots::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectModelRoots::*)() const>(&IFSelect_SelectModelRoots::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectPointed from ./opencascade/IFSelect_SelectPointed.hxx
    klass = m.attr("IFSelect_SelectPointed");


    // nested enums

    static_cast<py::class_<IFSelect_SelectPointed ,opencascade::handle<IFSelect_SelectPointed>  , IFSelect_SelectBase >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Clear",
             (void (IFSelect_SelectPointed::*)() ) static_cast<void (IFSelect_SelectPointed::*)() >(&IFSelect_SelectPointed::Clear),
             R"#(Clears the list of selected items Also says the list is unset All Add* methods and SetList say the list is set)#" 
          )
        .def("IsSet",
             (bool (IFSelect_SelectPointed::*)() const) static_cast<bool (IFSelect_SelectPointed::*)() const>(&IFSelect_SelectPointed::IsSet),
             R"#(Tells if the list has been set. Even if empty)#" 
          )
        .def("SetEntity",
             (void (IFSelect_SelectPointed::*)(  const handle<Standard_Transient> &  ) ) static_cast<void (IFSelect_SelectPointed::*)(  const handle<Standard_Transient> &  ) >(&IFSelect_SelectPointed::SetEntity),
             R"#(As SetList but with only one entity If <ent> is Null, the list is said as being set but is empty)#"  , py::arg("item")
          )
        .def("SetList",
             (void (IFSelect_SelectPointed::*)(  const handle<NCollection_HSequence<handle<Standard_Transient>>> &  ) ) static_cast<void (IFSelect_SelectPointed::*)(  const handle<NCollection_HSequence<handle<Standard_Transient>>> &  ) >(&IFSelect_SelectPointed::SetList),
             R"#(Sets a given list to define the list of selected items <list> can be empty or null : in this case, the list is said as being set, but it is empty)#"  , py::arg("list")
          )
        .def("Add",
             (bool (IFSelect_SelectPointed::*)(  const handle<Standard_Transient> &  ) ) static_cast<bool (IFSelect_SelectPointed::*)(  const handle<Standard_Transient> &  ) >(&IFSelect_SelectPointed::Add),
             R"#(Adds an item. Returns True if Done, False if <item> is already in the selected list)#"  , py::arg("item")
          )
        .def("Remove",
             (bool (IFSelect_SelectPointed::*)(  const handle<Standard_Transient> &  ) ) static_cast<bool (IFSelect_SelectPointed::*)(  const handle<Standard_Transient> &  ) >(&IFSelect_SelectPointed::Remove),
             R"#(Removes an item. Returns True if Done, False if <item> was not in the selected list)#"  , py::arg("item")
          )
        .def("Toggle",
             (bool (IFSelect_SelectPointed::*)(  const handle<Standard_Transient> &  ) ) static_cast<bool (IFSelect_SelectPointed::*)(  const handle<Standard_Transient> &  ) >(&IFSelect_SelectPointed::Toggle),
             R"#(Toggles status of an item : adds it if not pointed or removes it if already pointed. Returns the new status (Pointed or not))#"  , py::arg("item")
          )
        .def("AddList",
             (bool (IFSelect_SelectPointed::*)(  const handle<NCollection_HSequence<handle<Standard_Transient>>> &  ) ) static_cast<bool (IFSelect_SelectPointed::*)(  const handle<NCollection_HSequence<handle<Standard_Transient>>> &  ) >(&IFSelect_SelectPointed::AddList),
             R"#(Adds all the items defined in a list. Returns True if at least one item has been added, False else)#"  , py::arg("list")
          )
        .def("RemoveList",
             (bool (IFSelect_SelectPointed::*)(  const handle<NCollection_HSequence<handle<Standard_Transient>>> &  ) ) static_cast<bool (IFSelect_SelectPointed::*)(  const handle<NCollection_HSequence<handle<Standard_Transient>>> &  ) >(&IFSelect_SelectPointed::RemoveList),
             R"#(Removes all the items defined in a list. Returns True if at least one item has been removed, False else)#"  , py::arg("list")
          )
        .def("ToggleList",
             (bool (IFSelect_SelectPointed::*)(  const handle<NCollection_HSequence<handle<Standard_Transient>>> &  ) ) static_cast<bool (IFSelect_SelectPointed::*)(  const handle<NCollection_HSequence<handle<Standard_Transient>>> &  ) >(&IFSelect_SelectPointed::ToggleList),
             R"#(Toggles status of all the items defined in a list : adds it if not pointed or removes it if already pointed.)#"  , py::arg("list")
          )
        .def("Rank",
             (int (IFSelect_SelectPointed::*)(  const handle<Standard_Transient> &  ) const) static_cast<int (IFSelect_SelectPointed::*)(  const handle<Standard_Transient> &  ) const>(&IFSelect_SelectPointed::Rank),
             R"#(Returns the rank of an item in the selected list, or 0.)#"  , py::arg("item")
          )
        .def("NbItems",
             (int (IFSelect_SelectPointed::*)() const) static_cast<int (IFSelect_SelectPointed::*)() const>(&IFSelect_SelectPointed::NbItems),
             R"#(Returns the count of selected items)#" 
          )
        .def("Item",
             (handle<Standard_Transient> (IFSelect_SelectPointed::*)(  const int  ) const) static_cast<handle<Standard_Transient> (IFSelect_SelectPointed::*)(  const int  ) const>(&IFSelect_SelectPointed::Item),
             R"#(Returns an item given its rank, or a Null Handle)#"  , py::arg("num")
          )
        .def("Update",
             (void (IFSelect_SelectPointed::*)(  const handle<IFSelect_Transformer> &  ) ) static_cast<void (IFSelect_SelectPointed::*)(  const handle<IFSelect_Transformer> &  ) >(&IFSelect_SelectPointed::Update),
             R"#(Rebuilds the selected list, by querying a Transformer (same principle as from a CopyControl))#"  , py::arg("trf")
          )
        .def("Label",
             (TCollection_AsciiString (IFSelect_SelectPointed::*)() const) static_cast<TCollection_AsciiString (IFSelect_SelectPointed::*)() const>(&IFSelect_SelectPointed::Label),
             R"#(Returns a text which identifies the type of selection made. It is "Pointed Entities")#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectPointed::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectPointed::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectPointed::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectPointed::*)() const>(&IFSelect_SelectPointed::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectShared from ./opencascade/IFSelect_SelectShared.hxx
    klass = m.attr("IFSelect_SelectShared");


    // nested enums

    static_cast<py::class_<IFSelect_SelectShared ,opencascade::handle<IFSelect_SelectShared>  , IFSelect_SelectDeduct >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Label",
             (TCollection_AsciiString (IFSelect_SelectShared::*)() const) static_cast<TCollection_AsciiString (IFSelect_SelectShared::*)() const>(&IFSelect_SelectShared::Label),
             R"#(Returns a text defining the criterium : "Shared (one level)")#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectShared::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectShared::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectShared::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectShared::*)() const>(&IFSelect_SelectShared::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectSharing from ./opencascade/IFSelect_SelectSharing.hxx
    klass = m.attr("IFSelect_SelectSharing");


    // nested enums

    static_cast<py::class_<IFSelect_SelectSharing ,opencascade::handle<IFSelect_SelectSharing>  , IFSelect_SelectDeduct >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Label",
             (TCollection_AsciiString (IFSelect_SelectSharing::*)() const) static_cast<TCollection_AsciiString (IFSelect_SelectSharing::*)() const>(&IFSelect_SelectSharing::Label),
             R"#(Returns a text defining the criterium : "Sharing (one level)")#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectSharing::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectSharing::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectSharing::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectSharing::*)() const>(&IFSelect_SelectSharing::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectSuite from ./opencascade/IFSelect_SelectSuite.hxx
    klass = m.attr("IFSelect_SelectSuite");


    // nested enums

    static_cast<py::class_<IFSelect_SelectSuite ,opencascade::handle<IFSelect_SelectSuite>  , IFSelect_SelectDeduct >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("AddInput",
             (bool (IFSelect_SelectSuite::*)(  const handle<IFSelect_Selection> &  ) ) static_cast<bool (IFSelect_SelectSuite::*)(  const handle<IFSelect_Selection> &  ) >(&IFSelect_SelectSuite::AddInput),
             R"#(Adds an input selection. I.E. : If <item> is a SelectDeduct, adds it as Previous, not as Input Else, sets it as Input Returns True when done Returns False and refuses to work if Input is already defined)#"  , py::arg("item")
          )
        .def("AddPrevious",
             (void (IFSelect_SelectSuite::*)(  const handle<IFSelect_SelectDeduct> &  ) ) static_cast<void (IFSelect_SelectSuite::*)(  const handle<IFSelect_SelectDeduct> &  ) >(&IFSelect_SelectSuite::AddPrevious),
             R"#(Adds a new first item (prepends to the list). The Input is not touched If <item> is null, does nothing)#"  , py::arg("item")
          )
        .def("AddNext",
             (void (IFSelect_SelectSuite::*)(  const handle<IFSelect_SelectDeduct> &  ) ) static_cast<void (IFSelect_SelectSuite::*)(  const handle<IFSelect_SelectDeduct> &  ) >(&IFSelect_SelectSuite::AddNext),
             R"#(Adds a new last item (prepends to the list) If <item> is null, does nothing)#"  , py::arg("item")
          )
        .def("NbItems",
             (int (IFSelect_SelectSuite::*)() const) static_cast<int (IFSelect_SelectSuite::*)() const>(&IFSelect_SelectSuite::NbItems),
             R"#(Returns the count of Items)#" 
          )
        .def("Item",
             (handle<IFSelect_SelectDeduct> (IFSelect_SelectSuite::*)(  const int  ) const) static_cast<handle<IFSelect_SelectDeduct> (IFSelect_SelectSuite::*)(  const int  ) const>(&IFSelect_SelectSuite::Item),
             R"#(Returns an item from its rank in the list (the Input is always apart))#"  , py::arg("num")
          )
        .def("SetLabel",
             (void (IFSelect_SelectSuite::*)(  const char * const   ) ) static_cast<void (IFSelect_SelectSuite::*)(  const char * const   ) >(&IFSelect_SelectSuite::SetLabel),
             R"#(Sets a value for the Label)#"  , py::arg("lab")
          )
        .def("Label",
             (TCollection_AsciiString (IFSelect_SelectSuite::*)() const) static_cast<TCollection_AsciiString (IFSelect_SelectSuite::*)() const>(&IFSelect_SelectSuite::Label),
             R"#(Returns the Label Either it has been defined by SetLabel, or it will give "Suite of nn Selections")#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectSuite::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectSuite::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectSuite::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectSuite::*)() const>(&IFSelect_SelectSuite::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectUnion from ./opencascade/IFSelect_SelectUnion.hxx
    klass = m.attr("IFSelect_SelectUnion");


    // nested enums

    static_cast<py::class_<IFSelect_SelectUnion ,opencascade::handle<IFSelect_SelectUnion>  , IFSelect_SelectCombine >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Label",
             (TCollection_AsciiString (IFSelect_SelectUnion::*)() const) static_cast<TCollection_AsciiString (IFSelect_SelectUnion::*)() const>(&IFSelect_SelectUnion::Label),
             R"#(Returns a text defining the criterium : "Union (OR)")#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectUnion::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectUnion::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectUnion::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectUnion::*)() const>(&IFSelect_SelectUnion::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SignAncestor from ./opencascade/IFSelect_SignAncestor.hxx
    klass = m.attr("IFSelect_SignAncestor");


    // nested enums

    static_cast<py::class_<IFSelect_SignAncestor ,opencascade::handle<IFSelect_SignAncestor>  , IFSelect_SignType >>(klass)
    // constructors
        .def(py::init<  const bool >()  , py::arg("nopk")=static_cast< const bool>(false) )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SignAncestor::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SignAncestor::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SignAncestor::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SignAncestor::*)() const>(&IFSelect_SignAncestor::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectAnyType from ./opencascade/IFSelect_SelectAnyType.hxx
    klass = m.attr("IFSelect_SelectAnyType");


    // nested enums

    static_cast<py::class_<IFSelect_SelectAnyType ,opencascade::handle<IFSelect_SelectAnyType> ,Py_IFSelect_SelectAnyType , IFSelect_SelectExtract >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("TypeForMatch",
             (handle<Standard_Type> (IFSelect_SelectAnyType::*)() const) static_cast<handle<Standard_Type> (IFSelect_SelectAnyType::*)() const>(&IFSelect_SelectAnyType::TypeForMatch),
             R"#(Returns the Type which has to be matched for select)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectAnyType::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectAnyType::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectAnyType::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectAnyType::*)() const>(&IFSelect_SelectAnyType::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectErrorEntities from ./opencascade/IFSelect_SelectErrorEntities.hxx
    klass = m.attr("IFSelect_SelectErrorEntities");


    // nested enums

    static_cast<py::class_<IFSelect_SelectErrorEntities ,opencascade::handle<IFSelect_SelectErrorEntities>  , IFSelect_SelectExtract >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ExtractLabel",
             (TCollection_AsciiString (IFSelect_SelectErrorEntities::*)() const) static_cast<TCollection_AsciiString (IFSelect_SelectErrorEntities::*)() const>(&IFSelect_SelectErrorEntities::ExtractLabel),
             R"#(Returns a text defining the criterium : "Error Entities")#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectErrorEntities::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectErrorEntities::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectErrorEntities::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectErrorEntities::*)() const>(&IFSelect_SelectErrorEntities::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectFlag from ./opencascade/IFSelect_SelectFlag.hxx
    klass = m.attr("IFSelect_SelectFlag");


    // nested enums

    static_cast<py::class_<IFSelect_SelectFlag ,opencascade::handle<IFSelect_SelectFlag>  , IFSelect_SelectExtract >>(klass)
    // constructors
        .def(py::init<  const char * const  >()  , py::arg("flagname") )
    // custom constructors
    // methods
        .def("FlagName",
             ( const char * (IFSelect_SelectFlag::*)() const) static_cast< const char * (IFSelect_SelectFlag::*)() const>(&IFSelect_SelectFlag::FlagName),
             R"#(Returns the name of the flag)#" 
          )
        .def("ExtractLabel",
             (TCollection_AsciiString (IFSelect_SelectFlag::*)() const) static_cast<TCollection_AsciiString (IFSelect_SelectFlag::*)() const>(&IFSelect_SelectFlag::ExtractLabel),
             R"#(Returns a text defining the criterium, includes the flag name)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectFlag::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectFlag::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectFlag::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectFlag::*)() const>(&IFSelect_SelectFlag::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectInList from ./opencascade/IFSelect_SelectInList.hxx
    klass = m.attr("IFSelect_SelectInList");


    // nested enums

    static_cast<py::class_<IFSelect_SelectInList ,opencascade::handle<IFSelect_SelectInList> ,Py_IFSelect_SelectInList , IFSelect_SelectAnyList >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("ListedEntity",
             (handle<Standard_Transient> (IFSelect_SelectInList::*)(  const int ,   const handle<Standard_Transient> &  ) const) static_cast<handle<Standard_Transient> (IFSelect_SelectInList::*)(  const int ,   const handle<Standard_Transient> &  ) const>(&IFSelect_SelectInList::ListedEntity),
             R"#(Returns an Entity, given its rank in the list)#"  , py::arg("num"),  py::arg("ent")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectInList::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectInList::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectInList::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectInList::*)() const>(&IFSelect_SelectInList::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectRange from ./opencascade/IFSelect_SelectRange.hxx
    klass = m.attr("IFSelect_SelectRange");


    // nested enums

    static_cast<py::class_<IFSelect_SelectRange ,opencascade::handle<IFSelect_SelectRange>  , IFSelect_SelectExtract >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetRange",
             (void (IFSelect_SelectRange::*)(  const handle<IFSelect_IntParam> & ,   const handle<IFSelect_IntParam> &  ) ) static_cast<void (IFSelect_SelectRange::*)(  const handle<IFSelect_IntParam> & ,   const handle<IFSelect_IntParam> &  ) >(&IFSelect_SelectRange::SetRange),
             R"#(Sets a Range for numbers, with a lower and a upper limits Error if rankto is lower then rankfrom)#"  , py::arg("rankfrom"),  py::arg("rankto")
          )
        .def("SetOne",
             (void (IFSelect_SelectRange::*)(  const handle<IFSelect_IntParam> &  ) ) static_cast<void (IFSelect_SelectRange::*)(  const handle<IFSelect_IntParam> &  ) >(&IFSelect_SelectRange::SetOne),
             R"#(Sets a unique number (only one Entity will be sorted as True))#"  , py::arg("rank")
          )
        .def("SetFrom",
             (void (IFSelect_SelectRange::*)(  const handle<IFSelect_IntParam> &  ) ) static_cast<void (IFSelect_SelectRange::*)(  const handle<IFSelect_IntParam> &  ) >(&IFSelect_SelectRange::SetFrom),
             R"#(Sets a Lower limit but no upper limit)#"  , py::arg("rankfrom")
          )
        .def("SetUntil",
             (void (IFSelect_SelectRange::*)(  const handle<IFSelect_IntParam> &  ) ) static_cast<void (IFSelect_SelectRange::*)(  const handle<IFSelect_IntParam> &  ) >(&IFSelect_SelectRange::SetUntil),
             R"#(Sets an Upper limit but no lower limit (equivalent to lower 1))#"  , py::arg("rankto")
          )
        .def("HasLower",
             (bool (IFSelect_SelectRange::*)() const) static_cast<bool (IFSelect_SelectRange::*)() const>(&IFSelect_SelectRange::HasLower),
             R"#(Returns True if a Lower limit is defined)#" 
          )
        .def("Lower",
             (handle<IFSelect_IntParam> (IFSelect_SelectRange::*)() const) static_cast<handle<IFSelect_IntParam> (IFSelect_SelectRange::*)() const>(&IFSelect_SelectRange::Lower),
             R"#(Returns Lower limit (if there is; else, value is senseless))#" 
          )
        .def("LowerValue",
             (int (IFSelect_SelectRange::*)() const) static_cast<int (IFSelect_SelectRange::*)() const>(&IFSelect_SelectRange::LowerValue),
             R"#(Returns Value of Lower Limit (0 if none is defined))#" 
          )
        .def("HasUpper",
             (bool (IFSelect_SelectRange::*)() const) static_cast<bool (IFSelect_SelectRange::*)() const>(&IFSelect_SelectRange::HasUpper),
             R"#(Returns True if a Lower limit is defined)#" 
          )
        .def("Upper",
             (handle<IFSelect_IntParam> (IFSelect_SelectRange::*)() const) static_cast<handle<IFSelect_IntParam> (IFSelect_SelectRange::*)() const>(&IFSelect_SelectRange::Upper),
             R"#(Returns Upper limit (if there is; else, value is senseless))#" 
          )
        .def("UpperValue",
             (int (IFSelect_SelectRange::*)() const) static_cast<int (IFSelect_SelectRange::*)() const>(&IFSelect_SelectRange::UpperValue),
             R"#(Returns Value of Upper Limit (0 if none is defined))#" 
          )
        .def("ExtractLabel",
             (TCollection_AsciiString (IFSelect_SelectRange::*)() const) static_cast<TCollection_AsciiString (IFSelect_SelectRange::*)() const>(&IFSelect_SelectRange::ExtractLabel),
             R"#(Returns a text defining the criterium : following cases, " From .. Until .." or "From .." or "Until .." or "Rank no ..")#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectRange::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectRange::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectRange::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectRange::*)() const>(&IFSelect_SelectRange::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectRootComps from ./opencascade/IFSelect_SelectRootComps.hxx
    klass = m.attr("IFSelect_SelectRootComps");


    // nested enums

    static_cast<py::class_<IFSelect_SelectRootComps ,opencascade::handle<IFSelect_SelectRootComps>  , IFSelect_SelectExtract >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ExtractLabel",
             (TCollection_AsciiString (IFSelect_SelectRootComps::*)() const) static_cast<TCollection_AsciiString (IFSelect_SelectRootComps::*)() const>(&IFSelect_SelectRootComps::ExtractLabel),
             R"#(Returns a text defining the criterium : "Local Root Components")#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectRootComps::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectRootComps::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectRootComps::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectRootComps::*)() const>(&IFSelect_SelectRootComps::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectRoots from ./opencascade/IFSelect_SelectRoots.hxx
    klass = m.attr("IFSelect_SelectRoots");


    // nested enums

    static_cast<py::class_<IFSelect_SelectRoots ,opencascade::handle<IFSelect_SelectRoots>  , IFSelect_SelectExtract >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ExtractLabel",
             (TCollection_AsciiString (IFSelect_SelectRoots::*)() const) static_cast<TCollection_AsciiString (IFSelect_SelectRoots::*)() const>(&IFSelect_SelectRoots::ExtractLabel),
             R"#(Returns a text defining the criterium : "Local Root Entities")#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectRoots::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectRoots::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectRoots::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectRoots::*)() const>(&IFSelect_SelectRoots::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectSent from ./opencascade/IFSelect_SelectSent.hxx
    klass = m.attr("IFSelect_SelectSent");


    // nested enums

    static_cast<py::class_<IFSelect_SelectSent ,opencascade::handle<IFSelect_SelectSent>  , IFSelect_SelectExtract >>(klass)
    // constructors
        .def(py::init<  const int, const bool >()  , py::arg("sentcount")=static_cast< const int>(1),  py::arg("atleast")=static_cast< const bool>(true) )
    // custom constructors
    // methods
        .def("SentCount",
             (int (IFSelect_SelectSent::*)() const) static_cast<int (IFSelect_SelectSent::*)() const>(&IFSelect_SelectSent::SentCount),
             R"#(Returns the queried count of sending)#" 
          )
        .def("AtLeast",
             (bool (IFSelect_SelectSent::*)() const) static_cast<bool (IFSelect_SelectSent::*)() const>(&IFSelect_SelectSent::AtLeast),
             R"#(Returns the <atleast> status, True for sending at least the sending count, False for sending exactly the sending count Remark : if SentCount is 0, AtLeast is ignored)#" 
          )
        .def("ExtractLabel",
             (TCollection_AsciiString (IFSelect_SelectSent::*)() const) static_cast<TCollection_AsciiString (IFSelect_SelectSent::*)() const>(&IFSelect_SelectSent::ExtractLabel),
             R"#(Returns a text defining the criterium : query : SentCount = 0 -> "Remaining (non-sent) entities" SentCount = 1, AtLeast = True -> "Sent entities" SentCount = 1, AtLeast = False -> "Sent once (no duplicated)" SentCount = 2, AtLeast = True -> "Sent several times entities" SentCount = 2, AtLeast = False -> "Sent twice entities" SentCount > 2, AtLeast = True -> "Sent at least <count> times entities" SentCount > 2, AtLeast = False -> "Sent <count> times entities")#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectSent::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectSent::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectSent::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectSent::*)() const>(&IFSelect_SelectSent::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectSignature from ./opencascade/IFSelect_SelectSignature.hxx
    klass = m.attr("IFSelect_SelectSignature");


    // nested enums

    static_cast<py::class_<IFSelect_SelectSignature ,opencascade::handle<IFSelect_SelectSignature>  , IFSelect_SelectExtract >>(klass)
    // constructors
        .def(py::init<  const handle<IFSelect_SignCounter> &, const char * const , const bool >()  , py::arg("matcher"),  py::arg("signtext"),  py::arg("exact")=static_cast< const bool>(true) )
        .def(py::init<  const handle<IFSelect_Signature> &, const TCollection_AsciiString &, const bool >()  , py::arg("matcher"),  py::arg("signtext"),  py::arg("exact")=static_cast< const bool>(true) )
        .def(py::init<  const handle<IFSelect_Signature> &, const char * const , const bool >()  , py::arg("matcher"),  py::arg("signtext"),  py::arg("exact")=static_cast< const bool>(true) )
    // custom constructors
    // methods
        .def("Signature",
             (handle<IFSelect_Signature> (IFSelect_SelectSignature::*)() const) static_cast<handle<IFSelect_Signature> (IFSelect_SelectSignature::*)() const>(&IFSelect_SelectSignature::Signature),
             R"#(Returns the used Signature, then it is possible to access it, modify it as required. Can be null, hence see Counter)#" 
          )
        .def("Counter",
             (handle<IFSelect_SignCounter> (IFSelect_SelectSignature::*)() const) static_cast<handle<IFSelect_SignCounter> (IFSelect_SelectSignature::*)() const>(&IFSelect_SelectSignature::Counter),
             R"#(Returns the used SignCounter. Can be used as alternative for Signature)#" 
          )
        .def("IsExact",
             (bool (IFSelect_SelectSignature::*)() const) static_cast<bool (IFSelect_SelectSignature::*)() const>(&IFSelect_SelectSignature::IsExact),
             R"#(Returns True if match must be exact)#" 
          )
        .def("ExtractLabel",
             (TCollection_AsciiString (IFSelect_SelectSignature::*)() const) static_cast<TCollection_AsciiString (IFSelect_SelectSignature::*)() const>(&IFSelect_SelectSignature::ExtractLabel),
             R"#(Returns a text defining the criterium. (it refers to the text and exact flag to be matched, and is qualified by the Name provided by the Signature))#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectSignature::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectSignature::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("SignatureText",
             ( const TCollection_AsciiString & (IFSelect_SelectSignature::*)() const) static_cast< const TCollection_AsciiString & (IFSelect_SelectSignature::*)() const>(&IFSelect_SelectSignature::SignatureText),
             R"#(Returns Text used to Sort Entity on its Signature or SignCounter)#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectSignature::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectSignature::*)() const>(&IFSelect_SelectSignature::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectSignedShared from ./opencascade/IFSelect_SelectSignedShared.hxx
    klass = m.attr("IFSelect_SelectSignedShared");


    // nested enums

    static_cast<py::class_<IFSelect_SelectSignedShared ,opencascade::handle<IFSelect_SelectSignedShared>  , IFSelect_SelectExplore >>(klass)
    // constructors
        .def(py::init<  const handle<IFSelect_Signature> &, const char * const , const bool, const int >()  , py::arg("matcher"),  py::arg("signtext"),  py::arg("exact")=static_cast< const bool>(true),  py::arg("level")=static_cast< const int>(0) )
    // custom constructors
    // methods
        .def("Signature",
             (handle<IFSelect_Signature> (IFSelect_SelectSignedShared::*)() const) static_cast<handle<IFSelect_Signature> (IFSelect_SelectSignedShared::*)() const>(&IFSelect_SelectSignedShared::Signature),
             R"#(Returns the used Signature, then it is possible to access it, modify it as required)#" 
          )
        .def("IsExact",
             (bool (IFSelect_SelectSignedShared::*)() const) static_cast<bool (IFSelect_SelectSignedShared::*)() const>(&IFSelect_SelectSignedShared::IsExact),
             R"#(Returns True if match must be exact)#" 
          )
        .def("ExploreLabel",
             (TCollection_AsciiString (IFSelect_SelectSignedShared::*)() const) static_cast<TCollection_AsciiString (IFSelect_SelectSignedShared::*)() const>(&IFSelect_SelectSignedShared::ExploreLabel),
             R"#(Returns a text defining the criterium. (it refers to the text and exact flag to be matched, and is qualified by the Name provided by the Signature))#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectSignedShared::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectSignedShared::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("SignatureText",
             ( const TCollection_AsciiString & (IFSelect_SelectSignedShared::*)() const) static_cast< const TCollection_AsciiString & (IFSelect_SelectSignedShared::*)() const>(&IFSelect_SelectSignedShared::SignatureText),
             R"#(Returns Text used to Sort Entity on its Signature)#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectSignedShared::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectSignedShared::*)() const>(&IFSelect_SelectSignedShared::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectSignedSharing from ./opencascade/IFSelect_SelectSignedSharing.hxx
    klass = m.attr("IFSelect_SelectSignedSharing");


    // nested enums

    static_cast<py::class_<IFSelect_SelectSignedSharing ,opencascade::handle<IFSelect_SelectSignedSharing>  , IFSelect_SelectExplore >>(klass)
    // constructors
        .def(py::init<  const handle<IFSelect_Signature> &, const char * const , const bool, const int >()  , py::arg("matcher"),  py::arg("signtext"),  py::arg("exact")=static_cast< const bool>(true),  py::arg("level")=static_cast< const int>(0) )
    // custom constructors
    // methods
        .def("Signature",
             (handle<IFSelect_Signature> (IFSelect_SelectSignedSharing::*)() const) static_cast<handle<IFSelect_Signature> (IFSelect_SelectSignedSharing::*)() const>(&IFSelect_SelectSignedSharing::Signature),
             R"#(Returns the used Signature, then it is possible to access it, modify it as required)#" 
          )
        .def("IsExact",
             (bool (IFSelect_SelectSignedSharing::*)() const) static_cast<bool (IFSelect_SelectSignedSharing::*)() const>(&IFSelect_SelectSignedSharing::IsExact),
             R"#(Returns True if match must be exact)#" 
          )
        .def("ExploreLabel",
             (TCollection_AsciiString (IFSelect_SelectSignedSharing::*)() const) static_cast<TCollection_AsciiString (IFSelect_SelectSignedSharing::*)() const>(&IFSelect_SelectSignedSharing::ExploreLabel),
             R"#(Returns a text defining the criterium. (it refers to the text and exact flag to be matched, and is qualified by the Name provided by the Signature))#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectSignedSharing::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectSignedSharing::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("SignatureText",
             ( const TCollection_AsciiString & (IFSelect_SelectSignedSharing::*)() const) static_cast< const TCollection_AsciiString & (IFSelect_SelectSignedSharing::*)() const>(&IFSelect_SelectSignedSharing::SignatureText),
             R"#(Returns Text used to Sort Entity on its Signature)#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectSignedSharing::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectSignedSharing::*)() const>(&IFSelect_SelectSignedSharing::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectUnknownEntities from ./opencascade/IFSelect_SelectUnknownEntities.hxx
    klass = m.attr("IFSelect_SelectUnknownEntities");


    // nested enums

    static_cast<py::class_<IFSelect_SelectUnknownEntities ,opencascade::handle<IFSelect_SelectUnknownEntities>  , IFSelect_SelectExtract >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("ExtractLabel",
             (TCollection_AsciiString (IFSelect_SelectUnknownEntities::*)() const) static_cast<TCollection_AsciiString (IFSelect_SelectUnknownEntities::*)() const>(&IFSelect_SelectUnknownEntities::ExtractLabel),
             R"#(Returns a text defining the criterium : "Recognized Entities")#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectUnknownEntities::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectUnknownEntities::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectUnknownEntities::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectUnknownEntities::*)() const>(&IFSelect_SelectUnknownEntities::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectIncorrectEntities from ./opencascade/IFSelect_SelectIncorrectEntities.hxx
    klass = m.attr("IFSelect_SelectIncorrectEntities");


    // nested enums

    static_cast<py::class_<IFSelect_SelectIncorrectEntities ,opencascade::handle<IFSelect_SelectIncorrectEntities>  , IFSelect_SelectFlag >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectIncorrectEntities::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectIncorrectEntities::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectIncorrectEntities::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectIncorrectEntities::*)() const>(&IFSelect_SelectIncorrectEntities::DynamicType),
             R"#()#"
             
         )
;

    // Class IFSelect_SelectType from ./opencascade/IFSelect_SelectType.hxx
    klass = m.attr("IFSelect_SelectType");


    // nested enums

    static_cast<py::class_<IFSelect_SelectType ,opencascade::handle<IFSelect_SelectType>  , IFSelect_SelectAnyType >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<Standard_Type> & >()  , py::arg("atype") )
    // custom constructors
    // methods
        .def("SetType",
             (void (IFSelect_SelectType::*)(  const handle<Standard_Type> &  ) ) static_cast<void (IFSelect_SelectType::*)(  const handle<Standard_Type> &  ) >(&IFSelect_SelectType::SetType),
             R"#(Sets a TYpe for filter)#"  , py::arg("atype")
          )
        .def("TypeForMatch",
             (handle<Standard_Type> (IFSelect_SelectType::*)() const) static_cast<handle<Standard_Type> (IFSelect_SelectType::*)() const>(&IFSelect_SelectType::TypeForMatch),
             R"#(Returns the Type to be matched for select : this is the type given at instantiation time)#" 
          )
        .def("ExtractLabel",
             (TCollection_AsciiString (IFSelect_SelectType::*)() const) static_cast<TCollection_AsciiString (IFSelect_SelectType::*)() const>(&IFSelect_SelectType::ExtractLabel),
             R"#(Returns a text defining the criterium. (should by gotten from Type of Entity used for instantiation))#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&IFSelect_SelectType::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&IFSelect_SelectType::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (IFSelect_SelectType::*)() const) static_cast< const handle<Standard_Type> & (IFSelect_SelectType::*)() const>(&IFSelect_SelectType::DynamicType),
             R"#()#"
             
         )
;

// functions

// ./opencascade/IFSelect.hxx
// ./opencascade/IFSelect_Act.hxx
// ./opencascade/IFSelect_ActFunc.hxx
// ./opencascade/IFSelect_Activator.hxx
// ./opencascade/IFSelect_AppliedModifiers.hxx
// ./opencascade/IFSelect_BasicDumper.hxx
// ./opencascade/IFSelect_CheckCounter.hxx
// ./opencascade/IFSelect_ContextModif.hxx
// ./opencascade/IFSelect_ContextWrite.hxx
// ./opencascade/IFSelect_DispGlobal.hxx
// ./opencascade/IFSelect_DispPerCount.hxx
// ./opencascade/IFSelect_DispPerFiles.hxx
// ./opencascade/IFSelect_DispPerOne.hxx
// ./opencascade/IFSelect_DispPerSignature.hxx
// ./opencascade/IFSelect_Dispatch.hxx
// ./opencascade/IFSelect_EditForm.hxx
// ./opencascade/IFSelect_EditValue.hxx
// ./opencascade/IFSelect_Editor.hxx
// ./opencascade/IFSelect_Functions.hxx
// ./opencascade/IFSelect_GeneralModifier.hxx
// ./opencascade/IFSelect_GraphCounter.hxx
// ./opencascade/IFSelect_IntParam.hxx
// ./opencascade/IFSelect_ListEditor.hxx
// ./opencascade/IFSelect_ModelCopier.hxx
// ./opencascade/IFSelect_ModifEditForm.hxx
// ./opencascade/IFSelect_ModifReorder.hxx
// ./opencascade/IFSelect_Modifier.hxx
// ./opencascade/IFSelect_PacketList.hxx
// ./opencascade/IFSelect_ParamEditor.hxx
// ./opencascade/IFSelect_PrintCount.hxx
// ./opencascade/IFSelect_PrintFail.hxx
// ./opencascade/IFSelect_RemainMode.hxx
// ./opencascade/IFSelect_ReturnStatus.hxx
// ./opencascade/IFSelect_SelectAnyList.hxx
// ./opencascade/IFSelect_SelectAnyType.hxx
// ./opencascade/IFSelect_SelectBase.hxx
// ./opencascade/IFSelect_SelectCombine.hxx
// ./opencascade/IFSelect_SelectControl.hxx
// ./opencascade/IFSelect_SelectDeduct.hxx
// ./opencascade/IFSelect_SelectDiff.hxx
// ./opencascade/IFSelect_SelectEntityNumber.hxx
// ./opencascade/IFSelect_SelectErrorEntities.hxx
// ./opencascade/IFSelect_SelectExplore.hxx
// ./opencascade/IFSelect_SelectExtract.hxx
// ./opencascade/IFSelect_SelectFlag.hxx
// ./opencascade/IFSelect_SelectInList.hxx
// ./opencascade/IFSelect_SelectIncorrectEntities.hxx
// ./opencascade/IFSelect_SelectIntersection.hxx
// ./opencascade/IFSelect_SelectModelEntities.hxx
// ./opencascade/IFSelect_SelectModelRoots.hxx
// ./opencascade/IFSelect_SelectPointed.hxx
// ./opencascade/IFSelect_SelectRange.hxx
// ./opencascade/IFSelect_SelectRootComps.hxx
// ./opencascade/IFSelect_SelectRoots.hxx
// ./opencascade/IFSelect_SelectSent.hxx
// ./opencascade/IFSelect_SelectShared.hxx
// ./opencascade/IFSelect_SelectSharing.hxx
// ./opencascade/IFSelect_SelectSignature.hxx
// ./opencascade/IFSelect_SelectSignedShared.hxx
// ./opencascade/IFSelect_SelectSignedSharing.hxx
// ./opencascade/IFSelect_SelectSuite.hxx
// ./opencascade/IFSelect_SelectType.hxx
// ./opencascade/IFSelect_SelectUnion.hxx
// ./opencascade/IFSelect_SelectUnknownEntities.hxx
// ./opencascade/IFSelect_Selection.hxx
// ./opencascade/IFSelect_SelectionIterator.hxx
// ./opencascade/IFSelect_SessionDumper.hxx
// ./opencascade/IFSelect_SessionFile.hxx
// ./opencascade/IFSelect_SessionPilot.hxx
// ./opencascade/IFSelect_ShareOut.hxx
// ./opencascade/IFSelect_ShareOutResult.hxx
// ./opencascade/IFSelect_SignAncestor.hxx
// ./opencascade/IFSelect_SignCategory.hxx
// ./opencascade/IFSelect_SignCounter.hxx
// ./opencascade/IFSelect_SignMultiple.hxx
// ./opencascade/IFSelect_SignType.hxx
// ./opencascade/IFSelect_SignValidity.hxx
// ./opencascade/IFSelect_Signature.hxx
// ./opencascade/IFSelect_SignatureList.hxx
// ./opencascade/IFSelect_TransformStandard.hxx
// ./opencascade/IFSelect_Transformer.hxx
// ./opencascade/IFSelect_WorkLibrary.hxx
// ./opencascade/IFSelect_WorkSession.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
