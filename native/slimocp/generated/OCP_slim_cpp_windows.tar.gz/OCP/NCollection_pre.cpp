
// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;


// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes
#include <gp_XYZ.hxx>
#include <gp_XY.hxx>

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <NCollection_AccAllocator.hxx>
#include <NCollection_AliasedArray.hxx>
#include <NCollection_AlignedAllocator.hxx>
#include <NCollection_Allocator.hxx>
#include <NCollection_Array1.hxx>
#include <NCollection_Array2.hxx>
#include <NCollection_BaseAllocator.hxx>
#include <NCollection_BaseList.hxx>
#include <NCollection_BaseMap.hxx>
#include <NCollection_BaseSequence.hxx>
#include <NCollection_Buffer.hxx>
#include <NCollection_CellFilter.hxx>
#include <NCollection_DataMap.hxx>
#include <NCollection_DefaultHasher.hxx>
#include <NCollection_DefineAlloc.hxx>
#include <NCollection_DefineHasher.hxx>
#include <NCollection_DoubleMap.hxx>
#include <NCollection_DynamicArray.hxx>
#include <NCollection_EBTree.hxx>
#include <NCollection_FlatDataMap.hxx>
#include <NCollection_FlatMap.hxx>
#include <NCollection_Handle.hxx>
#include <NCollection_HArray1.hxx>
#include <NCollection_HArray2.hxx>
#include <NCollection_HeapAllocator.hxx>
#include <NCollection_HSequence.hxx>
#include <NCollection_IncAllocator.hxx>
#include <NCollection_IndexedDataMap.hxx>
#include <NCollection_IndexedIterator.hxx>
#include <NCollection_IndexedMap.hxx>
#include <NCollection_Iterator.hxx>
#include <NCollection_KDTree.hxx>
#include <NCollection_Lerp.hxx>
#include <NCollection_LinearVector.hxx>
#include <NCollection_List.hxx>
#include <NCollection_ListNode.hxx>
#include <NCollection_LocalArray.hxx>
#include <NCollection_Map.hxx>
#include <NCollection_MapAlgo.hxx>
#include <NCollection_Mat3.hxx>
#include <NCollection_Mat4.hxx>
#include <NCollection_OccAllocator.hxx>
#include <NCollection_OrderedDataMap.hxx>
#include <NCollection_OrderedMap.hxx>
#include <NCollection_PackedMap.hxx>
#include <NCollection_PackedMapAlgo.hxx>
#include <NCollection_Primes.hxx>
#include <NCollection_Sequence.hxx>
#include <NCollection_SparseArray.hxx>
#include <NCollection_SparseArrayBase.hxx>
#include <NCollection_StlIterator.hxx>
#include <NCollection_String.hxx>
#include <NCollection_TListIterator.hxx>
#include <NCollection_TListNode.hxx>
#include <NCollection_UBTree.hxx>
#include <NCollection_UBTreeFiller.hxx>
#include <NCollection_UtfIterator.hxx>
#include <NCollection_UtfString.hxx>
#include <NCollection_Vec2.hxx>
#include <NCollection_Vec3.hxx>
#include <NCollection_Vec4.hxx>
#include <NCollection_Vector.hxx>
#include <NCollection_WinHeapAllocator.hxx>

// template related includes

#include "NCollection_tmpl.hxx"


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module
const size_t DefaultBlockSize = 24600;
const size_t THE_DEFAULT_BLOCK_SIZE = DefaultBlockSize;

// Module definiiton
void register_NCollection_enums(py::module &main_module) {


py::module m = main_module.def_submodule("NCollection", R"#()#");

// add namespaces as submodules
auto NCollection_PackedMapAlgo = m.def_submodule("NCollection_PackedMapAlgo");
auto NCollection_Primes = m.def_submodule("NCollection_Primes");
auto NCollection_MapAlgo = m.def_submodule("NCollection_MapAlgo");

// user-defined inclusion per module in the body

// enums
    py::enum_<NCollection_CellFilter_Action>(m, "NCollection_CellFilter_Action",R"#(Auxiliary enumeration serving as response from method Inspect)#")
        .value("CellFilter_Keep",NCollection_CellFilter_Action::CellFilter_Keep)
        .value("CellFilter_Purge",NCollection_CellFilter_Action::CellFilter_Purge).export_values();

//Python trampoline classes

// pre-register typdefs+classes (topologically sorted)
    py::class_<NCollection_BaseList , shared_ptr<NCollection_BaseList>  >(
      m,
      "NCollection_BaseList",R"#()#"
    );
    py::class_<NCollection_BaseMap , shared_ptr_nodelete<NCollection_BaseMap>  >(
      m,
      "NCollection_BaseMap",R"#(Purpose: This is a base class for all Maps: Map DataMap DoubleMap IndexedMap IndexedDataMap Provides utilitites for managing the buckets.)#"
    );
    py::class_<NCollection_BaseSequence , shared_ptr_nodelete<NCollection_BaseSequence>  >(
      m,
      "NCollection_BaseSequence",R"#(Purpose: This is a base class for the Sequence. It deals with an indexed bidirectional list of NCollection_SeqNode's.)#"
    );
    py::class_<NCollection_DefaultHasher<bool> , shared_ptr<NCollection_DefaultHasher<bool>>  >(
      m,
      "NCollection_DefaultHasher_bool",R"#(Explicit specialization for bool.)#"
    );
    py::class_<NCollection_DefaultHasher<char16_t> , shared_ptr<NCollection_DefaultHasher<char16_t>>  >(
      m,
      "NCollection_DefaultHasher_char16_t",R"#(Explicit specialization for char16_t.)#"
    );
    py::class_<NCollection_DefaultHasher<char32_t> , shared_ptr<NCollection_DefaultHasher<char32_t>>  >(
      m,
      "NCollection_DefaultHasher_char32_t",R"#(Explicit specialization for char32_t.)#"
    );
    py::class_<NCollection_DefaultHasher<char> , shared_ptr<NCollection_DefaultHasher<char>>  >(
      m,
      "NCollection_DefaultHasher_char",R"#(Explicit specialization for char.)#"
    );
    py::class_<NCollection_DefaultHasher<int> , shared_ptr<NCollection_DefaultHasher<int>>  >(
      m,
      "NCollection_DefaultHasher_int",R"#(Explicit specialization for int.)#"
    );
    py::class_<NCollection_DefaultHasher<long long> , shared_ptr<NCollection_DefaultHasher<long long>>  >(
      m,
      "NCollection_DefaultHasher_long_long",R"#(Explicit specialization for long long.)#"
    );
    py::class_<NCollection_DefaultHasher<long> , shared_ptr<NCollection_DefaultHasher<long>>  >(
      m,
      "NCollection_DefaultHasher_long",R"#(Explicit specialization for long.)#"
    );
    py::class_<NCollection_DefaultHasher<short> , shared_ptr<NCollection_DefaultHasher<short>>  >(
      m,
      "NCollection_DefaultHasher_short",R"#(Explicit specialization for short.)#"
    );
    py::class_<NCollection_DefaultHasher<signed char> , shared_ptr<NCollection_DefaultHasher<signed char>>  >(
      m,
      "NCollection_DefaultHasher_signed_char",R"#(Explicit specialization for signed char.)#"
    );
    py::class_<NCollection_DefaultHasher<unsigned char> , shared_ptr<NCollection_DefaultHasher<unsigned char>>  >(
      m,
      "NCollection_DefaultHasher_unsigned_char",R"#(Explicit specialization for unsigned char.)#"
    );
    py::class_<NCollection_DefaultHasher<unsigned int> , shared_ptr<NCollection_DefaultHasher<unsigned int>>  >(
      m,
      "NCollection_DefaultHasher_unsigned_int",R"#(Explicit specialization for unsigned int.)#"
    );
    py::class_<NCollection_DefaultHasher<unsigned long long> , shared_ptr<NCollection_DefaultHasher<unsigned long long>>  >(
      m,
      "NCollection_DefaultHasher_unsigned_long_long",R"#(Explicit specialization for unsigned long long.)#"
    );
    py::class_<NCollection_DefaultHasher<unsigned long> , shared_ptr<NCollection_DefaultHasher<unsigned long>>  >(
      m,
      "NCollection_DefaultHasher_unsigned_long",R"#(Explicit specialization for unsigned long.)#"
    );
    py::class_<NCollection_DefaultHasher<unsigned short> , shared_ptr<NCollection_DefaultHasher<unsigned short>>  >(
      m,
      "NCollection_DefaultHasher_unsigned_short",R"#(Explicit specialization for unsigned short.)#"
    );
    py::class_<NCollection_DefaultHasher<wchar_t> , shared_ptr<NCollection_DefaultHasher<wchar_t>>  >(
      m,
      "NCollection_DefaultHasher_wchar_t",R"#(Explicit specialization for wchar_t.)#"
    );
    py::class_<NCollection_SparseArrayBase , shared_ptr_nodelete<NCollection_SparseArrayBase>  >(
      m,
      "NCollection_SparseArrayBase",R"#(Base class for NCollection_SparseArray; provides non-template implementation of general mechanics of block allocation, items creation / deletion etc.)#"
    );
    preregister_template_NCollection_UtfString<char>(m,"NCollection_String");
    py::class_<NCollection_UtfStringTool , shared_ptr<NCollection_UtfStringTool>  >(
      m,
      "NCollection_UtfStringTool",R"#(Auxiliary conversion tool.)#"
    );
    py::class_<NCollection_BaseAllocator ,opencascade::handle<NCollection_BaseAllocator>  , Standard_Transient >(
      m,
      "NCollection_BaseAllocator",R"#(Purpose: Basic class for memory allocation wizards. Defines the interface for devising different allocators firstly to be used by collections of NCollection, though it it is not deferred. It allocates/frees the memory through Standard procedures, thus it is unnecessary (and sometimes injurious) to have more than one such allocator. To avoid creation of multiple objects the constructors were maid inaccessible. To create the BaseAllocator use the method CommonBaseAllocator. Note that this object is managed by Handle.)#"
    );
    py::class_<NCollection_Buffer ,opencascade::handle<NCollection_Buffer>  , Standard_Transient >(
      m,
      "NCollection_Buffer",R"#(Low-level buffer object.)#"
    );
    py::class_<NCollection_AccAllocator ,opencascade::handle<NCollection_AccAllocator>  , NCollection_BaseAllocator >(
      m,
      "NCollection_AccAllocator",R"#(Class NCollection_AccAllocator - accumulating memory allocator. This class allocates memory on request returning the pointer to the allocated space. The allocation units are grouped in blocks requested from the system as required. This memory is returned to the system when all allocations in a block are freed.)#"
    );
    py::class_<NCollection_AlignedAllocator ,opencascade::handle<NCollection_AlignedAllocator>  , NCollection_BaseAllocator >(
      m,
      "NCollection_AlignedAllocator",R"#(NCollection allocator with managed memory alignment capabilities.)#"
    );
    py::class_<NCollection_HeapAllocator ,opencascade::handle<NCollection_HeapAllocator>  , NCollection_BaseAllocator >(
      m,
      "NCollection_HeapAllocator",R"#(Allocator that uses the global dynamic heap (malloc / free).)#"
    );
    py::class_<NCollection_IncAllocator ,opencascade::handle<NCollection_IncAllocator>  , NCollection_BaseAllocator >(
      m,
      "NCollection_IncAllocator",R"#(Class NCollection_IncAllocator - incremental memory allocator. This class allocates memory on request returning the pointer to an allocated block. This memory is never returned to the system until the allocator is destroyed.)#"
    );
    py::class_<NCollection_WinHeapAllocator ,opencascade::handle<NCollection_WinHeapAllocator>  , NCollection_BaseAllocator >(
      m,
      "NCollection_WinHeapAllocator",R"#(This memory allocator creates dedicated heap for allocations. This technics available only on Windows platform (no alternative on Unix systems). It may be used to take control over memory fragmentation because on destruction ALL allocated memory will be released to the system.)#"
    );

// preregister user-defined template specializations

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
