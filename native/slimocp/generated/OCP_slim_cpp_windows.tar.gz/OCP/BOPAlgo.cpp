
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BOPAlgo_PaveFiller.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BOPAlgo_PaveFiller.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Message_ProgressScope.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BOPAlgo_ArgumentAnalyzer.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BOPAlgo_BOP.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BOPAlgo_Builder.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BOPAlgo_PaveFiller.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BOPAlgo_Section.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BOPAlgo_WireEdgeSet.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <TopoDS_Face.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <BOPAlgo_PaveFiller.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>

// module includes
#include <BOPAlgo_Alerts.hxx>
#include <BOPAlgo_Algo.hxx>
#include <BOPAlgo_ArgumentAnalyzer.hxx>
#include <BOPAlgo_BOP.hxx>
#include <BOPAlgo_Builder.hxx>
#include <BOPAlgo_BuilderArea.hxx>
#include <BOPAlgo_BuilderFace.hxx>
#include <BOPAlgo_BuilderShape.hxx>
#include <BOPAlgo_BuilderSolid.hxx>
#include <BOPAlgo_CellsBuilder.hxx>
#include <BOPAlgo_CheckerSI.hxx>
#include <BOPAlgo_CheckResult.hxx>
#include <BOPAlgo_CheckStatus.hxx>
#include <BOPAlgo_GlueEnum.hxx>
#include <BOPAlgo_MakeConnected.hxx>
#include <BOPAlgo_MakePeriodic.hxx>
#include <BOPAlgo_MakerVolume.hxx>
#include <BOPAlgo_Operation.hxx>
#include <BOPAlgo_Options.hxx>
#include <BOPAlgo_PArgumentAnalyzer.hxx>
#include <BOPAlgo_PaveFiller.hxx>
#include <BOPAlgo_PBOP.hxx>
#include <BOPAlgo_PBuilder.hxx>
#include <BOPAlgo_PPaveFiller.hxx>
#include <BOPAlgo_PSection.hxx>
#include <BOPAlgo_PWireEdgeSet.hxx>
#include <BOPAlgo_RemoveFeatures.hxx>
#include <BOPAlgo_Section.hxx>
#include <BOPAlgo_SectionAttribute.hxx>
#include <BOPAlgo_ShellSplitter.hxx>
#include <BOPAlgo_Splitter.hxx>
#include <BOPAlgo_Tools.hxx>
#include <BOPAlgo_ToolsProvider.hxx>
#include <BOPAlgo_WireEdgeSet.hxx>
#include <BOPAlgo_WireSplitter.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module
#include <BOPDS_Iterator.hxx>
#include <BOPDS_DS.hxx>


// Module definiiton
void register_BOPAlgo(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("BOPAlgo"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes
    class Py_BOPAlgo_Algo : public BOPAlgo_Algo{
    public:
        using BOPAlgo_Algo::BOPAlgo_Algo;


        // public pure virtual
        void Perform( const Message_ProgressRange & theRange) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,BOPAlgo_Algo,Perform,theRange) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_BOPAlgo_BuilderArea : public BOPAlgo_BuilderArea{
    public:
        using BOPAlgo_BuilderArea::BOPAlgo_BuilderArea;


        // public pure virtual

        void Perform( const Message_ProgressRange & theRange) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,BOPAlgo_Algo,Perform,theRange) };

        // protected pure virtual
        void PerformShapesToAvoid( const Message_ProgressRange & theRange) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,BOPAlgo_BuilderArea,PerformShapesToAvoid,theRange) };
        void PerformLoops( const Message_ProgressRange & theRange) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,BOPAlgo_BuilderArea,PerformLoops,theRange) };
        void PerformAreas( const Message_ProgressRange & theRange) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,BOPAlgo_BuilderArea,PerformAreas,theRange) };
        void PerformInternalShapes( const Message_ProgressRange & theRange) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,BOPAlgo_BuilderArea,PerformInternalShapes,theRange) };


        // private pure virtual

    };
    class Py_BOPAlgo_BuilderShape : public BOPAlgo_BuilderShape{
    public:
        using BOPAlgo_BuilderShape::BOPAlgo_BuilderShape;


        // public pure virtual

        void Perform( const Message_ProgressRange & theRange) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,BOPAlgo_Algo,Perform,theRange) };

        // protected pure virtual


        // private pure virtual

    };
    class Py_BOPAlgo_ParallelAlgo : public BOPAlgo_ParallelAlgo{
    public:
        using BOPAlgo_ParallelAlgo::BOPAlgo_ParallelAlgo;


        // public pure virtual
        void Perform() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,BOPAlgo_ParallelAlgo,Perform,) };


        // protected pure virtual


        // private pure virtual

    };

// classes

    // Class BOPAlgo_AlertAcquiredSelfIntersection from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertAcquiredSelfIntersection");


    // nested enums

    static_cast<py::class_<BOPAlgo_AlertAcquiredSelfIntersection ,opencascade::handle<BOPAlgo_AlertAcquiredSelfIntersection>  , TopoDS_AlertWithShape >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("theShape") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertAcquiredSelfIntersection::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertAcquiredSelfIntersection::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertAcquiredSelfIntersection::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertAcquiredSelfIntersection::*)() const>(&BOPAlgo_AlertAcquiredSelfIntersection::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertBOPNotAllowed from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertBOPNotAllowed");

    // default constructor
    register_default_constructor<BOPAlgo_AlertBOPNotAllowed ,opencascade::handle<BOPAlgo_AlertBOPNotAllowed>>(m,"BOPAlgo_AlertBOPNotAllowed");

    // nested enums

    static_cast<py::class_<BOPAlgo_AlertBOPNotAllowed ,opencascade::handle<BOPAlgo_AlertBOPNotAllowed>  , Message_Alert >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertBOPNotAllowed::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertBOPNotAllowed::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertBOPNotAllowed::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertBOPNotAllowed::*)() const>(&BOPAlgo_AlertBOPNotAllowed::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertBOPNotSet from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertBOPNotSet");

    // default constructor
    register_default_constructor<BOPAlgo_AlertBOPNotSet ,opencascade::handle<BOPAlgo_AlertBOPNotSet>>(m,"BOPAlgo_AlertBOPNotSet");

    // nested enums

    static_cast<py::class_<BOPAlgo_AlertBOPNotSet ,opencascade::handle<BOPAlgo_AlertBOPNotSet>  , Message_Alert >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertBOPNotSet::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertBOPNotSet::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertBOPNotSet::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertBOPNotSet::*)() const>(&BOPAlgo_AlertBOPNotSet::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertBadPositioning from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertBadPositioning");


    // nested enums

    static_cast<py::class_<BOPAlgo_AlertBadPositioning ,opencascade::handle<BOPAlgo_AlertBadPositioning>  , TopoDS_AlertWithShape >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("theShape") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertBadPositioning::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertBadPositioning::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertBadPositioning::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertBadPositioning::*)() const>(&BOPAlgo_AlertBadPositioning::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertBuilderFailed from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertBuilderFailed");

    // default constructor
    register_default_constructor<BOPAlgo_AlertBuilderFailed ,opencascade::handle<BOPAlgo_AlertBuilderFailed>>(m,"BOPAlgo_AlertBuilderFailed");

    // nested enums

    static_cast<py::class_<BOPAlgo_AlertBuilderFailed ,opencascade::handle<BOPAlgo_AlertBuilderFailed>  , Message_Alert >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertBuilderFailed::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertBuilderFailed::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertBuilderFailed::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertBuilderFailed::*)() const>(&BOPAlgo_AlertBuilderFailed::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertBuildingPCurveFailed from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertBuildingPCurveFailed");


    // nested enums

    static_cast<py::class_<BOPAlgo_AlertBuildingPCurveFailed ,opencascade::handle<BOPAlgo_AlertBuildingPCurveFailed>  , TopoDS_AlertWithShape >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("theShape") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertBuildingPCurveFailed::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertBuildingPCurveFailed::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertBuildingPCurveFailed::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertBuildingPCurveFailed::*)() const>(&BOPAlgo_AlertBuildingPCurveFailed::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertEmptyShape from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertEmptyShape");


    // nested enums

    static_cast<py::class_<BOPAlgo_AlertEmptyShape ,opencascade::handle<BOPAlgo_AlertEmptyShape>  , TopoDS_AlertWithShape >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("theShape") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertEmptyShape::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertEmptyShape::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertEmptyShape::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertEmptyShape::*)() const>(&BOPAlgo_AlertEmptyShape::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertFaceBuilderUnusedEdges from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertFaceBuilderUnusedEdges");


    // nested enums

    static_cast<py::class_<BOPAlgo_AlertFaceBuilderUnusedEdges ,opencascade::handle<BOPAlgo_AlertFaceBuilderUnusedEdges>  , TopoDS_AlertWithShape >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("theShape") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertFaceBuilderUnusedEdges::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertFaceBuilderUnusedEdges::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertFaceBuilderUnusedEdges::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertFaceBuilderUnusedEdges::*)() const>(&BOPAlgo_AlertFaceBuilderUnusedEdges::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertIntersectionFailed from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertIntersectionFailed");

    // default constructor
    register_default_constructor<BOPAlgo_AlertIntersectionFailed ,opencascade::handle<BOPAlgo_AlertIntersectionFailed>>(m,"BOPAlgo_AlertIntersectionFailed");

    // nested enums

    static_cast<py::class_<BOPAlgo_AlertIntersectionFailed ,opencascade::handle<BOPAlgo_AlertIntersectionFailed>  , Message_Alert >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertIntersectionFailed::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertIntersectionFailed::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertIntersectionFailed::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertIntersectionFailed::*)() const>(&BOPAlgo_AlertIntersectionFailed::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertIntersectionOfPairOfShapesFailed from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertIntersectionOfPairOfShapesFailed");


    // nested enums

    static_cast<py::class_<BOPAlgo_AlertIntersectionOfPairOfShapesFailed ,opencascade::handle<BOPAlgo_AlertIntersectionOfPairOfShapesFailed>  , TopoDS_AlertWithShape >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("theShape") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertIntersectionOfPairOfShapesFailed::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertIntersectionOfPairOfShapesFailed::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertIntersectionOfPairOfShapesFailed::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertIntersectionOfPairOfShapesFailed::*)() const>(&BOPAlgo_AlertIntersectionOfPairOfShapesFailed::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertMultiDimensionalArguments from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertMultiDimensionalArguments");

    // default constructor
    register_default_constructor<BOPAlgo_AlertMultiDimensionalArguments ,opencascade::handle<BOPAlgo_AlertMultiDimensionalArguments>>(m,"BOPAlgo_AlertMultiDimensionalArguments");

    // nested enums

    static_cast<py::class_<BOPAlgo_AlertMultiDimensionalArguments ,opencascade::handle<BOPAlgo_AlertMultiDimensionalArguments>  , Message_Alert >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertMultiDimensionalArguments::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertMultiDimensionalArguments::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertMultiDimensionalArguments::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertMultiDimensionalArguments::*)() const>(&BOPAlgo_AlertMultiDimensionalArguments::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertMultipleArguments from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertMultipleArguments");

    // default constructor
    register_default_constructor<BOPAlgo_AlertMultipleArguments ,opencascade::handle<BOPAlgo_AlertMultipleArguments>>(m,"BOPAlgo_AlertMultipleArguments");

    // nested enums

    static_cast<py::class_<BOPAlgo_AlertMultipleArguments ,opencascade::handle<BOPAlgo_AlertMultipleArguments>  , Message_Alert >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertMultipleArguments::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertMultipleArguments::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertMultipleArguments::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertMultipleArguments::*)() const>(&BOPAlgo_AlertMultipleArguments::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertNoFacesToRemove from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertNoFacesToRemove");

    // default constructor
    register_default_constructor<BOPAlgo_AlertNoFacesToRemove ,opencascade::handle<BOPAlgo_AlertNoFacesToRemove>>(m,"BOPAlgo_AlertNoFacesToRemove");

    // nested enums

    static_cast<py::class_<BOPAlgo_AlertNoFacesToRemove ,opencascade::handle<BOPAlgo_AlertNoFacesToRemove>  , Message_Alert >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertNoFacesToRemove::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertNoFacesToRemove::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertNoFacesToRemove::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertNoFacesToRemove::*)() const>(&BOPAlgo_AlertNoFacesToRemove::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertNoFiller from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertNoFiller");

    // default constructor
    register_default_constructor<BOPAlgo_AlertNoFiller ,opencascade::handle<BOPAlgo_AlertNoFiller>>(m,"BOPAlgo_AlertNoFiller");

    // nested enums

    static_cast<py::class_<BOPAlgo_AlertNoFiller ,opencascade::handle<BOPAlgo_AlertNoFiller>  , Message_Alert >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertNoFiller::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertNoFiller::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertNoFiller::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertNoFiller::*)() const>(&BOPAlgo_AlertNoFiller::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertNoPeriodicityRequired from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertNoPeriodicityRequired");

    // default constructor
    register_default_constructor<BOPAlgo_AlertNoPeriodicityRequired ,opencascade::handle<BOPAlgo_AlertNoPeriodicityRequired>>(m,"BOPAlgo_AlertNoPeriodicityRequired");

    // nested enums

    static_cast<py::class_<BOPAlgo_AlertNoPeriodicityRequired ,opencascade::handle<BOPAlgo_AlertNoPeriodicityRequired>  , Message_Alert >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertNoPeriodicityRequired::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertNoPeriodicityRequired::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertNoPeriodicityRequired::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertNoPeriodicityRequired::*)() const>(&BOPAlgo_AlertNoPeriodicityRequired::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertNotSplittableEdge from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertNotSplittableEdge");


    // nested enums

    static_cast<py::class_<BOPAlgo_AlertNotSplittableEdge ,opencascade::handle<BOPAlgo_AlertNotSplittableEdge>  , TopoDS_AlertWithShape >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("theShape") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertNotSplittableEdge::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertNotSplittableEdge::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertNotSplittableEdge::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertNotSplittableEdge::*)() const>(&BOPAlgo_AlertNotSplittableEdge::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertNullInputShapes from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertNullInputShapes");

    // default constructor
    register_default_constructor<BOPAlgo_AlertNullInputShapes ,opencascade::handle<BOPAlgo_AlertNullInputShapes>>(m,"BOPAlgo_AlertNullInputShapes");

    // nested enums

    static_cast<py::class_<BOPAlgo_AlertNullInputShapes ,opencascade::handle<BOPAlgo_AlertNullInputShapes>  , Message_Alert >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertNullInputShapes::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertNullInputShapes::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertNullInputShapes::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertNullInputShapes::*)() const>(&BOPAlgo_AlertNullInputShapes::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertPostTreatFF from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertPostTreatFF");

    // default constructor
    register_default_constructor<BOPAlgo_AlertPostTreatFF ,opencascade::handle<BOPAlgo_AlertPostTreatFF>>(m,"BOPAlgo_AlertPostTreatFF");

    // nested enums

    static_cast<py::class_<BOPAlgo_AlertPostTreatFF ,opencascade::handle<BOPAlgo_AlertPostTreatFF>  , Message_Alert >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertPostTreatFF::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertPostTreatFF::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertPostTreatFF::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertPostTreatFF::*)() const>(&BOPAlgo_AlertPostTreatFF::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertRemovalOfIBForEdgesFailed from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertRemovalOfIBForEdgesFailed");


    // nested enums

    static_cast<py::class_<BOPAlgo_AlertRemovalOfIBForEdgesFailed ,opencascade::handle<BOPAlgo_AlertRemovalOfIBForEdgesFailed>  , TopoDS_AlertWithShape >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("theShape") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertRemovalOfIBForEdgesFailed::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertRemovalOfIBForEdgesFailed::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertRemovalOfIBForEdgesFailed::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertRemovalOfIBForEdgesFailed::*)() const>(&BOPAlgo_AlertRemovalOfIBForEdgesFailed::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertRemovalOfIBForFacesFailed from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertRemovalOfIBForFacesFailed");


    // nested enums

    static_cast<py::class_<BOPAlgo_AlertRemovalOfIBForFacesFailed ,opencascade::handle<BOPAlgo_AlertRemovalOfIBForFacesFailed>  , TopoDS_AlertWithShape >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("theShape") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertRemovalOfIBForFacesFailed::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertRemovalOfIBForFacesFailed::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertRemovalOfIBForFacesFailed::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertRemovalOfIBForFacesFailed::*)() const>(&BOPAlgo_AlertRemovalOfIBForFacesFailed::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertRemovalOfIBForMDimShapes from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertRemovalOfIBForMDimShapes");


    // nested enums

    static_cast<py::class_<BOPAlgo_AlertRemovalOfIBForMDimShapes ,opencascade::handle<BOPAlgo_AlertRemovalOfIBForMDimShapes>  , TopoDS_AlertWithShape >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("theShape") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertRemovalOfIBForMDimShapes::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertRemovalOfIBForMDimShapes::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertRemovalOfIBForMDimShapes::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertRemovalOfIBForMDimShapes::*)() const>(&BOPAlgo_AlertRemovalOfIBForMDimShapes::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertRemovalOfIBForSolidsFailed from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertRemovalOfIBForSolidsFailed");


    // nested enums

    static_cast<py::class_<BOPAlgo_AlertRemovalOfIBForSolidsFailed ,opencascade::handle<BOPAlgo_AlertRemovalOfIBForSolidsFailed>  , TopoDS_AlertWithShape >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("theShape") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertRemovalOfIBForSolidsFailed::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertRemovalOfIBForSolidsFailed::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertRemovalOfIBForSolidsFailed::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertRemovalOfIBForSolidsFailed::*)() const>(&BOPAlgo_AlertRemovalOfIBForSolidsFailed::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertRemoveFeaturesFailed from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertRemoveFeaturesFailed");

    // default constructor
    register_default_constructor<BOPAlgo_AlertRemoveFeaturesFailed ,opencascade::handle<BOPAlgo_AlertRemoveFeaturesFailed>>(m,"BOPAlgo_AlertRemoveFeaturesFailed");

    // nested enums

    static_cast<py::class_<BOPAlgo_AlertRemoveFeaturesFailed ,opencascade::handle<BOPAlgo_AlertRemoveFeaturesFailed>  , Message_Alert >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertRemoveFeaturesFailed::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertRemoveFeaturesFailed::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertRemoveFeaturesFailed::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertRemoveFeaturesFailed::*)() const>(&BOPAlgo_AlertRemoveFeaturesFailed::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertSelfInterferingShape from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertSelfInterferingShape");


    // nested enums

    static_cast<py::class_<BOPAlgo_AlertSelfInterferingShape ,opencascade::handle<BOPAlgo_AlertSelfInterferingShape>  , TopoDS_AlertWithShape >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("theShape") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertSelfInterferingShape::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertSelfInterferingShape::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertSelfInterferingShape::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertSelfInterferingShape::*)() const>(&BOPAlgo_AlertSelfInterferingShape::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertShapeIsNotPeriodic from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertShapeIsNotPeriodic");


    // nested enums

    static_cast<py::class_<BOPAlgo_AlertShapeIsNotPeriodic ,opencascade::handle<BOPAlgo_AlertShapeIsNotPeriodic>  , TopoDS_AlertWithShape >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("theShape") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertShapeIsNotPeriodic::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertShapeIsNotPeriodic::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertShapeIsNotPeriodic::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertShapeIsNotPeriodic::*)() const>(&BOPAlgo_AlertShapeIsNotPeriodic::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertShellSplitterFailed from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertShellSplitterFailed");


    // nested enums

    static_cast<py::class_<BOPAlgo_AlertShellSplitterFailed ,opencascade::handle<BOPAlgo_AlertShellSplitterFailed>  , TopoDS_AlertWithShape >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("theShape") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertShellSplitterFailed::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertShellSplitterFailed::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertShellSplitterFailed::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertShellSplitterFailed::*)() const>(&BOPAlgo_AlertShellSplitterFailed::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertSolidBuilderFailed from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertSolidBuilderFailed");

    // default constructor
    register_default_constructor<BOPAlgo_AlertSolidBuilderFailed ,opencascade::handle<BOPAlgo_AlertSolidBuilderFailed>>(m,"BOPAlgo_AlertSolidBuilderFailed");

    // nested enums

    static_cast<py::class_<BOPAlgo_AlertSolidBuilderFailed ,opencascade::handle<BOPAlgo_AlertSolidBuilderFailed>  , Message_Alert >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertSolidBuilderFailed::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertSolidBuilderFailed::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertSolidBuilderFailed::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertSolidBuilderFailed::*)() const>(&BOPAlgo_AlertSolidBuilderFailed::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertSolidBuilderUnusedFaces from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertSolidBuilderUnusedFaces");


    // nested enums

    static_cast<py::class_<BOPAlgo_AlertSolidBuilderUnusedFaces ,opencascade::handle<BOPAlgo_AlertSolidBuilderUnusedFaces>  , TopoDS_AlertWithShape >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("theShape") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertSolidBuilderUnusedFaces::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertSolidBuilderUnusedFaces::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertSolidBuilderUnusedFaces::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertSolidBuilderUnusedFaces::*)() const>(&BOPAlgo_AlertSolidBuilderUnusedFaces::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertTooFewArguments from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertTooFewArguments");

    // default constructor
    register_default_constructor<BOPAlgo_AlertTooFewArguments ,opencascade::handle<BOPAlgo_AlertTooFewArguments>>(m,"BOPAlgo_AlertTooFewArguments");

    // nested enums

    static_cast<py::class_<BOPAlgo_AlertTooFewArguments ,opencascade::handle<BOPAlgo_AlertTooFewArguments>  , Message_Alert >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertTooFewArguments::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertTooFewArguments::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertTooFewArguments::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertTooFewArguments::*)() const>(&BOPAlgo_AlertTooFewArguments::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertTooSmallEdge from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertTooSmallEdge");


    // nested enums

    static_cast<py::class_<BOPAlgo_AlertTooSmallEdge ,opencascade::handle<BOPAlgo_AlertTooSmallEdge>  , TopoDS_AlertWithShape >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("theShape") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertTooSmallEdge::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertTooSmallEdge::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertTooSmallEdge::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertTooSmallEdge::*)() const>(&BOPAlgo_AlertTooSmallEdge::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertUnableToGlue from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertUnableToGlue");


    // nested enums

    static_cast<py::class_<BOPAlgo_AlertUnableToGlue ,opencascade::handle<BOPAlgo_AlertUnableToGlue>  , TopoDS_AlertWithShape >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("theShape") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertUnableToGlue::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertUnableToGlue::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertUnableToGlue::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertUnableToGlue::*)() const>(&BOPAlgo_AlertUnableToGlue::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertUnableToMakeClosedEdgeOnFace from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertUnableToMakeClosedEdgeOnFace");


    // nested enums

    static_cast<py::class_<BOPAlgo_AlertUnableToMakeClosedEdgeOnFace ,opencascade::handle<BOPAlgo_AlertUnableToMakeClosedEdgeOnFace>  , TopoDS_AlertWithShape >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("theShape") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertUnableToMakeClosedEdgeOnFace::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertUnableToMakeClosedEdgeOnFace::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertUnableToMakeClosedEdgeOnFace::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertUnableToMakeClosedEdgeOnFace::*)() const>(&BOPAlgo_AlertUnableToMakeClosedEdgeOnFace::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertUnableToMakeIdentical from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertUnableToMakeIdentical");


    // nested enums

    static_cast<py::class_<BOPAlgo_AlertUnableToMakeIdentical ,opencascade::handle<BOPAlgo_AlertUnableToMakeIdentical>  , TopoDS_AlertWithShape >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("theShape") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertUnableToMakeIdentical::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertUnableToMakeIdentical::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertUnableToMakeIdentical::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertUnableToMakeIdentical::*)() const>(&BOPAlgo_AlertUnableToMakeIdentical::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertUnableToMakePeriodic from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertUnableToMakePeriodic");


    // nested enums

    static_cast<py::class_<BOPAlgo_AlertUnableToMakePeriodic ,opencascade::handle<BOPAlgo_AlertUnableToMakePeriodic>  , TopoDS_AlertWithShape >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("theShape") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertUnableToMakePeriodic::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertUnableToMakePeriodic::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertUnableToMakePeriodic::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertUnableToMakePeriodic::*)() const>(&BOPAlgo_AlertUnableToMakePeriodic::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertUnableToOrientTheShape from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertUnableToOrientTheShape");


    // nested enums

    static_cast<py::class_<BOPAlgo_AlertUnableToOrientTheShape ,opencascade::handle<BOPAlgo_AlertUnableToOrientTheShape>  , TopoDS_AlertWithShape >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("theShape") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertUnableToOrientTheShape::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertUnableToOrientTheShape::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertUnableToOrientTheShape::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertUnableToOrientTheShape::*)() const>(&BOPAlgo_AlertUnableToOrientTheShape::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertUnableToRemoveTheFeature from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertUnableToRemoveTheFeature");


    // nested enums

    static_cast<py::class_<BOPAlgo_AlertUnableToRemoveTheFeature ,opencascade::handle<BOPAlgo_AlertUnableToRemoveTheFeature>  , TopoDS_AlertWithShape >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("theShape") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertUnableToRemoveTheFeature::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertUnableToRemoveTheFeature::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertUnableToRemoveTheFeature::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertUnableToRemoveTheFeature::*)() const>(&BOPAlgo_AlertUnableToRemoveTheFeature::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertUnableToRepeat from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertUnableToRepeat");


    // nested enums

    static_cast<py::class_<BOPAlgo_AlertUnableToRepeat ,opencascade::handle<BOPAlgo_AlertUnableToRepeat>  , TopoDS_AlertWithShape >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("theShape") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertUnableToRepeat::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertUnableToRepeat::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertUnableToRepeat::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertUnableToRepeat::*)() const>(&BOPAlgo_AlertUnableToRepeat::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertUnableToTrim from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertUnableToTrim");


    // nested enums

    static_cast<py::class_<BOPAlgo_AlertUnableToTrim ,opencascade::handle<BOPAlgo_AlertUnableToTrim>  , TopoDS_AlertWithShape >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("theShape") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertUnableToTrim::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertUnableToTrim::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertUnableToTrim::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertUnableToTrim::*)() const>(&BOPAlgo_AlertUnableToTrim::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertUnknownShape from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertUnknownShape");


    // nested enums

    static_cast<py::class_<BOPAlgo_AlertUnknownShape ,opencascade::handle<BOPAlgo_AlertUnknownShape>  , TopoDS_AlertWithShape >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("theShape") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertUnknownShape::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertUnknownShape::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertUnknownShape::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertUnknownShape::*)() const>(&BOPAlgo_AlertUnknownShape::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertUnsupportedType from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertUnsupportedType");


    // nested enums

    static_cast<py::class_<BOPAlgo_AlertUnsupportedType ,opencascade::handle<BOPAlgo_AlertUnsupportedType>  , TopoDS_AlertWithShape >>(klass)
    // constructors
        .def(py::init<  const TopoDS_Shape & >()  , py::arg("theShape") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertUnsupportedType::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertUnsupportedType::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertUnsupportedType::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertUnsupportedType::*)() const>(&BOPAlgo_AlertUnsupportedType::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_AlertUserBreak from ./opencascade/BOPAlgo_Alerts.hxx
    klass = m.attr("BOPAlgo_AlertUserBreak");

    // default constructor
    register_default_constructor<BOPAlgo_AlertUserBreak ,opencascade::handle<BOPAlgo_AlertUserBreak>>(m,"BOPAlgo_AlertUserBreak");

    // nested enums

    static_cast<py::class_<BOPAlgo_AlertUserBreak ,opencascade::handle<BOPAlgo_AlertUserBreak>  , Message_Alert >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&BOPAlgo_AlertUserBreak::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&BOPAlgo_AlertUserBreak::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (BOPAlgo_AlertUserBreak::*)() const) static_cast< const handle<Standard_Type> & (BOPAlgo_AlertUserBreak::*)() const>(&BOPAlgo_AlertUserBreak::DynamicType),
             R"#()#"
             
         )
;

    // Class BOPAlgo_CheckResult from ./opencascade/BOPAlgo_CheckResult.hxx
    klass = m.attr("BOPAlgo_CheckResult");


    // nested enums

    static_cast<py::class_<BOPAlgo_CheckResult , shared_ptr<BOPAlgo_CheckResult>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetShape1",
             (void (BOPAlgo_CheckResult::*)(  const TopoDS_Shape &  ) ) static_cast<void (BOPAlgo_CheckResult::*)(  const TopoDS_Shape &  ) >(&BOPAlgo_CheckResult::SetShape1),
             R"#(sets ancestor shape (object) for faulty sub-shapes)#"  , py::arg("TheShape")
          )
        .def("AddFaultyShape1",
             (void (BOPAlgo_CheckResult::*)(  const TopoDS_Shape &  ) ) static_cast<void (BOPAlgo_CheckResult::*)(  const TopoDS_Shape &  ) >(&BOPAlgo_CheckResult::AddFaultyShape1),
             R"#(adds faulty sub-shapes from object to a list)#"  , py::arg("TheShape")
          )
        .def("SetShape2",
             (void (BOPAlgo_CheckResult::*)(  const TopoDS_Shape &  ) ) static_cast<void (BOPAlgo_CheckResult::*)(  const TopoDS_Shape &  ) >(&BOPAlgo_CheckResult::SetShape2),
             R"#(sets ancestor shape (tool) for faulty sub-shapes)#"  , py::arg("TheShape")
          )
        .def("AddFaultyShape2",
             (void (BOPAlgo_CheckResult::*)(  const TopoDS_Shape &  ) ) static_cast<void (BOPAlgo_CheckResult::*)(  const TopoDS_Shape &  ) >(&BOPAlgo_CheckResult::AddFaultyShape2),
             R"#(adds faulty sub-shapes from tool to a list)#"  , py::arg("TheShape")
          )
        .def("SetCheckStatus",
             (void (BOPAlgo_CheckResult::*)(  const BOPAlgo_CheckStatus  ) ) static_cast<void (BOPAlgo_CheckResult::*)(  const BOPAlgo_CheckStatus  ) >(&BOPAlgo_CheckResult::SetCheckStatus),
             R"#(set status of faulty)#"  , py::arg("TheStatus")
          )
        .def("GetCheckStatus",
             (BOPAlgo_CheckStatus (BOPAlgo_CheckResult::*)() const) static_cast<BOPAlgo_CheckStatus (BOPAlgo_CheckResult::*)() const>(&BOPAlgo_CheckResult::GetCheckStatus),
             R"#(gets status of faulty)#" 
          )
        .def("SetMaxDistance1",
             (void (BOPAlgo_CheckResult::*)(  const double  ) ) static_cast<void (BOPAlgo_CheckResult::*)(  const double  ) >(&BOPAlgo_CheckResult::SetMaxDistance1),
             R"#(Sets max distance for the first shape)#"  , py::arg("theDist")
          )
        .def("SetMaxDistance2",
             (void (BOPAlgo_CheckResult::*)(  const double  ) ) static_cast<void (BOPAlgo_CheckResult::*)(  const double  ) >(&BOPAlgo_CheckResult::SetMaxDistance2),
             R"#(Sets max distance for the second shape)#"  , py::arg("theDist")
          )
        .def("SetMaxParameter1",
             (void (BOPAlgo_CheckResult::*)(  const double  ) ) static_cast<void (BOPAlgo_CheckResult::*)(  const double  ) >(&BOPAlgo_CheckResult::SetMaxParameter1),
             R"#(Sets the parameter for the first shape)#"  , py::arg("thePar")
          )
        .def("SetMaxParameter2",
             (void (BOPAlgo_CheckResult::*)(  const double  ) ) static_cast<void (BOPAlgo_CheckResult::*)(  const double  ) >(&BOPAlgo_CheckResult::SetMaxParameter2),
             R"#(Sets the parameter for the second shape)#"  , py::arg("thePar")
          )
        .def("GetMaxDistance1",
             (double (BOPAlgo_CheckResult::*)() const) static_cast<double (BOPAlgo_CheckResult::*)() const>(&BOPAlgo_CheckResult::GetMaxDistance1),
             R"#(Returns the distance for the first shape)#" 
          )
        .def("GetMaxDistance2",
             (double (BOPAlgo_CheckResult::*)() const) static_cast<double (BOPAlgo_CheckResult::*)() const>(&BOPAlgo_CheckResult::GetMaxDistance2),
             R"#(Returns the distance for the second shape)#" 
          )
        .def("GetMaxParameter1",
             (double (BOPAlgo_CheckResult::*)() const) static_cast<double (BOPAlgo_CheckResult::*)() const>(&BOPAlgo_CheckResult::GetMaxParameter1),
             R"#(Returns the parameter for the fircst shape)#" 
          )
        .def("GetMaxParameter2",
             (double (BOPAlgo_CheckResult::*)() const) static_cast<double (BOPAlgo_CheckResult::*)() const>(&BOPAlgo_CheckResult::GetMaxParameter2),
             R"#(Returns the parameter for the second shape)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("GetShape1",
             ( const TopoDS_Shape & (BOPAlgo_CheckResult::*)() const) static_cast< const TopoDS_Shape & (BOPAlgo_CheckResult::*)() const>(&BOPAlgo_CheckResult::GetShape1),
             R"#(returns ancestor shape (object) for faulties)#"
             
         )
       .def("GetShape2",
             ( const TopoDS_Shape & (BOPAlgo_CheckResult::*)() const) static_cast< const TopoDS_Shape & (BOPAlgo_CheckResult::*)() const>(&BOPAlgo_CheckResult::GetShape2),
             R"#(returns ancestor shape (tool) for faulties)#"
             
         )
       .def("GetFaultyShapes1",
             ( const NCollection_List<TopoDS_Shape> & (BOPAlgo_CheckResult::*)() const) static_cast< const NCollection_List<TopoDS_Shape> & (BOPAlgo_CheckResult::*)() const>(&BOPAlgo_CheckResult::GetFaultyShapes1),
             R"#(returns list of faulty shapes for object)#"
             
         )
       .def("GetFaultyShapes2",
             ( const NCollection_List<TopoDS_Shape> & (BOPAlgo_CheckResult::*)() const) static_cast< const NCollection_List<TopoDS_Shape> & (BOPAlgo_CheckResult::*)() const>(&BOPAlgo_CheckResult::GetFaultyShapes2),
             R"#(returns list of faulty shapes for tool)#"
             
         )
;

    // Class BOPAlgo_EdgeInfo from ./opencascade/BOPAlgo_WireSplitter.hxx
    klass = m.attr("BOPAlgo_EdgeInfo");


    // nested enums

    static_cast<py::class_<BOPAlgo_EdgeInfo , shared_ptr<BOPAlgo_EdgeInfo>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetEdge",
             (void (BOPAlgo_EdgeInfo::*)(  const TopoDS_Edge &  ) ) static_cast<void (BOPAlgo_EdgeInfo::*)(  const TopoDS_Edge &  ) >(&BOPAlgo_EdgeInfo::SetEdge),
             R"#()#"  , py::arg("theE")
          )
        .def("SetPassed",
             (void (BOPAlgo_EdgeInfo::*)(  const bool  ) ) static_cast<void (BOPAlgo_EdgeInfo::*)(  const bool  ) >(&BOPAlgo_EdgeInfo::SetPassed),
             R"#()#"  , py::arg("theFlag")
          )
        .def("Passed",
             (bool (BOPAlgo_EdgeInfo::*)() const) static_cast<bool (BOPAlgo_EdgeInfo::*)() const>(&BOPAlgo_EdgeInfo::Passed),
             R"#()#" 
          )
        .def("SetInFlag",
             (void (BOPAlgo_EdgeInfo::*)(  const bool  ) ) static_cast<void (BOPAlgo_EdgeInfo::*)(  const bool  ) >(&BOPAlgo_EdgeInfo::SetInFlag),
             R"#()#"  , py::arg("theFlag")
          )
        .def("IsIn",
             (bool (BOPAlgo_EdgeInfo::*)() const) static_cast<bool (BOPAlgo_EdgeInfo::*)() const>(&BOPAlgo_EdgeInfo::IsIn),
             R"#()#" 
          )
        .def("SetAngle",
             (void (BOPAlgo_EdgeInfo::*)(  const double  ) ) static_cast<void (BOPAlgo_EdgeInfo::*)(  const double  ) >(&BOPAlgo_EdgeInfo::SetAngle),
             R"#()#"  , py::arg("theAngle")
          )
        .def("Angle",
             (double (BOPAlgo_EdgeInfo::*)() const) static_cast<double (BOPAlgo_EdgeInfo::*)() const>(&BOPAlgo_EdgeInfo::Angle),
             R"#()#" 
          )
        .def("IsInside",
             (bool (BOPAlgo_EdgeInfo::*)() const) static_cast<bool (BOPAlgo_EdgeInfo::*)() const>(&BOPAlgo_EdgeInfo::IsInside),
             R"#()#" 
          )
        .def("SetIsInside",
             (void (BOPAlgo_EdgeInfo::*)(  const bool  ) ) static_cast<void (BOPAlgo_EdgeInfo::*)(  const bool  ) >(&BOPAlgo_EdgeInfo::SetIsInside),
             R"#()#"  , py::arg("theIsInside")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Edge",
             ( const TopoDS_Edge & (BOPAlgo_EdgeInfo::*)() const) static_cast< const TopoDS_Edge & (BOPAlgo_EdgeInfo::*)() const>(&BOPAlgo_EdgeInfo::Edge),
             R"#()#"
             
         )
;

    // Class BOPAlgo_Options from ./opencascade/BOPAlgo_Options.hxx
    klass = m.attr("BOPAlgo_Options");


    // nested enums

    static_cast<py::class_<BOPAlgo_Options , shared_ptr<BOPAlgo_Options>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
        .def("Clear",
             (void (BOPAlgo_Options::*)() ) static_cast<void (BOPAlgo_Options::*)() >(&BOPAlgo_Options::Clear),
             R"#(Clears all warnings and errors, and any data cached by the algorithm. User defined options are not cleared.)#" 
          )
        .def("AddError",
             (void (BOPAlgo_Options::*)(  const handle<Message_Alert> &  ) ) static_cast<void (BOPAlgo_Options::*)(  const handle<Message_Alert> &  ) >(&BOPAlgo_Options::AddError),
             R"#(Adds the alert as error (fail))#"  , py::arg("theAlert")
          )
        .def("AddWarning",
             (void (BOPAlgo_Options::*)(  const handle<Message_Alert> &  ) ) static_cast<void (BOPAlgo_Options::*)(  const handle<Message_Alert> &  ) >(&BOPAlgo_Options::AddWarning),
             R"#(Adds the alert as warning)#"  , py::arg("theAlert")
          )
        .def("HasErrors",
             (bool (BOPAlgo_Options::*)() const) static_cast<bool (BOPAlgo_Options::*)() const>(&BOPAlgo_Options::HasErrors),
             R"#(Returns true if algorithm has failed)#" 
          )
        .def("HasError",
             (bool (BOPAlgo_Options::*)(  const handle<Standard_Type> &  ) const) static_cast<bool (BOPAlgo_Options::*)(  const handle<Standard_Type> &  ) const>(&BOPAlgo_Options::HasError),
             R"#(Returns true if algorithm has generated error of specified type)#"  , py::arg("theType")
          )
        .def("HasWarnings",
             (bool (BOPAlgo_Options::*)() const) static_cast<bool (BOPAlgo_Options::*)() const>(&BOPAlgo_Options::HasWarnings),
             R"#(Returns true if algorithm has generated some warning alerts)#" 
          )
        .def("HasWarning",
             (bool (BOPAlgo_Options::*)(  const handle<Standard_Type> &  ) const) static_cast<bool (BOPAlgo_Options::*)(  const handle<Standard_Type> &  ) const>(&BOPAlgo_Options::HasWarning),
             R"#(Returns true if algorithm has generated warning of specified type)#"  , py::arg("theType")
          )
        .def("DumpErrors",
             (void (BOPAlgo_Options::*)( Standard_OStream &  ) const) static_cast<void (BOPAlgo_Options::*)( Standard_OStream &  ) const>(&BOPAlgo_Options::DumpErrors),
             R"#(Dumps the error status into the given stream)#"  , py::arg("theOS")
          )
        .def("DumpWarnings",
             (void (BOPAlgo_Options::*)( Standard_OStream &  ) const) static_cast<void (BOPAlgo_Options::*)( Standard_OStream &  ) const>(&BOPAlgo_Options::DumpWarnings),
             R"#(Dumps the warning statuses into the given stream)#"  , py::arg("theOS")
          )
        .def("ClearWarnings",
             (void (BOPAlgo_Options::*)() ) static_cast<void (BOPAlgo_Options::*)() >(&BOPAlgo_Options::ClearWarnings),
             R"#(Clears the warnings of the algorithm)#" 
          )
        .def("SetRunParallel",
             (void (BOPAlgo_Options::*)(  const bool  ) ) static_cast<void (BOPAlgo_Options::*)(  const bool  ) >(&BOPAlgo_Options::SetRunParallel),
             R"#(Set the flag of parallel processing if <theFlag> is true the parallel processing is switched on if <theFlag> is false the parallel processing is switched off)#"  , py::arg("theFlag")
          )
        .def("RunParallel",
             (bool (BOPAlgo_Options::*)() const) static_cast<bool (BOPAlgo_Options::*)() const>(&BOPAlgo_Options::RunParallel),
             R"#(Returns the flag of parallel processing)#" 
          )
        .def("SetFuzzyValue",
             (void (BOPAlgo_Options::*)(  const double  ) ) static_cast<void (BOPAlgo_Options::*)(  const double  ) >(&BOPAlgo_Options::SetFuzzyValue),
             R"#(Sets the additional tolerance)#"  , py::arg("theFuzz")
          )
        .def("FuzzyValue",
             (double (BOPAlgo_Options::*)() const) static_cast<double (BOPAlgo_Options::*)() const>(&BOPAlgo_Options::FuzzyValue),
             R"#(Returns the additional tolerance)#" 
          )
        .def("SetUseOBB",
             (void (BOPAlgo_Options::*)(  const bool  ) ) static_cast<void (BOPAlgo_Options::*)(  const bool  ) >(&BOPAlgo_Options::SetUseOBB),
             R"#(Enables/Disables the usage of OBB)#"  , py::arg("theUseOBB")
          )
        .def("UseOBB",
             (bool (BOPAlgo_Options::*)() const) static_cast<bool (BOPAlgo_Options::*)() const>(&BOPAlgo_Options::UseOBB),
             R"#(Returns the flag defining usage of OBB)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("GetParallelMode_s",
                    (bool (*)() ) static_cast<bool (*)() >(&BOPAlgo_Options::GetParallelMode),
                    R"#(Gets the global parallel mode)#" 
          )
        .def_static("SetParallelMode_s",
                    (void (*)(  const bool  ) ) static_cast<void (*)(  const bool  ) >(&BOPAlgo_Options::SetParallelMode),
                    R"#(Sets the global parallel mode)#"  , py::arg("theNewMode")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Allocator",
             ( const handle<NCollection_BaseAllocator> & (BOPAlgo_Options::*)() const) static_cast< const handle<NCollection_BaseAllocator> & (BOPAlgo_Options::*)() const>(&BOPAlgo_Options::Allocator),
             R"#(Returns allocator)#"
             
         )
       .def("GetReport",
             ( const handle<Message_Report> & (BOPAlgo_Options::*)() const) static_cast< const handle<Message_Report> & (BOPAlgo_Options::*)() const>(&BOPAlgo_Options::GetReport),
             R"#(Returns report collecting all errors and warnings)#"
             
         )
;

    // Class BOPAlgo_PISteps from ./opencascade/BOPAlgo_Algo.hxx
    klass = m.attr("BOPAlgo_PISteps");


    // nested enums

    static_cast<py::class_<BOPAlgo_PISteps , shared_ptr<BOPAlgo_PISteps>  >>(klass)
    // constructors
        .def(py::init<  const int >()  , py::arg("theNbOp") )
    // custom constructors
    // methods
        .def("SetStep",
             (void (BOPAlgo_PISteps::*)(  const int ,   const double  ) ) static_cast<void (BOPAlgo_PISteps::*)(  const int ,   const double  ) >(&BOPAlgo_PISteps::SetStep),
             R"#(Assign the value theStep to theOperation)#"  , py::arg("theOperation"),  py::arg("theStep")
          )
        .def("GetStep",
             (double (BOPAlgo_PISteps::*)(  const int  ) ) static_cast<double (BOPAlgo_PISteps::*)(  const int  ) >(&BOPAlgo_PISteps::GetStep),
             R"#(Returns the step assigned to the operation)#"  , py::arg("theOperation")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Steps",
             ( const NCollection_Array1<double> & (BOPAlgo_PISteps::*)() const) static_cast< const NCollection_Array1<double> & (BOPAlgo_PISteps::*)() const>(&BOPAlgo_PISteps::Steps),
             R"#(Returns the steps)#"
             
         )
       .def("ChangeSteps",
             (NCollection_Array1<double> & (BOPAlgo_PISteps::*)() ) static_cast<NCollection_Array1<double> & (BOPAlgo_PISteps::*)() >(&BOPAlgo_PISteps::ChangeSteps),
             R"#(Returns modifiable steps)#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class BOPAlgo_SectionAttribute from ./opencascade/BOPAlgo_SectionAttribute.hxx
    klass = m.attr("BOPAlgo_SectionAttribute");


    // nested enums

    static_cast<py::class_<BOPAlgo_SectionAttribute , shared_ptr<BOPAlgo_SectionAttribute>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const bool, const bool, const bool >()  , py::arg("theAproximation"),  py::arg("thePCurveOnS1"),  py::arg("thePCurveOnS2") )
    // custom constructors
    // methods
        .def("Approximation",
             (void (BOPAlgo_SectionAttribute::*)(  const bool  ) ) static_cast<void (BOPAlgo_SectionAttribute::*)(  const bool  ) >(&BOPAlgo_SectionAttribute::Approximation),
             R"#(Sets the Approximation flag)#"  , py::arg("theApprox")
          )
        .def("PCurveOnS1",
             (void (BOPAlgo_SectionAttribute::*)(  const bool  ) ) static_cast<void (BOPAlgo_SectionAttribute::*)(  const bool  ) >(&BOPAlgo_SectionAttribute::PCurveOnS1),
             R"#(Sets the PCurveOnS1 flag)#"  , py::arg("thePCurveOnS1")
          )
        .def("PCurveOnS2",
             (void (BOPAlgo_SectionAttribute::*)(  const bool  ) ) static_cast<void (BOPAlgo_SectionAttribute::*)(  const bool  ) >(&BOPAlgo_SectionAttribute::PCurveOnS2),
             R"#(Sets the PCurveOnS2 flag)#"  , py::arg("thePCurveOnS2")
          )
        .def("Approximation",
             (bool (BOPAlgo_SectionAttribute::*)() const) static_cast<bool (BOPAlgo_SectionAttribute::*)() const>(&BOPAlgo_SectionAttribute::Approximation),
             R"#(Returns the Approximation flag)#" 
          )
        .def("PCurveOnS1",
             (bool (BOPAlgo_SectionAttribute::*)() const) static_cast<bool (BOPAlgo_SectionAttribute::*)() const>(&BOPAlgo_SectionAttribute::PCurveOnS1),
             R"#(Returns the PCurveOnS1 flag)#" 
          )
        .def("PCurveOnS2",
             (bool (BOPAlgo_SectionAttribute::*)() const) static_cast<bool (BOPAlgo_SectionAttribute::*)() const>(&BOPAlgo_SectionAttribute::PCurveOnS2),
             R"#(Returns the PCurveOnS2 flag)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BOPAlgo_Tools from ./opencascade/BOPAlgo_Tools.hxx
    klass = m.attr("BOPAlgo_Tools");

    // default constructor
    register_default_constructor<BOPAlgo_Tools , shared_ptr<BOPAlgo_Tools>>(m,"BOPAlgo_Tools");

    // nested enums

    static_cast<py::class_<BOPAlgo_Tools , shared_ptr<BOPAlgo_Tools>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("EdgesToWires_s",
                    (int (*)(  const TopoDS_Shape & ,  TopoDS_Shape & ,   const bool ,   const double  ) ) static_cast<int (*)(  const TopoDS_Shape & ,  TopoDS_Shape & ,   const bool ,   const double  ) >(&BOPAlgo_Tools::EdgesToWires),
                    R"#(Creates planar wires from the given edges. The input edges are expected to be planar. And for the performance sake the method does not check if the edges are really planar. Thus, the result wires will also be not planar if the input edges are not planar. The edges may be not shared, but the resulting wires will be sharing the coinciding parts and intersecting parts. The output wires may be non-manifold and contain free and multi-connected vertices. Parameters: <theEdges> - input edges; <theWires> - output wires; <theShared> - boolean flag which defines whether the input edges are already shared or have to be intersected; <theAngTol> - the angular tolerance which will be used for distinguishing the planes in which the edges are located. Default value is 1.e-8 which is used for intersection of planes in IntTools_FaceFace. Method returns the following error statuses: 0 - in case of success (at least one wire has been built); 1 - in case there are no edges in the given shape; 2 - sharing of the edges has failed.)#"  , py::arg("theEdges"),  py::arg("theWires"),  py::arg("theShared")=static_cast< const bool>(false),  py::arg("theAngTol")=static_cast< const double>(1.e-8)
          )
        .def_static("WiresToFaces_s",
                    (bool (*)(  const TopoDS_Shape & ,  TopoDS_Shape & ,   const double  ) ) static_cast<bool (*)(  const TopoDS_Shape & ,  TopoDS_Shape & ,   const double  ) >(&BOPAlgo_Tools::WiresToFaces),
                    R"#(Creates planar faces from given planar wires. The method does not check if the wires are really planar. The input wires may be non-manifold but should be shared. The wires located in the same planes and included into other wires will create holes in the faces built from outer wires. The tolerance values of the input shapes may be modified during the operation due to projection of the edges on the planes for creation of 2D curves. Parameters: <theWires> - the given wires; <theFaces> - the output faces; <theAngTol> - the angular tolerance for distinguishing the planes in which the wires are located. Default value is 1.e-8 which is used for intersection of planes in IntTools_FaceFace. Method returns TRUE in case of success, i.e. at least one face has been built.)#"  , py::arg("theWires"),  py::arg("theFaces"),  py::arg("theAngTol")=static_cast< const double>(1.e-8)
          )
        .def_static("IntersectVertices_s",
                    (void (*)(  const NCollection_IndexedDataMap<TopoDS_Shape, double, TopTools_ShapeMapHasher> & ,   const double ,  NCollection_List<NCollection_List<TopoDS_Shape>> &  ) ) static_cast<void (*)(  const NCollection_IndexedDataMap<TopoDS_Shape, double, TopTools_ShapeMapHasher> & ,   const double ,  NCollection_List<NCollection_List<TopoDS_Shape>> &  ) >(&BOPAlgo_Tools::IntersectVertices),
                    R"#(Finds chains of intersecting vertices)#"  , py::arg("theVertices"),  py::arg("theFuzzyValue"),  py::arg("theChains")
          )
        .def_static("TrsfToPoint_s",
                    (bool (*)(  const Bnd_Box & ,   const Bnd_Box & ,  gp_Trsf & ,   const gp_Pnt & ,   const double  ) ) static_cast<bool (*)(  const Bnd_Box & ,   const Bnd_Box & ,  gp_Trsf & ,   const gp_Pnt & ,   const double  ) >(&BOPAlgo_Tools::TrsfToPoint),
                    R"#(Computes the transformation needed to move the objects to the given point to increase the quality of computations. Returns true if the objects are located far from the given point (relatively given criteria), false otherwise.)#"  , py::arg("theBox1"),  py::arg("theBox2"),  py::arg("theTrsf"),  py::arg("thePoint")=static_cast< const gp_Pnt &>(gp_Pnt ( 0.0 , 0.0 , 0.0 )),  py::arg("theCriteria")=static_cast< const double>(1.e+5)
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BOPAlgo_WireEdgeSet from ./opencascade/BOPAlgo_WireEdgeSet.hxx
    klass = m.attr("BOPAlgo_WireEdgeSet");


    // nested enums

    static_cast<py::class_<BOPAlgo_WireEdgeSet , shared_ptr<BOPAlgo_WireEdgeSet>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
        .def("Clear",
             (void (BOPAlgo_WireEdgeSet::*)() ) static_cast<void (BOPAlgo_WireEdgeSet::*)() >(&BOPAlgo_WireEdgeSet::Clear),
             R"#()#" 
          )
        .def("SetFace",
             (void (BOPAlgo_WireEdgeSet::*)(  const TopoDS_Face &  ) ) static_cast<void (BOPAlgo_WireEdgeSet::*)(  const TopoDS_Face &  ) >(&BOPAlgo_WireEdgeSet::SetFace),
             R"#()#"  , py::arg("aF")
          )
        .def("AddStartElement",
             (void (BOPAlgo_WireEdgeSet::*)(  const TopoDS_Shape &  ) ) static_cast<void (BOPAlgo_WireEdgeSet::*)(  const TopoDS_Shape &  ) >(&BOPAlgo_WireEdgeSet::AddStartElement),
             R"#()#"  , py::arg("sS")
          )
        .def("AddShape",
             (void (BOPAlgo_WireEdgeSet::*)(  const TopoDS_Shape &  ) ) static_cast<void (BOPAlgo_WireEdgeSet::*)(  const TopoDS_Shape &  ) >(&BOPAlgo_WireEdgeSet::AddShape),
             R"#()#"  , py::arg("sS")
          )
        .def("Clear",
             (void (BOPAlgo_WireEdgeSet::*)() ) static_cast<void (BOPAlgo_WireEdgeSet::*)() >(&BOPAlgo_WireEdgeSet::Clear),
             R"#()#" 
          )
        .def("SetFace",
             (void (BOPAlgo_WireEdgeSet::*)(  const TopoDS_Face &  ) ) static_cast<void (BOPAlgo_WireEdgeSet::*)(  const TopoDS_Face &  ) >(&BOPAlgo_WireEdgeSet::SetFace),
             R"#()#"  , py::arg("aF")
          )
        .def("AddStartElement",
             (void (BOPAlgo_WireEdgeSet::*)(  const TopoDS_Shape &  ) ) static_cast<void (BOPAlgo_WireEdgeSet::*)(  const TopoDS_Shape &  ) >(&BOPAlgo_WireEdgeSet::AddStartElement),
             R"#()#"  , py::arg("aE")
          )
        .def("AddShape",
             (void (BOPAlgo_WireEdgeSet::*)(  const TopoDS_Shape &  ) ) static_cast<void (BOPAlgo_WireEdgeSet::*)(  const TopoDS_Shape &  ) >(&BOPAlgo_WireEdgeSet::AddShape),
             R"#()#"  , py::arg("aW")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Face",
             ( const TopoDS_Face & (BOPAlgo_WireEdgeSet::*)() const) static_cast< const TopoDS_Face & (BOPAlgo_WireEdgeSet::*)() const>(&BOPAlgo_WireEdgeSet::Face),
             R"#()#"
             
         )
       .def("StartElements",
             ( const NCollection_List<TopoDS_Shape> & (BOPAlgo_WireEdgeSet::*)() const) static_cast< const NCollection_List<TopoDS_Shape> & (BOPAlgo_WireEdgeSet::*)() const>(&BOPAlgo_WireEdgeSet::StartElements),
             R"#()#"
             
         )
       .def("Shapes",
             ( const NCollection_List<TopoDS_Shape> & (BOPAlgo_WireEdgeSet::*)() const) static_cast< const NCollection_List<TopoDS_Shape> & (BOPAlgo_WireEdgeSet::*)() const>(&BOPAlgo_WireEdgeSet::Shapes),
             R"#()#"
             
         )
       .def("Face",
             ( const TopoDS_Face & (BOPAlgo_WireEdgeSet::*)() const) static_cast< const TopoDS_Face & (BOPAlgo_WireEdgeSet::*)() const>(&BOPAlgo_WireEdgeSet::Face),
             R"#()#"
             
         )
       .def("StartElements",
             ( const NCollection_List<TopoDS_Shape> & (BOPAlgo_WireEdgeSet::*)() const) static_cast< const NCollection_List<TopoDS_Shape> & (BOPAlgo_WireEdgeSet::*)() const>(&BOPAlgo_WireEdgeSet::StartElements),
             R"#()#"
             
         )
       .def("Shapes",
             ( const NCollection_List<TopoDS_Shape> & (BOPAlgo_WireEdgeSet::*)() const) static_cast< const NCollection_List<TopoDS_Shape> & (BOPAlgo_WireEdgeSet::*)() const>(&BOPAlgo_WireEdgeSet::Shapes),
             R"#()#"
             
         )
;

    // Class BOPAlgo_Algo from ./opencascade/BOPAlgo_Algo.hxx
    klass = m.attr("BOPAlgo_Algo");


    // nested enums

    static_cast<py::class_<BOPAlgo_Algo , shared_ptr_nodelete<BOPAlgo_Algo> ,Py_BOPAlgo_Algo , BOPAlgo_Options >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("Perform",
             (void (BOPAlgo_Algo::*)(  const Message_ProgressRange &  ) ) static_cast<void (BOPAlgo_Algo::*)(  const Message_ProgressRange &  ) >(&BOPAlgo_Algo::Perform),
             R"#(The main method to implement the operation Providing the range allows to enable Progress indicator User break functionalities.)#"  , py::arg("theRange")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BOPAlgo_MakeConnected from ./opencascade/BOPAlgo_MakeConnected.hxx
    klass = m.attr("BOPAlgo_MakeConnected");


    // nested enums

    static_cast<py::class_<BOPAlgo_MakeConnected , shared_ptr<BOPAlgo_MakeConnected>  , BOPAlgo_Options >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetArguments",
             (void (BOPAlgo_MakeConnected::*)(  const NCollection_List<TopoDS_Shape> &  ) ) static_cast<void (BOPAlgo_MakeConnected::*)(  const NCollection_List<TopoDS_Shape> &  ) >(&BOPAlgo_MakeConnected::SetArguments),
             R"#(Sets the shape for making them connected.)#"  , py::arg("theArgs")
          )
        .def("AddArgument",
             (void (BOPAlgo_MakeConnected::*)(  const TopoDS_Shape &  ) ) static_cast<void (BOPAlgo_MakeConnected::*)(  const TopoDS_Shape &  ) >(&BOPAlgo_MakeConnected::AddArgument),
             R"#(Adds the shape to the arguments.)#"  , py::arg("theS")
          )
        .def("Perform",
             (void (BOPAlgo_MakeConnected::*)() ) static_cast<void (BOPAlgo_MakeConnected::*)() >(&BOPAlgo_MakeConnected::Perform),
             R"#(Performs the operation, i.e. makes the input shapes connected.)#" 
          )
        .def("MakePeriodic",
             (void (BOPAlgo_MakeConnected::*)(  const BOPAlgo_MakePeriodic::PeriodicityParams &  ) ) static_cast<void (BOPAlgo_MakeConnected::*)(  const BOPAlgo_MakePeriodic::PeriodicityParams &  ) >(&BOPAlgo_MakeConnected::MakePeriodic),
             R"#(Makes the connected shape periodic. Repeated calls of this method overwrite the previous calls working with the basis connected shape.)#"  , py::arg("theParams")
          )
        .def("RepeatShape",
             (void (BOPAlgo_MakeConnected::*)(  const int ,   const int  ) ) static_cast<void (BOPAlgo_MakeConnected::*)(  const int ,   const int  ) >(&BOPAlgo_MakeConnected::RepeatShape),
             R"#(Performs repetition of the periodic shape in specified direction required number of times.)#"  , py::arg("theDirectionID"),  py::arg("theTimes")
          )
        .def("ClearRepetitions",
             (void (BOPAlgo_MakeConnected::*)() ) static_cast<void (BOPAlgo_MakeConnected::*)() >(&BOPAlgo_MakeConnected::ClearRepetitions),
             R"#(Clears the repetitions performed on the periodic shape, keeping the shape periodic.)#" 
          )
        .def("MaterialsOnPositiveSide",
             ( const NCollection_List<TopoDS_Shape> & (BOPAlgo_MakeConnected::*)(  const TopoDS_Shape &  ) ) static_cast< const NCollection_List<TopoDS_Shape> & (BOPAlgo_MakeConnected::*)(  const TopoDS_Shape &  ) >(&BOPAlgo_MakeConnected::MaterialsOnPositiveSide),
             R"#(Returns the original shapes which images contain the the given shape with FORWARD orientation.)#"  , py::arg("theS")
          )
        .def("MaterialsOnNegativeSide",
             ( const NCollection_List<TopoDS_Shape> & (BOPAlgo_MakeConnected::*)(  const TopoDS_Shape &  ) ) static_cast< const NCollection_List<TopoDS_Shape> & (BOPAlgo_MakeConnected::*)(  const TopoDS_Shape &  ) >(&BOPAlgo_MakeConnected::MaterialsOnNegativeSide),
             R"#(Returns the original shapes which images contain the the given shape with REVERSED orientation.)#"  , py::arg("theS")
          )
        .def("GetModified",
             ( const NCollection_List<TopoDS_Shape> & (BOPAlgo_MakeConnected::*)(  const TopoDS_Shape &  ) ) static_cast< const NCollection_List<TopoDS_Shape> & (BOPAlgo_MakeConnected::*)(  const TopoDS_Shape &  ) >(&BOPAlgo_MakeConnected::GetModified),
             R"#(Returns the list of shapes modified from the given shape.)#"  , py::arg("theS")
          )
        .def("GetOrigins",
             ( const NCollection_List<TopoDS_Shape> & (BOPAlgo_MakeConnected::*)(  const TopoDS_Shape &  ) ) static_cast< const NCollection_List<TopoDS_Shape> & (BOPAlgo_MakeConnected::*)(  const TopoDS_Shape &  ) >(&BOPAlgo_MakeConnected::GetOrigins),
             R"#(Returns the list of original shapes from which the current shape has been created.)#"  , py::arg("theS")
          )
        .def("Clear",
             (void (BOPAlgo_MakeConnected::*)() ) static_cast<void (BOPAlgo_MakeConnected::*)() >(&BOPAlgo_MakeConnected::Clear),
             R"#(Clears the contents of the algorithm.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Arguments",
             ( const NCollection_List<TopoDS_Shape> & (BOPAlgo_MakeConnected::*)() const) static_cast< const NCollection_List<TopoDS_Shape> & (BOPAlgo_MakeConnected::*)() const>(&BOPAlgo_MakeConnected::Arguments),
             R"#(Returns the list of arguments of the operation.)#"
             
         )
       .def("PeriodicityTool",
             ( const BOPAlgo_MakePeriodic & (BOPAlgo_MakeConnected::*)() const) static_cast< const BOPAlgo_MakePeriodic & (BOPAlgo_MakeConnected::*)() const>(&BOPAlgo_MakeConnected::PeriodicityTool),
             R"#(Returns the periodicity tool.)#"
             
         )
       .def("History",
             ( const handle<BRepTools_History> & (BOPAlgo_MakeConnected::*)() const) static_cast< const handle<BRepTools_History> & (BOPAlgo_MakeConnected::*)() const>(&BOPAlgo_MakeConnected::History),
             R"#(Returns the history of operations)#"
             
         )
       .def("Shape",
             ( const TopoDS_Shape & (BOPAlgo_MakeConnected::*)() const) static_cast< const TopoDS_Shape & (BOPAlgo_MakeConnected::*)() const>(&BOPAlgo_MakeConnected::Shape),
             R"#(Returns the resulting connected shape)#"
             
         )
       .def("PeriodicShape",
             ( const TopoDS_Shape & (BOPAlgo_MakeConnected::*)() const) static_cast< const TopoDS_Shape & (BOPAlgo_MakeConnected::*)() const>(&BOPAlgo_MakeConnected::PeriodicShape),
             R"#(Returns the resulting periodic & repeated shape)#"
             
         )
;

    // Class BOPAlgo_MakePeriodic from ./opencascade/BOPAlgo_MakePeriodic.hxx
    klass = m.attr("BOPAlgo_MakePeriodic");


    // nested enums

    static_cast<py::class_<BOPAlgo_MakePeriodic , shared_ptr<BOPAlgo_MakePeriodic>  , BOPAlgo_Options >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetShape",
             (void (BOPAlgo_MakePeriodic::*)(  const TopoDS_Shape &  ) ) static_cast<void (BOPAlgo_MakePeriodic::*)(  const TopoDS_Shape &  ) >(&BOPAlgo_MakePeriodic::SetShape),
             R"#(Sets the shape to make it periodic.)#"  , py::arg("theShape")
          )
        .def("SetPeriodicityParameters",
             (void (BOPAlgo_MakePeriodic::*)(  const BOPAlgo_MakePeriodic::PeriodicityParams &  ) ) static_cast<void (BOPAlgo_MakePeriodic::*)(  const BOPAlgo_MakePeriodic::PeriodicityParams &  ) >(&BOPAlgo_MakePeriodic::SetPeriodicityParameters),
             R"#(Sets the periodicity parameters.)#"  , py::arg("theParams")
          )
        .def("MakePeriodic",
             (void (BOPAlgo_MakePeriodic::*)(  const int ,   const bool ,   const double  ) ) static_cast<void (BOPAlgo_MakePeriodic::*)(  const int ,   const bool ,   const double  ) >(&BOPAlgo_MakePeriodic::MakePeriodic),
             R"#(Sets the flag to make the shape periodic in specified direction: - 0 - X direction; - 1 - Y direction; - 2 - Z direction.)#"  , py::arg("theDirectionID"),  py::arg("theIsPeriodic"),  py::arg("thePeriod")=static_cast< const double>(0.0)
          )
        .def("IsPeriodic",
             (bool (BOPAlgo_MakePeriodic::*)(  const int  ) const) static_cast<bool (BOPAlgo_MakePeriodic::*)(  const int  ) const>(&BOPAlgo_MakePeriodic::IsPeriodic),
             R"#(Returns the info about Periodicity of the shape in specified direction.)#"  , py::arg("theDirectionID")
          )
        .def("Period",
             (double (BOPAlgo_MakePeriodic::*)(  const int  ) const) static_cast<double (BOPAlgo_MakePeriodic::*)(  const int  ) const>(&BOPAlgo_MakePeriodic::Period),
             R"#(Returns the Period of the shape in specified direction.)#"  , py::arg("theDirectionID")
          )
        .def("MakeXPeriodic",
             (void (BOPAlgo_MakePeriodic::*)(  const bool ,   const double  ) ) static_cast<void (BOPAlgo_MakePeriodic::*)(  const bool ,   const double  ) >(&BOPAlgo_MakePeriodic::MakeXPeriodic),
             R"#(Sets the flag to make the shape periodic in X direction.)#"  , py::arg("theIsPeriodic"),  py::arg("thePeriod")=static_cast< const double>(0.0)
          )
        .def("IsXPeriodic",
             (bool (BOPAlgo_MakePeriodic::*)() const) static_cast<bool (BOPAlgo_MakePeriodic::*)() const>(&BOPAlgo_MakePeriodic::IsXPeriodic),
             R"#(Returns the info about periodicity of the shape in X direction.)#" 
          )
        .def("XPeriod",
             (double (BOPAlgo_MakePeriodic::*)() const) static_cast<double (BOPAlgo_MakePeriodic::*)() const>(&BOPAlgo_MakePeriodic::XPeriod),
             R"#(Returns the XPeriod of the shape)#" 
          )
        .def("MakeYPeriodic",
             (void (BOPAlgo_MakePeriodic::*)(  const bool ,   const double  ) ) static_cast<void (BOPAlgo_MakePeriodic::*)(  const bool ,   const double  ) >(&BOPAlgo_MakePeriodic::MakeYPeriodic),
             R"#(Sets the flag to make the shape periodic in Y direction.)#"  , py::arg("theIsPeriodic"),  py::arg("thePeriod")=static_cast< const double>(0.0)
          )
        .def("IsYPeriodic",
             (bool (BOPAlgo_MakePeriodic::*)() const) static_cast<bool (BOPAlgo_MakePeriodic::*)() const>(&BOPAlgo_MakePeriodic::IsYPeriodic),
             R"#(Returns the info about periodicity of the shape in Y direction.)#" 
          )
        .def("YPeriod",
             (double (BOPAlgo_MakePeriodic::*)() const) static_cast<double (BOPAlgo_MakePeriodic::*)() const>(&BOPAlgo_MakePeriodic::YPeriod),
             R"#(Returns the YPeriod of the shape.)#" 
          )
        .def("MakeZPeriodic",
             (void (BOPAlgo_MakePeriodic::*)(  const bool ,   const double  ) ) static_cast<void (BOPAlgo_MakePeriodic::*)(  const bool ,   const double  ) >(&BOPAlgo_MakePeriodic::MakeZPeriodic),
             R"#(Sets the flag to make the shape periodic in Z direction.)#"  , py::arg("theIsPeriodic"),  py::arg("thePeriod")=static_cast< const double>(0.0)
          )
        .def("IsZPeriodic",
             (bool (BOPAlgo_MakePeriodic::*)() const) static_cast<bool (BOPAlgo_MakePeriodic::*)() const>(&BOPAlgo_MakePeriodic::IsZPeriodic),
             R"#(Returns the info about periodicity of the shape in Z direction.)#" 
          )
        .def("ZPeriod",
             (double (BOPAlgo_MakePeriodic::*)() const) static_cast<double (BOPAlgo_MakePeriodic::*)() const>(&BOPAlgo_MakePeriodic::ZPeriod),
             R"#(Returns the ZPeriod of the shape.)#" 
          )
        .def("SetTrimmed",
             (void (BOPAlgo_MakePeriodic::*)(  const int ,   const bool ,   const double  ) ) static_cast<void (BOPAlgo_MakePeriodic::*)(  const int ,   const bool ,   const double  ) >(&BOPAlgo_MakePeriodic::SetTrimmed),
             R"#(Defines whether the input shape is already trimmed in specified direction to fit the period in this direction. Direction is defined by an ID: - 0 - X direction; - 1 - Y direction; - 2 - Z direction.)#"  , py::arg("theDirectionID"),  py::arg("theIsTrimmed"),  py::arg("theFirst")=static_cast< const double>(0.0)
          )
        .def("IsInputTrimmed",
             (bool (BOPAlgo_MakePeriodic::*)(  const int  ) const) static_cast<bool (BOPAlgo_MakePeriodic::*)(  const int  ) const>(&BOPAlgo_MakePeriodic::IsInputTrimmed),
             R"#(Returns whether the input shape was trimmed in the specified direction.)#"  , py::arg("theDirectionID")
          )
        .def("PeriodFirst",
             (double (BOPAlgo_MakePeriodic::*)(  const int  ) const) static_cast<double (BOPAlgo_MakePeriodic::*)(  const int  ) const>(&BOPAlgo_MakePeriodic::PeriodFirst),
             R"#(Returns the first periodic parameter in the specified direction.)#"  , py::arg("theDirectionID")
          )
        .def("SetXTrimmed",
             (void (BOPAlgo_MakePeriodic::*)(  const bool ,   const bool  ) ) static_cast<void (BOPAlgo_MakePeriodic::*)(  const bool ,   const bool  ) >(&BOPAlgo_MakePeriodic::SetXTrimmed),
             R"#(Defines whether the input shape is already trimmed in X direction to fit the X period. If the shape is not trimmed it is required to set the first parameter for the X period. The algorithm will make the shape fit into the period.)#"  , py::arg("theIsTrimmed"),  py::arg("theFirst")=static_cast< const bool>(0.0)
          )
        .def("IsInputXTrimmed",
             (bool (BOPAlgo_MakePeriodic::*)() const) static_cast<bool (BOPAlgo_MakePeriodic::*)() const>(&BOPAlgo_MakePeriodic::IsInputXTrimmed),
             R"#(Returns whether the input shape was already trimmed for X period.)#" 
          )
        .def("XPeriodFirst",
             (double (BOPAlgo_MakePeriodic::*)() const) static_cast<double (BOPAlgo_MakePeriodic::*)() const>(&BOPAlgo_MakePeriodic::XPeriodFirst),
             R"#(Returns the first parameter for the X period.)#" 
          )
        .def("SetYTrimmed",
             (void (BOPAlgo_MakePeriodic::*)(  const bool ,   const bool  ) ) static_cast<void (BOPAlgo_MakePeriodic::*)(  const bool ,   const bool  ) >(&BOPAlgo_MakePeriodic::SetYTrimmed),
             R"#(Defines whether the input shape is already trimmed in Y direction to fit the Y period. If the shape is not trimmed it is required to set the first parameter for the Y period. The algorithm will make the shape fit into the period.)#"  , py::arg("theIsTrimmed"),  py::arg("theFirst")=static_cast< const bool>(0.0)
          )
        .def("IsInputYTrimmed",
             (bool (BOPAlgo_MakePeriodic::*)() const) static_cast<bool (BOPAlgo_MakePeriodic::*)() const>(&BOPAlgo_MakePeriodic::IsInputYTrimmed),
             R"#(Returns whether the input shape was already trimmed for Y period.)#" 
          )
        .def("YPeriodFirst",
             (double (BOPAlgo_MakePeriodic::*)() const) static_cast<double (BOPAlgo_MakePeriodic::*)() const>(&BOPAlgo_MakePeriodic::YPeriodFirst),
             R"#(Returns the first parameter for the Y period.)#" 
          )
        .def("SetZTrimmed",
             (void (BOPAlgo_MakePeriodic::*)(  const bool ,   const bool  ) ) static_cast<void (BOPAlgo_MakePeriodic::*)(  const bool ,   const bool  ) >(&BOPAlgo_MakePeriodic::SetZTrimmed),
             R"#(Defines whether the input shape is already trimmed in Z direction to fit the Z period. If the shape is not trimmed it is required to set the first parameter for the Z period. The algorithm will make the shape fit into the period.)#"  , py::arg("theIsTrimmed"),  py::arg("theFirst")=static_cast< const bool>(0.0)
          )
        .def("IsInputZTrimmed",
             (bool (BOPAlgo_MakePeriodic::*)() const) static_cast<bool (BOPAlgo_MakePeriodic::*)() const>(&BOPAlgo_MakePeriodic::IsInputZTrimmed),
             R"#(Returns whether the input shape was already trimmed for Z period.)#" 
          )
        .def("ZPeriodFirst",
             (double (BOPAlgo_MakePeriodic::*)() const) static_cast<double (BOPAlgo_MakePeriodic::*)() const>(&BOPAlgo_MakePeriodic::ZPeriodFirst),
             R"#(Returns the first parameter for the Z period.)#" 
          )
        .def("Perform",
             (void (BOPAlgo_MakePeriodic::*)() ) static_cast<void (BOPAlgo_MakePeriodic::*)() >(&BOPAlgo_MakePeriodic::Perform),
             R"#(Makes the shape periodic in necessary directions)#" 
          )
        .def("RepeatShape",
             ( const TopoDS_Shape & (BOPAlgo_MakePeriodic::*)(  const int ,   const int  ) ) static_cast< const TopoDS_Shape & (BOPAlgo_MakePeriodic::*)(  const int ,   const int  ) >(&BOPAlgo_MakePeriodic::RepeatShape),
             R"#(Performs repetition of the shape in specified direction required number of times. Negative value of times means that the repetition should be perform in negative direction. Makes the repeated shape a base for following repetitions.)#"  , py::arg("theDirectionID"),  py::arg("theTimes")
          )
        .def("XRepeat",
             ( const TopoDS_Shape & (BOPAlgo_MakePeriodic::*)(  const int  ) ) static_cast< const TopoDS_Shape & (BOPAlgo_MakePeriodic::*)(  const int  ) >(&BOPAlgo_MakePeriodic::XRepeat),
             R"#(Repeats the shape in X direction specified number of times. Negative value of times means that the repetition should be perform in negative X direction. Makes the repeated shape a base for following repetitions.)#"  , py::arg("theTimes")
          )
        .def("YRepeat",
             ( const TopoDS_Shape & (BOPAlgo_MakePeriodic::*)(  const int  ) ) static_cast< const TopoDS_Shape & (BOPAlgo_MakePeriodic::*)(  const int  ) >(&BOPAlgo_MakePeriodic::YRepeat),
             R"#(Repeats the shape in Y direction specified number of times. Negative value of times means that the repetition should be perform in negative Y direction. Makes the repeated shape a base for following repetitions.)#"  , py::arg("theTimes")
          )
        .def("ZRepeat",
             ( const TopoDS_Shape & (BOPAlgo_MakePeriodic::*)(  const int  ) ) static_cast< const TopoDS_Shape & (BOPAlgo_MakePeriodic::*)(  const int  ) >(&BOPAlgo_MakePeriodic::ZRepeat),
             R"#(Repeats the shape in Z direction specified number of times. Negative value of times means that the repetition should be perform in negative Z direction. Makes the repeated shape a base for following repetitions.)#"  , py::arg("theTimes")
          )
        .def("ClearRepetitions",
             (void (BOPAlgo_MakePeriodic::*)() ) static_cast<void (BOPAlgo_MakePeriodic::*)() >(&BOPAlgo_MakePeriodic::ClearRepetitions),
             R"#(Clears all performed repetitions. The next repetition will be performed on the base shape.)#" 
          )
        .def("GetTwins",
             ( const NCollection_List<TopoDS_Shape> & (BOPAlgo_MakePeriodic::*)(  const TopoDS_Shape &  ) const) static_cast< const NCollection_List<TopoDS_Shape> & (BOPAlgo_MakePeriodic::*)(  const TopoDS_Shape &  ) const>(&BOPAlgo_MakePeriodic::GetTwins),
             R"#(Returns the identical shapes for the given shape located on the opposite periodic side. Returns empty list in case the shape has no twin.)#"  , py::arg("theS")
          )
        .def("Clear",
             (void (BOPAlgo_MakePeriodic::*)() ) static_cast<void (BOPAlgo_MakePeriodic::*)() >(&BOPAlgo_MakePeriodic::Clear),
             R"#(Clears the algorithm from previous runs)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("ToDirectionID_s",
                    (int (*)(  const int  ) ) static_cast<int (*)(  const int  ) >(&BOPAlgo_MakePeriodic::ToDirectionID),
                    R"#(Converts the integer to ID of periodic direction)#"  , py::arg("theDirectionID")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("PeriodicityParameters",
             ( const BOPAlgo_MakePeriodic::PeriodicityParams & (BOPAlgo_MakePeriodic::*)() const) static_cast< const BOPAlgo_MakePeriodic::PeriodicityParams & (BOPAlgo_MakePeriodic::*)() const>(&BOPAlgo_MakePeriodic::PeriodicityParameters),
             R"#()#"
             
         )
       .def("RepeatedShape",
             ( const TopoDS_Shape & (BOPAlgo_MakePeriodic::*)() const) static_cast< const TopoDS_Shape & (BOPAlgo_MakePeriodic::*)() const>(&BOPAlgo_MakePeriodic::RepeatedShape),
             R"#(Returns the repeated shape)#"
             
         )
       .def("Shape",
             ( const TopoDS_Shape & (BOPAlgo_MakePeriodic::*)() const) static_cast< const TopoDS_Shape & (BOPAlgo_MakePeriodic::*)() const>(&BOPAlgo_MakePeriodic::Shape),
             R"#(Returns the resulting periodic shape)#"
             
         )
       .def("History",
             ( const handle<BRepTools_History> & (BOPAlgo_MakePeriodic::*)() const) static_cast< const handle<BRepTools_History> & (BOPAlgo_MakePeriodic::*)() const>(&BOPAlgo_MakePeriodic::History),
             R"#(Returns the History of the algorithm)#"
             
         )
;

    // Class BOPAlgo_ArgumentAnalyzer from ./opencascade/BOPAlgo_ArgumentAnalyzer.hxx
    klass = m.attr("BOPAlgo_ArgumentAnalyzer");


    // nested enums

    static_cast<py::class_<BOPAlgo_ArgumentAnalyzer , shared_ptr<BOPAlgo_ArgumentAnalyzer>  , BOPAlgo_Algo >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetShape1",
             (void (BOPAlgo_ArgumentAnalyzer::*)(  const TopoDS_Shape &  ) ) static_cast<void (BOPAlgo_ArgumentAnalyzer::*)(  const TopoDS_Shape &  ) >(&BOPAlgo_ArgumentAnalyzer::SetShape1),
             R"#(sets object shape)#"  , py::arg("TheShape")
          )
        .def("SetShape2",
             (void (BOPAlgo_ArgumentAnalyzer::*)(  const TopoDS_Shape &  ) ) static_cast<void (BOPAlgo_ArgumentAnalyzer::*)(  const TopoDS_Shape &  ) >(&BOPAlgo_ArgumentAnalyzer::SetShape2),
             R"#(sets tool shape)#"  , py::arg("TheShape")
          )
        .def("Perform",
             (void (BOPAlgo_ArgumentAnalyzer::*)(  const Message_ProgressRange &  ) ) static_cast<void (BOPAlgo_ArgumentAnalyzer::*)(  const Message_ProgressRange &  ) >(&BOPAlgo_ArgumentAnalyzer::Perform),
             R"#(performs analysis)#"  , py::arg("theRange")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def("HasFaulty",
             (bool (BOPAlgo_ArgumentAnalyzer::*)() const) static_cast<bool (BOPAlgo_ArgumentAnalyzer::*)() const>(&BOPAlgo_ArgumentAnalyzer::HasFaulty),
             R"#(result of test)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("GetShape1",
             ( const TopoDS_Shape & (BOPAlgo_ArgumentAnalyzer::*)() const) static_cast< const TopoDS_Shape & (BOPAlgo_ArgumentAnalyzer::*)() const>(&BOPAlgo_ArgumentAnalyzer::GetShape1),
             R"#(returns object shape;)#"
             
         )
       .def("GetShape2",
             ( const TopoDS_Shape & (BOPAlgo_ArgumentAnalyzer::*)() const) static_cast< const TopoDS_Shape & (BOPAlgo_ArgumentAnalyzer::*)() const>(&BOPAlgo_ArgumentAnalyzer::GetShape2),
             R"#(returns tool shape)#"
             
         )
       .def("OperationType",
             (BOPAlgo_Operation & (BOPAlgo_ArgumentAnalyzer::*)() ) static_cast<BOPAlgo_Operation & (BOPAlgo_ArgumentAnalyzer::*)() >(&BOPAlgo_ArgumentAnalyzer::OperationType),
             R"#(returns ref)#"
             
             , py::return_value_policy::reference_internal
         )
       .def_property("StopOnFirstFaulty",
                     [](BOPAlgo_ArgumentAnalyzer& self){return self.StopOnFirstFaulty();} ,
                     [](BOPAlgo_ArgumentAnalyzer& self, bool  val){self.StopOnFirstFaulty() = val;},                      R"#(returns ref)#"
         )
       .def_property("ArgumentTypeMode",
                     [](BOPAlgo_ArgumentAnalyzer& self){return self.ArgumentTypeMode();} ,
                     [](BOPAlgo_ArgumentAnalyzer& self, bool  val){self.ArgumentTypeMode() = val;},                      R"#(Returns (modifiable) mode that means checking types of shapes.)#"
         )
       .def_property("SelfInterMode",
                     [](BOPAlgo_ArgumentAnalyzer& self){return self.SelfInterMode();} ,
                     [](BOPAlgo_ArgumentAnalyzer& self, bool  val){self.SelfInterMode() = val;},                      R"#(Returns (modifiable) mode that means checking of self-intersection of shapes.)#"
         )
       .def_property("SmallEdgeMode",
                     [](BOPAlgo_ArgumentAnalyzer& self){return self.SmallEdgeMode();} ,
                     [](BOPAlgo_ArgumentAnalyzer& self, bool  val){self.SmallEdgeMode() = val;},                      R"#(Returns (modifiable) mode that means checking of small edges.)#"
         )
       .def_property("RebuildFaceMode",
                     [](BOPAlgo_ArgumentAnalyzer& self){return self.RebuildFaceMode();} ,
                     [](BOPAlgo_ArgumentAnalyzer& self, bool  val){self.RebuildFaceMode() = val;},                      R"#(Returns (modifiable) mode that means checking of possibility to split or rebuild faces.)#"
         )
       .def_property("TangentMode",
                     [](BOPAlgo_ArgumentAnalyzer& self){return self.TangentMode();} ,
                     [](BOPAlgo_ArgumentAnalyzer& self, bool  val){self.TangentMode() = val;},                      R"#(Returns (modifiable) mode that means checking of tangency between subshapes.)#"
         )
       .def_property("MergeVertexMode",
                     [](BOPAlgo_ArgumentAnalyzer& self){return self.MergeVertexMode();} ,
                     [](BOPAlgo_ArgumentAnalyzer& self, bool  val){self.MergeVertexMode() = val;},                      R"#(Returns (modifiable) mode that means checking of problem of merging vertices.)#"
         )
       .def_property("MergeEdgeMode",
                     [](BOPAlgo_ArgumentAnalyzer& self){return self.MergeEdgeMode();} ,
                     [](BOPAlgo_ArgumentAnalyzer& self, bool  val){self.MergeEdgeMode() = val;},                      R"#(Returns (modifiable) mode that means checking of problem of merging edges.)#"
         )
       .def_property("ContinuityMode",
                     [](BOPAlgo_ArgumentAnalyzer& self){return self.ContinuityMode();} ,
                     [](BOPAlgo_ArgumentAnalyzer& self, bool  val){self.ContinuityMode() = val;},                      R"#(Returns (modifiable) mode that means checking of problem of continuity of the shape.)#"
         )
       .def_property("CurveOnSurfaceMode",
                     [](BOPAlgo_ArgumentAnalyzer& self){return self.CurveOnSurfaceMode();} ,
                     [](BOPAlgo_ArgumentAnalyzer& self, bool  val){self.CurveOnSurfaceMode() = val;},                      R"#(Returns (modifiable) mode that means checking of problem of invalid curve on surface.)#"
         )
       .def("GetCheckResult",
             ( const NCollection_List<BOPAlgo_CheckResult> & (BOPAlgo_ArgumentAnalyzer::*)() const) static_cast< const NCollection_List<BOPAlgo_CheckResult> & (BOPAlgo_ArgumentAnalyzer::*)() const>(&BOPAlgo_ArgumentAnalyzer::GetCheckResult),
             R"#(returns a result of test)#"
             
         )
       .def_property("ArgumentTypeMode",
                     [](BOPAlgo_ArgumentAnalyzer& self){return self.ArgumentTypeMode();} ,
                     [](BOPAlgo_ArgumentAnalyzer& self, bool  val){self.ArgumentTypeMode() = val;},                      R"#(Returns (modifiable) mode that means checking types of shapes.)#"
         )
       .def_property("SelfInterMode",
                     [](BOPAlgo_ArgumentAnalyzer& self){return self.SelfInterMode();} ,
                     [](BOPAlgo_ArgumentAnalyzer& self, bool  val){self.SelfInterMode() = val;},                      R"#(Returns (modifiable) mode that means checking of self-intersection of shapes.)#"
         )
       .def_property("SmallEdgeMode",
                     [](BOPAlgo_ArgumentAnalyzer& self){return self.SmallEdgeMode();} ,
                     [](BOPAlgo_ArgumentAnalyzer& self, bool  val){self.SmallEdgeMode() = val;},                      R"#(Returns (modifiable) mode that means checking of small edges.)#"
         )
       .def_property("RebuildFaceMode",
                     [](BOPAlgo_ArgumentAnalyzer& self){return self.RebuildFaceMode();} ,
                     [](BOPAlgo_ArgumentAnalyzer& self, bool  val){self.RebuildFaceMode() = val;},                      R"#(Returns (modifiable) mode that means checking of possibility to split or rebuild faces.)#"
         )
       .def_property("TangentMode",
                     [](BOPAlgo_ArgumentAnalyzer& self){return self.TangentMode();} ,
                     [](BOPAlgo_ArgumentAnalyzer& self, bool  val){self.TangentMode() = val;},                      R"#(Returns (modifiable) mode that means checking of tangency between subshapes.)#"
         )
       .def_property("MergeVertexMode",
                     [](BOPAlgo_ArgumentAnalyzer& self){return self.MergeVertexMode();} ,
                     [](BOPAlgo_ArgumentAnalyzer& self, bool  val){self.MergeVertexMode() = val;},                      R"#(Returns (modifiable) mode that means checking of problem of merging vertices.)#"
         )
       .def_property("MergeEdgeMode",
                     [](BOPAlgo_ArgumentAnalyzer& self){return self.MergeEdgeMode();} ,
                     [](BOPAlgo_ArgumentAnalyzer& self, bool  val){self.MergeEdgeMode() = val;},                      R"#(Returns (modifiable) mode that means checking of problem of merging edges.)#"
         )
       .def_property("ContinuityMode",
                     [](BOPAlgo_ArgumentAnalyzer& self){return self.ContinuityMode();} ,
                     [](BOPAlgo_ArgumentAnalyzer& self, bool  val){self.ContinuityMode() = val;},                      R"#(Returns (modifiable) mode that means checking of problem of continuity of the shape.)#"
         )
       .def_property("CurveOnSurfaceMode",
                     [](BOPAlgo_ArgumentAnalyzer& self){return self.CurveOnSurfaceMode();} ,
                     [](BOPAlgo_ArgumentAnalyzer& self, bool  val){self.CurveOnSurfaceMode() = val;},                      R"#(Returns (modifiable) mode that means checking of problem of invalid curve on surface.)#"
         )
;

    // Class BOPAlgo_BuilderArea from ./opencascade/BOPAlgo_BuilderArea.hxx
    klass = m.attr("BOPAlgo_BuilderArea");


    // nested enums

    static_cast<py::class_<BOPAlgo_BuilderArea , shared_ptr_nodelete<BOPAlgo_BuilderArea> ,Py_BOPAlgo_BuilderArea , BOPAlgo_Algo >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("SetShapes",
             (void (BOPAlgo_BuilderArea::*)(  const NCollection_List<TopoDS_Shape> &  ) ) static_cast<void (BOPAlgo_BuilderArea::*)(  const NCollection_List<TopoDS_Shape> &  ) >(&BOPAlgo_BuilderArea::SetShapes),
             R"#(Sets the shapes for building areas)#"  , py::arg("theLS")
          )
        .def("SetAvoidInternalShapes",
             (void (BOPAlgo_BuilderArea::*)(  const bool  ) ) static_cast<void (BOPAlgo_BuilderArea::*)(  const bool  ) >(&BOPAlgo_BuilderArea::SetAvoidInternalShapes),
             R"#(Defines the preventing of addition of internal parts into result. The default value is FALSE, i.e. the internal parts are added into result.)#"  , py::arg("theAvoidInternal")
          )
        .def("IsAvoidInternalShapes",
             (bool (BOPAlgo_BuilderArea::*)() const) static_cast<bool (BOPAlgo_BuilderArea::*)() const>(&BOPAlgo_BuilderArea::IsAvoidInternalShapes),
             R"#(Returns the AvoidInternalShapes flag)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Shapes",
             ( const NCollection_List<TopoDS_Shape> & (BOPAlgo_BuilderArea::*)() const) static_cast< const NCollection_List<TopoDS_Shape> & (BOPAlgo_BuilderArea::*)() const>(&BOPAlgo_BuilderArea::Shapes),
             R"#(Returns the input shapes)#"
             
         )
       .def("Loops",
             ( const NCollection_List<TopoDS_Shape> & (BOPAlgo_BuilderArea::*)() const) static_cast< const NCollection_List<TopoDS_Shape> & (BOPAlgo_BuilderArea::*)() const>(&BOPAlgo_BuilderArea::Loops),
             R"#(Returns the found loops)#"
             
         )
       .def("Areas",
             ( const NCollection_List<TopoDS_Shape> & (BOPAlgo_BuilderArea::*)() const) static_cast< const NCollection_List<TopoDS_Shape> & (BOPAlgo_BuilderArea::*)() const>(&BOPAlgo_BuilderArea::Areas),
             R"#(Returns the found areas)#"
             
         )
;

    // Class BOPAlgo_BuilderShape from ./opencascade/BOPAlgo_BuilderShape.hxx
    klass = m.attr("BOPAlgo_BuilderShape");


    // nested enums

    static_cast<py::class_<BOPAlgo_BuilderShape , shared_ptr<BOPAlgo_BuilderShape> ,Py_BOPAlgo_BuilderShape , BOPAlgo_Algo >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("Modified",
             ( const NCollection_List<TopoDS_Shape> & (BOPAlgo_BuilderShape::*)(  const TopoDS_Shape &  ) ) static_cast< const NCollection_List<TopoDS_Shape> & (BOPAlgo_BuilderShape::*)(  const TopoDS_Shape &  ) >(&BOPAlgo_BuilderShape::Modified),
             R"#(Returns the list of shapes Modified from the shape theS.)#"  , py::arg("theS")
          )
        .def("Generated",
             ( const NCollection_List<TopoDS_Shape> & (BOPAlgo_BuilderShape::*)(  const TopoDS_Shape &  ) ) static_cast< const NCollection_List<TopoDS_Shape> & (BOPAlgo_BuilderShape::*)(  const TopoDS_Shape &  ) >(&BOPAlgo_BuilderShape::Generated),
             R"#(Returns the list of shapes Generated from the shape theS.)#"  , py::arg("theS")
          )
        .def("IsDeleted",
             (bool (BOPAlgo_BuilderShape::*)(  const TopoDS_Shape &  ) ) static_cast<bool (BOPAlgo_BuilderShape::*)(  const TopoDS_Shape &  ) >(&BOPAlgo_BuilderShape::IsDeleted),
             R"#(Returns true if the shape theS has been deleted. In this case the shape will have no Modified elements, but can have Generated elements.)#"  , py::arg("theS")
          )
        .def("HasModified",
             (bool (BOPAlgo_BuilderShape::*)() const) static_cast<bool (BOPAlgo_BuilderShape::*)() const>(&BOPAlgo_BuilderShape::HasModified),
             R"#(Returns true if any of the input shapes has been modified during operation.)#" 
          )
        .def("HasGenerated",
             (bool (BOPAlgo_BuilderShape::*)() const) static_cast<bool (BOPAlgo_BuilderShape::*)() const>(&BOPAlgo_BuilderShape::HasGenerated),
             R"#(Returns true if any of the input shapes has generated shapes during operation.)#" 
          )
        .def("HasDeleted",
             (bool (BOPAlgo_BuilderShape::*)() const) static_cast<bool (BOPAlgo_BuilderShape::*)() const>(&BOPAlgo_BuilderShape::HasDeleted),
             R"#(Returns true if any of the input shapes has been deleted during operation.)#" 
          )
        .def("History",
             (handle<BRepTools_History> (BOPAlgo_BuilderShape::*)() ) static_cast<handle<BRepTools_History> (BOPAlgo_BuilderShape::*)() >(&BOPAlgo_BuilderShape::History),
             R"#(History Tool)#" 
          )
        .def("SetToFillHistory",
             (void (BOPAlgo_BuilderShape::*)(  const bool  ) ) static_cast<void (BOPAlgo_BuilderShape::*)(  const bool  ) >(&BOPAlgo_BuilderShape::SetToFillHistory),
             R"#(Allows disabling the history collection)#"  , py::arg("theHistFlag")
          )
        .def("HasHistory",
             (bool (BOPAlgo_BuilderShape::*)() const) static_cast<bool (BOPAlgo_BuilderShape::*)() const>(&BOPAlgo_BuilderShape::HasHistory),
             R"#(Returns flag of history availability)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Shape",
             ( const TopoDS_Shape & (BOPAlgo_BuilderShape::*)() const) static_cast< const TopoDS_Shape & (BOPAlgo_BuilderShape::*)() const>(&BOPAlgo_BuilderShape::Shape),
             R"#(Returns the result of algorithm)#"
             
         )
;

    // Class BOPAlgo_ParallelAlgo from ./opencascade/BOPAlgo_Algo.hxx
    klass = m.attr("BOPAlgo_ParallelAlgo");


    // nested enums

    static_cast<py::class_<BOPAlgo_ParallelAlgo , shared_ptr<BOPAlgo_ParallelAlgo> ,Py_BOPAlgo_ParallelAlgo , BOPAlgo_Algo >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("Perform",
             (void (BOPAlgo_ParallelAlgo::*)() ) static_cast<void (BOPAlgo_ParallelAlgo::*)() >(&BOPAlgo_ParallelAlgo::Perform),
             R"#(The main method to implement the operation)#" 
          )
        .def("SetProgressRange",
             (void (BOPAlgo_ParallelAlgo::*)(  const Message_ProgressRange &  ) ) static_cast<void (BOPAlgo_ParallelAlgo::*)(  const Message_ProgressRange &  ) >(&BOPAlgo_ParallelAlgo::SetProgressRange),
             R"#(Sets the range for a single run)#"  , py::arg("theRange")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BOPAlgo_PaveFiller from ./opencascade/BOPAlgo_PaveFiller.hxx
    klass = m.attr("BOPAlgo_PaveFiller");


    // nested enums

    static_cast<py::class_<BOPAlgo_PaveFiller , shared_ptr<BOPAlgo_PaveFiller>  , BOPAlgo_Algo >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
        .def("SetArguments",
             (void (BOPAlgo_PaveFiller::*)(  const NCollection_List<TopoDS_Shape> &  ) ) static_cast<void (BOPAlgo_PaveFiller::*)(  const NCollection_List<TopoDS_Shape> &  ) >(&BOPAlgo_PaveFiller::SetArguments),
             R"#(Sets the arguments for operation)#"  , py::arg("theLS")
          )
        .def("AddArgument",
             (void (BOPAlgo_PaveFiller::*)(  const TopoDS_Shape &  ) ) static_cast<void (BOPAlgo_PaveFiller::*)(  const TopoDS_Shape &  ) >(&BOPAlgo_PaveFiller::AddArgument),
             R"#(Adds the argument for operation)#"  , py::arg("theShape")
          )
        .def("SetSectionAttribute",
             (void (BOPAlgo_PaveFiller::*)(  const BOPAlgo_SectionAttribute &  ) ) static_cast<void (BOPAlgo_PaveFiller::*)(  const BOPAlgo_SectionAttribute &  ) >(&BOPAlgo_PaveFiller::SetSectionAttribute),
             R"#()#"  , py::arg("theSecAttr")
          )
        .def("SetNonDestructive",
             (void (BOPAlgo_PaveFiller::*)(  const bool  ) ) static_cast<void (BOPAlgo_PaveFiller::*)(  const bool  ) >(&BOPAlgo_PaveFiller::SetNonDestructive),
             R"#(Sets the flag that defines the mode of treatment. In non-destructive mode the argument shapes are not modified. Instead a copy of a sub-shape is created in the result if it is needed to be updated.)#"  , py::arg("theFlag")
          )
        .def("NonDestructive",
             (bool (BOPAlgo_PaveFiller::*)() const) static_cast<bool (BOPAlgo_PaveFiller::*)() const>(&BOPAlgo_PaveFiller::NonDestructive),
             R"#(Returns the flag that defines the mode of treatment. In non-destructive mode the argument shapes are not modified. Instead a copy of a sub-shape is created in the result if it is needed to be updated.)#" 
          )
        .def("Perform",
             (void (BOPAlgo_PaveFiller::*)(  const Message_ProgressRange &  ) ) static_cast<void (BOPAlgo_PaveFiller::*)(  const Message_ProgressRange &  ) >(&BOPAlgo_PaveFiller::Perform),
             R"#()#"  , py::arg("theRange")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def("SetGlue",
             (void (BOPAlgo_PaveFiller::*)(  const BOPAlgo_GlueEnum  ) ) static_cast<void (BOPAlgo_PaveFiller::*)(  const BOPAlgo_GlueEnum  ) >(&BOPAlgo_PaveFiller::SetGlue),
             R"#(Sets the glue option for the algorithm)#"  , py::arg("theGlue")
          )
        .def("Glue",
             (BOPAlgo_GlueEnum (BOPAlgo_PaveFiller::*)() const) static_cast<BOPAlgo_GlueEnum (BOPAlgo_PaveFiller::*)() const>(&BOPAlgo_PaveFiller::Glue),
             R"#(Returns the glue option of the algorithm)#" 
          )
        .def("SetAvoidBuildPCurve",
             (void (BOPAlgo_PaveFiller::*)(  const bool  ) ) static_cast<void (BOPAlgo_PaveFiller::*)(  const bool  ) >(&BOPAlgo_PaveFiller::SetAvoidBuildPCurve),
             R"#(Sets the flag to avoid building of p-curves of edges on faces)#"  , py::arg("theValue")
          )
        .def("IsAvoidBuildPCurve",
             (bool (BOPAlgo_PaveFiller::*)() const) static_cast<bool (BOPAlgo_PaveFiller::*)() const>(&BOPAlgo_PaveFiller::IsAvoidBuildPCurve),
             R"#(Returns the flag to avoid building of p-curves of edges on faces)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Arguments",
             ( const NCollection_List<TopoDS_Shape> & (BOPAlgo_PaveFiller::*)() const) static_cast< const NCollection_List<TopoDS_Shape> & (BOPAlgo_PaveFiller::*)() const>(&BOPAlgo_PaveFiller::Arguments),
             R"#(Returns the list of arguments)#"
             
         )
;

    // Class BOPAlgo_ShellSplitter from ./opencascade/BOPAlgo_ShellSplitter.hxx
    klass = m.attr("BOPAlgo_ShellSplitter");


    // nested enums

    static_cast<py::class_<BOPAlgo_ShellSplitter , shared_ptr<BOPAlgo_ShellSplitter>  , BOPAlgo_Algo >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
        .def("AddStartElement",
             (void (BOPAlgo_ShellSplitter::*)(  const TopoDS_Shape &  ) ) static_cast<void (BOPAlgo_ShellSplitter::*)(  const TopoDS_Shape &  ) >(&BOPAlgo_ShellSplitter::AddStartElement),
             R"#(adds a face <theS> to process)#"  , py::arg("theS")
          )
        .def("Perform",
             (void (BOPAlgo_ShellSplitter::*)(  const Message_ProgressRange &  ) ) static_cast<void (BOPAlgo_ShellSplitter::*)(  const Message_ProgressRange &  ) >(&BOPAlgo_ShellSplitter::Perform),
             R"#(performs the algorithm)#"  , py::arg("theRange")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("StartElements",
             ( const NCollection_List<TopoDS_Shape> & (BOPAlgo_ShellSplitter::*)() const) static_cast< const NCollection_List<TopoDS_Shape> & (BOPAlgo_ShellSplitter::*)() const>(&BOPAlgo_ShellSplitter::StartElements),
             R"#(return the faces to process)#"
             
         )
       .def("Shells",
             ( const NCollection_List<TopoDS_Shape> & (BOPAlgo_ShellSplitter::*)() const) static_cast< const NCollection_List<TopoDS_Shape> & (BOPAlgo_ShellSplitter::*)() const>(&BOPAlgo_ShellSplitter::Shells),
             R"#(returns the loops)#"
             
         )
;

    // Class BOPAlgo_WireSplitter from ./opencascade/BOPAlgo_WireSplitter.hxx
    klass = m.attr("BOPAlgo_WireSplitter");


    // nested enums

    static_cast<py::class_<BOPAlgo_WireSplitter , shared_ptr<BOPAlgo_WireSplitter>  , BOPAlgo_Algo >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
        .def("SetWES",
             (void (BOPAlgo_WireSplitter::*)(  const BOPAlgo_WireEdgeSet &  ) ) static_cast<void (BOPAlgo_WireSplitter::*)(  const BOPAlgo_WireEdgeSet &  ) >(&BOPAlgo_WireSplitter::SetWES),
             R"#()#"  , py::arg("theWES")
          )
        .def("Perform",
             (void (BOPAlgo_WireSplitter::*)(  const Message_ProgressRange &  ) ) static_cast<void (BOPAlgo_WireSplitter::*)(  const Message_ProgressRange &  ) >(&BOPAlgo_WireSplitter::Perform),
             R"#()#"  , py::arg("theRange")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("MakeWire_s",
                    (void (*)( NCollection_List<TopoDS_Shape> & ,  TopoDS_Wire &  ) ) static_cast<void (*)( NCollection_List<TopoDS_Shape> & ,  TopoDS_Wire &  ) >(&BOPAlgo_WireSplitter::MakeWire),
                    R"#()#"  , py::arg("theLE"),  py::arg("theW")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("WES",
             (BOPAlgo_WireEdgeSet & (BOPAlgo_WireSplitter::*)() ) static_cast<BOPAlgo_WireEdgeSet & (BOPAlgo_WireSplitter::*)() >(&BOPAlgo_WireSplitter::WES),
             R"#()#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class BOPAlgo_Builder from ./opencascade/BOPAlgo_Builder.hxx
    klass = m.attr("BOPAlgo_Builder");


    // nested enums

    static_cast<py::class_<BOPAlgo_Builder , shared_ptr<BOPAlgo_Builder>  , BOPAlgo_BuilderShape >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
        .def("Clear",
             (void (BOPAlgo_Builder::*)() ) static_cast<void (BOPAlgo_Builder::*)() >(&BOPAlgo_Builder::Clear),
             R"#(Clears the content of the algorithm.)#" 
          )
        .def("PPaveFiller",
             (BOPAlgo_PPaveFiller (BOPAlgo_Builder::*)() ) static_cast<BOPAlgo_PPaveFiller (BOPAlgo_Builder::*)() >(&BOPAlgo_Builder::PPaveFiller),
             R"#(Returns the PaveFiller, algorithm for sub-shapes intersection.)#" 
          )
        .def("AddArgument",
             (void (BOPAlgo_Builder::*)(  const TopoDS_Shape &  ) ) static_cast<void (BOPAlgo_Builder::*)(  const TopoDS_Shape &  ) >(&BOPAlgo_Builder::AddArgument),
             R"#(Adds the argument to the operation.)#"  , py::arg("theShape")
          )
        .def("SetArguments",
             (void (BOPAlgo_Builder::*)(  const NCollection_List<TopoDS_Shape> &  ) ) static_cast<void (BOPAlgo_Builder::*)(  const NCollection_List<TopoDS_Shape> &  ) >(&BOPAlgo_Builder::SetArguments),
             R"#(Sets the list of arguments for the operation.)#"  , py::arg("theLS")
          )
        .def("SetNonDestructive",
             (void (BOPAlgo_Builder::*)(  const bool  ) ) static_cast<void (BOPAlgo_Builder::*)(  const bool  ) >(&BOPAlgo_Builder::SetNonDestructive),
             R"#(Sets the flag that defines the mode of treatment. In non-destructive mode the argument shapes are not modified. Instead a copy of a sub-shape is created in the result if it is needed to be updated. This flag is taken into account if internal PaveFiller is used only. In the case of calling PerformWithFiller the corresponding flag of that PaveFiller is in force.)#"  , py::arg("theFlag")
          )
        .def("NonDestructive",
             (bool (BOPAlgo_Builder::*)() const) static_cast<bool (BOPAlgo_Builder::*)() const>(&BOPAlgo_Builder::NonDestructive),
             R"#(Returns the flag that defines the mode of treatment. In non-destructive mode the argument shapes are not modified. Instead a copy of a sub-shape is created in the result if it is needed to be updated.)#" 
          )
        .def("SetGlue",
             (void (BOPAlgo_Builder::*)(  const BOPAlgo_GlueEnum  ) ) static_cast<void (BOPAlgo_Builder::*)(  const BOPAlgo_GlueEnum  ) >(&BOPAlgo_Builder::SetGlue),
             R"#(Sets the glue option for the algorithm)#"  , py::arg("theGlue")
          )
        .def("Glue",
             (BOPAlgo_GlueEnum (BOPAlgo_Builder::*)() const) static_cast<BOPAlgo_GlueEnum (BOPAlgo_Builder::*)() const>(&BOPAlgo_Builder::Glue),
             R"#(Returns the glue option of the algorithm)#" 
          )
        .def("SetCheckInverted",
             (void (BOPAlgo_Builder::*)(  const bool  ) ) static_cast<void (BOPAlgo_Builder::*)(  const bool  ) >(&BOPAlgo_Builder::SetCheckInverted),
             R"#(Enables/Disables the check of the input solids for inverted status)#"  , py::arg("theCheck")
          )
        .def("CheckInverted",
             (bool (BOPAlgo_Builder::*)() const) static_cast<bool (BOPAlgo_Builder::*)() const>(&BOPAlgo_Builder::CheckInverted),
             R"#(Returns the flag defining whether the check for input solids on inverted status should be performed or not.)#" 
          )
        .def("Perform",
             (void (BOPAlgo_Builder::*)(  const Message_ProgressRange &  ) ) static_cast<void (BOPAlgo_Builder::*)(  const Message_ProgressRange &  ) >(&BOPAlgo_Builder::Perform),
             R"#(Performs the operation. The intersection will be performed also.)#"  , py::arg("theRange")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def("PerformWithFiller",
             (void (BOPAlgo_Builder::*)(  const BOPAlgo_PaveFiller & ,   const Message_ProgressRange &  ) ) static_cast<void (BOPAlgo_Builder::*)(  const BOPAlgo_PaveFiller & ,   const Message_ProgressRange &  ) >(&BOPAlgo_Builder::PerformWithFiller),
             R"#(Performs the operation with the prepared filler. The intersection will not be performed in this case.)#"  , py::arg("theFiller"),  py::arg("theRange")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def("BuildBOP",
             (void (BOPAlgo_Builder::*)(  const NCollection_List<TopoDS_Shape> & ,   const TopAbs_State ,   const NCollection_List<TopoDS_Shape> & ,   const TopAbs_State ,   const Message_ProgressRange & ,  handle<Message_Report>  ) ) static_cast<void (BOPAlgo_Builder::*)(  const NCollection_List<TopoDS_Shape> & ,   const TopAbs_State ,   const NCollection_List<TopoDS_Shape> & ,   const TopAbs_State ,   const Message_ProgressRange & ,  handle<Message_Report>  ) >(&BOPAlgo_Builder::BuildBOP),
             R"#(Builds the result shape according to the given states for the objects and tools. These states can be unambiguously converted into the Boolean operation type. Thus, it performs the Boolean operation on the given groups of shapes.)#"  , py::arg("theObjects"),  py::arg("theObjState"),  py::arg("theTools"),  py::arg("theToolsState"),  py::arg("theRange"),  py::arg("theReport")=static_cast<handle<Message_Report>>(nullptr)
          )
        .def("BuildBOP",
             (void (BOPAlgo_Builder::*)(  const NCollection_List<TopoDS_Shape> & ,   const NCollection_List<TopoDS_Shape> & ,   const BOPAlgo_Operation ,   const Message_ProgressRange & ,  handle<Message_Report>  ) ) static_cast<void (BOPAlgo_Builder::*)(  const NCollection_List<TopoDS_Shape> & ,   const NCollection_List<TopoDS_Shape> & ,   const BOPAlgo_Operation ,   const Message_ProgressRange & ,  handle<Message_Report>  ) >(&BOPAlgo_Builder::BuildBOP),
             R"#(Builds the result of Boolean operation of given type basing on the result of Builder operation (GF or any other).)#"  , py::arg("theObjects"),  py::arg("theTools"),  py::arg("theOperation"),  py::arg("theRange"),  py::arg("theReport")=static_cast<handle<Message_Report>>(nullptr)
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Arguments",
             ( const NCollection_List<TopoDS_Shape> & (BOPAlgo_Builder::*)() const) static_cast< const NCollection_List<TopoDS_Shape> & (BOPAlgo_Builder::*)() const>(&BOPAlgo_Builder::Arguments),
             R"#(Returns the list of arguments.)#"
             
         )
       .def("Images",
             ( const NCollection_DataMap<TopoDS_Shape, NCollection_List<TopoDS_Shape>, TopTools_ShapeMapHasher> & (BOPAlgo_Builder::*)() const) static_cast< const NCollection_DataMap<TopoDS_Shape, NCollection_List<TopoDS_Shape>, TopTools_ShapeMapHasher> & (BOPAlgo_Builder::*)() const>(&BOPAlgo_Builder::Images),
             R"#(Returns the map of images.)#"
             
         )
       .def("Origins",
             ( const NCollection_DataMap<TopoDS_Shape, NCollection_List<TopoDS_Shape>, TopTools_ShapeMapHasher> & (BOPAlgo_Builder::*)() const) static_cast< const NCollection_DataMap<TopoDS_Shape, NCollection_List<TopoDS_Shape>, TopTools_ShapeMapHasher> & (BOPAlgo_Builder::*)() const>(&BOPAlgo_Builder::Origins),
             R"#(Returns the map of origins.)#"
             
         )
       .def("ShapesSD",
             ( const NCollection_DataMap<TopoDS_Shape, TopoDS_Shape, TopTools_ShapeMapHasher> & (BOPAlgo_Builder::*)() const) static_cast< const NCollection_DataMap<TopoDS_Shape, TopoDS_Shape, TopTools_ShapeMapHasher> & (BOPAlgo_Builder::*)() const>(&BOPAlgo_Builder::ShapesSD),
             R"#(Returns the map of Same Domain (SD) shapes - coinciding shapes from different arguments.)#"
             
         )
;

    // Class BOPAlgo_BuilderFace from ./opencascade/BOPAlgo_BuilderFace.hxx
    klass = m.attr("BOPAlgo_BuilderFace");


    // nested enums

    static_cast<py::class_<BOPAlgo_BuilderFace , shared_ptr<BOPAlgo_BuilderFace>  , BOPAlgo_BuilderArea >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
        .def("SetFace",
             (void (BOPAlgo_BuilderFace::*)(  const TopoDS_Face &  ) ) static_cast<void (BOPAlgo_BuilderFace::*)(  const TopoDS_Face &  ) >(&BOPAlgo_BuilderFace::SetFace),
             R"#(Sets the face generatix)#"  , py::arg("theFace")
          )
        .def("Perform",
             (void (BOPAlgo_BuilderFace::*)(  const Message_ProgressRange &  ) ) static_cast<void (BOPAlgo_BuilderFace::*)(  const Message_ProgressRange &  ) >(&BOPAlgo_BuilderFace::Perform),
             R"#(Performs the algorithm)#"  , py::arg("theRange")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def("Orientation",
             (TopAbs_Orientation (BOPAlgo_BuilderFace::*)() const) static_cast<TopAbs_Orientation (BOPAlgo_BuilderFace::*)() const>(&BOPAlgo_BuilderFace::Orientation),
             R"#()#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Face",
             ( const TopoDS_Face & (BOPAlgo_BuilderFace::*)() const) static_cast< const TopoDS_Face & (BOPAlgo_BuilderFace::*)() const>(&BOPAlgo_BuilderFace::Face),
             R"#(Returns the face generatix)#"
             
         )
;

    // Class BOPAlgo_BuilderSolid from ./opencascade/BOPAlgo_BuilderSolid.hxx
    klass = m.attr("BOPAlgo_BuilderSolid");


    // nested enums

    static_cast<py::class_<BOPAlgo_BuilderSolid , shared_ptr<BOPAlgo_BuilderSolid>  , BOPAlgo_BuilderArea >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
        .def("Perform",
             (void (BOPAlgo_BuilderSolid::*)(  const Message_ProgressRange &  ) ) static_cast<void (BOPAlgo_BuilderSolid::*)(  const Message_ProgressRange &  ) >(&BOPAlgo_BuilderSolid::Perform),
             R"#(Performs the construction of the solids from the given faces)#"  , py::arg("theRange")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("GetBoxesMap",
             ( const NCollection_DataMap<TopoDS_Shape, Bnd_Box, TopTools_ShapeMapHasher> & (BOPAlgo_BuilderSolid::*)() const) static_cast< const NCollection_DataMap<TopoDS_Shape, Bnd_Box, TopTools_ShapeMapHasher> & (BOPAlgo_BuilderSolid::*)() const>(&BOPAlgo_BuilderSolid::GetBoxesMap),
             R"#(For classification purposes the algorithm builds the bounding boxes for all created solids. This method returns the data map of solid - box pairs.)#"
             
         )
;

    // Class BOPAlgo_CheckerSI from ./opencascade/BOPAlgo_CheckerSI.hxx
    klass = m.attr("BOPAlgo_CheckerSI");


    // nested enums

    static_cast<py::class_<BOPAlgo_CheckerSI , shared_ptr<BOPAlgo_CheckerSI>  , BOPAlgo_PaveFiller >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Perform",
             (void (BOPAlgo_CheckerSI::*)(  const Message_ProgressRange &  ) ) static_cast<void (BOPAlgo_CheckerSI::*)(  const Message_ProgressRange &  ) >(&BOPAlgo_CheckerSI::Perform),
             R"#()#"  , py::arg("theRange")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def("SetLevelOfCheck",
             (void (BOPAlgo_CheckerSI::*)(  const int  ) ) static_cast<void (BOPAlgo_CheckerSI::*)(  const int  ) >(&BOPAlgo_CheckerSI::SetLevelOfCheck),
             R"#(Sets the level of checking shape on self-interference. It defines which interferences will be checked: 0 - only V/V; 1 - V/V and V/E; 2 - V/V, V/E and E/E; 3 - V/V, V/E, E/E and V/F; 4 - V/V, V/E, E/E, V/F and E/F; 5 - V/V, V/E, E/E, V/F, E/F and F/F; 6 - V/V, V/E, E/E, V/F, E/F, F/F and V/S; 7 - V/V, V/E, E/E, V/F, E/F, F/F, V/S and E/S; 8 - V/V, V/E, E/E, V/F, E/F, F/F, V/S, E/S and F/S; 9 - V/V, V/E, E/E, V/F, E/F, F/F, V/S, E/S, F/S and S/S - all interferences (Default value))#"  , py::arg("theLevel")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BOPAlgo_RemoveFeatures from ./opencascade/BOPAlgo_RemoveFeatures.hxx
    klass = m.attr("BOPAlgo_RemoveFeatures");


    // nested enums

    static_cast<py::class_<BOPAlgo_RemoveFeatures , shared_ptr<BOPAlgo_RemoveFeatures>  , BOPAlgo_BuilderShape >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetShape",
             (void (BOPAlgo_RemoveFeatures::*)(  const TopoDS_Shape &  ) ) static_cast<void (BOPAlgo_RemoveFeatures::*)(  const TopoDS_Shape &  ) >(&BOPAlgo_RemoveFeatures::SetShape),
             R"#(Sets the shape for processing.)#"  , py::arg("theShape")
          )
        .def("AddFaceToRemove",
             (void (BOPAlgo_RemoveFeatures::*)(  const TopoDS_Shape &  ) ) static_cast<void (BOPAlgo_RemoveFeatures::*)(  const TopoDS_Shape &  ) >(&BOPAlgo_RemoveFeatures::AddFaceToRemove),
             R"#(Adds the face to remove from the input shape.)#"  , py::arg("theFace")
          )
        .def("AddFacesToRemove",
             (void (BOPAlgo_RemoveFeatures::*)(  const NCollection_List<TopoDS_Shape> &  ) ) static_cast<void (BOPAlgo_RemoveFeatures::*)(  const NCollection_List<TopoDS_Shape> &  ) >(&BOPAlgo_RemoveFeatures::AddFacesToRemove),
             R"#(Adds the faces to remove from the input shape.)#"  , py::arg("theFaces")
          )
        .def("Perform",
             (void (BOPAlgo_RemoveFeatures::*)(  const Message_ProgressRange &  ) ) static_cast<void (BOPAlgo_RemoveFeatures::*)(  const Message_ProgressRange &  ) >(&BOPAlgo_RemoveFeatures::Perform),
             R"#(Performs the operation)#"  , py::arg("theRange")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def("Clear",
             (void (BOPAlgo_RemoveFeatures::*)() ) static_cast<void (BOPAlgo_RemoveFeatures::*)() >(&BOPAlgo_RemoveFeatures::Clear),
             R"#(Clears the contents of the algorithm from previous run, allowing reusing it for following removals.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("InputShape",
             ( const TopoDS_Shape & (BOPAlgo_RemoveFeatures::*)() const) static_cast< const TopoDS_Shape & (BOPAlgo_RemoveFeatures::*)() const>(&BOPAlgo_RemoveFeatures::InputShape),
             R"#(Returns the input shape)#"
             
         )
       .def("FacesToRemove",
             ( const NCollection_List<TopoDS_Shape> & (BOPAlgo_RemoveFeatures::*)() const) static_cast< const NCollection_List<TopoDS_Shape> & (BOPAlgo_RemoveFeatures::*)() const>(&BOPAlgo_RemoveFeatures::FacesToRemove),
             R"#(Returns the list of faces which have been requested for removal from the input shape.)#"
             
         )
;

    // Class BOPAlgo_CellsBuilder from ./opencascade/BOPAlgo_CellsBuilder.hxx
    klass = m.attr("BOPAlgo_CellsBuilder");


    // nested enums

    static_cast<py::class_<BOPAlgo_CellsBuilder , shared_ptr<BOPAlgo_CellsBuilder>  , BOPAlgo_Builder >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
        .def("Clear",
             (void (BOPAlgo_CellsBuilder::*)() ) static_cast<void (BOPAlgo_CellsBuilder::*)() >(&BOPAlgo_CellsBuilder::Clear),
             R"#(Redefined method Clear - clears the contents.)#" 
          )
        .def("AddToResult",
             (void (BOPAlgo_CellsBuilder::*)(  const NCollection_List<TopoDS_Shape> & ,   const NCollection_List<TopoDS_Shape> & ,   const int ,   const bool  ) ) static_cast<void (BOPAlgo_CellsBuilder::*)(  const NCollection_List<TopoDS_Shape> & ,   const NCollection_List<TopoDS_Shape> & ,   const int ,   const bool  ) >(&BOPAlgo_CellsBuilder::AddToResult),
             R"#(Adding the parts to result. The parts are defined by two lists of shapes: <theLSToTake> defines the arguments which parts should be taken into result; <theLSToAvoid> defines the arguments which parts should not be taken into result; To be taken into result the part must be IN for all shapes from the list <theLSToTake> and must be OUT of all shapes from the list <theLSToAvoid>.)#"  , py::arg("theLSToTake"),  py::arg("theLSToAvoid"),  py::arg("theMaterial")=static_cast< const int>(0),  py::arg("theUpdate")=static_cast< const bool>(false)
          )
        .def("AddAllToResult",
             (void (BOPAlgo_CellsBuilder::*)(  const int ,   const bool  ) ) static_cast<void (BOPAlgo_CellsBuilder::*)(  const int ,   const bool  ) >(&BOPAlgo_CellsBuilder::AddAllToResult),
             R"#(Add all split parts to result. <theMaterial> defines the removal of internal boundaries; <theUpdate> parameter defines whether to remove boundaries now or not.)#"  , py::arg("theMaterial")=static_cast< const int>(0),  py::arg("theUpdate")=static_cast< const bool>(false)
          )
        .def("RemoveFromResult",
             (void (BOPAlgo_CellsBuilder::*)(  const NCollection_List<TopoDS_Shape> & ,   const NCollection_List<TopoDS_Shape> &  ) ) static_cast<void (BOPAlgo_CellsBuilder::*)(  const NCollection_List<TopoDS_Shape> & ,   const NCollection_List<TopoDS_Shape> &  ) >(&BOPAlgo_CellsBuilder::RemoveFromResult),
             R"#(Removing the parts from result. The parts are defined by two lists of shapes: <theLSToTake> defines the arguments which parts should be removed from result; <theLSToAvoid> defines the arguments which parts should not be removed from result. To be removed from the result the part must be IN for all shapes from the list <theLSToTake> and must be OUT of all shapes from the list <theLSToAvoid>.)#"  , py::arg("theLSToTake"),  py::arg("theLSToAvoid")
          )
        .def("RemoveAllFromResult",
             (void (BOPAlgo_CellsBuilder::*)() ) static_cast<void (BOPAlgo_CellsBuilder::*)() >(&BOPAlgo_CellsBuilder::RemoveAllFromResult),
             R"#(Remove all parts from result.)#" 
          )
        .def("RemoveInternalBoundaries",
             (void (BOPAlgo_CellsBuilder::*)() ) static_cast<void (BOPAlgo_CellsBuilder::*)() >(&BOPAlgo_CellsBuilder::RemoveInternalBoundaries),
             R"#(Removes internal boundaries between cells with the same material. If the result contains the cells with same material but of different dimension the removal of internal boundaries between these cells will not be performed. In case of some errors during the removal the method will set the appropriate warning status - use GetReport() to access them.)#" 
          )
        .def("MakeContainers",
             (void (BOPAlgo_CellsBuilder::*)() ) static_cast<void (BOPAlgo_CellsBuilder::*)() >(&BOPAlgo_CellsBuilder::MakeContainers),
             R"#(Makes the Containers of proper type from the parts added to result.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("GetAllParts",
             ( const TopoDS_Shape & (BOPAlgo_CellsBuilder::*)() const) static_cast< const TopoDS_Shape & (BOPAlgo_CellsBuilder::*)() const>(&BOPAlgo_CellsBuilder::GetAllParts),
             R"#(Get all split parts.)#"
             
         )
;

    // Class BOPAlgo_MakerVolume from ./opencascade/BOPAlgo_MakerVolume.hxx
    klass = m.attr("BOPAlgo_MakerVolume");


    // nested enums

    static_cast<py::class_<BOPAlgo_MakerVolume , shared_ptr<BOPAlgo_MakerVolume>  , BOPAlgo_Builder >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
        .def("Clear",
             (void (BOPAlgo_MakerVolume::*)() ) static_cast<void (BOPAlgo_MakerVolume::*)() >(&BOPAlgo_MakerVolume::Clear),
             R"#(Clears the data.)#" 
          )
        .def("SetIntersect",
             (void (BOPAlgo_MakerVolume::*)(  const bool  ) ) static_cast<void (BOPAlgo_MakerVolume::*)(  const bool  ) >(&BOPAlgo_MakerVolume::SetIntersect),
             R"#(Sets the flag myIntersect: if <bIntersect> is TRUE the shapes from <myArguments> will be intersected. if <bIntersect> is FALSE no intersection will be done.)#"  , py::arg("bIntersect")
          )
        .def("IsIntersect",
             (bool (BOPAlgo_MakerVolume::*)() const) static_cast<bool (BOPAlgo_MakerVolume::*)() const>(&BOPAlgo_MakerVolume::IsIntersect),
             R"#(Returns the flag <myIntersect>.)#" 
          )
        .def("SetAvoidInternalShapes",
             (void (BOPAlgo_MakerVolume::*)(  const bool  ) ) static_cast<void (BOPAlgo_MakerVolume::*)(  const bool  ) >(&BOPAlgo_MakerVolume::SetAvoidInternalShapes),
             R"#(Defines the preventing of addition of internal for solid parts into the result. By default the internal parts are added into result.)#"  , py::arg("theAvoidInternal")
          )
        .def("IsAvoidInternalShapes",
             (bool (BOPAlgo_MakerVolume::*)() const) static_cast<bool (BOPAlgo_MakerVolume::*)() const>(&BOPAlgo_MakerVolume::IsAvoidInternalShapes),
             R"#(Returns the AvoidInternalShapes flag)#" 
          )
        .def("Perform",
             (void (BOPAlgo_MakerVolume::*)(  const Message_ProgressRange &  ) ) static_cast<void (BOPAlgo_MakerVolume::*)(  const Message_ProgressRange &  ) >(&BOPAlgo_MakerVolume::Perform),
             R"#(Performs the operation.)#"  , py::arg("theRange")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
        .def("Clear",
             (void (BOPAlgo_MakerVolume::*)() ) static_cast<void (BOPAlgo_MakerVolume::*)() >(&BOPAlgo_MakerVolume::Clear),
             R"#(Clears the data.)#" 
          )
        .def("SetIntersect",
             (void (BOPAlgo_MakerVolume::*)(  const bool  ) ) static_cast<void (BOPAlgo_MakerVolume::*)(  const bool  ) >(&BOPAlgo_MakerVolume::SetIntersect),
             R"#(Sets the flag myIntersect: if <bIntersect> is TRUE the shapes from <myArguments> will be intersected. if <bIntersect> is FALSE no intersection will be done.)#"  , py::arg("bIntersect")
          )
        .def("IsIntersect",
             (bool (BOPAlgo_MakerVolume::*)() const) static_cast<bool (BOPAlgo_MakerVolume::*)() const>(&BOPAlgo_MakerVolume::IsIntersect),
             R"#(Returns the flag <myIntersect>.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Box",
             ( const TopoDS_Solid & (BOPAlgo_MakerVolume::*)() const) static_cast< const TopoDS_Solid & (BOPAlgo_MakerVolume::*)() const>(&BOPAlgo_MakerVolume::Box),
             R"#(Returns the solid box <mySBox>.)#"
             
         )
       .def("Faces",
             ( const NCollection_List<TopoDS_Shape> & (BOPAlgo_MakerVolume::*)() const) static_cast< const NCollection_List<TopoDS_Shape> & (BOPAlgo_MakerVolume::*)() const>(&BOPAlgo_MakerVolume::Faces),
             R"#(Returns the processed faces <myFaces>.)#"
             
         )
       .def("Box",
             ( const TopoDS_Solid & (BOPAlgo_MakerVolume::*)() const) static_cast< const TopoDS_Solid & (BOPAlgo_MakerVolume::*)() const>(&BOPAlgo_MakerVolume::Box),
             R"#(Returns the solid box <mySBox>.)#"
             
         )
       .def("Faces",
             ( const NCollection_List<TopoDS_Shape> & (BOPAlgo_MakerVolume::*)() const) static_cast< const NCollection_List<TopoDS_Shape> & (BOPAlgo_MakerVolume::*)() const>(&BOPAlgo_MakerVolume::Faces),
             R"#(Returns the processed faces <myFaces>.)#"
             
         )
;

    // Class BOPAlgo_Section from ./opencascade/BOPAlgo_Section.hxx
    klass = m.attr("BOPAlgo_Section");


    // nested enums

    static_cast<py::class_<BOPAlgo_Section , shared_ptr<BOPAlgo_Section>  , BOPAlgo_Builder >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BOPAlgo_ToolsProvider from ./opencascade/BOPAlgo_ToolsProvider.hxx
    klass = m.attr("BOPAlgo_ToolsProvider");


    // nested enums

    static_cast<py::class_<BOPAlgo_ToolsProvider , shared_ptr<BOPAlgo_ToolsProvider>  , BOPAlgo_Builder >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
        .def("Clear",
             (void (BOPAlgo_ToolsProvider::*)() ) static_cast<void (BOPAlgo_ToolsProvider::*)() >(&BOPAlgo_ToolsProvider::Clear),
             R"#(Clears internal fields and arguments)#" 
          )
        .def("AddTool",
             (void (BOPAlgo_ToolsProvider::*)(  const TopoDS_Shape &  ) ) static_cast<void (BOPAlgo_ToolsProvider::*)(  const TopoDS_Shape &  ) >(&BOPAlgo_ToolsProvider::AddTool),
             R"#(Adds Tool argument of the operation)#"  , py::arg("theShape")
          )
        .def("SetTools",
             (void (BOPAlgo_ToolsProvider::*)(  const NCollection_List<TopoDS_Shape> &  ) ) static_cast<void (BOPAlgo_ToolsProvider::*)(  const NCollection_List<TopoDS_Shape> &  ) >(&BOPAlgo_ToolsProvider::SetTools),
             R"#(Adds the Tool arguments of the operation)#"  , py::arg("theShapes")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Tools",
             ( const NCollection_List<TopoDS_Shape> & (BOPAlgo_ToolsProvider::*)() const) static_cast< const NCollection_List<TopoDS_Shape> & (BOPAlgo_ToolsProvider::*)() const>(&BOPAlgo_ToolsProvider::Tools),
             R"#(Returns the Tool arguments of the operation)#"
             
         )
;

    // Class BOPAlgo_BOP from ./opencascade/BOPAlgo_BOP.hxx
    klass = m.attr("BOPAlgo_BOP");


    // nested enums

    static_cast<py::class_<BOPAlgo_BOP , shared_ptr<BOPAlgo_BOP>  , BOPAlgo_ToolsProvider >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
        .def("Clear",
             (void (BOPAlgo_BOP::*)() ) static_cast<void (BOPAlgo_BOP::*)() >(&BOPAlgo_BOP::Clear),
             R"#(Clears internal fields and arguments)#" 
          )
        .def("SetOperation",
             (void (BOPAlgo_BOP::*)(  const BOPAlgo_Operation  ) ) static_cast<void (BOPAlgo_BOP::*)(  const BOPAlgo_Operation  ) >(&BOPAlgo_BOP::SetOperation),
             R"#()#"  , py::arg("theOperation")
          )
        .def("Operation",
             (BOPAlgo_Operation (BOPAlgo_BOP::*)() const) static_cast<BOPAlgo_Operation (BOPAlgo_BOP::*)() const>(&BOPAlgo_BOP::Operation),
             R"#()#" 
          )
        .def("Perform",
             (void (BOPAlgo_BOP::*)(  const Message_ProgressRange &  ) ) static_cast<void (BOPAlgo_BOP::*)(  const Message_ProgressRange &  ) >(&BOPAlgo_BOP::Perform),
             R"#()#"  , py::arg("theRange")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class BOPAlgo_Splitter from ./opencascade/BOPAlgo_Splitter.hxx
    klass = m.attr("BOPAlgo_Splitter");


    // nested enums

    static_cast<py::class_<BOPAlgo_Splitter , shared_ptr<BOPAlgo_Splitter>  , BOPAlgo_ToolsProvider >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >()  , py::arg("theAllocator") )
    // custom constructors
    // methods
        .def("Perform",
             (void (BOPAlgo_Splitter::*)(  const Message_ProgressRange &  ) ) static_cast<void (BOPAlgo_Splitter::*)(  const Message_ProgressRange &  ) >(&BOPAlgo_Splitter::Perform),
             R"#(Performs the operation)#"  , py::arg("theRange")=static_cast< const Message_ProgressRange &>(Message_ProgressRange ( ))
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

// functions

// ./opencascade/BOPAlgo_Alerts.hxx
// ./opencascade/BOPAlgo_Algo.hxx
// ./opencascade/BOPAlgo_ArgumentAnalyzer.hxx
// ./opencascade/BOPAlgo_BOP.hxx
// ./opencascade/BOPAlgo_Builder.hxx
// ./opencascade/BOPAlgo_BuilderArea.hxx
// ./opencascade/BOPAlgo_BuilderFace.hxx
// ./opencascade/BOPAlgo_BuilderShape.hxx
// ./opencascade/BOPAlgo_BuilderSolid.hxx
// ./opencascade/BOPAlgo_CellsBuilder.hxx
// ./opencascade/BOPAlgo_CheckResult.hxx
// ./opencascade/BOPAlgo_CheckStatus.hxx
// ./opencascade/BOPAlgo_CheckerSI.hxx
// ./opencascade/BOPAlgo_GlueEnum.hxx
// ./opencascade/BOPAlgo_MakeConnected.hxx
// ./opencascade/BOPAlgo_MakePeriodic.hxx
// ./opencascade/BOPAlgo_MakerVolume.hxx
// ./opencascade/BOPAlgo_Operation.hxx
// ./opencascade/BOPAlgo_Options.hxx
// ./opencascade/BOPAlgo_PArgumentAnalyzer.hxx
// ./opencascade/BOPAlgo_PBOP.hxx
// ./opencascade/BOPAlgo_PBuilder.hxx
// ./opencascade/BOPAlgo_PPaveFiller.hxx
// ./opencascade/BOPAlgo_PSection.hxx
// ./opencascade/BOPAlgo_PWireEdgeSet.hxx
// ./opencascade/BOPAlgo_PaveFiller.hxx
// ./opencascade/BOPAlgo_RemoveFeatures.hxx
// ./opencascade/BOPAlgo_Section.hxx
// ./opencascade/BOPAlgo_SectionAttribute.hxx
// ./opencascade/BOPAlgo_ShellSplitter.hxx
// ./opencascade/BOPAlgo_Splitter.hxx
// ./opencascade/BOPAlgo_Tools.hxx
// ./opencascade/BOPAlgo_ToolsProvider.hxx
// ./opencascade/BOPAlgo_WireEdgeSet.hxx
// ./opencascade/BOPAlgo_WireSplitter.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
