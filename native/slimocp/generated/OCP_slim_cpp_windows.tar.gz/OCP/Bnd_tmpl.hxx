#pragma once

#include <initializer_list>
using std::initializer_list;

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Pln.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Lin.hxx>
#include <gp_Pln.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <Bnd_B2.hxx>
#include <Bnd_B3.hxx>
#include <Bnd_BoundSortBox.hxx>
#include <Bnd_Box.hxx>
#include <Bnd_Box2d.hxx>
#include <Bnd_OBB.hxx>
#include <Bnd_Range.hxx>
#include <Bnd_Sphere.hxx>
#include <Bnd_Tools.hxx>

// user-defined pre
#include "OCP_specific.inc"

// Class template handling functions

template <typename RealType>
void preregister_template_Bnd_B3(py::object &m, const char *name){
    py::class_<Bnd_B3<RealType> , shared_ptr<Bnd_B3<RealType>> >(m,name,R"#(Template class for 3D bounding box. This is a base template that is instantiated for double and float.)#");
}

template <typename RealType>
void register_template_Bnd_B3(py::object &m, const char *name){
    static_cast<py::class_<Bnd_B3<RealType> , shared_ptr<Bnd_B3<RealType>> >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const gp_XYZ &, const gp_XYZ & >() ,py::arg("theCenter"), py::arg("theHSize") )
        .def(py::init<  const array<RealType, 3> &, const array<RealType, 3> & >() ,py::arg("theCenter"), py::arg("theHSize") )
        .def("IsVoid",
             (bool (Bnd_B3<RealType>::*)() const) &Bnd_B3<RealType>::IsVoid,
             R"#(Returns True if the box is void (non-initialized).)#" )
        .def("Clear",
             (void (Bnd_B3<RealType>::*)() ) &Bnd_B3<RealType>::Clear,
             R"#(Reset the box data.)#" )
        .def("Add",
             (void (Bnd_B3<RealType>::*)(  const gp_XYZ &  ) ) &Bnd_B3<RealType>::Add,
             R"#(Update the box by a point.)#" ,py::arg("thePnt"))
        .def("Add",
             (void (Bnd_B3<RealType>::*)(  const gp_Pnt &  ) ) &Bnd_B3<RealType>::Add,
             R"#(Update the box by a point.)#" ,py::arg("thePnt"))
        .def("Add",
             (void (Bnd_B3<RealType>::*)(  const Bnd_B3<RealType> &  ) ) &Bnd_B3<RealType>::Add,
             R"#(Update the box by another box.)#" ,py::arg("theBox"))
        .def("CornerMin",
             (gp_XYZ (Bnd_B3<RealType>::*)() const) &Bnd_B3<RealType>::CornerMin,
             R"#(Query the lower corner: (Center - HSize). You must make sure that the box is NOT VOID (see IsVoid()), otherwise the method returns irrelevant result.)#" )
        .def("CornerMax",
             (gp_XYZ (Bnd_B3<RealType>::*)() const) &Bnd_B3<RealType>::CornerMax,
             R"#(Query the upper corner: (Center + HSize). You must make sure that the box is NOT VOID (see IsVoid()), otherwise the method returns irrelevant result.)#" )
        .def("SquareExtent",
             (double (Bnd_B3<RealType>::*)() const) &Bnd_B3<RealType>::SquareExtent,
             R"#(Query the square diagonal. If the box is VOID (see method IsVoid()) then a very big real value is returned.)#" )
        .def("Enlarge",
             (void (Bnd_B3<RealType>::*)(  const double  ) ) &Bnd_B3<RealType>::Enlarge,
             R"#(Extend the Box by the absolute value of theDiff.)#" ,py::arg("theDiff"))
        .def("Limit",
             (bool (Bnd_B3<RealType>::*)(  const Bnd_B3<RealType> &  ) ) &Bnd_B3<RealType>::Limit,
             R"#(Limit the Box by the internals of theOtherBox. Returns True if the limitation takes place, otherwise False indicating that the boxes do not intersect.)#" ,py::arg("theOtherBox"))
        .def("Transformed",
             (Bnd_B3<RealType> (Bnd_B3<RealType>::*)(  const gp_Trsf &  ) const) &Bnd_B3<RealType>::Transformed,
             R"#(Transform the bounding box with the given transformation. The resulting box will be larger if theTrsf contains rotation.)#" ,py::arg("theTrsf"))
        .def("IsOut",
             (bool (Bnd_B3<RealType>::*)(  const gp_XYZ &  ) const) &Bnd_B3<RealType>::IsOut,
             R"#(Check the given point for the inclusion in the Box. Returns True if the point is outside.)#" ,py::arg("thePnt"))
        .def("IsOut",
             (bool (Bnd_B3<RealType>::*)(  const gp_XYZ & ,   const double ,   const bool  ) const) &Bnd_B3<RealType>::IsOut,
             R"#(Check a sphere for the intersection with the current box. Returns True if there is no intersection between boxes. If the parameter 'IsSphereHollow' is True, then the intersection is not reported for a box that is completely inside the sphere (otherwise this method would report an intersection).)#" ,py::arg("theCenter"), py::arg("theRadius"), py::arg("isSphereHollow")=static_cast< const bool>(false))
        .def("IsOut",
             (bool (Bnd_B3<RealType>::*)(  const Bnd_B3<RealType> &  ) const) &Bnd_B3<RealType>::IsOut,
             R"#(Check the given box for the intersection with the current box. Returns True if there is no intersection between boxes.)#" ,py::arg("theOtherBox"))
        .def("IsOut",
             (bool (Bnd_B3<RealType>::*)(  const Bnd_B3<RealType> & ,   const gp_Trsf &  ) const) &Bnd_B3<RealType>::IsOut,
             R"#(Check the given box oriented by the given transformation for the intersection with the current box. Returns True if there is no intersection between boxes.)#" ,py::arg("theOtherBox"), py::arg("theTrsf"))
        .def("IsOut",
             (bool (Bnd_B3<RealType>::*)(  const gp_Ax1 & ,   const bool ,   const double  ) const) &Bnd_B3<RealType>::IsOut,
             R"#(Check the given Line for the intersection with the current box. Returns True if there is no intersection. isRay==True means intersection check with the positive half-line theOverthickness is the addition to the size of the current box (may be negative). If positive, it can be treated as the thickness of the line 'theLine' or the radius of the cylinder along 'theLine')#" ,py::arg("theLine"), py::arg("isRay")=static_cast< const bool>(false), py::arg("theOverthickness")=static_cast< const double>(0.0))
        .def("IsOut",
             (bool (Bnd_B3<RealType>::*)(  const gp_Ax3 &  ) const) &Bnd_B3<RealType>::IsOut,
             R"#(Check the given Plane for the intersection with the current box. Returns True if there is no intersection.)#" ,py::arg("thePlane"))
        .def("IsIn",
             (bool (Bnd_B3<RealType>::*)(  const Bnd_B3<RealType> &  ) const) &Bnd_B3<RealType>::IsIn,
             R"#(Check that the box 'this' is inside the given box 'theBox'. Returns True if 'this' box is fully inside 'theBox'.)#" ,py::arg("theBox"))
        .def("IsIn",
             (bool (Bnd_B3<RealType>::*)(  const Bnd_B3<RealType> & ,   const gp_Trsf &  ) const) &Bnd_B3<RealType>::IsIn,
             R"#(Check that the box 'this' is inside the given box 'theBox' transformed by 'theTrsf'. Returns True if 'this' box is fully inside the transformed 'theBox'.)#" ,py::arg("theBox"), py::arg("theTrsf"))
        .def("SetCenter",
             (void (Bnd_B3<RealType>::*)(  const gp_XYZ &  ) ) &Bnd_B3<RealType>::SetCenter,
             R"#(Set the Center coordinates)#" ,py::arg("theCenter"))
        .def("SetCenter",
             (void (Bnd_B3<RealType>::*)(  const array<RealType, 3> &  ) ) &Bnd_B3<RealType>::SetCenter,
             R"#(Set the Center coordinates)#" ,py::arg("theCenter"))
        .def("SetHSize",
             (void (Bnd_B3<RealType>::*)(  const gp_XYZ &  ) ) &Bnd_B3<RealType>::SetHSize,
             R"#(Set the HSize (half-diagonal) coordinates. All components of theHSize must be non-negative.)#" ,py::arg("theHSize"))
        .def("SetHSize",
             (void (Bnd_B3<RealType>::*)(  const array<RealType, 3> &  ) ) &Bnd_B3<RealType>::SetHSize,
             R"#(Set the HSize (half-diagonal) coordinates. All components of theHSize must be non-negative.)#" ,py::arg("theHSize"))
        .def("Center",
             ( const array<RealType, 3> & (Bnd_B3<RealType>::*)() const) &Bnd_B3<RealType>::Center,
             R"#(Get the Center coordinates)#" )
        .def("HSize",
             ( const array<RealType, 3> & (Bnd_B3<RealType>::*)() const) &Bnd_B3<RealType>::HSize,
             R"#(Get the HSize (half-diagonal) coordinates)#" )
    ;
};

template <typename RealType>
void preregister_template_Bnd_B2(py::object &m, const char *name){
    py::class_<Bnd_B2<RealType> , shared_ptr<Bnd_B2<RealType>> >(m,name,R"#(Template class for 2D bounding box. This is a base template that is instantiated for double and float.)#");
}

template <typename RealType>
void register_template_Bnd_B2(py::object &m, const char *name){
    static_cast<py::class_<Bnd_B2<RealType> , shared_ptr<Bnd_B2<RealType>> >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const gp_XY &, const gp_XY & >() ,py::arg("theCenter"), py::arg("theHSize") )
        .def(py::init<  const array<RealType, 2> &, const array<RealType, 2> & >() ,py::arg("theCenter"), py::arg("theHSize") )
        .def("IsVoid",
             (bool (Bnd_B2<RealType>::*)() const) &Bnd_B2<RealType>::IsVoid,
             R"#(Returns True if the box is void (non-initialized).)#" )
        .def("Clear",
             (void (Bnd_B2<RealType>::*)() ) &Bnd_B2<RealType>::Clear,
             R"#(Reset the box data.)#" )
        .def("Add",
             (void (Bnd_B2<RealType>::*)(  const gp_XY &  ) ) &Bnd_B2<RealType>::Add,
             R"#(Update the box by a point.)#" ,py::arg("thePnt"))
        .def("Add",
             (void (Bnd_B2<RealType>::*)(  const gp_Pnt2d &  ) ) &Bnd_B2<RealType>::Add,
             R"#(Update the box by a point.)#" ,py::arg("thePnt"))
        .def("Add",
             (void (Bnd_B2<RealType>::*)(  const Bnd_B2<RealType> &  ) ) &Bnd_B2<RealType>::Add,
             R"#(Update the box by another box.)#" ,py::arg("theBox"))
        .def("CornerMin",
             (gp_XY (Bnd_B2<RealType>::*)() const) &Bnd_B2<RealType>::CornerMin,
             R"#(Query a box corner: (Center - HSize). You must make sure that the box is NOT VOID (see IsVoid()), otherwise the method returns irrelevant result.)#" )
        .def("CornerMax",
             (gp_XY (Bnd_B2<RealType>::*)() const) &Bnd_B2<RealType>::CornerMax,
             R"#(Query a box corner: (Center + HSize). You must make sure that the box is NOT VOID (see IsVoid()), otherwise the method returns irrelevant result.)#" )
        .def("SquareExtent",
             (double (Bnd_B2<RealType>::*)() const) &Bnd_B2<RealType>::SquareExtent,
             R"#(Query the square diagonal. If the box is VOID (see method IsVoid()) then a very big real value is returned.)#" )
        .def("Enlarge",
             (void (Bnd_B2<RealType>::*)(  const double  ) ) &Bnd_B2<RealType>::Enlarge,
             R"#(Extend the Box by the absolute value of theDiff.)#" ,py::arg("theDiff"))
        .def("Limit",
             (bool (Bnd_B2<RealType>::*)(  const Bnd_B2<RealType> &  ) ) &Bnd_B2<RealType>::Limit,
             R"#(Limit the Box by the internals of theOtherBox. Returns True if the limitation takes place, otherwise False indicating that the boxes do not intersect.)#" ,py::arg("theOtherBox"))
        .def("Transformed",
             (Bnd_B2<RealType> (Bnd_B2<RealType>::*)(  const gp_Trsf2d &  ) const) &Bnd_B2<RealType>::Transformed,
             R"#(Transform the bounding box with the given transformation. The resulting box will be larger if theTrsf contains rotation.)#" ,py::arg("theTrsf"))
        .def("IsOut",
             (bool (Bnd_B2<RealType>::*)(  const gp_XY &  ) const) &Bnd_B2<RealType>::IsOut,
             R"#(Check the given point for the inclusion in the Box. Returns True if the point is outside.)#" ,py::arg("thePnt"))
        .def("IsOut",
             (bool (Bnd_B2<RealType>::*)(  const gp_XY & ,   const double ,   const bool  ) const) &Bnd_B2<RealType>::IsOut,
             R"#(Check a circle for the intersection with the current box. Returns True if there is no intersection between boxes.)#" ,py::arg("theCenter"), py::arg("theRadius"), py::arg("isCircleHollow")=static_cast< const bool>(false))
        .def("IsOut",
             (bool (Bnd_B2<RealType>::*)(  const Bnd_B2<RealType> &  ) const) &Bnd_B2<RealType>::IsOut,
             R"#(Check the given box for the intersection with the current box. Returns True if there is no intersection between boxes.)#" ,py::arg("theOtherBox"))
        .def("IsOut",
             (bool (Bnd_B2<RealType>::*)(  const Bnd_B2<RealType> & ,   const gp_Trsf2d &  ) const) &Bnd_B2<RealType>::IsOut,
             R"#(Check the given box oriented by the given transformation for the intersection with the current box. Returns True if there is no intersection between boxes.)#" ,py::arg("theOtherBox"), py::arg("theTrsf"))
        .def("IsOut",
             (bool (Bnd_B2<RealType>::*)(  const gp_Ax2d &  ) const) &Bnd_B2<RealType>::IsOut,
             R"#(Check the given Line for the intersection with the current box. Returns True if there is no intersection.)#" ,py::arg("theLine"))
        .def("IsOut",
             (bool (Bnd_B2<RealType>::*)(  const gp_XY & ,   const gp_XY &  ) const) &Bnd_B2<RealType>::IsOut,
             R"#(Check the Segment defined by the couple of input points for the intersection with the current box. Returns True if there is no intersection.)#" ,py::arg("theP0"), py::arg("theP1"))
        .def("IsIn",
             (bool (Bnd_B2<RealType>::*)(  const Bnd_B2<RealType> &  ) const) &Bnd_B2<RealType>::IsIn,
             R"#(Check that the box 'this' is inside the given box 'theBox'. Returns True if 'this' box is fully inside 'theBox'.)#" ,py::arg("theBox"))
        .def("IsIn",
             (bool (Bnd_B2<RealType>::*)(  const Bnd_B2<RealType> & ,   const gp_Trsf2d &  ) const) &Bnd_B2<RealType>::IsIn,
             R"#(Check that the box 'this' is inside the given box 'theBox' transformed by 'theTrsf'. Returns True if 'this' box is fully inside the transformed 'theBox'.)#" ,py::arg("theBox"), py::arg("theTrsf"))
        .def("SetCenter",
             (void (Bnd_B2<RealType>::*)(  const gp_XY &  ) ) &Bnd_B2<RealType>::SetCenter,
             R"#(Set the Center coordinates)#" ,py::arg("theCenter"))
        .def("SetCenter",
             (void (Bnd_B2<RealType>::*)(  const array<RealType, 2> &  ) ) &Bnd_B2<RealType>::SetCenter,
             R"#(Set the Center coordinates)#" ,py::arg("theCenter"))
        .def("SetHSize",
             (void (Bnd_B2<RealType>::*)(  const gp_XY &  ) ) &Bnd_B2<RealType>::SetHSize,
             R"#(Set the HSize (half-diagonal) coordinates. All components of theHSize must be non-negative.)#" ,py::arg("theHSize"))
        .def("SetHSize",
             (void (Bnd_B2<RealType>::*)(  const array<RealType, 2> &  ) ) &Bnd_B2<RealType>::SetHSize,
             R"#(Set the HSize (half-diagonal) coordinates. All components of theHSize must be non-negative.)#" ,py::arg("theHSize"))
        .def("Center",
             ( const array<RealType, 2> & (Bnd_B2<RealType>::*)() const) &Bnd_B2<RealType>::Center,
             R"#(Get the Center coordinates)#" )
        .def("HSize",
             ( const array<RealType, 2> & (Bnd_B2<RealType>::*)() const) &Bnd_B2<RealType>::HSize,
             R"#(Get the HSize (half-diagonal) coordinates)#" )
    ;
};


// user-defined post

