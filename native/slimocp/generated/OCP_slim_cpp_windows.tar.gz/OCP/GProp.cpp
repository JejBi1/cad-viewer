
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Pnt.hxx>
#include <gp_Mat.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Circ.hxx>
#include <gp_Lin.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Ax1.hxx>
#include <GProp_PrincipalProps.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Pln.hxx>
#include <gp_Lin.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Cylinder.hxx>
#include <gp_Cone.hxx>
#include <gp_Sphere.hxx>
#include <gp_Torus.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Cylinder.hxx>
#include <gp_Cone.hxx>
#include <gp_Sphere.hxx>
#include <gp_Torus.hxx>

// module includes
#include <GProp.hxx>
#include <GProp_CelGProps.hxx>
#include <GProp_GProps.hxx>
#include <GProp_PEquation.hxx>
#include <GProp_PGProps.hxx>
#include <GProp_PrincipalProps.hxx>
#include <GProp_SelGProps.hxx>
#include <GProp_UndefinedAxis.hxx>
#include <GProp_ValueType.hxx>
#include <GProp_VelGProps.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_GProp(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("GProp"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes

// classes

    // Class GProp from ./opencascade/GProp.hxx
    klass = m.attr("GProp");

    // default constructor
    register_default_constructor<GProp , shared_ptr<GProp>>(m,"GProp");

    // nested enums

    static_cast<py::class_<GProp , shared_ptr<GProp>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("HOperator_s",
                    (void (*)(  const gp_Pnt & ,   const gp_Pnt & ,   const double ,  gp_Mat &  ) ) static_cast<void (*)(  const gp_Pnt & ,   const gp_Pnt & ,   const double ,  gp_Mat &  ) >(&GProp::HOperator),
                    R"#(methods of package Computes the matrix Operator, referred to as the "Huyghens Operator" of a geometric system at the point Q of the space, using the following data: - Mass, i.e. the mass of the system, - G, the center of mass of the system. The "Huyghens Operator" is used to compute Inertia/Q, the matrix of inertia of the system at the point Q using Huyghens' theorem: Inertia/Q = Inertia/G + HOperator (Q, G, Mass) where Inertia/G is the matrix of inertia of the system relative to its center of mass as returned by the function MatrixOfInertia on any GProp_GProps object.)#"  , py::arg("G"),  py::arg("Q"),  py::arg("Mass"),  py::arg("Operator")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class GProp_GProps from ./opencascade/GProp_GProps.hxx
    klass = m.attr("GProp_GProps");


    // nested enums

    static_cast<py::class_<GProp_GProps , shared_ptr<GProp_GProps>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const gp_Pnt & >()  , py::arg("SystemLocation") )
    // custom constructors
    // methods
        .def("Add",
             (void (GProp_GProps::*)(  const GProp_GProps & ,   const double  ) ) static_cast<void (GProp_GProps::*)(  const GProp_GProps & ,   const double  ) >(&GProp_GProps::Add),
             R"#(Either: - initializes the global properties retained by this framework from those retained by the framework Item, or - brings together the global properties retained by this framework with those retained by the framework Item.)#"  , py::arg("Item"),  py::arg("Density")=static_cast< const double>(1.0)
          )
        .def("Mass",
             (double (GProp_GProps::*)() const) static_cast<double (GProp_GProps::*)() const>(&GProp_GProps::Mass),
             R"#(Returns the mass of the current system.)#" 
          )
        .def("CentreOfMass",
             (gp_Pnt (GProp_GProps::*)() const) static_cast<gp_Pnt (GProp_GProps::*)() const>(&GProp_GProps::CentreOfMass),
             R"#(Returns the centre of mass of the current system. With a uniform gravitational field this is also the centre of gravity. The coordinates returned for the centre of mass are expressed in the absolute Cartesian coordinate system.)#" 
          )
        .def("MatrixOfInertia",
             (gp_Mat (GProp_GProps::*)() const) static_cast<gp_Mat (GProp_GProps::*)() const>(&GProp_GProps::MatrixOfInertia),
             R"#(Returns the matrix of inertia. It is a symmetric matrix whose coefficients are the quadratic moments of inertia: Ixx, Iyy, Izz are the moments of inertia; Ixy, Ixz, Iyz are the products of inertia.)#" 
          )
        .def("MomentOfInertia",
             (double (GProp_GProps::*)(  const gp_Ax1 &  ) const) static_cast<double (GProp_GProps::*)(  const gp_Ax1 &  ) const>(&GProp_GProps::MomentOfInertia),
             R"#(Computes the moment of inertia of the system about the axis A.)#"  , py::arg("A")
          )
        .def("PrincipalProperties",
             (GProp_PrincipalProps (GProp_GProps::*)() const) static_cast<GProp_PrincipalProps (GProp_GProps::*)() const>(&GProp_GProps::PrincipalProperties),
             R"#(Computes the principal properties of inertia of the current system. There is always a set of axes for which the products of inertia of a geometric system are equal to 0 - i.e. the matrix of inertia of the system is diagonal. These axes are the principal axes of inertia; their origin coincides with the centre of mass of the system. The associated moments are called the principal moments of inertia.)#" 
          )
        .def("RadiusOfGyration",
             (double (GProp_GProps::*)(  const gp_Ax1 &  ) const) static_cast<double (GProp_GProps::*)(  const gp_Ax1 &  ) const>(&GProp_GProps::RadiusOfGyration),
             R"#(Returns the radius of gyration of the current system about the axis A.)#"  , py::arg("A")
          )
    // methods using call by reference i.s.o. return
        .def("StaticMoments",
             []( GProp_GProps &self   ){
                 double  Ix;
                double  Iy;
                double  Iz;

                 self.StaticMoments(Ix,Iy,Iz);
                 return std::make_tuple(Ix,Iy,Iz); },
             R"#(Returns the static moments of inertia of the current system - i.e. the moments of inertia about the three axes of the absolute Cartesian coordinate system.)#" 
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class GProp_PEquation from ./opencascade/GProp_PEquation.hxx
    klass = m.attr("GProp_PEquation");


    // nested enums
        py::enum_<GProp_PEquation::Type>(klass, "Type_e", R"#(Type of geometric entity that best fits the cloud.)#")
            .value("None_", GProp_PEquation::Type::None)
            .value("Point", GProp_PEquation::Type::Point)
            .value("Line", GProp_PEquation::Type::Line)
            .value("Plane", GProp_PEquation::Type::Plane)
            .value("Space", GProp_PEquation::Type::Space);

    static_cast<py::class_<GProp_PEquation , shared_ptr<GProp_PEquation>  >>(klass)
    // constructors
        .def(py::init<  const NCollection_Array1<gp_Pnt> &,double >()  , py::arg("thePnts"),  py::arg("theTol") )
    // custom constructors
    // methods
        .def("GetType",
             (GProp_PEquation::Type (GProp_PEquation::*)() const) static_cast<GProp_PEquation::Type (GProp_PEquation::*)() const>(&GProp_PEquation::GetType),
             R"#(Returns the type of the fitted entity.)#" 
          )
        .def("IsPlanar",
             (bool (GProp_PEquation::*)() const) static_cast<bool (GProp_PEquation::*)() const>(&GProp_PEquation::IsPlanar),
             R"#(Returns true if points are coplanar within tolerance.)#" 
          )
        .def("IsLinear",
             (bool (GProp_PEquation::*)() const) static_cast<bool (GProp_PEquation::*)() const>(&GProp_PEquation::IsLinear),
             R"#(Returns true if points are collinear within tolerance.)#" 
          )
        .def("IsPoint",
             (bool (GProp_PEquation::*)() const) static_cast<bool (GProp_PEquation::*)() const>(&GProp_PEquation::IsPoint),
             R"#(Returns true if points are coincident within tolerance.)#" 
          )
        .def("IsSpace",
             (bool (GProp_PEquation::*)() const) static_cast<bool (GProp_PEquation::*)() const>(&GProp_PEquation::IsSpace),
             R"#(Returns true if points span 3D space.)#" 
          )
        .def("Plane",
             (gp_Pln (GProp_PEquation::*)() const) static_cast<gp_Pln (GProp_PEquation::*)() const>(&GProp_PEquation::Plane),
             R"#(Returns the mean plane.)#" 
          )
        .def("Line",
             (gp_Lin (GProp_PEquation::*)() const) static_cast<gp_Lin (GProp_PEquation::*)() const>(&GProp_PEquation::Line),
             R"#(Returns the mean line.)#" 
          )
        .def("Point",
             (gp_Pnt (GProp_PEquation::*)() const) static_cast<gp_Pnt (GProp_PEquation::*)() const>(&GProp_PEquation::Point),
             R"#(Returns the mean point.)#" 
          )
        .def("Box",
             (void (GProp_PEquation::*)( gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) const) static_cast<void (GProp_PEquation::*)( gp_Pnt & ,  gp_Vec & ,  gp_Vec & ,  gp_Vec &  ) const>(&GProp_PEquation::Box),
             R"#(Returns a bounding box aligned with the principal axes.)#"  , py::arg("theP"),  py::arg("theV1"),  py::arg("theV2"),  py::arg("theV3")
          )
        .def("PrincipalAxis",
             ( const gp_Vec & (GProp_PEquation::*)( int  ) const) static_cast< const gp_Vec & (GProp_PEquation::*)( int  ) const>(&GProp_PEquation::PrincipalAxis),
             R"#(Returns the unit principal axis at theIndex (1, 2 or 3), ordered by eigenvalue.)#"  , py::arg("theIndex")
          )
        .def("Extent",
             (double (GProp_PEquation::*)( int  ) const) static_cast<double (GProp_PEquation::*)( int  ) const>(&GProp_PEquation::Extent),
             R"#(Returns the extent (max - min projection) along principal axis theIndex (1, 2 or 3).)#"  , py::arg("theIndex")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Barycentre",
             ( const gp_Pnt & (GProp_PEquation::*)() const) static_cast< const gp_Pnt & (GProp_PEquation::*)() const>(&GProp_PEquation::Barycentre),
             R"#(Returns the centre of mass of the cloud (always valid after construction).)#"
             
         )
;

    // Class GProp_PrincipalProps from ./opencascade/GProp_PrincipalProps.hxx
    klass = m.attr("GProp_PrincipalProps");


    // nested enums

    static_cast<py::class_<GProp_PrincipalProps , shared_ptr<GProp_PrincipalProps>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("HasSymmetryAxis",
             (bool (GProp_PrincipalProps::*)() const) static_cast<bool (GProp_PrincipalProps::*)() const>(&GProp_PrincipalProps::HasSymmetryAxis),
             R"#(returns true if the geometric system has an axis of symmetry. For comparing moments relative tolerance 1.e-10 is used. Usually it is enough for objects, restricted by faces with analytical geometry.)#" 
          )
        .def("HasSymmetryAxis",
             (bool (GProp_PrincipalProps::*)(  const double  ) const) static_cast<bool (GProp_PrincipalProps::*)(  const double  ) const>(&GProp_PrincipalProps::HasSymmetryAxis),
             R"#(returns true if the geometric system has an axis of symmetry. aTol is relative tolerance for checking equality of moments If aTol == 0, relative tolerance is ~ 1.e-16 (Epsilon(I)))#"  , py::arg("aTol")
          )
        .def("HasSymmetryPoint",
             (bool (GProp_PrincipalProps::*)() const) static_cast<bool (GProp_PrincipalProps::*)() const>(&GProp_PrincipalProps::HasSymmetryPoint),
             R"#(returns true if the geometric system has a point of symmetry. For comparing moments relative tolerance 1.e-10 is used. Usually it is enough for objects, restricted by faces with analytical geometry.)#" 
          )
        .def("HasSymmetryPoint",
             (bool (GProp_PrincipalProps::*)(  const double  ) const) static_cast<bool (GProp_PrincipalProps::*)(  const double  ) const>(&GProp_PrincipalProps::HasSymmetryPoint),
             R"#(returns true if the geometric system has a point of symmetry. aTol is relative tolerance for checking equality of moments If aTol == 0, relative tolerance is ~ 1.e-16 (Epsilon(I)))#"  , py::arg("aTol")
          )
    // methods using call by reference i.s.o. return
        .def("Moments",
             []( GProp_PrincipalProps &self   ){
                 double  Ixx;
                double  Iyy;
                double  Izz;

                 self.Moments(Ixx,Iyy,Izz);
                 return std::make_tuple(Ixx,Iyy,Izz); },
             R"#(Ixx, Iyy and Izz return the principal moments of inertia in the current system. Notes : - If the current system has an axis of symmetry, two of the three values Ixx, Iyy and Izz are equal. They indicate which eigen vectors define an infinity of axes of principal inertia. - If the current system has a center of symmetry, Ixx, Iyy and Izz are equal.)#" 
          )
        .def("RadiusOfGyration",
             []( GProp_PrincipalProps &self   ){
                 double  Rxx;
                double  Ryy;
                double  Rzz;

                 self.RadiusOfGyration(Rxx,Ryy,Rzz);
                 return std::make_tuple(Rxx,Ryy,Rzz); },
             R"#(Returns the principal radii of gyration Rxx, Ryy and Rzz are the radii of gyration of the current system about its three principal axes of inertia. Note that: - If the current system has an axis of symmetry, two of the three values Rxx, Ryy and Rzz are equal. - If the current system has a center of symmetry, Rxx, Ryy and Rzz are equal.)#" 
          )
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("FirstAxisOfInertia",
             ( const gp_Vec & (GProp_PrincipalProps::*)() const) static_cast< const gp_Vec & (GProp_PrincipalProps::*)() const>(&GProp_PrincipalProps::FirstAxisOfInertia),
             R"#(returns the first axis of inertia.)#"
             
         )
       .def("SecondAxisOfInertia",
             ( const gp_Vec & (GProp_PrincipalProps::*)() const) static_cast< const gp_Vec & (GProp_PrincipalProps::*)() const>(&GProp_PrincipalProps::SecondAxisOfInertia),
             R"#(returns the second axis of inertia.)#"
             
         )
       .def("ThirdAxisOfInertia",
             ( const gp_Vec & (GProp_PrincipalProps::*)() const) static_cast< const gp_Vec & (GProp_PrincipalProps::*)() const>(&GProp_PrincipalProps::ThirdAxisOfInertia),
             R"#(returns the third axis of inertia. This and the above functions return the first, second or third eigen vector of the matrix of inertia of the current system. The first, second and third principal axis of inertia pass through the center of mass of the current system. They are respectively parallel to these three eigen vectors. Note that: - If the current system has an axis of symmetry, any axis is an axis of principal inertia if it passes through the center of mass of the system, and runs parallel to a linear combination of the two eigen vectors of the matrix of inertia, corresponding to the two eigen values which are equal. If the current system has a center of symmetry, any axis passing through the center of mass of the system is an axis of principal inertia. Use the functions HasSymmetryAxis and HasSymmetryPoint to check these particular cases, where the returned eigen vectors define an infinity of principal axis of inertia. - The Moments function can be used to know which of the three eigen vectors corresponds to the two eigen values which are equal.)#"
             
         )
;

    // Class GProp_CelGProps from ./opencascade/GProp_CelGProps.hxx
    klass = m.attr("GProp_CelGProps");


    // nested enums

    static_cast<py::class_<GProp_CelGProps , shared_ptr<GProp_CelGProps>  , GProp_GProps >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const gp_Circ &, const double, const double, const gp_Pnt & >()  , py::arg("C"),  py::arg("U1"),  py::arg("U2"),  py::arg("CLocation") )
        .def(py::init<  const gp_Circ &, const gp_Pnt & >()  , py::arg("C"),  py::arg("CLocation") )
        .def(py::init<  const gp_Lin &, const double, const double, const gp_Pnt & >()  , py::arg("C"),  py::arg("U1"),  py::arg("U2"),  py::arg("CLocation") )
    // custom constructors
    // methods
        .def("SetLocation",
             (void (GProp_CelGProps::*)(  const gp_Pnt &  ) ) static_cast<void (GProp_CelGProps::*)(  const gp_Pnt &  ) >(&GProp_CelGProps::SetLocation),
             R"#()#"  , py::arg("CLocation")
          )
        .def("Perform",
             (void (GProp_CelGProps::*)(  const gp_Circ & ,   const double ,   const double  ) ) static_cast<void (GProp_CelGProps::*)(  const gp_Circ & ,   const double ,   const double  ) >(&GProp_CelGProps::Perform),
             R"#()#"  , py::arg("C"),  py::arg("U1"),  py::arg("U2")
          )
        .def("Perform",
             (void (GProp_CelGProps::*)(  const gp_Lin & ,   const double ,   const double  ) ) static_cast<void (GProp_CelGProps::*)(  const gp_Lin & ,   const double ,   const double  ) >(&GProp_CelGProps::Perform),
             R"#()#"  , py::arg("C"),  py::arg("U1"),  py::arg("U2")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class GProp_PGProps from ./opencascade/GProp_PGProps.hxx
    klass = m.attr("GProp_PGProps");


    // nested enums

    static_cast<py::class_<GProp_PGProps , shared_ptr<GProp_PGProps>  , GProp_GProps >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const NCollection_Array1<gp_Pnt> & >()  , py::arg("thePnts") )
        .def(py::init<  const NCollection_Array1<gp_Pnt> &, const NCollection_Array1<double> & >()  , py::arg("thePnts"),  py::arg("theDensity") )
        .def(py::init<  const NCollection_Array2<gp_Pnt> & >()  , py::arg("thePnts") )
        .def(py::init<  const NCollection_Array2<gp_Pnt> &, const NCollection_Array2<double> & >()  , py::arg("thePnts"),  py::arg("theDensity") )
    // custom constructors
    // methods
        .def("AddPoint",
             (void (GProp_PGProps::*)(  const gp_Pnt &  ) ) static_cast<void (GProp_PGProps::*)(  const gp_Pnt &  ) >(&GProp_PGProps::AddPoint),
             R"#(Adds a point with unit mass.)#"  , py::arg("thePnt")
          )
        .def("AddPoint",
             (void (GProp_PGProps::*)(  const gp_Pnt & ,  double  ) ) static_cast<void (GProp_PGProps::*)(  const gp_Pnt & ,  double  ) >(&GProp_PGProps::AddPoint),
             R"#(Adds a point with a given mass.)#"  , py::arg("thePnt"),  py::arg("theDensity")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Barycentre_s",
                    (gp_Pnt (*)(  const NCollection_Array1<gp_Pnt> &  ) ) static_cast<gp_Pnt (*)(  const NCollection_Array1<gp_Pnt> &  ) >(&GProp_PGProps::Barycentre),
                    R"#(Computes the barycentre of a set of points (unit mass).)#"  , py::arg("thePnts")
          )
        .def_static("Barycentre_s",
                    (gp_Pnt (*)(  const NCollection_Array2<gp_Pnt> &  ) ) static_cast<gp_Pnt (*)(  const NCollection_Array2<gp_Pnt> &  ) >(&GProp_PGProps::Barycentre),
                    R"#(Computes the barycentre of a 2D array of points (unit mass).)#"  , py::arg("thePnts")
          )
    // static methods using call by reference i.s.o. return
        .def_static("Barycentre_s",
            []( const NCollection_Array1<gp_Pnt> & thePnts, const NCollection_Array1<double> & theDensity,gp_Pnt & theG ){
                double  theMass;

                GProp_PGProps::Barycentre(thePnts,theDensity,theMass,theG);
                
return std::make_tuple(theMass); },
            R"#(Computes the weighted barycentre and total mass of a set of points.)#"  , py::arg("thePnts"),  py::arg("theDensity"),  py::arg("theG")
          )
        .def_static("Barycentre_s",
            []( const NCollection_Array2<gp_Pnt> & thePnts, const NCollection_Array2<double> & theDensity,gp_Pnt & theG ){
                double  theMass;

                GProp_PGProps::Barycentre(thePnts,theDensity,theMass,theG);
                
return std::make_tuple(theMass); },
            R"#(Computes the weighted barycentre and total mass for a 2D point array.)#"  , py::arg("thePnts"),  py::arg("theDensity"),  py::arg("theG")
          )
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class GProp_SelGProps from ./opencascade/GProp_SelGProps.hxx
    klass = m.attr("GProp_SelGProps");


    // nested enums

    static_cast<py::class_<GProp_SelGProps , shared_ptr<GProp_SelGProps>  , GProp_GProps >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const gp_Cone &, const double, const double, const double, const double, const gp_Pnt & >()  , py::arg("S"),  py::arg("Alpha1"),  py::arg("Alpha2"),  py::arg("Z1"),  py::arg("Z2"),  py::arg("SLocation") )
        .def(py::init<  const gp_Cylinder &, const double, const double, const double, const double, const gp_Pnt & >()  , py::arg("S"),  py::arg("Alpha1"),  py::arg("Alpha2"),  py::arg("Z1"),  py::arg("Z2"),  py::arg("SLocation") )
        .def(py::init<  const gp_Sphere &, const double, const double, const double, const double, const gp_Pnt & >()  , py::arg("S"),  py::arg("Teta1"),  py::arg("Teta2"),  py::arg("Alpha1"),  py::arg("Alpha2"),  py::arg("SLocation") )
        .def(py::init<  const gp_Torus &, const double, const double, const double, const double, const gp_Pnt & >()  , py::arg("S"),  py::arg("Teta1"),  py::arg("Teta2"),  py::arg("Alpha1"),  py::arg("Alpha2"),  py::arg("SLocation") )
    // custom constructors
    // methods
        .def("SetLocation",
             (void (GProp_SelGProps::*)(  const gp_Pnt &  ) ) static_cast<void (GProp_SelGProps::*)(  const gp_Pnt &  ) >(&GProp_SelGProps::SetLocation),
             R"#()#"  , py::arg("SLocation")
          )
        .def("Perform",
             (void (GProp_SelGProps::*)(  const gp_Cylinder & ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<void (GProp_SelGProps::*)(  const gp_Cylinder & ,   const double ,   const double ,   const double ,   const double  ) >(&GProp_SelGProps::Perform),
             R"#()#"  , py::arg("S"),  py::arg("Alpha1"),  py::arg("Alpha2"),  py::arg("Z1"),  py::arg("Z2")
          )
        .def("Perform",
             (void (GProp_SelGProps::*)(  const gp_Cone & ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<void (GProp_SelGProps::*)(  const gp_Cone & ,   const double ,   const double ,   const double ,   const double  ) >(&GProp_SelGProps::Perform),
             R"#()#"  , py::arg("S"),  py::arg("Alpha1"),  py::arg("Alpha2"),  py::arg("Z1"),  py::arg("Z2")
          )
        .def("Perform",
             (void (GProp_SelGProps::*)(  const gp_Sphere & ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<void (GProp_SelGProps::*)(  const gp_Sphere & ,   const double ,   const double ,   const double ,   const double  ) >(&GProp_SelGProps::Perform),
             R"#()#"  , py::arg("S"),  py::arg("Teta1"),  py::arg("Teta2"),  py::arg("Alpha1"),  py::arg("Alpha2")
          )
        .def("Perform",
             (void (GProp_SelGProps::*)(  const gp_Torus & ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<void (GProp_SelGProps::*)(  const gp_Torus & ,   const double ,   const double ,   const double ,   const double  ) >(&GProp_SelGProps::Perform),
             R"#()#"  , py::arg("S"),  py::arg("Teta1"),  py::arg("Teta2"),  py::arg("Alpha1"),  py::arg("Alpha2")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class GProp_VelGProps from ./opencascade/GProp_VelGProps.hxx
    klass = m.attr("GProp_VelGProps");


    // nested enums

    static_cast<py::class_<GProp_VelGProps , shared_ptr<GProp_VelGProps>  , GProp_GProps >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const gp_Cone &, const double, const double, const double, const double, const gp_Pnt & >()  , py::arg("S"),  py::arg("Alpha1"),  py::arg("Alpha2"),  py::arg("Z1"),  py::arg("Z2"),  py::arg("VLocation") )
        .def(py::init<  const gp_Cylinder &, const double, const double, const double, const double, const gp_Pnt & >()  , py::arg("S"),  py::arg("Alpha1"),  py::arg("Alpha2"),  py::arg("Z1"),  py::arg("Z2"),  py::arg("VLocation") )
        .def(py::init<  const gp_Sphere &, const double, const double, const double, const double, const gp_Pnt & >()  , py::arg("S"),  py::arg("Teta1"),  py::arg("Teta2"),  py::arg("Alpha1"),  py::arg("Alpha2"),  py::arg("VLocation") )
        .def(py::init<  const gp_Torus &, const double, const double, const double, const double, const gp_Pnt & >()  , py::arg("S"),  py::arg("Teta1"),  py::arg("Teta2"),  py::arg("Alpha1"),  py::arg("Alpha2"),  py::arg("VLocation") )
    // custom constructors
    // methods
        .def("SetLocation",
             (void (GProp_VelGProps::*)(  const gp_Pnt &  ) ) static_cast<void (GProp_VelGProps::*)(  const gp_Pnt &  ) >(&GProp_VelGProps::SetLocation),
             R"#()#"  , py::arg("VLocation")
          )
        .def("Perform",
             (void (GProp_VelGProps::*)(  const gp_Cylinder & ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<void (GProp_VelGProps::*)(  const gp_Cylinder & ,   const double ,   const double ,   const double ,   const double  ) >(&GProp_VelGProps::Perform),
             R"#()#"  , py::arg("S"),  py::arg("Alpha1"),  py::arg("Alpha2"),  py::arg("Z1"),  py::arg("Z2")
          )
        .def("Perform",
             (void (GProp_VelGProps::*)(  const gp_Cone & ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<void (GProp_VelGProps::*)(  const gp_Cone & ,   const double ,   const double ,   const double ,   const double  ) >(&GProp_VelGProps::Perform),
             R"#()#"  , py::arg("S"),  py::arg("Alpha1"),  py::arg("Alpha2"),  py::arg("Z1"),  py::arg("Z2")
          )
        .def("Perform",
             (void (GProp_VelGProps::*)(  const gp_Sphere & ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<void (GProp_VelGProps::*)(  const gp_Sphere & ,   const double ,   const double ,   const double ,   const double  ) >(&GProp_VelGProps::Perform),
             R"#()#"  , py::arg("S"),  py::arg("Teta1"),  py::arg("Teta2"),  py::arg("Alpha1"),  py::arg("Alpha2")
          )
        .def("Perform",
             (void (GProp_VelGProps::*)(  const gp_Torus & ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<void (GProp_VelGProps::*)(  const gp_Torus & ,   const double ,   const double ,   const double ,   const double  ) >(&GProp_VelGProps::Perform),
             R"#()#"  , py::arg("S"),  py::arg("Teta1"),  py::arg("Teta2"),  py::arg("Alpha1"),  py::arg("Alpha2")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

// functions

// ./opencascade/GProp.hxx
// ./opencascade/GProp_CelGProps.hxx
// ./opencascade/GProp_GProps.hxx
// ./opencascade/GProp_PEquation.hxx
// ./opencascade/GProp_PGProps.hxx
// ./opencascade/GProp_PrincipalProps.hxx
// ./opencascade/GProp_SelGProps.hxx
// ./opencascade/GProp_UndefinedAxis.hxx
// ./opencascade/GProp_ValueType.hxx
// ./opencascade/GProp_VelGProps.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions
register_occ_exception<GProp_UndefinedAxis>(m, "GProp_UndefinedAxis");

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
