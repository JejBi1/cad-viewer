#pragma once

#include <initializer_list>
using std::initializer_list;

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Extrema_ExtElC.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Extrema_ExtElC2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Lin.hxx>
#include <gp_Circ.hxx>
#include <gp_Elips.hxx>
#include <gp_Hypr.hxx>
#include <gp_Parab.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Lin2d.hxx>
#include <gp_Circ2d.hxx>
#include <gp_Elips2d.hxx>
#include <gp_Hypr2d.hxx>
#include <gp_Parab2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Lin.hxx>
#include <gp_Pln.hxx>
#include <gp_Cylinder.hxx>
#include <gp_Cone.hxx>
#include <gp_Sphere.hxx>
#include <gp_Torus.hxx>
#include <gp_Circ.hxx>
#include <gp_Hypr.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Pln.hxx>
#include <gp_Sphere.hxx>
#include <gp_Cylinder.hxx>
#include <gp_Cone.hxx>
#include <gp_Torus.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Lin.hxx>
#include <gp_Circ.hxx>
#include <gp_Elips.hxx>
#include <gp_Hypr.hxx>
#include <gp_Parab.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Lin2d.hxx>
#include <gp_Circ2d.hxx>
#include <gp_Elips2d.hxx>
#include <gp_Hypr2d.hxx>
#include <gp_Parab2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Cylinder.hxx>
#include <gp_Pln.hxx>
#include <gp_Cone.hxx>
#include <gp_Torus.hxx>
#include <gp_Sphere.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Extrema_ExtPExtS.hxx>
#include <Extrema_ExtPRevS.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <Extrema_CCLocFOfLocECC.hxx>
#include <Extrema_CCLocFOfLocECC2d.hxx>
#include <Extrema_Curve2dTool.hxx>
#include <Extrema_CurveTool.hxx>
#include <Extrema_ECC.hxx>
#include <Extrema_ECC2d.hxx>
#include <Extrema_ELPCOfLocateExtPC.hxx>
#include <Extrema_ELPCOfLocateExtPC2d.hxx>
#include <Extrema_EPCOfELPCOfLocateExtPC.hxx>
#include <Extrema_EPCOfELPCOfLocateExtPC2d.hxx>
#include <Extrema_EPCOfExtPC.hxx>
#include <Extrema_EPCOfExtPC2d.hxx>
#include <Extrema_ElementType.hxx>
#include <Extrema_ExtAlgo.hxx>
#include <Extrema_ExtCC.hxx>
#include <Extrema_ExtCC2d.hxx>
#include <Extrema_ExtCS.hxx>
#include <Extrema_ExtElC.hxx>
#include <Extrema_ExtElC2d.hxx>
#include <Extrema_ExtElCS.hxx>
#include <Extrema_ExtElSS.hxx>
#include <Extrema_ExtFlag.hxx>
#include <Extrema_ExtPC.hxx>
#include <Extrema_ExtPC2d.hxx>
#include <Extrema_ExtPElC.hxx>
#include <Extrema_ExtPElC2d.hxx>
#include <Extrema_ExtPElS.hxx>
#include <Extrema_ExtPExtS.hxx>
#include <Extrema_ExtPRevS.hxx>
#include <Extrema_ExtPS.hxx>
#include <Extrema_ExtSS.hxx>
#include <Extrema_FuncExtCS.hxx>
#include <Extrema_FuncExtSS.hxx>
#include <Extrema_FuncPSDist.hxx>
#include <Extrema_FuncPSNorm.hxx>
#include <Extrema_GCurveLocator.hxx>
#include <Extrema_GFuncExtCC.hxx>
#include <Extrema_GFuncExtPC.hxx>
#include <Extrema_GGExtPC.hxx>
#include <Extrema_GGenExtPC.hxx>
#include <Extrema_GLocateExtPC.hxx>
#include <Extrema_GenExtCS.hxx>
#include <Extrema_GenExtPS.hxx>
#include <Extrema_GenExtSS.hxx>
#include <Extrema_GenLocateExtCC.hxx>
#include <Extrema_GenLocateExtCS.hxx>
#include <Extrema_GenLocateExtPC.hxx>
#include <Extrema_GenLocateExtPS.hxx>
#include <Extrema_GenLocateExtSS.hxx>
#include <Extrema_GlobOptFuncCC.hxx>
#include <Extrema_GlobOptFuncCQuadric.hxx>
#include <Extrema_GlobOptFuncCS.hxx>
#include <Extrema_GlobOptFuncConicS.hxx>
#include <Extrema_LocECC.hxx>
#include <Extrema_LocECC2d.hxx>
#include <Extrema_LocEPCOfLocateExtPC.hxx>
#include <Extrema_LocEPCOfLocateExtPC2d.hxx>
#include <Extrema_LocateExtCC.hxx>
#include <Extrema_LocateExtCC2d.hxx>
#include <Extrema_LocateExtPC.hxx>
#include <Extrema_LocateExtPC2d.hxx>
#include <Extrema_PCFOfEPCOfELPCOfLocateExtPC.hxx>
#include <Extrema_PCFOfEPCOfELPCOfLocateExtPC2d.hxx>
#include <Extrema_PCFOfEPCOfExtPC.hxx>
#include <Extrema_PCFOfEPCOfExtPC2d.hxx>
#include <Extrema_PCLocFOfLocEPCOfLocateExtPC.hxx>
#include <Extrema_PCLocFOfLocEPCOfLocateExtPC2d.hxx>
#include <Extrema_POnCurv.hxx>
#include <Extrema_POnCurv2d.hxx>
#include <Extrema_POnSurf.hxx>
#include <Extrema_POnSurfParams.hxx>

// user-defined pre
#include "OCP_specific.inc"

// Class template handling functions

template <typename TheCurve,typename TheTool,typename ThePOnC,typename TheCCLocF>
void preregister_template_Extrema_GenLocateExtCC(py::object &m, const char *name){
    py::class_<Extrema_GenLocateExtCC<TheCurve,TheTool,ThePOnC,TheCCLocF> , shared_ptr<Extrema_GenLocateExtCC<TheCurve,TheTool,ThePOnC,TheCCLocF>> >(m,name,R"#(Template class for locating local extremum of distance between two curves. Searches for a pair of parameter values (U,V) such that dist(C1(u),C2(v)) passes through an extremum, and (U,V) is the solution closest to (U0,V0).)#");
}

template <typename TheCurve,typename TheTool,typename ThePOnC,typename TheCCLocF>
void register_template_Extrema_GenLocateExtCC(py::object &m, const char *name){
    static_cast<py::class_<Extrema_GenLocateExtCC<TheCurve,TheTool,ThePOnC,TheCCLocF> , shared_ptr<Extrema_GenLocateExtCC<TheCurve,TheTool,ThePOnC,TheCCLocF>> >>(m.attr(name))
        .def(py::init<  const TheCurve &, const TheCurve &, const double, const double, const double, const double >() ,py::arg("theC1"), py::arg("theC2"), py::arg("theU0"), py::arg("theV0"), py::arg("theTolU"), py::arg("theTolV") )
        .def("IsDone",
             (bool (Extrema_GenLocateExtCC<TheCurve,TheTool,ThePOnC,TheCCLocF>::*)() const) &Extrema_GenLocateExtCC<TheCurve,TheTool,ThePOnC,TheCCLocF>::IsDone,
             R"#(Returns True if the distance is found.)#" )
        .def("SquareDistance",
             (double (Extrema_GenLocateExtCC<TheCurve,TheTool,ThePOnC,TheCCLocF>::*)() const) &Extrema_GenLocateExtCC<TheCurve,TheTool,ThePOnC,TheCCLocF>::SquareDistance,
             R"#(Returns the value of the extremum square distance.)#" )
        .def("Point",
             (void (Extrema_GenLocateExtCC<TheCurve,TheTool,ThePOnC,TheCCLocF>::*)( ThePOnC & ,  ThePOnC &  ) const) &Extrema_GenLocateExtCC<TheCurve,TheTool,ThePOnC,TheCCLocF>::Point,
             R"#(Returns the points of the extremum distance.)#" ,py::arg("theP1"), py::arg("theP2"))
    ;
};

template <typename TheCurve,typename TheCurveTool,typename ThePOnC,typename ThePoint>
void preregister_template_Extrema_GCurveLocator(py::object &m, const char *name){
    py::class_<Extrema_GCurveLocator<TheCurve,TheCurveTool,ThePOnC,ThePoint> , shared_ptr<Extrema_GCurveLocator<TheCurve,TheCurveTool,ThePOnC,ThePoint>> >(m,name,R"#(Template class for locating the closest point on a curve to a given point. Among a set of sampled points on the curve, finds the one closest to the target.)#");
}

template <typename TheCurve,typename TheCurveTool,typename ThePOnC,typename ThePoint>
void register_template_Extrema_GCurveLocator(py::object &m, const char *name){
    static_cast<py::class_<Extrema_GCurveLocator<TheCurve,TheCurveTool,ThePOnC,ThePoint> , shared_ptr<Extrema_GCurveLocator<TheCurve,TheCurveTool,ThePOnC,ThePoint>> >>(m.attr(name))
        .def_static("Locate_s",
                    (void (*)(  const ThePoint & ,   const TheCurve & ,   const int ,  ThePOnC &  ) ) &Extrema_GCurveLocator<TheCurve,TheCurveTool,ThePOnC,ThePoint>::Locate,
                    R"#(Among a set of points {C(ui), i=1,NbU}, locate the point P=C(uj) such that: distance(P,C) = Min{distance(P,C(ui))})#" ,py::arg("theP"), py::arg("theC"), py::arg("theNbU"), py::arg("thePapp"))
        .def_static("Locate_s",
                    (void (*)(  const ThePoint & ,   const TheCurve & ,   const int ,   const double ,   const double ,  ThePOnC &  ) ) &Extrema_GCurveLocator<TheCurve,TheCurveTool,ThePOnC,ThePoint>::Locate,
                    R"#(Among a set of points {C(ui), i=1,NbU}, locate the point P=C(uj) such that: distance(P,C) = Min{distance(P,C(ui))} The search is done between theUmin and theUsup.)#" ,py::arg("theP"), py::arg("theC"), py::arg("theNbU"), py::arg("theUmin"), py::arg("theUsup"), py::arg("thePapp"))
    ;
};

template <typename TheCurve,typename TheCurveTool,typename ThePoint,typename TheVector,typename ThePOnC,typename TheELPC,typename TheLocEPC>
void preregister_template_Extrema_GLocateExtPC(py::object &m, const char *name){
    py::class_<Extrema_GLocateExtPC<TheCurve,TheCurveTool,ThePoint,TheVector,ThePOnC,TheELPC,TheLocEPC> , shared_ptr<Extrema_GLocateExtPC<TheCurve,TheCurveTool,ThePoint,TheVector,ThePOnC,TheELPC,TheLocEPC>> >(m,name,R"#(Template class for locating extremum of distance between a point and a curve. Calculates the distance with a close point. The close point is defined by the parameter value U0. The function F(u)=distance(P,C(u)) has an extremum when g(u)=dF/du=0. The algorithm searches a zero near the close point.)#");
}

template <typename TheCurve,typename TheCurveTool,typename ThePoint,typename TheVector,typename ThePOnC,typename TheELPC,typename TheLocEPC>
void register_template_Extrema_GLocateExtPC(py::object &m, const char *name){
    static_cast<py::class_<Extrema_GLocateExtPC<TheCurve,TheCurveTool,ThePoint,TheVector,ThePOnC,TheELPC,TheLocEPC> , shared_ptr<Extrema_GLocateExtPC<TheCurve,TheCurveTool,ThePoint,TheVector,ThePOnC,TheELPC,TheLocEPC>> >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const ThePoint &, const TheCurve &, const double, const double >() ,py::arg("theP"), py::arg("theC"), py::arg("theU0"), py::arg("theTolF") )
        .def(py::init<  const ThePoint &, const TheCurve &, const double, const double, const double, const double >() ,py::arg("theP"), py::arg("theC"), py::arg("theU0"), py::arg("theUmin"), py::arg("theUsup"), py::arg("theTolF") )
        .def("Initialize",
             (void (Extrema_GLocateExtPC<TheCurve,TheCurveTool,ThePoint,TheVector,ThePOnC,TheELPC,TheLocEPC>::*)(  const TheCurve & ,   const double ,   const double ,   const double  ) ) &Extrema_GLocateExtPC<TheCurve,TheCurveTool,ThePoint,TheVector,ThePOnC,TheELPC,TheLocEPC>::Initialize,
             R"#(Sets the fields of the algorithm.)#" ,py::arg("theC"), py::arg("theUmin"), py::arg("theUsup"), py::arg("theTolF"))
        .def("Perform",
             (void (Extrema_GLocateExtPC<TheCurve,TheCurveTool,ThePoint,TheVector,ThePOnC,TheELPC,TheLocEPC>::*)(  const ThePoint & ,   const double  ) ) &Extrema_GLocateExtPC<TheCurve,TheCurveTool,ThePoint,TheVector,ThePOnC,TheELPC,TheLocEPC>::Perform,
             R"#(Performs the algorithm with point P and initial parameter U0.)#" ,py::arg("theP"), py::arg("theU0"))
        .def("IsDone",
             (bool (Extrema_GLocateExtPC<TheCurve,TheCurveTool,ThePoint,TheVector,ThePOnC,TheELPC,TheLocEPC>::*)() const) &Extrema_GLocateExtPC<TheCurve,TheCurveTool,ThePoint,TheVector,ThePOnC,TheELPC,TheLocEPC>::IsDone,
             R"#(Returns True if the distance is found.)#" )
        .def("SquareDistance",
             (double (Extrema_GLocateExtPC<TheCurve,TheCurveTool,ThePoint,TheVector,ThePOnC,TheELPC,TheLocEPC>::*)() const) &Extrema_GLocateExtPC<TheCurve,TheCurveTool,ThePoint,TheVector,ThePOnC,TheELPC,TheLocEPC>::SquareDistance,
             R"#(Returns the value of the extremum square distance.)#" )
        .def("IsMin",
             (bool (Extrema_GLocateExtPC<TheCurve,TheCurveTool,ThePoint,TheVector,ThePOnC,TheELPC,TheLocEPC>::*)() const) &Extrema_GLocateExtPC<TheCurve,TheCurveTool,ThePoint,TheVector,ThePOnC,TheELPC,TheLocEPC>::IsMin,
             R"#(Returns True if the extremum distance is a minimum.)#" )
        .def("Point",
             ( const ThePOnC & (Extrema_GLocateExtPC<TheCurve,TheCurveTool,ThePoint,TheVector,ThePOnC,TheELPC,TheLocEPC>::*)() const) &Extrema_GLocateExtPC<TheCurve,TheCurveTool,ThePoint,TheVector,ThePOnC,TheELPC,TheLocEPC>::Point,
             R"#(Returns the point of the extremum distance.)#" )
    ;
};

template <typename TheCurve,typename TheCurveTool,typename ThePOnC,typename ThePoint,typename TheVector,typename TheSeqPOnC>
void preregister_template_Extrema_GFuncExtPC(py::object &m, const char *name){
    py::class_<Extrema_GFuncExtPC<TheCurve,TheCurveTool,ThePOnC,ThePoint,TheVector,TheSeqPOnC> , shared_ptr<Extrema_GFuncExtPC<TheCurve,TheCurveTool,ThePOnC,ThePoint,TheVector,TheSeqPOnC>> , math_FunctionWithDerivative >(m,name,R"#(Template class for computing extremal distance function between a point and a curve. Searches for a parameter value u such that dist(P, C(u)) passes through an extremum. Inherits from math_FunctionWithDerivative and is used by math_FunctionRoot and math_FunctionRoots algorithms.)#");
}

template <typename TheCurve,typename TheCurveTool,typename ThePOnC,typename ThePoint,typename TheVector,typename TheSeqPOnC>
void register_template_Extrema_GFuncExtPC(py::object &m, const char *name){
    static_cast<py::class_<Extrema_GFuncExtPC<TheCurve,TheCurveTool,ThePOnC,ThePoint,TheVector,TheSeqPOnC> , shared_ptr<Extrema_GFuncExtPC<TheCurve,TheCurveTool,ThePOnC,ThePoint,TheVector,TheSeqPOnC>> , math_FunctionWithDerivative >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const ThePoint &, const TheCurve & >() ,py::arg("theP"), py::arg("theC") )
        .def("Initialize",
             (void (Extrema_GFuncExtPC<TheCurve,TheCurveTool,ThePOnC,ThePoint,TheVector,TheSeqPOnC>::*)(  const TheCurve &  ) ) &Extrema_GFuncExtPC<TheCurve,TheCurveTool,ThePOnC,ThePoint,TheVector,TheSeqPOnC>::Initialize,
             R"#(Sets the curve field.)#" ,py::arg("theC"))
        .def("SetPoint",
             (void (Extrema_GFuncExtPC<TheCurve,TheCurveTool,ThePOnC,ThePoint,TheVector,TheSeqPOnC>::*)(  const ThePoint &  ) ) &Extrema_GFuncExtPC<TheCurve,TheCurveTool,ThePOnC,ThePoint,TheVector,TheSeqPOnC>::SetPoint,
             R"#(Sets the point field.)#" ,py::arg("theP"))
        .def("Value",
             (bool (Extrema_GFuncExtPC<TheCurve,TheCurveTool,ThePOnC,ThePoint,TheVector,TheSeqPOnC>::*)(  const double ,  double &  ) ) &Extrema_GFuncExtPC<TheCurve,TheCurveTool,ThePOnC,ThePoint,TheVector,TheSeqPOnC>::Value,
             R"#(Calculation of F(u).)#" ,py::arg("theU"), py::arg("theF"))
        .def("Derivative",
             (bool (Extrema_GFuncExtPC<TheCurve,TheCurveTool,ThePOnC,ThePoint,TheVector,TheSeqPOnC>::*)(  const double ,  double &  ) ) &Extrema_GFuncExtPC<TheCurve,TheCurveTool,ThePOnC,ThePoint,TheVector,TheSeqPOnC>::Derivative,
             R"#(Calculation of F'(u).)#" ,py::arg("theU"), py::arg("theDF"))
        .def("Values",
             (bool (Extrema_GFuncExtPC<TheCurve,TheCurveTool,ThePOnC,ThePoint,TheVector,TheSeqPOnC>::*)(  const double ,  double & ,  double &  ) ) &Extrema_GFuncExtPC<TheCurve,TheCurveTool,ThePOnC,ThePoint,TheVector,TheSeqPOnC>::Values,
             R"#(Calculation of F(u) and F'(u).)#" ,py::arg("theU"), py::arg("theF"), py::arg("theDF"))
        .def("GetStateNumber",
             (int (Extrema_GFuncExtPC<TheCurve,TheCurveTool,ThePOnC,ThePoint,TheVector,TheSeqPOnC>::*)() ) &Extrema_GFuncExtPC<TheCurve,TheCurveTool,ThePOnC,ThePoint,TheVector,TheSeqPOnC>::GetStateNumber,
             R"#(Save the found extremum.)#" )
        .def("NbExt",
             (int (Extrema_GFuncExtPC<TheCurve,TheCurveTool,ThePOnC,ThePoint,TheVector,TheSeqPOnC>::*)() const) &Extrema_GFuncExtPC<TheCurve,TheCurveTool,ThePOnC,ThePoint,TheVector,TheSeqPOnC>::NbExt,
             R"#(Return the number of found extrema.)#" )
        .def("SquareDistance",
             (double (Extrema_GFuncExtPC<TheCurve,TheCurveTool,ThePOnC,ThePoint,TheVector,TheSeqPOnC>::*)(  const int  ) const) &Extrema_GFuncExtPC<TheCurve,TheCurveTool,ThePOnC,ThePoint,TheVector,TheSeqPOnC>::SquareDistance,
             R"#(Returns the Nth square distance.)#" ,py::arg("theN"))
        .def("IsMin",
             (bool (Extrema_GFuncExtPC<TheCurve,TheCurveTool,ThePOnC,ThePoint,TheVector,TheSeqPOnC>::*)(  const int  ) const) &Extrema_GFuncExtPC<TheCurve,TheCurveTool,ThePOnC,ThePoint,TheVector,TheSeqPOnC>::IsMin,
             R"#(Shows if the Nth distance is a minimum.)#" ,py::arg("theN"))
        .def("Point",
             ( const ThePOnC & (Extrema_GFuncExtPC<TheCurve,TheCurveTool,ThePOnC,ThePoint,TheVector,TheSeqPOnC>::*)(  const int  ) const) &Extrema_GFuncExtPC<TheCurve,TheCurveTool,ThePOnC,ThePoint,TheVector,TheSeqPOnC>::Point,
             R"#(Returns the Nth extremum point.)#" ,py::arg("theN"))
        .def("SubIntervalInitialize",
             (void (Extrema_GFuncExtPC<TheCurve,TheCurveTool,ThePOnC,ThePoint,TheVector,TheSeqPOnC>::*)(  const double ,   const double  ) ) &Extrema_GFuncExtPC<TheCurve,TheCurveTool,ThePOnC,ThePoint,TheVector,TheSeqPOnC>::SubIntervalInitialize,
             R"#(Determines boundaries of subinterval for root finding.)#" ,py::arg("theUfirst"), py::arg("theUlast"))
        .def("SearchOfTolerance",
             (double (Extrema_GFuncExtPC<TheCurve,TheCurveTool,ThePOnC,ThePoint,TheVector,TheSeqPOnC>::*)() ) &Extrema_GFuncExtPC<TheCurve,TheCurveTool,ThePOnC,ThePoint,TheVector,TheSeqPOnC>::SearchOfTolerance,
             R"#(Computes a tolerance value. If 1st derivative of curve |D1| < Tol, it is considered D1=0.)#" )
    ;
};

template <typename TheCurve,typename TheTool,typename ThePOnC,typename ThePnt,typename ThePCLocF>
void preregister_template_Extrema_GenLocateExtPC(py::object &m, const char *name){
    py::class_<Extrema_GenLocateExtPC<TheCurve,TheTool,ThePOnC,ThePnt,ThePCLocF> , shared_ptr<Extrema_GenLocateExtPC<TheCurve,TheTool,ThePOnC,ThePnt,ThePCLocF>> >(m,name,R"#(Template class for local extremum search between a point and a curve. Searches for a local extremum of distance between a point and a curve near an initial parameter value.)#");
}

template <typename TheCurve,typename TheTool,typename ThePOnC,typename ThePnt,typename ThePCLocF>
void register_template_Extrema_GenLocateExtPC(py::object &m, const char *name){
    static_cast<py::class_<Extrema_GenLocateExtPC<TheCurve,TheTool,ThePOnC,ThePnt,ThePCLocF> , shared_ptr<Extrema_GenLocateExtPC<TheCurve,TheTool,ThePOnC,ThePnt,ThePCLocF>> >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const ThePnt &, const TheCurve &, const double, const double >() ,py::arg("theP"), py::arg("theC"), py::arg("theU0"), py::arg("theTolU") )
        .def(py::init<  const ThePnt &, const TheCurve &, const double, const double, const double, const double >() ,py::arg("theP"), py::arg("theC"), py::arg("theU0"), py::arg("theUmin"), py::arg("theUsup"), py::arg("theTolU") )
        .def("Initialize",
             (void (Extrema_GenLocateExtPC<TheCurve,TheTool,ThePOnC,ThePnt,ThePCLocF>::*)(  const TheCurve & ,   const double ,   const double ,   const double  ) ) &Extrema_GenLocateExtPC<TheCurve,TheTool,ThePOnC,ThePnt,ThePCLocF>::Initialize,
             R"#(Sets the fields of the algorithm.)#" ,py::arg("theC"), py::arg("theUmin"), py::arg("theUsup"), py::arg("theTolU"))
        .def("Perform",
             (void (Extrema_GenLocateExtPC<TheCurve,TheTool,ThePOnC,ThePnt,ThePCLocF>::*)(  const ThePnt & ,   const double  ) ) &Extrema_GenLocateExtPC<TheCurve,TheTool,ThePOnC,ThePnt,ThePCLocF>::Perform,
             R"#(The algorithm is done with the point P. An exception is raised if the fields have not been initialized.)#" ,py::arg("theP"), py::arg("theU0"))
        .def("IsDone",
             (bool (Extrema_GenLocateExtPC<TheCurve,TheTool,ThePOnC,ThePnt,ThePCLocF>::*)() const) &Extrema_GenLocateExtPC<TheCurve,TheTool,ThePOnC,ThePnt,ThePCLocF>::IsDone,
             R"#(Returns True if the distance is found.)#" )
        .def("SquareDistance",
             (double (Extrema_GenLocateExtPC<TheCurve,TheTool,ThePOnC,ThePnt,ThePCLocF>::*)() const) &Extrema_GenLocateExtPC<TheCurve,TheTool,ThePOnC,ThePnt,ThePCLocF>::SquareDistance,
             R"#(Returns the value of the extremum square distance.)#" )
        .def("IsMin",
             (bool (Extrema_GenLocateExtPC<TheCurve,TheTool,ThePOnC,ThePnt,ThePCLocF>::*)() const) &Extrema_GenLocateExtPC<TheCurve,TheTool,ThePOnC,ThePnt,ThePCLocF>::IsMin,
             R"#(Returns True if the extremum distance is a minimum.)#" )
        .def("Point",
             ( const ThePOnC & (Extrema_GenLocateExtPC<TheCurve,TheTool,ThePOnC,ThePnt,ThePCLocF>::*)() const) &Extrema_GenLocateExtPC<TheCurve,TheTool,ThePOnC,ThePnt,ThePCLocF>::Point,
             R"#(Returns the point of the extremum distance.)#" )
    ;
};

template <typename TheCurve1,typename TheCurveTool1,typename TheCurve2,typename TheCurveTool2,typename ThePOnC,typename ThePoint,typename TheVector,typename TheSequenceOfPOnC>
void preregister_template_Extrema_GFuncExtCC(py::object &m, const char *name){
    py::class_<Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC> , shared_ptr<Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>> , math_FunctionSetWithDerivatives >(m,name,R"#(Template class for function used to find extremal distance between two curves. This class inherits from math_FunctionSetWithDerivatives and is used by the algorithm math_FunctionSetRoot.)#");
}

template <typename TheCurve1,typename TheCurveTool1,typename TheCurve2,typename TheCurveTool2,typename ThePOnC,typename ThePoint,typename TheVector,typename TheSequenceOfPOnC>
void register_template_Extrema_GFuncExtCC(py::object &m, const char *name){
    static_cast<py::class_<Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC> , shared_ptr<Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>> , math_FunctionSetWithDerivatives >>(m.attr(name))
        .def(py::init<  const double >() ,py::arg("theTol")=static_cast< const double>(1.0e-10) )
        .def(py::init<  const TheCurve1 &, const TheCurve2 &, const double >() ,py::arg("theC1"), py::arg("theC2"), py::arg("theTol")=static_cast< const double>(1.0e-10) )
        .def("SetCurve",
             (void (Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>::*)(  const int ,   const TheCurve1 &  ) ) &Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>::SetCurve,
             R"#(Sets the curve for the specified rank (1 or 2).)#" ,py::arg("theRank"), py::arg("theC"))
        .def("SetTolerance",
             (void (Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>::*)(  const double  ) ) &Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>::SetTolerance,
             R"#(Sets the tolerance.)#" ,py::arg("theTol"))
        .def("NbVariables",
             (int (Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>::*)() const) &Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>::NbVariables,
             R"#(Returns the number of variables (2).)#" )
        .def("NbEquations",
             (int (Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>::*)() const) &Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>::NbEquations,
             R"#(Returns the number of equations (2).)#" )
        .def("Value",
             (bool (Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>::*)(  const math_Vector & ,  math_Vector &  ) ) &Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>::Value,
             R"#(Calculate Fi(U,V).)#" ,py::arg("theUV"), py::arg("theF"))
        .def("Derivatives",
             (bool (Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>::*)(  const math_Vector & ,  math_Matrix &  ) ) &Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>::Derivatives,
             R"#(Calculate Fi'(U,V).)#" ,py::arg("theUV"), py::arg("theDF"))
        .def("Values",
             (bool (Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>::*)(  const math_Vector & ,  math_Vector & ,  math_Matrix &  ) ) &Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>::Values,
             R"#(Calculate Fi(U,V) and Fi'(U,V).)#" ,py::arg("theUV"), py::arg("theF"), py::arg("theDF"))
        .def("GetStateNumber",
             (int (Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>::*)() ) &Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>::GetStateNumber,
             R"#(Save the found extremum.)#" )
        .def("NbExt",
             (int (Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>::*)() const) &Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>::NbExt,
             R"#(Return the number of found extrema.)#" )
        .def("SquareDistance",
             (double (Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>::*)(  const int  ) const) &Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>::SquareDistance,
             R"#(Return the value of the Nth distance.)#" ,py::arg("theN"))
        .def("Points",
             (void (Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>::*)(  const int ,  ThePOnC & ,  ThePOnC &  ) const) &Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>::Points,
             R"#(Return the points of the Nth extreme distance.)#" ,py::arg("theN"), py::arg("theP1"), py::arg("theP2"))
        .def("CurvePtr",
             (void * (Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>::*)(  const int  ) const) &Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>::CurvePtr,
             R"#(Returns a pointer to the curve specified in the constructor or in SetCurve() method.)#" ,py::arg("theRank"))
        .def("Tolerance",
             (double (Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>::*)() const) &Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>::Tolerance,
             R"#(Returns a tolerance specified in the constructor or in SetTolerance() method.)#" )
        .def("SubIntervalInitialize",
             (void (Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>::*)(  const math_Vector & ,   const math_Vector &  ) ) &Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>::SubIntervalInitialize,
             R"#(Determines boundaries of subinterval for find of root.)#" ,py::arg("theUfirst"), py::arg("theUlast"))
        .def("SearchOfTolerance",
             (double (Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>::*)( void * const   ) ) &Extrema_GFuncExtCC<TheCurve1,TheCurveTool1,TheCurve2,TheCurveTool2,ThePOnC,ThePoint,TheVector,TheSequenceOfPOnC>::SearchOfTolerance,
             R"#(Computes a Tol value. If 1st derivative of curve |D1|<Tol, it is considered D1=0.)#" ,py::arg("theC"))
    ;
};

template <typename TheCurve,typename TheCurveTool,typename TheExtPElC,typename ThePoint,typename TheVector,typename ThePOnC,typename TheSequenceOfPOnC,typename TheEPC>
void preregister_template_Extrema_GGExtPC(py::object &m, const char *name){
    py::class_<Extrema_GGExtPC<TheCurve,TheCurveTool,TheExtPElC,ThePoint,TheVector,ThePOnC,TheSequenceOfPOnC,TheEPC> , shared_ptr<Extrema_GGExtPC<TheCurve,TheCurveTool,TheExtPElC,ThePoint,TheVector,ThePOnC,TheSequenceOfPOnC,TheEPC>> >(m,name,R"#(Generic class for computing extremal distances between a point and a curve.)#");
}

template <typename TheCurve,typename TheCurveTool,typename TheExtPElC,typename ThePoint,typename TheVector,typename ThePOnC,typename TheSequenceOfPOnC,typename TheEPC>
void register_template_Extrema_GGExtPC(py::object &m, const char *name){
    static_cast<py::class_<Extrema_GGExtPC<TheCurve,TheCurveTool,TheExtPElC,ThePoint,TheVector,ThePOnC,TheSequenceOfPOnC,TheEPC> , shared_ptr<Extrema_GGExtPC<TheCurve,TheCurveTool,TheExtPElC,ThePoint,TheVector,ThePOnC,TheSequenceOfPOnC,TheEPC>> >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const ThePoint &, const TheCurve &, const double, const double, const double >() ,py::arg("theP"), py::arg("theC"), py::arg("theUinf"), py::arg("theUsup"), py::arg("theTolF")=static_cast< const double>(1.0e-10) )
        .def(py::init<  const ThePoint &, const TheCurve &, const double >() ,py::arg("theP"), py::arg("theC"), py::arg("theTolF")=static_cast< const double>(1.0e-10) )
        .def("Initialize",
             (void (Extrema_GGExtPC<TheCurve,TheCurveTool,TheExtPElC,ThePoint,TheVector,ThePOnC,TheSequenceOfPOnC,TheEPC>::*)(  const TheCurve & ,   const double ,   const double ,   const double  ) ) &Extrema_GGExtPC<TheCurve,TheCurveTool,TheExtPElC,ThePoint,TheVector,ThePOnC,TheSequenceOfPOnC,TheEPC>::Initialize,
             R"#(Initializes the algorithm with curve and parameter range.)#" ,py::arg("theC"), py::arg("theUinf"), py::arg("theUsup"), py::arg("theTolF")=static_cast< const double>(1.0e-10))
        .def("Perform",
             (void (Extrema_GGExtPC<TheCurve,TheCurveTool,TheExtPElC,ThePoint,TheVector,ThePOnC,TheSequenceOfPOnC,TheEPC>::*)(  const ThePoint &  ) ) &Extrema_GGExtPC<TheCurve,TheCurveTool,TheExtPElC,ThePoint,TheVector,ThePOnC,TheSequenceOfPOnC,TheEPC>::Perform,
             R"#(Performs the extremum computation for the given point.)#" ,py::arg("theP"))
        .def("IsDone",
             (bool (Extrema_GGExtPC<TheCurve,TheCurveTool,TheExtPElC,ThePoint,TheVector,ThePOnC,TheSequenceOfPOnC,TheEPC>::*)() const) &Extrema_GGExtPC<TheCurve,TheCurveTool,TheExtPElC,ThePoint,TheVector,ThePOnC,TheSequenceOfPOnC,TheEPC>::IsDone,
             R"#(Returns true if the distances are found.)#" )
        .def("SquareDistance",
             (double (Extrema_GGExtPC<TheCurve,TheCurveTool,TheExtPElC,ThePoint,TheVector,ThePOnC,TheSequenceOfPOnC,TheEPC>::*)(  const int  ) const) &Extrema_GGExtPC<TheCurve,TheCurveTool,TheExtPElC,ThePoint,TheVector,ThePOnC,TheSequenceOfPOnC,TheEPC>::SquareDistance,
             R"#(Returns the Nth extremum square distance.)#" ,py::arg("theN"))
        .def("NbExt",
             (int (Extrema_GGExtPC<TheCurve,TheCurveTool,TheExtPElC,ThePoint,TheVector,ThePOnC,TheSequenceOfPOnC,TheEPC>::*)() const) &Extrema_GGExtPC<TheCurve,TheCurveTool,TheExtPElC,ThePoint,TheVector,ThePOnC,TheSequenceOfPOnC,TheEPC>::NbExt,
             R"#(Returns the number of extremum distances.)#" )
        .def("IsMin",
             (bool (Extrema_GGExtPC<TheCurve,TheCurveTool,TheExtPElC,ThePoint,TheVector,ThePOnC,TheSequenceOfPOnC,TheEPC>::*)(  const int  ) const) &Extrema_GGExtPC<TheCurve,TheCurveTool,TheExtPElC,ThePoint,TheVector,ThePOnC,TheSequenceOfPOnC,TheEPC>::IsMin,
             R"#(Returns true if the Nth extremum distance is a minimum.)#" ,py::arg("theN"))
        .def("Point",
             ( const ThePOnC & (Extrema_GGExtPC<TheCurve,TheCurveTool,TheExtPElC,ThePoint,TheVector,ThePOnC,TheSequenceOfPOnC,TheEPC>::*)(  const int  ) const) &Extrema_GGExtPC<TheCurve,TheCurveTool,TheExtPElC,ThePoint,TheVector,ThePOnC,TheSequenceOfPOnC,TheEPC>::Point,
             R"#(Returns the point of the Nth extremum distance.)#" ,py::arg("theN"))
        .def("TrimmedSquareDistances",
             (void (Extrema_GGExtPC<TheCurve,TheCurveTool,TheExtPElC,ThePoint,TheVector,ThePOnC,TheSequenceOfPOnC,TheEPC>::*)( double & ,  double & ,  ThePoint & ,  ThePoint &  ) const) &Extrema_GGExtPC<TheCurve,TheCurveTool,TheExtPElC,ThePoint,TheVector,ThePOnC,TheSequenceOfPOnC,TheEPC>::TrimmedSquareDistances,
             R"#(Returns the distances at curve endpoints.)#" ,py::arg("theDist1"), py::arg("theDist2"), py::arg("theP1"), py::arg("theP2"))
    ;
};

template <typename TheCurve,typename TheTool,typename ThePOnC,typename ThePoint,typename ThePCF>
void preregister_template_Extrema_GGenExtPC(py::object &m, const char *name){
    py::class_<Extrema_GGenExtPC<TheCurve,TheTool,ThePOnC,ThePoint,ThePCF> , shared_ptr<Extrema_GGenExtPC<TheCurve,TheTool,ThePOnC,ThePoint,ThePCF>> >(m,name,R"#(Generic class for finding extremal distances between a point and a curve.)#");
}

template <typename TheCurve,typename TheTool,typename ThePOnC,typename ThePoint,typename ThePCF>
void register_template_Extrema_GGenExtPC(py::object &m, const char *name){
    static_cast<py::class_<Extrema_GGenExtPC<TheCurve,TheTool,ThePOnC,ThePoint,ThePCF> , shared_ptr<Extrema_GGenExtPC<TheCurve,TheTool,ThePOnC,ThePoint,ThePCF>> >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const ThePoint &, const TheCurve &, const int, const double, const double >() ,py::arg("theP"), py::arg("theC"), py::arg("theNbSample"), py::arg("theTolU"), py::arg("theTolF") )
        .def(py::init<  const ThePoint &, const TheCurve &, const int, const double, const double, const double, const double >() ,py::arg("theP"), py::arg("theC"), py::arg("theNbSample"), py::arg("theUmin"), py::arg("theUsup"), py::arg("theTolU"), py::arg("theTolF") )
        .def("Initialize",
             (void (Extrema_GGenExtPC<TheCurve,TheTool,ThePOnC,ThePoint,ThePCF>::*)(  const TheCurve & ,   const int ,   const double ,   const double  ) ) &Extrema_GGenExtPC<TheCurve,TheTool,ThePOnC,ThePoint,ThePCF>::Initialize,
             R"#(Initializes the algorithm with the full curve parameter range.)#" ,py::arg("theC"), py::arg("theNbU"), py::arg("theTolU"), py::arg("theTolF"))
        .def("Initialize",
             (void (Extrema_GGenExtPC<TheCurve,TheTool,ThePOnC,ThePoint,ThePCF>::*)(  const TheCurve & ,   const int ,   const double ,   const double ,   const double ,   const double  ) ) &Extrema_GGenExtPC<TheCurve,TheTool,ThePOnC,ThePoint,ThePCF>::Initialize,
             R"#(Initializes the algorithm with a specified parameter range.)#" ,py::arg("theC"), py::arg("theNbU"), py::arg("theUmin"), py::arg("theUsup"), py::arg("theTolU"), py::arg("theTolF"))
        .def("Initialize",
             (void (Extrema_GGenExtPC<TheCurve,TheTool,ThePOnC,ThePoint,ThePCF>::*)(  const int ,   const double ,   const double ,   const double ,   const double  ) ) &Extrema_GGenExtPC<TheCurve,TheTool,ThePOnC,ThePoint,ThePCF>::Initialize,
             R"#(Initializes only the parameter range and tolerances.)#" ,py::arg("theNbU"), py::arg("theUmin"), py::arg("theUsup"), py::arg("theTolU"), py::arg("theTolF"))
        .def("Initialize",
             (void (Extrema_GGenExtPC<TheCurve,TheTool,ThePOnC,ThePoint,ThePCF>::*)(  const TheCurve &  ) ) &Extrema_GGenExtPC<TheCurve,TheTool,ThePOnC,ThePoint,ThePCF>::Initialize,
             R"#(Initializes the curve for the function.)#" ,py::arg("theC"))
        .def("Perform",
             (void (Extrema_GGenExtPC<TheCurve,TheTool,ThePOnC,ThePoint,ThePCF>::*)(  const ThePoint &  ) ) &Extrema_GGenExtPC<TheCurve,TheTool,ThePOnC,ThePoint,ThePCF>::Perform,
             R"#(Performs the extremum search for the given point.)#" ,py::arg("theP"))
        .def("IsDone",
             (bool (Extrema_GGenExtPC<TheCurve,TheTool,ThePOnC,ThePoint,ThePCF>::*)() const) &Extrema_GGenExtPC<TheCurve,TheTool,ThePOnC,ThePoint,ThePCF>::IsDone,
             R"#(Returns true if the distances are found.)#" )
        .def("NbExt",
             (int (Extrema_GGenExtPC<TheCurve,TheTool,ThePOnC,ThePoint,ThePCF>::*)() const) &Extrema_GGenExtPC<TheCurve,TheTool,ThePOnC,ThePoint,ThePCF>::NbExt,
             R"#(Returns the number of extremum distances.)#" )
        .def("SquareDistance",
             (double (Extrema_GGenExtPC<TheCurve,TheTool,ThePOnC,ThePoint,ThePCF>::*)(  const int  ) const) &Extrema_GGenExtPC<TheCurve,TheTool,ThePOnC,ThePoint,ThePCF>::SquareDistance,
             R"#(Returns the Nth extremum square distance.)#" ,py::arg("theN"))
        .def("IsMin",
             (bool (Extrema_GGenExtPC<TheCurve,TheTool,ThePOnC,ThePoint,ThePCF>::*)(  const int  ) const) &Extrema_GGenExtPC<TheCurve,TheTool,ThePOnC,ThePoint,ThePCF>::IsMin,
             R"#(Returns true if the Nth extremum distance is a minimum.)#" ,py::arg("theN"))
        .def("Point",
             ( const ThePOnC & (Extrema_GGenExtPC<TheCurve,TheTool,ThePOnC,ThePoint,ThePCF>::*)(  const int  ) const) &Extrema_GGenExtPC<TheCurve,TheTool,ThePOnC,ThePoint,ThePCF>::Point,
             R"#(Returns the point of the Nth extremum distance.)#" ,py::arg("theN"))
    ;
};


// user-defined post

