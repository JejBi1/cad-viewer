
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom_Curve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom2d_Curve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>

// module includes
#include <GeomLProp.hxx>
#include <GeomLProp_CLProps.hxx>
#include <GeomLProp_CurAndInf2d.hxx>
#include <GeomLProp_SLProps.hxx>
#include <GeomLProp_SurfaceUtils.hxx>

// template related includes

// ./opencascade/GeomLProp_CLProps.hxx
#include "GeomLProp_tmpl.hxx"

// ./opencascade/GeomLProp_CLProps.hxx
#include "GeomLProp_tmpl.hxx"

// ./opencascade/GeomLProp_SLProps.hxx
#include "GeomLProp_tmpl.hxx"


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_GeomLProp(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("GeomLProp"));
py::object klass;

// get namespaces as submodules
auto LProp_SurfaceUtils = static_cast<py::module>(m.attr("LProp_SurfaceUtils"));

//Python trampoline classes

// classes

    // Class GeomLProp from ./opencascade/GeomLProp.hxx
    klass = m.attr("GeomLProp");

    // default constructor
    register_default_constructor<GeomLProp , shared_ptr<GeomLProp>>(m,"GeomLProp");

    // nested enums

    static_cast<py::class_<GeomLProp , shared_ptr<GeomLProp>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Continuity_s",
                    (GeomAbs_Shape (*)(  const handle<Geom_Curve> & ,   const handle<Geom_Curve> & ,   const double ,   const double ,   const bool ,   const bool ,   const double ,   const double  ) ) static_cast<GeomAbs_Shape (*)(  const handle<Geom_Curve> & ,   const handle<Geom_Curve> & ,   const double ,   const double ,   const bool ,   const bool ,   const double ,   const double  ) >(&GeomLProp::Continuity),
                    R"#(Computes the regularity at the junction between C1 and C2. The booleans r1 and r2 are true if the curves must be taken reversed. The point u1 on C1 and the point u2 on C2 must be confused. tl and ta are the linear and angular tolerance used two compare the derivative.)#"  , py::arg("C1"),  py::arg("C2"),  py::arg("u1"),  py::arg("u2"),  py::arg("r1"),  py::arg("r2"),  py::arg("tl"),  py::arg("ta")
          )
        .def_static("Continuity_s",
                    (GeomAbs_Shape (*)(  const handle<Geom_Curve> & ,   const handle<Geom_Curve> & ,   const double ,   const double ,   const bool ,   const bool  ) ) static_cast<GeomAbs_Shape (*)(  const handle<Geom_Curve> & ,   const handle<Geom_Curve> & ,   const double ,   const double ,   const bool ,   const bool  ) >(&GeomLProp::Continuity),
                    R"#(The same as preceding but using the standard tolerances from package Precision.)#"  , py::arg("C1"),  py::arg("C2"),  py::arg("u1"),  py::arg("u2"),  py::arg("r1"),  py::arg("r2")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class GeomLProp_CurAndInf2d from ./opencascade/GeomLProp_CurAndInf2d.hxx
    klass = m.attr("GeomLProp_CurAndInf2d");


    // nested enums

    static_cast<py::class_<GeomLProp_CurAndInf2d , shared_ptr<GeomLProp_CurAndInf2d>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Perform",
             (void (GeomLProp_CurAndInf2d::*)(  const handle<Geom2d_Curve> &  ) ) static_cast<void (GeomLProp_CurAndInf2d::*)(  const handle<Geom2d_Curve> &  ) >(&GeomLProp_CurAndInf2d::Perform),
             R"#(For the curve C, Computes both the inflection points and the maximum and minimum curvatures.)#"  , py::arg("C")
          )
        .def("PerformCurExt",
             (void (GeomLProp_CurAndInf2d::*)(  const handle<Geom2d_Curve> &  ) ) static_cast<void (GeomLProp_CurAndInf2d::*)(  const handle<Geom2d_Curve> &  ) >(&GeomLProp_CurAndInf2d::PerformCurExt),
             R"#(For the curve C, Computes the locals extremas of curvature.)#"  , py::arg("C")
          )
        .def("PerformInf",
             (void (GeomLProp_CurAndInf2d::*)(  const handle<Geom2d_Curve> &  ) ) static_cast<void (GeomLProp_CurAndInf2d::*)(  const handle<Geom2d_Curve> &  ) >(&GeomLProp_CurAndInf2d::PerformInf),
             R"#(For the curve C, Computes the inflections. After computation, the following functions can be used: - IsDone to check if the computation was successful - NbPoints to obtain the number of computed particular points - Parameter to obtain the parameter on the curve for each particular point - Type to check if the point is an inflection point or an extremum of curvature of the curve C. Warning These functions can be used to analyze a series of curves, however it is necessary to clear the table of results between each computation.)#"  , py::arg("C")
          )
        .def("IsDone",
             (bool (GeomLProp_CurAndInf2d::*)() const) static_cast<bool (GeomLProp_CurAndInf2d::*)() const>(&GeomLProp_CurAndInf2d::IsDone),
             R"#(True if the solutions are found.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class LProp_SurfaceUtils::DirectAccess from ./opencascade/GeomLProp_SurfaceUtils.hxx
    klass = LProp_SurfaceUtils.attr("DirectAccess");

    // default constructor
    register_default_constructor<LProp_SurfaceUtils::DirectAccess , shared_ptr<LProp_SurfaceUtils::DirectAccess>>(LProp_SurfaceUtils,"DirectAccess");

    // nested enums

    static_cast<py::class_<LProp_SurfaceUtils::DirectAccess , shared_ptr<LProp_SurfaceUtils::DirectAccess>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

// functions
auto mLProp_SurfaceUtils = static_cast<py::module>(m.attr("LProp_SurfaceUtils"));

// ./opencascade/GeomLProp.hxx
// ./opencascade/GeomLProp_CLProps.hxx
// ./opencascade/GeomLProp_CurAndInf2d.hxx
// ./opencascade/GeomLProp_SLProps.hxx
// ./opencascade/GeomLProp_SurfaceUtils.hxx
    mLProp_SurfaceUtils.def("GetSurfBounds",
          (void (*)(  const Geom_Surface & ,  double & ,  double & ,  double & ,  double &  ))  static_cast<void (*)(  const Geom_Surface & ,  double & ,  double & ,  double & ,  double &  )>(&LProp_SurfaceUtils::GetSurfBounds),
          R"#(Get bounds from Geom_Surface (uses Bounds method with U1, U2, V1, V2 order).)#"  , py::arg("theSurf"),  py::arg("theU1"),  py::arg("theV1"),  py::arg("theU2"),  py::arg("theV2")
          );
    mLProp_SurfaceUtils.def("GetSurfBounds",
          (void (*)(  const Adaptor3d_Surface & ,  double & ,  double & ,  double & ,  double &  ))  static_cast<void (*)(  const Adaptor3d_Surface & ,  double & ,  double & ,  double & ,  double &  )>(&LProp_SurfaceUtils::GetSurfBounds),
          R"#(Get bounds from Adaptor3d_Surface (uses individual parameter methods). Also works for BRepAdaptor_Surface which inherits from Adaptor3d_Surface.)#"  , py::arg("theSurf"),  py::arg("theU1"),  py::arg("theV1"),  py::arg("theU2"),  py::arg("theV2")
          );
    mLProp_SurfaceUtils.def("ComputeSurfNormal",
          (bool (*)(  const gp_Vec & ,   const gp_Vec & ,  double ,  gp_Dir &  ))  static_cast<bool (*)(  const gp_Vec & ,   const gp_Vec & ,  double ,  gp_Dir &  )>(&LProp_SurfaceUtils::ComputeSurfNormal),
          R"#(Check if surface normal is defined, and compute it via CSLib::Normal.)#"  , py::arg("theD1u"),  py::arg("theD1v"),  py::arg("theLinTol"),  py::arg("theNormal")
          );
    mLProp_SurfaceUtils.def("ComputeSurfCurvatures",
          (bool (*)(  const gp_Vec & ,   const gp_Vec & ,   const gp_Vec & ,   const gp_Vec & ,   const gp_Vec & ,   const gp_Dir & ,  double & ,  double & ,  gp_Dir & ,  gp_Dir & ,  double & ,  double &  ))  static_cast<bool (*)(  const gp_Vec & ,   const gp_Vec & ,   const gp_Vec & ,   const gp_Vec & ,   const gp_Vec & ,   const gp_Dir & ,  double & ,  double & ,  gp_Dir & ,  gp_Dir & ,  double & ,  double &  )>(&LProp_SurfaceUtils::ComputeSurfCurvatures),
          R"#(Compute principal curvatures and directions via fundamental forms. Solves the eigenvalue problem for the shape operator using first and second fundamental form coefficients.)#"  , py::arg("theD1u"),  py::arg("theD1v"),  py::arg("theD2u"),  py::arg("theD2v"),  py::arg("theDuv"),  py::arg("theNormal"),  py::arg("theMinCurv"),  py::arg("theMaxCurv"),  py::arg("theDirMin"),  py::arg("theDirMax"),  py::arg("theMeanCurv"),  py::arg("theGausCurv")
          );

// Additional functions


// operators

// register typdefs
    register_template_GeomLProp_CLPropsBase<gp_Pnt, gp_Vec, gp_Dir, occ::handle<Geom_Curve>>(m,"GeomLProp_CLProps");
    register_template_GeomLProp_CLPropsBase<gp_Pnt2d, gp_Vec2d, gp_Dir2d, occ::handle<Geom2d_Curve>>(m,"GeomLProp_CLProps2d");
    register_template_GeomLProp_SLPropsBase<occ::handle<Geom_Surface>>(m,"GeomLProp_SLProps");

// register user-defined template specializations


// exceptions

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
