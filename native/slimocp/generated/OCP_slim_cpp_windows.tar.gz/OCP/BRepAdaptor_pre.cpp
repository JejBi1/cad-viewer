
// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;


// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Geom_BezierCurve.hxx>
#include <Geom_BSplineCurve.hxx>
#include <TopoDS_Face.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Geom_BezierSurface.hxx>
#include <Geom_BSplineSurface.hxx>

// module includes
#include <BRepAdaptor_CompCurve.hxx>
#include <BRepAdaptor_Curve.hxx>
#include <BRepAdaptor_Curve2d.hxx>
#include <BRepAdaptor_Surface.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_BRepAdaptor_enums(py::module &main_module) {


py::module m = main_module.def_submodule("BRepAdaptor", R"#()#");

// add namespaces as submodules

// user-defined inclusion per module in the body

// enums

//Python trampoline classes

// pre-register typdefs+classes (topologically sorted)
    py::class_<BRepAdaptor_CompCurve ,opencascade::handle<BRepAdaptor_CompCurve>  , Adaptor3d_Curve >(
      m,
      "BRepAdaptor_CompCurve",R"#(The Curve from BRepAdaptor allows to use a Wire of the BRep topology like a 3D curve. Warning: With this class of curve, C0 and C1 continuities are not assumed. So be careful with some algorithm! Please note that BRepAdaptor_CompCurve cannot be periodic curve at all (even if it contains single periodic edge).)#"
    );
    py::class_<BRepAdaptor_Curve ,opencascade::handle<BRepAdaptor_Curve>  , GeomAdaptor_TransformedCurve >(
      m,
      "BRepAdaptor_Curve",R"#(The Curve from BRepAdaptor allows to use an Edge of the BRep topology like a 3D curve.)#"
    );
    py::class_<BRepAdaptor_Curve2d ,opencascade::handle<BRepAdaptor_Curve2d>  >(
      m,
      "BRepAdaptor_Curve2d",R"#(The Curve2d from BRepAdaptor allows to use an Edge on a Face like a 2d curve (curve in the parametric space).)#"
    );
    py::class_<BRepAdaptor_Surface ,opencascade::handle<BRepAdaptor_Surface>  , GeomAdaptor_TransformedSurface >(
      m,
      "BRepAdaptor_Surface",R"#(The Surface from BRepAdaptor allows to use a Face of the BRep topology look like a 3D surface.)#"
    );

// preregister user-defined template specializations

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
