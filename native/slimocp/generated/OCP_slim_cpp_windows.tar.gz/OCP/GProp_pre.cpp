
// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;


// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Pnt.hxx>
#include <gp_Mat.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Circ.hxx>
#include <gp_Lin.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Ax1.hxx>
#include <GProp_PrincipalProps.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Pln.hxx>
#include <gp_Lin.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Cylinder.hxx>
#include <gp_Cone.hxx>
#include <gp_Sphere.hxx>
#include <gp_Torus.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Cylinder.hxx>
#include <gp_Cone.hxx>
#include <gp_Sphere.hxx>
#include <gp_Torus.hxx>

// module includes
#include <GProp.hxx>
#include <GProp_CelGProps.hxx>
#include <GProp_GProps.hxx>
#include <GProp_PEquation.hxx>
#include <GProp_PGProps.hxx>
#include <GProp_PrincipalProps.hxx>
#include <GProp_SelGProps.hxx>
#include <GProp_UndefinedAxis.hxx>
#include <GProp_ValueType.hxx>
#include <GProp_VelGProps.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_GProp_enums(py::module &main_module) {


py::module m = main_module.def_submodule("GProp", R"#()#");

// add namespaces as submodules

// user-defined inclusion per module in the body

// enums
    py::enum_<GProp_ValueType>(m, "GProp_ValueType",R"#(Algorithms:)#")
        .value("GProp_Mass",GProp_ValueType::GProp_Mass)
        .value("GProp_CenterMassX",GProp_ValueType::GProp_CenterMassX)
        .value("GProp_CenterMassY",GProp_ValueType::GProp_CenterMassY)
        .value("GProp_CenterMassZ",GProp_ValueType::GProp_CenterMassZ)
        .value("GProp_InertiaXX",GProp_ValueType::GProp_InertiaXX)
        .value("GProp_InertiaYY",GProp_ValueType::GProp_InertiaYY)
        .value("GProp_InertiaZZ",GProp_ValueType::GProp_InertiaZZ)
        .value("GProp_InertiaXY",GProp_ValueType::GProp_InertiaXY)
        .value("GProp_InertiaXZ",GProp_ValueType::GProp_InertiaXZ)
        .value("GProp_InertiaYZ",GProp_ValueType::GProp_InertiaYZ)
        .value("GProp_Unknown",GProp_ValueType::GProp_Unknown).export_values();

//Python trampoline classes

// pre-register typdefs+classes (topologically sorted)
    py::class_<GProp , shared_ptr<GProp>  >(
      m,
      "GProp",R"#(This package defines algorithms to compute the global properties of a set of points, a curve, a surface, a solid (non infinite region of space delimited with geometric entities), a compound geometric system (heterogeneous composition of the previous entities).)#"
    );
    py::class_<GProp_GProps , shared_ptr<GProp_GProps>  >(
      m,
      "GProp_GProps",R"#(Implements a general mechanism to compute the global properties of a "compound geometric system" in 3D space by composition of the global properties of elementary geometric entities such as a curve, surface, solid, or set of points. It is also possible to compose the properties of several "compound geometric systems".)#"
    );
    py::class_<GProp_PEquation , shared_ptr<GProp_PEquation>  >(
      m,
      "GProp_PEquation",R"#(Analyzes a collection of 3D points to decide whether they are coincident, collinear, coplanar, or span 3D space, within a given tolerance.)#"
    );
    py::class_<GProp_PrincipalProps , shared_ptr<GProp_PrincipalProps>  >(
      m,
      "GProp_PrincipalProps",R"#(A framework to present the principal properties of inertia of a system of which global properties are computed by a GProp_GProps object. There is always a set of axes for which the products of inertia of a geometric system are equal to 0; i.e. the matrix of inertia of the system is diagonal. These axes are the principal axes of inertia. Their origin is coincident with the center of mass of the system. The associated moments are called the principal moments of inertia. This sort of presentation object is created, filled and returned by the function PrincipalProperties for any GProp_GProps object, and can be queried to access the result. Note: The system whose principal properties of inertia are returned by this framework is referred to as the current system. The current system, however, is retained neither by this presentation framework nor by the GProp_GProps object which activates it.)#"
    );
    py::class_<GProp_CelGProps , shared_ptr<GProp_CelGProps>  , GProp_GProps >(
      m,
      "GProp_CelGProps",R"#(Computes the global properties of bounded curves in 3D space. Supports elementary curves from the gp package: Lin, Circ, Elips, Parab.)#"
    );
    py::class_<GProp_PGProps , shared_ptr<GProp_PGProps>  , GProp_GProps >(
      m,
      "GProp_PGProps",R"#(Computes global properties (mass, barycentre, inertia matrix) of a weighted set of 3D points.)#"
    );
    py::class_<GProp_SelGProps , shared_ptr<GProp_SelGProps>  , GProp_GProps >(
      m,
      "GProp_SelGProps",R"#(Computes the global properties of a bounded elementary surface in 3D (surfaces from the gp package: Cylinder, Cone, Sphere, Torus).)#"
    );
    py::class_<GProp_VelGProps , shared_ptr<GProp_VelGProps>  , GProp_GProps >(
      m,
      "GProp_VelGProps",R"#(Computes the global properties and the volume of a geometric solid (3D closed region of space). Supports elementary solids from the gp package: Cylinder, Cone, Sphere, Torus.)#"
    );

// preregister user-defined template specializations

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
