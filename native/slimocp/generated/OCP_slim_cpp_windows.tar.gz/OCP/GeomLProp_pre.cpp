
// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;


// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom_Curve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom2d_Curve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>

// module includes
#include <GeomLProp.hxx>
#include <GeomLProp_CLProps.hxx>
#include <GeomLProp_CurAndInf2d.hxx>
#include <GeomLProp_SLProps.hxx>
#include <GeomLProp_SurfaceUtils.hxx>

// template related includes

#include "GeomLProp_tmpl.hxx"

#include "GeomLProp_tmpl.hxx"

#include "GeomLProp_tmpl.hxx"


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_GeomLProp_enums(py::module &main_module) {


py::module m = main_module.def_submodule("GeomLProp", R"#()#");

// add namespaces as submodules
auto LProp_SurfaceUtils = m.def_submodule("LProp_SurfaceUtils");

// user-defined inclusion per module in the body

// enums

//Python trampoline classes

// pre-register typdefs+classes (topologically sorted)
    py::class_<GeomLProp , shared_ptr<GeomLProp>  >(
      m,
      "GeomLProp",R"#(These global functions compute the degree of continuity of a 3D curve built by concatenation of two other curves (or portions of curves) at their junction point.)#"
    );
    py::class_<LProp_SurfaceUtils::DirectAccess , shared_ptr<LProp_SurfaceUtils::DirectAccess>  >(
      LProp_SurfaceUtils,
      "DirectAccess",R"#(Direct access policy: calls D0/D1/D2 methods on the surface object. Works with occ::handle<T> and by-value surface types.)#"
    );
    preregister_template_GeomLProp_CLPropsBase<gp_Pnt, gp_Vec, gp_Dir, occ::handle<Geom_Curve>>(m,"GeomLProp_CLProps");
    preregister_template_GeomLProp_CLPropsBase<gp_Pnt2d, gp_Vec2d, gp_Dir2d, occ::handle<Geom2d_Curve>>(m,"GeomLProp_CLProps2d");
    py::class_<GeomLProp_CurAndInf2d , shared_ptr<GeomLProp_CurAndInf2d>  >(
      m,
      "GeomLProp_CurAndInf2d",R"#(An algorithm for computing local properties of a curve. These properties include: - the maximum and minimum curvatures - the inflection points. A CurAndInf2d object provides the framework for: - defining the curve to be analyzed - implementing the computation algorithms - consulting the results.)#"
    );
    preregister_template_GeomLProp_SLPropsBase<occ::handle<Geom_Surface>>(m,"GeomLProp_SLProps");

// preregister user-defined template specializations

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
