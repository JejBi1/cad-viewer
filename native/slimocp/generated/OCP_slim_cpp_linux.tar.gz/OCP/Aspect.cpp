
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Aspect_DisplayConnection.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Aspect_ScrollDelta.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_ArrayOfTriangles.hxx>
#include <Image_Texture.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <Aspect_AspectFillAreaDefinitionError.hxx>
#include <Aspect_AspectLineDefinitionError.hxx>
#include <Aspect_AspectMarkerDefinitionError.hxx>
#include <Aspect_Background.hxx>
#include <Aspect_CircularGrid.hxx>
#include <Aspect_ColorSpace.hxx>
#include <Aspect_Display.hxx>
#include <Aspect_DisplayConnection.hxx>
#include <Aspect_DisplayConnectionDefinitionError.hxx>
#include <Aspect_Drawable.hxx>
#include <Aspect_Eye.hxx>
#include <Aspect_FBConfig.hxx>
#include <Aspect_FillMethod.hxx>
#include <Aspect_FrustumLRBT.hxx>
#include <Aspect_GenId.hxx>
#include <Aspect_GradientBackground.hxx>
#include <Aspect_GradientFillMethod.hxx>
#include <Aspect_GraphicDeviceDefinitionError.hxx>
#include <Aspect_GraphicsLibrary.hxx>
#include <Aspect_Grid.hxx>
#include <Aspect_GridDrawMode.hxx>
#include <Aspect_GridParams.hxx>
#include <Aspect_GridType.hxx>
#include <Aspect_Handle.hxx>
#include <Aspect_HatchStyle.hxx>
#include <Aspect_IdentDefinitionError.hxx>
#include <Aspect_InteriorStyle.hxx>
#include <Aspect_NeutralWindow.hxx>
#include <Aspect_OpenVRSession.hxx>
#include <Aspect_PolygonOffsetMode.hxx>
#include <Aspect_RectangularGrid.hxx>
#include <Aspect_RenderingContext.hxx>
#include <Aspect_ScrollDelta.hxx>
#include <Aspect_SkydomeBackground.hxx>
#include <Aspect_Touch.hxx>
#include <Aspect_TrackedDevicePose.hxx>
#include <Aspect_TypeOfColorScaleData.hxx>
#include <Aspect_TypeOfColorScaleOrientation.hxx>
#include <Aspect_TypeOfColorScalePosition.hxx>
#include <Aspect_TypeOfDeflection.hxx>
#include <Aspect_TypeOfDisplayText.hxx>
#include <Aspect_TypeOfFacingModel.hxx>
#include <Aspect_TypeOfHighlightMethod.hxx>
#include <Aspect_TypeOfLine.hxx>
#include <Aspect_TypeOfMarker.hxx>
#include <Aspect_TypeOfResize.hxx>
#include <Aspect_TypeOfStyleText.hxx>
#include <Aspect_TypeOfTriedronPosition.hxx>
#include <Aspect_Units.hxx>
#include <Aspect_VKey.hxx>
#include <Aspect_VKeyFlags.hxx>
#include <Aspect_WidthOfLine.hxx>
#include <Aspect_Window.hxx>
#include <Aspect_WindowDefinitionError.hxx>
#include <Aspect_WindowError.hxx>
#include <Aspect_WindowInputListener.hxx>
#include <Aspect_XAtom.hxx>
#include <Aspect_XRAction.hxx>
#include <Aspect_XRActionSet.hxx>
#include <Aspect_XRActionType.hxx>
#include <Aspect_XRAnalogActionData.hxx>
#include <Aspect_XRDigitalActionData.hxx>
#include <Aspect_XRGenericAction.hxx>
#include <Aspect_XRHapticActionData.hxx>
#include <Aspect_XRPoseActionData.hxx>
#include <Aspect_XRSession.hxx>
#include <Aspect_XRTrackedDeviceRole.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module
struct __GLXFBConfigRec {};
struct Aspect_XVisualInfo {};
#include <WNT_HIDSpaceMouse.hxx>


// Module definiiton
void register_Aspect(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("Aspect"));
py::object klass;

// get namespaces as submodules

//Python trampoline classes
    class Py_Aspect_Grid : public Aspect_Grid{
    public:
        using Aspect_Grid::Aspect_Grid;


        // public pure virtual
        void Display() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Grid,Display,) };
        void Erase() const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Grid,Erase,) };
        bool IsDisplayed() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Grid,IsDisplayed,) };
        void Init() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Grid,Init,) };
        void Compute( const double X, const double Y,double & gridX,double & gridY) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Grid,Compute,X,Y,gridX,gridY) };


        // protected pure virtual
        void UpdateDisplay() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Grid,UpdateDisplay,) };


        // private pure virtual

    };
    class Py_Aspect_Window : public Aspect_Window{
    public:
        using Aspect_Window::Aspect_Window;


        // public pure virtual
        bool IsMapped() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Window,IsMapped,) };
        void Map() const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Window,Map,) };
        void Unmap() const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Window,Unmap,) };
        Aspect_TypeOfResize DoResize() override { using return_type = Aspect_TypeOfResize;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Window,DoResize,) };
        bool DoMapping() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Window,DoMapping,) };
        double Ratio() const  override { using return_type = double;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Window,Ratio,) };
        Aspect_Drawable NativeHandle() const  override { using return_type = Aspect_Drawable;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Window,NativeHandle,) };
        Aspect_Drawable NativeParentHandle() const  override { using return_type = Aspect_Drawable;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Window,NativeParentHandle,) };
        void Position(int & X1,int & Y1,int & X2,int & Y2) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Window,Position,X1,Y1,X2,Y2) };
        void Size(int & Width,int & Height) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Window,Size,Width,Height) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_Aspect_WindowInputListener : public Aspect_WindowInputListener{
    public:
        using Aspect_WindowInputListener::Aspect_WindowInputListener;


        // public pure virtual
        void ProcessExpose() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_WindowInputListener,ProcessExpose,) };
        void ProcessConfigure(bool theIsResized) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_WindowInputListener,ProcessConfigure,theIsResized) };
        void ProcessInput() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_WindowInputListener,ProcessInput,) };
        void ProcessFocus(bool theIsActivated) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_WindowInputListener,ProcessFocus,theIsActivated) };
        void ProcessClose() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_WindowInputListener,ProcessClose,) };
        void KeyDown(Aspect_VKey theKey,double theTime,double thePressure) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_WindowInputListener,KeyDown,theKey,theTime,thePressure) };
        void KeyUp(Aspect_VKey theKey,double theTime) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_WindowInputListener,KeyUp,theKey,theTime) };
        void KeyFromAxis(Aspect_VKey theNegative,Aspect_VKey thePositive,double theTime,double thePressure) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_WindowInputListener,KeyFromAxis,theNegative,thePositive,theTime,thePressure) };
        bool UpdateMouseScroll( const Aspect_ScrollDelta & theDelta) override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_WindowInputListener,UpdateMouseScroll,theDelta) };
        bool UpdateMouseButtons( const NCollection_Vec2<int> & thePoint,Aspect_VKeyMouse theButtons,Aspect_VKeyFlags theModifiers,bool theIsEmulated) override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_WindowInputListener,UpdateMouseButtons,thePoint,theButtons,theModifiers,theIsEmulated) };
        bool UpdateMousePosition( const NCollection_Vec2<int> & thePoint,Aspect_VKeyMouse theButtons,Aspect_VKeyFlags theModifiers,bool theIsEmulated) override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_WindowInputListener,UpdateMousePosition,thePoint,theButtons,theModifiers,theIsEmulated) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_Aspect_XRSession : public Aspect_XRSession{
    public:
        using Aspect_XRSession::Aspect_XRSession;


        // public pure virtual
        bool IsOpen() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,IsOpen,) };
        bool Open() override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,Open,) };
        void Close() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,Close,) };
        bool WaitPoses() override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,WaitPoses,) };
        NCollection_Vec2<int> RecommendedViewport() const  override { using return_type = NCollection_Vec2<int>;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,RecommendedViewport,) };
        NCollection_Mat4<double> EyeToHeadTransform(Aspect_Eye theEye) const  override { using return_type = NCollection_Mat4<double>;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,EyeToHeadTransform,theEye) };
        NCollection_Mat4<double> ProjectionMatrix(Aspect_Eye theEye,double theZNear,double theZFar) const  override { using return_type = NCollection_Mat4<double>;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,ProjectionMatrix,theEye,theZNear,theZFar) };
        bool HasProjectionFrustums() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,HasProjectionFrustums,) };
        void ProcessEvents() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,ProcessEvents,) };
        bool SubmitEye(void * theTexture,Aspect_GraphicsLibrary theGraphicsLib,Aspect_ColorSpace theColorSpace,Aspect_Eye theEye) override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,SubmitEye,theTexture,theGraphicsLib,theColorSpace,theEye) };
        int NamedTrackedDevice(Aspect_XRTrackedDeviceRole theDevice) const  override { using return_type = int;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,NamedTrackedDevice,theDevice) };
        Aspect_XRDigitalActionData GetDigitalActionData( const handle<Aspect_XRAction> & theAction) const  override { using return_type = Aspect_XRDigitalActionData;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,GetDigitalActionData,theAction) };
        Aspect_XRAnalogActionData GetAnalogActionData( const handle<Aspect_XRAction> & theAction) const  override { using return_type = Aspect_XRAnalogActionData;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,GetAnalogActionData,theAction) };
        Aspect_XRPoseActionData GetPoseActionDataForNextFrame( const handle<Aspect_XRAction> & theAction) const  override { using return_type = Aspect_XRPoseActionData;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,GetPoseActionDataForNextFrame,theAction) };
        TCollection_AsciiString GetString(Aspect_XRSession::InfoString theInfo) const  override { using return_type = TCollection_AsciiString;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,GetString,theInfo) };


        // protected pure virtual
        handle<Graphic3d_ArrayOfTriangles> loadRenderModel(int theDevice,bool theToApplyUnitFactor,handle<Image_Texture> & theTexture) override { using return_type = handle<Graphic3d_ArrayOfTriangles>;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,loadRenderModel,theDevice,theToApplyUnitFactor,theTexture) };
        void triggerHapticVibrationAction( const handle<Aspect_XRAction> & theAction, const Aspect_XRHapticActionData & theParams) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_XRSession,triggerHapticVibrationAction,theAction,theParams) };


        // private pure virtual

    };
    class Py_Aspect_CircularGrid : public Aspect_CircularGrid{
    public:
        using Aspect_CircularGrid::Aspect_CircularGrid;


        // public pure virtual

        void Display() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Grid,Display,) };
        void Erase() const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Grid,Erase,) };
        bool IsDisplayed() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Grid,IsDisplayed,) };

        // protected pure virtual

        void UpdateDisplay() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Grid,UpdateDisplay,) };

        // private pure virtual

    };
    class Py_Aspect_RectangularGrid : public Aspect_RectangularGrid{
    public:
        using Aspect_RectangularGrid::Aspect_RectangularGrid;


        // public pure virtual

        void Display() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Grid,Display,) };
        void Erase() const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Grid,Erase,) };
        bool IsDisplayed() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Grid,IsDisplayed,) };

        // protected pure virtual

        void UpdateDisplay() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Aspect_Grid,UpdateDisplay,) };

        // private pure virtual

    };

// classes

    // Class Aspect_Background from ./opencascade/Aspect_Background.hxx
    klass = m.attr("Aspect_Background");


    // nested enums

    static_cast<py::class_<Aspect_Background , shared_ptr<Aspect_Background>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const Quantity_Color & >()  , py::arg("AColor") )
    // custom constructors
    // methods
        .def("SetColor",
             (void (Aspect_Background::*)(  const Quantity_Color &  ) ) static_cast<void (Aspect_Background::*)(  const Quantity_Color &  ) >(&Aspect_Background::SetColor),
             R"#(Modifies the colour of the window background <me>.)#"  , py::arg("AColor")
          )
        .def("Color",
             (Quantity_Color (Aspect_Background::*)() const) static_cast<Quantity_Color (Aspect_Background::*)() const>(&Aspect_Background::Color),
             R"#(Returns the colour of the window background <me>.)#" 
          )
        .def("DumpJson",
             (void (Aspect_Background::*)( Standard_OStream & ,  int  ) const) static_cast<void (Aspect_Background::*)( Standard_OStream & ,  int  ) const>(&Aspect_Background::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Aspect_DisplayConnection from ./opencascade/Aspect_DisplayConnection.hxx
    klass = m.attr("Aspect_DisplayConnection");


    // nested enums

    static_cast<py::class_<Aspect_DisplayConnection ,opencascade::handle<Aspect_DisplayConnection>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const TCollection_AsciiString & >()  , py::arg("theDisplayName") )
    // custom constructors
    // methods
        .def("IsOwnDisplay",
             (bool (Aspect_DisplayConnection::*)() const) static_cast<bool (Aspect_DisplayConnection::*)() const>(&Aspect_DisplayConnection::IsOwnDisplay),
             R"#(Returns TRUE if X Display has been allocated by this class)#" 
          )
        .def("GetAtom",
             (uint64_t (Aspect_DisplayConnection::*)(  const Aspect_XAtom  ) const) static_cast<uint64_t (Aspect_DisplayConnection::*)(  const Aspect_XAtom  ) const>(&Aspect_DisplayConnection::GetAtom),
             R"#(Returns identifier(atom) for custom named property associated with windows that use current connection to X server.)#"  , py::arg("theAtom")
          )
        .def("GetDefaultVisualInfo",
             (Aspect_XVisualInfo * (Aspect_DisplayConnection::*)() const) static_cast<Aspect_XVisualInfo * (Aspect_DisplayConnection::*)() const>(&Aspect_DisplayConnection::GetDefaultVisualInfo),
             R"#(Return default window visual or NULL when undefined.)#" 
          )
        .def("GetDefaultFBConfig",
             (Aspect_FBConfig (Aspect_DisplayConnection::*)() const) static_cast<Aspect_FBConfig (Aspect_DisplayConnection::*)() const>(&Aspect_DisplayConnection::GetDefaultFBConfig),
             R"#(Returns native Window FB config (GLXFBConfig on Xlib))#" 
          )
        .def("SetDefaultVisualInfo",
             (void (Aspect_DisplayConnection::*)( Aspect_XVisualInfo * ,  Aspect_FBConfig  ) ) static_cast<void (Aspect_DisplayConnection::*)( Aspect_XVisualInfo * ,  Aspect_FBConfig  ) >(&Aspect_DisplayConnection::SetDefaultVisualInfo),
             R"#(Set default window visual; the visual will be deallocated using XFree().)#"  , py::arg("theVisual"),  py::arg("theFBConfig")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&Aspect_DisplayConnection::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&Aspect_DisplayConnection::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (Aspect_DisplayConnection::*)() const) static_cast< const handle<Standard_Type> & (Aspect_DisplayConnection::*)() const>(&Aspect_DisplayConnection::DynamicType),
             R"#()#"
             
         )
;

    // Class Aspect_GenId from ./opencascade/Aspect_GenId.hxx
    klass = m.attr("Aspect_GenId");


    // nested enums

    static_cast<py::class_<Aspect_GenId , shared_ptr<Aspect_GenId>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const int, const int >()  , py::arg("theLow"),  py::arg("theUpper") )
    // custom constructors
    // methods
        .def("Free",
             (void (Aspect_GenId::*)() ) static_cast<void (Aspect_GenId::*)() >(&Aspect_GenId::Free),
             R"#(Free all identifiers - make the whole range available again.)#" 
          )
        .def("Free",
             (void (Aspect_GenId::*)(  const int  ) ) static_cast<void (Aspect_GenId::*)(  const int  ) >(&Aspect_GenId::Free),
             R"#(Free specified identifier. Warning - method has no protection against double-freeing!)#"  , py::arg("theId")
          )
        .def("HasFree",
             (bool (Aspect_GenId::*)() const) static_cast<bool (Aspect_GenId::*)() const>(&Aspect_GenId::HasFree),
             R"#(Returns true if there are available identifiers in range.)#" 
          )
        .def("Available",
             (int (Aspect_GenId::*)() const) static_cast<int (Aspect_GenId::*)() const>(&Aspect_GenId::Available),
             R"#(Returns the number of available identifiers.)#" 
          )
        .def("Lower",
             (int (Aspect_GenId::*)() const) static_cast<int (Aspect_GenId::*)() const>(&Aspect_GenId::Lower),
             R"#(Returns the lower identifier in range.)#" 
          )
        .def("Next",
             (int (Aspect_GenId::*)() ) static_cast<int (Aspect_GenId::*)() >(&Aspect_GenId::Next),
             R"#(Returns the next available identifier. Warning: Raises IdentDefinitionError if all identifiers are busy.)#" 
          )
        .def("Next",
             (bool (Aspect_GenId::*)( int &  ) ) static_cast<bool (Aspect_GenId::*)( int &  ) >(&Aspect_GenId::Next),
             R"#(Generates the next available identifier.)#"  , py::arg("theId")
          )
        .def("Upper",
             (int (Aspect_GenId::*)() const) static_cast<int (Aspect_GenId::*)() const>(&Aspect_GenId::Upper),
             R"#(Returns the upper identifier in range.)#" 
          )
        .def("DumpJson",
             (void (Aspect_GenId::*)( Standard_OStream & ,  int  ) const) static_cast<void (Aspect_GenId::*)( Standard_OStream & ,  int  ) const>(&Aspect_GenId::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Aspect_Grid from ./opencascade/Aspect_Grid.hxx
    klass = m.attr("Aspect_Grid");


    // nested enums

    static_cast<py::class_<Aspect_Grid ,opencascade::handle<Aspect_Grid> ,Py_Aspect_Grid , Standard_Transient >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("SetXOrigin",
             (void (Aspect_Grid::*)(  const double  ) ) static_cast<void (Aspect_Grid::*)(  const double  ) >(&Aspect_Grid::SetXOrigin),
             R"#(defines the x Origin of the grid.)#"  , py::arg("anOrigin")
          )
        .def("SetYOrigin",
             (void (Aspect_Grid::*)(  const double  ) ) static_cast<void (Aspect_Grid::*)(  const double  ) >(&Aspect_Grid::SetYOrigin),
             R"#(defines the y Origin of the grid.)#"  , py::arg("anOrigin")
          )
        .def("SetRotationAngle",
             (void (Aspect_Grid::*)(  const double  ) ) static_cast<void (Aspect_Grid::*)(  const double  ) >(&Aspect_Grid::SetRotationAngle),
             R"#(defines the orientation of the grid.)#"  , py::arg("anAngle")
          )
        .def("Rotate",
             (void (Aspect_Grid::*)(  const double  ) ) static_cast<void (Aspect_Grid::*)(  const double  ) >(&Aspect_Grid::Rotate),
             R"#(Rotate the grid from a relative angle.)#"  , py::arg("anAngle")
          )
        .def("Translate",
             (void (Aspect_Grid::*)(  const double ,   const double  ) ) static_cast<void (Aspect_Grid::*)(  const double ,   const double  ) >(&Aspect_Grid::Translate),
             R"#(Translate the grid from a relative distance.)#"  , py::arg("aDx"),  py::arg("aDy")
          )
        .def("SetColors",
             (void (Aspect_Grid::*)(  const Quantity_Color & ,   const Quantity_Color &  ) ) static_cast<void (Aspect_Grid::*)(  const Quantity_Color & ,   const Quantity_Color &  ) >(&Aspect_Grid::SetColors),
             R"#(Change the colors of the grid)#"  , py::arg("aColor"),  py::arg("aTenthColor")
          )
        .def("Activate",
             (void (Aspect_Grid::*)() ) static_cast<void (Aspect_Grid::*)() >(&Aspect_Grid::Activate),
             R"#(activates the grid. The Hit method will return gridx and gridx computed according to the steps of the grid.)#" 
          )
        .def("Deactivate",
             (void (Aspect_Grid::*)() ) static_cast<void (Aspect_Grid::*)() >(&Aspect_Grid::Deactivate),
             R"#(deactivates the grid. The hit method will return gridx and gridx as the enter value X & Y.)#" 
          )
        .def("XOrigin",
             (double (Aspect_Grid::*)() const) static_cast<double (Aspect_Grid::*)() const>(&Aspect_Grid::XOrigin),
             R"#(returns the x Origin of the grid.)#" 
          )
        .def("YOrigin",
             (double (Aspect_Grid::*)() const) static_cast<double (Aspect_Grid::*)() const>(&Aspect_Grid::YOrigin),
             R"#(returns the x Origin of the grid.)#" 
          )
        .def("RotationAngle",
             (double (Aspect_Grid::*)() const) static_cast<double (Aspect_Grid::*)() const>(&Aspect_Grid::RotationAngle),
             R"#(returns the x Angle of the grid.)#" 
          )
        .def("IsActive",
             (bool (Aspect_Grid::*)() const) static_cast<bool (Aspect_Grid::*)() const>(&Aspect_Grid::IsActive),
             R"#(Returns TRUE when the grid is active.)#" 
          )
        .def("Colors",
             (void (Aspect_Grid::*)( Quantity_Color & ,  Quantity_Color &  ) const) static_cast<void (Aspect_Grid::*)( Quantity_Color & ,  Quantity_Color &  ) const>(&Aspect_Grid::Colors),
             R"#(Returns the colors of the grid.)#"  , py::arg("aColor"),  py::arg("aTenthColor")
          )
        .def("SetDrawMode",
             (void (Aspect_Grid::*)(  const Aspect_GridDrawMode  ) ) static_cast<void (Aspect_Grid::*)(  const Aspect_GridDrawMode  ) >(&Aspect_Grid::SetDrawMode),
             R"#(Change the grid aspect.)#"  , py::arg("aDrawMode")
          )
        .def("DrawMode",
             (Aspect_GridDrawMode (Aspect_Grid::*)() const) static_cast<Aspect_GridDrawMode (Aspect_Grid::*)() const>(&Aspect_Grid::DrawMode),
             R"#(Returns the grid aspect.)#" 
          )
        .def("Display",
             (void (Aspect_Grid::*)() ) static_cast<void (Aspect_Grid::*)() >(&Aspect_Grid::Display),
             R"#(Display the grid at screen.)#" 
          )
        .def("Erase",
             (void (Aspect_Grid::*)() const) static_cast<void (Aspect_Grid::*)() const>(&Aspect_Grid::Erase),
             R"#(Erase the grid from screen.)#" 
          )
        .def("IsDisplayed",
             (bool (Aspect_Grid::*)() const) static_cast<bool (Aspect_Grid::*)() const>(&Aspect_Grid::IsDisplayed),
             R"#(Returns TRUE when the grid is displayed at screen.)#" 
          )
        .def("Init",
             (void (Aspect_Grid::*)() ) static_cast<void (Aspect_Grid::*)() >(&Aspect_Grid::Init),
             R"#()#" 
          )
        .def("DumpJson",
             (void (Aspect_Grid::*)( Standard_OStream & ,  int  ) const) static_cast<void (Aspect_Grid::*)( Standard_OStream & ,  int  ) const>(&Aspect_Grid::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
        .def("Hit",
             []( Aspect_Grid &self ,  const double X, const double Y ){
                 double  gridX;
                double  gridY;

                 self.Hit(X,Y,gridX,gridY);
                 return std::make_tuple(gridX,gridY); },
             R"#(returns the point of the grid the closest to the point X,Y if the grid is active. If the grid is not active returns X,Y.)#"  , py::arg("X"),  py::arg("Y")
          )
        .def("Compute",
             []( Aspect_Grid &self ,  const double X, const double Y ){
                 double  gridX;
                double  gridY;

                 self.Compute(X,Y,gridX,gridY);
                 return std::make_tuple(gridX,gridY); },
             R"#(returns the point of the grid the closest to the point X,Y)#"  , py::arg("X"),  py::arg("Y")
          )
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&Aspect_Grid::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&Aspect_Grid::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (Aspect_Grid::*)() const) static_cast< const handle<Standard_Type> & (Aspect_Grid::*)() const>(&Aspect_Grid::DynamicType),
             R"#()#"
             
         )
;

    // Class Aspect_GridParams from ./opencascade/Aspect_GridParams.hxx
    klass = m.attr("Aspect_GridParams");


    // nested enums

    static_cast<py::class_<Aspect_GridParams , shared_ptr<Aspect_GridParams>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("SetColor",
             (void (Aspect_GridParams::*)(  const Quantity_Color &  ) ) static_cast<void (Aspect_GridParams::*)(  const Quantity_Color &  ) >(&Aspect_GridParams::SetColor),
             R"#(Set grid line color.)#"  , py::arg("theColor")
          )
        .def("SetOrigin",
             (void (Aspect_GridParams::*)(  const gp_Pnt &  ) ) static_cast<void (Aspect_GridParams::*)(  const gp_Pnt &  ) >(&Aspect_GridParams::SetOrigin),
             R"#(Set local offset of the grid origin within the plane.)#"  , py::arg("theOrigin")
          )
        .def("SetAccentColor",
             (void (Aspect_GridParams::*)(  const Quantity_Color &  ) ) static_cast<void (Aspect_GridParams::*)(  const Quantity_Color &  ) >(&Aspect_GridParams::SetAccentColor),
             R"#(Set every-tenth-line / accent colour rendered by the shader.)#"  , py::arg("theColor")
          )
        .def("AccentScaleX",
             (double (Aspect_GridParams::*)() const) static_cast<double (Aspect_GridParams::*)() const>(&Aspect_GridParams::AccentScaleX),
             R"#(Return accent overlay scale along the plane X/radial direction. Zero disables the accent layer on that axis.)#" 
          )
        .def("SetAccentScaleX",
             (void (Aspect_GridParams::*)(  const double  ) ) static_cast<void (Aspect_GridParams::*)(  const double  ) >(&Aspect_GridParams::SetAccentScaleX),
             R"#(Set accent overlay scale along the plane X/radial direction.)#"  , py::arg("theScale")
          )
        .def("AccentScaleY",
             (double (Aspect_GridParams::*)() const) static_cast<double (Aspect_GridParams::*)() const>(&Aspect_GridParams::AccentScaleY),
             R"#(Return accent overlay scale along the plane Y direction. Zero disables the accent layer on that axis.)#" 
          )
        .def("SetAccentScaleY",
             (void (Aspect_GridParams::*)(  const double  ) ) static_cast<void (Aspect_GridParams::*)(  const double  ) >(&Aspect_GridParams::SetAccentScaleY),
             R"#(Set accent overlay scale along the plane Y direction.)#"  , py::arg("theScale")
          )
        .def("AccentAngularScale",
             (double (Aspect_GridParams::*)() const) static_cast<double (Aspect_GridParams::*)() const>(&Aspect_GridParams::AccentAngularScale),
             R"#(Return accent overlay angular scale for circular-grid spokes. Zero disables the angular accent layer.)#" 
          )
        .def("SetAccentAngularScale",
             (void (Aspect_GridParams::*)(  const double  ) ) static_cast<void (Aspect_GridParams::*)(  const double  ) >(&Aspect_GridParams::SetAccentAngularScale),
             R"#(Set accent overlay angular scale for circular-grid spokes.)#"  , py::arg("theScale")
          )
        .def("Scale",
             (double (Aspect_GridParams::*)() const) static_cast<double (Aspect_GridParams::*)() const>(&Aspect_GridParams::Scale),
             R"#(Return major-grid scale factor along the plane X direction (cells per plane unit).)#" 
          )
        .def("SetScale",
             (void (Aspect_GridParams::*)(  const double  ) ) static_cast<void (Aspect_GridParams::*)(  const double  ) >(&Aspect_GridParams::SetScale),
             R"#(Set major-grid scale factor along the plane X direction (cells per plane unit). Must be non-negative; zero is a valid "unused" sentinel.)#"  , py::arg("theScale")
          )
        .def("ScaleY",
             (double (Aspect_GridParams::*)() const) static_cast<double (Aspect_GridParams::*)() const>(&Aspect_GridParams::ScaleY),
             R"#(Return explicit Y-direction scale. When 0.0, renderer falls back to Scale() (isotropic).)#" 
          )
        .def("SetScaleY",
             (void (Aspect_GridParams::*)(  const double  ) ) static_cast<void (Aspect_GridParams::*)(  const double  ) >(&Aspect_GridParams::SetScaleY),
             R"#(Set explicit Y-direction scale. Pass 0.0 to mirror Scale() (isotropic, default).)#"  , py::arg("theScaleY")
          )
        .def("EffectiveScaleY",
             (double (Aspect_GridParams::*)() const) static_cast<double (Aspect_GridParams::*)() const>(&Aspect_GridParams::EffectiveScaleY),
             R"#(Effective Y-direction scale actually consumed by the renderer.)#" 
          )
        .def("LineThickness",
             (double (Aspect_GridParams::*)() const) static_cast<double (Aspect_GridParams::*)() const>(&Aspect_GridParams::LineThickness),
             R"#(Return line thickness in plane units (minimum pixel-space line width is derived from fwidth).)#" 
          )
        .def("SetLineThickness",
             (void (Aspect_GridParams::*)(  const double  ) ) static_cast<void (Aspect_GridParams::*)(  const double  ) >(&Aspect_GridParams::SetLineThickness),
             R"#(Set line thickness in plane units.)#"  , py::arg("theThickness")
          )
        .def("RotationAngle",
             (double (Aspect_GridParams::*)() const) static_cast<double (Aspect_GridParams::*)() const>(&Aspect_GridParams::RotationAngle),
             R"#(Return in-plane rotation angle (radians) applied to the grid axes around the plane normal.)#" 
          )
        .def("SetRotationAngle",
             (void (Aspect_GridParams::*)(  const double  ) ) static_cast<void (Aspect_GridParams::*)(  const double  ) >(&Aspect_GridParams::SetRotationAngle),
             R"#(Set in-plane rotation angle (radians) applied to the grid axes around the plane normal.)#"  , py::arg("theAngle")
          )
        .def("AngularDivisions",
             (int (Aspect_GridParams::*)() const) static_cast<int (Aspect_GridParams::*)() const>(&Aspect_GridParams::AngularDivisions),
             R"#(Return the angular subdivision count of the half-circle for circular grids. Zero means rectangular grid (default); any positive value switches the renderer to polar rings (Scale -> radial step) and spokes at pi/N rad.)#" 
          )
        .def("SetAngularDivisions",
             (void (Aspect_GridParams::*)(  const int  ) ) static_cast<void (Aspect_GridParams::*)(  const int  ) >(&Aspect_GridParams::SetAngularDivisions),
             R"#(Set angular subdivision count (0 = rectangular grid, N>0 = circular with N spokes per 180 deg).)#"  , py::arg("theDivisions")
          )
        .def("IsCircular",
             (bool (Aspect_GridParams::*)() const) static_cast<bool (Aspect_GridParams::*)() const>(&Aspect_GridParams::IsCircular),
             R"#(Return TRUE when the parameters describe a circular (polar) grid.)#" 
          )
        .def("SizeX",
             (double (Aspect_GridParams::*)() const) static_cast<double (Aspect_GridParams::*)() const>(&Aspect_GridParams::SizeX),
             R"#(Return rectangular bounded extent along plane X; 0.0 means unbounded.)#" 
          )
        .def("SetSizeX",
             (void (Aspect_GridParams::*)(  const double  ) ) static_cast<void (Aspect_GridParams::*)(  const double  ) >(&Aspect_GridParams::SetSizeX),
             R"#(Set rectangular bounded extent along plane X; 0.0 means unbounded.)#"  , py::arg("theSize")
          )
        .def("SizeY",
             (double (Aspect_GridParams::*)() const) static_cast<double (Aspect_GridParams::*)() const>(&Aspect_GridParams::SizeY),
             R"#(Return rectangular bounded extent along plane Y; 0.0 means unbounded.)#" 
          )
        .def("SetSizeY",
             (void (Aspect_GridParams::*)(  const double  ) ) static_cast<void (Aspect_GridParams::*)(  const double  ) >(&Aspect_GridParams::SetSizeY),
             R"#(Set rectangular bounded extent along plane Y; 0.0 means unbounded.)#"  , py::arg("theSize")
          )
        .def("Radius",
             (double (Aspect_GridParams::*)() const) static_cast<double (Aspect_GridParams::*)() const>(&Aspect_GridParams::Radius),
             R"#(Return circular bounded radius; 0.0 means unbounded.)#" 
          )
        .def("SetRadius",
             (void (Aspect_GridParams::*)(  const double  ) ) static_cast<void (Aspect_GridParams::*)(  const double  ) >(&Aspect_GridParams::SetRadius),
             R"#(Set circular bounded radius; 0.0 means unbounded.)#"  , py::arg("theRadius")
          )
        .def("ZOffset",
             (double (Aspect_GridParams::*)() const) static_cast<double (Aspect_GridParams::*)() const>(&Aspect_GridParams::ZOffset),
             R"#(Return signed plane-normal offset applied at render time.)#" 
          )
        .def("SetZOffset",
             (void (Aspect_GridParams::*)(  const double  ) ) static_cast<void (Aspect_GridParams::*)(  const double  ) >(&Aspect_GridParams::SetZOffset),
             R"#(Set signed plane-normal offset applied at render and echo time.)#"  , py::arg("theOffset")
          )
        .def("AngleStart",
             (double (Aspect_GridParams::*)() const) static_cast<double (Aspect_GridParams::*)() const>(&Aspect_GridParams::AngleStart),
             R"#(Return arc start angle (radians). Meaningful only when IsArc() is true.)#" 
          )
        .def("AngleEnd",
             (double (Aspect_GridParams::*)() const) static_cast<double (Aspect_GridParams::*)() const>(&Aspect_GridParams::AngleEnd),
             R"#(Return arc end angle (radians). Meaningful only when IsArc() is true.)#" 
          )
        .def("SetArcRange",
             (void (Aspect_GridParams::*)(  const double ,   const double  ) ) static_cast<void (Aspect_GridParams::*)(  const double ,   const double  ) >(&Aspect_GridParams::SetArcRange),
             R"#(Restrict the circular grid to an angular wedge [start, end], walking CCW. Equal start and end (e.g. 0.0 and 0.0) returns to full-circle rendering.)#"  , py::arg("theStart"),  py::arg("theEnd")
          )
        .def("IsBounded",
             (bool (Aspect_GridParams::*)() const) static_cast<bool (Aspect_GridParams::*)() const>(&Aspect_GridParams::IsBounded),
             R"#(Return TRUE when the parameters describe a bounded rectangle or disc.)#" 
          )
        .def("IsArc",
             (bool (Aspect_GridParams::*)() const) static_cast<bool (Aspect_GridParams::*)() const>(&Aspect_GridParams::IsArc),
             R"#(Return TRUE when the circular grid is restricted to a sub-arc.)#" 
          )
        .def("DrawMode",
             (Aspect_GridDrawMode (Aspect_GridParams::*)() const) static_cast<Aspect_GridDrawMode (Aspect_GridParams::*)() const>(&Aspect_GridParams::DrawMode),
             R"#(Return draw mode: lines, points at grid intersections, or none.)#" 
          )
        .def("SetDrawMode",
             (void (Aspect_GridParams::*)(  const Aspect_GridDrawMode  ) ) static_cast<void (Aspect_GridParams::*)(  const Aspect_GridDrawMode  ) >(&Aspect_GridParams::SetDrawMode),
             R"#(Set draw mode. Aspect_GDM_None suppresses rendering entirely; Points draws dots at grid-line intersections, Lines (default) draws the full grid.)#"  , py::arg("theMode")
          )
        .def("IsBackground",
             (bool (Aspect_GridParams::*)() const) static_cast<bool (Aspect_GridParams::*)() const>(&Aspect_GridParams::IsBackground),
             R"#(Return TRUE if grid is drawn as a view-space background (behind all geometry).)#" 
          )
        .def("SetIsBackground",
             (void (Aspect_GridParams::*)(  const bool  ) ) static_cast<void (Aspect_GridParams::*)(  const bool  ) >(&Aspect_GridParams::SetIsBackground),
             R"#(Set background-mode rendering on/off.)#"  , py::arg("theIsBackground")
          )
        .def("IsDrawAxis",
             (bool (Aspect_GridParams::*)() const) static_cast<bool (Aspect_GridParams::*)() const>(&Aspect_GridParams::IsDrawAxis),
             R"#(Return TRUE if axis lines on the grid plane are drawn in red/green/blue.)#" 
          )
        .def("SetIsDrawAxis",
             (void (Aspect_GridParams::*)(  const bool  ) ) static_cast<void (Aspect_GridParams::*)(  const bool  ) >(&Aspect_GridParams::SetIsDrawAxis),
             R"#(Set axis coloring on/off.)#"  , py::arg("theIsDrawAxis")
          )
        .def("IsViewAdaptive",
             (bool (Aspect_GridParams::*)() const) static_cast<bool (Aspect_GridParams::*)() const>(&Aspect_GridParams::IsViewAdaptive),
             R"#(Return TRUE if grid spacing and visible extents adapt to the camera view.)#" 
          )
        .def("SetIsViewAdaptive",
             (void (Aspect_GridParams::*)(  const bool  ) ) static_cast<void (Aspect_GridParams::*)(  const bool  ) >(&Aspect_GridParams::SetIsViewAdaptive),
             R"#(Set view-adaptive grid on/off. When enabled, shader renderer keeps the screen-space grid step stable by scaling the cell spacing with camera zoom.)#"  , py::arg("theIsViewAdaptive")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Color",
             ( const Quantity_Color & (Aspect_GridParams::*)() const) static_cast< const Quantity_Color & (Aspect_GridParams::*)() const>(&Aspect_GridParams::Color),
             R"#(Return grid line color.)#"
             
         )
       .def("Origin",
             ( const gp_Pnt & (Aspect_GridParams::*)() const) static_cast< const gp_Pnt & (Aspect_GridParams::*)() const>(&Aspect_GridParams::Origin),
             R"#(Return local offset of the grid origin within the plane.)#"
             
         )
       .def("AccentColor",
             ( const Quantity_Color & (Aspect_GridParams::*)() const) static_cast< const Quantity_Color & (Aspect_GridParams::*)() const>(&Aspect_GridParams::AccentColor),
             R"#(Return every-tenth-line / accent colour rendered by the shader.)#"
             
         )
;

    // Class Aspect_ScrollDelta from ./opencascade/Aspect_ScrollDelta.hxx
    klass = m.attr("Aspect_ScrollDelta");


    // nested enums

    static_cast<py::class_<Aspect_ScrollDelta , shared_ptr<Aspect_ScrollDelta>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const NCollection_Vec2<int> &,double,Aspect_VKeyFlags >()  , py::arg("thePnt"),  py::arg("theValue"),  py::arg("theFlags")=static_cast<Aspect_VKeyFlags>(Aspect_VKeyFlags_NONE) )
        .def(py::init< double,Aspect_VKeyFlags >()  , py::arg("theValue"),  py::arg("theFlags")=static_cast<Aspect_VKeyFlags>(Aspect_VKeyFlags_NONE) )
    // custom constructors
    // methods
        .def("HasPoint",
             (bool (Aspect_ScrollDelta::*)() const) static_cast<bool (Aspect_ScrollDelta::*)() const>(&Aspect_ScrollDelta::HasPoint),
             R"#(Return true if action has point defined.)#" 
          )
        .def("ResetPoint",
             (void (Aspect_ScrollDelta::*)() ) static_cast<void (Aspect_ScrollDelta::*)() >(&Aspect_ScrollDelta::ResetPoint),
             R"#(Reset at point.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
        .def_readwrite("Delta", &Aspect_ScrollDelta::Delta)
    // methods returning by ref wrapped as properties
;

    // Class Aspect_SkydomeBackground from ./opencascade/Aspect_SkydomeBackground.hxx
    klass = m.attr("Aspect_SkydomeBackground");


    // nested enums

    static_cast<py::class_<Aspect_SkydomeBackground , shared_ptr<Aspect_SkydomeBackground>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const gp_Dir &,float,float,float,int >()  , py::arg("theSunDirection"),  py::arg("theCloudiness"),  py::arg("theTime"),  py::arg("theFogginess"),  py::arg("theSize") )
    // custom constructors
    // methods
        .def("Cloudiness",
             (float (Aspect_SkydomeBackground::*)() const) static_cast<float (Aspect_SkydomeBackground::*)() const>(&Aspect_SkydomeBackground::Cloudiness),
             R"#(Get cloud intensity. By default this value is 0.2 0.0 means no clouds at all and 1.0 - high clody.)#" 
          )
        .def("TimeParameter",
             (float (Aspect_SkydomeBackground::*)() const) static_cast<float (Aspect_SkydomeBackground::*)() const>(&Aspect_SkydomeBackground::TimeParameter),
             R"#(Get time of cloud simulation. By default this value is 0.0 This value might be tweaked to slightly change appearance of clouds.)#" 
          )
        .def("Fogginess",
             (float (Aspect_SkydomeBackground::*)() const) static_cast<float (Aspect_SkydomeBackground::*)() const>(&Aspect_SkydomeBackground::Fogginess),
             R"#(Get fog intensity. By default this value is 0.0 0.0 means no fog and 1.0 - high fogginess)#" 
          )
        .def("Size",
             (int (Aspect_SkydomeBackground::*)() const) static_cast<int (Aspect_SkydomeBackground::*)() const>(&Aspect_SkydomeBackground::Size),
             R"#(Get size of cubemap. By default this value is 512)#" 
          )
        .def("SetSunDirection",
             (void (Aspect_SkydomeBackground::*)(  const gp_Dir &  ) ) static_cast<void (Aspect_SkydomeBackground::*)(  const gp_Dir &  ) >(&Aspect_SkydomeBackground::SetSunDirection),
             R"#(Set sun direction. By default this value is (0, 1, 0) Sun direction with negative Y component represents moon with (-X, -Y, -Z) direction.)#"  , py::arg("theSunDirection")
          )
        .def("SetCloudiness",
             (void (Aspect_SkydomeBackground::*)( float  ) ) static_cast<void (Aspect_SkydomeBackground::*)( float  ) >(&Aspect_SkydomeBackground::SetCloudiness),
             R"#(Set cloud intensity. By default this value is 0.2 0.0 means no clouds at all and 1.0 - high clody.)#"  , py::arg("theCloudiness")
          )
        .def("SetTimeParameter",
             (void (Aspect_SkydomeBackground::*)( float  ) ) static_cast<void (Aspect_SkydomeBackground::*)( float  ) >(&Aspect_SkydomeBackground::SetTimeParameter),
             R"#(Set time of cloud simulation. By default this value is 0.0 This value might be tweaked to slightly change appearance of clouds.)#"  , py::arg("theTime")
          )
        .def("SetFogginess",
             (void (Aspect_SkydomeBackground::*)( float  ) ) static_cast<void (Aspect_SkydomeBackground::*)( float  ) >(&Aspect_SkydomeBackground::SetFogginess),
             R"#(Set fog intensity. By default this value is 0.0 0.0 means no fog and 1.0 - high fogginess)#"  , py::arg("theFogginess")
          )
        .def("SetSize",
             (void (Aspect_SkydomeBackground::*)( int  ) ) static_cast<void (Aspect_SkydomeBackground::*)( int  ) >(&Aspect_SkydomeBackground::SetSize),
             R"#(Set size of cubemap. By default this value is 512)#"  , py::arg("theSize")
          )
        .def("DumpJson",
             (void (Aspect_SkydomeBackground::*)( Standard_OStream & ,  int  ) const) static_cast<void (Aspect_SkydomeBackground::*)( Standard_OStream & ,  int  ) const>(&Aspect_SkydomeBackground::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("SunDirection",
             ( const gp_Dir & (Aspect_SkydomeBackground::*)() const) static_cast< const gp_Dir & (Aspect_SkydomeBackground::*)() const>(&Aspect_SkydomeBackground::SunDirection),
             R"#(Get sun direction. By default this value is (0, 1, 0) Sun direction with negative Y component represents moon with (-X, -Y, -Z) direction.)#"
             
         )
;

    // Class Aspect_Touch from ./opencascade/Aspect_Touch.hxx
    klass = m.attr("Aspect_Touch");


    // nested enums

    static_cast<py::class_<Aspect_Touch , shared_ptr<Aspect_Touch>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const NCollection_Vec2<double> &,bool >()  , py::arg("thePnt"),  py::arg("theIsPreciseDevice") )
        .def(py::init< double,double,bool >()  , py::arg("theX"),  py::arg("theY"),  py::arg("theIsPreciseDevice") )
    // custom constructors
    // methods
        .def("Delta",
             (NCollection_Vec2<double> (Aspect_Touch::*)() const) static_cast<NCollection_Vec2<double> (Aspect_Touch::*)() const>(&Aspect_Touch::Delta),
             R"#(Return values delta.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
        .def_readwrite("IsPreciseDevice", &Aspect_Touch::IsPreciseDevice)
    // methods returning by ref wrapped as properties
;

    // Class Aspect_TrackedDevicePose from ./opencascade/Aspect_TrackedDevicePose.hxx
    klass = m.attr("Aspect_TrackedDevicePose");


    // nested enums

    static_cast<py::class_<Aspect_TrackedDevicePose , shared_ptr<Aspect_TrackedDevicePose>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
        .def_readwrite("Orientation", &Aspect_TrackedDevicePose::Orientation)
        .def_readwrite("Velocity", &Aspect_TrackedDevicePose::Velocity)
        .def_readwrite("AngularVelocity", &Aspect_TrackedDevicePose::AngularVelocity)
        .def_readwrite("IsValidPose", &Aspect_TrackedDevicePose::IsValidPose)
        .def_readwrite("IsConnectedDevice", &Aspect_TrackedDevicePose::IsConnectedDevice)
    // methods returning by ref wrapped as properties
;

    // Class Aspect_Window from ./opencascade/Aspect_Window.hxx
    klass = m.attr("Aspect_Window");


    // nested enums

    static_cast<py::class_<Aspect_Window ,opencascade::handle<Aspect_Window> ,Py_Aspect_Window , Standard_Transient >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("IsVirtual",
             (bool (Aspect_Window::*)() const) static_cast<bool (Aspect_Window::*)() const>(&Aspect_Window::IsVirtual),
             R"#(Returns True if the window <me> is virtual)#" 
          )
        .def("SetVirtual",
             (void (Aspect_Window::*)(  const bool  ) ) static_cast<void (Aspect_Window::*)(  const bool  ) >(&Aspect_Window::SetVirtual),
             R"#(Setup the virtual state)#"  , py::arg("theVirtual")
          )
        .def("TopLeft",
             (NCollection_Vec2<int> (Aspect_Window::*)() const) static_cast<NCollection_Vec2<int> (Aspect_Window::*)() const>(&Aspect_Window::TopLeft),
             R"#(Returns window top-left corner.)#" 
          )
        .def("Dimensions",
             (NCollection_Vec2<int> (Aspect_Window::*)() const) static_cast<NCollection_Vec2<int> (Aspect_Window::*)() const>(&Aspect_Window::Dimensions),
             R"#(Returns window dimensions.)#" 
          )
        .def("Background",
             (Aspect_Background (Aspect_Window::*)() const) static_cast<Aspect_Background (Aspect_Window::*)() const>(&Aspect_Window::Background),
             R"#(Returns the window background.)#" 
          )
        .def("BackgroundFillMethod",
             (Aspect_FillMethod (Aspect_Window::*)() const) static_cast<Aspect_FillMethod (Aspect_Window::*)() const>(&Aspect_Window::BackgroundFillMethod),
             R"#(Returns the current image background fill mode.)#" 
          )
        .def("GradientBackground",
             (Aspect_GradientBackground (Aspect_Window::*)() const) static_cast<Aspect_GradientBackground (Aspect_Window::*)() const>(&Aspect_Window::GradientBackground),
             R"#(Returns the window gradient background.)#" 
          )
        .def("SetBackground",
             (void (Aspect_Window::*)(  const Aspect_Background &  ) ) static_cast<void (Aspect_Window::*)(  const Aspect_Background &  ) >(&Aspect_Window::SetBackground),
             R"#(Modifies the window background.)#"  , py::arg("theBack")
          )
        .def("SetBackground",
             (void (Aspect_Window::*)(  const Quantity_Color &  ) ) static_cast<void (Aspect_Window::*)(  const Quantity_Color &  ) >(&Aspect_Window::SetBackground),
             R"#(Modifies the window background.)#"  , py::arg("theColor")
          )
        .def("SetBackground",
             (void (Aspect_Window::*)(  const Aspect_GradientBackground &  ) ) static_cast<void (Aspect_Window::*)(  const Aspect_GradientBackground &  ) >(&Aspect_Window::SetBackground),
             R"#(Modifies the window gradient background.)#"  , py::arg("theBackground")
          )
        .def("SetBackground",
             (void (Aspect_Window::*)(  const Quantity_Color & ,   const Quantity_Color & ,   const Aspect_GradientFillMethod  ) ) static_cast<void (Aspect_Window::*)(  const Quantity_Color & ,   const Quantity_Color & ,   const Aspect_GradientFillMethod  ) >(&Aspect_Window::SetBackground),
             R"#(Modifies the window gradient background.)#"  , py::arg("theFirstColor"),  py::arg("theSecondColor"),  py::arg("theFillMethod")
          )
        .def("IsMapped",
             (bool (Aspect_Window::*)() const) static_cast<bool (Aspect_Window::*)() const>(&Aspect_Window::IsMapped),
             R"#(Returns True if the window <me> is opened and False if the window is closed.)#" 
          )
        .def("Map",
             (void (Aspect_Window::*)() const) static_cast<void (Aspect_Window::*)() const>(&Aspect_Window::Map),
             R"#(Opens the window <me>.)#" 
          )
        .def("Unmap",
             (void (Aspect_Window::*)() const) static_cast<void (Aspect_Window::*)() const>(&Aspect_Window::Unmap),
             R"#(Closes the window <me>.)#" 
          )
        .def("DoResize",
             (Aspect_TypeOfResize (Aspect_Window::*)() ) static_cast<Aspect_TypeOfResize (Aspect_Window::*)() >(&Aspect_Window::DoResize),
             R"#(Apply the resizing to the window <me>.)#" 
          )
        .def("DoMapping",
             (bool (Aspect_Window::*)() const) static_cast<bool (Aspect_Window::*)() const>(&Aspect_Window::DoMapping),
             R"#(Apply the mapping change to the window <me>. and returns TRUE if the window is mapped at screen.)#" 
          )
        .def("Ratio",
             (double (Aspect_Window::*)() const) static_cast<double (Aspect_Window::*)() const>(&Aspect_Window::Ratio),
             R"#(Returns The Window RATIO equal to the physical WIDTH/HEIGHT dimensions)#" 
          )
        .def("NativeHandle",
             (Aspect_Drawable (Aspect_Window::*)() const) static_cast<Aspect_Drawable (Aspect_Window::*)() const>(&Aspect_Window::NativeHandle),
             R"#(Returns native Window handle (HWND on Windows, Window with Xlib, and so on))#" 
          )
        .def("NativeParentHandle",
             (Aspect_Drawable (Aspect_Window::*)() const) static_cast<Aspect_Drawable (Aspect_Window::*)() const>(&Aspect_Window::NativeParentHandle),
             R"#(Returns parent of native Window handle (HWND on Windows, Window with Xlib, and so on))#" 
          )
        .def("SetTitle",
             (void (Aspect_Window::*)(  const TCollection_AsciiString &  ) ) static_cast<void (Aspect_Window::*)(  const TCollection_AsciiString &  ) >(&Aspect_Window::SetTitle),
             R"#(Sets window title.)#"  , py::arg("theTitle")
          )
        .def("InvalidateContent",
             (void (Aspect_Window::*)(  const handle<Aspect_DisplayConnection> &  ) ) static_cast<void (Aspect_Window::*)(  const handle<Aspect_DisplayConnection> &  ) >(&Aspect_Window::InvalidateContent),
             R"#(Invalidate entire window content.)#"  , py::arg("theDisp")
          )
        .def("DevicePixelRatio",
             (double (Aspect_Window::*)() const) static_cast<double (Aspect_Window::*)() const>(&Aspect_Window::DevicePixelRatio),
             R"#(Return device pixel ratio (logical to backing store scale factor).)#" 
          )
        .def("ConvertPointToBacking",
             (NCollection_Vec2<double> (Aspect_Window::*)(  const NCollection_Vec2<double> &  ) const) static_cast<NCollection_Vec2<double> (Aspect_Window::*)(  const NCollection_Vec2<double> &  ) const>(&Aspect_Window::ConvertPointToBacking),
             R"#(Convert point from logical units into backing store units.)#"  , py::arg("thePnt")
          )
        .def("ConvertPointFromBacking",
             (NCollection_Vec2<double> (Aspect_Window::*)(  const NCollection_Vec2<double> &  ) const) static_cast<NCollection_Vec2<double> (Aspect_Window::*)(  const NCollection_Vec2<double> &  ) const>(&Aspect_Window::ConvertPointFromBacking),
             R"#(Convert point from backing store units to logical units.)#"  , py::arg("thePnt")
          )
        .def("DumpJson",
             (void (Aspect_Window::*)( Standard_OStream & ,  int  ) const) static_cast<void (Aspect_Window::*)( Standard_OStream & ,  int  ) const>(&Aspect_Window::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
        .def("Position",
             []( Aspect_Window &self   ){
                 int  X1;
                int  Y1;
                int  X2;
                int  Y2;

                 self.Position(X1,Y1,X2,Y2);
                 return std::make_tuple(X1,Y1,X2,Y2); },
             R"#(Returns The Window POSITION in PIXEL)#" 
          )
        .def("Size",
             []( Aspect_Window &self   ){
                 int  Width;
                int  Height;

                 self.Size(Width,Height);
                 return std::make_tuple(Width,Height); },
             R"#(Returns The Window SIZE in PIXEL)#" 
          )
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&Aspect_Window::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&Aspect_Window::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (Aspect_Window::*)() const) static_cast< const handle<Standard_Type> & (Aspect_Window::*)() const>(&Aspect_Window::DynamicType),
             R"#()#"
             
         )
       .def("DisplayConnection",
             ( const handle<Aspect_DisplayConnection> & (Aspect_Window::*)() const) static_cast< const handle<Aspect_DisplayConnection> & (Aspect_Window::*)() const>(&Aspect_Window::DisplayConnection),
             R"#(Returns connection to Display or NULL.)#"
             
         )
;

    // Class Aspect_WindowInputListener from ./opencascade/Aspect_WindowInputListener.hxx
    klass = m.attr("Aspect_WindowInputListener");


    // nested enums

    static_cast<py::class_<Aspect_WindowInputListener , shared_ptr<Aspect_WindowInputListener> ,Py_Aspect_WindowInputListener >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("EventTime",
             (double (Aspect_WindowInputListener::*)() const) static_cast<double (Aspect_WindowInputListener::*)() const>(&Aspect_WindowInputListener::EventTime),
             R"#(Return event time (e.g. current time).)#" 
          )
        .def("ProcessExpose",
             (void (Aspect_WindowInputListener::*)() ) static_cast<void (Aspect_WindowInputListener::*)() >(&Aspect_WindowInputListener::ProcessExpose),
             R"#(Handle expose event (window content has been invalidation and should be redrawn).)#" 
          )
        .def("ProcessConfigure",
             (void (Aspect_WindowInputListener::*)( bool  ) ) static_cast<void (Aspect_WindowInputListener::*)( bool  ) >(&Aspect_WindowInputListener::ProcessConfigure),
             R"#(Handle window resize event.)#"  , py::arg("theIsResized")
          )
        .def("ProcessInput",
             (void (Aspect_WindowInputListener::*)() ) static_cast<void (Aspect_WindowInputListener::*)() >(&Aspect_WindowInputListener::ProcessInput),
             R"#(Handle window input event immediately (flush input buffer or ignore).)#" 
          )
        .def("ProcessFocus",
             (void (Aspect_WindowInputListener::*)( bool  ) ) static_cast<void (Aspect_WindowInputListener::*)( bool  ) >(&Aspect_WindowInputListener::ProcessFocus),
             R"#(Handle focus event.)#"  , py::arg("theIsActivated")
          )
        .def("ProcessClose",
             (void (Aspect_WindowInputListener::*)() ) static_cast<void (Aspect_WindowInputListener::*)() >(&Aspect_WindowInputListener::ProcessClose),
             R"#(Handle window close event.)#" 
          )
        .def("KeyDown",
             (void (Aspect_WindowInputListener::*)( Aspect_VKey ,  double ,  double  ) ) static_cast<void (Aspect_WindowInputListener::*)( Aspect_VKey ,  double ,  double  ) >(&Aspect_WindowInputListener::KeyDown),
             R"#(Press key. Default implementation updates internal cache.)#"  , py::arg("theKey"),  py::arg("theTime"),  py::arg("thePressure")=static_cast<double>(1.0)
          )
        .def("KeyUp",
             (void (Aspect_WindowInputListener::*)( Aspect_VKey ,  double  ) ) static_cast<void (Aspect_WindowInputListener::*)( Aspect_VKey ,  double  ) >(&Aspect_WindowInputListener::KeyUp),
             R"#(Release key. Default implementation updates internal cache.)#"  , py::arg("theKey"),  py::arg("theTime")
          )
        .def("KeyFromAxis",
             (void (Aspect_WindowInputListener::*)( Aspect_VKey ,  Aspect_VKey ,  double ,  double  ) ) static_cast<void (Aspect_WindowInputListener::*)( Aspect_VKey ,  Aspect_VKey ,  double ,  double  ) >(&Aspect_WindowInputListener::KeyFromAxis),
             R"#(Simulate key up/down events from axis value. Default implementation updates internal cache.)#"  , py::arg("theNegative"),  py::arg("thePositive"),  py::arg("theTime"),  py::arg("thePressure")
          )
        .def("UpdateMouseScroll",
             (bool (Aspect_WindowInputListener::*)(  const Aspect_ScrollDelta &  ) ) static_cast<bool (Aspect_WindowInputListener::*)(  const Aspect_ScrollDelta &  ) >(&Aspect_WindowInputListener::UpdateMouseScroll),
             R"#(Update mouse scroll event. This method is expected to be called from UI thread.)#"  , py::arg("theDelta")
          )
        .def("UpdateMouseButtons",
             (bool (Aspect_WindowInputListener::*)(  const NCollection_Vec2<int> & ,  Aspect_VKeyMouse ,  Aspect_VKeyFlags ,  bool  ) ) static_cast<bool (Aspect_WindowInputListener::*)(  const NCollection_Vec2<int> & ,  Aspect_VKeyMouse ,  Aspect_VKeyFlags ,  bool  ) >(&Aspect_WindowInputListener::UpdateMouseButtons),
             R"#(Handle mouse button press/release event. This method is expected to be called from UI thread.)#"  , py::arg("thePoint"),  py::arg("theButtons"),  py::arg("theModifiers"),  py::arg("theIsEmulated")
          )
        .def("UpdateMousePosition",
             (bool (Aspect_WindowInputListener::*)(  const NCollection_Vec2<int> & ,  Aspect_VKeyMouse ,  Aspect_VKeyFlags ,  bool  ) ) static_cast<bool (Aspect_WindowInputListener::*)(  const NCollection_Vec2<int> & ,  Aspect_VKeyMouse ,  Aspect_VKeyFlags ,  bool  ) >(&Aspect_WindowInputListener::UpdateMousePosition),
             R"#(Handle mouse cursor movement event. This method is expected to be called from UI thread. Default implementation does nothing.)#"  , py::arg("thePoint"),  py::arg("theButtons"),  py::arg("theModifiers"),  py::arg("theIsEmulated")
          )
        .def("PressMouseButton",
             (bool (Aspect_WindowInputListener::*)(  const NCollection_Vec2<int> & ,  Aspect_VKeyMouse ,  Aspect_VKeyFlags ,  bool  ) ) static_cast<bool (Aspect_WindowInputListener::*)(  const NCollection_Vec2<int> & ,  Aspect_VKeyMouse ,  Aspect_VKeyFlags ,  bool  ) >(&Aspect_WindowInputListener::PressMouseButton),
             R"#(Handle mouse button press event. This method is expected to be called from UI thread. Default implementation redirects to UpdateMousePosition().)#"  , py::arg("thePoint"),  py::arg("theButton"),  py::arg("theModifiers"),  py::arg("theIsEmulated")
          )
        .def("ReleaseMouseButton",
             (bool (Aspect_WindowInputListener::*)(  const NCollection_Vec2<int> & ,  Aspect_VKeyMouse ,  Aspect_VKeyFlags ,  bool  ) ) static_cast<bool (Aspect_WindowInputListener::*)(  const NCollection_Vec2<int> & ,  Aspect_VKeyMouse ,  Aspect_VKeyFlags ,  bool  ) >(&Aspect_WindowInputListener::ReleaseMouseButton),
             R"#(Handle mouse button release event. This method is expected to be called from UI thread. Default implementation redirects to UpdateMousePosition().)#"  , py::arg("thePoint"),  py::arg("theButton"),  py::arg("theModifiers"),  py::arg("theIsEmulated")
          )
        .def("PressedMouseButtons",
             (Aspect_VKeyMouse (Aspect_WindowInputListener::*)() const) static_cast<Aspect_VKeyMouse (Aspect_WindowInputListener::*)() const>(&Aspect_WindowInputListener::PressedMouseButtons),
             R"#(Return currently pressed mouse buttons.)#" 
          )
        .def("LastMouseFlags",
             (Aspect_VKeyFlags (Aspect_WindowInputListener::*)() const) static_cast<Aspect_VKeyFlags (Aspect_WindowInputListener::*)() const>(&Aspect_WindowInputListener::LastMouseFlags),
             R"#(Return active key modifiers passed with last mouse event.)#" 
          )
        .def("HasTouchPoints",
             (bool (Aspect_WindowInputListener::*)() const) static_cast<bool (Aspect_WindowInputListener::*)() const>(&Aspect_WindowInputListener::HasTouchPoints),
             R"#(Return TRUE if touches map is not empty.)#" 
          )
        .def("AddTouchPoint",
             (void (Aspect_WindowInputListener::*)( size_t ,   const NCollection_Vec2<double> & ,  bool  ) ) static_cast<void (Aspect_WindowInputListener::*)( size_t ,   const NCollection_Vec2<double> & ,  bool  ) >(&Aspect_WindowInputListener::AddTouchPoint),
             R"#(Add touch point with the given ID. This method is expected to be called from UI thread.)#"  , py::arg("theId"),  py::arg("thePnt"),  py::arg("theClearBefore")=static_cast<bool>(false)
          )
        .def("RemoveTouchPoint",
             (bool (Aspect_WindowInputListener::*)( size_t ,  bool  ) ) static_cast<bool (Aspect_WindowInputListener::*)( size_t ,  bool  ) >(&Aspect_WindowInputListener::RemoveTouchPoint),
             R"#(Remove touch point with the given ID. This method is expected to be called from UI thread.)#"  , py::arg("theId"),  py::arg("theClearSelectPnts")=static_cast<bool>(false)
          )
        .def("UpdateTouchPoint",
             (void (Aspect_WindowInputListener::*)( size_t ,   const NCollection_Vec2<double> &  ) ) static_cast<void (Aspect_WindowInputListener::*)( size_t ,   const NCollection_Vec2<double> &  ) >(&Aspect_WindowInputListener::UpdateTouchPoint),
             R"#(Update touch point with the given ID. If point with specified ID was not registered before, it will be added. This method is expected to be called from UI thread.)#"  , py::arg("theId"),  py::arg("thePnt")
          )
        .def("Get3dMouseTranslationScale",
             (float (Aspect_WindowInputListener::*)() const) static_cast<float (Aspect_WindowInputListener::*)() const>(&Aspect_WindowInputListener::Get3dMouseTranslationScale),
             R"#(Return acceleration ratio for translation event; 2.0 by default.)#" 
          )
        .def("Set3dMouseTranslationScale",
             (void (Aspect_WindowInputListener::*)( float  ) ) static_cast<void (Aspect_WindowInputListener::*)( float  ) >(&Aspect_WindowInputListener::Set3dMouseTranslationScale),
             R"#(Set acceleration ratio for translation event.)#"  , py::arg("theScale")
          )
        .def("Get3dMouseRotationScale",
             (float (Aspect_WindowInputListener::*)() const) static_cast<float (Aspect_WindowInputListener::*)() const>(&Aspect_WindowInputListener::Get3dMouseRotationScale),
             R"#(Return acceleration ratio for rotation event; 4.0 by default.)#" 
          )
        .def("Set3dMouseRotationScale",
             (void (Aspect_WindowInputListener::*)( float  ) ) static_cast<void (Aspect_WindowInputListener::*)( float  ) >(&Aspect_WindowInputListener::Set3dMouseRotationScale),
             R"#(Set acceleration ratio for rotation event.)#"  , py::arg("theScale")
          )
        .def("To3dMousePreciseInput",
             (bool (Aspect_WindowInputListener::*)() const) static_cast<bool (Aspect_WindowInputListener::*)() const>(&Aspect_WindowInputListener::To3dMousePreciseInput),
             R"#(Return quadric acceleration flag; TRUE by default.)#" 
          )
        .def("Set3dMousePreciseInput",
             (void (Aspect_WindowInputListener::*)( bool  ) ) static_cast<void (Aspect_WindowInputListener::*)( bool  ) >(&Aspect_WindowInputListener::Set3dMousePreciseInput),
             R"#(Set quadric acceleration flag.)#"  , py::arg("theIsQuadric")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Keys",
             ( const Aspect_VKeySet & (Aspect_WindowInputListener::*)() const) static_cast< const Aspect_VKeySet & (Aspect_WindowInputListener::*)() const>(&Aspect_WindowInputListener::Keys),
             R"#(Return keyboard state.)#"
             
         )
       .def("ChangeKeys",
             (Aspect_VKeySet & (Aspect_WindowInputListener::*)() ) static_cast<Aspect_VKeySet & (Aspect_WindowInputListener::*)() >(&Aspect_WindowInputListener::ChangeKeys),
             R"#(Return keyboard state.)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("LastMousePosition",
             ( const NCollection_Vec2<int> & (Aspect_WindowInputListener::*)() const) static_cast< const NCollection_Vec2<int> & (Aspect_WindowInputListener::*)() const>(&Aspect_WindowInputListener::LastMousePosition),
             R"#(Return last mouse position.)#"
             
         )
       .def("TouchPoints",
             ( const NCollection_IndexedDataMap<size_t, Aspect_Touch> & (Aspect_WindowInputListener::*)() const) static_cast< const NCollection_IndexedDataMap<size_t, Aspect_Touch> & (Aspect_WindowInputListener::*)() const>(&Aspect_WindowInputListener::TouchPoints),
             R"#(Return map of active touches.)#"
             
         )
       .def("Get3dMouseIsNoRotate",
             ( const NCollection_Vec3<bool> & (Aspect_WindowInputListener::*)() const) static_cast< const NCollection_Vec3<bool> & (Aspect_WindowInputListener::*)() const>(&Aspect_WindowInputListener::Get3dMouseIsNoRotate),
             R"#(Return 3d mouse rotation axes (tilt/roll/spin) ignore flag; (FALSE, FALSE, FALSE) by default.)#"
             
         )
       .def("Change3dMouseIsNoRotate",
             (NCollection_Vec3<bool> & (Aspect_WindowInputListener::*)() ) static_cast<NCollection_Vec3<bool> & (Aspect_WindowInputListener::*)() >(&Aspect_WindowInputListener::Change3dMouseIsNoRotate),
             R"#(Return 3d mouse rotation axes (tilt/roll/spin) ignore flag; (FALSE, FALSE, FALSE) by default.)#"
             
             , py::return_value_policy::reference_internal
         )
       .def("Get3dMouseToReverse",
             ( const NCollection_Vec3<bool> & (Aspect_WindowInputListener::*)() const) static_cast< const NCollection_Vec3<bool> & (Aspect_WindowInputListener::*)() const>(&Aspect_WindowInputListener::Get3dMouseToReverse),
             R"#(Return 3d mouse rotation axes (tilt/roll/spin) reverse flag; (TRUE, FALSE, FALSE) by default.)#"
             
         )
       .def("Change3dMouseToReverse",
             (NCollection_Vec3<bool> & (Aspect_WindowInputListener::*)() ) static_cast<NCollection_Vec3<bool> & (Aspect_WindowInputListener::*)() >(&Aspect_WindowInputListener::Change3dMouseToReverse),
             R"#(Return 3d mouse rotation axes (tilt/roll/spin) reverse flag; (TRUE, FALSE, FALSE) by default.)#"
             
             , py::return_value_policy::reference_internal
         )
;

    // Class Aspect_XRAction from ./opencascade/Aspect_XRAction.hxx
    klass = m.attr("Aspect_XRAction");


    // nested enums

    static_cast<py::class_<Aspect_XRAction ,opencascade::handle<Aspect_XRAction>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const TCollection_AsciiString &, const Aspect_XRActionType >()  , py::arg("theId"),  py::arg("theType") )
    // custom constructors
    // methods
        .def("Type",
             (Aspect_XRActionType (Aspect_XRAction::*)() const) static_cast<Aspect_XRActionType (Aspect_XRAction::*)() const>(&Aspect_XRAction::Type),
             R"#(Return action type.)#" 
          )
        .def("IsValid",
             (bool (Aspect_XRAction::*)() const) static_cast<bool (Aspect_XRAction::*)() const>(&Aspect_XRAction::IsValid),
             R"#(Return TRUE if action is defined.)#" 
          )
        .def("RawHandle",
             (uint64_t (Aspect_XRAction::*)() const) static_cast<uint64_t (Aspect_XRAction::*)() const>(&Aspect_XRAction::RawHandle),
             R"#(Return action handle.)#" 
          )
        .def("SetRawHandle",
             (void (Aspect_XRAction::*)( uint64_t  ) ) static_cast<void (Aspect_XRAction::*)( uint64_t  ) >(&Aspect_XRAction::SetRawHandle),
             R"#(Set action handle.)#"  , py::arg("theHande")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&Aspect_XRAction::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&Aspect_XRAction::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (Aspect_XRAction::*)() const) static_cast< const handle<Standard_Type> & (Aspect_XRAction::*)() const>(&Aspect_XRAction::DynamicType),
             R"#()#"
             
         )
       .def("Id",
             ( const TCollection_AsciiString & (Aspect_XRAction::*)() const) static_cast< const TCollection_AsciiString & (Aspect_XRAction::*)() const>(&Aspect_XRAction::Id),
             R"#(Return action id.)#"
             
         )
;

    // Class Aspect_XRActionSet from ./opencascade/Aspect_XRActionSet.hxx
    klass = m.attr("Aspect_XRActionSet");


    // nested enums

    static_cast<py::class_<Aspect_XRActionSet ,opencascade::handle<Aspect_XRActionSet>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  const TCollection_AsciiString & >()  , py::arg("theId") )
    // custom constructors
    // methods
        .def("RawHandle",
             (uint64_t (Aspect_XRActionSet::*)() const) static_cast<uint64_t (Aspect_XRActionSet::*)() const>(&Aspect_XRActionSet::RawHandle),
             R"#(Return action handle.)#" 
          )
        .def("SetRawHandle",
             (void (Aspect_XRActionSet::*)( uint64_t  ) ) static_cast<void (Aspect_XRActionSet::*)( uint64_t  ) >(&Aspect_XRActionSet::SetRawHandle),
             R"#(Set action handle.)#"  , py::arg("theHande")
          )
        .def("AddAction",
             (void (Aspect_XRActionSet::*)(  const handle<Aspect_XRAction> &  ) ) static_cast<void (Aspect_XRActionSet::*)(  const handle<Aspect_XRAction> &  ) >(&Aspect_XRActionSet::AddAction),
             R"#(Add action.)#"  , py::arg("theAction")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&Aspect_XRActionSet::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&Aspect_XRActionSet::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (Aspect_XRActionSet::*)() const) static_cast< const handle<Standard_Type> & (Aspect_XRActionSet::*)() const>(&Aspect_XRActionSet::DynamicType),
             R"#()#"
             
         )
       .def("Id",
             ( const TCollection_AsciiString & (Aspect_XRActionSet::*)() const) static_cast< const TCollection_AsciiString & (Aspect_XRActionSet::*)() const>(&Aspect_XRActionSet::Id),
             R"#(Return action id.)#"
             
         )
       .def("Actions",
             ( const NCollection_IndexedDataMap<TCollection_AsciiString, handle<Aspect_XRAction>> & (Aspect_XRActionSet::*)() const) static_cast< const NCollection_IndexedDataMap<TCollection_AsciiString, handle<Aspect_XRAction>> & (Aspect_XRActionSet::*)() const>(&Aspect_XRActionSet::Actions),
             R"#(Return map of actions.)#"
             
         )
;

    // Class Aspect_XRAnalogActionData from ./opencascade/Aspect_XRAnalogActionData.hxx
    klass = m.attr("Aspect_XRAnalogActionData");


    // nested enums

    static_cast<py::class_<Aspect_XRAnalogActionData , shared_ptr<Aspect_XRAnalogActionData>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("IsChanged",
             (bool (Aspect_XRAnalogActionData::*)() ) static_cast<bool (Aspect_XRAnalogActionData::*)() >(&Aspect_XRAnalogActionData::IsChanged),
             R"#(Return TRUE if delta is non-zero.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
        .def_readwrite("UpdateTime", &Aspect_XRAnalogActionData::UpdateTime)
        .def_readwrite("IsActive", &Aspect_XRAnalogActionData::IsActive)
    // methods returning by ref wrapped as properties
;

    // Class Aspect_XRDigitalActionData from ./opencascade/Aspect_XRDigitalActionData.hxx
    klass = m.attr("Aspect_XRDigitalActionData");


    // nested enums

    static_cast<py::class_<Aspect_XRDigitalActionData , shared_ptr<Aspect_XRDigitalActionData>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
        .def_readwrite("UpdateTime", &Aspect_XRDigitalActionData::UpdateTime)
        .def_readwrite("IsActive", &Aspect_XRDigitalActionData::IsActive)
        .def_readwrite("IsPressed", &Aspect_XRDigitalActionData::IsPressed)
        .def_readwrite("IsChanged", &Aspect_XRDigitalActionData::IsChanged)
    // methods returning by ref wrapped as properties
;

    // Class Aspect_XRHapticActionData from ./opencascade/Aspect_XRHapticActionData.hxx
    klass = m.attr("Aspect_XRHapticActionData");


    // nested enums

    static_cast<py::class_<Aspect_XRHapticActionData , shared_ptr<Aspect_XRHapticActionData>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("IsValid",
             (bool (Aspect_XRHapticActionData::*)() const) static_cast<bool (Aspect_XRHapticActionData::*)() const>(&Aspect_XRHapticActionData::IsValid),
             R"#(Return TRUE if data is not empty.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
        .def_readwrite("Delay", &Aspect_XRHapticActionData::Delay)
        .def_readwrite("Duration", &Aspect_XRHapticActionData::Duration)
        .def_readwrite("Frequency", &Aspect_XRHapticActionData::Frequency)
        .def_readwrite("Amplitude", &Aspect_XRHapticActionData::Amplitude)
    // methods returning by ref wrapped as properties
;

    // Class Aspect_XRPoseActionData from ./opencascade/Aspect_XRPoseActionData.hxx
    klass = m.attr("Aspect_XRPoseActionData");


    // nested enums

    static_cast<py::class_<Aspect_XRPoseActionData , shared_ptr<Aspect_XRPoseActionData>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
        .def_readwrite("Pose", &Aspect_XRPoseActionData::Pose)
        .def_readwrite("IsActive", &Aspect_XRPoseActionData::IsActive)
    // methods returning by ref wrapped as properties
;

    // Class Aspect_XRSession from ./opencascade/Aspect_XRSession.hxx
    klass = m.attr("Aspect_XRSession");


    // nested enums
        py::enum_<Aspect_XRSession::TrackingUniverseOrigin>(klass, "TrackingUniverseOrigin_e", R"#(Identifies which style of tracking origin the application wants to use for the poses it is requesting.)#")
            .value("TrackingUniverseOrigin_Seated", Aspect_XRSession::TrackingUniverseOrigin::TrackingUniverseOrigin_Seated)
            .value("TrackingUniverseOrigin_Standing", Aspect_XRSession::TrackingUniverseOrigin::TrackingUniverseOrigin_Standing);
        py::enum_<Aspect_XRSession::InfoString>(klass, "InfoString_e", R"#(Info string enumeration.)#")
            .value("InfoString_Vendor", Aspect_XRSession::InfoString::InfoString_Vendor)
            .value("InfoString_Device", Aspect_XRSession::InfoString::InfoString_Device)
            .value("InfoString_Tracker", Aspect_XRSession::InfoString::InfoString_Tracker)
            .value("InfoString_SerialNumber", Aspect_XRSession::InfoString::InfoString_SerialNumber);

    static_cast<py::class_<Aspect_XRSession ,opencascade::handle<Aspect_XRSession> ,Py_Aspect_XRSession , Standard_Transient >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("IsOpen",
             (bool (Aspect_XRSession::*)() const) static_cast<bool (Aspect_XRSession::*)() const>(&Aspect_XRSession::IsOpen),
             R"#(Return TRUE if session is opened.)#" 
          )
        .def("Open",
             (bool (Aspect_XRSession::*)() ) static_cast<bool (Aspect_XRSession::*)() >(&Aspect_XRSession::Open),
             R"#(Initialize session.)#" 
          )
        .def("Close",
             (void (Aspect_XRSession::*)() ) static_cast<void (Aspect_XRSession::*)() >(&Aspect_XRSession::Close),
             R"#(Release session.)#" 
          )
        .def("WaitPoses",
             (bool (Aspect_XRSession::*)() ) static_cast<bool (Aspect_XRSession::*)() >(&Aspect_XRSession::WaitPoses),
             R"#(Fetch actual poses of tracked devices.)#" 
          )
        .def("RecommendedViewport",
             (NCollection_Vec2<int> (Aspect_XRSession::*)() const) static_cast<NCollection_Vec2<int> (Aspect_XRSession::*)() const>(&Aspect_XRSession::RecommendedViewport),
             R"#(Return recommended viewport Width x Height for rendering into VR.)#" 
          )
        .def("EyeToHeadTransform",
             (NCollection_Mat4<double> (Aspect_XRSession::*)( Aspect_Eye  ) const) static_cast<NCollection_Mat4<double> (Aspect_XRSession::*)( Aspect_Eye  ) const>(&Aspect_XRSession::EyeToHeadTransform),
             R"#(Return transformation from eye to head.)#"  , py::arg("theEye")
          )
        .def("HeadToEyeTransform",
             (NCollection_Mat4<double> (Aspect_XRSession::*)( Aspect_Eye  ) const) static_cast<NCollection_Mat4<double> (Aspect_XRSession::*)( Aspect_Eye  ) const>(&Aspect_XRSession::HeadToEyeTransform),
             R"#(Return transformation from head to eye.)#"  , py::arg("theEye")
          )
        .def("ProjectionMatrix",
             (NCollection_Mat4<double> (Aspect_XRSession::*)( Aspect_Eye ,  double ,  double  ) const) static_cast<NCollection_Mat4<double> (Aspect_XRSession::*)( Aspect_Eye ,  double ,  double  ) const>(&Aspect_XRSession::ProjectionMatrix),
             R"#(Return projection matrix.)#"  , py::arg("theEye"),  py::arg("theZNear"),  py::arg("theZFar")
          )
        .def("HasProjectionFrustums",
             (bool (Aspect_XRSession::*)() const) static_cast<bool (Aspect_XRSession::*)() const>(&Aspect_XRSession::HasProjectionFrustums),
             R"#(Return FALSE if projection frustums are unsupported and general 4x4 projection matrix should be fetched instead)#" 
          )
        .def("ProcessEvents",
             (void (Aspect_XRSession::*)() ) static_cast<void (Aspect_XRSession::*)() >(&Aspect_XRSession::ProcessEvents),
             R"#(Receive XR events.)#" 
          )
        .def("SubmitEye",
             (bool (Aspect_XRSession::*)( void * ,  Aspect_GraphicsLibrary ,  Aspect_ColorSpace ,  Aspect_Eye  ) ) static_cast<bool (Aspect_XRSession::*)( void * ,  Aspect_GraphicsLibrary ,  Aspect_ColorSpace ,  Aspect_Eye  ) >(&Aspect_XRSession::SubmitEye),
             R"#(Submit texture eye to XR Composer.)#"  , py::arg("theTexture"),  py::arg("theGraphicsLib"),  py::arg("theColorSpace"),  py::arg("theEye")
          )
        .def("UnitFactor",
             (double (Aspect_XRSession::*)() const) static_cast<double (Aspect_XRSession::*)() const>(&Aspect_XRSession::UnitFactor),
             R"#(Return unit scale factor defined as scale factor for m (meters); 1.0 by default.)#" 
          )
        .def("SetUnitFactor",
             (void (Aspect_XRSession::*)( double  ) ) static_cast<void (Aspect_XRSession::*)( double  ) >(&Aspect_XRSession::SetUnitFactor),
             R"#(Set unit scale factor.)#"  , py::arg("theFactor")
          )
        .def("Aspect",
             (double (Aspect_XRSession::*)() const) static_cast<double (Aspect_XRSession::*)() const>(&Aspect_XRSession::Aspect),
             R"#(Return aspect ratio.)#" 
          )
        .def("FieldOfView",
             (double (Aspect_XRSession::*)() const) static_cast<double (Aspect_XRSession::*)() const>(&Aspect_XRSession::FieldOfView),
             R"#(Return field of view.)#" 
          )
        .def("IOD",
             (double (Aspect_XRSession::*)() const) static_cast<double (Aspect_XRSession::*)() const>(&Aspect_XRSession::IOD),
             R"#(Return Intra-ocular Distance (IOD); also known as Interpupillary Distance (IPD). Defined in meters by default ()#" 
          )
        .def("DisplayFrequency",
             (float (Aspect_XRSession::*)() const) static_cast<float (Aspect_XRSession::*)() const>(&Aspect_XRSession::DisplayFrequency),
             R"#(Return display frequency or 0 if unknown.)#" 
          )
        .def("ProjectionFrustum",
             ( const Aspect_FrustumLRBT<double> & (Aspect_XRSession::*)( Aspect_Eye  ) const) static_cast< const Aspect_FrustumLRBT<double> & (Aspect_XRSession::*)( Aspect_Eye  ) const>(&Aspect_XRSession::ProjectionFrustum),
             R"#(Return projection frustum.)#"  , py::arg("theEye")
          )
        .def("LeftHandPose",
             (gp_Trsf (Aspect_XRSession::*)() const) static_cast<gp_Trsf (Aspect_XRSession::*)() const>(&Aspect_XRSession::LeftHandPose),
             R"#(Return left hand orientation.)#" 
          )
        .def("RightHandPose",
             (gp_Trsf (Aspect_XRSession::*)() const) static_cast<gp_Trsf (Aspect_XRSession::*)() const>(&Aspect_XRSession::RightHandPose),
             R"#(Return right hand orientation.)#" 
          )
        .def("HasTrackedPose",
             (bool (Aspect_XRSession::*)( int  ) const) static_cast<bool (Aspect_XRSession::*)( int  ) const>(&Aspect_XRSession::HasTrackedPose),
             R"#(Return TRUE if device orientation is defined.)#"  , py::arg("theDevice")
          )
        .def("NamedTrackedDevice",
             (int (Aspect_XRSession::*)( Aspect_XRTrackedDeviceRole  ) const) static_cast<int (Aspect_XRSession::*)( Aspect_XRTrackedDeviceRole  ) const>(&Aspect_XRSession::NamedTrackedDevice),
             R"#(Return index of tracked device of known role, or -1 if undefined.)#"  , py::arg("theDevice")
          )
        .def("LoadRenderModel",
             (handle<Graphic3d_ArrayOfTriangles> (Aspect_XRSession::*)( int ,  handle<Image_Texture> &  ) ) static_cast<handle<Graphic3d_ArrayOfTriangles> (Aspect_XRSession::*)( int ,  handle<Image_Texture> &  ) >(&Aspect_XRSession::LoadRenderModel),
             R"#(Load model for displaying device.)#"  , py::arg("theDevice"),  py::arg("theTexture")
          )
        .def("LoadRenderModel",
             (handle<Graphic3d_ArrayOfTriangles> (Aspect_XRSession::*)( int ,  bool ,  handle<Image_Texture> &  ) ) static_cast<handle<Graphic3d_ArrayOfTriangles> (Aspect_XRSession::*)( int ,  bool ,  handle<Image_Texture> &  ) >(&Aspect_XRSession::LoadRenderModel),
             R"#(Load model for displaying device.)#"  , py::arg("theDevice"),  py::arg("theToApplyUnitFactor"),  py::arg("theTexture")
          )
        .def("GetDigitalActionData",
             (Aspect_XRDigitalActionData (Aspect_XRSession::*)(  const handle<Aspect_XRAction> &  ) const) static_cast<Aspect_XRDigitalActionData (Aspect_XRSession::*)(  const handle<Aspect_XRAction> &  ) const>(&Aspect_XRSession::GetDigitalActionData),
             R"#(Fetch data for digital input action (like button).)#"  , py::arg("theAction")
          )
        .def("GetAnalogActionData",
             (Aspect_XRAnalogActionData (Aspect_XRSession::*)(  const handle<Aspect_XRAction> &  ) const) static_cast<Aspect_XRAnalogActionData (Aspect_XRSession::*)(  const handle<Aspect_XRAction> &  ) const>(&Aspect_XRSession::GetAnalogActionData),
             R"#(Fetch data for digital input action (like axis).)#"  , py::arg("theAction")
          )
        .def("GetPoseActionDataForNextFrame",
             (Aspect_XRPoseActionData (Aspect_XRSession::*)(  const handle<Aspect_XRAction> &  ) const) static_cast<Aspect_XRPoseActionData (Aspect_XRSession::*)(  const handle<Aspect_XRAction> &  ) const>(&Aspect_XRSession::GetPoseActionDataForNextFrame),
             R"#(Fetch data for pose input action (like fingertip position). The returned values will match the values returned by the last call to WaitPoses().)#"  , py::arg("theAction")
          )
        .def("TriggerHapticVibrationAction",
             (void (Aspect_XRSession::*)(  const handle<Aspect_XRAction> & ,   const Aspect_XRHapticActionData &  ) ) static_cast<void (Aspect_XRSession::*)(  const handle<Aspect_XRAction> & ,   const Aspect_XRHapticActionData &  ) >(&Aspect_XRSession::TriggerHapticVibrationAction),
             R"#(Trigger vibration.)#"  , py::arg("theAction"),  py::arg("theParams")
          )
        .def("AbortHapticVibrationAction",
             (void (Aspect_XRSession::*)(  const handle<Aspect_XRAction> &  ) ) static_cast<void (Aspect_XRSession::*)(  const handle<Aspect_XRAction> &  ) >(&Aspect_XRSession::AbortHapticVibrationAction),
             R"#(Abort vibration.)#"  , py::arg("theAction")
          )
        .def("TrackingOrigin",
             (Aspect_XRSession::TrackingUniverseOrigin (Aspect_XRSession::*)() const) static_cast<Aspect_XRSession::TrackingUniverseOrigin (Aspect_XRSession::*)() const>(&Aspect_XRSession::TrackingOrigin),
             R"#(Return tracking origin.)#" 
          )
        .def("SetTrackingOrigin",
             (void (Aspect_XRSession::*)( Aspect_XRSession::TrackingUniverseOrigin  ) ) static_cast<void (Aspect_XRSession::*)( Aspect_XRSession::TrackingUniverseOrigin  ) >(&Aspect_XRSession::SetTrackingOrigin),
             R"#(Set tracking origin.)#"  , py::arg("theOrigin")
          )
        .def("GenericAction",
             ( const handle<Aspect_XRAction> & (Aspect_XRSession::*)( Aspect_XRTrackedDeviceRole ,  Aspect_XRGenericAction  ) const) static_cast< const handle<Aspect_XRAction> & (Aspect_XRSession::*)( Aspect_XRTrackedDeviceRole ,  Aspect_XRGenericAction  ) const>(&Aspect_XRSession::GenericAction),
             R"#(Return generic action for specific hand or NULL if undefined.)#"  , py::arg("theDevice"),  py::arg("theAction")
          )
        .def("GetString",
             (TCollection_AsciiString (Aspect_XRSession::*)( Aspect_XRSession::InfoString  ) const) static_cast<TCollection_AsciiString (Aspect_XRSession::*)( Aspect_XRSession::InfoString  ) const>(&Aspect_XRSession::GetString),
             R"#(Query information.)#"  , py::arg("theInfo")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&Aspect_XRSession::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&Aspect_XRSession::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (Aspect_XRSession::*)() const) static_cast< const handle<Standard_Type> & (Aspect_XRSession::*)() const>(&Aspect_XRSession::DynamicType),
             R"#()#"
             
         )
       .def("HeadPose",
             ( const gp_Trsf & (Aspect_XRSession::*)() const) static_cast< const gp_Trsf & (Aspect_XRSession::*)() const>(&Aspect_XRSession::HeadPose),
             R"#(Return head orientation in right-handed system: +y is up +x is to the right -z is forward Distance unit is meters by default ()#"
             
         )
       .def("TrackedPoses",
             ( const NCollection_Array1<Aspect_TrackedDevicePose> & (Aspect_XRSession::*)() const) static_cast< const NCollection_Array1<Aspect_TrackedDevicePose> & (Aspect_XRSession::*)() const>(&Aspect_XRSession::TrackedPoses),
             R"#(Return number of tracked poses array.)#"
             
         )
;

    // Class Aspect_CircularGrid from ./opencascade/Aspect_CircularGrid.hxx
    klass = m.attr("Aspect_CircularGrid");


    // nested enums

    static_cast<py::class_<Aspect_CircularGrid ,opencascade::handle<Aspect_CircularGrid> ,Py_Aspect_CircularGrid , Aspect_Grid >>(klass)
    // constructors
        .def(py::init<  const double, const int, const double, const double, const double >()  , py::arg("aRadiusStep"),  py::arg("aDivisionNumber"),  py::arg("XOrigin")=static_cast< const double>(0),  py::arg("anYOrigin")=static_cast< const double>(0),  py::arg("aRotationAngle")=static_cast< const double>(0) )
    // custom constructors
    // methods
        .def("SetRadiusStep",
             (void (Aspect_CircularGrid::*)(  const double  ) ) static_cast<void (Aspect_CircularGrid::*)(  const double  ) >(&Aspect_CircularGrid::SetRadiusStep),
             R"#(defines the x step of the grid.)#"  , py::arg("aStep")
          )
        .def("SetDivisionNumber",
             (void (Aspect_CircularGrid::*)(  const int  ) ) static_cast<void (Aspect_CircularGrid::*)(  const int  ) >(&Aspect_CircularGrid::SetDivisionNumber),
             R"#(defines the step of the grid.)#"  , py::arg("aNumber")
          )
        .def("SetGridValues",
             (void (Aspect_CircularGrid::*)(  const double ,   const double ,   const double ,   const int ,   const double  ) ) static_cast<void (Aspect_CircularGrid::*)(  const double ,   const double ,   const double ,   const int ,   const double  ) >(&Aspect_CircularGrid::SetGridValues),
             R"#()#"  , py::arg("XOrigin"),  py::arg("YOrigin"),  py::arg("RadiusStep"),  py::arg("DivisionNumber"),  py::arg("RotationAngle")
          )
        .def("RadiusStep",
             (double (Aspect_CircularGrid::*)() const) static_cast<double (Aspect_CircularGrid::*)() const>(&Aspect_CircularGrid::RadiusStep),
             R"#(returns the x step of the grid.)#" 
          )
        .def("DivisionNumber",
             (int (Aspect_CircularGrid::*)() const) static_cast<int (Aspect_CircularGrid::*)() const>(&Aspect_CircularGrid::DivisionNumber),
             R"#(returns the x step of the grid.)#" 
          )
        .def("SetRadius",
             (void (Aspect_CircularGrid::*)(  const double  ) ) static_cast<void (Aspect_CircularGrid::*)(  const double  ) >(&Aspect_CircularGrid::SetRadius),
             R"#(Set the circular grid radius (plane-local units). 0.0 (default) means unbounded - the shader draws the grid to the horizon.)#"  , py::arg("theRadius")
          )
        .def("Radius",
             (double (Aspect_CircularGrid::*)() const) static_cast<double (Aspect_CircularGrid::*)() const>(&Aspect_CircularGrid::Radius),
             R"#(Return the bounded radius. 0.0 means unbounded.)#" 
          )
        .def("SetZOffset",
             (void (Aspect_CircularGrid::*)(  const double  ) ) static_cast<void (Aspect_CircularGrid::*)(  const double  ) >(&Aspect_CircularGrid::SetZOffset),
             R"#(Set signed offset along the plane normal for display only; snap math stays on the plane. Use a small negative value to avoid z-fighting with coplanar geometry.)#"  , py::arg("theOffset")
          )
        .def("ZOffset",
             (double (Aspect_CircularGrid::*)() const) static_cast<double (Aspect_CircularGrid::*)() const>(&Aspect_CircularGrid::ZOffset),
             R"#(Return the display-time Z-offset along the plane normal.)#" 
          )
        .def("SetArcRange",
             (void (Aspect_CircularGrid::*)(  const double ,   const double  ) ) static_cast<void (Aspect_CircularGrid::*)(  const double ,   const double  ) >(&Aspect_CircularGrid::SetArcRange),
             R"#(Restrict the grid to an angular wedge, walking counter-clockwise from theStart to theEnd (radians, measured from the rotated plane X axis). Setting both values equal (e.g. both 0.0) returns to full-circle rendering - the sentinel used for unbounded.)#"  , py::arg("theStart"),  py::arg("theEnd")
          )
        .def("AngleStart",
             (double (Aspect_CircularGrid::*)() const) static_cast<double (Aspect_CircularGrid::*)() const>(&Aspect_CircularGrid::AngleStart),
             R"#(Return the arc start angle (radians). Meaningful only when IsArc() is true.)#" 
          )
        .def("AngleEnd",
             (double (Aspect_CircularGrid::*)() const) static_cast<double (Aspect_CircularGrid::*)() const>(&Aspect_CircularGrid::AngleEnd),
             R"#(Return the arc end angle (radians). Meaningful only when IsArc() is true.)#" 
          )
        .def("IsArc",
             (bool (Aspect_CircularGrid::*)() const) static_cast<bool (Aspect_CircularGrid::*)() const>(&Aspect_CircularGrid::IsArc),
             R"#(Return TRUE when the grid is restricted to an angular wedge.)#" 
          )
        .def("Init",
             (void (Aspect_CircularGrid::*)() ) static_cast<void (Aspect_CircularGrid::*)() >(&Aspect_CircularGrid::Init),
             R"#()#" 
          )
        .def("DumpJson",
             (void (Aspect_CircularGrid::*)( Standard_OStream & ,  int  ) const) static_cast<void (Aspect_CircularGrid::*)( Standard_OStream & ,  int  ) const>(&Aspect_CircularGrid::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
        .def("Compute",
             []( Aspect_CircularGrid &self ,  const double X, const double Y ){
                 double  gridX;
                double  gridY;

                 self.Compute(X,Y,gridX,gridY);
                 return std::make_tuple(gridX,gridY); },
             R"#(returns the point of the grid the closest to the point X,Y)#"  , py::arg("X"),  py::arg("Y")
          )
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&Aspect_CircularGrid::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&Aspect_CircularGrid::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (Aspect_CircularGrid::*)() const) static_cast< const handle<Standard_Type> & (Aspect_CircularGrid::*)() const>(&Aspect_CircularGrid::DynamicType),
             R"#()#"
             
         )
;

    // Class Aspect_GradientBackground from ./opencascade/Aspect_GradientBackground.hxx
    klass = m.attr("Aspect_GradientBackground");


    // nested enums

    static_cast<py::class_<Aspect_GradientBackground , shared_ptr<Aspect_GradientBackground>  , Aspect_Background >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const Quantity_Color &, const Quantity_Color &, const Aspect_GradientFillMethod >()  , py::arg("theColor1"),  py::arg("theColor2"),  py::arg("theMethod")=static_cast< const Aspect_GradientFillMethod>(Aspect_GradientFillMethod_Horizontal) )
    // custom constructors
    // methods
        .def("SetColors",
             (void (Aspect_GradientBackground::*)(  const Quantity_Color & ,   const Quantity_Color & ,   const Aspect_GradientFillMethod  ) ) static_cast<void (Aspect_GradientBackground::*)(  const Quantity_Color & ,   const Quantity_Color & ,   const Aspect_GradientFillMethod  ) >(&Aspect_GradientBackground::SetColors),
             R"#(Modifies the colours of the window gradient background.)#"  , py::arg("theColor1"),  py::arg("theColor2"),  py::arg("theMethod")=static_cast< const Aspect_GradientFillMethod>(Aspect_GradientFillMethod_Horizontal)
          )
        .def("Colors",
             (void (Aspect_GradientBackground::*)( Quantity_Color & ,  Quantity_Color &  ) const) static_cast<void (Aspect_GradientBackground::*)( Quantity_Color & ,  Quantity_Color &  ) const>(&Aspect_GradientBackground::Colors),
             R"#(Returns colours of the window gradient background.)#"  , py::arg("theColor1"),  py::arg("theColor2")
          )
        .def("BgGradientFillMethod",
             (Aspect_GradientFillMethod (Aspect_GradientBackground::*)() const) static_cast<Aspect_GradientFillMethod (Aspect_GradientBackground::*)() const>(&Aspect_GradientBackground::BgGradientFillMethod),
             R"#(Returns the current gradient background fill mode.)#" 
          )
        .def("DumpJson",
             (void (Aspect_GradientBackground::*)( Standard_OStream & ,  int  ) const) static_cast<void (Aspect_GradientBackground::*)( Standard_OStream & ,  int  ) const>(&Aspect_GradientBackground::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Aspect_NeutralWindow from ./opencascade/Aspect_NeutralWindow.hxx
    klass = m.attr("Aspect_NeutralWindow");


    // nested enums

    static_cast<py::class_<Aspect_NeutralWindow ,opencascade::handle<Aspect_NeutralWindow>  , Aspect_Window >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("NativeHandle",
             (Aspect_Drawable (Aspect_NeutralWindow::*)() const) static_cast<Aspect_Drawable (Aspect_NeutralWindow::*)() const>(&Aspect_NeutralWindow::NativeHandle),
             R"#(Return native handle of this drawable.)#" 
          )
        .def("NativeParentHandle",
             (Aspect_Drawable (Aspect_NeutralWindow::*)() const) static_cast<Aspect_Drawable (Aspect_NeutralWindow::*)() const>(&Aspect_NeutralWindow::NativeParentHandle),
             R"#(Return native handle of the parent drawable.)#" 
          )
        .def("SetNativeHandle",
             (bool (Aspect_NeutralWindow::*)( Aspect_Drawable  ) ) static_cast<bool (Aspect_NeutralWindow::*)( Aspect_Drawable  ) >(&Aspect_NeutralWindow::SetNativeHandle),
             R"#(Set native handle.)#"  , py::arg("theWindow")
          )
        .def("IsMapped",
             (bool (Aspect_NeutralWindow::*)() const) static_cast<bool (Aspect_NeutralWindow::*)() const>(&Aspect_NeutralWindow::IsMapped),
             R"#(Return true if window is not hidden.)#" 
          )
        .def("Map",
             (void (Aspect_NeutralWindow::*)() const) static_cast<void (Aspect_NeutralWindow::*)() const>(&Aspect_NeutralWindow::Map),
             R"#(Change window mapped flag to TRUE.)#" 
          )
        .def("Unmap",
             (void (Aspect_NeutralWindow::*)() const) static_cast<void (Aspect_NeutralWindow::*)() const>(&Aspect_NeutralWindow::Unmap),
             R"#(Change window mapped flag to FALSE.)#" 
          )
        .def("DoResize",
             (Aspect_TypeOfResize (Aspect_NeutralWindow::*)() ) static_cast<Aspect_TypeOfResize (Aspect_NeutralWindow::*)() >(&Aspect_NeutralWindow::DoResize),
             R"#(Resize window - do nothing.)#" 
          )
        .def("DoMapping",
             (bool (Aspect_NeutralWindow::*)() const) static_cast<bool (Aspect_NeutralWindow::*)() const>(&Aspect_NeutralWindow::DoMapping),
             R"#(Map window - do nothing.)#" 
          )
        .def("Ratio",
             (double (Aspect_NeutralWindow::*)() const) static_cast<double (Aspect_NeutralWindow::*)() const>(&Aspect_NeutralWindow::Ratio),
             R"#(Returns window ratio equal to the physical width/height dimensions.)#" 
          )
        .def("SetPosition",
             (bool (Aspect_NeutralWindow::*)( int ,  int  ) ) static_cast<bool (Aspect_NeutralWindow::*)( int ,  int  ) >(&Aspect_NeutralWindow::SetPosition),
             R"#(Set the window position.)#"  , py::arg("theX1"),  py::arg("theY1")
          )
        .def("SetPosition",
             (bool (Aspect_NeutralWindow::*)( int ,  int ,  int ,  int  ) ) static_cast<bool (Aspect_NeutralWindow::*)( int ,  int ,  int ,  int  ) >(&Aspect_NeutralWindow::SetPosition),
             R"#(Set the window position.)#"  , py::arg("theX1"),  py::arg("theY1"),  py::arg("theX2"),  py::arg("theY2")
          )
        .def("SetSize",
             (bool (Aspect_NeutralWindow::*)(  const int ,   const int  ) ) static_cast<bool (Aspect_NeutralWindow::*)(  const int ,   const int  ) >(&Aspect_NeutralWindow::SetSize),
             R"#(Set the window size.)#"  , py::arg("theWidth"),  py::arg("theHeight")
          )
    // methods using call by reference i.s.o. return
        .def("Position",
             []( Aspect_NeutralWindow &self   ){
                 int  theX1;
                int  theY1;
                int  theX2;
                int  theY2;

                 self.Position(theX1,theY1,theX2,theY2);
                 return std::make_tuple(theX1,theY1,theX2,theY2); },
             R"#(Return the window position.)#" 
          )
        .def("Size",
             []( Aspect_NeutralWindow &self   ){
                 int  theWidth;
                int  theHeight;

                 self.Size(theWidth,theHeight);
                 return std::make_tuple(theWidth,theHeight); },
             R"#(Return the window size.)#" 
          )
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&Aspect_NeutralWindow::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&Aspect_NeutralWindow::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (Aspect_NeutralWindow::*)() const) static_cast< const handle<Standard_Type> & (Aspect_NeutralWindow::*)() const>(&Aspect_NeutralWindow::DynamicType),
             R"#()#"
             
         )
;

    // Class Aspect_OpenVRSession from ./opencascade/Aspect_OpenVRSession.hxx
    klass = m.attr("Aspect_OpenVRSession");


    // nested enums

    static_cast<py::class_<Aspect_OpenVRSession ,opencascade::handle<Aspect_OpenVRSession>  , Aspect_XRSession >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("IsOpen",
             (bool (Aspect_OpenVRSession::*)() const) static_cast<bool (Aspect_OpenVRSession::*)() const>(&Aspect_OpenVRSession::IsOpen),
             R"#(Return TRUE if session is opened.)#" 
          )
        .def("Open",
             (bool (Aspect_OpenVRSession::*)() ) static_cast<bool (Aspect_OpenVRSession::*)() >(&Aspect_OpenVRSession::Open),
             R"#(Initialize session.)#" 
          )
        .def("Close",
             (void (Aspect_OpenVRSession::*)() ) static_cast<void (Aspect_OpenVRSession::*)() >(&Aspect_OpenVRSession::Close),
             R"#(Release session.)#" 
          )
        .def("WaitPoses",
             (bool (Aspect_OpenVRSession::*)() ) static_cast<bool (Aspect_OpenVRSession::*)() >(&Aspect_OpenVRSession::WaitPoses),
             R"#(Fetch actual poses of tracked devices.)#" 
          )
        .def("RecommendedViewport",
             (NCollection_Vec2<int> (Aspect_OpenVRSession::*)() const) static_cast<NCollection_Vec2<int> (Aspect_OpenVRSession::*)() const>(&Aspect_OpenVRSession::RecommendedViewport),
             R"#(Return recommended viewport Width x Height for rendering into VR.)#" 
          )
        .def("EyeToHeadTransform",
             (NCollection_Mat4<double> (Aspect_OpenVRSession::*)( Aspect_Eye  ) const) static_cast<NCollection_Mat4<double> (Aspect_OpenVRSession::*)( Aspect_Eye  ) const>(&Aspect_OpenVRSession::EyeToHeadTransform),
             R"#(Return transformation from eye to head. vr::GetEyeToHeadTransform() wrapper.)#"  , py::arg("theEye")
          )
        .def("ProjectionMatrix",
             (NCollection_Mat4<double> (Aspect_OpenVRSession::*)( Aspect_Eye ,  double ,  double  ) const) static_cast<NCollection_Mat4<double> (Aspect_OpenVRSession::*)( Aspect_Eye ,  double ,  double  ) const>(&Aspect_OpenVRSession::ProjectionMatrix),
             R"#(Return projection matrix.)#"  , py::arg("theEye"),  py::arg("theZNear"),  py::arg("theZFar")
          )
        .def("HasProjectionFrustums",
             (bool (Aspect_OpenVRSession::*)() const) static_cast<bool (Aspect_OpenVRSession::*)() const>(&Aspect_OpenVRSession::HasProjectionFrustums),
             R"#(Return TRUE.)#" 
          )
        .def("ProcessEvents",
             (void (Aspect_OpenVRSession::*)() ) static_cast<void (Aspect_OpenVRSession::*)() >(&Aspect_OpenVRSession::ProcessEvents),
             R"#(Receive XR events.)#" 
          )
        .def("SubmitEye",
             (bool (Aspect_OpenVRSession::*)( void * ,  Aspect_GraphicsLibrary ,  Aspect_ColorSpace ,  Aspect_Eye  ) ) static_cast<bool (Aspect_OpenVRSession::*)( void * ,  Aspect_GraphicsLibrary ,  Aspect_ColorSpace ,  Aspect_Eye  ) >(&Aspect_OpenVRSession::SubmitEye),
             R"#(Submit texture eye to XR Composer.)#"  , py::arg("theTexture"),  py::arg("theGraphicsLib"),  py::arg("theColorSpace"),  py::arg("theEye")
          )
        .def("GetString",
             (TCollection_AsciiString (Aspect_OpenVRSession::*)( Aspect_XRSession::InfoString  ) const) static_cast<TCollection_AsciiString (Aspect_OpenVRSession::*)( Aspect_XRSession::InfoString  ) const>(&Aspect_OpenVRSession::GetString),
             R"#(Query information.)#"  , py::arg("theInfo")
          )
        .def("NamedTrackedDevice",
             (int (Aspect_OpenVRSession::*)( Aspect_XRTrackedDeviceRole  ) const) static_cast<int (Aspect_OpenVRSession::*)( Aspect_XRTrackedDeviceRole  ) const>(&Aspect_OpenVRSession::NamedTrackedDevice),
             R"#(Return index of tracked device of known role.)#"  , py::arg("theDevice")
          )
        .def("GetDigitalActionData",
             (Aspect_XRDigitalActionData (Aspect_OpenVRSession::*)(  const handle<Aspect_XRAction> &  ) const) static_cast<Aspect_XRDigitalActionData (Aspect_OpenVRSession::*)(  const handle<Aspect_XRAction> &  ) const>(&Aspect_OpenVRSession::GetDigitalActionData),
             R"#(Fetch data for digital input action (like button).)#"  , py::arg("theAction")
          )
        .def("GetAnalogActionData",
             (Aspect_XRAnalogActionData (Aspect_OpenVRSession::*)(  const handle<Aspect_XRAction> &  ) const) static_cast<Aspect_XRAnalogActionData (Aspect_OpenVRSession::*)(  const handle<Aspect_XRAction> &  ) const>(&Aspect_OpenVRSession::GetAnalogActionData),
             R"#(Fetch data for analog input action (like axis).)#"  , py::arg("theAction")
          )
        .def("GetPoseActionDataForNextFrame",
             (Aspect_XRPoseActionData (Aspect_OpenVRSession::*)(  const handle<Aspect_XRAction> &  ) const) static_cast<Aspect_XRPoseActionData (Aspect_OpenVRSession::*)(  const handle<Aspect_XRAction> &  ) const>(&Aspect_OpenVRSession::GetPoseActionDataForNextFrame),
             R"#(Fetch data for pose input action (like fingertip position).)#"  , py::arg("theAction")
          )
        .def("SetTrackingOrigin",
             (void (Aspect_OpenVRSession::*)( Aspect_XRSession::TrackingUniverseOrigin  ) ) static_cast<void (Aspect_OpenVRSession::*)( Aspect_XRSession::TrackingUniverseOrigin  ) >(&Aspect_OpenVRSession::SetTrackingOrigin),
             R"#(Set tracking origin.)#"  , py::arg("theOrigin")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&Aspect_OpenVRSession::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&Aspect_OpenVRSession::get_type_descriptor),
                    R"#()#" 
          )
        .def_static("IsHmdPresent_s",
                    (bool (*)() ) static_cast<bool (*)() >(&Aspect_OpenVRSession::IsHmdPresent),
                    R"#(Return TRUE if an HMD may be presented on the system (e.g. to show VR checkbox in application GUI). This is fast check, and even if it returns TRUE, opening session may fail.)#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (Aspect_OpenVRSession::*)() const) static_cast< const handle<Standard_Type> & (Aspect_OpenVRSession::*)() const>(&Aspect_OpenVRSession::DynamicType),
             R"#()#"
             
         )
;

    // Class Aspect_RectangularGrid from ./opencascade/Aspect_RectangularGrid.hxx
    klass = m.attr("Aspect_RectangularGrid");


    // nested enums

    static_cast<py::class_<Aspect_RectangularGrid ,opencascade::handle<Aspect_RectangularGrid> ,Py_Aspect_RectangularGrid , Aspect_Grid >>(klass)
    // constructors
        .def(py::init<  const double, const double, const double, const double, const double, const double, const double >()  , py::arg("aXStep"),  py::arg("aYStep"),  py::arg("anXOrigin")=static_cast< const double>(0),  py::arg("anYOrigin")=static_cast< const double>(0),  py::arg("aFirstAngle")=static_cast< const double>(0),  py::arg("aSecondAngle")=static_cast< const double>(0),  py::arg("aRotationAngle")=static_cast< const double>(0) )
    // custom constructors
    // methods
        .def("SetXStep",
             (void (Aspect_RectangularGrid::*)(  const double  ) ) static_cast<void (Aspect_RectangularGrid::*)(  const double  ) >(&Aspect_RectangularGrid::SetXStep),
             R"#(defines the x step of the grid.)#"  , py::arg("aStep")
          )
        .def("SetYStep",
             (void (Aspect_RectangularGrid::*)(  const double  ) ) static_cast<void (Aspect_RectangularGrid::*)(  const double  ) >(&Aspect_RectangularGrid::SetYStep),
             R"#(defines the y step of the grid.)#"  , py::arg("aStep")
          )
        .def("SetAngle",
             (void (Aspect_RectangularGrid::*)(  const double ,   const double  ) ) static_cast<void (Aspect_RectangularGrid::*)(  const double ,   const double  ) >(&Aspect_RectangularGrid::SetAngle),
             R"#(defines the angle of the second network the fist angle is given relatively to the horizontal. the second angle is given relatively to the vertical.)#"  , py::arg("anAngle1"),  py::arg("anAngle2")
          )
        .def("SetGridValues",
             (void (Aspect_RectangularGrid::*)(  const double ,   const double ,   const double ,   const double ,   const double  ) ) static_cast<void (Aspect_RectangularGrid::*)(  const double ,   const double ,   const double ,   const double ,   const double  ) >(&Aspect_RectangularGrid::SetGridValues),
             R"#()#"  , py::arg("XOrigin"),  py::arg("YOrigin"),  py::arg("XStep"),  py::arg("YStep"),  py::arg("RotationAngle")
          )
        .def("XStep",
             (double (Aspect_RectangularGrid::*)() const) static_cast<double (Aspect_RectangularGrid::*)() const>(&Aspect_RectangularGrid::XStep),
             R"#(returns the x step of the grid.)#" 
          )
        .def("YStep",
             (double (Aspect_RectangularGrid::*)() const) static_cast<double (Aspect_RectangularGrid::*)() const>(&Aspect_RectangularGrid::YStep),
             R"#(returns the x step of the grid.)#" 
          )
        .def("FirstAngle",
             (double (Aspect_RectangularGrid::*)() const) static_cast<double (Aspect_RectangularGrid::*)() const>(&Aspect_RectangularGrid::FirstAngle),
             R"#(returns the x Angle of the grid, relatively to the horizontal.)#" 
          )
        .def("SecondAngle",
             (double (Aspect_RectangularGrid::*)() const) static_cast<double (Aspect_RectangularGrid::*)() const>(&Aspect_RectangularGrid::SecondAngle),
             R"#(returns the y Angle of the grid, relatively to the vertical.)#" 
          )
        .def("SetSizeX",
             (void (Aspect_RectangularGrid::*)(  const double  ) ) static_cast<void (Aspect_RectangularGrid::*)(  const double  ) >(&Aspect_RectangularGrid::SetSizeX),
             R"#(Set full extent of the bounded grid along the plane X direction (plane-local units). 0.0 (default) means unbounded - the shader draws the grid to the horizon.)#"  , py::arg("theSize")
          )
        .def("SizeX",
             (double (Aspect_RectangularGrid::*)() const) static_cast<double (Aspect_RectangularGrid::*)() const>(&Aspect_RectangularGrid::SizeX),
             R"#(Return the bounded-region extent along plane X. 0.0 means unbounded.)#" 
          )
        .def("SetSizeY",
             (void (Aspect_RectangularGrid::*)(  const double  ) ) static_cast<void (Aspect_RectangularGrid::*)(  const double  ) >(&Aspect_RectangularGrid::SetSizeY),
             R"#(Set full extent of the bounded grid along the plane Y direction (plane-local units). 0.0 (default) means unbounded.)#"  , py::arg("theSize")
          )
        .def("SizeY",
             (double (Aspect_RectangularGrid::*)() const) static_cast<double (Aspect_RectangularGrid::*)() const>(&Aspect_RectangularGrid::SizeY),
             R"#(Return the bounded-region extent along plane Y. 0.0 means unbounded.)#" 
          )
        .def("SetZOffset",
             (void (Aspect_RectangularGrid::*)(  const double  ) ) static_cast<void (Aspect_RectangularGrid::*)(  const double  ) >(&Aspect_RectangularGrid::SetZOffset),
             R"#(Set signed offset (plane-local units) applied along the plane normal for display only - snap math stays on the plane. Use a small negative value to push the grid slightly below coplanar geometry and avoid z-fighting.)#"  , py::arg("theOffset")
          )
        .def("ZOffset",
             (double (Aspect_RectangularGrid::*)() const) static_cast<double (Aspect_RectangularGrid::*)() const>(&Aspect_RectangularGrid::ZOffset),
             R"#(Return the display-time Z-offset along the plane normal.)#" 
          )
        .def("Init",
             (void (Aspect_RectangularGrid::*)() ) static_cast<void (Aspect_RectangularGrid::*)() >(&Aspect_RectangularGrid::Init),
             R"#()#" 
          )
        .def("DumpJson",
             (void (Aspect_RectangularGrid::*)( Standard_OStream & ,  int  ) const) static_cast<void (Aspect_RectangularGrid::*)( Standard_OStream & ,  int  ) const>(&Aspect_RectangularGrid::DumpJson),
             R"#(Dumps the content of me into the stream)#"  , py::arg("theOStream"),  py::arg("theDepth")=static_cast<int>(- 1)
          )
    // methods using call by reference i.s.o. return
        .def("Compute",
             []( Aspect_RectangularGrid &self ,  const double X, const double Y ){
                 double  gridX;
                double  gridY;

                 self.Compute(X,Y,gridX,gridY);
                 return std::make_tuple(gridX,gridY); },
             R"#(returns the point of the grid the closest to the point X,Y)#"  , py::arg("X"),  py::arg("Y")
          )
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&Aspect_RectangularGrid::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&Aspect_RectangularGrid::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (Aspect_RectangularGrid::*)() const) static_cast< const handle<Standard_Type> & (Aspect_RectangularGrid::*)() const>(&Aspect_RectangularGrid::DynamicType),
             R"#()#"
             
         )
;

// functions

// ./opencascade/Aspect_AspectFillAreaDefinitionError.hxx
// ./opencascade/Aspect_AspectLineDefinitionError.hxx
// ./opencascade/Aspect_AspectMarkerDefinitionError.hxx
// ./opencascade/Aspect_Background.hxx
// ./opencascade/Aspect_CircularGrid.hxx
// ./opencascade/Aspect_ColorSpace.hxx
// ./opencascade/Aspect_Display.hxx
// ./opencascade/Aspect_DisplayConnection.hxx
// ./opencascade/Aspect_DisplayConnectionDefinitionError.hxx
// ./opencascade/Aspect_Drawable.hxx
// ./opencascade/Aspect_Eye.hxx
// ./opencascade/Aspect_FBConfig.hxx
// ./opencascade/Aspect_FillMethod.hxx
// ./opencascade/Aspect_FrustumLRBT.hxx
// ./opencascade/Aspect_GenId.hxx
// ./opencascade/Aspect_GradientBackground.hxx
// ./opencascade/Aspect_GradientFillMethod.hxx
// ./opencascade/Aspect_GraphicDeviceDefinitionError.hxx
// ./opencascade/Aspect_GraphicsLibrary.hxx
// ./opencascade/Aspect_Grid.hxx
// ./opencascade/Aspect_GridDrawMode.hxx
// ./opencascade/Aspect_GridParams.hxx
// ./opencascade/Aspect_GridType.hxx
// ./opencascade/Aspect_Handle.hxx
// ./opencascade/Aspect_HatchStyle.hxx
// ./opencascade/Aspect_IdentDefinitionError.hxx
// ./opencascade/Aspect_InteriorStyle.hxx
// ./opencascade/Aspect_NeutralWindow.hxx
// ./opencascade/Aspect_OpenVRSession.hxx
// ./opencascade/Aspect_PolygonOffsetMode.hxx
// ./opencascade/Aspect_RectangularGrid.hxx
// ./opencascade/Aspect_RenderingContext.hxx
// ./opencascade/Aspect_ScrollDelta.hxx
// ./opencascade/Aspect_SkydomeBackground.hxx
// ./opencascade/Aspect_Touch.hxx
// ./opencascade/Aspect_TrackedDevicePose.hxx
// ./opencascade/Aspect_TypeOfColorScaleData.hxx
// ./opencascade/Aspect_TypeOfColorScaleOrientation.hxx
// ./opencascade/Aspect_TypeOfColorScalePosition.hxx
// ./opencascade/Aspect_TypeOfDeflection.hxx
// ./opencascade/Aspect_TypeOfDisplayText.hxx
// ./opencascade/Aspect_TypeOfFacingModel.hxx
// ./opencascade/Aspect_TypeOfHighlightMethod.hxx
// ./opencascade/Aspect_TypeOfLine.hxx
// ./opencascade/Aspect_TypeOfMarker.hxx
// ./opencascade/Aspect_TypeOfResize.hxx
// ./opencascade/Aspect_TypeOfStyleText.hxx
// ./opencascade/Aspect_TypeOfTriedronPosition.hxx
// ./opencascade/Aspect_Units.hxx
// ./opencascade/Aspect_VKey.hxx
    m.def("Aspect_VKey2Modifier",
          (Aspect_VKeyFlags (*)( Aspect_VKey  ))  static_cast<Aspect_VKeyFlags (*)( Aspect_VKey  )>(&Aspect_VKey2Modifier),
          R"#(Return modifier flags for specified modifier key.)#"  , py::arg("theKey")
          );
// ./opencascade/Aspect_VKeyFlags.hxx
// ./opencascade/Aspect_WidthOfLine.hxx
// ./opencascade/Aspect_Window.hxx
// ./opencascade/Aspect_WindowDefinitionError.hxx
// ./opencascade/Aspect_WindowError.hxx
// ./opencascade/Aspect_WindowInputListener.hxx
// ./opencascade/Aspect_XAtom.hxx
// ./opencascade/Aspect_XRAction.hxx
// ./opencascade/Aspect_XRActionSet.hxx
// ./opencascade/Aspect_XRActionType.hxx
// ./opencascade/Aspect_XRAnalogActionData.hxx
// ./opencascade/Aspect_XRDigitalActionData.hxx
// ./opencascade/Aspect_XRGenericAction.hxx
// ./opencascade/Aspect_XRHapticActionData.hxx
// ./opencascade/Aspect_XRPoseActionData.hxx
// ./opencascade/Aspect_XRSession.hxx
// ./opencascade/Aspect_XRTrackedDeviceRole.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions
register_occ_exception<Aspect_AspectFillAreaDefinitionError>(m, "Aspect_AspectFillAreaDefinitionError");
register_occ_exception<Aspect_AspectLineDefinitionError>(m, "Aspect_AspectLineDefinitionError");
register_occ_exception<Aspect_AspectMarkerDefinitionError>(m, "Aspect_AspectMarkerDefinitionError");
register_occ_exception<Aspect_DisplayConnectionDefinitionError>(m, "Aspect_DisplayConnectionDefinitionError");
register_occ_exception<Aspect_GraphicDeviceDefinitionError>(m, "Aspect_GraphicDeviceDefinitionError");
register_occ_exception<Aspect_IdentDefinitionError>(m, "Aspect_IdentDefinitionError");
register_occ_exception<Aspect_WindowDefinitionError>(m, "Aspect_WindowDefinitionError");
register_occ_exception<Aspect_WindowError>(m, "Aspect_WindowError");

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
