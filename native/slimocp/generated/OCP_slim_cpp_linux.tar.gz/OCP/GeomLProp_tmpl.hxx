#pragma once

#include <initializer_list>
using std::initializer_list;

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom_Curve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Geom2d_Curve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>

// module includes
#include <GeomLProp.hxx>
#include <GeomLProp_CLProps.hxx>
#include <GeomLProp_CurAndInf2d.hxx>
#include <GeomLProp_SLProps.hxx>
#include <GeomLProp_SurfaceUtils.hxx>

// user-defined pre
#include "OCP_specific.inc"

// Class template handling functions

template <typename Tool>
void preregister_template_LProp_SurfaceUtils__ToolAccess(py::object &m, const char *name){
    py::class_<LProp_SurfaceUtils::ToolAccess<Tool> , shared_ptr<LProp_SurfaceUtils::ToolAccess<Tool>> >(m,name,R"#(Tool-based access policy: delegates to static Tool methods. Used for HLRBRep types where Tool class provides the interface.)#");
}

template <typename Tool>
void register_template_LProp_SurfaceUtils__ToolAccess(py::object &m, const char *name){
    static_cast<py::class_<LProp_SurfaceUtils::ToolAccess<Tool> , shared_ptr<LProp_SurfaceUtils::ToolAccess<Tool>> >>(m.attr(name))
    ;
};

template <typename SurfaceType,typename Access=LProp_SurfaceUtils::DirectAccess>
void preregister_template_GeomLProp_SLPropsBase(py::object &m, const char *name){
    py::class_<GeomLProp_SLPropsBase<SurfaceType,Access> , shared_ptr<GeomLProp_SLPropsBase<SurfaceType,Access>> >(m,name,R"#(Template class for computing local properties of a 3D surface: point, first and second derivatives, tangent directions, normal, and curvature analysis (max, min, mean, Gaussian).)#");
}

template <typename SurfaceType,typename Access=LProp_SurfaceUtils::DirectAccess>
void register_template_GeomLProp_SLPropsBase(py::object &m, const char *name){
    static_cast<py::class_<GeomLProp_SLPropsBase<SurfaceType,Access> , shared_ptr<GeomLProp_SLPropsBase<SurfaceType,Access>> >>(m.attr(name))
        .def(py::init<  const SurfaceType &, const double, const double, const int, const double >() ,py::arg("S"), py::arg("U"), py::arg("V"), py::arg("N"), py::arg("Resolution") )
        .def(py::init<  const SurfaceType &, const int, const double >() ,py::arg("S"), py::arg("N"), py::arg("Resolution") )
        .def(py::init<  const int, const double >() ,py::arg("N"), py::arg("Resolution") )
        .def("SetSurface",
             (void (GeomLProp_SLPropsBase<SurfaceType,Access>::*)(  const SurfaceType &  ) ) &GeomLProp_SLPropsBase<SurfaceType,Access>::SetSurface,
             R"#(Initializes the local properties of the surface S for the new surface.)#" ,py::arg("S"))
        .def("SetParameters",
             (void (GeomLProp_SLPropsBase<SurfaceType,Access>::*)(  const double ,   const double  ) ) &GeomLProp_SLPropsBase<SurfaceType,Access>::SetParameters,
             R"#(Initializes the local properties of the surface S for the new parameter values (<U>, <V>).)#" ,py::arg("U"), py::arg("V"))
        .def("Value",
             ( const gp_Pnt & (GeomLProp_SLPropsBase<SurfaceType,Access>::*)() const) &GeomLProp_SLPropsBase<SurfaceType,Access>::Value,
             R"#(Returns the point.)#" )
        .def("D1U",
             ( const gp_Vec & (GeomLProp_SLPropsBase<SurfaceType,Access>::*)() ) &GeomLProp_SLPropsBase<SurfaceType,Access>::D1U,
             R"#(Returns the first U derivative. The derivative is computed if it has not been yet.)#" )
        .def("D1V",
             ( const gp_Vec & (GeomLProp_SLPropsBase<SurfaceType,Access>::*)() ) &GeomLProp_SLPropsBase<SurfaceType,Access>::D1V,
             R"#(Returns the first V derivative. The derivative is computed if it has not been yet.)#" )
        .def("D2U",
             ( const gp_Vec & (GeomLProp_SLPropsBase<SurfaceType,Access>::*)() ) &GeomLProp_SLPropsBase<SurfaceType,Access>::D2U,
             R"#(Returns the second U derivatives The derivative is computed if it has not been yet.)#" )
        .def("D2V",
             ( const gp_Vec & (GeomLProp_SLPropsBase<SurfaceType,Access>::*)() ) &GeomLProp_SLPropsBase<SurfaceType,Access>::D2V,
             R"#(Returns the second V derivative. The derivative is computed if it has not been yet.)#" )
        .def("DUV",
             ( const gp_Vec & (GeomLProp_SLPropsBase<SurfaceType,Access>::*)() ) &GeomLProp_SLPropsBase<SurfaceType,Access>::DUV,
             R"#(Returns the second UV cross-derivative. The derivative is computed if it has not been yet.)#" )
        .def("IsTangentUDefined",
             (bool (GeomLProp_SLPropsBase<SurfaceType,Access>::*)() ) &GeomLProp_SLPropsBase<SurfaceType,Access>::IsTangentUDefined,
             R"#(returns True if the U tangent is defined. For example, the tangent is not defined if the two first U derivatives are null.)#" )
        .def("TangentU",
             (void (GeomLProp_SLPropsBase<SurfaceType,Access>::*)( gp_Dir &  ) ) &GeomLProp_SLPropsBase<SurfaceType,Access>::TangentU,
             R"#(Returns the tangent direction <D> on the iso-V.)#" ,py::arg("D"))
        .def("IsTangentVDefined",
             (bool (GeomLProp_SLPropsBase<SurfaceType,Access>::*)() ) &GeomLProp_SLPropsBase<SurfaceType,Access>::IsTangentVDefined,
             R"#(returns if the V tangent is defined. For example, the tangent is not defined if the two first V derivatives are null.)#" )
        .def("TangentV",
             (void (GeomLProp_SLPropsBase<SurfaceType,Access>::*)( gp_Dir &  ) ) &GeomLProp_SLPropsBase<SurfaceType,Access>::TangentV,
             R"#(Returns the tangent direction <D> on the iso-V.)#" ,py::arg("D"))
        .def("IsNormalDefined",
             (bool (GeomLProp_SLPropsBase<SurfaceType,Access>::*)() ) &GeomLProp_SLPropsBase<SurfaceType,Access>::IsNormalDefined,
             R"#(Tells if the normal is defined.)#" )
        .def("Normal",
             ( const gp_Dir & (GeomLProp_SLPropsBase<SurfaceType,Access>::*)() ) &GeomLProp_SLPropsBase<SurfaceType,Access>::Normal,
             R"#(Returns the normal direction.)#" )
        .def("IsCurvatureDefined",
             (bool (GeomLProp_SLPropsBase<SurfaceType,Access>::*)() ) &GeomLProp_SLPropsBase<SurfaceType,Access>::IsCurvatureDefined,
             R"#(returns True if the curvature is defined.)#" )
        .def("IsUmbilic",
             (bool (GeomLProp_SLPropsBase<SurfaceType,Access>::*)() ) &GeomLProp_SLPropsBase<SurfaceType,Access>::IsUmbilic,
             R"#(returns True if the point is umbilic (i.e. if the curvature is constant).)#" )
        .def("MaxCurvature",
             (double (GeomLProp_SLPropsBase<SurfaceType,Access>::*)() ) &GeomLProp_SLPropsBase<SurfaceType,Access>::MaxCurvature,
             R"#(Returns the maximum curvature)#" )
        .def("MinCurvature",
             (double (GeomLProp_SLPropsBase<SurfaceType,Access>::*)() ) &GeomLProp_SLPropsBase<SurfaceType,Access>::MinCurvature,
             R"#(Returns the minimum curvature)#" )
        .def("CurvatureDirections",
             (void (GeomLProp_SLPropsBase<SurfaceType,Access>::*)( gp_Dir & ,  gp_Dir &  ) ) &GeomLProp_SLPropsBase<SurfaceType,Access>::CurvatureDirections,
             R"#(Returns the direction of the maximum and minimum curvature <MaxD> and <MinD>)#" ,py::arg("MaxD"), py::arg("MinD"))
        .def("MeanCurvature",
             (double (GeomLProp_SLPropsBase<SurfaceType,Access>::*)() ) &GeomLProp_SLPropsBase<SurfaceType,Access>::MeanCurvature,
             R"#(Returns the mean curvature.)#" )
        .def("GaussianCurvature",
             (double (GeomLProp_SLPropsBase<SurfaceType,Access>::*)() ) &GeomLProp_SLPropsBase<SurfaceType,Access>::GaussianCurvature,
             R"#(Returns the Gaussian curvature)#" )
    ;
};

template <typename Pnt,typename Vec,typename Dir,typename CurveType,typename Access=LProp_CurveUtils::DirectAccess>
void preregister_template_GeomLProp_CLPropsBase(py::object &m, const char *name){
    py::class_<GeomLProp_CLPropsBase<Pnt,Vec,Dir,CurveType,Access> , shared_ptr<GeomLProp_CLPropsBase<Pnt,Vec,Dir,CurveType,Access>> >(m,name,R"#(Implementation class for computing local properties of a curve: point, derivatives up to order 3, tangent, curvature, normal, and centre of curvature. Parameterized by geometric types (Pnt/Vec/Dir) and curve type.)#");
}

template <typename Pnt,typename Vec,typename Dir,typename CurveType,typename Access=LProp_CurveUtils::DirectAccess>
void register_template_GeomLProp_CLPropsBase(py::object &m, const char *name){
    static_cast<py::class_<GeomLProp_CLPropsBase<Pnt,Vec,Dir,CurveType,Access> , shared_ptr<GeomLProp_CLPropsBase<Pnt,Vec,Dir,CurveType,Access>> >>(m.attr(name))
        .def(py::init<  const CurveType &, const int, const double >() ,py::arg("C"), py::arg("N"), py::arg("Resolution") )
        .def(py::init<  const CurveType &, const double, const int, const double >() ,py::arg("C"), py::arg("U"), py::arg("N"), py::arg("Resolution") )
        .def(py::init<  const int, const double >() ,py::arg("N"), py::arg("Resolution") )
        .def("SetParameter",
             (void (GeomLProp_CLPropsBase<Pnt,Vec,Dir,CurveType,Access>::*)(  const double  ) ) &GeomLProp_CLPropsBase<Pnt,Vec,Dir,CurveType,Access>::SetParameter,
             R"#(Initializes the local properties of the curve for the parameter value <U>.)#" ,py::arg("U"))
        .def("SetCurve",
             (void (GeomLProp_CLPropsBase<Pnt,Vec,Dir,CurveType,Access>::*)(  const CurveType &  ) ) &GeomLProp_CLPropsBase<Pnt,Vec,Dir,CurveType,Access>::SetCurve,
             R"#(Initializes the local properties of the curve for the new curve.)#" ,py::arg("C"))
        .def("Value",
             ( const Pnt & (GeomLProp_CLPropsBase<Pnt,Vec,Dir,CurveType,Access>::*)() const) &GeomLProp_CLPropsBase<Pnt,Vec,Dir,CurveType,Access>::Value,
             R"#(Returns the Point.)#" )
        .def("D1",
             ( const Vec & (GeomLProp_CLPropsBase<Pnt,Vec,Dir,CurveType,Access>::*)() ) &GeomLProp_CLPropsBase<Pnt,Vec,Dir,CurveType,Access>::D1,
             R"#(Returns the first derivative. The derivative is computed if it has not been yet.)#" )
        .def("D2",
             ( const Vec & (GeomLProp_CLPropsBase<Pnt,Vec,Dir,CurveType,Access>::*)() ) &GeomLProp_CLPropsBase<Pnt,Vec,Dir,CurveType,Access>::D2,
             R"#(Returns the second derivative. The derivative is computed if it has not been yet.)#" )
        .def("D3",
             ( const Vec & (GeomLProp_CLPropsBase<Pnt,Vec,Dir,CurveType,Access>::*)() ) &GeomLProp_CLPropsBase<Pnt,Vec,Dir,CurveType,Access>::D3,
             R"#(Returns the third derivative. The derivative is computed if it has not been yet.)#" )
        .def("IsTangentDefined",
             (bool (GeomLProp_CLPropsBase<Pnt,Vec,Dir,CurveType,Access>::*)() ) &GeomLProp_CLPropsBase<Pnt,Vec,Dir,CurveType,Access>::IsTangentDefined,
             R"#(Returns True if the tangent is defined. For example, the tangent is not defined if the three first derivatives are all null.)#" )
        .def("Tangent",
             (void (GeomLProp_CLPropsBase<Pnt,Vec,Dir,CurveType,Access>::*)( Dir &  ) ) &GeomLProp_CLPropsBase<Pnt,Vec,Dir,CurveType,Access>::Tangent,
             R"#(output the tangent direction <D>.)#" ,py::arg("D"))
        .def("Curvature",
             (double (GeomLProp_CLPropsBase<Pnt,Vec,Dir,CurveType,Access>::*)() ) &GeomLProp_CLPropsBase<Pnt,Vec,Dir,CurveType,Access>::Curvature,
             R"#(Returns the curvature.)#" )
        .def("Normal",
             (void (GeomLProp_CLPropsBase<Pnt,Vec,Dir,CurveType,Access>::*)( Dir &  ) ) &GeomLProp_CLPropsBase<Pnt,Vec,Dir,CurveType,Access>::Normal,
             R"#(Returns the normal direction <N>.)#" ,py::arg("N"))
        .def("CentreOfCurvature",
             (void (GeomLProp_CLPropsBase<Pnt,Vec,Dir,CurveType,Access>::*)( Pnt &  ) ) &GeomLProp_CLPropsBase<Pnt,Vec,Dir,CurveType,Access>::CentreOfCurvature,
             R"#(Returns the centre of curvature <P>.)#" ,py::arg("P"))
    ;
};


// user-defined post

