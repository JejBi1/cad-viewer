
// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;


// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Extrema_ExtElC.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Extrema_ExtElC2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Lin.hxx>
#include <gp_Circ.hxx>
#include <gp_Elips.hxx>
#include <gp_Hypr.hxx>
#include <gp_Parab.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Lin2d.hxx>
#include <gp_Circ2d.hxx>
#include <gp_Elips2d.hxx>
#include <gp_Hypr2d.hxx>
#include <gp_Parab2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Lin.hxx>
#include <gp_Pln.hxx>
#include <gp_Cylinder.hxx>
#include <gp_Cone.hxx>
#include <gp_Sphere.hxx>
#include <gp_Torus.hxx>
#include <gp_Circ.hxx>
#include <gp_Hypr.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Pln.hxx>
#include <gp_Sphere.hxx>
#include <gp_Cylinder.hxx>
#include <gp_Cone.hxx>
#include <gp_Torus.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Lin.hxx>
#include <gp_Circ.hxx>
#include <gp_Elips.hxx>
#include <gp_Hypr.hxx>
#include <gp_Parab.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Lin2d.hxx>
#include <gp_Circ2d.hxx>
#include <gp_Elips2d.hxx>
#include <gp_Hypr2d.hxx>
#include <gp_Parab2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <gp_Cylinder.hxx>
#include <gp_Pln.hxx>
#include <gp_Cone.hxx>
#include <gp_Torus.hxx>
#include <gp_Sphere.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Extrema_ExtPExtS.hxx>
#include <Extrema_ExtPRevS.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <Extrema_CCLocFOfLocECC.hxx>
#include <Extrema_CCLocFOfLocECC2d.hxx>
#include <Extrema_Curve2dTool.hxx>
#include <Extrema_CurveTool.hxx>
#include <Extrema_ECC.hxx>
#include <Extrema_ECC2d.hxx>
#include <Extrema_ElementType.hxx>
#include <Extrema_ELPCOfLocateExtPC.hxx>
#include <Extrema_ELPCOfLocateExtPC2d.hxx>
#include <Extrema_EPCOfELPCOfLocateExtPC.hxx>
#include <Extrema_EPCOfELPCOfLocateExtPC2d.hxx>
#include <Extrema_EPCOfExtPC.hxx>
#include <Extrema_EPCOfExtPC2d.hxx>
#include <Extrema_ExtAlgo.hxx>
#include <Extrema_ExtCC.hxx>
#include <Extrema_ExtCC2d.hxx>
#include <Extrema_ExtCS.hxx>
#include <Extrema_ExtElC.hxx>
#include <Extrema_ExtElC2d.hxx>
#include <Extrema_ExtElCS.hxx>
#include <Extrema_ExtElSS.hxx>
#include <Extrema_ExtFlag.hxx>
#include <Extrema_ExtPC.hxx>
#include <Extrema_ExtPC2d.hxx>
#include <Extrema_ExtPElC.hxx>
#include <Extrema_ExtPElC2d.hxx>
#include <Extrema_ExtPElS.hxx>
#include <Extrema_ExtPExtS.hxx>
#include <Extrema_ExtPRevS.hxx>
#include <Extrema_ExtPS.hxx>
#include <Extrema_ExtSS.hxx>
#include <Extrema_FuncExtCS.hxx>
#include <Extrema_FuncExtSS.hxx>
#include <Extrema_FuncPSDist.hxx>
#include <Extrema_FuncPSNorm.hxx>
#include <Extrema_GCurveLocator.hxx>
#include <Extrema_GenExtCS.hxx>
#include <Extrema_GenExtPS.hxx>
#include <Extrema_GenExtSS.hxx>
#include <Extrema_GenLocateExtCC.hxx>
#include <Extrema_GenLocateExtCS.hxx>
#include <Extrema_GenLocateExtPC.hxx>
#include <Extrema_GenLocateExtPS.hxx>
#include <Extrema_GenLocateExtSS.hxx>
#include <Extrema_GFuncExtCC.hxx>
#include <Extrema_GFuncExtPC.hxx>
#include <Extrema_GGenExtPC.hxx>
#include <Extrema_GGExtPC.hxx>
#include <Extrema_GlobOptFuncCC.hxx>
#include <Extrema_GlobOptFuncConicS.hxx>
#include <Extrema_GlobOptFuncCQuadric.hxx>
#include <Extrema_GlobOptFuncCS.hxx>
#include <Extrema_GLocateExtPC.hxx>
#include <Extrema_LocateExtCC.hxx>
#include <Extrema_LocateExtCC2d.hxx>
#include <Extrema_LocateExtPC.hxx>
#include <Extrema_LocateExtPC2d.hxx>
#include <Extrema_LocECC.hxx>
#include <Extrema_LocECC2d.hxx>
#include <Extrema_LocEPCOfLocateExtPC.hxx>
#include <Extrema_LocEPCOfLocateExtPC2d.hxx>
#include <Extrema_PCFOfEPCOfELPCOfLocateExtPC.hxx>
#include <Extrema_PCFOfEPCOfELPCOfLocateExtPC2d.hxx>
#include <Extrema_PCFOfEPCOfExtPC.hxx>
#include <Extrema_PCFOfEPCOfExtPC2d.hxx>
#include <Extrema_PCLocFOfLocEPCOfLocateExtPC.hxx>
#include <Extrema_PCLocFOfLocEPCOfLocateExtPC2d.hxx>
#include <Extrema_POnCurv.hxx>
#include <Extrema_POnCurv2d.hxx>
#include <Extrema_POnSurf.hxx>
#include <Extrema_POnSurfParams.hxx>

// template related includes

#include "math_tmpl.hxx"

#include "Extrema_tmpl.hxx"

#include "Extrema_tmpl.hxx"

#include "Extrema_tmpl.hxx"

#include "Extrema_tmpl.hxx"

#include "Extrema_tmpl.hxx"

#include "Extrema_tmpl.hxx"

#include "Extrema_tmpl.hxx"

#include "Extrema_tmpl.hxx"

#include "Extrema_tmpl.hxx"

#include "Extrema_tmpl.hxx"

#include "Extrema_tmpl.hxx"

#include "Extrema_tmpl.hxx"

#include "Extrema_tmpl.hxx"

#include "Extrema_tmpl.hxx"


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_Extrema_enums(py::module &main_module) {


py::module m = main_module.def_submodule("Extrema", R"#()#");

// add namespaces as submodules

// user-defined inclusion per module in the body

// enums
    py::enum_<Extrema_ElementType>(m, "Extrema_ElementType",R"#()#")
        .value("Extrema_Node",Extrema_ElementType::Extrema_Node)
        .value("Extrema_UIsoEdge",Extrema_ElementType::Extrema_UIsoEdge)
        .value("Extrema_VIsoEdge",Extrema_ElementType::Extrema_VIsoEdge)
        .value("Extrema_Face",Extrema_ElementType::Extrema_Face).export_values();
    py::enum_<Extrema_ExtAlgo>(m, "Extrema_ExtAlgo",R"#()#")
        .value("Extrema_ExtAlgo_Grad",Extrema_ExtAlgo::Extrema_ExtAlgo_Grad)
        .value("Extrema_ExtAlgo_Tree",Extrema_ExtAlgo::Extrema_ExtAlgo_Tree).export_values();
    py::enum_<Extrema_ExtFlag>(m, "Extrema_ExtFlag",R"#()#")
        .value("Extrema_ExtFlag_MIN",Extrema_ExtFlag::Extrema_ExtFlag_MIN)
        .value("Extrema_ExtFlag_MAX",Extrema_ExtFlag::Extrema_ExtFlag_MAX)
        .value("Extrema_ExtFlag_MINMAX",Extrema_ExtFlag::Extrema_ExtFlag_MINMAX).export_values();

//Python trampoline classes

// pre-register typdefs+classes (topologically sorted)
    py::class_<Extrema_Curve2dTool , shared_ptr<Extrema_Curve2dTool>  >(
      m,
      "Extrema_Curve2dTool",R"#()#"
    );
    py::class_<Extrema_CurveTool , shared_ptr<Extrema_CurveTool>  >(
      m,
      "Extrema_CurveTool",R"#()#"
    );
    py::class_<Extrema_ExtCC , shared_ptr<Extrema_ExtCC>  >(
      m,
      "Extrema_ExtCC",R"#(It calculates all the distance between two curves. These distances can be maximum or minimum.)#"
    );
    py::class_<Extrema_ExtCC2d , shared_ptr<Extrema_ExtCC2d>  >(
      m,
      "Extrema_ExtCC2d",R"#(It calculates all the distance between two curves. These distances can be maximum or minimum.)#"
    );
    py::class_<Extrema_ExtCS , shared_ptr<Extrema_ExtCS>  >(
      m,
      "Extrema_ExtCS",R"#(It calculates all the extremum distances between a curve and a surface. These distances can be minimum or maximum.)#"
    );
    py::class_<Extrema_ExtElC , shared_ptr<Extrema_ExtElC>  >(
      m,
      "Extrema_ExtElC",R"#(It calculates all the distance between two elementary curves. These distances can be maximum or minimum.)#"
    );
    py::class_<Extrema_ExtElC2d , shared_ptr<Extrema_ExtElC2d>  >(
      m,
      "Extrema_ExtElC2d",R"#(It calculates all the distance between two elementary curves. These distances can be maximum or minimum.)#"
    );
    py::class_<Extrema_ExtElCS , shared_ptr<Extrema_ExtElCS>  >(
      m,
      "Extrema_ExtElCS",R"#(It calculates all the distances between a curve and a surface. These distances can be maximum or minimum.)#"
    );
    py::class_<Extrema_ExtElSS , shared_ptr<Extrema_ExtElSS>  >(
      m,
      "Extrema_ExtElSS",R"#(It calculates all the distances between 2 elementary surfaces. These distances can be maximum or minimum.)#"
    );
    py::class_<Extrema_ExtPElC , shared_ptr<Extrema_ExtPElC>  >(
      m,
      "Extrema_ExtPElC",R"#(It calculates all the distances between a point and an elementary curve. These distances can be minimum or maximum.)#"
    );
    py::class_<Extrema_ExtPElC2d , shared_ptr<Extrema_ExtPElC2d>  >(
      m,
      "Extrema_ExtPElC2d",R"#(It calculates all the distances between a point and an elementary curve. These distances can be minimum or maximum.)#"
    );
    py::class_<Extrema_ExtPElS , shared_ptr<Extrema_ExtPElS>  >(
      m,
      "Extrema_ExtPElS",R"#(It calculates all the extremum distances between a point and a surface. These distances can be minimum or maximum.)#"
    );
    py::class_<Extrema_ExtPS , shared_ptr<Extrema_ExtPS>  >(
      m,
      "Extrema_ExtPS",R"#(It calculates all the extremum distances between a point and a surface. These distances can be minimum or maximum.)#"
    );
    py::class_<Extrema_ExtSS , shared_ptr<Extrema_ExtSS>  >(
      m,
      "Extrema_ExtSS",R"#(It calculates all the extremum distances between two surfaces. These distances can be minimum or maximum.)#"
    );
    py::class_<Extrema_GenExtCS , shared_ptr<Extrema_GenExtCS>  >(
      m,
      "Extrema_GenExtCS",R"#(It calculates all the extremum distances between acurve and a surface. These distances can be minimum or maximum.)#"
    );
    py::class_<Extrema_GenExtPS , shared_ptr<Extrema_GenExtPS>  >(
      m,
      "Extrema_GenExtPS",R"#(It calculates all the extremum distances between a point and a surface. These distances can be minimum or maximum.)#"
    );
    py::class_<Extrema_GenExtSS , shared_ptr<Extrema_GenExtSS>  >(
      m,
      "Extrema_GenExtSS",R"#(It calculates all the extremum distances between two surfaces. These distances can be minimum or maximum.)#"
    );
    py::class_<Extrema_GenLocateExtCS , shared_ptr<Extrema_GenLocateExtCS>  >(
      m,
      "Extrema_GenLocateExtCS",R"#(With two close points it calculates the distance between two surfaces. This distance can be a minimum or a maximum.)#"
    );
    py::class_<Extrema_GenLocateExtPS , shared_ptr<Extrema_GenLocateExtPS>  >(
      m,
      "Extrema_GenLocateExtPS",R"#(With a close point, it calculates the distance between a point and a surface. Criteria type is defined in "Perform" method.)#"
    );
    py::class_<Extrema_GenLocateExtSS , shared_ptr<Extrema_GenLocateExtSS>  >(
      m,
      "Extrema_GenLocateExtSS",R"#(With two close points it calculates the distance between two surfaces. This distance can be a minimum or a maximum.)#"
    );
    py::class_<Extrema_LocateExtCC , shared_ptr<Extrema_LocateExtCC>  >(
      m,
      "Extrema_LocateExtCC",R"#(It calculates the distance between two curves with a close point; these distances can be maximum or minimum.)#"
    );
    py::class_<Extrema_LocateExtCC2d , shared_ptr<Extrema_LocateExtCC2d>  >(
      m,
      "Extrema_LocateExtCC2d",R"#(It calculates the distance between two curves with a close point; these distances can be maximum or minimum.)#"
    );
    py::class_<Extrema_POnCurv , shared_ptr<Extrema_POnCurv>  >(
      m,
      "Extrema_POnCurv",R"#(Definition of a point on curve.)#"
    );
    py::class_<Extrema_POnCurv2d , shared_ptr<Extrema_POnCurv2d>  >(
      m,
      "Extrema_POnCurv2d",R"#(Definition of a point on 2D curve.)#"
    );
    py::class_<Extrema_POnSurf , shared_ptr<Extrema_POnSurf>  >(
      m,
      "Extrema_POnSurf",R"#(Definition of a point on surface.)#"
    );
    preregister_template_math_VectorBase<double>(m,"math_Vector");
    preregister_template_Extrema_GFuncExtCC<Adaptor3d_Curve, Extrema_CurveTool, Adaptor3d_Curve, Extrema_CurveTool, Extrema_POnCurv, gp_Pnt, gp_Vec, NCollection_Sequence<Extrema_POnCurv>>(m,"Extrema_CCLocFOfLocECC");
    preregister_template_Extrema_GFuncExtCC<Adaptor2d_Curve2d, Extrema_Curve2dTool, Adaptor2d_Curve2d, Extrema_Curve2dTool, Extrema_POnCurv2d, gp_Pnt2d, gp_Vec2d, NCollection_Sequence<Extrema_POnCurv2d>>(m,"Extrema_CCLocFOfLocECC2d");
    preregister_template_Extrema_GGenExtPC<Adaptor3d_Curve, Extrema_CurveTool, Extrema_POnCurv, gp_Pnt, Extrema_PCFOfEPCOfExtPC>(m,"Extrema_EPCOfExtPC");
    preregister_template_Extrema_GGenExtPC<Adaptor2d_Curve2d, Extrema_Curve2dTool, Extrema_POnCurv2d, gp_Pnt2d, Extrema_PCFOfEPCOfExtPC2d>(m,"Extrema_EPCOfExtPC2d");
    py::class_<Extrema_ExtPExtS ,opencascade::handle<Extrema_ExtPExtS>  , Standard_Transient >(
      m,
      "Extrema_ExtPExtS",R"#(It calculates all the extremum (minimum and maximum) distances between a point and a linear extrusion surface.)#"
    );
    py::class_<Extrema_ExtPRevS ,opencascade::handle<Extrema_ExtPRevS>  , Standard_Transient >(
      m,
      "Extrema_ExtPRevS",R"#(It calculates all the extremum (minimum and maximum) distances between a point and a surface of revolution.)#"
    );
    py::class_<Extrema_FuncExtCS , shared_ptr<Extrema_FuncExtCS>  , math_FunctionSetWithDerivatives >(
      m,
      "Extrema_FuncExtCS",R"#(Function to find extrema of the distance between a curve and a surface.)#"
    );
    py::class_<Extrema_FuncExtSS , shared_ptr<Extrema_FuncExtSS>  , math_FunctionSetWithDerivatives >(
      m,
      "Extrema_FuncExtSS",R"#(Function to find extrema of the distance between two surfaces.)#"
    );
    py::class_<Extrema_FuncPSDist , shared_ptr<Extrema_FuncPSDist>  , math_MultipleVarFunctionWithGradient >(
      m,
      "Extrema_FuncPSDist",R"#(Functional for search of extremum of the square Euclidean distance between point P and surface S, starting from approximate solution (u0, v0).)#"
    );
    py::class_<Extrema_FuncPSNorm , shared_ptr<Extrema_FuncPSNorm>  , math_FunctionSetWithDerivatives >(
      m,
      "Extrema_FuncPSNorm",R"#(Functional for search of extremum of the distance between point P and surface S, starting from approximate solution (u0, v0).)#"
    );
    py::class_<Extrema_GlobOptFuncCCC0 , shared_ptr<Extrema_GlobOptFuncCCC0>  , math_MultipleVarFunction >(
      m,
      "Extrema_GlobOptFuncCCC0",R"#(This class implements function which calculate Eucluidean distance between point on curve and point on other curve in case of C1 and C2 continuity is C0.)#"
    );
    py::class_<Extrema_GlobOptFuncCCC1 , shared_ptr<Extrema_GlobOptFuncCCC1>  , math_MultipleVarFunctionWithGradient >(
      m,
      "Extrema_GlobOptFuncCCC1",R"#(This class implements function which calculate Eucluidean distance between point on curve and point on other curve in case of C1 and C2 continuity is C1.)#"
    );
    py::class_<Extrema_GlobOptFuncCCC2 , shared_ptr<Extrema_GlobOptFuncCCC2>  , math_MultipleVarFunctionWithHessian >(
      m,
      "Extrema_GlobOptFuncCCC2",R"#(This class implements function which calculate Eucluidean distance between point on curve and point on other curve in case of C1 and C2 continuity is C2.)#"
    );
    py::class_<Extrema_GlobOptFuncCQuadric , shared_ptr<Extrema_GlobOptFuncCQuadric>  , math_MultipleVarFunction >(
      m,
      "Extrema_GlobOptFuncCQuadric",R"#(This class implements function which calculate square Eucluidean distance between point on surface and nearest point on Conic.)#"
    );
    py::class_<Extrema_GlobOptFuncCS , shared_ptr<Extrema_GlobOptFuncCS>  , math_MultipleVarFunctionWithHessian >(
      m,
      "Extrema_GlobOptFuncCS",R"#(This class implements function which calculate square Eucluidean distance between point on curve and point on surface in case of continuity is C2.)#"
    );
    py::class_<Extrema_GlobOptFuncConicS , shared_ptr<Extrema_GlobOptFuncConicS>  , math_MultipleVarFunction >(
      m,
      "Extrema_GlobOptFuncConicS",R"#(This class implements function which calculate square Eucluidean distance between point on surface and nearest point on Conic.)#"
    );
    preregister_template_Extrema_GenLocateExtPC<Adaptor3d_Curve, Extrema_CurveTool, Extrema_POnCurv, gp_Pnt, Extrema_PCLocFOfLocEPCOfLocateExtPC>(m,"Extrema_LocEPCOfLocateExtPC");
    preregister_template_Extrema_GenLocateExtPC<Adaptor2d_Curve2d, Extrema_Curve2dTool, Extrema_POnCurv2d, gp_Pnt2d, Extrema_PCLocFOfLocEPCOfLocateExtPC2d>(m,"Extrema_LocEPCOfLocateExtPC2d");
    preregister_template_Extrema_GFuncExtPC<Adaptor3d_Curve, Extrema_CurveTool, Extrema_POnCurv, gp_Pnt, gp_Vec, NCollection_Sequence<Extrema_POnCurv>>(m,"Extrema_PCFOfEPCOfELPCOfLocateExtPC");
    preregister_template_Extrema_GFuncExtPC<Adaptor2d_Curve2d, Extrema_Curve2dTool, Extrema_POnCurv2d, gp_Pnt2d, gp_Vec2d, NCollection_Sequence<Extrema_POnCurv2d>>(m,"Extrema_PCFOfEPCOfELPCOfLocateExtPC2d");
    py::class_<Extrema_POnSurfParams , shared_ptr<Extrema_POnSurfParams>  , Extrema_POnSurf >(
      m,
      "Extrema_POnSurfParams",R"#(Data container for point on surface parameters. These parameters are required to compute an initial approximation for extrema computation.)#"
    );
    preregister_template_Extrema_GGExtPC<Adaptor3d_Curve, Extrema_CurveTool, Extrema_ExtPElC, gp_Pnt, gp_Vec, Extrema_POnCurv, NCollection_Sequence<Extrema_POnCurv>, Extrema_EPCOfExtPC>(m,"Extrema_ExtPC");
    preregister_template_Extrema_GGExtPC<Adaptor2d_Curve2d, Extrema_Curve2dTool, Extrema_ExtPElC2d, gp_Pnt2d, gp_Vec2d, Extrema_POnCurv2d, NCollection_Sequence<Extrema_POnCurv2d>, Extrema_EPCOfExtPC2d>(m,"Extrema_ExtPC2d");
    preregister_template_Extrema_GenLocateExtCC<Adaptor3d_Curve, Extrema_CurveTool, Extrema_POnCurv, Extrema_CCLocFOfLocECC>(m,"Extrema_LocECC");
    preregister_template_Extrema_GenLocateExtCC<Adaptor2d_Curve2d, Extrema_Curve2dTool, Extrema_POnCurv2d, Extrema_CCLocFOfLocECC2d>(m,"Extrema_LocECC2d");
    preregister_template_Extrema_GLocateExtPC<Adaptor3d_Curve, Extrema_CurveTool, gp_Pnt, gp_Vec, Extrema_POnCurv, Extrema_ELPCOfLocateExtPC, Extrema_LocEPCOfLocateExtPC>(m,"Extrema_LocateExtPC");
    preregister_template_Extrema_GLocateExtPC<Adaptor2d_Curve2d, Extrema_Curve2dTool, gp_Pnt2d, gp_Vec2d, Extrema_POnCurv2d, Extrema_ELPCOfLocateExtPC2d, Extrema_LocEPCOfLocateExtPC2d>(m,"Extrema_LocateExtPC2d");

// preregister user-defined template specializations

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
