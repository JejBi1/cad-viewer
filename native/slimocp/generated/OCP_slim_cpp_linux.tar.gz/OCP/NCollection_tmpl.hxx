#pragma once

#include <initializer_list>
using std::initializer_list;

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes
#include <gp_XYZ.hxx>
#include <gp_XY.hxx>

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <NCollection_AccAllocator.hxx>
#include <NCollection_AliasedArray.hxx>
#include <NCollection_AlignedAllocator.hxx>
#include <NCollection_Allocator.hxx>
#include <NCollection_Array1.hxx>
#include <NCollection_Array2.hxx>
#include <NCollection_BaseAllocator.hxx>
#include <NCollection_BaseList.hxx>
#include <NCollection_BaseMap.hxx>
#include <NCollection_BaseSequence.hxx>
#include <NCollection_Buffer.hxx>
#include <NCollection_CellFilter.hxx>
#include <NCollection_DataMap.hxx>
#include <NCollection_DefaultHasher.hxx>
#include <NCollection_DefineAlloc.hxx>
#include <NCollection_DefineHasher.hxx>
#include <NCollection_DoubleMap.hxx>
#include <NCollection_DynamicArray.hxx>
#include <NCollection_EBTree.hxx>
#include <NCollection_FlatDataMap.hxx>
#include <NCollection_FlatMap.hxx>
#include <NCollection_HArray1.hxx>
#include <NCollection_HArray2.hxx>
#include <NCollection_HSequence.hxx>
#include <NCollection_Handle.hxx>
#include <NCollection_HeapAllocator.hxx>
#include <NCollection_IncAllocator.hxx>
#include <NCollection_IndexedDataMap.hxx>
#include <NCollection_IndexedIterator.hxx>
#include <NCollection_IndexedMap.hxx>
#include <NCollection_Iterator.hxx>
#include <NCollection_KDTree.hxx>
#include <NCollection_Lerp.hxx>
#include <NCollection_LinearVector.hxx>
#include <NCollection_List.hxx>
#include <NCollection_ListNode.hxx>
#include <NCollection_LocalArray.hxx>
#include <NCollection_Map.hxx>
#include <NCollection_MapAlgo.hxx>
#include <NCollection_Mat3.hxx>
#include <NCollection_Mat4.hxx>
#include <NCollection_OccAllocator.hxx>
#include <NCollection_OrderedDataMap.hxx>
#include <NCollection_OrderedMap.hxx>
#include <NCollection_PackedMap.hxx>
#include <NCollection_PackedMapAlgo.hxx>
#include <NCollection_Primes.hxx>
#include <NCollection_Sequence.hxx>
#include <NCollection_SparseArray.hxx>
#include <NCollection_SparseArrayBase.hxx>
#include <NCollection_StlIterator.hxx>
#include <NCollection_String.hxx>
#include <NCollection_TListIterator.hxx>
#include <NCollection_TListNode.hxx>
#include <NCollection_UBTree.hxx>
#include <NCollection_UBTreeFiller.hxx>
#include <NCollection_UtfIterator.hxx>
#include <NCollection_UtfString.hxx>
#include <NCollection_Vec2.hxx>
#include <NCollection_Vec3.hxx>
#include <NCollection_Vec4.hxx>
#include <NCollection_Vector.hxx>
#include <NCollection_WinHeapAllocator.hxx>

// user-defined pre
#include "OCP_specific.inc"

// Class template handling functions

template <typename Element_t>
void preregister_template_NCollection_Mat4(py::object &m, const char *name){
    py::class_<NCollection_Mat4<Element_t> , shared_ptr<NCollection_Mat4<Element_t>> >(m,name,R"#(Generic matrix of 4 x 4 elements. To be used in conjunction with NCollection_Vec4 entities. Originally introduced for 3D space projection and orientation operations. Warning, empty constructor returns an identity matrix.)#");
}

template <typename Element_t>
void register_template_NCollection_Mat4(py::object &m, const char *name){
    static_cast<py::class_<NCollection_Mat4<Element_t> , shared_ptr<NCollection_Mat4<Element_t>> >>(m.attr(name))
        .def(py::init<  >()  )
        .def("GetValue",
             (Element_t (NCollection_Mat4<Element_t>::*)(  const size_t ,   const size_t  ) const) &NCollection_Mat4<Element_t>::GetValue,
             R"#(Get element at the specified row and column.)#" ,py::arg("theRow"), py::arg("theCol"))
        .def("ChangeValue",
             (Element_t & (NCollection_Mat4<Element_t>::*)(  const size_t ,   const size_t  ) ) &NCollection_Mat4<Element_t>::ChangeValue,
             R"#(Access element at the specified row and column.)#" ,py::arg("theRow"), py::arg("theCol"))
        .def("SetValue",
             (void (NCollection_Mat4<Element_t>::*)(  const size_t ,   const size_t ,   const Element_t  ) ) &NCollection_Mat4<Element_t>::SetValue,
             R"#(Set value for the element specified by row and columns.)#" ,py::arg("theRow"), py::arg("theCol"), py::arg("theValue"))
        .def("GetRow",
             (NCollection_Vec4<Element_t> (NCollection_Mat4<Element_t>::*)(  const size_t  ) const) &NCollection_Mat4<Element_t>::GetRow,
             R"#(Get vector of elements for the specified row.)#" ,py::arg("theRow"))
        .def("SetRow",
             (void (NCollection_Mat4<Element_t>::*)(  const size_t ,   const NCollection_Vec3<Element_t> &  ) ) &NCollection_Mat4<Element_t>::SetRow,
             R"#(Change first 3 row values by the passed vector.)#" ,py::arg("theRow"), py::arg("theVec"))
        .def("SetRow",
             (void (NCollection_Mat4<Element_t>::*)(  const size_t ,   const NCollection_Vec4<Element_t> &  ) ) &NCollection_Mat4<Element_t>::SetRow,
             R"#(Set row values by the passed 4 element vector.)#" ,py::arg("theRow"), py::arg("theVec"))
        .def("GetColumn",
             (NCollection_Vec4<Element_t> (NCollection_Mat4<Element_t>::*)(  const size_t  ) const) &NCollection_Mat4<Element_t>::GetColumn,
             R"#(Get vector of elements for the specified column.)#" ,py::arg("theCol"))
        .def("SetColumn",
             (void (NCollection_Mat4<Element_t>::*)(  const size_t ,   const NCollection_Vec3<Element_t> &  ) ) &NCollection_Mat4<Element_t>::SetColumn,
             R"#(Change first 3 column values by the passed vector.)#" ,py::arg("theCol"), py::arg("theVec"))
        .def("SetColumn",
             (void (NCollection_Mat4<Element_t>::*)(  const size_t ,   const NCollection_Vec4<Element_t> &  ) ) &NCollection_Mat4<Element_t>::SetColumn,
             R"#(Set column values by the passed 4 element vector.)#" ,py::arg("theCol"), py::arg("theVec"))
        .def("GetDiagonal",
             (NCollection_Vec4<Element_t> (NCollection_Mat4<Element_t>::*)() const) &NCollection_Mat4<Element_t>::GetDiagonal,
             R"#(Get vector of diagonal elements.)#" )
        .def("SetDiagonal",
             (void (NCollection_Mat4<Element_t>::*)(  const NCollection_Vec3<Element_t> &  ) ) &NCollection_Mat4<Element_t>::SetDiagonal,
             R"#(Change first 3 elements of the diagonal matrix.)#" ,py::arg("theVec"))
        .def("SetDiagonal",
             (void (NCollection_Mat4<Element_t>::*)(  const NCollection_Vec4<Element_t> &  ) ) &NCollection_Mat4<Element_t>::SetDiagonal,
             R"#(Set diagonal elements of the matrix by the passed vector.)#" ,py::arg("theVec"))
        .def("GetMat3",
             (NCollection_Mat3<Element_t> (NCollection_Mat4<Element_t>::*)() const) &NCollection_Mat4<Element_t>::GetMat3,
             R"#(Return 3x3 sub-matrix.)#" )
        .def("InitZero",
             (void (NCollection_Mat4<Element_t>::*)() ) &NCollection_Mat4<Element_t>::InitZero,
             R"#(Initialize the zero matrix.)#" )
        .def("IsZero",
             (bool (NCollection_Mat4<Element_t>::*)() const) &NCollection_Mat4<Element_t>::IsZero,
             R"#(Checks the matrix for zero (without tolerance).)#" )
        .def("InitIdentity",
             (void (NCollection_Mat4<Element_t>::*)() ) &NCollection_Mat4<Element_t>::InitIdentity,
             R"#(Initialize the identity matrix.)#" )
        .def("IsIdentity",
             (bool (NCollection_Mat4<Element_t>::*)() const) &NCollection_Mat4<Element_t>::IsIdentity,
             R"#(Checks the matrix for identity (without tolerance).)#" )
        .def("IsEqual",
             (bool (NCollection_Mat4<Element_t>::*)(  const NCollection_Mat4<Element_t> &  ) const) &NCollection_Mat4<Element_t>::IsEqual,
             R"#(Check this matrix for equality with another matrix (without tolerance!).)#" ,py::arg("theOther"))
        .def("GetData",
             ( const Element_t * (NCollection_Mat4<Element_t>::*)() const) &NCollection_Mat4<Element_t>::GetData,
             R"#(Raw access to the data (for OpenGL exchange); the data is returned in column-major order.)#" )
        .def("ChangeData",
             (Element_t * (NCollection_Mat4<Element_t>::*)() ) &NCollection_Mat4<Element_t>::ChangeData,
             R"#()#" )
        .def("Multiply",
             (void (NCollection_Mat4<Element_t>::*)(  const NCollection_Mat4<Element_t> &  ) ) &NCollection_Mat4<Element_t>::Multiply,
             R"#(Compute matrix multiplication.)#" ,py::arg("theMat"))
        .def("Multiplied",
             (NCollection_Mat4<Element_t> (NCollection_Mat4<Element_t>::*)(  const NCollection_Mat4<Element_t> &  ) const) &NCollection_Mat4<Element_t>::Multiplied,
             R"#(Compute matrix multiplication product.)#" ,py::arg("theMat"))
        .def("Multiply",
             (void (NCollection_Mat4<Element_t>::*)(  const Element_t  ) ) &NCollection_Mat4<Element_t>::Multiply,
             R"#(Compute per-component multiplication.)#" ,py::arg("theFactor"))
        .def("Multiplied",
             (NCollection_Mat4<Element_t> (NCollection_Mat4<Element_t>::*)(  const Element_t  ) const) &NCollection_Mat4<Element_t>::Multiplied,
             R"#(Compute per-element multiplication.)#" ,py::arg("theFactor"))
        .def("Divide",
             (void (NCollection_Mat4<Element_t>::*)(  const Element_t  ) ) &NCollection_Mat4<Element_t>::Divide,
             R"#(Compute per-component division.)#" ,py::arg("theFactor"))
        .def("Divided",
             (NCollection_Mat4<Element_t> (NCollection_Mat4<Element_t>::*)(  const Element_t  ) const) &NCollection_Mat4<Element_t>::Divided,
             R"#(Divides all the coefficients of the matrix by scalar.)#" ,py::arg("theScalar"))
        .def("Add",
             (void (NCollection_Mat4<Element_t>::*)(  const NCollection_Mat4<Element_t> &  ) ) &NCollection_Mat4<Element_t>::Add,
             R"#(Per-component addition of another matrix.)#" ,py::arg("theMat"))
        .def("Subtract",
             (void (NCollection_Mat4<Element_t>::*)(  const NCollection_Mat4<Element_t> &  ) ) &NCollection_Mat4<Element_t>::Subtract,
             R"#(Per-component subtraction of another matrix.)#" ,py::arg("theMat"))
        .def("Added",
             (NCollection_Mat4<Element_t> (NCollection_Mat4<Element_t>::*)(  const NCollection_Mat4<Element_t> &  ) const) &NCollection_Mat4<Element_t>::Added,
             R"#(Per-component addition of another matrix.)#" ,py::arg("theMat"))
        .def("Subtracted",
             (NCollection_Mat4<Element_t> (NCollection_Mat4<Element_t>::*)(  const NCollection_Mat4<Element_t> &  ) const) &NCollection_Mat4<Element_t>::Subtracted,
             R"#(Per-component subtraction of another matrix.)#" ,py::arg("theMat"))
        .def("Negated",
             (NCollection_Mat4<Element_t> (NCollection_Mat4<Element_t>::*)() const) &NCollection_Mat4<Element_t>::Negated,
             R"#(Returns matrix with all components negated.)#" )
        .def("Translate",
             (void (NCollection_Mat4<Element_t>::*)(  const NCollection_Vec3<Element_t> &  ) ) &NCollection_Mat4<Element_t>::Translate,
             R"#(Translate the matrix on the passed vector.)#" ,py::arg("theVec"))
        .def("Transposed",
             (NCollection_Mat4<Element_t> (NCollection_Mat4<Element_t>::*)() const) &NCollection_Mat4<Element_t>::Transposed,
             R"#(Transpose the matrix.)#" )
        .def("Transpose",
             (void (NCollection_Mat4<Element_t>::*)() ) &NCollection_Mat4<Element_t>::Transpose,
             R"#(Transpose the matrix.)#" )
        .def("Inverted",
             (bool (NCollection_Mat4<Element_t>::*)( NCollection_Mat4<Element_t> & ,  Element_t &  ) const) &NCollection_Mat4<Element_t>::Inverted,
             R"#(Compute inverted matrix.)#" ,py::arg("theOutMx"), py::arg("theDet"))
        .def("Inverted",
             (bool (NCollection_Mat4<Element_t>::*)( NCollection_Mat4<Element_t> &  ) const) &NCollection_Mat4<Element_t>::Inverted,
             R"#(Compute inverted matrix.)#" ,py::arg("theOutMx"))
        .def("Inverted",
             (NCollection_Mat4<Element_t> (NCollection_Mat4<Element_t>::*)() const) &NCollection_Mat4<Element_t>::Inverted,
             R"#(Return inverted matrix.)#" )
        .def("DeterminantMat3",
             (Element_t (NCollection_Mat4<Element_t>::*)() const) &NCollection_Mat4<Element_t>::DeterminantMat3,
             R"#(Return determinant of the 3x3 sub-matrix.)#" )
        .def("Adjoint",
             (NCollection_Mat4<Element_t> (NCollection_Mat4<Element_t>::*)() const) &NCollection_Mat4<Element_t>::Adjoint,
             R"#(Return adjoint (adjugate matrix, e.g. conjugate transpose).)#" )
        .def("DumpJson",
             (void (NCollection_Mat4<Element_t>::*)( Standard_OStream & ,  int  ) const) &NCollection_Mat4<Element_t>::DumpJson,
             R"#(Dumps the content of me into the stream)#" ,py::arg("theOStream"), py::arg("arg1"))
        .def_static("Rows_s",
                    (size_t (*)() ) &NCollection_Mat4<Element_t>::Rows,
                    R"#(Get number of rows.)#" )
        .def_static("Cols_s",
                    (size_t (*)() ) &NCollection_Mat4<Element_t>::Cols,
                    R"#(Get number of columns.)#" )
        .def_static("Identity_s",
                    (NCollection_Mat4<Element_t> (*)() ) &NCollection_Mat4<Element_t>::Identity,
                    R"#(Return identity matrix.)#" )
        .def_static("Zero_s",
                    (NCollection_Mat4<Element_t> (*)() ) &NCollection_Mat4<Element_t>::Zero,
                    R"#(Return zero matrix.)#" )
        .def_static("Multiply_s",
                    (NCollection_Mat4<Element_t> (*)(  const NCollection_Mat4<Element_t> & ,   const NCollection_Mat4<Element_t> &  ) ) &NCollection_Mat4<Element_t>::Multiply,
                    R"#(Compute matrix multiplication product: A * B.)#" ,py::arg("theMatA"), py::arg("theMatB"))
        .def_static("Map_s",
                    (NCollection_Mat4<Element_t> & (*)( Element_t *  ) ) &NCollection_Mat4<Element_t>::Map,
                    R"#(Maps plain C array to matrix type.)#" ,py::arg("theData"))
        .def_static("Map_s",
                    ( const NCollection_Mat4<Element_t> & (*)(  const Element_t *  ) ) &NCollection_Mat4<Element_t>::Map,
                    R"#(Maps plain C array to matrix type.)#" ,py::arg("theData"))
        .def("__mul__",
             (NCollection_Vec4<Element_t> (NCollection_Mat4<Element_t>::*)(  const NCollection_Vec4<Element_t> &  ) const) &NCollection_Mat4<Element_t>::operator*,
             py::is_operator(),
             R"#(Multiply by the vector (M * V).)#" ,py::arg("theVec"))
        .def("__rmul__",
             (NCollection_Vec4<Element_t> (NCollection_Mat4<Element_t>::*)(  const NCollection_Vec4<Element_t> &  ) const) &NCollection_Mat4<Element_t>::operator*,
             py::is_operator(),
             R"#(Multiply by the vector (M * V).)#" ,py::arg("theVec"))
        .def("__imul__",
             (NCollection_Mat4<Element_t> & (NCollection_Mat4<Element_t>::*)(  const NCollection_Mat4<Element_t> &  ) ) &NCollection_Mat4<Element_t>::operator*=,
             py::is_operator(),
             R"#(Multiply by the another matrix.)#" ,py::arg("theMat"))
        .def("__mul__",
             (NCollection_Mat4<Element_t> (NCollection_Mat4<Element_t>::*)(  const NCollection_Mat4<Element_t> &  ) const) &NCollection_Mat4<Element_t>::operator*,
             py::is_operator(),
             R"#(Compute matrix multiplication product.)#" ,py::arg("theMat"))
        .def("__rmul__",
             (NCollection_Mat4<Element_t> (NCollection_Mat4<Element_t>::*)(  const NCollection_Mat4<Element_t> &  ) const) &NCollection_Mat4<Element_t>::operator*,
             py::is_operator(),
             R"#(Compute matrix multiplication product.)#" ,py::arg("theMat"))
        .def("__imul__",
             (NCollection_Mat4<Element_t> & (NCollection_Mat4<Element_t>::*)(  const Element_t  ) ) &NCollection_Mat4<Element_t>::operator*=,
             py::is_operator(),
             R"#(Compute per-element multiplication.)#" ,py::arg("theFactor"))
        .def("__mul__",
             (NCollection_Mat4<Element_t> (NCollection_Mat4<Element_t>::*)(  const Element_t  ) const) &NCollection_Mat4<Element_t>::operator*,
             py::is_operator(),
             R"#(Compute per-element multiplication.)#" ,py::arg("theFactor"))
        .def("__rmul__",
             (NCollection_Mat4<Element_t> (NCollection_Mat4<Element_t>::*)(  const Element_t  ) const) &NCollection_Mat4<Element_t>::operator*,
             py::is_operator(),
             R"#(Compute per-element multiplication.)#" ,py::arg("theFactor"))
        .def("__itruediv__",
             (NCollection_Mat4<Element_t> & (NCollection_Mat4<Element_t>::*)(  const Element_t  ) ) &NCollection_Mat4<Element_t>::operator/=,
             py::is_operator(),
             R"#(Per-component division.)#" ,py::arg("theScalar"))
        .def("__truediv__",
             (NCollection_Mat4<Element_t> (NCollection_Mat4<Element_t>::*)(  const Element_t  ) const) &NCollection_Mat4<Element_t>::operator/,
             py::is_operator(),
             R"#(Divides all the coefficients of the matrix by scalar.)#" ,py::arg("theScalar"))
        .def("__iadd__",
             (NCollection_Mat4<Element_t> & (NCollection_Mat4<Element_t>::*)(  const NCollection_Mat4<Element_t> &  ) ) &NCollection_Mat4<Element_t>::operator+=,
             py::is_operator(),
             R"#(Per-component addition of another matrix.)#" ,py::arg("theMat"))
        .def("__isub__",
             (NCollection_Mat4<Element_t> & (NCollection_Mat4<Element_t>::*)(  const NCollection_Mat4<Element_t> &  ) ) &NCollection_Mat4<Element_t>::operator-=,
             py::is_operator(),
             R"#(Per-component subtraction of another matrix.)#" ,py::arg("theMat"))
        .def("__add__",
             (NCollection_Mat4<Element_t> (NCollection_Mat4<Element_t>::*)(  const NCollection_Mat4<Element_t> &  ) const) &NCollection_Mat4<Element_t>::operator+,
             py::is_operator(),
             R"#(Per-component addition of another matrix.)#" ,py::arg("theMat"))
        .def("__sub__",
             (NCollection_Mat4<Element_t> (NCollection_Mat4<Element_t>::*)(  const NCollection_Mat4<Element_t> &  ) const) &NCollection_Mat4<Element_t>::operator-,
             py::is_operator(),
             R"#(Per-component subtraction of another matrix.)#" ,py::arg("theMat"))
        .def("__neg__",
             (NCollection_Mat4<Element_t> (NCollection_Mat4<Element_t>::*)() const) &NCollection_Mat4<Element_t>::operator-,
             py::is_operator(),
             R"#(Returns matrix with all components negated.)#" )
    ;
};

template <typename TheItemType>
void preregister_template_NCollection_List(py::object &m, const char *name){
    py::class_<NCollection_List<TheItemType> , shared_ptr<NCollection_List<TheItemType>> , NCollection_BaseList >(m,name,R"#(Purpose: Simple list to link items together keeping the first and the last one. Inherits BaseList, adding the data item to each node.)#");
}

template <typename TheItemType>
void register_template_NCollection_List(py::object &m, const char *name){
    static_cast<py::class_<NCollection_List<TheItemType> , shared_ptr<NCollection_List<TheItemType>> , NCollection_BaseList >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >() ,py::arg("theAllocator") )
        .def(py::init<  const NCollection_List<TheItemType> & >() ,py::arg("theOther") )
        .def(py::init< initializer_list<TheItemType>, const handle<NCollection_BaseAllocator> & >() ,py::arg("theInitList"), py::arg("theAllocator")=static_cast< const handle<NCollection_BaseAllocator> &>(occ :: handle < NCollection_BaseAllocator > ( )) )
        .def("Assign",
             (NCollection_List<TheItemType> & (NCollection_List<TheItemType>::*)(  const NCollection_List<TheItemType> &  ) ) &NCollection_List<TheItemType>::Assign,
             R"#(Replace this list by the items of another list (theOther parameter). This method does not change the internal allocator.)#" ,py::arg("theOther"))
        .def("Clear",
             (void (NCollection_List<TheItemType>::*)(  const handle<NCollection_BaseAllocator> &  ) ) &NCollection_List<TheItemType>::Clear,
             R"#(Clear this list)#" ,py::arg("theAllocator")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr))
        .def("First",
             ( const TheItemType & (NCollection_List<TheItemType>::*)() const) &NCollection_List<TheItemType>::First,
             R"#(First item)#" )
        .def("First",
             (TheItemType & (NCollection_List<TheItemType>::*)() ) &NCollection_List<TheItemType>::First,
             R"#(First item (non-const))#" )
        .def("Last",
             ( const TheItemType & (NCollection_List<TheItemType>::*)() const) &NCollection_List<TheItemType>::Last,
             R"#(Last item)#" )
        .def("Last",
             (TheItemType & (NCollection_List<TheItemType>::*)() ) &NCollection_List<TheItemType>::Last,
             R"#(Last item (non-const))#" )
        .def("Append",
             (TheItemType & (NCollection_List<TheItemType>::*)(  const TheItemType &  ) ) &NCollection_List<TheItemType>::Append,
             R"#(Append one item at the end)#" ,py::arg("theItem"))
        .def("Append",
             (void (NCollection_List<TheItemType>::*)(  const TheItemType & ,  typename NCollection_List<TheItemType>::Iterator &  ) ) &NCollection_List<TheItemType>::Append,
             R"#(Append one item at the end and output iterator pointing at the appended item)#" ,py::arg("theItem"), py::arg("theIter"))
        .def("Append",
             (void (NCollection_List<TheItemType>::*)( NCollection_List<TheItemType> &  ) ) &NCollection_List<TheItemType>::Append,
             R"#(Append another list at the end. After this operation, theOther list will be cleared.)#" ,py::arg("theOther"))
        .def("Prepend",
             (TheItemType & (NCollection_List<TheItemType>::*)(  const TheItemType &  ) ) &NCollection_List<TheItemType>::Prepend,
             R"#(Prepend one item at the beginning)#" ,py::arg("theItem"))
        .def("Prepend",
             (void (NCollection_List<TheItemType>::*)( NCollection_List<TheItemType> &  ) ) &NCollection_List<TheItemType>::Prepend,
             R"#(Prepend another list at the beginning)#" ,py::arg("theOther"))
        .def("RemoveFirst",
             (void (NCollection_List<TheItemType>::*)() ) &NCollection_List<TheItemType>::RemoveFirst,
             R"#(RemoveFirst item)#" )
        .def("Remove",
             (void (NCollection_List<TheItemType>::*)( typename NCollection_List<TheItemType>::Iterator &  ) ) &NCollection_List<TheItemType>::Remove,
             R"#(Remove item pointed by iterator theIter; theIter is then set to the next item)#" ,py::arg("theIter"))
        .def("InsertBefore",
             (TheItemType & (NCollection_List<TheItemType>::*)(  const TheItemType & ,  typename NCollection_List<TheItemType>::Iterator &  ) ) &NCollection_List<TheItemType>::InsertBefore,
             R"#(InsertBefore)#" ,py::arg("theItem"), py::arg("theIter"))
        .def("InsertBefore",
             (void (NCollection_List<TheItemType>::*)( NCollection_List<TheItemType> & ,  typename NCollection_List<TheItemType>::Iterator &  ) ) &NCollection_List<TheItemType>::InsertBefore,
             R"#(InsertBefore)#" ,py::arg("theOther"), py::arg("theIter"))
        .def("InsertAfter",
             (TheItemType & (NCollection_List<TheItemType>::*)(  const TheItemType & ,  typename NCollection_List<TheItemType>::Iterator &  ) ) &NCollection_List<TheItemType>::InsertAfter,
             R"#(InsertAfter)#" ,py::arg("theItem"), py::arg("theIter"))
        .def("InsertAfter",
             (void (NCollection_List<TheItemType>::*)( NCollection_List<TheItemType> & ,  typename NCollection_List<TheItemType>::Iterator &  ) ) &NCollection_List<TheItemType>::InsertAfter,
             R"#(InsertAfter)#" ,py::arg("theOther"), py::arg("theIter"))
        .def("Reverse",
             (void (NCollection_List<TheItemType>::*)() ) &NCollection_List<TheItemType>::Reverse,
             R"#(Reverse the list)#" )
        .def("Exchange",
             (void (NCollection_List<TheItemType>::*)( NCollection_List<TheItemType> &  ) ) &NCollection_List<TheItemType>::Exchange,
             R"#(Exchange the content of two lists without re-allocations. Swaps all internal state including allocators, ensuring correct deallocation. Existing iterators remain valid but will point to the other list's elements.)#" ,py::arg("theOther"))
        .def("__iter__",[](const NCollection_List<TheItemType> &self)
             { return py::make_iterator<py::return_value_policy::copy>(self.begin(), self.end()); },
             py::keep_alive<0, 1>())
        .def("__len__",[](const NCollection_List<TheItemType> &self)
             { return self.Extent(); }
             )
        .def("__len__",[](const NCollection_List<TheItemType> &self)
             { return self.Size(); }
             )
        .def("__bool__",[](const NCollection_List<TheItemType> &self)
             { return self.IsEmpty(); }
             )
    ;
};

template <typename TheItemType>
void preregister_template_NCollection_LinearVector(py::object &m, const char *name){
    py::class_<NCollection_LinearVector<TheItemType> , shared_ptr<NCollection_LinearVector<TheItemType>> >(m,name,R"#(Contiguous dynamic array using a flat memory buffer.)#");
}

template <typename TheItemType>
void register_template_NCollection_LinearVector(py::object &m, const char *name){
    static_cast<py::class_<NCollection_LinearVector<TheItemType> , shared_ptr<NCollection_LinearVector<TheItemType>> >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const size_t >() ,py::arg("theCapacity") )
        .def(py::init<  const size_t, const TheItemType & >() ,py::arg("theSize"), py::arg("theValue") )
        .def(py::init<  const NCollection_LinearVector<TheItemType> & >() ,py::arg("theOther") )
        .def("Data",
             (TheItemType * (NCollection_LinearVector<TheItemType>::*)() ) &NCollection_LinearVector<TheItemType>::Data,
             R"#(Returns raw data pointer.)#" )
        .def("Data",
             ( const TheItemType * (NCollection_LinearVector<TheItemType>::*)() const) &NCollection_LinearVector<TheItemType>::Data,
             R"#(Returns raw data pointer.)#" )
        .def("HasData",
             (bool (NCollection_LinearVector<TheItemType>::*)() const) &NCollection_LinearVector<TheItemType>::HasData,
             R"#(Returns true if the vector has allocated storage.)#" )
        .def("Empty",
             (bool (NCollection_LinearVector<TheItemType>::*)() const) &NCollection_LinearVector<TheItemType>::Empty,
             R"#(Returns true if the vector contains no elements.)#" )
        .def("Size",
             (size_t (NCollection_LinearVector<TheItemType>::*)() const) &NCollection_LinearVector<TheItemType>::Size,
             R"#(Returns number of elements.)#" )
        .def("IsEmpty",
             (bool (NCollection_LinearVector<TheItemType>::*)() const) &NCollection_LinearVector<TheItemType>::IsEmpty,
             R"#(Returns true if the vector contains no elements.)#" )
        .def("Capacity",
             (size_t (NCollection_LinearVector<TheItemType>::*)() const) &NCollection_LinearVector<TheItemType>::Capacity,
             R"#(Returns current allocated capacity.)#" )
        .def("Reserve",
             (void (NCollection_LinearVector<TheItemType>::*)(  const size_t  ) ) &NCollection_LinearVector<TheItemType>::Reserve,
             R"#(Pre-allocate memory for at least theCapacity elements without changing size.)#" ,py::arg("theCapacity"))
        .def("Resize",
             (void (NCollection_LinearVector<TheItemType>::*)(  const size_t  ) ) &NCollection_LinearVector<TheItemType>::Resize,
             R"#(Change the number of elements. If theSize > Size(), new elements are default-constructed. If theSize < Size(), excess elements are destroyed.)#" ,py::arg("theSize"))
        .def("Resize",
             (void (NCollection_LinearVector<TheItemType>::*)(  const size_t ,   const TheItemType &  ) ) &NCollection_LinearVector<TheItemType>::Resize,
             R"#(Change the number of elements, filling new slots with theValue. If theSize > Size(), new elements are copy-constructed from theValue. If theSize < Size(), excess elements are destroyed.)#" ,py::arg("theSize"), py::arg("theValue"))
        .def("Value",
             ( const TheItemType & (NCollection_LinearVector<TheItemType>::*)(  const size_t  ) const) &NCollection_LinearVector<TheItemType>::Value,
             R"#(Returns const reference to element at theIndex. [in] theIndex element index (0-based))#" ,py::arg("theIndex"))
        .def("ChangeValue",
             (TheItemType & (NCollection_LinearVector<TheItemType>::*)(  const size_t  ) ) &NCollection_LinearVector<TheItemType>::ChangeValue,
             R"#(Returns mutable reference to element at theIndex. [in] theIndex element index (0-based))#" ,py::arg("theIndex"))
        .def("First",
             ( const TheItemType & (NCollection_LinearVector<TheItemType>::*)() const) &NCollection_LinearVector<TheItemType>::First,
             R"#(Returns const reference to the first element.)#" )
        .def("ChangeFirst",
             (TheItemType & (NCollection_LinearVector<TheItemType>::*)() ) &NCollection_LinearVector<TheItemType>::ChangeFirst,
             R"#(Returns mutable reference to the first element.)#" )
        .def("Last",
             ( const TheItemType & (NCollection_LinearVector<TheItemType>::*)() const) &NCollection_LinearVector<TheItemType>::Last,
             R"#(Returns const reference to the last element.)#" )
        .def("ChangeLast",
             (TheItemType & (NCollection_LinearVector<TheItemType>::*)() ) &NCollection_LinearVector<TheItemType>::ChangeLast,
             R"#(Returns mutable reference to the last element.)#" )
        .def("Append",
             (TheItemType & (NCollection_LinearVector<TheItemType>::*)(  const TheItemType &  ) ) &NCollection_LinearVector<TheItemType>::Append,
             R"#(Append a copy of theValue to the end.)#" ,py::arg("theValue"))
        .def("Appended",
             (TheItemType & (NCollection_LinearVector<TheItemType>::*)() ) &NCollection_LinearVector<TheItemType>::Appended,
             R"#(Append a default-constructed element.)#" )
        .def("SetValue",
             (TheItemType & (NCollection_LinearVector<TheItemType>::*)(  const size_t ,   const TheItemType &  ) ) &NCollection_LinearVector<TheItemType>::SetValue,
             R"#(Set value at theIndex. If theIndex >= Size(), the vector is extended.)#" ,py::arg("theIndex"), py::arg("theValue"))
        .def("InsertBefore",
             (void (NCollection_LinearVector<TheItemType>::*)(  const size_t ,   const TheItemType &  ) ) &NCollection_LinearVector<TheItemType>::InsertBefore,
             R"#(Insert theValue before theIndex, shifting elements right.)#" ,py::arg("theIndex"), py::arg("theValue"))
        .def("InsertAfter",
             (void (NCollection_LinearVector<TheItemType>::*)(  const size_t ,   const TheItemType &  ) ) &NCollection_LinearVector<TheItemType>::InsertAfter,
             R"#(Insert theValue after theIndex, shifting elements right.)#" ,py::arg("theIndex"), py::arg("theValue"))
        .def("EraseLast",
             (void (NCollection_LinearVector<TheItemType>::*)() ) &NCollection_LinearVector<TheItemType>::EraseLast,
             R"#(Remove the last element.)#" )
        .def("Erase",
             (void (NCollection_LinearVector<TheItemType>::*)(  const size_t  ) ) &NCollection_LinearVector<TheItemType>::Erase,
             R"#(Remove element at theIndex, shifting subsequent elements left.)#" ,py::arg("theIndex"))
        .def("Erase",
             (void (NCollection_LinearVector<TheItemType>::*)(  const size_t ,   const size_t  ) ) &NCollection_LinearVector<TheItemType>::Erase,
             R"#(Remove elements in range [theFrom, theTo), shifting subsequent elements left.)#" ,py::arg("theFrom"), py::arg("theTo"))
        .def("Clear",
             (void (NCollection_LinearVector<TheItemType>::*)(  const bool  ) ) &NCollection_LinearVector<TheItemType>::Clear,
             R"#(Remove all elements.)#" ,py::arg("theReleaseMemory")=static_cast< const bool>(false))
        .def("ToArray1",
             (NCollection_Array1<TheItemType> (NCollection_LinearVector<TheItemType>::*)() const) &NCollection_LinearVector<TheItemType>::ToArray1,
             R"#(Returns a span as Array1 with shared memory. Modifying the vector or the array may invalidate the shared buffer.)#" )
        .def_static("MaxSize_s",
                    (size_t (*)() ) &NCollection_LinearVector<TheItemType>::MaxSize,
                    R"#(Returns current max supported size.)#" )
        .def("__call__",
             ( const TheItemType & (NCollection_LinearVector<TheItemType>::*)(  const size_t  ) const) &NCollection_LinearVector<TheItemType>::operator(),
             py::is_operator(),
             R"#(Returns const reference to element at theIndex.)#" ,py::arg("theIndex"))
        .def("__call__",
             (TheItemType & (NCollection_LinearVector<TheItemType>::*)(  const size_t  ) ) &NCollection_LinearVector<TheItemType>::operator(),
             py::is_operator(),
             R"#(Returns mutable reference to element at theIndex.)#" ,py::arg("theIndex"))
        .def("__iter__",[](const NCollection_LinearVector<TheItemType> &self)
             { return py::make_iterator<py::return_value_policy::copy>(self.begin(), self.end()); },
             py::keep_alive<0, 1>())
        .def("__len__",[](const NCollection_LinearVector<TheItemType> &self)
             { return self.Size(); }
             )
        .def("__bool__",[](const NCollection_LinearVector<TheItemType> &self)
             { return self.IsEmpty(); }
             )
    ;
};

template <typename Element_t>
void preregister_template_NCollection_Vec2(py::object &m, const char *name){
    py::class_<NCollection_Vec2<Element_t> , shared_ptr<NCollection_Vec2<Element_t>> >(m,name,R"#(Defines the 2D-vector template. The main target for this class - to handle raw low-level arrays (from/to graphic driver etc.).)#");
}

template <typename Element_t>
void register_template_NCollection_Vec2(py::object &m, const char *name){
    static_cast<py::class_<NCollection_Vec2<Element_t> , shared_ptr<NCollection_Vec2<Element_t>> >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const Element_t >() ,py::arg("theXY") )
        .def(py::init<  const Element_t, const Element_t >() ,py::arg("theX"), py::arg("theY") )
        .def("SetValues",
             (void (NCollection_Vec2<Element_t>::*)(  const Element_t ,   const Element_t  ) ) &NCollection_Vec2<Element_t>::SetValues,
             R"#(Assign new values to the vector.)#" ,py::arg("theX"), py::arg("theY"))
        .def("x",
             (Element_t (NCollection_Vec2<Element_t>::*)() const) &NCollection_Vec2<Element_t>::x,
             R"#(Alias to 1st component as X coordinate in XY.)#" )
        .def("y",
             (Element_t (NCollection_Vec2<Element_t>::*)() const) &NCollection_Vec2<Element_t>::y,
             R"#(Alias to 2nd component as Y coordinate in XY.)#" )
        .def("xy",
             (NCollection_Vec2<Element_t> (NCollection_Vec2<Element_t>::*)() const) &NCollection_Vec2<Element_t>::xy,
             R"#(Returns 2 components by their names in specified order (in GLSL-style))#" )
        .def("yx",
             (NCollection_Vec2<Element_t> (NCollection_Vec2<Element_t>::*)() const) &NCollection_Vec2<Element_t>::yx,
             R"#(Returns 2 components by their names in specified order (in GLSL-style))#" )
        .def("x",
             (Element_t & (NCollection_Vec2<Element_t>::*)() ) &NCollection_Vec2<Element_t>::x,
             R"#(Alias to 1st component as X coordinate in XY.)#" )
        .def("y",
             (Element_t & (NCollection_Vec2<Element_t>::*)() ) &NCollection_Vec2<Element_t>::y,
             R"#(Alias to 2nd component as Y coordinate in XY.)#" )
        .def("IsEqual",
             (bool (NCollection_Vec2<Element_t>::*)(  const NCollection_Vec2<Element_t> &  ) const) &NCollection_Vec2<Element_t>::IsEqual,
             R"#(Check this vector with another vector for equality (without tolerance!).)#" ,py::arg("theOther"))
        .def("GetData",
             ( const Element_t * (NCollection_Vec2<Element_t>::*)() const) &NCollection_Vec2<Element_t>::GetData,
             R"#(Raw access to the data (for OpenGL exchange).)#" )
        .def("ChangeData",
             (Element_t * (NCollection_Vec2<Element_t>::*)() ) &NCollection_Vec2<Element_t>::ChangeData,
             R"#()#" )
        .def("Multiply",
             (void (NCollection_Vec2<Element_t>::*)(  const Element_t  ) ) &NCollection_Vec2<Element_t>::Multiply,
             R"#(Compute per-component multiplication by scale factor.)#" ,py::arg("theFactor"))
        .def("Multiplied",
             (NCollection_Vec2<Element_t> (NCollection_Vec2<Element_t>::*)(  const Element_t  ) const) &NCollection_Vec2<Element_t>::Multiplied,
             R"#(Compute per-component multiplication by scale factor.)#" ,py::arg("theFactor"))
        .def("cwiseMin",
             (NCollection_Vec2<Element_t> (NCollection_Vec2<Element_t>::*)(  const NCollection_Vec2<Element_t> &  ) const) &NCollection_Vec2<Element_t>::cwiseMin,
             R"#(Compute component-wise minimum of two vectors.)#" ,py::arg("theVec"))
        .def("cwiseMax",
             (NCollection_Vec2<Element_t> (NCollection_Vec2<Element_t>::*)(  const NCollection_Vec2<Element_t> &  ) const) &NCollection_Vec2<Element_t>::cwiseMax,
             R"#(Compute component-wise maximum of two vectors.)#" ,py::arg("theVec"))
        .def("cwiseAbs",
             (NCollection_Vec2<Element_t> (NCollection_Vec2<Element_t>::*)() const) &NCollection_Vec2<Element_t>::cwiseAbs,
             R"#(Compute component-wise modulus of the vector.)#" )
        .def("maxComp",
             (Element_t (NCollection_Vec2<Element_t>::*)() const) &NCollection_Vec2<Element_t>::maxComp,
             R"#(Compute maximum component of the vector.)#" )
        .def("minComp",
             (Element_t (NCollection_Vec2<Element_t>::*)() const) &NCollection_Vec2<Element_t>::minComp,
             R"#(Compute minimum component of the vector.)#" )
        .def("Dot",
             (Element_t (NCollection_Vec2<Element_t>::*)(  const NCollection_Vec2<Element_t> &  ) const) &NCollection_Vec2<Element_t>::Dot,
             R"#(Computes the dot product.)#" ,py::arg("theOther"))
        .def("Modulus",
             (Element_t (NCollection_Vec2<Element_t>::*)() const) &NCollection_Vec2<Element_t>::Modulus,
             R"#(Computes the vector modulus (magnitude, length).)#" )
        .def("SquareModulus",
             (Element_t (NCollection_Vec2<Element_t>::*)() const) &NCollection_Vec2<Element_t>::SquareModulus,
             R"#(Computes the square of vector modulus (magnitude, length). This method may be used for performance tricks.)#" )
        .def("DumpJson",
             (void (NCollection_Vec2<Element_t>::*)( Standard_OStream & ,  int  ) const) &NCollection_Vec2<Element_t>::DumpJson,
             R"#(Dumps the content of me into the stream)#" ,py::arg("theOStream"), py::arg("theDepth")=static_cast<int>(- 1))
        .def_static("Length_s",
                    (int (*)() ) &NCollection_Vec2<Element_t>::Length,
                    R"#(Returns the number of components.)#" )
        .def_static("DX_s",
                    (NCollection_Vec2<Element_t> (*)() ) &NCollection_Vec2<Element_t>::DX,
                    R"#(Construct DX unit vector.)#" )
        .def_static("DY_s",
                    (NCollection_Vec2<Element_t> (*)() ) &NCollection_Vec2<Element_t>::DY,
                    R"#(Construct DY unit vector.)#" )
        .def("__iadd__",
             (NCollection_Vec2<Element_t> & (NCollection_Vec2<Element_t>::*)(  const NCollection_Vec2<Element_t> &  ) ) &NCollection_Vec2<Element_t>::operator+=,
             py::is_operator(),
             R"#(Compute per-component summary.)#" ,py::arg("theAdd"))
        .def("__isub__",
             (NCollection_Vec2<Element_t> & (NCollection_Vec2<Element_t>::*)(  const NCollection_Vec2<Element_t> &  ) ) &NCollection_Vec2<Element_t>::operator-=,
             py::is_operator(),
             R"#(Compute per-component subtraction.)#" ,py::arg("theDec"))
        .def("__neg__",
             (NCollection_Vec2<Element_t> (NCollection_Vec2<Element_t>::*)() const) &NCollection_Vec2<Element_t>::operator-,
             py::is_operator(),
             R"#(Unary -.)#" )
        .def("__imul__",
             (NCollection_Vec2<Element_t> & (NCollection_Vec2<Element_t>::*)(  const NCollection_Vec2<Element_t> &  ) ) &NCollection_Vec2<Element_t>::operator*=,
             py::is_operator(),
             R"#(Compute per-component multiplication.)#" ,py::arg("theRight"))
        .def("__imul__",
             (NCollection_Vec2<Element_t> & (NCollection_Vec2<Element_t>::*)(  const Element_t  ) ) &NCollection_Vec2<Element_t>::operator*=,
             py::is_operator(),
             R"#(Compute per-component multiplication by scale factor.)#" ,py::arg("theFactor"))
        .def("__itruediv__",
             (NCollection_Vec2<Element_t> & (NCollection_Vec2<Element_t>::*)(  const Element_t  ) ) &NCollection_Vec2<Element_t>::operator/=,
             py::is_operator(),
             R"#(Compute per-component division by scale factor.)#" ,py::arg("theInvFactor"))
        .def("__itruediv__",
             (NCollection_Vec2<Element_t> & (NCollection_Vec2<Element_t>::*)(  const NCollection_Vec2<Element_t> &  ) ) &NCollection_Vec2<Element_t>::operator/=,
             py::is_operator(),
             R"#(Compute per-component division.)#" ,py::arg("theRight"))
        .def("__mul__",
             (NCollection_Vec2<Element_t> (NCollection_Vec2<Element_t>::*)(  const Element_t  ) const) &NCollection_Vec2<Element_t>::operator*,
             py::is_operator(),
             R"#(Compute per-component multiplication by scale factor.)#" ,py::arg("theFactor"))
        .def("__rmul__",
             (NCollection_Vec2<Element_t> (NCollection_Vec2<Element_t>::*)(  const Element_t  ) const) &NCollection_Vec2<Element_t>::operator*,
             py::is_operator(),
             R"#(Compute per-component multiplication by scale factor.)#" ,py::arg("theFactor"))
        .def("__truediv__",
             (NCollection_Vec2<Element_t> (NCollection_Vec2<Element_t>::*)(  const Element_t  ) const) &NCollection_Vec2<Element_t>::operator/,
             py::is_operator(),
             R"#(Compute per-component division by scale factor.)#" ,py::arg("theInvFactor"))
    ;
};

template <typename TheKeyType,typename Hasher=NCollection_DefaultHasher<TheKeyType>>
void preregister_template_NCollection_FlatMap(py::object &m, const char *name){
    py::class_<NCollection_FlatMap<TheKeyType,Hasher> , shared_ptr<NCollection_FlatMap<TheKeyType,Hasher>> >(m,name,R"#(High-performance hash set using open addressing with Robin Hood hashing.)#");
}

template <typename TheKeyType,typename Hasher=NCollection_DefaultHasher<TheKeyType>>
void register_template_NCollection_FlatMap(py::object &m, const char *name){
    static_cast<py::class_<NCollection_FlatMap<TheKeyType,Hasher> , shared_ptr<NCollection_FlatMap<TheKeyType,Hasher>> >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const size_t >() ,py::arg("theNbBuckets") )
        .def(py::init<  const Hasher &, const size_t >() ,py::arg("theHasher"), py::arg("theNbBuckets")=static_cast< const size_t>(0) )
        .def(py::init<  const NCollection_FlatMap<TheKeyType, Hasher> & >() ,py::arg("theOther") )
        .def("Size",
             (size_t (NCollection_FlatMap<TheKeyType,Hasher>::*)() const) &NCollection_FlatMap<TheKeyType,Hasher>::Size,
             R"#(Returns number of elements.)#" )
        .def("IsEmpty",
             (bool (NCollection_FlatMap<TheKeyType,Hasher>::*)() const) &NCollection_FlatMap<TheKeyType,Hasher>::IsEmpty,
             R"#(Returns true if map is empty)#" )
        .def("Capacity",
             (size_t (NCollection_FlatMap<TheKeyType,Hasher>::*)() const) &NCollection_FlatMap<TheKeyType,Hasher>::Capacity,
             R"#(Returns current capacity)#" )
        .def("Contains",
             (bool (NCollection_FlatMap<TheKeyType,Hasher>::*)(  const TheKeyType &  ) const) &NCollection_FlatMap<TheKeyType,Hasher>::Contains,
             R"#(Check if key exists)#" ,py::arg("theKey"))
        .def("Seek",
             ( const TheKeyType * (NCollection_FlatMap<TheKeyType,Hasher>::*)(  const TheKeyType &  ) const) &NCollection_FlatMap<TheKeyType,Hasher>::Seek,
             R"#(Seek returns pointer to key in map. Returns NULL if not found.)#" ,py::arg("theKey"))
        .def("ChangeSeek",
             (TheKeyType * (NCollection_FlatMap<TheKeyType,Hasher>::*)(  const TheKeyType &  ) ) &NCollection_FlatMap<TheKeyType,Hasher>::ChangeSeek,
             R"#(ChangeSeek returns modifiable pointer to key in map. Returns NULL if not found.)#" ,py::arg("theKey"))
        .def("Add",
             (bool (NCollection_FlatMap<TheKeyType,Hasher>::*)(  const TheKeyType &  ) ) &NCollection_FlatMap<TheKeyType,Hasher>::Add,
             R"#(Add key to set)#" ,py::arg("theKey"))
        .def("Added",
             ( const TheKeyType & (NCollection_FlatMap<TheKeyType,Hasher>::*)(  const TheKeyType &  ) ) &NCollection_FlatMap<TheKeyType,Hasher>::Added,
             R"#(Added: add a new key if not yet in the map, and return reference to either newly added or previously existing key.)#" ,py::arg("theKey"))
        .def("Remove",
             (bool (NCollection_FlatMap<TheKeyType,Hasher>::*)(  const TheKeyType &  ) ) &NCollection_FlatMap<TheKeyType,Hasher>::Remove,
             R"#(Remove key from set)#" ,py::arg("theKey"))
        .def("Clear",
             (void (NCollection_FlatMap<TheKeyType,Hasher>::*)( bool  ) ) &NCollection_FlatMap<TheKeyType,Hasher>::Clear,
             R"#(Clear all elements)#" ,py::arg("doReleaseMemory")=static_cast<bool>(false))
        .def("Exchange",
             (void (NCollection_FlatMap<TheKeyType,Hasher>::*)( NCollection_FlatMap<TheKeyType, Hasher> &  ) ) &NCollection_FlatMap<TheKeyType,Hasher>::Exchange,
             R"#(Exchange content with another map)#" ,py::arg("theOther"))
        .def("GetHasher",
             ( const Hasher & (NCollection_FlatMap<TheKeyType,Hasher>::*)() const) &NCollection_FlatMap<TheKeyType,Hasher>::GetHasher,
             R"#(Returns const reference to the hasher.)#" )
        .def("reserve",
             (void (NCollection_FlatMap<TheKeyType,Hasher>::*)( size_t  ) ) &NCollection_FlatMap<TheKeyType,Hasher>::reserve,
             R"#(Reserve capacity for at least theN elements)#" ,py::arg("theN"))
        .def("Reserve",
             (void (NCollection_FlatMap<TheKeyType,Hasher>::*)(  const size_t  ) ) &NCollection_FlatMap<TheKeyType,Hasher>::Reserve,
             R"#(Reserve capacity for at least theN elements)#" ,py::arg("theN"))
        .def("__iter__",[](const NCollection_FlatMap<TheKeyType,Hasher> &self)
             { return py::make_iterator<py::return_value_policy::copy>(self.begin(), self.end()); },
             py::keep_alive<0, 1>())
        .def("__len__",[](const NCollection_FlatMap<TheKeyType,Hasher> &self)
             { return self.Size(); }
             )
        .def("__bool__",[](const NCollection_FlatMap<TheKeyType,Hasher> &self)
             { return self.IsEmpty(); }
             )
    ;
};

template <typename ThePointType,int TheDimension,bool HasRadii=false>
void preregister_template_NCollection_KDTree(py::object &m, const char *name){
    py::class_<NCollection_KDTree<ThePointType,TheDimension,HasRadii> , shared_ptr<NCollection_KDTree<ThePointType,TheDimension,HasRadii>> >(m,name,R"#(Static KD-Tree for efficient point set queries.)#");
}

template <typename ThePointType,int TheDimension,bool HasRadii=false>
void register_template_NCollection_KDTree(py::object &m, const char *name){
    static_cast<py::class_<NCollection_KDTree<ThePointType,TheDimension,HasRadii> , shared_ptr<NCollection_KDTree<ThePointType,TheDimension,HasRadii>> >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const NCollection_KDTree<ThePointType, TheDimension, HasRadii> & >() ,py::arg("theOther") )
        .def("IsEmpty",
             (bool (NCollection_KDTree<ThePointType,TheDimension,HasRadii>::*)() const) &NCollection_KDTree<ThePointType,TheDimension,HasRadii>::IsEmpty,
             R"#(Returns true if the tree contains no points.)#" )
        .def("Size",
             (size_t (NCollection_KDTree<ThePointType,TheDimension,HasRadii>::*)() const) &NCollection_KDTree<ThePointType,TheDimension,HasRadii>::Size,
             R"#(Returns the number of points in the tree.)#" )
        .def("Clear",
             (void (NCollection_KDTree<ThePointType,TheDimension,HasRadii>::*)() ) &NCollection_KDTree<ThePointType,TheDimension,HasRadii>::Clear,
             R"#(Clears the tree.)#" )
        .def("Point",
             ( const ThePointType & (NCollection_KDTree<ThePointType,TheDimension,HasRadii>::*)( size_t  ) const) &NCollection_KDTree<ThePointType,TheDimension,HasRadii>::Point,
             R"#(Returns the point at the given 1-based original index.)#" ,py::arg("theIndex"))
        .def("NearestPoint",
             (size_t (NCollection_KDTree<ThePointType,TheDimension,HasRadii>::*)(  const ThePointType &  ) const) &NCollection_KDTree<ThePointType,TheDimension,HasRadii>::NearestPoint,
             R"#(Finds the nearest point to theQuery.)#" ,py::arg("theQuery"))
        .def("NearestPoint",
             (size_t (NCollection_KDTree<ThePointType,TheDimension,HasRadii>::*)(  const ThePointType & ,  double &  ) const) &NCollection_KDTree<ThePointType,TheDimension,HasRadii>::NearestPoint,
             R"#(Finds the nearest point to theQuery and returns the squared distance.)#" ,py::arg("theQuery"), py::arg("theSqDistance"))
        .def("NearestPoints",
             (NCollection_DynamicArray<size_t> (NCollection_KDTree<ThePointType,TheDimension,HasRadii>::*)(  const ThePointType & ,  double ,  double &  ) const) &NCollection_KDTree<ThePointType,TheDimension,HasRadii>::NearestPoints,
             R"#(Finds all nearest points to theQuery that share the same minimum distance. Useful when multiple points are equidistant from the query. First finds the nearest distance via tree traversal, then collects all points at that distance using a range search with theTolerance for floating-point comparison.)#" ,py::arg("theQuery"), py::arg("theTolerance"), py::arg("theSqDistance"))
        .def("KNearestPoints",
             (size_t (NCollection_KDTree<ThePointType,TheDimension,HasRadii>::*)(  const ThePointType & ,  size_t ,  NCollection_Array1<size_t> & ,  NCollection_Array1<double> &  ) const) &NCollection_KDTree<ThePointType,TheDimension,HasRadii>::KNearestPoints,
             R"#(Finds the K nearest points to theQuery. Results are sorted by distance (closest first).)#" ,py::arg("theQuery"), py::arg("theK"), py::arg("theIndices"), py::arg("theSqDistances"))
        .def("RangeSearch",
             (NCollection_DynamicArray<size_t> (NCollection_KDTree<ThePointType,TheDimension,HasRadii>::*)(  const ThePointType & ,  double  ) const) &NCollection_KDTree<ThePointType,TheDimension,HasRadii>::RangeSearch,
             R"#(Finds all points within theRadius of theQuery (sphere search).)#" ,py::arg("theQuery"), py::arg("theRadius"))
        .def("BoxSearch",
             (NCollection_DynamicArray<size_t> (NCollection_KDTree<ThePointType,TheDimension,HasRadii>::*)(  const ThePointType & ,   const ThePointType &  ) const) &NCollection_KDTree<ThePointType,TheDimension,HasRadii>::BoxSearch,
             R"#(Finds all points within the axis-aligned bounding box [theMin, theMax].)#" ,py::arg("theMin"), py::arg("theMax"))
        .def("__len__",[](const NCollection_KDTree<ThePointType,TheDimension,HasRadii> &self)
             { return self.Size(); }
             )
        .def("__bool__",[](const NCollection_KDTree<ThePointType,TheDimension,HasRadii> &self)
             { return self.IsEmpty(); }
             )
    ;
};

template <typename Category,typename BaseIterator,typename ItemType,bool IsConstant>
void preregister_template_NCollection_StlIterator(py::object &m, const char *name){
    py::class_<NCollection_StlIterator<Category,BaseIterator,ItemType,IsConstant> , shared_ptr<NCollection_StlIterator<Category,BaseIterator,ItemType,IsConstant>> >(m,name,R"#(Helper class that allows to use NCollection iterators as STL iterators. NCollection iterator can be extended to STL iterator of any category by adding necessary methods: STL forward iterator requires IsEqual method, STL bidirectional iterator requires Previous method, and STL random access iterator requires Offset and Differ methods. See NCollection_DynamicArray as example of declaring custom STL iterators.)#");
}

template <typename Category,typename BaseIterator,typename ItemType,bool IsConstant>
void register_template_NCollection_StlIterator(py::object &m, const char *name){
    static_cast<py::class_<NCollection_StlIterator<Category,BaseIterator,ItemType,IsConstant> , shared_ptr<NCollection_StlIterator<Category,BaseIterator,ItemType,IsConstant>> >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const BaseIterator & >() ,py::arg("theIterator") )
        .def(py::init<  const NCollection_StlIterator<Category, BaseIterator, ItemType, false> & >() ,py::arg("theIterator") )
        .def("Iterator",
             ( const BaseIterator & (NCollection_StlIterator<Category,BaseIterator,ItemType,IsConstant>::*)() const) &NCollection_StlIterator<Category,BaseIterator,ItemType,IsConstant>::Iterator,
             R"#(Access to NCollection iterator instance)#" )
        .def("ChangeIterator",
             (BaseIterator & (NCollection_StlIterator<Category,BaseIterator,ItemType,IsConstant>::*)() ) &NCollection_StlIterator<Category,BaseIterator,ItemType,IsConstant>::ChangeIterator,
             R"#(Access to NCollection iterator instance)#" )
        .def("__iadd__",
             (NCollection_StlIterator<Category, BaseIterator, ItemType, IsConstant> & (NCollection_StlIterator<Category,BaseIterator,ItemType,IsConstant>::*)( typename NCollection_StlIterator<Category, BaseIterator, ItemType, IsConstant>::difference_type  ) ) &NCollection_StlIterator<Category,BaseIterator,ItemType,IsConstant>::operator+=,
             py::is_operator(),
             R"#(Move forward)#" ,py::arg("theOffset"))
        .def("__add__",
             (NCollection_StlIterator<Category, BaseIterator, ItemType, IsConstant> (NCollection_StlIterator<Category,BaseIterator,ItemType,IsConstant>::*)( typename NCollection_StlIterator<Category, BaseIterator, ItemType, IsConstant>::difference_type  ) const) &NCollection_StlIterator<Category,BaseIterator,ItemType,IsConstant>::operator+,
             py::is_operator(),
             R"#(Addition)#" ,py::arg("theOffset"))
        .def("__isub__",
             (NCollection_StlIterator<Category, BaseIterator, ItemType, IsConstant> & (NCollection_StlIterator<Category,BaseIterator,ItemType,IsConstant>::*)( typename NCollection_StlIterator<Category, BaseIterator, ItemType, IsConstant>::difference_type  ) ) &NCollection_StlIterator<Category,BaseIterator,ItemType,IsConstant>::operator-=,
             py::is_operator(),
             R"#(Move backward)#" ,py::arg("theOffset"))
        .def("__sub__",
             (NCollection_StlIterator<Category, BaseIterator, ItemType, IsConstant> (NCollection_StlIterator<Category,BaseIterator,ItemType,IsConstant>::*)( typename NCollection_StlIterator<Category, BaseIterator, ItemType, IsConstant>::difference_type  ) const) &NCollection_StlIterator<Category,BaseIterator,ItemType,IsConstant>::operator-,
             py::is_operator(),
             R"#(Decrease)#" ,py::arg("theOffset"))
        .def("__sub__",
             (typename NCollection_StlIterator<Category,BaseIterator,ItemType,IsConstant>::difference_type (NCollection_StlIterator<Category,BaseIterator,ItemType,IsConstant>::*)(  const NCollection_StlIterator<Category, BaseIterator, ItemType, IsConstant> &  ) const) &NCollection_StlIterator<Category,BaseIterator,ItemType,IsConstant>::operator-,
             py::is_operator(),
             R"#(Difference)#" ,py::arg("theOther"))
    ;
};

template <typename TheItemType>
void preregister_template_NCollection_SparseArray(py::object &m, const char *name){
    py::class_<NCollection_SparseArray<TheItemType> , shared_ptr<NCollection_SparseArray<TheItemType>> , NCollection_SparseArrayBase >(m,name,R"#(Dynamically resizable sparse array of objects)#");
}

template <typename TheItemType>
void register_template_NCollection_SparseArray(py::object &m, const char *name){
    static_cast<py::class_<NCollection_SparseArray<TheItemType> , shared_ptr<NCollection_SparseArray<TheItemType>> , NCollection_SparseArrayBase >>(m.attr(name))
        .def(py::init< size_t >() ,py::arg("theIncrement") )
        .def("Assign",
             (NCollection_SparseArray<TheItemType> & (NCollection_SparseArray<TheItemType>::*)(  const NCollection_SparseArray<TheItemType> &  ) ) &NCollection_SparseArray<TheItemType>::Assign,
             R"#(Explicit assignment operator)#" ,py::arg("theOther"))
        .def("Exchange",
             (void (NCollection_SparseArray<TheItemType>::*)( NCollection_SparseArray<TheItemType> &  ) ) &NCollection_SparseArray<TheItemType>::Exchange,
             R"#(Exchange the data of two arrays; can be used primarily to move contents of theOther into the new array in a fast way (without creation of duplicated data))#" ,py::arg("theOther"))
        .def("Clear",
             (void (NCollection_SparseArray<TheItemType>::*)() ) &NCollection_SparseArray<TheItemType>::Clear,
             R"#(Clears all the data)#" )
        .def("Value",
             ( const TheItemType & (NCollection_SparseArray<TheItemType>::*)(  const size_t  ) const) &NCollection_SparseArray<TheItemType>::Value,
             R"#(Direct const access to the item)#" ,py::arg("theIndex"))
        .def("ChangeValue",
             (TheItemType & (NCollection_SparseArray<TheItemType>::*)(  const size_t  ) ) &NCollection_SparseArray<TheItemType>::ChangeValue,
             R"#(Modification access to the item)#" ,py::arg("theIndex"))
        .def("SetValue",
             (TheItemType & (NCollection_SparseArray<TheItemType>::*)(  const size_t ,   const TheItemType &  ) ) &NCollection_SparseArray<TheItemType>::SetValue,
             R"#(Set a value at specified index method)#" ,py::arg("theIndex"), py::arg("theValue"))
        .def("UnsetValue",
             (bool (NCollection_SparseArray<TheItemType>::*)(  const size_t  ) ) &NCollection_SparseArray<TheItemType>::UnsetValue,
             R"#(Deletes the item from the array; returns True if that item was defined)#" ,py::arg("theIndex"))
        .def("Extent",
             (size_t (NCollection_SparseArray<TheItemType>::*)() const) &NCollection_SparseArray<TheItemType>::Extent,
             R"#(Returns number of items in the array)#" )
        .def("IsEmpty",
             (bool (NCollection_SparseArray<TheItemType>::*)() const) &NCollection_SparseArray<TheItemType>::IsEmpty,
             R"#(Returns True if array is empty)#" )
        .def("Find",
             ( const TheItemType & (NCollection_SparseArray<TheItemType>::*)(  const size_t  ) const) &NCollection_SparseArray<TheItemType>::Find,
             R"#(Direct const access to the item)#" ,py::arg("theIndex"))
        .def("ChangeFind",
             (TheItemType & (NCollection_SparseArray<TheItemType>::*)(  const size_t  ) ) &NCollection_SparseArray<TheItemType>::ChangeFind,
             R"#(Modification access to the item)#" ,py::arg("theIndex"))
        .def("Bind",
             (TheItemType & (NCollection_SparseArray<TheItemType>::*)(  const size_t ,   const TheItemType &  ) ) &NCollection_SparseArray<TheItemType>::Bind,
             R"#(Set a value as explicit method)#" ,py::arg("theIndex"), py::arg("theValue"))
        .def("IsBound",
             (bool (NCollection_SparseArray<TheItemType>::*)(  const size_t  ) const) &NCollection_SparseArray<TheItemType>::IsBound,
             R"#(Returns True if the item is defined)#" ,py::arg("theIndex"))
        .def("UnBind",
             (bool (NCollection_SparseArray<TheItemType>::*)(  const size_t  ) ) &NCollection_SparseArray<TheItemType>::UnBind,
             R"#(Remove the item from array)#" ,py::arg("theIndex"))
        .def("__call__",
             ( const TheItemType & (NCollection_SparseArray<TheItemType>::*)(  const size_t  ) const) &NCollection_SparseArray<TheItemType>::operator(),
             py::is_operator(),
             R"#(Const access to the item - operator())#" ,py::arg("theIndex"))
        .def("__call__",
             (TheItemType & (NCollection_SparseArray<TheItemType>::*)(  const size_t  ) ) &NCollection_SparseArray<TheItemType>::operator(),
             py::is_operator(),
             R"#(Access to the item - operator())#" ,py::arg("theIndex"))
        .def("__len__",[](const NCollection_SparseArray<TheItemType> &self)
             { return self.Extent(); }
             )
        .def("__len__",[](const NCollection_SparseArray<TheItemType> &self)
             { return self.Size(); }
             )
        .def("__bool__",[](const NCollection_SparseArray<TheItemType> &self)
             { return self.IsEmpty(); }
             )
    ;
};

template <typename Category,typename BaseIndexedMap,typename ItemType,bool IsConstant>
void preregister_template_NCollection_IndexedIterator(py::object &m, const char *name){
    py::class_<NCollection_IndexedIterator<Category,BaseIndexedMap,ItemType,IsConstant> , shared_ptr<NCollection_IndexedIterator<Category,BaseIndexedMap,ItemType,IsConstant>> >(m,name,R"#(Helper class that allows to use NCollection iterators as STL iterators. NCollection iterator can be extended to STL iterator of any category by adding necessary methods: STL forward iterator requires IsEqual method, STL bidirectional iterator requires Previous method, and STL random access iterator requires Offset and Differ methods. See NCollection_DynamicArray as example of declaring custom STL iterators.)#");
}

template <typename Category,typename BaseIndexedMap,typename ItemType,bool IsConstant>
void register_template_NCollection_IndexedIterator(py::object &m, const char *name){
    static_cast<py::class_<NCollection_IndexedIterator<Category,BaseIndexedMap,ItemType,IsConstant> , shared_ptr<NCollection_IndexedIterator<Category,BaseIndexedMap,ItemType,IsConstant>> >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const BaseIndexedMap & >() ,py::arg("theMap") )
        .def(py::init<  const size_t, const BaseIndexedMap & >() ,py::arg("theIndex"), py::arg("theMap") )
        .def(py::init<  const NCollection_IndexedIterator<Category, BaseIndexedMap, ItemType, false> & >() ,py::arg("theOther") )
        .def("__iadd__",
             (NCollection_IndexedIterator<Category, BaseIndexedMap, ItemType, IsConstant> & (NCollection_IndexedIterator<Category,BaseIndexedMap,ItemType,IsConstant>::*)( typename NCollection_IndexedIterator<Category, BaseIndexedMap, ItemType, IsConstant>::difference_type  ) ) &NCollection_IndexedIterator<Category,BaseIndexedMap,ItemType,IsConstant>::operator+=,
             py::is_operator(),
             R"#(Move forward)#" ,py::arg("theOffset"))
        .def("__add__",
             (NCollection_IndexedIterator<Category, BaseIndexedMap, ItemType, IsConstant> (NCollection_IndexedIterator<Category,BaseIndexedMap,ItemType,IsConstant>::*)( typename NCollection_IndexedIterator<Category, BaseIndexedMap, ItemType, IsConstant>::difference_type  ) const) &NCollection_IndexedIterator<Category,BaseIndexedMap,ItemType,IsConstant>::operator+,
             py::is_operator(),
             R"#(Addition)#" ,py::arg("theOffset"))
        .def("__isub__",
             (NCollection_IndexedIterator<Category, BaseIndexedMap, ItemType, IsConstant> & (NCollection_IndexedIterator<Category,BaseIndexedMap,ItemType,IsConstant>::*)( typename NCollection_IndexedIterator<Category, BaseIndexedMap, ItemType, IsConstant>::difference_type  ) ) &NCollection_IndexedIterator<Category,BaseIndexedMap,ItemType,IsConstant>::operator-=,
             py::is_operator(),
             R"#(Move backward)#" ,py::arg("theOffset"))
        .def("__sub__",
             (NCollection_IndexedIterator<Category, BaseIndexedMap, ItemType, IsConstant> (NCollection_IndexedIterator<Category,BaseIndexedMap,ItemType,IsConstant>::*)( typename NCollection_IndexedIterator<Category, BaseIndexedMap, ItemType, IsConstant>::difference_type  ) const) &NCollection_IndexedIterator<Category,BaseIndexedMap,ItemType,IsConstant>::operator-,
             py::is_operator(),
             R"#(Decrease)#" ,py::arg("theOffset"))
        .def("__sub__",
             (typename NCollection_IndexedIterator<Category,BaseIndexedMap,ItemType,IsConstant>::difference_type (NCollection_IndexedIterator<Category,BaseIndexedMap,ItemType,IsConstant>::*)(  const NCollection_IndexedIterator<Category, BaseIndexedMap, ItemType, IsConstant> &  ) const) &NCollection_IndexedIterator<Category,BaseIndexedMap,ItemType,IsConstant>::operator-,
             py::is_operator(),
             R"#(Difference)#" ,py::arg("theOther"))
    ;
};

template <typename TheItemType>
void preregister_template_NCollection_HSequence(py::object &m, const char *name){
    py::class_<NCollection_HSequence<TheItemType> , opencascade::handle<NCollection_HSequence<TheItemType>> , NCollection_Sequence<TheItemType> , Standard_Transient >(m,name,R"#(Template class for Handle-managed sequences. Inherits from both NCollection_Sequence<TheItemType> and Standard_Transient, providing reference-counted sequence functionality.)#");
}

template <typename TheItemType>
void register_template_NCollection_HSequence(py::object &m, const char *name){
    static_cast<py::class_<NCollection_HSequence<TheItemType> , opencascade::handle<NCollection_HSequence<TheItemType>> , NCollection_Sequence<TheItemType> , Standard_Transient >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const typename NCollection_HSequence<TheItemType>::SequenceType & >() ,py::arg("theOther") )
        .def("Sequence",
             ( const typename NCollection_HSequence<TheItemType>::SequenceType & (NCollection_HSequence<TheItemType>::*)() const) &NCollection_HSequence<TheItemType>::Sequence,
             R"#(Returns const reference to the underlying sequence.)#" )
        .def("ChangeSequence",
             (typename NCollection_HSequence<TheItemType>::SequenceType & (NCollection_HSequence<TheItemType>::*)() ) &NCollection_HSequence<TheItemType>::ChangeSequence,
             R"#(Returns mutable reference to the underlying sequence.)#" )
        .def("Append",
             (void (NCollection_HSequence<TheItemType>::*)(  const TheItemType &  ) ) &NCollection_HSequence<TheItemType>::Append,
             R"#(Append single item.)#" ,py::arg("theItem"))
        .def("Append",
             (void (NCollection_HSequence<TheItemType>::*)( typename NCollection_HSequence<TheItemType>::SequenceType &  ) ) &NCollection_HSequence<TheItemType>::Append,
             R"#(Append another sequence.)#" ,py::arg("theSequence"))
        .def("DynamicType",
             ( const handle<Standard_Type> & (NCollection_HSequence<TheItemType>::*)() const) &NCollection_HSequence<TheItemType>::DynamicType,
             R"#()#" )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) &NCollection_HSequence<TheItemType>::get_type_name,
                    R"#()#" )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) &NCollection_HSequence<TheItemType>::get_type_descriptor,
                    R"#()#" )
    ;
};

template <typename TheItemType>
void preregister_template_NCollection_DynamicArray(py::object &m, const char *name){
    py::class_<NCollection_DynamicArray<TheItemType> , shared_ptr<NCollection_DynamicArray<TheItemType>> >(m,name,R"#(Class NCollection_DynamicArray (dynamic array of objects))#");
}

template <typename TheItemType>
void register_template_NCollection_DynamicArray(py::object &m, const char *name){
    static_cast<py::class_<NCollection_DynamicArray<TheItemType> , shared_ptr<NCollection_DynamicArray<TheItemType>> >>(m.attr(name))
        .def(py::init<  const size_t >() ,py::arg("theIncrement") )
        .def(py::init<  const int >() ,py::arg("theIncrement")=static_cast< const int>(256) )
        .def(py::init<  const size_t, const handle<NCollection_BaseAllocator> & >() ,py::arg("theIncrement"), py::arg("theAllocator") )
        .def(py::init<  const int, const handle<NCollection_BaseAllocator> & >() ,py::arg("theIncrement"), py::arg("theAllocator") )
        .def(py::init<  const size_t, const typename NCollection_DynamicArray<TheItemType>::allocator_type & >() ,py::arg("theIncrement"), py::arg("theAllocator") )
        .def(py::init<  const int, const typename NCollection_DynamicArray<TheItemType>::allocator_type & >() ,py::arg("theIncrement"), py::arg("theAllocator") )
        .def(py::init<  const NCollection_DynamicArray<TheItemType> & >() ,py::arg("theOther") )
        .def("Size",
             (size_t (NCollection_DynamicArray<TheItemType>::*)() const) &NCollection_DynamicArray<TheItemType>::Size,
             R"#(Total number of items in the vector.)#" )
        .def("Length",
             (int (NCollection_DynamicArray<TheItemType>::*)() const) &NCollection_DynamicArray<TheItemType>::Length,
             R"#(Total number of items (legacy int-returning API).)#" )
        .def("Lower",
             (int (NCollection_DynamicArray<TheItemType>::*)() const) &NCollection_DynamicArray<TheItemType>::Lower,
             R"#(Method for consistency with other collections.)#" )
        .def("Upper",
             (int (NCollection_DynamicArray<TheItemType>::*)() const) &NCollection_DynamicArray<TheItemType>::Upper,
             R"#(Method for consistency with other collections.)#" )
        .def("IsEmpty",
             (bool (NCollection_DynamicArray<TheItemType>::*)() const) &NCollection_DynamicArray<TheItemType>::IsEmpty,
             R"#(Empty query)#" )
        .def("Assign",
             (NCollection_DynamicArray<TheItemType> & (NCollection_DynamicArray<TheItemType>::*)(  const NCollection_DynamicArray<TheItemType> & ,   const bool  ) ) &NCollection_DynamicArray<TheItemType>::Assign,
             R"#(Assignment to the collection of the same type)#" ,py::arg("theOther"), py::arg("theOwnAllocator")=static_cast< const bool>(true))
        .def("Append",
             (typename NCollection_DynamicArray<TheItemType>::reference (NCollection_DynamicArray<TheItemType>::*)(  const TheItemType &  ) ) &NCollection_DynamicArray<TheItemType>::Append,
             R"#(Append)#" ,py::arg("theValue"))
        .def("InsertAfter",
             (typename NCollection_DynamicArray<TheItemType>::reference (NCollection_DynamicArray<TheItemType>::*)(  const size_t ,   const TheItemType &  ) ) &NCollection_DynamicArray<TheItemType>::InsertAfter,
             R"#(Insert a value after the element at theIndex, shifting subsequent elements right.)#" ,py::arg("theIndex"), py::arg("theValue"))
        .def("InsertAfter",
             (typename NCollection_DynamicArray<TheItemType>::reference (NCollection_DynamicArray<TheItemType>::*)(  const int ,   const TheItemType &  ) ) &NCollection_DynamicArray<TheItemType>::InsertAfter,
             R"#()#" ,py::arg("theIndex"), py::arg("theValue"))
        .def("InsertBefore",
             (typename NCollection_DynamicArray<TheItemType>::reference (NCollection_DynamicArray<TheItemType>::*)(  const size_t ,   const TheItemType &  ) ) &NCollection_DynamicArray<TheItemType>::InsertBefore,
             R"#(Insert a value before the element at theIndex, shifting it and subsequent elements right.)#" ,py::arg("theIndex"), py::arg("theValue"))
        .def("InsertBefore",
             (typename NCollection_DynamicArray<TheItemType>::reference (NCollection_DynamicArray<TheItemType>::*)(  const int ,   const TheItemType &  ) ) &NCollection_DynamicArray<TheItemType>::InsertBefore,
             R"#()#" ,py::arg("theIndex"), py::arg("theValue"))
        .def("EraseLast",
             (void (NCollection_DynamicArray<TheItemType>::*)() ) &NCollection_DynamicArray<TheItemType>::EraseLast,
             R"#()#" )
        .def("Appended",
             (typename NCollection_DynamicArray<TheItemType>::reference (NCollection_DynamicArray<TheItemType>::*)() ) &NCollection_DynamicArray<TheItemType>::Appended,
             R"#(Appends an empty value and returns the reference to it)#" )
        .def("Value",
             (typename NCollection_DynamicArray<TheItemType>::const_reference (NCollection_DynamicArray<TheItemType>::*)(  const size_t  ) const) &NCollection_DynamicArray<TheItemType>::Value,
             R"#()#" ,py::arg("theIndex"))
        .def("Value",
             (typename NCollection_DynamicArray<TheItemType>::const_reference (NCollection_DynamicArray<TheItemType>::*)(  const int  ) const) &NCollection_DynamicArray<TheItemType>::Value,
             R"#()#" ,py::arg("theIndex"))
        .def("First",
             (typename NCollection_DynamicArray<TheItemType>::const_reference (NCollection_DynamicArray<TheItemType>::*)() const) &NCollection_DynamicArray<TheItemType>::First,
             R"#(Returns first element)#" )
        .def("ChangeFirst",
             (typename NCollection_DynamicArray<TheItemType>::reference (NCollection_DynamicArray<TheItemType>::*)() ) &NCollection_DynamicArray<TheItemType>::ChangeFirst,
             R"#(Returns first element)#" )
        .def("Last",
             (typename NCollection_DynamicArray<TheItemType>::const_reference (NCollection_DynamicArray<TheItemType>::*)() const) &NCollection_DynamicArray<TheItemType>::Last,
             R"#(Returns last element)#" )
        .def("ChangeLast",
             (typename NCollection_DynamicArray<TheItemType>::reference (NCollection_DynamicArray<TheItemType>::*)() ) &NCollection_DynamicArray<TheItemType>::ChangeLast,
             R"#(Returns last element)#" )
        .def("ChangeValue",
             (typename NCollection_DynamicArray<TheItemType>::reference (NCollection_DynamicArray<TheItemType>::*)(  const size_t  ) ) &NCollection_DynamicArray<TheItemType>::ChangeValue,
             R"#()#" ,py::arg("theIndex"))
        .def("ChangeValue",
             (typename NCollection_DynamicArray<TheItemType>::reference (NCollection_DynamicArray<TheItemType>::*)(  const int  ) ) &NCollection_DynamicArray<TheItemType>::ChangeValue,
             R"#()#" ,py::arg("theIndex"))
        .def("SetValue",
             (typename NCollection_DynamicArray<TheItemType>::reference (NCollection_DynamicArray<TheItemType>::*)(  const size_t ,   const TheItemType &  ) ) &NCollection_DynamicArray<TheItemType>::SetValue,
             R"#(SetValue () - set or append a value)#" ,py::arg("theIndex"), py::arg("theValue"))
        .def("SetValue",
             (typename NCollection_DynamicArray<TheItemType>::reference (NCollection_DynamicArray<TheItemType>::*)(  const int ,   const TheItemType &  ) ) &NCollection_DynamicArray<TheItemType>::SetValue,
             R"#()#" ,py::arg("theIndex"), py::arg("theValue"))
        .def("Clear",
             (void (NCollection_DynamicArray<TheItemType>::*)(  const bool  ) ) &NCollection_DynamicArray<TheItemType>::Clear,
             R"#()#" ,py::arg("theReleaseMemory")=static_cast< const bool>(false))
        .def("SetIncrement",
             (void (NCollection_DynamicArray<TheItemType>::*)(  const size_t  ) ) &NCollection_DynamicArray<TheItemType>::SetIncrement,
             R"#()#" ,py::arg("theIncrement"))
        .def("SetIncrement",
             (void (NCollection_DynamicArray<TheItemType>::*)(  const int  ) ) &NCollection_DynamicArray<TheItemType>::SetIncrement,
             R"#()#" ,py::arg("theIncrement"))
        .def("__call__",
             (typename NCollection_DynamicArray<TheItemType>::const_reference (NCollection_DynamicArray<TheItemType>::*)(  const size_t  ) const) &NCollection_DynamicArray<TheItemType>::operator(),
             py::is_operator(),
             R"#(Operator() - query the const value)#" ,py::arg("theIndex"))
        .def("__call__",
             (typename NCollection_DynamicArray<TheItemType>::const_reference (NCollection_DynamicArray<TheItemType>::*)(  const int  ) const) &NCollection_DynamicArray<TheItemType>::operator(),
             py::is_operator(),
             R"#()#" ,py::arg("theIndex"))
        .def("__call__",
             (typename NCollection_DynamicArray<TheItemType>::reference (NCollection_DynamicArray<TheItemType>::*)(  const size_t  ) ) &NCollection_DynamicArray<TheItemType>::operator(),
             py::is_operator(),
             R"#(Operator() - query the value)#" ,py::arg("theIndex"))
        .def("__call__",
             (typename NCollection_DynamicArray<TheItemType>::reference (NCollection_DynamicArray<TheItemType>::*)(  const int  ) ) &NCollection_DynamicArray<TheItemType>::operator(),
             py::is_operator(),
             R"#()#" ,py::arg("theIndex"))
        .def("__iter__",[](const NCollection_DynamicArray<TheItemType> &self)
             { return py::make_iterator<py::return_value_policy::copy>(self.begin(), self.end()); },
             py::keep_alive<0, 1>())
        .def("__len__",[](const NCollection_DynamicArray<TheItemType> &self)
             { return self.Size(); }
             )
        .def("__bool__",[](const NCollection_DynamicArray<TheItemType> &self)
             { return self.IsEmpty(); }
             )
    ;
};

template <typename Element_t>
void preregister_template_NCollection_Vec3(py::object &m, const char *name){
    py::class_<NCollection_Vec3<Element_t> , shared_ptr<NCollection_Vec3<Element_t>> >(m,name,R"#(Generic 3-components vector. To be used as RGB color pixel or XYZ 3D-point. The main target for this class - to handle raw low-level arrays (from/to graphic driver etc.).)#");
}

template <typename Element_t>
void register_template_NCollection_Vec3(py::object &m, const char *name){
    static_cast<py::class_<NCollection_Vec3<Element_t> , shared_ptr<NCollection_Vec3<Element_t>> >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init< Element_t >() ,py::arg("theValue") )
        .def(py::init<  const Element_t, const Element_t, const Element_t >() ,py::arg("theX"), py::arg("theY"), py::arg("theZ") )
        .def(py::init<  const NCollection_Vec2<Element_t> &,Element_t >() ,py::arg("theVec2"), py::arg("theZ")=static_cast<Element_t>(Element_t ( 0 )) )
        .def("SetValues",
             (void (NCollection_Vec3<Element_t>::*)(  const Element_t ,   const Element_t ,   const Element_t  ) ) &NCollection_Vec3<Element_t>::SetValues,
             R"#(Assign new values to the vector.)#" ,py::arg("theX"), py::arg("theY"), py::arg("theZ"))
        .def("SetValues",
             (void (NCollection_Vec3<Element_t>::*)(  const NCollection_Vec2<Element_t> & ,  Element_t  ) ) &NCollection_Vec3<Element_t>::SetValues,
             R"#(Assign new values to the vector.)#" ,py::arg("theVec2"), py::arg("theZ"))
        .def("x",
             (Element_t (NCollection_Vec3<Element_t>::*)() const) &NCollection_Vec3<Element_t>::x,
             R"#(Alias to 1st component as X coordinate in XYZ.)#" )
        .def("r",
             (Element_t (NCollection_Vec3<Element_t>::*)() const) &NCollection_Vec3<Element_t>::r,
             R"#(Alias to 1st component as RED channel in RGB.)#" )
        .def("y",
             (Element_t (NCollection_Vec3<Element_t>::*)() const) &NCollection_Vec3<Element_t>::y,
             R"#(Alias to 2nd component as Y coordinate in XYZ.)#" )
        .def("g",
             (Element_t (NCollection_Vec3<Element_t>::*)() const) &NCollection_Vec3<Element_t>::g,
             R"#(Alias to 2nd component as GREEN channel in RGB.)#" )
        .def("z",
             (Element_t (NCollection_Vec3<Element_t>::*)() const) &NCollection_Vec3<Element_t>::z,
             R"#(Alias to 3rd component as Z coordinate in XYZ.)#" )
        .def("b",
             (Element_t (NCollection_Vec3<Element_t>::*)() const) &NCollection_Vec3<Element_t>::b,
             R"#(Alias to 3rd component as BLUE channel in RGB.)#" )
        .def("xy",
             (NCollection_Vec2<Element_t> (NCollection_Vec3<Element_t>::*)() const) &NCollection_Vec3<Element_t>::xy,
             R"#(Returns 2 components by their names in specified order (in GLSL-style))#" )
        .def("yx",
             (NCollection_Vec2<Element_t> (NCollection_Vec3<Element_t>::*)() const) &NCollection_Vec3<Element_t>::yx,
             R"#(Returns 2 components by their names in specified order (in GLSL-style))#" )
        .def("xz",
             (NCollection_Vec2<Element_t> (NCollection_Vec3<Element_t>::*)() const) &NCollection_Vec3<Element_t>::xz,
             R"#(Returns 2 components by their names in specified order (in GLSL-style))#" )
        .def("zx",
             (NCollection_Vec2<Element_t> (NCollection_Vec3<Element_t>::*)() const) &NCollection_Vec3<Element_t>::zx,
             R"#(Returns 2 components by their names in specified order (in GLSL-style))#" )
        .def("yz",
             (NCollection_Vec2<Element_t> (NCollection_Vec3<Element_t>::*)() const) &NCollection_Vec3<Element_t>::yz,
             R"#(Returns 2 components by their names in specified order (in GLSL-style))#" )
        .def("zy",
             (NCollection_Vec2<Element_t> (NCollection_Vec3<Element_t>::*)() const) &NCollection_Vec3<Element_t>::zy,
             R"#(Returns 2 components by their names in specified order (in GLSL-style))#" )
        .def("xyz",
             (NCollection_Vec3<Element_t> (NCollection_Vec3<Element_t>::*)() const) &NCollection_Vec3<Element_t>::xyz,
             R"#(Returns 3 components by their names in specified order (in GLSL-style))#" )
        .def("xzy",
             (NCollection_Vec3<Element_t> (NCollection_Vec3<Element_t>::*)() const) &NCollection_Vec3<Element_t>::xzy,
             R"#(Returns 3 components by their names in specified order (in GLSL-style))#" )
        .def("yxz",
             (NCollection_Vec3<Element_t> (NCollection_Vec3<Element_t>::*)() const) &NCollection_Vec3<Element_t>::yxz,
             R"#(Returns 3 components by their names in specified order (in GLSL-style))#" )
        .def("yzx",
             (NCollection_Vec3<Element_t> (NCollection_Vec3<Element_t>::*)() const) &NCollection_Vec3<Element_t>::yzx,
             R"#(Returns 3 components by their names in specified order (in GLSL-style))#" )
        .def("zyx",
             (NCollection_Vec3<Element_t> (NCollection_Vec3<Element_t>::*)() const) &NCollection_Vec3<Element_t>::zyx,
             R"#(Returns 3 components by their names in specified order (in GLSL-style))#" )
        .def("zxy",
             (NCollection_Vec3<Element_t> (NCollection_Vec3<Element_t>::*)() const) &NCollection_Vec3<Element_t>::zxy,
             R"#(Returns 3 components by their names in specified order (in GLSL-style))#" )
        .def("x",
             (Element_t & (NCollection_Vec3<Element_t>::*)() ) &NCollection_Vec3<Element_t>::x,
             R"#(Alias to 1st component as X coordinate in XYZ.)#" )
        .def("r",
             (Element_t & (NCollection_Vec3<Element_t>::*)() ) &NCollection_Vec3<Element_t>::r,
             R"#(Alias to 1st component as RED channel in RGB.)#" )
        .def("y",
             (Element_t & (NCollection_Vec3<Element_t>::*)() ) &NCollection_Vec3<Element_t>::y,
             R"#(Alias to 2nd component as Y coordinate in XYZ.)#" )
        .def("g",
             (Element_t & (NCollection_Vec3<Element_t>::*)() ) &NCollection_Vec3<Element_t>::g,
             R"#(Alias to 2nd component as GREEN channel in RGB.)#" )
        .def("z",
             (Element_t & (NCollection_Vec3<Element_t>::*)() ) &NCollection_Vec3<Element_t>::z,
             R"#(Alias to 3rd component as Z coordinate in XYZ.)#" )
        .def("b",
             (Element_t & (NCollection_Vec3<Element_t>::*)() ) &NCollection_Vec3<Element_t>::b,
             R"#(Alias to 3rd component as BLUE channel in RGB.)#" )
        .def("IsEqual",
             (bool (NCollection_Vec3<Element_t>::*)(  const NCollection_Vec3<Element_t> &  ) const) &NCollection_Vec3<Element_t>::IsEqual,
             R"#(Check this vector with another vector for equality (without tolerance!).)#" ,py::arg("theOther"))
        .def("GetData",
             ( const Element_t * (NCollection_Vec3<Element_t>::*)() const) &NCollection_Vec3<Element_t>::GetData,
             R"#(Raw access to the data (for OpenGL exchange).)#" )
        .def("ChangeData",
             (Element_t * (NCollection_Vec3<Element_t>::*)() ) &NCollection_Vec3<Element_t>::ChangeData,
             R"#()#" )
        .def("Multiply",
             (void (NCollection_Vec3<Element_t>::*)(  const Element_t  ) ) &NCollection_Vec3<Element_t>::Multiply,
             R"#(Compute per-component multiplication by scale factor.)#" ,py::arg("theFactor"))
        .def("Multiplied",
             (NCollection_Vec3<Element_t> (NCollection_Vec3<Element_t>::*)(  const Element_t  ) const) &NCollection_Vec3<Element_t>::Multiplied,
             R"#(Compute per-component multiplication by scale factor.)#" ,py::arg("theFactor"))
        .def("cwiseMin",
             (NCollection_Vec3<Element_t> (NCollection_Vec3<Element_t>::*)(  const NCollection_Vec3<Element_t> &  ) const) &NCollection_Vec3<Element_t>::cwiseMin,
             R"#(Compute component-wise minimum of two vectors.)#" ,py::arg("theVec"))
        .def("cwiseMax",
             (NCollection_Vec3<Element_t> (NCollection_Vec3<Element_t>::*)(  const NCollection_Vec3<Element_t> &  ) const) &NCollection_Vec3<Element_t>::cwiseMax,
             R"#(Compute component-wise maximum of two vectors.)#" ,py::arg("theVec"))
        .def("cwiseAbs",
             (NCollection_Vec3<Element_t> (NCollection_Vec3<Element_t>::*)() const) &NCollection_Vec3<Element_t>::cwiseAbs,
             R"#(Compute component-wise modulus of the vector.)#" )
        .def("maxComp",
             (Element_t (NCollection_Vec3<Element_t>::*)() const) &NCollection_Vec3<Element_t>::maxComp,
             R"#(Compute maximum component of the vector.)#" )
        .def("minComp",
             (Element_t (NCollection_Vec3<Element_t>::*)() const) &NCollection_Vec3<Element_t>::minComp,
             R"#(Compute minimum component of the vector.)#" )
        .def("Dot",
             (Element_t (NCollection_Vec3<Element_t>::*)(  const NCollection_Vec3<Element_t> &  ) const) &NCollection_Vec3<Element_t>::Dot,
             R"#(Computes the dot product.)#" ,py::arg("theOther"))
        .def("Modulus",
             (Element_t (NCollection_Vec3<Element_t>::*)() const) &NCollection_Vec3<Element_t>::Modulus,
             R"#(Computes the vector modulus (magnitude, length).)#" )
        .def("SquareModulus",
             (Element_t (NCollection_Vec3<Element_t>::*)() const) &NCollection_Vec3<Element_t>::SquareModulus,
             R"#(Computes the square of vector modulus (magnitude, length). This method may be used for performance tricks.)#" )
        .def("Normalize",
             (void (NCollection_Vec3<Element_t>::*)() ) &NCollection_Vec3<Element_t>::Normalize,
             R"#(Normalize the vector.)#" )
        .def("Normalized",
             (NCollection_Vec3<Element_t> (NCollection_Vec3<Element_t>::*)() const) &NCollection_Vec3<Element_t>::Normalized,
             R"#(Normalize the vector.)#" )
        .def("DumpJson",
             (void (NCollection_Vec3<Element_t>::*)( Standard_OStream & ,  int  ) const) &NCollection_Vec3<Element_t>::DumpJson,
             R"#(Dumps the content of me into the stream)#" ,py::arg("theOStream"), py::arg("theDepth")=static_cast<int>(- 1))
        .def_static("Length_s",
                    (int (*)() ) &NCollection_Vec3<Element_t>::Length,
                    R"#(Returns the number of components.)#" )
        .def_static("Cross_s",
                    (NCollection_Vec3<Element_t> (*)(  const NCollection_Vec3<Element_t> & ,   const NCollection_Vec3<Element_t> &  ) ) &NCollection_Vec3<Element_t>::Cross,
                    R"#(Computes the cross product.)#" ,py::arg("theVec1"), py::arg("theVec2"))
        .def_static("GetLERP_s",
                    (NCollection_Vec3<Element_t> (*)(  const NCollection_Vec3<Element_t> & ,   const NCollection_Vec3<Element_t> & ,   const Element_t  ) ) &NCollection_Vec3<Element_t>::GetLERP,
                    R"#(Compute linear interpolation between to vectors.)#" ,py::arg("theFrom"), py::arg("theTo"), py::arg("theT"))
        .def_static("DX_s",
                    (NCollection_Vec3<Element_t> (*)() ) &NCollection_Vec3<Element_t>::DX,
                    R"#(Construct DX unit vector.)#" )
        .def_static("DY_s",
                    (NCollection_Vec3<Element_t> (*)() ) &NCollection_Vec3<Element_t>::DY,
                    R"#(Construct DY unit vector.)#" )
        .def_static("DZ_s",
                    (NCollection_Vec3<Element_t> (*)() ) &NCollection_Vec3<Element_t>::DZ,
                    R"#(Construct DZ unit vector.)#" )
        .def("__iadd__",
             (NCollection_Vec3<Element_t> & (NCollection_Vec3<Element_t>::*)(  const NCollection_Vec3<Element_t> &  ) ) &NCollection_Vec3<Element_t>::operator+=,
             py::is_operator(),
             R"#(Compute per-component summary.)#" ,py::arg("theAdd"))
        .def("__neg__",
             (NCollection_Vec3<Element_t> (NCollection_Vec3<Element_t>::*)() const) &NCollection_Vec3<Element_t>::operator-,
             py::is_operator(),
             R"#(Unary -.)#" )
        .def("__isub__",
             (NCollection_Vec3<Element_t> & (NCollection_Vec3<Element_t>::*)(  const NCollection_Vec3<Element_t> &  ) ) &NCollection_Vec3<Element_t>::operator-=,
             py::is_operator(),
             R"#(Compute per-component subtraction.)#" ,py::arg("theDec"))
        .def("__imul__",
             (NCollection_Vec3<Element_t> & (NCollection_Vec3<Element_t>::*)(  const NCollection_Vec3<Element_t> &  ) ) &NCollection_Vec3<Element_t>::operator*=,
             py::is_operator(),
             R"#(Compute per-component multiplication.)#" ,py::arg("theRight"))
        .def("__imul__",
             (NCollection_Vec3<Element_t> & (NCollection_Vec3<Element_t>::*)(  const Element_t  ) ) &NCollection_Vec3<Element_t>::operator*=,
             py::is_operator(),
             R"#(Compute per-component multiplication by scale factor.)#" ,py::arg("theFactor"))
        .def("__mul__",
             (NCollection_Vec3<Element_t> (NCollection_Vec3<Element_t>::*)(  const Element_t  ) const) &NCollection_Vec3<Element_t>::operator*,
             py::is_operator(),
             R"#(Compute per-component multiplication by scale factor.)#" ,py::arg("theFactor"))
        .def("__rmul__",
             (NCollection_Vec3<Element_t> (NCollection_Vec3<Element_t>::*)(  const Element_t  ) const) &NCollection_Vec3<Element_t>::operator*,
             py::is_operator(),
             R"#(Compute per-component multiplication by scale factor.)#" ,py::arg("theFactor"))
        .def("__itruediv__",
             (NCollection_Vec3<Element_t> & (NCollection_Vec3<Element_t>::*)(  const Element_t  ) ) &NCollection_Vec3<Element_t>::operator/=,
             py::is_operator(),
             R"#(Compute per-component division by scale factor.)#" ,py::arg("theInvFactor"))
        .def("__itruediv__",
             (NCollection_Vec3<Element_t> & (NCollection_Vec3<Element_t>::*)(  const NCollection_Vec3<Element_t> &  ) ) &NCollection_Vec3<Element_t>::operator/=,
             py::is_operator(),
             R"#(Compute per-component division.)#" ,py::arg("theRight"))
        .def("__truediv__",
             (NCollection_Vec3<Element_t> (NCollection_Vec3<Element_t>::*)(  const Element_t  ) const) &NCollection_Vec3<Element_t>::operator/,
             py::is_operator(),
             R"#(Compute per-component division by scale factor.)#" ,py::arg("theInvFactor"))
    ;
};

template <typename TheKeyType,typename TheItemType,typename Hasher=NCollection_DefaultHasher<TheKeyType>>
void preregister_template_NCollection_IndexedDataMap(py::object &m, const char *name){
    py::class_<NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher> , shared_ptr<NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>> , NCollection_BaseMap >(m,name,R"#(Purpose: An indexed map is used to store keys and to bind an index to them. Each new key stored in the map gets an index. Index are incremented as keys are stored in the map. A key can be found by the index and an index by the key. No key but the last can be removed so the indices are in the range 1.. Extent. An Item is stored with each key.)#");
}

template <typename TheKeyType,typename TheItemType,typename Hasher=NCollection_DefaultHasher<TheKeyType>>
void register_template_NCollection_IndexedDataMap(py::object &m, const char *name){
    static_cast<py::class_<NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher> , shared_ptr<NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>> , NCollection_BaseMap >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const size_t, const handle<NCollection_BaseAllocator> & >() ,py::arg("theNbBuckets"), py::arg("theAllocator")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr) )
        .def(py::init<  const int, const handle<NCollection_BaseAllocator> & >() ,py::arg("theNbBuckets"), py::arg("theAllocator")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr) )
        .def(py::init<  const Hasher &, const size_t, const handle<NCollection_BaseAllocator> & >() ,py::arg("theHasher"), py::arg("theNbBuckets")=static_cast< const size_t>(1), py::arg("theAllocator")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr) )
        .def(py::init<  const Hasher &, const int, const handle<NCollection_BaseAllocator> & >() ,py::arg("theHasher"), py::arg("theNbBuckets"), py::arg("theAllocator")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr) )
        .def(py::init<  const NCollection_IndexedDataMap<TheKeyType, TheItemType, Hasher> & >() ,py::arg("theOther") )
        .def("Items",
             (typename NCollection_IndexedDataMap<TheKeyType, TheItemType, Hasher>::ItemsView (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)() ) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::Items,
             R"#(Returns a view for key-value pair iteration. Usage: for (auto [aKey, aValue] : aMap.Items()))#" )
        .def("Items",
             (typename NCollection_IndexedDataMap<TheKeyType, TheItemType, Hasher>::ConstItemsView (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)() const) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::Items,
             R"#(Returns a const view for key-value pair iteration. Usage: for (const auto& [aKey, aValue] : aMap.Items()))#" )
        .def("IndexedItems",
             (typename NCollection_IndexedDataMap<TheKeyType, TheItemType, Hasher>::IndexedItemsView (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)() ) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::IndexedItems,
             R"#(Returns a view for key-value-index tuple iteration. Usage: for (auto [aKey, aValue, anIndex] : aMap.IndexedItems()))#" )
        .def("IndexedItems",
             (typename NCollection_IndexedDataMap<TheKeyType, TheItemType, Hasher>::ConstIndexedItemsView (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)() const) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::IndexedItems,
             R"#(Returns a const view for key-value-index tuple iteration. Usage: for (const auto& [aKey, aValue, anIndex] : aMap.IndexedItems()))#" )
        .def("Exchange",
             (void (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)( NCollection_IndexedDataMap<TheKeyType, TheItemType, Hasher> &  ) ) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::Exchange,
             R"#(Exchange the content of two maps without re-allocations. Notice that allocators will be swapped as well!)#" ,py::arg("theOther"))
        .def("GetHasher",
             ( const Hasher & (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)() const) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::GetHasher,
             R"#(Returns const reference to the hasher.)#" )
        .def("Assign",
             (NCollection_IndexedDataMap<TheKeyType, TheItemType, Hasher> & (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const NCollection_IndexedDataMap<TheKeyType, TheItemType, Hasher> &  ) ) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::Assign,
             R"#(Assignment. This method does not change the internal allocator.)#" ,py::arg("theOther"))
        .def("ReSize",
             (void (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const size_t  ) ) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::ReSize,
             R"#(ReSize)#" ,py::arg("N"))
        .def("ReSize",
             (void (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const int  ) ) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::ReSize,
             R"#()#" ,py::arg("N"))
        .def("Add",
             (int (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType & ,   const TheItemType &  ) ) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::Add,
             R"#(Returns the Index of already bound Key or appends new Key with specified Item value.)#" ,py::arg("theKey1"), py::arg("theItem"))
        .def("TryBound",
             (TheItemType & (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType & ,   const TheItemType &  ) ) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::TryBound,
             R"#(TryBound binds Item to Key only if Key is not yet bound.)#" ,py::arg("theKey1"), py::arg("theItem"))
        .def("TryBind",
             (bool (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType & ,   const TheItemType &  ) ) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::TryBind,
             R"#(TryBind binds Item to Key only if Key is not yet bound.)#" ,py::arg("theKey1"), py::arg("theItem"))
        .def("Bind",
             (bool (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType & ,   const TheItemType &  ) ) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::Bind,
             R"#(Bind binds Item to Key in map; overwrites value if Key already exists.)#" ,py::arg("theKey1"), py::arg("theItem"))
        .def("Bound",
             (TheItemType * (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType & ,   const TheItemType &  ) ) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::Bound,
             R"#(Bound binds Item to Key in map; overwrites value if Key already exists.)#" ,py::arg("theKey1"), py::arg("theItem"))
        .def("Contains",
             (bool (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType &  ) const) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::Contains,
             R"#(Contains)#" ,py::arg("theKey1"))
        .def("Substitute",
             (void (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const size_t ,   const TheKeyType & ,   const TheItemType &  ) ) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::Substitute,
             R"#(Substitute)#" ,py::arg("theIndex"), py::arg("theKey1"), py::arg("theItem"))
        .def("Substitute",
             (void (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const int ,   const TheKeyType & ,   const TheItemType &  ) ) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::Substitute,
             R"#()#" ,py::arg("theIndex"), py::arg("theKey1"), py::arg("theItem"))
        .def("Swap",
             (void (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const size_t ,   const size_t  ) ) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::Swap,
             R"#(Swaps two elements with the given indices.)#" ,py::arg("theIndex1"), py::arg("theIndex2"))
        .def("Swap",
             (void (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const int ,   const int  ) ) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::Swap,
             R"#()#" ,py::arg("theIndex1"), py::arg("theIndex2"))
        .def("RemoveLast",
             (void (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)() ) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::RemoveLast,
             R"#(RemoveLast)#" )
        .def("RemoveFromIndex",
             (void (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const size_t  ) ) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::RemoveFromIndex,
             R"#(Remove the key of the given index. Caution! The index of the last key can be changed.)#" ,py::arg("theIndex"))
        .def("RemoveFromIndex",
             (void (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const int  ) ) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::RemoveFromIndex,
             R"#()#" ,py::arg("theIndex"))
        .def("RemoveKey",
             (void (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType &  ) ) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::RemoveKey,
             R"#(Remove the given key. Caution! The index of the last key can be changed.)#" ,py::arg("theKey1"))
        .def("FindKey",
             ( const TheKeyType & (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const size_t  ) const) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::FindKey,
             R"#(FindKey)#" ,py::arg("theIndex"))
        .def("FindKey",
             ( const TheKeyType & (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const int  ) const) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::FindKey,
             R"#()#" ,py::arg("theIndex"))
        .def("FindFromIndex",
             ( const TheItemType & (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const size_t  ) const) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::FindFromIndex,
             R"#(FindFromIndex)#" ,py::arg("theIndex"))
        .def("FindFromIndex",
             ( const TheItemType & (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const int  ) const) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::FindFromIndex,
             R"#()#" ,py::arg("theIndex"))
        .def("ChangeFromIndex",
             (TheItemType & (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const size_t  ) ) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::ChangeFromIndex,
             R"#(ChangeFromIndex)#" ,py::arg("theIndex"))
        .def("ChangeFromIndex",
             (TheItemType & (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const int  ) ) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::ChangeFromIndex,
             R"#()#" ,py::arg("theIndex"))
        .def("FindIndex",
             (int (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType &  ) const) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::FindIndex,
             R"#(FindIndex)#" ,py::arg("theKey1"))
        .def("FindFromKey",
             ( const TheItemType & (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType &  ) const) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::FindFromKey,
             R"#(FindFromKey)#" ,py::arg("theKey1"))
        .def("ChangeFromKey",
             (TheItemType & (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType &  ) ) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::ChangeFromKey,
             R"#(ChangeFromKey)#" ,py::arg("theKey1"))
        .def("FindFromKey",
             (bool (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType & ,  TheItemType &  ) const) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::FindFromKey,
             R"#(Find value for key with copying.)#" ,py::arg("theKey1"), py::arg("theValue"))
        .def("Clear",
             (void (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const bool  ) ) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::Clear,
             R"#(Clear data. If doReleaseMemory is false then the table of buckets is not released and will be reused.)#" ,py::arg("doReleaseMemory")=static_cast< const bool>(false))
        .def("Clear",
             (void (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const handle<NCollection_BaseAllocator> &  ) ) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::Clear,
             R"#(Clear data and reset allocator)#" ,py::arg("theAllocator"))
        .def("__call__",
             ( const TheItemType & (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const size_t  ) const) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::operator(),
             py::is_operator(),
             R"#(operator ())#" ,py::arg("theIndex"))
        .def("__call__",
             ( const TheItemType & (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const int  ) const) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::operator(),
             py::is_operator(),
             R"#()#" ,py::arg("theIndex"))
        .def("__call__",
             (TheItemType & (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const size_t  ) ) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::operator(),
             py::is_operator(),
             R"#(operator ())#" ,py::arg("theIndex"))
        .def("__call__",
             (TheItemType & (NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const int  ) ) &NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher>::operator(),
             py::is_operator(),
             R"#()#" ,py::arg("theIndex"))
        .def("__iter__",[](const NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher> &self)
             { return py::make_iterator<py::return_value_policy::copy>(self.begin(), self.end()); },
             py::keep_alive<0, 1>())
        .def("__len__",[](const NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher> &self)
             { return self.Extent(); }
             )
        .def("__len__",[](const NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher> &self)
             { return self.Size(); }
             )
        .def("__bool__",[](const NCollection_IndexedDataMap<TheKeyType,TheItemType,Hasher> &self)
             { return self.IsEmpty(); }
             )
    ;
};

template <typename TheObjType,typename TheBndType>
void preregister_template_NCollection_UBTreeFiller(py::object &m, const char *name){
    py::class_<NCollection_UBTreeFiller<TheObjType,TheBndType> , shared_ptr<NCollection_UBTreeFiller<TheObjType,TheBndType>> >(m,name,R"#(This class is used to fill an UBTree in a random order. The quality of a tree is much better (from the point of view of the search time) if objects are added to it in a random order to avoid adding a chain of neerby objects one following each other.)#");
}

template <typename TheObjType,typename TheBndType>
void register_template_NCollection_UBTreeFiller(py::object &m, const char *name){
    static_cast<py::class_<NCollection_UBTreeFiller<TheObjType,TheBndType> , shared_ptr<NCollection_UBTreeFiller<TheObjType,TheBndType>> >>(m.attr(name))
        .def(py::init< typename NCollection_UBTreeFiller<TheObjType, TheBndType>::UBTree &, const handle<NCollection_BaseAllocator> &, const bool >() ,py::arg("theTree"), py::arg("theAlloc")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr), py::arg("isFullRandom")=static_cast< const bool>(true) )
        .def("Add",
             (void (NCollection_UBTreeFiller<TheObjType,TheBndType>::*)(  const TheObjType & ,   const TheBndType &  ) ) &NCollection_UBTreeFiller<TheObjType,TheBndType>::Add,
             R"#(Adds a pair (theObj, theBnd) to my sequence)#" ,py::arg("theObj"), py::arg("theBnd"))
        .def("Fill",
             (int (NCollection_UBTreeFiller<TheObjType,TheBndType>::*)() ) &NCollection_UBTreeFiller<TheObjType,TheBndType>::Fill,
             R"#(Fills the tree with the objects from my sequence. This method clears the internal buffer of added items making sure that no item would be added twice.)#" )
        .def("Reset",
             (void (NCollection_UBTreeFiller<TheObjType,TheBndType>::*)() ) &NCollection_UBTreeFiller<TheObjType,TheBndType>::Reset,
             R"#(Remove all data from Filler, partculary if the Tree no more needed so the destructor of this Filler should not populate the useless Tree.)#" )
        .def("CheckTree",
             (int (NCollection_UBTreeFiller<TheObjType,TheBndType>::*)( Standard_OStream &  ) ) &NCollection_UBTreeFiller<TheObjType,TheBndType>::CheckTree,
             R"#(Check the filled tree for the total number of items and the balance outputting these results to std::ostream.)#" ,py::arg("theStream"))
    ;
};

template <typename TheKey1Type,typename TheKey2Type,typename Hasher1=NCollection_DefaultHasher<TheKey1Type>,typename Hasher2=NCollection_DefaultHasher<TheKey2Type>>
void preregister_template_NCollection_DoubleMap(py::object &m, const char *name){
    py::class_<NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2> , shared_ptr<NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>> , NCollection_BaseMap >(m,name,R"#(Purpose: The DoubleMap is used to bind pairs (Key1,Key2) and retrieve them in linear time.)#");
}

template <typename TheKey1Type,typename TheKey2Type,typename Hasher1=NCollection_DefaultHasher<TheKey1Type>,typename Hasher2=NCollection_DefaultHasher<TheKey2Type>>
void register_template_NCollection_DoubleMap(py::object &m, const char *name){
    static_cast<py::class_<NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2> , shared_ptr<NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>> , NCollection_BaseMap >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const size_t, const handle<NCollection_BaseAllocator> & >() ,py::arg("theNbBuckets"), py::arg("theAllocator")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr) )
        .def(py::init<  const int, const handle<NCollection_BaseAllocator> & >() ,py::arg("theNbBuckets"), py::arg("theAllocator")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr) )
        .def(py::init<  const NCollection_DoubleMap<TheKey1Type, TheKey2Type, Hasher1, Hasher2> & >() ,py::arg("theOther") )
        .def("Exchange",
             (void (NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::*)( NCollection_DoubleMap<TheKey1Type, TheKey2Type, Hasher1, Hasher2> &  ) ) &NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::Exchange,
             R"#(Exchange the content of two maps without re-allocations. Notice that allocators will be swapped as well!)#" ,py::arg("theOther"))
        .def("Assign",
             (NCollection_DoubleMap<TheKey1Type, TheKey2Type, Hasher1, Hasher2> & (NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::*)(  const NCollection_DoubleMap<TheKey1Type, TheKey2Type, Hasher1, Hasher2> &  ) ) &NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::Assign,
             R"#(Assignment. This method does not change the internal allocator.)#" ,py::arg("theOther"))
        .def("ReSize",
             (void (NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::*)(  const size_t  ) ) &NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::ReSize,
             R"#(ReSize)#" ,py::arg("N"))
        .def("ReSize",
             (void (NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::*)(  const int  ) ) &NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::ReSize,
             R"#()#" ,py::arg("N"))
        .def("Bind",
             (void (NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::*)(  const TheKey1Type & ,   const TheKey2Type &  ) ) &NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::Bind,
             R"#(Bind binds the pair (Key1, Key2).)#" ,py::arg("theKey1"), py::arg("theKey2"))
        .def("TryBind",
             (bool (NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::*)(  const TheKey1Type & ,   const TheKey2Type &  ) ) &NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::TryBind,
             R"#(TryBind binds the pair (Key1, Key2) only if neither key is already bound.)#" ,py::arg("theKey1"), py::arg("theKey2"))
        .def("AreBound",
             (bool (NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::*)(  const TheKey1Type & ,   const TheKey2Type &  ) const) &NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::AreBound,
             R"#(* AreBound)#" ,py::arg("theKey1"), py::arg("theKey2"))
        .def("IsBound1",
             (bool (NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::*)(  const TheKey1Type &  ) const) &NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::IsBound1,
             R"#(IsBound1)#" ,py::arg("theKey1"))
        .def("IsBound2",
             (bool (NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::*)(  const TheKey2Type &  ) const) &NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::IsBound2,
             R"#(IsBound2)#" ,py::arg("theKey2"))
        .def("UnBind1",
             (bool (NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::*)(  const TheKey1Type &  ) ) &NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::UnBind1,
             R"#(UnBind1)#" ,py::arg("theKey1"))
        .def("UnBind2",
             (bool (NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::*)(  const TheKey2Type &  ) ) &NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::UnBind2,
             R"#(UnBind2)#" ,py::arg("theKey2"))
        .def("Find1",
             ( const TheKey2Type & (NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::*)(  const TheKey1Type &  ) const) &NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::Find1,
             R"#(Find the Key1 and return Key2 value. Raises an exception if Key1 was not bound.)#" ,py::arg("theKey1"))
        .def("Find1",
             (bool (NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::*)(  const TheKey1Type & ,  TheKey2Type &  ) const) &NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::Find1,
             R"#(Find the Key1 and return Key2 value (by copying its value).)#" ,py::arg("theKey1"), py::arg("theKey2"))
        .def("Seek1",
             ( const TheKey2Type * (NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::*)(  const TheKey1Type &  ) const) &NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::Seek1,
             R"#(Find the Key1 and return pointer to Key2 or NULL if Key1 is not bound.)#" ,py::arg("theKey1"))
        .def("Find2",
             ( const TheKey1Type & (NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::*)(  const TheKey2Type &  ) const) &NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::Find2,
             R"#(Find the Key2 and return Key1 value. Raises an exception if Key2 was not bound.)#" ,py::arg("theKey2"))
        .def("Find2",
             (bool (NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::*)(  const TheKey2Type & ,  TheKey1Type &  ) const) &NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::Find2,
             R"#(Find the Key2 and return Key1 value (by copying its value).)#" ,py::arg("theKey2"), py::arg("theKey1"))
        .def("Seek2",
             ( const TheKey1Type * (NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::*)(  const TheKey2Type &  ) const) &NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::Seek2,
             R"#(Find the Key2 and return pointer to Key1 or NULL if not bound.)#" ,py::arg("theKey2"))
        .def("Clear",
             (void (NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::*)(  const bool  ) ) &NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::Clear,
             R"#(Clear data. If doReleaseMemory is false then the table of buckets is not released and will be reused.)#" ,py::arg("doReleaseMemory")=static_cast< const bool>(false))
        .def("Clear",
             (void (NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::*)(  const handle<NCollection_BaseAllocator> &  ) ) &NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2>::Clear,
             R"#(Clear data and reset allocator)#" ,py::arg("theAllocator"))
        .def("__len__",[](const NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2> &self)
             { return self.Extent(); }
             )
        .def("__len__",[](const NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2> &self)
             { return self.Size(); }
             )
        .def("__bool__",[](const NCollection_DoubleMap<TheKey1Type,TheKey2Type,Hasher1,Hasher2> &self)
             { return self.IsEmpty(); }
             )
    ;
};

template <typename TheItemType>
void preregister_template_NCollection_Array1(py::object &m, const char *name){
    py::class_<NCollection_Array1<TheItemType> , shared_ptr<NCollection_Array1<TheItemType>> >(m,name,R"#(The class NCollection_Array1 represents unidimensional arrays of fixed size known at run time. The range of the index is user defined. An array1 can be constructed with a "C array". This functionality is useful to call methods expecting an Array1. It allows to carry the bounds inside the arrays.)#");
}

template <typename TheItemType>
void register_template_NCollection_Array1(py::object &m, const char *name){
    static_cast<py::class_<NCollection_Array1<TheItemType> , shared_ptr<NCollection_Array1<TheItemType>> >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const int, const int >() ,py::arg("theLower"), py::arg("theUpper") )
        .def(py::init< typename NCollection_Array1<TheItemType>::const_reference, const int, const int, const bool >() ,py::arg("theBegin"), py::arg("theLower"), py::arg("theUpper"), py::arg("theUseBuffer")=static_cast< const bool>(true) )
        .def(py::init<  const size_t >() ,py::arg("theSize") )
        .def(py::init< typename NCollection_Array1<TheItemType>::pointer, const size_t >() ,py::arg("theBegin"), py::arg("theSize") )
        .def(py::init<  const NCollection_Array1<TheItemType> & >() ,py::arg("theOther") )
        .def("Init",
             (void (NCollection_Array1<TheItemType>::*)( typename NCollection_Array1<TheItemType>::const_reference  ) ) &NCollection_Array1<TheItemType>::Init,
             R"#(Initialise the items with theValue)#" ,py::arg("theValue"))
        .def("Size",
             (size_t (NCollection_Array1<TheItemType>::*)() const) &NCollection_Array1<TheItemType>::Size,
             R"#(Size query.)#" )
        .def("Length",
             (int (NCollection_Array1<TheItemType>::*)() const) &NCollection_Array1<TheItemType>::Length,
             R"#(Length query (legacy int-returning API).)#" )
        .def("IsEmpty",
             (bool (NCollection_Array1<TheItemType>::*)() const) &NCollection_Array1<TheItemType>::IsEmpty,
             R"#(Return TRUE if array has zero length.)#" )
        .def("Lower",
             (int (NCollection_Array1<TheItemType>::*)() const) &NCollection_Array1<TheItemType>::Lower,
             R"#(Lower bound)#" )
        .def("Upper",
             (int (NCollection_Array1<TheItemType>::*)() const) &NCollection_Array1<TheItemType>::Upper,
             R"#(Upper bound)#" )
        .def("Assign",
             (NCollection_Array1<TheItemType> & (NCollection_Array1<TheItemType>::*)(  const NCollection_Array1<TheItemType> &  ) ) &NCollection_Array1<TheItemType>::Assign,
             R"#(Replaces this array by a copy of theOther array. Bounds and length are copied from theOther. When this array wraps an external (non-owned) buffer: - if theOther has the same length, values are copied in place into the external buffer and ownership is unchanged; - if theOther has a different length, this array detaches from the external buffer and allocates a fresh owned buffer. Use CopyValues() to preserve this array's bounds.)#" ,py::arg("theOther"))
        .def("CopyValues",
             (NCollection_Array1<TheItemType> & (NCollection_Array1<TheItemType>::*)(  const NCollection_Array1<TheItemType> &  ) ) &NCollection_Array1<TheItemType>::CopyValues,
             R"#(Copies values from theOther array without changing this array bounds. This array should be pre-allocated and have the same length as theOther; otherwise exception Standard_DimensionMismatch is thrown.)#" ,py::arg("theOther"))
        .def("Move",
             (NCollection_Array1<TheItemType> & (NCollection_Array1<TheItemType>::*)( NCollection_Array1<TheItemType> &  ) ) &NCollection_Array1<TheItemType>::Move,
             R"#()#" ,py::arg("theOther"))
        .def("First",
             (typename NCollection_Array1<TheItemType>::const_reference (NCollection_Array1<TheItemType>::*)() const) &NCollection_Array1<TheItemType>::First,
             R"#(Returns first element)#" )
        .def("ChangeFirst",
             (typename NCollection_Array1<TheItemType>::reference (NCollection_Array1<TheItemType>::*)() ) &NCollection_Array1<TheItemType>::ChangeFirst,
             R"#(Returns first element)#" )
        .def("Last",
             (typename NCollection_Array1<TheItemType>::const_reference (NCollection_Array1<TheItemType>::*)() const) &NCollection_Array1<TheItemType>::Last,
             R"#(Returns last element)#" )
        .def("ChangeLast",
             (typename NCollection_Array1<TheItemType>::reference (NCollection_Array1<TheItemType>::*)() ) &NCollection_Array1<TheItemType>::ChangeLast,
             R"#(Returns last element)#" )
        .def("Value",
             (typename NCollection_Array1<TheItemType>::const_reference (NCollection_Array1<TheItemType>::*)(  const int  ) const) &NCollection_Array1<TheItemType>::Value,
             R"#(Constant value access)#" ,py::arg("theIndex"))
        .def("ChangeValue",
             (typename NCollection_Array1<TheItemType>::reference (NCollection_Array1<TheItemType>::*)(  const int  ) ) &NCollection_Array1<TheItemType>::ChangeValue,
             R"#(Variable value access)#" ,py::arg("theIndex"))
        .def("At",
             (typename NCollection_Array1<TheItemType>::const_reference (NCollection_Array1<TheItemType>::*)(  const size_t  ) const) &NCollection_Array1<TheItemType>::At,
             R"#(0-based checked access independent of Lower()/Upper().)#" ,py::arg("theIndex"))
        .def("ChangeAt",
             (typename NCollection_Array1<TheItemType>::reference (NCollection_Array1<TheItemType>::*)(  const size_t  ) ) &NCollection_Array1<TheItemType>::ChangeAt,
             R"#(0-based checked mutable access independent of Lower()/Upper().)#" ,py::arg("theIndex"))
        .def("SetValue",
             (void (NCollection_Array1<TheItemType>::*)(  const int ,   const typename NCollection_Array1<TheItemType>::value_type &  ) ) &NCollection_Array1<TheItemType>::SetValue,
             R"#(Set value)#" ,py::arg("theIndex"), py::arg("theItem"))
        .def("UpdateLowerBound",
             (void (NCollection_Array1<TheItemType>::*)(  const int  ) ) &NCollection_Array1<TheItemType>::UpdateLowerBound,
             R"#(Changes the lowest bound. Do not move data)#" ,py::arg("theLower"))
        .def("UpdateUpperBound",
             (void (NCollection_Array1<TheItemType>::*)(  const int  ) ) &NCollection_Array1<TheItemType>::UpdateUpperBound,
             R"#(Changes the upper bound. Do not move data)#" ,py::arg("theUpper"))
        .def("Resize",
             (void (NCollection_Array1<TheItemType>::*)(  const int ,   const int ,   const bool  ) ) &NCollection_Array1<TheItemType>::Resize,
             R"#(Resizes the array to specified bounds. No re-allocation will be done if length of array does not change, but existing values will not be discarded if theToCopyData set to FALSE.)#" ,py::arg("theLower"), py::arg("theUpper"), py::arg("theToCopyData"))
        .def("Resize",
             (void (NCollection_Array1<TheItemType>::*)(  const size_t ,   const bool  ) ) &NCollection_Array1<TheItemType>::Resize,
             R"#(Resizes the array to theSize elements, keeping the lower bound unchanged.)#" ,py::arg("theSize"), py::arg("theToCopyData"))
        .def("IsDeletable",
             (bool (NCollection_Array1<TheItemType>::*)() const) &NCollection_Array1<TheItemType>::IsDeletable,
             R"#()#" )
        .def("__call__",
             (typename NCollection_Array1<TheItemType>::const_reference (NCollection_Array1<TheItemType>::*)(  const int  ) const) &NCollection_Array1<TheItemType>::operator(),
             py::is_operator(),
             R"#(operator() - alias to Value)#" ,py::arg("theIndex"))
        .def("__call__",
             (typename NCollection_Array1<TheItemType>::reference (NCollection_Array1<TheItemType>::*)(  const int  ) ) &NCollection_Array1<TheItemType>::operator(),
             py::is_operator(),
             R"#(operator() - alias to ChangeValue)#" ,py::arg("theIndex"))
        .def("__iter__",[](const NCollection_Array1<TheItemType> &self)
             { return py::make_iterator<py::return_value_policy::copy>(self.begin(), self.end()); },
             py::keep_alive<0, 1>())
        .def("__len__",[](const NCollection_Array1<TheItemType> &self)
             { return self.Size(); }
             )
        .def("__bool__",[](const NCollection_Array1<TheItemType> &self)
             { return self.IsEmpty(); }
             )
    ;
};

template <typename TheKeyType,typename TheItemType,typename Hasher=NCollection_DefaultHasher<TheKeyType>>
void preregister_template_NCollection_OrderedDataMap(py::object &m, const char *name){
    py::class_<NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher> , shared_ptr<NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>> , NCollection_BaseMap >(m,name,R"#(Hash map that preserves insertion order.)#");
}

template <typename TheKeyType,typename TheItemType,typename Hasher=NCollection_DefaultHasher<TheKeyType>>
void register_template_NCollection_OrderedDataMap(py::object &m, const char *name){
    static_cast<py::class_<NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher> , shared_ptr<NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>> , NCollection_BaseMap >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const size_t, const handle<NCollection_BaseAllocator> & >() ,py::arg("theNbBuckets"), py::arg("theAllocator")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr) )
        .def(py::init<  const int, const handle<NCollection_BaseAllocator> & >() ,py::arg("theNbBuckets"), py::arg("theAllocator")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr) )
        .def(py::init<  const Hasher &, const size_t, const handle<NCollection_BaseAllocator> & >() ,py::arg("theHasher"), py::arg("theNbBuckets")=static_cast< const size_t>(1), py::arg("theAllocator")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr) )
        .def(py::init<  const Hasher &, const int, const handle<NCollection_BaseAllocator> & >() ,py::arg("theHasher"), py::arg("theNbBuckets"), py::arg("theAllocator")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr) )
        .def(py::init<  const NCollection_OrderedDataMap<TheKeyType, TheItemType, Hasher> & >() ,py::arg("theOther") )
        .def("Items",
             (typename NCollection_OrderedDataMap<TheKeyType, TheItemType, Hasher>::ItemsView (NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::*)() ) &NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::Items,
             R"#(Returns a view for key-value pair iteration. Usage: for (auto [aKey, aValue] : aMap.Items()))#" )
        .def("Items",
             (typename NCollection_OrderedDataMap<TheKeyType, TheItemType, Hasher>::ConstItemsView (NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::*)() const) &NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::Items,
             R"#(Returns a const view for key-value pair iteration. Usage: for (const auto& [aKey, aValue] : aMap.Items()))#" )
        .def("Exchange",
             (void (NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::*)( NCollection_OrderedDataMap<TheKeyType, TheItemType, Hasher> &  ) ) &NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::Exchange,
             R"#(Exchange the content of two maps without re-allocations. Notice that allocators will be swapped as well!)#" ,py::arg("theOther"))
        .def("GetHasher",
             ( const Hasher & (NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::*)() const) &NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::GetHasher,
             R"#(Returns const reference to the hasher.)#" )
        .def("Assign",
             (NCollection_OrderedDataMap<TheKeyType, TheItemType, Hasher> & (NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const NCollection_OrderedDataMap<TheKeyType, TheItemType, Hasher> &  ) ) &NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::Assign,
             R"#(Assignment. This method does not change the internal allocator.)#" ,py::arg("theOther"))
        .def("ReSize",
             (void (NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const size_t  ) ) &NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::ReSize,
             R"#(ReSize)#" ,py::arg("N"))
        .def("ReSize",
             (void (NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const int  ) ) &NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::ReSize,
             R"#()#" ,py::arg("N"))
        .def("Bind",
             (bool (NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType & ,   const TheItemType &  ) ) &NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::Bind,
             R"#(Bind binds Item to Key in map.)#" ,py::arg("theKey"), py::arg("theItem"))
        .def("Bound",
             (TheItemType * (NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType & ,   const TheItemType &  ) ) &NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::Bound,
             R"#(Bound binds Item to Key in map.)#" ,py::arg("theKey"), py::arg("theItem"))
        .def("TryBind",
             (bool (NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType & ,   const TheItemType &  ) ) &NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::TryBind,
             R"#(TryBind binds Item to Key in map only if Key is not yet bound.)#" ,py::arg("theKey"), py::arg("theItem"))
        .def("TryBound",
             (TheItemType & (NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType & ,   const TheItemType &  ) ) &NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::TryBound,
             R"#(TryBound binds Item to Key in map only if Key is not yet bound.)#" ,py::arg("theKey"), py::arg("theItem"))
        .def("IsBound",
             (bool (NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType &  ) const) &NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::IsBound,
             R"#(IsBound)#" ,py::arg("theKey"))
        .def("UnBind",
             (bool (NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType &  ) ) &NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::UnBind,
             R"#(UnBind removes Item Key pair from map)#" ,py::arg("theKey"))
        .def("Seek",
             ( const TheItemType * (NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType &  ) const) &NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::Seek,
             R"#(Seek returns pointer to Item by Key. Returns NULL if Key was not bound.)#" ,py::arg("theKey"))
        .def("Find",
             ( const TheItemType & (NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType &  ) const) &NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::Find,
             R"#(Find returns the Item for Key. Raises if Key was not bound)#" ,py::arg("theKey"))
        .def("Find",
             (bool (NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType & ,  TheItemType &  ) const) &NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::Find,
             R"#(Find Item for key with copying.)#" ,py::arg("theKey"), py::arg("theValue"))
        .def("ChangeSeek",
             (TheItemType * (NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType &  ) ) &NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::ChangeSeek,
             R"#(ChangeSeek returns modifiable pointer to Item by Key. Returns NULL if Key was not bound.)#" ,py::arg("theKey"))
        .def("ChangeFind",
             (TheItemType & (NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType &  ) ) &NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::ChangeFind,
             R"#(ChangeFind returns modifiable Item by Key. Raises if Key was not bound)#" ,py::arg("theKey"))
        .def("Clear",
             (void (NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const bool  ) ) &NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::Clear,
             R"#(Clear data. If doReleaseMemory is false then the table of buckets is not released and will be reused.)#" ,py::arg("doReleaseMemory")=static_cast< const bool>(false))
        .def("Clear",
             (void (NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const handle<NCollection_BaseAllocator> &  ) ) &NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::Clear,
             R"#(Clear data and reset allocator)#" ,py::arg("theAllocator"))
        .def("First",
             ( const TheKeyType & (NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::*)() const) &NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::First,
             R"#(Returns the first key in insertion order.)#" )
        .def("Last",
             ( const TheKeyType & (NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::*)() const) &NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::Last,
             R"#(Returns the last key in insertion order.)#" )
        .def("FirstValue",
             ( const TheItemType & (NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::*)() const) &NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::FirstValue,
             R"#(Returns the first value in insertion order.)#" )
        .def("LastValue",
             ( const TheItemType & (NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::*)() const) &NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::LastValue,
             R"#(Returns the last value in insertion order.)#" )
        .def("ChangeFirstValue",
             (TheItemType & (NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::*)() ) &NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::ChangeFirstValue,
             R"#(Returns modifiable first value in insertion order.)#" )
        .def("ChangeLastValue",
             (TheItemType & (NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::*)() ) &NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::ChangeLastValue,
             R"#(Returns modifiable last value in insertion order.)#" )
        .def("__call__",
             ( const TheItemType & (NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType &  ) const) &NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::operator(),
             py::is_operator(),
             R"#(operator ())#" ,py::arg("theKey"))
        .def("__call__",
             (TheItemType & (NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType &  ) ) &NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher>::operator(),
             py::is_operator(),
             R"#(operator ())#" ,py::arg("theKey"))
        .def("__iter__",[](const NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher> &self)
             { return py::make_iterator<py::return_value_policy::copy>(self.begin(), self.end()); },
             py::keep_alive<0, 1>())
        .def("__len__",[](const NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher> &self)
             { return self.Extent(); }
             )
        .def("__len__",[](const NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher> &self)
             { return self.Size(); }
             )
        .def("__bool__",[](const NCollection_OrderedDataMap<TheKeyType,TheItemType,Hasher> &self)
             { return self.IsEmpty(); }
             )
    ;
};

template <typename TheItemType>
void preregister_template_NCollection_Sequence(py::object &m, const char *name){
    py::class_<NCollection_Sequence<TheItemType> , shared_ptr<NCollection_Sequence<TheItemType>> , NCollection_BaseSequence >(m,name,R"#(Purpose: Definition of a sequence of elements indexed by an Integer in range of 1..n)#");
}

template <typename TheItemType>
void register_template_NCollection_Sequence(py::object &m, const char *name){
    static_cast<py::class_<NCollection_Sequence<TheItemType> , shared_ptr<NCollection_Sequence<TheItemType>> , NCollection_BaseSequence >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >() ,py::arg("theAllocator") )
        .def(py::init<  const NCollection_Sequence<TheItemType> & >() ,py::arg("theOther") )
        .def("Upper",
             (int (NCollection_Sequence<TheItemType>::*)() const) &NCollection_Sequence<TheItemType>::Upper,
             R"#(Method for consistency with other collections.)#" )
        .def("IsEmpty",
             (bool (NCollection_Sequence<TheItemType>::*)() const) &NCollection_Sequence<TheItemType>::IsEmpty,
             R"#(Empty query)#" )
        .def("Reverse",
             (void (NCollection_Sequence<TheItemType>::*)() ) &NCollection_Sequence<TheItemType>::Reverse,
             R"#(Reverse sequence)#" )
        .def("Exchange",
             (void (NCollection_Sequence<TheItemType>::*)(  const size_t ,   const size_t  ) ) &NCollection_Sequence<TheItemType>::Exchange,
             R"#(Exchange two members)#" ,py::arg("I"), py::arg("J"))
        .def("Exchange",
             (void (NCollection_Sequence<TheItemType>::*)(  const int ,   const int  ) ) &NCollection_Sequence<TheItemType>::Exchange,
             R"#()#" ,py::arg("I"), py::arg("J"))
        .def("Clear",
             (void (NCollection_Sequence<TheItemType>::*)(  const handle<NCollection_BaseAllocator> &  ) ) &NCollection_Sequence<TheItemType>::Clear,
             R"#(Clear the items out, take a new allocator if non null)#" ,py::arg("theAllocator")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr))
        .def("Assign",
             (NCollection_Sequence<TheItemType> & (NCollection_Sequence<TheItemType>::*)(  const NCollection_Sequence<TheItemType> &  ) ) &NCollection_Sequence<TheItemType>::Assign,
             R"#(Replace this sequence by the items of theOther. This method does not change the internal allocator.)#" ,py::arg("theOther"))
        .def("Remove",
             (void (NCollection_Sequence<TheItemType>::*)(  const size_t  ) ) &NCollection_Sequence<TheItemType>::Remove,
             R"#(Remove one item)#" ,py::arg("theIndex"))
        .def("Remove",
             (void (NCollection_Sequence<TheItemType>::*)(  const int  ) ) &NCollection_Sequence<TheItemType>::Remove,
             R"#()#" ,py::arg("theIndex"))
        .def("Remove",
             (void (NCollection_Sequence<TheItemType>::*)(  const size_t ,   const size_t  ) ) &NCollection_Sequence<TheItemType>::Remove,
             R"#(Remove range of items)#" ,py::arg("theFromIndex"), py::arg("theToIndex"))
        .def("Remove",
             (void (NCollection_Sequence<TheItemType>::*)(  const int ,   const int  ) ) &NCollection_Sequence<TheItemType>::Remove,
             R"#()#" ,py::arg("theFromIndex"), py::arg("theToIndex"))
        .def("Append",
             (void (NCollection_Sequence<TheItemType>::*)(  const TheItemType &  ) ) &NCollection_Sequence<TheItemType>::Append,
             R"#(Append one item)#" ,py::arg("theItem"))
        .def("Append",
             (void (NCollection_Sequence<TheItemType>::*)( NCollection_Sequence<TheItemType> &  ) ) &NCollection_Sequence<TheItemType>::Append,
             R"#(Append another sequence (making it empty))#" ,py::arg("theSeq"))
        .def("Prepend",
             (void (NCollection_Sequence<TheItemType>::*)(  const TheItemType &  ) ) &NCollection_Sequence<TheItemType>::Prepend,
             R"#(Prepend one item)#" ,py::arg("theItem"))
        .def("Prepend",
             (void (NCollection_Sequence<TheItemType>::*)( NCollection_Sequence<TheItemType> &  ) ) &NCollection_Sequence<TheItemType>::Prepend,
             R"#(Prepend another sequence (making it empty))#" ,py::arg("theSeq"))
        .def("InsertBefore",
             (void (NCollection_Sequence<TheItemType>::*)(  const size_t ,   const TheItemType &  ) ) &NCollection_Sequence<TheItemType>::InsertBefore,
             R"#(InsertBefore theIndex theItem)#" ,py::arg("theIndex"), py::arg("theItem"))
        .def("InsertBefore",
             (void (NCollection_Sequence<TheItemType>::*)(  const int ,   const TheItemType &  ) ) &NCollection_Sequence<TheItemType>::InsertBefore,
             R"#()#" ,py::arg("theIndex"), py::arg("theItem"))
        .def("InsertBefore",
             (void (NCollection_Sequence<TheItemType>::*)(  const size_t ,  NCollection_Sequence<TheItemType> &  ) ) &NCollection_Sequence<TheItemType>::InsertBefore,
             R"#(InsertBefore theIndex another sequence (making it empty))#" ,py::arg("theIndex"), py::arg("theSeq"))
        .def("InsertBefore",
             (void (NCollection_Sequence<TheItemType>::*)(  const int ,  NCollection_Sequence<TheItemType> &  ) ) &NCollection_Sequence<TheItemType>::InsertBefore,
             R"#()#" ,py::arg("theIndex"), py::arg("theSeq"))
        .def("InsertAfter",
             (void (NCollection_Sequence<TheItemType>::*)(  const size_t ,  NCollection_Sequence<TheItemType> &  ) ) &NCollection_Sequence<TheItemType>::InsertAfter,
             R"#(InsertAfter theIndex another sequence (making it empty))#" ,py::arg("theIndex"), py::arg("theSeq"))
        .def("InsertAfter",
             (void (NCollection_Sequence<TheItemType>::*)(  const int ,  NCollection_Sequence<TheItemType> &  ) ) &NCollection_Sequence<TheItemType>::InsertAfter,
             R"#()#" ,py::arg("theIndex"), py::arg("theSeq"))
        .def("InsertAfter",
             (void (NCollection_Sequence<TheItemType>::*)(  const size_t ,   const TheItemType &  ) ) &NCollection_Sequence<TheItemType>::InsertAfter,
             R"#(InsertAfter theIndex theItem)#" ,py::arg("theIndex"), py::arg("theItem"))
        .def("InsertAfter",
             (void (NCollection_Sequence<TheItemType>::*)(  const int ,   const TheItemType &  ) ) &NCollection_Sequence<TheItemType>::InsertAfter,
             R"#()#" ,py::arg("theIndex"), py::arg("theItem"))
        .def("Split",
             (void (NCollection_Sequence<TheItemType>::*)(  const size_t ,  NCollection_Sequence<TheItemType> &  ) ) &NCollection_Sequence<TheItemType>::Split,
             R"#(Split in two sequences)#" ,py::arg("theIndex"), py::arg("theSeq"))
        .def("Split",
             (void (NCollection_Sequence<TheItemType>::*)(  const int ,  NCollection_Sequence<TheItemType> &  ) ) &NCollection_Sequence<TheItemType>::Split,
             R"#()#" ,py::arg("theIndex"), py::arg("theSeq"))
        .def("First",
             ( const TheItemType & (NCollection_Sequence<TheItemType>::*)() const) &NCollection_Sequence<TheItemType>::First,
             R"#(First item access)#" )
        .def("ChangeFirst",
             (TheItemType & (NCollection_Sequence<TheItemType>::*)() ) &NCollection_Sequence<TheItemType>::ChangeFirst,
             R"#(First item access)#" )
        .def("Last",
             ( const TheItemType & (NCollection_Sequence<TheItemType>::*)() const) &NCollection_Sequence<TheItemType>::Last,
             R"#(Last item access)#" )
        .def("ChangeLast",
             (TheItemType & (NCollection_Sequence<TheItemType>::*)() ) &NCollection_Sequence<TheItemType>::ChangeLast,
             R"#(Last item access)#" )
        .def("Value",
             ( const TheItemType & (NCollection_Sequence<TheItemType>::*)(  const size_t  ) const) &NCollection_Sequence<TheItemType>::Value,
             R"#(Constant item access by theIndex)#" ,py::arg("theIndex"))
        .def("Value",
             ( const TheItemType & (NCollection_Sequence<TheItemType>::*)(  const int  ) const) &NCollection_Sequence<TheItemType>::Value,
             R"#()#" ,py::arg("theIndex"))
        .def("ChangeValue",
             (TheItemType & (NCollection_Sequence<TheItemType>::*)(  const size_t  ) ) &NCollection_Sequence<TheItemType>::ChangeValue,
             R"#(Variable item access by theIndex)#" ,py::arg("theIndex"))
        .def("ChangeValue",
             (TheItemType & (NCollection_Sequence<TheItemType>::*)(  const int  ) ) &NCollection_Sequence<TheItemType>::ChangeValue,
             R"#()#" ,py::arg("theIndex"))
        .def("SetValue",
             (void (NCollection_Sequence<TheItemType>::*)(  const size_t ,   const TheItemType &  ) ) &NCollection_Sequence<TheItemType>::SetValue,
             R"#(Set item value by theIndex)#" ,py::arg("theIndex"), py::arg("theItem"))
        .def("SetValue",
             (void (NCollection_Sequence<TheItemType>::*)(  const int ,   const TheItemType &  ) ) &NCollection_Sequence<TheItemType>::SetValue,
             R"#()#" ,py::arg("theIndex"), py::arg("theItem"))
        .def("At",
             ( const TheItemType & (NCollection_Sequence<TheItemType>::*)(  const size_t  ) const) &NCollection_Sequence<TheItemType>::At,
             R"#(0-based checked access independent of Lower()/Upper().)#" ,py::arg("theIndex"))
        .def("ChangeAt",
             (TheItemType & (NCollection_Sequence<TheItemType>::*)(  const size_t  ) ) &NCollection_Sequence<TheItemType>::ChangeAt,
             R"#(0-based checked mutable access independent of Lower()/Upper().)#" ,py::arg("theIndex"))
        .def_static("Lower_s",
                    (int (*)() ) &NCollection_Sequence<TheItemType>::Lower,
                    R"#(Method for consistency with other collections.)#" )
        .def_static("delNode_s",
                    (void (*)( NCollection_SeqNode * ,  handle<NCollection_BaseAllocator> &  ) ) &NCollection_Sequence<TheItemType>::delNode,
                    R"#(Static deleter to be passed to BaseSequence)#" ,py::arg("theNode"), py::arg("theAl"))
        .def("__call__",
             ( const TheItemType & (NCollection_Sequence<TheItemType>::*)(  const size_t  ) const) &NCollection_Sequence<TheItemType>::operator(),
             py::is_operator(),
             R"#(Constant operator())#" ,py::arg("theIndex"))
        .def("__call__",
             ( const TheItemType & (NCollection_Sequence<TheItemType>::*)(  const int  ) const) &NCollection_Sequence<TheItemType>::operator(),
             py::is_operator(),
             R"#()#" ,py::arg("theIndex"))
        .def("__call__",
             (TheItemType & (NCollection_Sequence<TheItemType>::*)(  const size_t  ) ) &NCollection_Sequence<TheItemType>::operator(),
             py::is_operator(),
             R"#(Variable operator())#" ,py::arg("theIndex"))
        .def("__call__",
             (TheItemType & (NCollection_Sequence<TheItemType>::*)(  const int  ) ) &NCollection_Sequence<TheItemType>::operator(),
             py::is_operator(),
             R"#()#" ,py::arg("theIndex"))
        .def("__iter__",[](const NCollection_Sequence<TheItemType> &self)
             { return py::make_iterator<py::return_value_policy::copy>(self.begin(), self.end()); },
             py::keep_alive<0, 1>())
        .def("__len__",[](const NCollection_Sequence<TheItemType> &self)
             { return self.Size(); }
             )
        .def("__bool__",[](const NCollection_Sequence<TheItemType> &self)
             { return self.IsEmpty(); }
             )
    ;
};

template <typename theItem,int MAX_ARRAY_SIZE=1024>
void preregister_template_NCollection_LocalArray(py::object &m, const char *name){
    py::class_<NCollection_LocalArray<theItem,MAX_ARRAY_SIZE> , shared_ptr<NCollection_LocalArray<theItem,MAX_ARRAY_SIZE>> >(m,name,R"#(Auxiliary class optimizing creation of array buffer (using stack allocation for small arrays).)#");
}

template <typename theItem,int MAX_ARRAY_SIZE=1024>
void register_template_NCollection_LocalArray(py::object &m, const char *name){
    static_cast<py::class_<NCollection_LocalArray<theItem,MAX_ARRAY_SIZE> , shared_ptr<NCollection_LocalArray<theItem,MAX_ARRAY_SIZE>> >>(m.attr(name))
        .def(py::init<  const size_t >() ,py::arg("theSize") )
        .def(py::init<  >()  )
        .def(py::init<  const NCollection_LocalArray<theItem, MAX_ARRAY_SIZE> & >() ,py::arg("arg0") )
        .def("Allocate",
             (void (NCollection_LocalArray<theItem,MAX_ARRAY_SIZE>::*)(  const size_t  ) ) &NCollection_LocalArray<theItem,MAX_ARRAY_SIZE>::Allocate,
             R"#()#" ,py::arg("theSize"))
        .def("Reallocate",
             (void (NCollection_LocalArray<theItem,MAX_ARRAY_SIZE>::*)(  const size_t ,  bool  ) ) &NCollection_LocalArray<theItem,MAX_ARRAY_SIZE>::Reallocate,
             R"#(Reallocate the array to a new size.)#" ,py::arg("theNewSize"), py::arg("theToCopy")=static_cast<bool>(true))
        .def("Size",
             (size_t (NCollection_LocalArray<theItem,MAX_ARRAY_SIZE>::*)() const) &NCollection_LocalArray<theItem,MAX_ARRAY_SIZE>::Size,
             R"#()#" )
        .def("ToArray1",
             (NCollection_Array1<theItem> (NCollection_LocalArray<theItem,MAX_ARRAY_SIZE>::*)() const) &NCollection_LocalArray<theItem,MAX_ARRAY_SIZE>::ToArray1,
             R"#(Returns a span as Array1 with shared memory. Modifying the local array or the array view may invalidate the shared buffer.)#" )
        .def("__len__",[](const NCollection_LocalArray<theItem,MAX_ARRAY_SIZE> &self)
             { return self.Size(); }
             )
    ;
};

template <typename TheObjType,typename TheBndType>
void preregister_template_NCollection_UBTree(py::object &m, const char *name){
    py::class_<NCollection_UBTree<TheObjType,TheBndType> , shared_ptr<NCollection_UBTree<TheObjType,TheBndType>> >(m,name,R"#(The algorithm of unbalanced binary tree of overlapped bounding boxes.)#");
}

template <typename TheObjType,typename TheBndType>
void register_template_NCollection_UBTree(py::object &m, const char *name){
    static_cast<py::class_<NCollection_UBTree<TheObjType,TheBndType> , shared_ptr<NCollection_UBTree<TheObjType,TheBndType>> >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >() ,py::arg("theAllocator") )
        .def("Add",
             (bool (NCollection_UBTree<TheObjType,TheBndType>::*)(  const TheObjType & ,   const TheBndType &  ) ) &NCollection_UBTree<TheObjType,TheBndType>::Add,
             R"#(Update the tree with a new object and its bounding box.)#" ,py::arg("theObj"), py::arg("theBnd"))
        .def("Clear",
             (void (NCollection_UBTree<TheObjType,TheBndType>::*)(  const handle<NCollection_BaseAllocator> &  ) ) &NCollection_UBTree<TheObjType,TheBndType>::Clear,
             R"#(Clears the contents of the tree.)#" ,py::arg("aNewAlloc")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr))
        .def("IsEmpty",
             (bool (NCollection_UBTree<TheObjType,TheBndType>::*)() const) &NCollection_UBTree<TheObjType,TheBndType>::IsEmpty,
             R"#()#" )
        .def("Allocator",
             ( const handle<NCollection_BaseAllocator> & (NCollection_UBTree<TheObjType,TheBndType>::*)() const) &NCollection_UBTree<TheObjType,TheBndType>::Allocator,
             R"#(Recommended to be used only in sub-classes.)#" )
        .def("__bool__",[](const NCollection_UBTree<TheObjType,TheBndType> &self)
             { return self.IsEmpty(); }
             )
    ;
};

template <typename Inspector>
void preregister_template_NCollection_CellFilter(py::object &m, const char *name){
    py::class_<NCollection_CellFilter<Inspector> , shared_ptr<NCollection_CellFilter<Inspector>> >(m,name,R"#(A data structure for sorting geometric objects (called targets) in n-dimensional space into cells, with associated algorithm for fast checking of coincidence (overlapping, intersection, etc.) with other objects (called here bullets).)#");
}

template <typename Inspector>
void register_template_NCollection_CellFilter(py::object &m, const char *name){
    static_cast<py::class_<NCollection_CellFilter<Inspector> , shared_ptr<NCollection_CellFilter<Inspector>> >>(m.attr(name))
        .def(py::init<  const int, const double, const handle<NCollection_IncAllocator> & >() ,py::arg("theDim"), py::arg("theCellSize")=static_cast< const double>(0), py::arg("theAlloc")=static_cast< const handle<NCollection_IncAllocator> &>(nullptr) )
        .def(py::init<  const double, const handle<NCollection_IncAllocator> & >() ,py::arg("theCellSize")=static_cast< const double>(0), py::arg("theAlloc")=static_cast< const handle<NCollection_IncAllocator> &>(nullptr) )
        .def("Reset",
             (void (NCollection_CellFilter<Inspector>::*)( double ,   const handle<NCollection_IncAllocator> &  ) ) &NCollection_CellFilter<Inspector>::Reset,
             R"#(Clear the data structures, set new cell size and allocator)#" ,py::arg("theCellSize"), py::arg("theAlloc")=static_cast< const handle<NCollection_IncAllocator> &>(nullptr))
        .def("Reset",
             (void (NCollection_CellFilter<Inspector>::*)( NCollection_Array1<double> & ,   const handle<NCollection_IncAllocator> &  ) ) &NCollection_CellFilter<Inspector>::Reset,
             R"#(Clear the data structures and set new cell sizes and allocator)#" ,py::arg("theCellSize"), py::arg("theAlloc")=static_cast< const handle<NCollection_IncAllocator> &>(nullptr))
        .def("Add",
             (void (NCollection_CellFilter<Inspector>::*)(  const typename NCollection_CellFilter<Inspector>::Target & ,   const typename NCollection_CellFilter<Inspector>::Point &  ) ) &NCollection_CellFilter<Inspector>::Add,
             R"#(Adds a target object for further search at a point (into only one cell))#" ,py::arg("theTarget"), py::arg("thePnt"))
        .def("Add",
             (void (NCollection_CellFilter<Inspector>::*)(  const typename NCollection_CellFilter<Inspector>::Target & ,   const typename NCollection_CellFilter<Inspector>::Point & ,   const typename NCollection_CellFilter<Inspector>::Point &  ) ) &NCollection_CellFilter<Inspector>::Add,
             R"#(Adds a target object for further search in the range of cells defined by two points (the first point must have all coordinates equal or less than the same coordinate of the second point))#" ,py::arg("theTarget"), py::arg("thePntMin"), py::arg("thePntMax"))
        .def("Remove",
             (void (NCollection_CellFilter<Inspector>::*)(  const typename NCollection_CellFilter<Inspector>::Target & ,   const typename NCollection_CellFilter<Inspector>::Point &  ) ) &NCollection_CellFilter<Inspector>::Remove,
             R"#(Find a target object at a point and remove it from the structures. For usage of this method "operator ==" should be defined for Target.)#" ,py::arg("theTarget"), py::arg("thePnt"))
        .def("Remove",
             (void (NCollection_CellFilter<Inspector>::*)(  const typename NCollection_CellFilter<Inspector>::Target & ,   const typename NCollection_CellFilter<Inspector>::Point & ,   const typename NCollection_CellFilter<Inspector>::Point &  ) ) &NCollection_CellFilter<Inspector>::Remove,
             R"#(Find a target object in the range of cells defined by two points and remove it from the structures (the first point must have all coordinates equal or less than the same coordinate of the second point). For usage of this method "operator ==" should be defined for Target.)#" ,py::arg("theTarget"), py::arg("thePntMin"), py::arg("thePntMax"))
        .def("Inspect",
             (void (NCollection_CellFilter<Inspector>::*)(  const typename NCollection_CellFilter<Inspector>::Point & ,  Inspector &  ) ) &NCollection_CellFilter<Inspector>::Inspect,
             R"#(Inspect all targets in the cell corresponding to the given point)#" ,py::arg("thePnt"), py::arg("theInspector"))
        .def("Inspect",
             (void (NCollection_CellFilter<Inspector>::*)(  const typename NCollection_CellFilter<Inspector>::Point & ,   const typename NCollection_CellFilter<Inspector>::Point & ,  Inspector &  ) ) &NCollection_CellFilter<Inspector>::Inspect,
             R"#(Inspect all targets in the cells range limited by two given points (the first point must have all coordinates equal or less than the same coordinate of the second point))#" ,py::arg("thePntMin"), py::arg("thePntMax"), py::arg("theInspector"))
    ;
};

template <typename TheItemType>
void preregister_template_NCollection_TListNode(py::object &m, const char *name){
    py::class_<NCollection_TListNode<TheItemType> , shared_ptr<NCollection_TListNode<TheItemType>> , NCollection_ListNode >(m,name,R"#(Purpose: Abstract list node class. Used by BaseList Remark: Internal class)#");
}

template <typename TheItemType>
void register_template_NCollection_TListNode(py::object &m, const char *name){
    static_cast<py::class_<NCollection_TListNode<TheItemType> , shared_ptr<NCollection_TListNode<TheItemType>> , NCollection_ListNode >>(m.attr(name))
        .def(py::init<  const TheItemType &,NCollection_ListNode * >() ,py::arg("theItem"), py::arg("theNext")=static_cast<NCollection_ListNode *>(nullptr) )
        .def("Value",
             ( const TheItemType & (NCollection_TListNode<TheItemType>::*)() const) &NCollection_TListNode<TheItemType>::Value,
             R"#(Constant value access)#" )
        .def("ChangeValue",
             (TheItemType & (NCollection_TListNode<TheItemType>::*)() ) &NCollection_TListNode<TheItemType>::ChangeValue,
             R"#(Variable value access)#" )
        .def_static("delNode_s",
                    (void (*)( NCollection_ListNode * ,  handle<NCollection_BaseAllocator> &  ) ) &NCollection_TListNode<TheItemType>::delNode,
                    R"#(Static deleter to be passed to BaseList)#" ,py::arg("theNode"), py::arg("theAl"))
    ;
};

template <typename ItemType>
void preregister_template_NCollection_Allocator(py::object &m, const char *name){
    py::class_<NCollection_Allocator<ItemType> , shared_ptr<NCollection_Allocator<ItemType>> >(m,name,R"#(Implements allocator requirements as defined in ISO C++ Standard 2003, section 20.1.5. The allocator uses a standard OCCT mechanism for memory allocation and deallocation. It can be used with standard containers (std::vector, std::map, etc.) to take advantage of OCCT memory optimizations.)#");
}

template <typename ItemType>
void register_template_NCollection_Allocator(py::object &m, const char *name){
    static_cast<py::class_<NCollection_Allocator<ItemType> , shared_ptr<NCollection_Allocator<ItemType>> >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >() ,py::arg("arg0") )
        .def("address",
             (typename NCollection_Allocator<ItemType>::const_pointer (NCollection_Allocator<ItemType>::*)( typename NCollection_Allocator<ItemType>::const_reference  ) const) &NCollection_Allocator<ItemType>::address,
             R"#(Returns an object address.)#" ,py::arg("theItem"))
        .def("destroy",
             (void (NCollection_Allocator<ItemType>::*)( typename NCollection_Allocator<ItemType>::pointer  ) ) &NCollection_Allocator<ItemType>::destroy,
             R"#(Destroys the object. Uses the object destructor.)#" ,py::arg("thePnt"))
    ;
};

template <typename T>
void preregister_template_NCollection_Lerp(py::object &m, const char *name){
    py::class_<NCollection_Lerp<T> , shared_ptr<NCollection_Lerp<T>> >(m,name,R"#(Simple linear interpolation tool (also known as mix() in GLSL). The main purpose of this template class is making interpolation routines more readable.)#");
}

template <typename T>
void register_template_NCollection_Lerp(py::object &m, const char *name){
    static_cast<py::class_<NCollection_Lerp<T> , shared_ptr<NCollection_Lerp<T>> >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const T &, const T & >() ,py::arg("theStart"), py::arg("theEnd") )
        .def("Init",
             (void (NCollection_Lerp<T>::*)(  const T & ,   const T &  ) ) &NCollection_Lerp<T>::Init,
             R"#(Initialize values.)#" ,py::arg("theStart"), py::arg("theEnd"))
        .def("Interpolate",
             (void (NCollection_Lerp<T>::*)( double ,  T &  ) const) &NCollection_Lerp<T>::Interpolate,
             R"#(Compute interpolated value between two values.)#" ,py::arg("theT"), py::arg("theResult"))
        .def_static("Interpolate_s",
                    (T (*)(  const T & ,   const T & ,  double  ) ) &NCollection_Lerp<T>::Interpolate,
                    R"#(Compute interpolated value between two values.)#" ,py::arg("theStart"), py::arg("theEnd"), py::arg("theT"))
    ;
};

template <typename TheKeyType,typename Hasher=NCollection_DefaultHasher<TheKeyType>>
void preregister_template_NCollection_OrderedMap(py::object &m, const char *name){
    py::class_<NCollection_OrderedMap<TheKeyType,Hasher> , shared_ptr<NCollection_OrderedMap<TheKeyType,Hasher>> , NCollection_BaseMap >(m,name,R"#(Hash set that preserves insertion order.)#");
}

template <typename TheKeyType,typename Hasher=NCollection_DefaultHasher<TheKeyType>>
void register_template_NCollection_OrderedMap(py::object &m, const char *name){
    static_cast<py::class_<NCollection_OrderedMap<TheKeyType,Hasher> , shared_ptr<NCollection_OrderedMap<TheKeyType,Hasher>> , NCollection_BaseMap >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const size_t, const handle<NCollection_BaseAllocator> & >() ,py::arg("theNbBuckets"), py::arg("theAllocator")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr) )
        .def(py::init<  const int, const handle<NCollection_BaseAllocator> & >() ,py::arg("theNbBuckets"), py::arg("theAllocator")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr) )
        .def(py::init<  const Hasher &, const size_t, const handle<NCollection_BaseAllocator> & >() ,py::arg("theHasher"), py::arg("theNbBuckets")=static_cast< const size_t>(1), py::arg("theAllocator")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr) )
        .def(py::init<  const Hasher &, const int, const handle<NCollection_BaseAllocator> & >() ,py::arg("theHasher"), py::arg("theNbBuckets"), py::arg("theAllocator")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr) )
        .def(py::init<  const NCollection_OrderedMap<TheKeyType, Hasher> & >() ,py::arg("theOther") )
        .def("Exchange",
             (void (NCollection_OrderedMap<TheKeyType,Hasher>::*)( NCollection_OrderedMap<TheKeyType, Hasher> &  ) ) &NCollection_OrderedMap<TheKeyType,Hasher>::Exchange,
             R"#(Exchange the content of two maps without re-allocations. Notice that allocators will be swapped as well!)#" ,py::arg("theOther"))
        .def("GetHasher",
             ( const Hasher & (NCollection_OrderedMap<TheKeyType,Hasher>::*)() const) &NCollection_OrderedMap<TheKeyType,Hasher>::GetHasher,
             R"#(Returns const reference to the hasher.)#" )
        .def("Assign",
             (NCollection_OrderedMap<TheKeyType, Hasher> & (NCollection_OrderedMap<TheKeyType,Hasher>::*)(  const NCollection_OrderedMap<TheKeyType, Hasher> &  ) ) &NCollection_OrderedMap<TheKeyType,Hasher>::Assign,
             R"#(Assign. This method does not change the internal allocator.)#" ,py::arg("theOther"))
        .def("ReSize",
             (void (NCollection_OrderedMap<TheKeyType,Hasher>::*)(  const size_t  ) ) &NCollection_OrderedMap<TheKeyType,Hasher>::ReSize,
             R"#(ReSize)#" ,py::arg("N"))
        .def("ReSize",
             (void (NCollection_OrderedMap<TheKeyType,Hasher>::*)(  const int  ) ) &NCollection_OrderedMap<TheKeyType,Hasher>::ReSize,
             R"#()#" ,py::arg("N"))
        .def("Add",
             (bool (NCollection_OrderedMap<TheKeyType,Hasher>::*)(  const TheKeyType &  ) ) &NCollection_OrderedMap<TheKeyType,Hasher>::Add,
             R"#(Add)#" ,py::arg("theKey"))
        .def("Added",
             ( const TheKeyType & (NCollection_OrderedMap<TheKeyType,Hasher>::*)(  const TheKeyType &  ) ) &NCollection_OrderedMap<TheKeyType,Hasher>::Added,
             R"#(Added: add a new key if not yet in the map, and return reference to either newly added or previously existing object)#" ,py::arg("theKey"))
        .def("Contains",
             (bool (NCollection_OrderedMap<TheKeyType,Hasher>::*)(  const TheKeyType &  ) const) &NCollection_OrderedMap<TheKeyType,Hasher>::Contains,
             R"#(Contains)#" ,py::arg("theKey"))
        .def("Remove",
             (bool (NCollection_OrderedMap<TheKeyType,Hasher>::*)(  const TheKeyType &  ) ) &NCollection_OrderedMap<TheKeyType,Hasher>::Remove,
             R"#(Remove)#" ,py::arg("K"))
        .def("Clear",
             (void (NCollection_OrderedMap<TheKeyType,Hasher>::*)(  const bool  ) ) &NCollection_OrderedMap<TheKeyType,Hasher>::Clear,
             R"#(Clear data. If doReleaseMemory is false then the table of buckets is not released and will be reused.)#" ,py::arg("doReleaseMemory")=static_cast< const bool>(false))
        .def("Clear",
             (void (NCollection_OrderedMap<TheKeyType,Hasher>::*)(  const handle<NCollection_BaseAllocator> &  ) ) &NCollection_OrderedMap<TheKeyType,Hasher>::Clear,
             R"#(Clear data and reset allocator)#" ,py::arg("theAllocator"))
        .def("First",
             ( const TheKeyType & (NCollection_OrderedMap<TheKeyType,Hasher>::*)() const) &NCollection_OrderedMap<TheKeyType,Hasher>::First,
             R"#(Returns the first key in insertion order.)#" )
        .def("Last",
             ( const TheKeyType & (NCollection_OrderedMap<TheKeyType,Hasher>::*)() const) &NCollection_OrderedMap<TheKeyType,Hasher>::Last,
             R"#(Returns the last key in insertion order.)#" )
        .def("__iter__",[](const NCollection_OrderedMap<TheKeyType,Hasher> &self)
             { return py::make_iterator<py::return_value_policy::copy>(self.begin(), self.end()); },
             py::keep_alive<0, 1>())
        .def("__len__",[](const NCollection_OrderedMap<TheKeyType,Hasher> &self)
             { return self.Extent(); }
             )
        .def("__len__",[](const NCollection_OrderedMap<TheKeyType,Hasher> &self)
             { return self.Size(); }
             )
        .def("__bool__",[](const NCollection_OrderedMap<TheKeyType,Hasher> &self)
             { return self.IsEmpty(); }
             )
    ;
};

template <typename TheKeyType>
void preregister_template_NCollection_DefaultHasher(py::object &m, const char *name){
    py::class_<NCollection_DefaultHasher<TheKeyType> , shared_ptr<NCollection_DefaultHasher<TheKeyType>> >(m,name,R"#(Purpose: The DefaultHasher is a Hasher that is used by default in NCollection maps. To compute the hash code of the key is used the global function HashCode. To compare two keys is used the global function IsEqual.)#");
}

template <typename TheKeyType>
void register_template_NCollection_DefaultHasher(py::object &m, const char *name){
    static_cast<py::class_<NCollection_DefaultHasher<TheKeyType> , shared_ptr<NCollection_DefaultHasher<TheKeyType>> >>(m.attr(name))
        .def("__call__",
             (size_t (NCollection_DefaultHasher<TheKeyType>::*)(  const TheKeyType &  ) const) &NCollection_DefaultHasher<TheKeyType>::operator(),
             py::is_operator(),
             R"#()#" ,py::arg("theKey"))
    ;
};

template <int MyAlignSize=16>
void preregister_template_NCollection_AliasedArray(py::object &m, const char *name){
    py::class_<NCollection_AliasedArray<MyAlignSize> , shared_ptr<NCollection_AliasedArray<MyAlignSize>> >(m,name,R"#(Defines an array of values of configurable size. For instance, this class allows defining an array of 32-bit or 64-bit integer values with bitness determined in runtime. The element size in bytes (stride) should be specified at construction time. Indexation starts from 0 index. As actual type of element varies at runtime, element accessors are defined as templates. Memory for array is allocated with the given alignment (template parameter).)#");
}

template <int MyAlignSize=16>
void register_template_NCollection_AliasedArray(py::object &m, const char *name){
    static_cast<py::class_<NCollection_AliasedArray<MyAlignSize> , shared_ptr<NCollection_AliasedArray<MyAlignSize>> >>(m.attr(name))
        .def(py::init< int >() ,py::arg("theStride") )
        .def(py::init< int,int >() ,py::arg("theStride"), py::arg("theLength") )
        .def(py::init<  const NCollection_AliasedArray<MyAlignSize> & >() ,py::arg("theOther") )
        .def("Stride",
             (int (NCollection_AliasedArray<MyAlignSize>::*)() const) &NCollection_AliasedArray<MyAlignSize>::Stride,
             R"#(Returns an element size in bytes.)#" )
        .def("Size",
             (int (NCollection_AliasedArray<MyAlignSize>::*)() const) &NCollection_AliasedArray<MyAlignSize>::Size,
             R"#(Size query)#" )
        .def("Length",
             (int (NCollection_AliasedArray<MyAlignSize>::*)() const) &NCollection_AliasedArray<MyAlignSize>::Length,
             R"#(Length query (the same as Size()))#" )
        .def("IsEmpty",
             (bool (NCollection_AliasedArray<MyAlignSize>::*)() const) &NCollection_AliasedArray<MyAlignSize>::IsEmpty,
             R"#(Return TRUE if array has zero length.)#" )
        .def("Lower",
             (int (NCollection_AliasedArray<MyAlignSize>::*)() const) &NCollection_AliasedArray<MyAlignSize>::Lower,
             R"#(Lower bound)#" )
        .def("Upper",
             (int (NCollection_AliasedArray<MyAlignSize>::*)() const) &NCollection_AliasedArray<MyAlignSize>::Upper,
             R"#(Upper bound)#" )
        .def("IsDeletable",
             (bool (NCollection_AliasedArray<MyAlignSize>::*)() const) &NCollection_AliasedArray<MyAlignSize>::IsDeletable,
             R"#(myDeletable flag)#" )
        .def("IsAllocated",
             (bool (NCollection_AliasedArray<MyAlignSize>::*)() const) &NCollection_AliasedArray<MyAlignSize>::IsAllocated,
             R"#(IsAllocated flag - for naming compatibility)#" )
        .def("SizeBytes",
             (size_t (NCollection_AliasedArray<MyAlignSize>::*)() const) &NCollection_AliasedArray<MyAlignSize>::SizeBytes,
             R"#(Return buffer size in bytes.)#" )
        .def("Assign",
             (NCollection_AliasedArray<MyAlignSize> & (NCollection_AliasedArray<MyAlignSize>::*)(  const NCollection_AliasedArray<MyAlignSize> &  ) ) &NCollection_AliasedArray<MyAlignSize>::Assign,
             R"#(Copies data of theOther array to this. This array should be pre-allocated and have the same length as theOther; otherwise exception Standard_DimensionMismatch is thrown.)#" ,py::arg("theOther"))
        .def("Move",
             (NCollection_AliasedArray<MyAlignSize> & (NCollection_AliasedArray<MyAlignSize>::*)( NCollection_AliasedArray<MyAlignSize> &  ) ) &NCollection_AliasedArray<MyAlignSize>::Move,
             R"#(Move assignment. This array will borrow all the data from theOther. The moved object will keep pointer to the memory buffer and range, but it will not free the buffer on destruction.)#" ,py::arg("theOther"))
        .def("Resize",
             (void (NCollection_AliasedArray<MyAlignSize>::*)( int ,  bool  ) ) &NCollection_AliasedArray<MyAlignSize>::Resize,
             R"#(Resizes the array to specified bounds. No re-allocation will be done if length of array does not change, but existing values will not be discarded if theToCopyData set to FALSE.)#" ,py::arg("theLength"), py::arg("theToCopyData"))
        .def("value",
             ( const uint8_t * (NCollection_AliasedArray<MyAlignSize>::*)( int  ) const) &NCollection_AliasedArray<MyAlignSize>::value,
             R"#(Access raw bytes of specified element.)#" ,py::arg("theIndex"))
        .def("changeValue",
             (uint8_t * (NCollection_AliasedArray<MyAlignSize>::*)( int  ) ) &NCollection_AliasedArray<MyAlignSize>::changeValue,
             R"#(Access raw bytes of specified element.)#" ,py::arg("theIndex"))
        .def("__len__",[](const NCollection_AliasedArray<MyAlignSize> &self)
             { return self.Size(); }
             )
        .def("__bool__",[](const NCollection_AliasedArray<MyAlignSize> &self)
             { return self.IsEmpty(); }
             )
    ;
};

template <typename TheObjType,typename TheBndType>
void preregister_template_NCollection_EBTree(py::object &m, const char *name){
    py::class_<NCollection_EBTree<TheObjType,TheBndType> , shared_ptr<NCollection_EBTree<TheObjType,TheBndType>> , NCollection_UBTree<TheObjType, TheBndType> >(m,name,R"#(The algorithm of unbalanced binary tree of overlapped bounding boxes with the possibility of deleting objects from the tree.)#");
}

template <typename TheObjType,typename TheBndType>
void register_template_NCollection_EBTree(py::object &m, const char *name){
    static_cast<py::class_<NCollection_EBTree<TheObjType,TheBndType> , shared_ptr<NCollection_EBTree<TheObjType,TheBndType>> , NCollection_UBTree<TheObjType, TheBndType> >>(m.attr(name))
        .def(py::init<  const handle<NCollection_BaseAllocator> & >() ,py::arg("theAllocator")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr) )
        .def("Add",
             (bool (NCollection_EBTree<TheObjType,TheBndType>::*)(  const TheObjType & ,   const TheBndType &  ) ) &NCollection_EBTree<TheObjType,TheBndType>::Add,
             R"#(Updates the tree with a new object and its bounding box. Extends the functionality of the parent method by maintaining the map myObjNodeMap. Redefined virtual method.)#" ,py::arg("theObj"), py::arg("theBnd"))
        .def("Remove",
             (bool (NCollection_EBTree<TheObjType,TheBndType>::*)(  const TheObjType &  ) ) &NCollection_EBTree<TheObjType,TheBndType>::Remove,
             R"#(Removes the given object and updates the tree.)#" ,py::arg("theObj"))
        .def("Contains",
             (bool (NCollection_EBTree<TheObjType,TheBndType>::*)(  const TheObjType &  ) const) &NCollection_EBTree<TheObjType,TheBndType>::Contains,
             R"#(Returns True if the tree contains the object.)#" ,py::arg("theObj"))
        .def("FindNode",
             ( const typename NCollection_EBTree<TheObjType, TheBndType>::TreeNode & (NCollection_EBTree<TheObjType,TheBndType>::*)(  const TheObjType &  ) const) &NCollection_EBTree<TheObjType,TheBndType>::FindNode,
             R"#(Returns The leaf node containing the object.)#" ,py::arg("theObj"))
        .def("Clear",
             (void (NCollection_EBTree<TheObjType,TheBndType>::*)(  const handle<NCollection_BaseAllocator> &  ) ) &NCollection_EBTree<TheObjType,TheBndType>::Clear,
             R"#(Clears the contents of the tree. Redefined virtual method)#" ,py::arg("aNewAlloc")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr))
    ;
};

template <typename TheKeyType,typename Hasher=NCollection_DefaultHasher<TheKeyType>>
void preregister_template_NCollection_IndexedMap(py::object &m, const char *name){
    py::class_<NCollection_IndexedMap<TheKeyType,Hasher> , shared_ptr<NCollection_IndexedMap<TheKeyType,Hasher>> , NCollection_BaseMap >(m,name,R"#(Purpose: An indexed map is used to store keys and to bind an index to them. Each new key stored in the map gets an index. Index are incremented as keys are stored in the map. A key can be found by the index and an index by the key. No key but the last can be removed so the indices are in the range 1..Extent. See the class Map from NCollection for a discussion about the number of buckets.)#");
}

template <typename TheKeyType,typename Hasher=NCollection_DefaultHasher<TheKeyType>>
void register_template_NCollection_IndexedMap(py::object &m, const char *name){
    static_cast<py::class_<NCollection_IndexedMap<TheKeyType,Hasher> , shared_ptr<NCollection_IndexedMap<TheKeyType,Hasher>> , NCollection_BaseMap >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const size_t, const handle<NCollection_BaseAllocator> & >() ,py::arg("theNbBuckets"), py::arg("theAllocator")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr) )
        .def(py::init<  const int, const handle<NCollection_BaseAllocator> & >() ,py::arg("theNbBuckets"), py::arg("theAllocator")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr) )
        .def(py::init<  const Hasher &, const size_t, const handle<NCollection_BaseAllocator> & >() ,py::arg("theHasher"), py::arg("theNbBuckets")=static_cast< const size_t>(1), py::arg("theAllocator")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr) )
        .def(py::init<  const Hasher &, const int, const handle<NCollection_BaseAllocator> & >() ,py::arg("theHasher"), py::arg("theNbBuckets"), py::arg("theAllocator")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr) )
        .def(py::init<  const NCollection_IndexedMap<TheKeyType, Hasher> & >() ,py::arg("theOther") )
        .def("IndexedItems",
             (typename NCollection_IndexedMap<TheKeyType, Hasher>::IndexedItemsView (NCollection_IndexedMap<TheKeyType,Hasher>::*)() const) &NCollection_IndexedMap<TheKeyType,Hasher>::IndexedItems,
             R"#(Returns a view for key-index pair iteration. Usage: for (auto [aKey, anIndex] : aMap.IndexedItems()))#" )
        .def("Exchange",
             (void (NCollection_IndexedMap<TheKeyType,Hasher>::*)( NCollection_IndexedMap<TheKeyType, Hasher> &  ) ) &NCollection_IndexedMap<TheKeyType,Hasher>::Exchange,
             R"#(Exchange the content of two maps without re-allocations. Notice that allocators will be swapped as well!)#" ,py::arg("theOther"))
        .def("GetHasher",
             ( const Hasher & (NCollection_IndexedMap<TheKeyType,Hasher>::*)() const) &NCollection_IndexedMap<TheKeyType,Hasher>::GetHasher,
             R"#(Returns const reference to the hasher.)#" )
        .def("Assign",
             (NCollection_IndexedMap<TheKeyType, Hasher> & (NCollection_IndexedMap<TheKeyType,Hasher>::*)(  const NCollection_IndexedMap<TheKeyType, Hasher> &  ) ) &NCollection_IndexedMap<TheKeyType,Hasher>::Assign,
             R"#(Assign. This method does not change the internal allocator.)#" ,py::arg("theOther"))
        .def("ReSize",
             (void (NCollection_IndexedMap<TheKeyType,Hasher>::*)(  const size_t  ) ) &NCollection_IndexedMap<TheKeyType,Hasher>::ReSize,
             R"#(ReSize)#" ,py::arg("theExtent"))
        .def("ReSize",
             (void (NCollection_IndexedMap<TheKeyType,Hasher>::*)(  const int  ) ) &NCollection_IndexedMap<TheKeyType,Hasher>::ReSize,
             R"#()#" ,py::arg("theExtent"))
        .def("Add",
             (int (NCollection_IndexedMap<TheKeyType,Hasher>::*)(  const TheKeyType &  ) ) &NCollection_IndexedMap<TheKeyType,Hasher>::Add,
             R"#(Add adds a new key to the map.)#" ,py::arg("theKey1"))
        .def("Added",
             ( const TheKeyType & (NCollection_IndexedMap<TheKeyType,Hasher>::*)(  const TheKeyType &  ) ) &NCollection_IndexedMap<TheKeyType,Hasher>::Added,
             R"#(Added: add a new key if not yet in the map, and return reference to either newly added or previously existing key.)#" ,py::arg("theKey1"))
        .def("Contains",
             (bool (NCollection_IndexedMap<TheKeyType,Hasher>::*)(  const TheKeyType &  ) const) &NCollection_IndexedMap<TheKeyType,Hasher>::Contains,
             R"#(Contains)#" ,py::arg("theKey1"))
        .def("Substitute",
             (void (NCollection_IndexedMap<TheKeyType,Hasher>::*)(  const size_t ,   const TheKeyType &  ) ) &NCollection_IndexedMap<TheKeyType,Hasher>::Substitute,
             R"#(Substitute)#" ,py::arg("theIndex"), py::arg("theKey1"))
        .def("Substitute",
             (void (NCollection_IndexedMap<TheKeyType,Hasher>::*)(  const int ,   const TheKeyType &  ) ) &NCollection_IndexedMap<TheKeyType,Hasher>::Substitute,
             R"#()#" ,py::arg("theIndex"), py::arg("theKey1"))
        .def("Swap",
             (void (NCollection_IndexedMap<TheKeyType,Hasher>::*)(  const size_t ,   const size_t  ) ) &NCollection_IndexedMap<TheKeyType,Hasher>::Swap,
             R"#(Swaps two elements with the given indices.)#" ,py::arg("theIndex1"), py::arg("theIndex2"))
        .def("Swap",
             (void (NCollection_IndexedMap<TheKeyType,Hasher>::*)(  const int ,   const int  ) ) &NCollection_IndexedMap<TheKeyType,Hasher>::Swap,
             R"#()#" ,py::arg("theIndex1"), py::arg("theIndex2"))
        .def("RemoveLast",
             (void (NCollection_IndexedMap<TheKeyType,Hasher>::*)() ) &NCollection_IndexedMap<TheKeyType,Hasher>::RemoveLast,
             R"#(RemoveLast)#" )
        .def("RemoveFromIndex",
             (void (NCollection_IndexedMap<TheKeyType,Hasher>::*)(  const size_t  ) ) &NCollection_IndexedMap<TheKeyType,Hasher>::RemoveFromIndex,
             R"#(Remove the key of the given index. Caution! The index of the last key can be changed.)#" ,py::arg("theIndex"))
        .def("RemoveFromIndex",
             (void (NCollection_IndexedMap<TheKeyType,Hasher>::*)(  const int  ) ) &NCollection_IndexedMap<TheKeyType,Hasher>::RemoveFromIndex,
             R"#()#" ,py::arg("theIndex"))
        .def("RemoveKey",
             (bool (NCollection_IndexedMap<TheKeyType,Hasher>::*)(  const TheKeyType &  ) ) &NCollection_IndexedMap<TheKeyType,Hasher>::RemoveKey,
             R"#(Remove the given key. Caution! The index of the last key can be changed.)#" ,py::arg("theKey1"))
        .def("FindKey",
             ( const TheKeyType & (NCollection_IndexedMap<TheKeyType,Hasher>::*)(  const size_t  ) const) &NCollection_IndexedMap<TheKeyType,Hasher>::FindKey,
             R"#(FindKey)#" ,py::arg("theIndex"))
        .def("FindKey",
             ( const TheKeyType & (NCollection_IndexedMap<TheKeyType,Hasher>::*)(  const int  ) const) &NCollection_IndexedMap<TheKeyType,Hasher>::FindKey,
             R"#()#" ,py::arg("theIndex"))
        .def("FindIndex",
             (int (NCollection_IndexedMap<TheKeyType,Hasher>::*)(  const TheKeyType &  ) const) &NCollection_IndexedMap<TheKeyType,Hasher>::FindIndex,
             R"#(FindIndex)#" ,py::arg("theKey1"))
        .def("Clear",
             (void (NCollection_IndexedMap<TheKeyType,Hasher>::*)(  const bool  ) ) &NCollection_IndexedMap<TheKeyType,Hasher>::Clear,
             R"#(Clear data. If doReleaseMemory is false then the table of buckets is not released and will be reused.)#" ,py::arg("doReleaseMemory")=static_cast< const bool>(false))
        .def("Clear",
             (void (NCollection_IndexedMap<TheKeyType,Hasher>::*)(  const handle<NCollection_BaseAllocator> &  ) ) &NCollection_IndexedMap<TheKeyType,Hasher>::Clear,
             R"#(Clear data and reset allocator)#" ,py::arg("theAllocator"))
        .def("__call__",
             ( const TheKeyType & (NCollection_IndexedMap<TheKeyType,Hasher>::*)(  const size_t  ) const) &NCollection_IndexedMap<TheKeyType,Hasher>::operator(),
             py::is_operator(),
             R"#(operator ())#" ,py::arg("theIndex"))
        .def("__call__",
             ( const TheKeyType & (NCollection_IndexedMap<TheKeyType,Hasher>::*)(  const int  ) const) &NCollection_IndexedMap<TheKeyType,Hasher>::operator(),
             py::is_operator(),
             R"#()#" ,py::arg("theIndex"))
        .def("__iter__",[](const NCollection_IndexedMap<TheKeyType,Hasher> &self)
             { return py::make_iterator<py::return_value_policy::copy>(self.begin(), self.end()); },
             py::keep_alive<0, 1>())
        .def("__len__",[](const NCollection_IndexedMap<TheKeyType,Hasher> &self)
             { return self.Extent(); }
             )
        .def("__len__",[](const NCollection_IndexedMap<TheKeyType,Hasher> &self)
             { return self.Size(); }
             )
        .def("__bool__",[](const NCollection_IndexedMap<TheKeyType,Hasher> &self)
             { return self.IsEmpty(); }
             )
    ;
};

template <typename TheItemType>
void preregister_template_NCollection_HArray2(py::object &m, const char *name){
    py::class_<NCollection_HArray2<TheItemType> , opencascade::handle<NCollection_HArray2<TheItemType>> , NCollection_Array2<TheItemType> , Standard_Transient >(m,name,R"#(Template class for Handle-managed 2D arrays. Inherits from both NCollection_Array2<TheItemType> and Standard_Transient, providing reference-counted 2D array functionality.)#");
}

template <typename TheItemType>
void register_template_NCollection_HArray2(py::object &m, const char *name){
    static_cast<py::class_<NCollection_HArray2<TheItemType> , opencascade::handle<NCollection_HArray2<TheItemType>> , NCollection_Array2<TheItemType> , Standard_Transient >>(m.attr(name))
        .def(py::init<  const int, const int, const int, const int >() ,py::arg("theRowLow"), py::arg("theRowUpp"), py::arg("theColLow"), py::arg("theColUpp") )
        .def(py::init<  const int, const int, const int, const int, const TheItemType & >() ,py::arg("theRowLow"), py::arg("theRowUpp"), py::arg("theColLow"), py::arg("theColUpp"), py::arg("theValue") )
        .def(py::init<  const typename NCollection_HArray2<TheItemType>::Array2Type & >() ,py::arg("theOther") )
        .def("Array2",
             ( const typename NCollection_HArray2<TheItemType>::Array2Type & (NCollection_HArray2<TheItemType>::*)() const) &NCollection_HArray2<TheItemType>::Array2,
             R"#(Returns const reference to the underlying array.)#" )
        .def("ChangeArray2",
             (typename NCollection_HArray2<TheItemType>::Array2Type & (NCollection_HArray2<TheItemType>::*)() ) &NCollection_HArray2<TheItemType>::ChangeArray2,
             R"#(Returns mutable reference to the underlying array.)#" )
        .def("DynamicType",
             ( const handle<Standard_Type> & (NCollection_HArray2<TheItemType>::*)() const) &NCollection_HArray2<TheItemType>::DynamicType,
             R"#()#" )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) &NCollection_HArray2<TheItemType>::get_type_name,
                    R"#()#" )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) &NCollection_HArray2<TheItemType>::get_type_descriptor,
                    R"#()#" )
    ;
};

template <typename Type>
void preregister_template_NCollection_UtfString(py::object &m, const char *name){
    py::class_<NCollection_UtfString<Type> , shared_ptr<NCollection_UtfString<Type>> >(m,name,R"#(This template class represent constant UTF-* string. String stored in memory continuously, always NULL-terminated and can be used as standard C-string using ToCString() method.)#");
}

template <typename Type>
void register_template_NCollection_UtfString(py::object &m, const char *name){
    static_cast<py::class_<NCollection_UtfString<Type> , shared_ptr<NCollection_UtfString<Type>> >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const NCollection_UtfString<Type> & >() ,py::arg("theCopy") )
        .def(py::init<  const char *, const int >() ,py::arg("theCopyUtf8"), py::arg("theLength")=static_cast< const int>(- 1) )
        .def(py::init<  const char16_t *, const int >() ,py::arg("theCopyUtf16"), py::arg("theLength")=static_cast< const int>(- 1) )
        .def(py::init<  const char32_t *, const int >() ,py::arg("theCopyUtf32"), py::arg("theLength")=static_cast< const int>(- 1) )
        .def(py::init<  const wchar_t *, const int >() ,py::arg("theCopyUtfWide"), py::arg("theLength")=static_cast< const int>(- 1) )
        .def("Iterator",
             (NCollection_UtfIterator<Type> (NCollection_UtfString<Type>::*)() const) &NCollection_UtfString<Type>::Iterator,
             R"#()#" )
        .def("Size",
             (int (NCollection_UtfString<Type>::*)() const) &NCollection_UtfString<Type>::Size,
             R"#(Returns the size of the buffer in bytes, excluding NULL-termination symbol)#" )
        .def("Length",
             (int (NCollection_UtfString<Type>::*)() const) &NCollection_UtfString<Type>::Length,
             R"#(Returns the length of the string in Unicode symbols)#" )
        .def("GetChar",
             (char32_t (NCollection_UtfString<Type>::*)(  const int  ) const) &NCollection_UtfString<Type>::GetChar,
             R"#(Retrieve Unicode symbol at specified position. Warning! This is a slow access. Iterator should be used for consecutive parsing.)#" ,py::arg("theCharIndex"))
        .def("GetCharBuffer",
             ( const Type * (NCollection_UtfString<Type>::*)(  const int  ) const) &NCollection_UtfString<Type>::GetCharBuffer,
             R"#(Retrieve string buffer at specified position. Warning! This is a slow access. Iterator should be used for consecutive parsing.)#" ,py::arg("theCharIndex"))
        .def("FromLocale",
             (void (NCollection_UtfString<Type>::*)(  const char * ,   const int  ) ) &NCollection_UtfString<Type>::FromLocale,
             R"#(Copy from multibyte string in current system locale.)#" ,py::arg("theString"), py::arg("theLength")=static_cast< const int>(- 1))
        .def("IsEqual",
             (bool (NCollection_UtfString<Type>::*)(  const NCollection_UtfString<Type> &  ) const) &NCollection_UtfString<Type>::IsEqual,
             R"#(Compares this string with another one.)#" ,py::arg("theCompare"))
        .def("SubString",
             (NCollection_UtfString<Type> (NCollection_UtfString<Type>::*)(  const int ,   const int  ) const) &NCollection_UtfString<Type>::SubString,
             R"#(Returns the substring.)#" ,py::arg("theStart"), py::arg("theEnd"))
        .def("ToCString",
             ( const Type * (NCollection_UtfString<Type>::*)() const) &NCollection_UtfString<Type>::ToCString,
             R"#(Returns NULL-terminated Unicode string. Should not be modified or deleted!)#" )
        .def("ToUtf8",
             ( const NCollection_UtfString<char> (NCollection_UtfString<Type>::*)() const) &NCollection_UtfString<Type>::ToUtf8,
             R"#(Returns copy in UTF-8 format)#" )
        .def("ToUtf16",
             ( const NCollection_UtfString<char16_t> (NCollection_UtfString<Type>::*)() const) &NCollection_UtfString<Type>::ToUtf16,
             R"#(Returns copy in UTF-16 format)#" )
        .def("ToUtf32",
             ( const NCollection_UtfString<char32_t> (NCollection_UtfString<Type>::*)() const) &NCollection_UtfString<Type>::ToUtf32,
             R"#(Returns copy in UTF-32 format)#" )
        .def("ToUtfWide",
             ( const NCollection_UtfString<wchar_t> (NCollection_UtfString<Type>::*)() const) &NCollection_UtfString<Type>::ToUtfWide,
             R"#(Returns copy in wide format (UTF-16 on Windows and UTF-32 on Linux))#" )
        .def("ToLocale",
             (bool (NCollection_UtfString<Type>::*)( char * ,   const int  ) const) &NCollection_UtfString<Type>::ToLocale,
             R"#(Converts the string into string in the current system locale.)#" ,py::arg("theBuffer"), py::arg("theSizeBytes"))
        .def("IsEmpty",
             (bool (NCollection_UtfString<Type>::*)() const) &NCollection_UtfString<Type>::IsEmpty,
             R"#(Returns true if string is empty)#" )
        .def("Clear",
             (void (NCollection_UtfString<Type>::*)() ) &NCollection_UtfString<Type>::Clear,
             R"#(Zero string.)#" )
        .def("Assign",
             ( const NCollection_UtfString<Type> & (NCollection_UtfString<Type>::*)(  const NCollection_UtfString<Type> &  ) ) &NCollection_UtfString<Type>::Assign,
             R"#(Copy from another string.)#" ,py::arg("theOther"))
        .def("Swap",
             (void (NCollection_UtfString<Type>::*)( NCollection_UtfString<Type> &  ) ) &NCollection_UtfString<Type>::Swap,
             R"#(Exchange the data of two strings (without reallocating memory).)#" ,py::arg("theOther"))
        .def("__iadd__",
             (NCollection_UtfString<Type> & (NCollection_UtfString<Type>::*)(  const NCollection_UtfString<Type> &  ) ) &NCollection_UtfString<Type>::operator+=,
             py::is_operator(),
             R"#(Join strings.)#" ,py::arg("theAppend"))
        .def("__len__",[](const NCollection_UtfString<Type> &self)
             { return self.Size(); }
             )
        .def("__bool__",[](const NCollection_UtfString<Type> &self)
             { return self.IsEmpty(); }
             )
    ;
};

template <typename Element_t>
void preregister_template_NCollection_Vec4(py::object &m, const char *name){
    py::class_<NCollection_Vec4<Element_t> , shared_ptr<NCollection_Vec4<Element_t>> >(m,name,R"#(Generic 4-components vector. To be used as RGBA color vector or XYZW 3D-point with special W-component for operations with projection / model view matrices. Use this class for 3D-points carefully because declared W-component may results in incorrect results if used without matrices.)#");
}

template <typename Element_t>
void register_template_NCollection_Vec4(py::object &m, const char *name){
    static_cast<py::class_<NCollection_Vec4<Element_t> , shared_ptr<NCollection_Vec4<Element_t>> >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const Element_t >() ,py::arg("theValue") )
        .def(py::init<  const Element_t, const Element_t, const Element_t, const Element_t >() ,py::arg("theX"), py::arg("theY"), py::arg("theZ"), py::arg("theW") )
        .def(py::init<  const NCollection_Vec2<Element_t> & >() ,py::arg("theVec2") )
        .def(py::init<  const NCollection_Vec3<Element_t> &, const Element_t >() ,py::arg("theVec3"), py::arg("theW")=static_cast< const Element_t>(Element_t ( 0 )) )
        .def("SetValues",
             (void (NCollection_Vec4<Element_t>::*)(  const Element_t ,   const Element_t ,   const Element_t ,   const Element_t  ) ) &NCollection_Vec4<Element_t>::SetValues,
             R"#(Assign new values to the vector.)#" ,py::arg("theX"), py::arg("theY"), py::arg("theZ"), py::arg("theW"))
        .def("SetValues",
             (void (NCollection_Vec4<Element_t>::*)(  const NCollection_Vec3<Element_t> & ,   const Element_t  ) ) &NCollection_Vec4<Element_t>::SetValues,
             R"#(Assign new values as 3-component vector and a 4-th value.)#" ,py::arg("theVec3"), py::arg("theW"))
        .def("x",
             (Element_t (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::x,
             R"#(Alias to 1st component as X coordinate in XYZW.)#" )
        .def("r",
             (Element_t (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::r,
             R"#(Alias to 1st component as RED channel in RGBA.)#" )
        .def("y",
             (Element_t (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::y,
             R"#(Alias to 2nd component as Y coordinate in XYZW.)#" )
        .def("g",
             (Element_t (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::g,
             R"#(Alias to 2nd component as GREEN channel in RGBA.)#" )
        .def("z",
             (Element_t (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::z,
             R"#(Alias to 3rd component as Z coordinate in XYZW.)#" )
        .def("b",
             (Element_t (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::b,
             R"#(Alias to 3rd component as BLUE channel in RGBA.)#" )
        .def("w",
             (Element_t (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::w,
             R"#(Alias to 4th component as W coordinate in XYZW.)#" )
        .def("a",
             (Element_t (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::a,
             R"#(Alias to 4th component as ALPHA channel in RGBA.)#" )
        .def("xy",
             (NCollection_Vec2<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::xy,
             R"#(Returns 2 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("yx",
             (NCollection_Vec2<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::yx,
             R"#(Returns 2 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("xz",
             (NCollection_Vec2<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::xz,
             R"#(Returns 2 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("zx",
             (NCollection_Vec2<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::zx,
             R"#(Returns 2 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("xw",
             (NCollection_Vec2<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::xw,
             R"#(Returns 2 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("wx",
             (NCollection_Vec2<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::wx,
             R"#(Returns 2 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("yz",
             (NCollection_Vec2<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::yz,
             R"#(Returns 2 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("zy",
             (NCollection_Vec2<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::zy,
             R"#(Returns 2 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("yw",
             (NCollection_Vec2<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::yw,
             R"#(Returns 2 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("wy",
             (NCollection_Vec2<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::wy,
             R"#(Returns 2 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("zw",
             (NCollection_Vec2<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::zw,
             R"#(Returns 2 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("wz",
             (NCollection_Vec2<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::wz,
             R"#(Returns 2 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("xyz",
             (NCollection_Vec3<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::xyz,
             R"#(Returns 3 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("xzy",
             (NCollection_Vec3<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::xzy,
             R"#(Returns 3 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("yxz",
             (NCollection_Vec3<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::yxz,
             R"#(Returns 3 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("yzx",
             (NCollection_Vec3<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::yzx,
             R"#(Returns 3 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("zyx",
             (NCollection_Vec3<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::zyx,
             R"#(Returns 3 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("zxy",
             (NCollection_Vec3<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::zxy,
             R"#(Returns 3 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("xyw",
             (NCollection_Vec3<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::xyw,
             R"#(Returns 3 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("xwy",
             (NCollection_Vec3<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::xwy,
             R"#(Returns 3 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("yxw",
             (NCollection_Vec3<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::yxw,
             R"#(Returns 3 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("ywx",
             (NCollection_Vec3<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::ywx,
             R"#(Returns 3 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("wyx",
             (NCollection_Vec3<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::wyx,
             R"#(Returns 3 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("wxy",
             (NCollection_Vec3<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::wxy,
             R"#(Returns 3 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("xzw",
             (NCollection_Vec3<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::xzw,
             R"#(Returns 3 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("xwz",
             (NCollection_Vec3<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::xwz,
             R"#(Returns 3 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("zxw",
             (NCollection_Vec3<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::zxw,
             R"#(Returns 3 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("zwx",
             (NCollection_Vec3<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::zwx,
             R"#(Returns 3 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("wzx",
             (NCollection_Vec3<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::wzx,
             R"#(Returns 3 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("wxz",
             (NCollection_Vec3<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::wxz,
             R"#(Returns 3 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("yzw",
             (NCollection_Vec3<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::yzw,
             R"#(Returns 3 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("ywz",
             (NCollection_Vec3<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::ywz,
             R"#(Returns 3 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("zyw",
             (NCollection_Vec3<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::zyw,
             R"#(Returns 3 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("zwy",
             (NCollection_Vec3<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::zwy,
             R"#(Returns 3 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("wzy",
             (NCollection_Vec3<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::wzy,
             R"#(Returns 3 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("wyz",
             (NCollection_Vec3<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::wyz,
             R"#(Returns 3 of XYZW components in specified order as vector in GLSL-style)#" )
        .def("rgb",
             (NCollection_Vec3<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::rgb,
             R"#(Returns RGB components as vector)#" )
        .def("rbg",
             (NCollection_Vec3<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::rbg,
             R"#(Returns RGB components as vector)#" )
        .def("grb",
             (NCollection_Vec3<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::grb,
             R"#(Returns RGB components as vector)#" )
        .def("gbr",
             (NCollection_Vec3<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::gbr,
             R"#(Returns RGB components as vector)#" )
        .def("bgr",
             (NCollection_Vec3<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::bgr,
             R"#(Returns RGB components as vector)#" )
        .def("brg",
             (NCollection_Vec3<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::brg,
             R"#(Returns RGB components as vector)#" )
        .def("x",
             (Element_t & (NCollection_Vec4<Element_t>::*)() ) &NCollection_Vec4<Element_t>::x,
             R"#(Alias to 1st component as X coordinate in XYZW.)#" )
        .def("r",
             (Element_t & (NCollection_Vec4<Element_t>::*)() ) &NCollection_Vec4<Element_t>::r,
             R"#(Alias to 1st component as RED channel in RGBA.)#" )
        .def("y",
             (Element_t & (NCollection_Vec4<Element_t>::*)() ) &NCollection_Vec4<Element_t>::y,
             R"#(Alias to 2nd component as Y coordinate in XYZW.)#" )
        .def("g",
             (Element_t & (NCollection_Vec4<Element_t>::*)() ) &NCollection_Vec4<Element_t>::g,
             R"#(Alias to 2nd component as GREEN channel in RGBA.)#" )
        .def("z",
             (Element_t & (NCollection_Vec4<Element_t>::*)() ) &NCollection_Vec4<Element_t>::z,
             R"#(Alias to 3rd component as Z coordinate in XYZW.)#" )
        .def("b",
             (Element_t & (NCollection_Vec4<Element_t>::*)() ) &NCollection_Vec4<Element_t>::b,
             R"#(Alias to 3rd component as BLUE channel in RGBA.)#" )
        .def("w",
             (Element_t & (NCollection_Vec4<Element_t>::*)() ) &NCollection_Vec4<Element_t>::w,
             R"#(Alias to 4th component as W coordinate in XYZW.)#" )
        .def("a",
             (Element_t & (NCollection_Vec4<Element_t>::*)() ) &NCollection_Vec4<Element_t>::a,
             R"#(Alias to 4th component as ALPHA channel in RGBA.)#" )
        .def("IsEqual",
             (bool (NCollection_Vec4<Element_t>::*)(  const NCollection_Vec4<Element_t> &  ) const) &NCollection_Vec4<Element_t>::IsEqual,
             R"#(Check this vector with another vector for equality (without tolerance!).)#" ,py::arg("theOther"))
        .def("GetData",
             ( const Element_t * (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::GetData,
             R"#(Raw access to the data (for OpenGL exchange).)#" )
        .def("ChangeData",
             (Element_t * (NCollection_Vec4<Element_t>::*)() ) &NCollection_Vec4<Element_t>::ChangeData,
             R"#()#" )
        .def("Multiply",
             (void (NCollection_Vec4<Element_t>::*)(  const Element_t  ) ) &NCollection_Vec4<Element_t>::Multiply,
             R"#(Compute per-component multiplication.)#" ,py::arg("theFactor"))
        .def("Multiplied",
             (NCollection_Vec4<Element_t> (NCollection_Vec4<Element_t>::*)(  const Element_t  ) const) &NCollection_Vec4<Element_t>::Multiplied,
             R"#(Compute per-component multiplication.)#" ,py::arg("theFactor"))
        .def("cwiseMin",
             (NCollection_Vec4<Element_t> (NCollection_Vec4<Element_t>::*)(  const NCollection_Vec4<Element_t> &  ) const) &NCollection_Vec4<Element_t>::cwiseMin,
             R"#(Compute component-wise minimum of two vectors.)#" ,py::arg("theVec"))
        .def("cwiseMax",
             (NCollection_Vec4<Element_t> (NCollection_Vec4<Element_t>::*)(  const NCollection_Vec4<Element_t> &  ) const) &NCollection_Vec4<Element_t>::cwiseMax,
             R"#(Compute component-wise maximum of two vectors.)#" ,py::arg("theVec"))
        .def("cwiseAbs",
             (NCollection_Vec4<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::cwiseAbs,
             R"#(Compute component-wise modulus of the vector.)#" )
        .def("maxComp",
             (Element_t (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::maxComp,
             R"#(Compute maximum component of the vector.)#" )
        .def("minComp",
             (Element_t (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::minComp,
             R"#(Compute minimum component of the vector.)#" )
        .def("Dot",
             (Element_t (NCollection_Vec4<Element_t>::*)(  const NCollection_Vec4<Element_t> &  ) const) &NCollection_Vec4<Element_t>::Dot,
             R"#(Computes the dot product.)#" ,py::arg("theOther"))
        .def("DumpJson",
             (void (NCollection_Vec4<Element_t>::*)( Standard_OStream & ,  int  ) const) &NCollection_Vec4<Element_t>::DumpJson,
             R"#(Dumps the content of me into the stream)#" ,py::arg("theOStream"), py::arg("theDepth")=static_cast<int>(- 1))
        .def_static("Length_s",
                    (int (*)() ) &NCollection_Vec4<Element_t>::Length,
                    R"#(Returns the number of components.)#" )
        .def("__iadd__",
             (NCollection_Vec4<Element_t> & (NCollection_Vec4<Element_t>::*)(  const NCollection_Vec4<Element_t> &  ) ) &NCollection_Vec4<Element_t>::operator+=,
             py::is_operator(),
             R"#(Compute per-component summary.)#" ,py::arg("theAdd"))
        .def("__neg__",
             (NCollection_Vec4<Element_t> (NCollection_Vec4<Element_t>::*)() const) &NCollection_Vec4<Element_t>::operator-,
             py::is_operator(),
             R"#(Unary -.)#" )
        .def("__isub__",
             (NCollection_Vec4<Element_t> & (NCollection_Vec4<Element_t>::*)(  const NCollection_Vec4<Element_t> &  ) ) &NCollection_Vec4<Element_t>::operator-=,
             py::is_operator(),
             R"#(Compute per-component subtraction.)#" ,py::arg("theDec"))
        .def("__imul__",
             (NCollection_Vec4<Element_t> & (NCollection_Vec4<Element_t>::*)(  const NCollection_Vec4<Element_t> &  ) ) &NCollection_Vec4<Element_t>::operator*=,
             py::is_operator(),
             R"#(Compute per-component multiplication.)#" ,py::arg("theRight"))
        .def("__imul__",
             (NCollection_Vec4<Element_t> & (NCollection_Vec4<Element_t>::*)(  const Element_t  ) ) &NCollection_Vec4<Element_t>::operator*=,
             py::is_operator(),
             R"#(Compute per-component multiplication.)#" ,py::arg("theFactor"))
        .def("__mul__",
             (NCollection_Vec4<Element_t> (NCollection_Vec4<Element_t>::*)(  const Element_t  ) const) &NCollection_Vec4<Element_t>::operator*,
             py::is_operator(),
             R"#(Compute per-component multiplication.)#" ,py::arg("theFactor"))
        .def("__rmul__",
             (NCollection_Vec4<Element_t> (NCollection_Vec4<Element_t>::*)(  const Element_t  ) const) &NCollection_Vec4<Element_t>::operator*,
             py::is_operator(),
             R"#(Compute per-component multiplication.)#" ,py::arg("theFactor"))
        .def("__itruediv__",
             (NCollection_Vec4<Element_t> & (NCollection_Vec4<Element_t>::*)(  const Element_t  ) ) &NCollection_Vec4<Element_t>::operator/=,
             py::is_operator(),
             R"#(Compute per-component division by scale factor.)#" ,py::arg("theInvFactor"))
        .def("__itruediv__",
             (NCollection_Vec4<Element_t> & (NCollection_Vec4<Element_t>::*)(  const NCollection_Vec4<Element_t> &  ) ) &NCollection_Vec4<Element_t>::operator/=,
             py::is_operator(),
             R"#(Compute per-component division.)#" ,py::arg("theRight"))
        .def("__truediv__",
             (NCollection_Vec4<Element_t> (NCollection_Vec4<Element_t>::*)(  const Element_t  ) const) &NCollection_Vec4<Element_t>::operator/,
             py::is_operator(),
             R"#(Compute per-component division by scale factor.)#" ,py::arg("theInvFactor"))
    ;
};

template <typename TheKeyType,typename TheItemType,typename Hasher=NCollection_DefaultHasher<TheKeyType>>
void preregister_template_NCollection_FlatDataMap(py::object &m, const char *name){
    py::class_<NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher> , shared_ptr<NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>> >(m,name,R"#(High-performance hash map using open addressing with Robin Hood hashing.)#");
}

template <typename TheKeyType,typename TheItemType,typename Hasher=NCollection_DefaultHasher<TheKeyType>>
void register_template_NCollection_FlatDataMap(py::object &m, const char *name){
    static_cast<py::class_<NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher> , shared_ptr<NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>> >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const size_t >() ,py::arg("theNbBuckets") )
        .def(py::init<  const Hasher &, const size_t >() ,py::arg("theHasher"), py::arg("theNbBuckets")=static_cast< const size_t>(0) )
        .def(py::init<  const NCollection_FlatDataMap<TheKeyType, TheItemType, Hasher> & >() ,py::arg("theOther") )
        .def("Size",
             (size_t (NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::*)() const) &NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::Size,
             R"#(Returns number of elements.)#" )
        .def("Extent",
             (int (NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::*)() const) &NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::Extent,
             R"#(Returns number of elements (legacy int-returning API, convention shared with BaseMap).)#" )
        .def("IsEmpty",
             (bool (NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::*)() const) &NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::IsEmpty,
             R"#(Returns true if map is empty)#" )
        .def("Capacity",
             (size_t (NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::*)() const) &NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::Capacity,
             R"#(Returns current capacity)#" )
        .def("IsBound",
             (bool (NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType &  ) const) &NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::IsBound,
             R"#(Check if key exists)#" ,py::arg("theKey"))
        .def("Seek",
             ( const TheItemType * (NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType &  ) const) &NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::Seek,
             R"#(Find value by key, returns nullptr if not found)#" ,py::arg("theKey"))
        .def("ChangeSeek",
             (TheItemType * (NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType &  ) ) &NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::ChangeSeek,
             R"#(Find value by key (mutable), returns nullptr if not found)#" ,py::arg("theKey"))
        .def("Find",
             ( const TheItemType & (NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType &  ) const) &NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::Find,
             R"#(Find value by key, throws if not found)#" ,py::arg("theKey"))
        .def("ChangeFind",
             (TheItemType & (NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType &  ) ) &NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::ChangeFind,
             R"#(Find value by key (mutable), throws if not found)#" ,py::arg("theKey"))
        .def("Bind",
             (bool (NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType & ,   const TheItemType &  ) ) &NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::Bind,
             R"#(Bind key to value)#" ,py::arg("theKey"), py::arg("theItem"))
        .def("TryBind",
             (bool (NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType & ,   const TheItemType &  ) ) &NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::TryBind,
             R"#(TryBind binds key to value only if key is not yet bound.)#" ,py::arg("theKey"), py::arg("theItem"))
        .def("Bound",
             (TheItemType & (NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType & ,   const TheItemType &  ) ) &NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::Bound,
             R"#(Bound binds key to value and returns reference to the value.)#" ,py::arg("theKey"), py::arg("theItem"))
        .def("TryBound",
             (TheItemType & (NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType & ,   const TheItemType &  ) ) &NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::TryBound,
             R"#(TryBound binds key to value only if key is not yet bound.)#" ,py::arg("theKey"), py::arg("theItem"))
        .def("UnBind",
             (bool (NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType &  ) ) &NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::UnBind,
             R"#(Remove key from map)#" ,py::arg("theKey"))
        .def("Clear",
             (void (NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::*)( bool  ) ) &NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::Clear,
             R"#(Clear all elements)#" ,py::arg("doReleaseMemory")=static_cast<bool>(false))
        .def("Exchange",
             (void (NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::*)( NCollection_FlatDataMap<TheKeyType, TheItemType, Hasher> &  ) ) &NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::Exchange,
             R"#(Exchange content with another map)#" ,py::arg("theOther"))
        .def("GetHasher",
             ( const Hasher & (NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::*)() const) &NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::GetHasher,
             R"#(Returns const reference to the hasher.)#" )
        .def("reserve",
             (void (NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::*)( size_t  ) ) &NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::reserve,
             R"#(Reserve capacity for at least theN elements)#" ,py::arg("theN"))
        .def("Reserve",
             (void (NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::*)(  const size_t  ) ) &NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::Reserve,
             R"#(Reserve capacity for at least theN elements)#" ,py::arg("theN"))
        .def("Items",
             (typename NCollection_FlatDataMap<TheKeyType, TheItemType, Hasher>::ItemsView (NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::*)() ) &NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::Items,
             R"#(Returns a view for key-value pair iteration. Usage: for (auto [aKey, aValue] : aMap.Items()))#" )
        .def("Items",
             (typename NCollection_FlatDataMap<TheKeyType, TheItemType, Hasher>::ConstItemsView (NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::*)() const) &NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::Items,
             R"#(Returns a const view for key-value pair iteration. Usage: for (const auto& [aKey, aValue] : aMap.Items()))#" )
        .def("__call__",
             ( const TheItemType & (NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType &  ) const) &NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::operator(),
             py::is_operator(),
             R"#(Operator() for const access)#" ,py::arg("theKey"))
        .def("__call__",
             (TheItemType & (NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType &  ) ) &NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher>::operator(),
             py::is_operator(),
             R"#(Operator() for mutable access)#" ,py::arg("theKey"))
        .def("__iter__",[](const NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher> &self)
             { return py::make_iterator<py::return_value_policy::copy>(self.begin(), self.end()); },
             py::keep_alive<0, 1>())
        .def("__len__",[](const NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher> &self)
             { return self.Extent(); }
             )
        .def("__len__",[](const NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher> &self)
             { return self.Size(); }
             )
        .def("__bool__",[](const NCollection_FlatDataMap<TheKeyType,TheItemType,Hasher> &self)
             { return self.IsEmpty(); }
             )
    ;
};

template <typename ItemType>
void preregister_template_NCollection_OccAllocator(py::object &m, const char *name){
    py::class_<NCollection_OccAllocator<ItemType> , shared_ptr<NCollection_OccAllocator<ItemType>> >(m,name,R"#(Implements allocator requirements as defined in ISO C++ Standard 2003, section 20.1.5. The allocator uses a standard OCCT mechanism for memory allocation and deallocation. It can be used with standard containers (std::vector, std::map, etc.) to take advantage of OCCT memory optimizations.)#");
}

template <typename ItemType>
void register_template_NCollection_OccAllocator(py::object &m, const char *name){
    static_cast<py::class_<NCollection_OccAllocator<ItemType> , shared_ptr<NCollection_OccAllocator<ItemType>> >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const handle<NCollection_BaseAllocator> & >() ,py::arg("theAlloc") )
        .def(py::init<  const NCollection_OccAllocator<ItemType> & >() ,py::arg("theOther") )
        .def("SetAllocator",
             (void (NCollection_OccAllocator<ItemType>::*)(  const handle<NCollection_BaseAllocator> &  ) ) &NCollection_OccAllocator<ItemType>::SetAllocator,
             R"#()#" ,py::arg("theAlloc"))
        .def("Allocator",
             ( const handle<NCollection_BaseAllocator> & (NCollection_OccAllocator<ItemType>::*)() const) &NCollection_OccAllocator<ItemType>::Allocator,
             R"#()#" )
        .def("address",
             (typename NCollection_OccAllocator<ItemType>::const_pointer (NCollection_OccAllocator<ItemType>::*)( typename NCollection_OccAllocator<ItemType>::const_reference  ) const) &NCollection_OccAllocator<ItemType>::address,
             R"#(Returns an object address.)#" ,py::arg("theItem"))
        .def("max_size",
             (size_t (NCollection_OccAllocator<ItemType>::*)() const) &NCollection_OccAllocator<ItemType>::max_size,
             R"#(Estimate maximum array size)#" )
    ;
};

template <typename Element_t>
void preregister_template_NCollection_Mat3(py::object &m, const char *name){
    py::class_<NCollection_Mat3<Element_t> , shared_ptr<NCollection_Mat3<Element_t>> >(m,name,R"#(3x3 Matrix class. Warning, empty constructor returns an identity matrix.)#");
}

template <typename Element_t>
void register_template_NCollection_Mat3(py::object &m, const char *name){
    static_cast<py::class_<NCollection_Mat3<Element_t> , shared_ptr<NCollection_Mat3<Element_t>> >>(m.attr(name))
        .def(py::init<  >()  )
        .def("GetValue",
             (Element_t (NCollection_Mat3<Element_t>::*)(  const size_t ,   const size_t  ) const) &NCollection_Mat3<Element_t>::GetValue,
             R"#(Get element at the specified row and column.)#" ,py::arg("theRow"), py::arg("theCol"))
        .def("ChangeValue",
             (Element_t & (NCollection_Mat3<Element_t>::*)(  const size_t ,   const size_t  ) ) &NCollection_Mat3<Element_t>::ChangeValue,
             R"#(Access element at the specified row and column.)#" ,py::arg("theRow"), py::arg("theCol"))
        .def("SetValue",
             (void (NCollection_Mat3<Element_t>::*)(  const size_t ,   const size_t ,   const Element_t  ) ) &NCollection_Mat3<Element_t>::SetValue,
             R"#(Set value for the element specified by row and columns.)#" ,py::arg("theRow"), py::arg("theCol"), py::arg("theValue"))
        .def("GetRow",
             (NCollection_Vec3<Element_t> (NCollection_Mat3<Element_t>::*)(  const size_t  ) const) &NCollection_Mat3<Element_t>::GetRow,
             R"#(Return the row.)#" ,py::arg("theRow"))
        .def("SetRow",
             (void (NCollection_Mat3<Element_t>::*)(  const size_t ,   const NCollection_Vec3<Element_t> &  ) ) &NCollection_Mat3<Element_t>::SetRow,
             R"#(Change first 3 row values by the passed vector.)#" ,py::arg("theRow"), py::arg("theVec"))
        .def("GetColumn",
             (NCollection_Vec3<Element_t> (NCollection_Mat3<Element_t>::*)(  const size_t  ) const) &NCollection_Mat3<Element_t>::GetColumn,
             R"#(Return the column.)#" ,py::arg("theCol"))
        .def("SetColumn",
             (void (NCollection_Mat3<Element_t>::*)(  const size_t ,   const NCollection_Vec3<Element_t> &  ) ) &NCollection_Mat3<Element_t>::SetColumn,
             R"#(Change first 3 column values by the passed vector.)#" ,py::arg("theCol"), py::arg("theVec"))
        .def("GetDiagonal",
             (NCollection_Vec3<Element_t> (NCollection_Mat3<Element_t>::*)() const) &NCollection_Mat3<Element_t>::GetDiagonal,
             R"#(Get vector of diagonal elements.)#" )
        .def("SetDiagonal",
             (void (NCollection_Mat3<Element_t>::*)(  const NCollection_Vec3<Element_t> &  ) ) &NCollection_Mat3<Element_t>::SetDiagonal,
             R"#(Change first 3 elements of the diagonal matrix.)#" ,py::arg("theVec"))
        .def("InitZero",
             (void (NCollection_Mat3<Element_t>::*)() ) &NCollection_Mat3<Element_t>::InitZero,
             R"#(Initialize the zero matrix.)#" )
        .def("IsZero",
             (bool (NCollection_Mat3<Element_t>::*)() const) &NCollection_Mat3<Element_t>::IsZero,
             R"#(Checks the matrix for zero (without tolerance).)#" )
        .def("InitIdentity",
             (void (NCollection_Mat3<Element_t>::*)() ) &NCollection_Mat3<Element_t>::InitIdentity,
             R"#(Initialize the identity matrix.)#" )
        .def("IsIdentity",
             (bool (NCollection_Mat3<Element_t>::*)() const) &NCollection_Mat3<Element_t>::IsIdentity,
             R"#(Checks the matrix for identity (without tolerance).)#" )
        .def("IsEqual",
             (bool (NCollection_Mat3<Element_t>::*)(  const NCollection_Mat3<Element_t> &  ) const) &NCollection_Mat3<Element_t>::IsEqual,
             R"#(Check this matrix for equality with another matrix (without tolerance!).)#" ,py::arg("theOther"))
        .def("GetData",
             ( const Element_t * (NCollection_Mat3<Element_t>::*)() const) &NCollection_Mat3<Element_t>::GetData,
             R"#(Raw access to the data (for OpenGL exchange). the data is returned in column-major order.)#" )
        .def("ChangeData",
             (Element_t * (NCollection_Mat3<Element_t>::*)() ) &NCollection_Mat3<Element_t>::ChangeData,
             R"#()#" )
        .def("Multiply",
             (void (NCollection_Mat3<Element_t>::*)(  const NCollection_Mat3<Element_t> &  ) ) &NCollection_Mat3<Element_t>::Multiply,
             R"#(Compute matrix multiplication.)#" ,py::arg("theMat"))
        .def("Multiplied",
             (NCollection_Mat3<Element_t> (NCollection_Mat3<Element_t>::*)(  const NCollection_Mat3<Element_t> &  ) const) &NCollection_Mat3<Element_t>::Multiplied,
             R"#(Compute matrix multiplication product.)#" ,py::arg("theMat"))
        .def("Multiply",
             (void (NCollection_Mat3<Element_t>::*)(  const Element_t  ) ) &NCollection_Mat3<Element_t>::Multiply,
             R"#(Compute per-component multiplication.)#" ,py::arg("theFactor"))
        .def("Multiplied",
             (NCollection_Mat3<Element_t> (NCollection_Mat3<Element_t>::*)(  const Element_t  ) const) &NCollection_Mat3<Element_t>::Multiplied,
             R"#(Compute per-element multiplication.)#" ,py::arg("theFactor"))
        .def("Divide",
             (void (NCollection_Mat3<Element_t>::*)(  const Element_t  ) ) &NCollection_Mat3<Element_t>::Divide,
             R"#(Compute per-component division.)#" ,py::arg("theFactor"))
        .def("Divided",
             (NCollection_Mat3<Element_t> (NCollection_Mat3<Element_t>::*)(  const Element_t  ) const) &NCollection_Mat3<Element_t>::Divided,
             R"#(Divides all the coefficients of the matrix by scalar.)#" ,py::arg("theScalar"))
        .def("Add",
             (void (NCollection_Mat3<Element_t>::*)(  const NCollection_Mat3<Element_t> &  ) ) &NCollection_Mat3<Element_t>::Add,
             R"#(Per-component addition of another matrix.)#" ,py::arg("theMat"))
        .def("Subtract",
             (void (NCollection_Mat3<Element_t>::*)(  const NCollection_Mat3<Element_t> &  ) ) &NCollection_Mat3<Element_t>::Subtract,
             R"#(Per-component subtraction of another matrix.)#" ,py::arg("theMat"))
        .def("Added",
             (NCollection_Mat3<Element_t> (NCollection_Mat3<Element_t>::*)(  const NCollection_Mat3<Element_t> &  ) const) &NCollection_Mat3<Element_t>::Added,
             R"#(Per-component addition of another matrix.)#" ,py::arg("theMat"))
        .def("Subtracted",
             (NCollection_Mat3<Element_t> (NCollection_Mat3<Element_t>::*)(  const NCollection_Mat3<Element_t> &  ) const) &NCollection_Mat3<Element_t>::Subtracted,
             R"#(Per-component subtraction of another matrix.)#" ,py::arg("theMat"))
        .def("Negated",
             (NCollection_Mat3<Element_t> (NCollection_Mat3<Element_t>::*)() const) &NCollection_Mat3<Element_t>::Negated,
             R"#(Returns matrix with all components negated.)#" )
        .def("Transposed",
             (NCollection_Mat3<Element_t> (NCollection_Mat3<Element_t>::*)() const) &NCollection_Mat3<Element_t>::Transposed,
             R"#(Transpose the matrix.)#" )
        .def("Transpose",
             (void (NCollection_Mat3<Element_t>::*)() ) &NCollection_Mat3<Element_t>::Transpose,
             R"#(Transpose the matrix.)#" )
        .def("Determinant",
             (Element_t (NCollection_Mat3<Element_t>::*)() const) &NCollection_Mat3<Element_t>::Determinant,
             R"#(Return determinant of the matrix.)#" )
        .def("Adjoint",
             (NCollection_Mat3<Element_t> (NCollection_Mat3<Element_t>::*)() const) &NCollection_Mat3<Element_t>::Adjoint,
             R"#(Return adjoint (adjugate matrix, e.g. conjugate transpose).)#" )
        .def("Inverted",
             (bool (NCollection_Mat3<Element_t>::*)( NCollection_Mat3<Element_t> & ,  Element_t &  ) const) &NCollection_Mat3<Element_t>::Inverted,
             R"#(Compute inverted matrix.)#" ,py::arg("theInv"), py::arg("theDet"))
        .def("Inverted",
             (bool (NCollection_Mat3<Element_t>::*)( NCollection_Mat3<Element_t> &  ) const) &NCollection_Mat3<Element_t>::Inverted,
             R"#(Compute inverted matrix.)#" ,py::arg("theInv"))
        .def("Inverted",
             (NCollection_Mat3<Element_t> (NCollection_Mat3<Element_t>::*)() const) &NCollection_Mat3<Element_t>::Inverted,
             R"#(Return inverted matrix.)#" )
        .def("DumpJson",
             (void (NCollection_Mat3<Element_t>::*)( Standard_OStream & ,  int  ) const) &NCollection_Mat3<Element_t>::DumpJson,
             R"#(Dumps the content of me into the stream)#" ,py::arg("theOStream"), py::arg("arg1"))
        .def_static("Identity_s",
                    (NCollection_Mat3<Element_t> (*)() ) &NCollection_Mat3<Element_t>::Identity,
                    R"#(Return identity matrix.)#" )
        .def_static("Zero_s",
                    (NCollection_Mat3<Element_t> (*)() ) &NCollection_Mat3<Element_t>::Zero,
                    R"#(Return zero matrix.)#" )
        .def_static("Multiply_s",
                    (NCollection_Mat3<Element_t> (*)(  const NCollection_Mat3<Element_t> & ,   const NCollection_Mat3<Element_t> &  ) ) &NCollection_Mat3<Element_t>::Multiply,
                    R"#(Compute matrix multiplication product: A * B.)#" ,py::arg("theMatA"), py::arg("theMatB"))
        .def_static("Map_s",
                    (NCollection_Mat3<Element_t> & (*)( Element_t *  ) ) &NCollection_Mat3<Element_t>::Map,
                    R"#(Maps plain C array to matrix type.)#" ,py::arg("theData"))
        .def_static("Map_s",
                    ( const NCollection_Mat3<Element_t> & (*)(  const Element_t *  ) ) &NCollection_Mat3<Element_t>::Map,
                    R"#(Maps plain C array to matrix type.)#" ,py::arg("theData"))
        .def("__mul__",
             (NCollection_Vec3<Element_t> (NCollection_Mat3<Element_t>::*)(  const NCollection_Vec3<Element_t> &  ) const) &NCollection_Mat3<Element_t>::operator*,
             py::is_operator(),
             R"#(Multiply by the vector (M * V).)#" ,py::arg("theVec"))
        .def("__rmul__",
             (NCollection_Vec3<Element_t> (NCollection_Mat3<Element_t>::*)(  const NCollection_Vec3<Element_t> &  ) const) &NCollection_Mat3<Element_t>::operator*,
             py::is_operator(),
             R"#(Multiply by the vector (M * V).)#" ,py::arg("theVec"))
        .def("__imul__",
             (NCollection_Mat3<Element_t> & (NCollection_Mat3<Element_t>::*)(  const NCollection_Mat3<Element_t> &  ) ) &NCollection_Mat3<Element_t>::operator*=,
             py::is_operator(),
             R"#(Multiply by the another matrix.)#" ,py::arg("theMat"))
        .def("__mul__",
             (NCollection_Mat3<Element_t> (NCollection_Mat3<Element_t>::*)(  const NCollection_Mat3<Element_t> &  ) const) &NCollection_Mat3<Element_t>::operator*,
             py::is_operator(),
             R"#(Compute matrix multiplication product.)#" ,py::arg("theMat"))
        .def("__rmul__",
             (NCollection_Mat3<Element_t> (NCollection_Mat3<Element_t>::*)(  const NCollection_Mat3<Element_t> &  ) const) &NCollection_Mat3<Element_t>::operator*,
             py::is_operator(),
             R"#(Compute matrix multiplication product.)#" ,py::arg("theMat"))
        .def("__imul__",
             (NCollection_Mat3<Element_t> & (NCollection_Mat3<Element_t>::*)(  const Element_t  ) ) &NCollection_Mat3<Element_t>::operator*=,
             py::is_operator(),
             R"#(Compute per-element multiplication.)#" ,py::arg("theFactor"))
        .def("__mul__",
             (NCollection_Mat3<Element_t> (NCollection_Mat3<Element_t>::*)(  const Element_t  ) const) &NCollection_Mat3<Element_t>::operator*,
             py::is_operator(),
             R"#(Compute per-element multiplication.)#" ,py::arg("theFactor"))
        .def("__rmul__",
             (NCollection_Mat3<Element_t> (NCollection_Mat3<Element_t>::*)(  const Element_t  ) const) &NCollection_Mat3<Element_t>::operator*,
             py::is_operator(),
             R"#(Compute per-element multiplication.)#" ,py::arg("theFactor"))
        .def("__itruediv__",
             (NCollection_Mat3<Element_t> & (NCollection_Mat3<Element_t>::*)(  const Element_t  ) ) &NCollection_Mat3<Element_t>::operator/=,
             py::is_operator(),
             R"#(Per-component division.)#" ,py::arg("theScalar"))
        .def("__truediv__",
             (NCollection_Mat3<Element_t> (NCollection_Mat3<Element_t>::*)(  const Element_t  ) const) &NCollection_Mat3<Element_t>::operator/,
             py::is_operator(),
             R"#(Divides all the coefficients of the matrix by scalar.)#" ,py::arg("theScalar"))
        .def("__iadd__",
             (NCollection_Mat3<Element_t> & (NCollection_Mat3<Element_t>::*)(  const NCollection_Mat3<Element_t> &  ) ) &NCollection_Mat3<Element_t>::operator+=,
             py::is_operator(),
             R"#(Per-component addition of another matrix.)#" ,py::arg("theMat"))
        .def("__isub__",
             (NCollection_Mat3<Element_t> & (NCollection_Mat3<Element_t>::*)(  const NCollection_Mat3<Element_t> &  ) ) &NCollection_Mat3<Element_t>::operator-=,
             py::is_operator(),
             R"#(Per-component subtraction of another matrix.)#" ,py::arg("theMat"))
        .def("__add__",
             (NCollection_Mat3<Element_t> (NCollection_Mat3<Element_t>::*)(  const NCollection_Mat3<Element_t> &  ) const) &NCollection_Mat3<Element_t>::operator+,
             py::is_operator(),
             R"#(Per-component addition of another matrix.)#" ,py::arg("theMat"))
        .def("__sub__",
             (NCollection_Mat3<Element_t> (NCollection_Mat3<Element_t>::*)(  const NCollection_Mat3<Element_t> &  ) const) &NCollection_Mat3<Element_t>::operator-,
             py::is_operator(),
             R"#(Per-component subtraction of another matrix.)#" ,py::arg("theMat"))
        .def("__neg__",
             (NCollection_Mat3<Element_t> (NCollection_Mat3<Element_t>::*)() const) &NCollection_Mat3<Element_t>::operator-,
             py::is_operator(),
             R"#(Returns matrix with all components negated.)#" )
    ;
};

template <typename TheKeyType,typename TheItemType,typename Hasher=NCollection_DefaultHasher<TheKeyType>>
void preregister_template_NCollection_DataMap(py::object &m, const char *name){
    py::class_<NCollection_DataMap<TheKeyType,TheItemType,Hasher> , shared_ptr<NCollection_DataMap<TheKeyType,TheItemType,Hasher>> , NCollection_BaseMap >(m,name,R"#(Purpose: The DataMap is a Map to store keys with associated Items. See Map from NCollection for a discussion about the number of buckets.)#");
}

template <typename TheKeyType,typename TheItemType,typename Hasher=NCollection_DefaultHasher<TheKeyType>>
void register_template_NCollection_DataMap(py::object &m, const char *name){
    static_cast<py::class_<NCollection_DataMap<TheKeyType,TheItemType,Hasher> , shared_ptr<NCollection_DataMap<TheKeyType,TheItemType,Hasher>> , NCollection_BaseMap >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const size_t, const handle<NCollection_BaseAllocator> & >() ,py::arg("theNbBuckets"), py::arg("theAllocator")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr) )
        .def(py::init<  const int, const handle<NCollection_BaseAllocator> & >() ,py::arg("theNbBuckets"), py::arg("theAllocator")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr) )
        .def(py::init<  const Hasher &, const size_t, const handle<NCollection_BaseAllocator> & >() ,py::arg("theHasher"), py::arg("theNbBuckets")=static_cast< const size_t>(1), py::arg("theAllocator")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr) )
        .def(py::init<  const Hasher &, const int, const handle<NCollection_BaseAllocator> & >() ,py::arg("theHasher"), py::arg("theNbBuckets"), py::arg("theAllocator")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr) )
        .def(py::init<  const NCollection_DataMap<TheKeyType, TheItemType, Hasher> & >() ,py::arg("theOther") )
        .def("Items",
             (typename NCollection_DataMap<TheKeyType, TheItemType, Hasher>::ItemsView (NCollection_DataMap<TheKeyType,TheItemType,Hasher>::*)() ) &NCollection_DataMap<TheKeyType,TheItemType,Hasher>::Items,
             R"#(Returns a view for key-value pair iteration. Usage: for (auto [aKey, aValue] : aMap.Items()))#" )
        .def("Items",
             (typename NCollection_DataMap<TheKeyType, TheItemType, Hasher>::ConstItemsView (NCollection_DataMap<TheKeyType,TheItemType,Hasher>::*)() const) &NCollection_DataMap<TheKeyType,TheItemType,Hasher>::Items,
             R"#(Returns a const view for key-value pair iteration. Usage: for (const auto& [aKey, aValue] : aMap.Items()))#" )
        .def("Exchange",
             (void (NCollection_DataMap<TheKeyType,TheItemType,Hasher>::*)( NCollection_DataMap<TheKeyType, TheItemType, Hasher> &  ) ) &NCollection_DataMap<TheKeyType,TheItemType,Hasher>::Exchange,
             R"#(Exchange the content of two maps without re-allocations. Notice that allocators will be swapped as well!)#" ,py::arg("theOther"))
        .def("GetHasher",
             ( const Hasher & (NCollection_DataMap<TheKeyType,TheItemType,Hasher>::*)() const) &NCollection_DataMap<TheKeyType,TheItemType,Hasher>::GetHasher,
             R"#(Returns const reference to the hasher.)#" )
        .def("Assign",
             (NCollection_DataMap<TheKeyType, TheItemType, Hasher> & (NCollection_DataMap<TheKeyType,TheItemType,Hasher>::*)(  const NCollection_DataMap<TheKeyType, TheItemType, Hasher> &  ) ) &NCollection_DataMap<TheKeyType,TheItemType,Hasher>::Assign,
             R"#(Assignment. This method does not change the internal allocator.)#" ,py::arg("theOther"))
        .def("ReSize",
             (void (NCollection_DataMap<TheKeyType,TheItemType,Hasher>::*)(  const size_t  ) ) &NCollection_DataMap<TheKeyType,TheItemType,Hasher>::ReSize,
             R"#(ReSize)#" ,py::arg("N"))
        .def("ReSize",
             (void (NCollection_DataMap<TheKeyType,TheItemType,Hasher>::*)(  const int  ) ) &NCollection_DataMap<TheKeyType,TheItemType,Hasher>::ReSize,
             R"#()#" ,py::arg("N"))
        .def("Bind",
             (bool (NCollection_DataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType & ,   const TheItemType &  ) ) &NCollection_DataMap<TheKeyType,TheItemType,Hasher>::Bind,
             R"#(Bind binds Item to Key in map.)#" ,py::arg("theKey"), py::arg("theItem"))
        .def("TryBind",
             (bool (NCollection_DataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType & ,   const TheItemType &  ) ) &NCollection_DataMap<TheKeyType,TheItemType,Hasher>::TryBind,
             R"#(TryBind binds Item to Key in map only if Key is not yet bound.)#" ,py::arg("theKey"), py::arg("theItem"))
        .def("TryBound",
             (TheItemType & (NCollection_DataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType & ,   const TheItemType &  ) ) &NCollection_DataMap<TheKeyType,TheItemType,Hasher>::TryBound,
             R"#(TryBound binds Item to Key in map only if Key is not yet bound.)#" ,py::arg("theKey"), py::arg("theItem"))
        .def("IsBound",
             (bool (NCollection_DataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType &  ) const) &NCollection_DataMap<TheKeyType,TheItemType,Hasher>::IsBound,
             R"#(IsBound)#" ,py::arg("theKey"))
        .def("UnBind",
             (bool (NCollection_DataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType &  ) ) &NCollection_DataMap<TheKeyType,TheItemType,Hasher>::UnBind,
             R"#(UnBind removes Item Key pair from map)#" ,py::arg("theKey"))
        .def("Find",
             ( const TheItemType & (NCollection_DataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType &  ) const) &NCollection_DataMap<TheKeyType,TheItemType,Hasher>::Find,
             R"#(Find returns the Item for Key. Raises if Key was not bound)#" ,py::arg("theKey"))
        .def("Find",
             (bool (NCollection_DataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType & ,  TheItemType &  ) const) &NCollection_DataMap<TheKeyType,TheItemType,Hasher>::Find,
             R"#(Find Item for key with copying.)#" ,py::arg("theKey"), py::arg("theValue"))
        .def("ChangeFind",
             (TheItemType & (NCollection_DataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType &  ) ) &NCollection_DataMap<TheKeyType,TheItemType,Hasher>::ChangeFind,
             R"#(ChangeFind returns modifiable Item by Key. Raises if Key was not bound)#" ,py::arg("theKey"))
        .def("Clear",
             (void (NCollection_DataMap<TheKeyType,TheItemType,Hasher>::*)(  const bool  ) ) &NCollection_DataMap<TheKeyType,TheItemType,Hasher>::Clear,
             R"#(Clear data. If doReleaseMemory is false then the table of buckets is not released and will be reused.)#" ,py::arg("doReleaseMemory")=static_cast< const bool>(false))
        .def("Clear",
             (void (NCollection_DataMap<TheKeyType,TheItemType,Hasher>::*)(  const handle<NCollection_BaseAllocator> &  ) ) &NCollection_DataMap<TheKeyType,TheItemType,Hasher>::Clear,
             R"#(Clear data and reset allocator)#" ,py::arg("theAllocator"))
        .def("__call__",
             ( const TheItemType & (NCollection_DataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType &  ) const) &NCollection_DataMap<TheKeyType,TheItemType,Hasher>::operator(),
             py::is_operator(),
             R"#(operator ())#" ,py::arg("theKey"))
        .def("__call__",
             (TheItemType & (NCollection_DataMap<TheKeyType,TheItemType,Hasher>::*)(  const TheKeyType &  ) ) &NCollection_DataMap<TheKeyType,TheItemType,Hasher>::operator(),
             py::is_operator(),
             R"#(operator ())#" ,py::arg("theKey"))
        .def("__iter__",[](const NCollection_DataMap<TheKeyType,TheItemType,Hasher> &self)
             { return py::make_iterator<py::return_value_policy::copy>(self.begin(), self.end()); },
             py::keep_alive<0, 1>())
        .def("__len__",[](const NCollection_DataMap<TheKeyType,TheItemType,Hasher> &self)
             { return self.Extent(); }
             )
        .def("__len__",[](const NCollection_DataMap<TheKeyType,TheItemType,Hasher> &self)
             { return self.Size(); }
             )
        .def("__bool__",[](const NCollection_DataMap<TheKeyType,TheItemType,Hasher> &self)
             { return self.IsEmpty(); }
             )
    ;
};

template <typename TheItemType>
void preregister_template_NCollection_HArray1(py::object &m, const char *name){
    py::class_<NCollection_HArray1<TheItemType> , opencascade::handle<NCollection_HArray1<TheItemType>> , NCollection_Array1<TheItemType> , Standard_Transient >(m,name,R"#(Template class for Handle-managed 1D arrays. Inherits from both NCollection_Array1<TheItemType> and Standard_Transient, providing reference-counted array functionality.)#");
}

template <typename TheItemType>
void register_template_NCollection_HArray1(py::object &m, const char *name){
    static_cast<py::class_<NCollection_HArray1<TheItemType> , opencascade::handle<NCollection_HArray1<TheItemType>> , NCollection_Array1<TheItemType> , Standard_Transient >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const int, const int >() ,py::arg("theLower"), py::arg("theUpper") )
        .def(py::init<  const int, const int, const TheItemType & >() ,py::arg("theLower"), py::arg("theUpper"), py::arg("theValue") )
        .def(py::init<  const TheItemType &, const int, const int, const bool >() ,py::arg("theBegin"), py::arg("theLower"), py::arg("theUpper"), py::arg("theUseBuffer") )
        .def(py::init<  const typename NCollection_HArray1<TheItemType>::Array1Type & >() ,py::arg("theOther") )
        .def("Array1",
             ( const typename NCollection_HArray1<TheItemType>::Array1Type & (NCollection_HArray1<TheItemType>::*)() const) &NCollection_HArray1<TheItemType>::Array1,
             R"#(Returns const reference to the underlying array.)#" )
        .def("ChangeArray1",
             (typename NCollection_HArray1<TheItemType>::Array1Type & (NCollection_HArray1<TheItemType>::*)() ) &NCollection_HArray1<TheItemType>::ChangeArray1,
             R"#(Returns mutable reference to the underlying array.)#" )
        .def("DynamicType",
             ( const handle<Standard_Type> & (NCollection_HArray1<TheItemType>::*)() const) &NCollection_HArray1<TheItemType>::DynamicType,
             R"#()#" )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) &NCollection_HArray1<TheItemType>::get_type_name,
                    R"#()#" )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) &NCollection_HArray1<TheItemType>::get_type_descriptor,
                    R"#()#" )
    ;
};

template <typename T>
void preregister_template_NCollection_Handle(py::object &m, const char *name){
    py::class_<NCollection_Handle<T> , shared_ptr<NCollection_Handle<T>> >(m,name,R"#(Purpose: This template class is used to define Handle adaptor for allocated dynamically objects of arbitrary type.)#");
}

template <typename T>
void register_template_NCollection_Handle(py::object &m, const char *name){
    static_cast<py::class_<NCollection_Handle<T> , shared_ptr<NCollection_Handle<T>> >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init< T * >() ,py::arg("theObject") )
        .def("get",
             (T * (NCollection_Handle<T>::*)() ) &NCollection_Handle<T>::get,
             R"#(Cast handle to contained type)#" )
        .def("get",
             ( const T * (NCollection_Handle<T>::*)() const) &NCollection_Handle<T>::get,
             R"#(Cast handle to contained type)#" )
        .def_static("DownCast_s",
                    (NCollection_Handle<T> (*)(  const handle<Standard_Transient> &  ) ) &NCollection_Handle<T>::DownCast,
                    R"#(Downcast arbitrary Handle to the argument type if contained object is Handle for this type; returns null otherwise)#" ,py::arg("theOther"))
    ;
};

template <typename TheKeyType,typename Hasher=NCollection_DefaultHasher<TheKeyType>>
void preregister_template_NCollection_Map(py::object &m, const char *name){
    py::class_<NCollection_Map<TheKeyType,Hasher> , shared_ptr<NCollection_Map<TheKeyType,Hasher>> , NCollection_BaseMap >(m,name,R"#(Purpose: Single hashed Map. This Map is used to store and retrieve keys in linear time.)#");
}

template <typename TheKeyType,typename Hasher=NCollection_DefaultHasher<TheKeyType>>
void register_template_NCollection_Map(py::object &m, const char *name){
    static_cast<py::class_<NCollection_Map<TheKeyType,Hasher> , shared_ptr<NCollection_Map<TheKeyType,Hasher>> , NCollection_BaseMap >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const size_t, const handle<NCollection_BaseAllocator> & >() ,py::arg("theNbBuckets"), py::arg("theAllocator")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr) )
        .def(py::init<  const int, const handle<NCollection_BaseAllocator> & >() ,py::arg("theNbBuckets"), py::arg("theAllocator")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr) )
        .def(py::init<  const Hasher &, const size_t, const handle<NCollection_BaseAllocator> & >() ,py::arg("theHasher"), py::arg("theNbBuckets")=static_cast< const size_t>(1), py::arg("theAllocator")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr) )
        .def(py::init<  const Hasher &, const int, const handle<NCollection_BaseAllocator> & >() ,py::arg("theHasher"), py::arg("theNbBuckets"), py::arg("theAllocator")=static_cast< const handle<NCollection_BaseAllocator> &>(nullptr) )
        .def(py::init<  const NCollection_Map<TheKeyType, Hasher> & >() ,py::arg("theOther") )
        .def("Exchange",
             (void (NCollection_Map<TheKeyType,Hasher>::*)( NCollection_Map<TheKeyType, Hasher> &  ) ) &NCollection_Map<TheKeyType,Hasher>::Exchange,
             R"#(Exchange the content of two maps without re-allocations. Notice that allocators will be swapped as well!)#" ,py::arg("theOther"))
        .def("GetHasher",
             ( const Hasher & (NCollection_Map<TheKeyType,Hasher>::*)() const) &NCollection_Map<TheKeyType,Hasher>::GetHasher,
             R"#(Returns const reference to the hasher.)#" )
        .def("Assign",
             (NCollection_Map<TheKeyType, Hasher> & (NCollection_Map<TheKeyType,Hasher>::*)(  const NCollection_Map<TheKeyType, Hasher> &  ) ) &NCollection_Map<TheKeyType,Hasher>::Assign,
             R"#(Assign. This method does not change the internal allocator.)#" ,py::arg("theOther"))
        .def("ReSize",
             (void (NCollection_Map<TheKeyType,Hasher>::*)(  const size_t  ) ) &NCollection_Map<TheKeyType,Hasher>::ReSize,
             R"#(ReSize)#" ,py::arg("N"))
        .def("ReSize",
             (void (NCollection_Map<TheKeyType,Hasher>::*)(  const int  ) ) &NCollection_Map<TheKeyType,Hasher>::ReSize,
             R"#()#" ,py::arg("N"))
        .def("Add",
             (bool (NCollection_Map<TheKeyType,Hasher>::*)(  const TheKeyType &  ) ) &NCollection_Map<TheKeyType,Hasher>::Add,
             R"#(Add)#" ,py::arg("theKey"))
        .def("Added",
             ( const TheKeyType & (NCollection_Map<TheKeyType,Hasher>::*)(  const TheKeyType &  ) ) &NCollection_Map<TheKeyType,Hasher>::Added,
             R"#(Added: add a new key if not yet in the map, and return reference to either newly added or previously existing object)#" ,py::arg("theKey"))
        .def("Contains",
             (bool (NCollection_Map<TheKeyType,Hasher>::*)(  const TheKeyType &  ) const) &NCollection_Map<TheKeyType,Hasher>::Contains,
             R"#(Contains)#" ,py::arg("theKey"))
        .def("Remove",
             (bool (NCollection_Map<TheKeyType,Hasher>::*)(  const TheKeyType &  ) ) &NCollection_Map<TheKeyType,Hasher>::Remove,
             R"#(Remove)#" ,py::arg("K"))
        .def("Clear",
             (void (NCollection_Map<TheKeyType,Hasher>::*)(  const bool  ) ) &NCollection_Map<TheKeyType,Hasher>::Clear,
             R"#(Clear data. If doReleaseMemory is false then the table of buckets is not released and will be reused.)#" ,py::arg("doReleaseMemory")=static_cast< const bool>(false))
        .def("Clear",
             (void (NCollection_Map<TheKeyType,Hasher>::*)(  const handle<NCollection_BaseAllocator> &  ) ) &NCollection_Map<TheKeyType,Hasher>::Clear,
             R"#(Clear data and reset allocator)#" ,py::arg("theAllocator"))
        .def("IsEqual",
             (bool (NCollection_Map<TheKeyType,Hasher>::*)(  const NCollection_Map<TheKeyType, Hasher> &  ) const) &NCollection_Map<TheKeyType,Hasher>::IsEqual,
             R"#(Checks if two maps contain exactly the same keys. This function compares the keys of this map and another map and returns true if they contain exactly the same keys.)#" ,py::arg("theOther"))
        .def("Contains",
             (bool (NCollection_Map<TheKeyType,Hasher>::*)(  const NCollection_Map<TheKeyType, Hasher> &  ) const) &NCollection_Map<TheKeyType,Hasher>::Contains,
             R"#(Checks if this map contains all keys of another map. This function checks if this map contains all keys of another map.)#" ,py::arg("theOther"))
        .def("Union",
             (void (NCollection_Map<TheKeyType,Hasher>::*)(  const NCollection_Map<TheKeyType, Hasher> & ,   const NCollection_Map<TheKeyType, Hasher> &  ) ) &NCollection_Map<TheKeyType,Hasher>::Union,
             R"#(Sets this Map to be the result of union (aka addition, fuse, merge, boolean OR) operation between two given Maps The new Map contains the values that are contained either in the first map or in the second map or in both. All previous content of this Map is cleared. This map (result of the boolean operation) can also be passed as one of operands.)#" ,py::arg("theLeft"), py::arg("theRight"))
        .def("Unite",
             (bool (NCollection_Map<TheKeyType,Hasher>::*)(  const NCollection_Map<TheKeyType, Hasher> &  ) ) &NCollection_Map<TheKeyType,Hasher>::Unite,
             R"#(Apply to this Map the boolean operation union (aka addition, fuse, merge, boolean OR) with another (given) Map. The result contains the values that were previously contained in this map or contained in the given (operand) map. This algorithm is similar to method Union(). Returns True if contents of this map is changed.)#" ,py::arg("theOther"))
        .def("HasIntersection",
             (bool (NCollection_Map<TheKeyType,Hasher>::*)(  const NCollection_Map<TheKeyType, Hasher> &  ) const) &NCollection_Map<TheKeyType,Hasher>::HasIntersection,
             R"#(Returns true if this and theMap have common elements.)#" ,py::arg("theMap"))
        .def("Intersection",
             (void (NCollection_Map<TheKeyType,Hasher>::*)(  const NCollection_Map<TheKeyType, Hasher> & ,   const NCollection_Map<TheKeyType, Hasher> &  ) ) &NCollection_Map<TheKeyType,Hasher>::Intersection,
             R"#(Sets this Map to be the result of intersection (aka multiplication, common, boolean AND) operation between two given Maps. The new Map contains only the values that are contained in both map operands. All previous content of this Map is cleared. This same map (result of the boolean operation) can also be used as one of operands.)#" ,py::arg("theLeft"), py::arg("theRight"))
        .def("Intersect",
             (bool (NCollection_Map<TheKeyType,Hasher>::*)(  const NCollection_Map<TheKeyType, Hasher> &  ) ) &NCollection_Map<TheKeyType,Hasher>::Intersect,
             R"#(Apply to this Map the intersection operation (aka multiplication, common, boolean AND) with another (given) Map. The result contains only the values that are contained in both this and the given maps. This algorithm is similar to method Intersection(). Returns True if contents of this map is changed.)#" ,py::arg("theOther"))
        .def("Subtraction",
             (void (NCollection_Map<TheKeyType,Hasher>::*)(  const NCollection_Map<TheKeyType, Hasher> & ,   const NCollection_Map<TheKeyType, Hasher> &  ) ) &NCollection_Map<TheKeyType,Hasher>::Subtraction,
             R"#(Sets this Map to be the result of subtraction (aka set-theoretic difference, relative complement, exclude, cut, boolean NOT) operation between two given Maps. The new Map contains only the values that are contained in the first map operands and not contained in the second one. All previous content of this Map is cleared.)#" ,py::arg("theLeft"), py::arg("theRight"))
        .def("Subtract",
             (bool (NCollection_Map<TheKeyType,Hasher>::*)(  const NCollection_Map<TheKeyType, Hasher> &  ) ) &NCollection_Map<TheKeyType,Hasher>::Subtract,
             R"#(Apply to this Map the subtraction (aka set-theoretic difference, relative complement, exclude, cut, boolean NOT) operation with another (given) Map. The result contains only the values that were previously contained in this map and not contained in this map. This algorithm is similar to method Subtract() with two operands. Returns True if contents of this map is changed.)#" ,py::arg("theOther"))
        .def("Difference",
             (void (NCollection_Map<TheKeyType,Hasher>::*)(  const NCollection_Map<TheKeyType, Hasher> & ,   const NCollection_Map<TheKeyType, Hasher> &  ) ) &NCollection_Map<TheKeyType,Hasher>::Difference,
             R"#(Sets this Map to be the result of symmetric difference (aka exclusive disjunction, boolean XOR) operation between two given Maps. The new Map contains the values that are contained only in the first or the second operand maps but not in both. All previous content of this Map is cleared. This map (result of the boolean operation) can also be used as one of operands.)#" ,py::arg("theLeft"), py::arg("theRight"))
        .def("Differ",
             (bool (NCollection_Map<TheKeyType,Hasher>::*)(  const NCollection_Map<TheKeyType, Hasher> &  ) ) &NCollection_Map<TheKeyType,Hasher>::Differ,
             R"#(Apply to this Map the symmetric difference (aka exclusive disjunction, boolean XOR) operation with another (given) Map. The result contains the values that are contained only in this or the operand map, but not in both. This algorithm is similar to method Difference(). Returns True if contents of this map is changed.)#" ,py::arg("theOther"))
        .def("__iter__",[](const NCollection_Map<TheKeyType,Hasher> &self)
             { return py::make_iterator<py::return_value_policy::copy>(self.begin(), self.end()); },
             py::keep_alive<0, 1>())
        .def("__len__",[](const NCollection_Map<TheKeyType,Hasher> &self)
             { return self.Extent(); }
             )
        .def("__len__",[](const NCollection_Map<TheKeyType,Hasher> &self)
             { return self.Size(); }
             )
        .def("__bool__",[](const NCollection_Map<TheKeyType,Hasher> &self)
             { return self.IsEmpty(); }
             )
    ;
};

template <typename IntType>
void preregister_template_NCollection_PackedMap(py::object &m, const char *name){
    py::class_<NCollection_PackedMap<IntType> , shared_ptr<NCollection_PackedMap<IntType>> >(m,name,R"#(Optimized Map for integer values of various integral types.)#");
}

template <typename IntType>
void register_template_NCollection_PackedMap(py::object &m, const char *name){
    static_cast<py::class_<NCollection_PackedMap<IntType> , shared_ptr<NCollection_PackedMap<IntType>> >>(m.attr(name))
        .def(py::init<  const size_t >() ,py::arg("theNbBuckets")=static_cast< const size_t>(1) )
        .def(py::init<  const int >() ,py::arg("theNbBuckets") )
        .def(py::init<  const NCollection_PackedMap<IntType> & >() ,py::arg("theOther") )
        .def("Assign",
             (NCollection_PackedMap<IntType> & (NCollection_PackedMap<IntType>::*)(  const NCollection_PackedMap<IntType> &  ) ) &NCollection_PackedMap<IntType>::Assign,
             R"#(Assignment operator)#" ,py::arg("theOther"))
        .def("ReSize",
             (void (NCollection_PackedMap<IntType>::*)(  const size_t  ) ) &NCollection_PackedMap<IntType>::ReSize,
             R"#(Resize the map)#" ,py::arg("theNbBuckets"))
        .def("ReSize",
             (void (NCollection_PackedMap<IntType>::*)(  const int  ) ) &NCollection_PackedMap<IntType>::ReSize,
             R"#(Resize the map (legacy int-taking).)#" ,py::arg("theNbBuckets"))
        .def("Clear",
             (void (NCollection_PackedMap<IntType>::*)() ) &NCollection_PackedMap<IntType>::Clear,
             R"#(Clear the map)#" )
        .def("Add",
             (bool (NCollection_PackedMap<IntType>::*)(  const IntType  ) ) &NCollection_PackedMap<IntType>::Add,
             R"#(Add a key to the map)#" ,py::arg("theKey"))
        .def("Contains",
             (bool (NCollection_PackedMap<IntType>::*)(  const IntType  ) const) &NCollection_PackedMap<IntType>::Contains,
             R"#(Check if the map contains a key)#" ,py::arg("theKey"))
        .def("Remove",
             (bool (NCollection_PackedMap<IntType>::*)(  const IntType  ) ) &NCollection_PackedMap<IntType>::Remove,
             R"#(Remove a key from the map)#" ,py::arg("theKey"))
        .def("NbBuckets",
             (size_t (NCollection_PackedMap<IntType>::*)() const) &NCollection_PackedMap<IntType>::NbBuckets,
             R"#(Returns the number of map buckets.)#" )
        .def("Extent",
             (int (NCollection_PackedMap<IntType>::*)() const) &NCollection_PackedMap<IntType>::Extent,
             R"#(Returns map extent (legacy int-returning API).)#" )
        .def("Length",
             (int (NCollection_PackedMap<IntType>::*)() const) &NCollection_PackedMap<IntType>::Length,
             R"#(Returns map extent (legacy int-returning API, synonym of Extent()).)#" )
        .def("Size",
             (size_t (NCollection_PackedMap<IntType>::*)() const) &NCollection_PackedMap<IntType>::Size,
             R"#(Returns map extent.)#" )
        .def("IsEmpty",
             (bool (NCollection_PackedMap<IntType>::*)() const) &NCollection_PackedMap<IntType>::IsEmpty,
             R"#(Returns TRUE if map is empty.)#" )
        .def("GetMinimalMapped",
             (IntType (NCollection_PackedMap<IntType>::*)() const) &NCollection_PackedMap<IntType>::GetMinimalMapped,
             R"#(Query the minimal contained key value.)#" )
        .def("GetMaximalMapped",
             (IntType (NCollection_PackedMap<IntType>::*)() const) &NCollection_PackedMap<IntType>::GetMaximalMapped,
             R"#(Query the maximal contained key value.)#" )
        .def("Union",
             (void (NCollection_PackedMap<IntType>::*)(  const NCollection_PackedMap<IntType> & ,   const NCollection_PackedMap<IntType> &  ) ) &NCollection_PackedMap<IntType>::Union,
             R"#()#" ,py::arg("theLeft"), py::arg("theRight"))
        .def("Unite",
             (bool (NCollection_PackedMap<IntType>::*)(  const NCollection_PackedMap<IntType> &  ) ) &NCollection_PackedMap<IntType>::Unite,
             R"#()#" ,py::arg("theOther"))
        .def("Intersection",
             (void (NCollection_PackedMap<IntType>::*)(  const NCollection_PackedMap<IntType> & ,   const NCollection_PackedMap<IntType> &  ) ) &NCollection_PackedMap<IntType>::Intersection,
             R"#()#" ,py::arg("theLeft"), py::arg("theRight"))
        .def("Intersect",
             (bool (NCollection_PackedMap<IntType>::*)(  const NCollection_PackedMap<IntType> &  ) ) &NCollection_PackedMap<IntType>::Intersect,
             R"#()#" ,py::arg("theOther"))
        .def("Subtraction",
             (void (NCollection_PackedMap<IntType>::*)(  const NCollection_PackedMap<IntType> & ,   const NCollection_PackedMap<IntType> &  ) ) &NCollection_PackedMap<IntType>::Subtraction,
             R"#()#" ,py::arg("theLeft"), py::arg("theRight"))
        .def("Subtract",
             (bool (NCollection_PackedMap<IntType>::*)(  const NCollection_PackedMap<IntType> &  ) ) &NCollection_PackedMap<IntType>::Subtract,
             R"#()#" ,py::arg("theOther"))
        .def("Difference",
             (void (NCollection_PackedMap<IntType>::*)(  const NCollection_PackedMap<IntType> & ,   const NCollection_PackedMap<IntType> &  ) ) &NCollection_PackedMap<IntType>::Difference,
             R"#()#" ,py::arg("theLeft"), py::arg("theRight"))
        .def("Differ",
             (bool (NCollection_PackedMap<IntType>::*)(  const NCollection_PackedMap<IntType> &  ) ) &NCollection_PackedMap<IntType>::Differ,
             R"#()#" ,py::arg("theOther"))
        .def("IsEqual",
             (bool (NCollection_PackedMap<IntType>::*)(  const NCollection_PackedMap<IntType> &  ) const) &NCollection_PackedMap<IntType>::IsEqual,
             R"#()#" ,py::arg("theOther"))
        .def("IsSubset",
             (bool (NCollection_PackedMap<IntType>::*)(  const NCollection_PackedMap<IntType> &  ) const) &NCollection_PackedMap<IntType>::IsSubset,
             R"#()#" ,py::arg("theOther"))
        .def("HasIntersection",
             (bool (NCollection_PackedMap<IntType>::*)(  const NCollection_PackedMap<IntType> &  ) const) &NCollection_PackedMap<IntType>::HasIntersection,
             R"#()#" ,py::arg("theOther"))
        .def("Contains",
             (bool (NCollection_PackedMap<IntType>::*)(  const NCollection_PackedMap<IntType> &  ) const) &NCollection_PackedMap<IntType>::Contains,
             R"#()#" ,py::arg("theOther"))
        .def("__len__",[](const NCollection_PackedMap<IntType> &self)
             { return self.Extent(); }
             )
        .def("__len__",[](const NCollection_PackedMap<IntType> &self)
             { return self.Size(); }
             )
        .def("__bool__",[](const NCollection_PackedMap<IntType> &self)
             { return self.IsEmpty(); }
             )
    ;
};

template <typename Type>
void preregister_template_NCollection_UtfIterator(py::object &m, const char *name){
    py::class_<NCollection_UtfIterator<Type> , shared_ptr<NCollection_UtfIterator<Type>> >(m,name,R"#(Template class for Unicode strings support.)#");
}

template <typename Type>
void register_template_NCollection_UtfIterator(py::object &m, const char *name){
    static_cast<py::class_<NCollection_UtfIterator<Type> , shared_ptr<NCollection_UtfIterator<Type>> >>(m.attr(name))
        .def(py::init<  const Type * >() ,py::arg("theString") )
        .def("Init",
             (void (NCollection_UtfIterator<Type>::*)(  const Type *  ) ) &NCollection_UtfIterator<Type>::Init,
             R"#(Initialize iterator within specified NULL-terminated string.)#" ,py::arg("theString"))
        .def("IsValid",
             (bool (NCollection_UtfIterator<Type>::*)() const) &NCollection_UtfIterator<Type>::IsValid,
             R"#(Return true if Unicode symbol is within valid range.)#" )
        .def("BufferHere",
             ( const Type * (NCollection_UtfIterator<Type>::*)() const) &NCollection_UtfIterator<Type>::BufferHere,
             R"#(Buffer-fetching getter.)#" )
        .def("ChangeBufferHere",
             (Type * (NCollection_UtfIterator<Type>::*)() ) &NCollection_UtfIterator<Type>::ChangeBufferHere,
             R"#(Buffer-fetching getter. Dangerous! Iterator should be reinitialized on buffer change.)#" )
        .def("BufferNext",
             ( const Type * (NCollection_UtfIterator<Type>::*)() const) &NCollection_UtfIterator<Type>::BufferNext,
             R"#(Buffer-fetching getter.)#" )
        .def("Index",
             (int (NCollection_UtfIterator<Type>::*)() const) &NCollection_UtfIterator<Type>::Index,
             R"#(Returns the index displacement from iterator initialization (first symbol has index 0))#" )
        .def("AdvanceBytesUtf8",
             (int (NCollection_UtfIterator<Type>::*)() const) &NCollection_UtfIterator<Type>::AdvanceBytesUtf8,
             R"#(Returns the advance in bytes to store current symbol in UTF-8. 0 means an invalid symbol; 1-4 bytes are valid range.)#" )
        .def("AdvanceBytesUtf16",
             (int (NCollection_UtfIterator<Type>::*)() const) &NCollection_UtfIterator<Type>::AdvanceBytesUtf16,
             R"#(Returns the advance in bytes to store current symbol in UTF-16. 0 means an invalid symbol; 2 bytes is a general case; 4 bytes for surrogate pair.)#" )
        .def("AdvanceCodeUnitsUtf16",
             (int (NCollection_UtfIterator<Type>::*)() const) &NCollection_UtfIterator<Type>::AdvanceCodeUnitsUtf16,
             R"#(Returns the advance in bytes to store current symbol in UTF-16. 0 means an invalid symbol; 1 16-bit code unit is a general case; 2 16-bit code units for surrogate pair.)#" )
        .def("AdvanceBytesUtf32",
             (int (NCollection_UtfIterator<Type>::*)() const) &NCollection_UtfIterator<Type>::AdvanceBytesUtf32,
             R"#(Returns the advance in bytes to store current symbol in UTF-32. Always 4 bytes (method for consistency).)#" )
        .def("GetUtf8",
             (char * (NCollection_UtfIterator<Type>::*)( char *  ) const) &NCollection_UtfIterator<Type>::GetUtf8,
             R"#(Fill the UTF-8 buffer within current Unicode symbol. Use method AdvanceUtf8() to allocate buffer with enough size.)#" ,py::arg("theBuffer"))
        .def("GetUtf8",
             (unsigned char * (NCollection_UtfIterator<Type>::*)( unsigned char *  ) const) &NCollection_UtfIterator<Type>::GetUtf8,
             R"#()#" ,py::arg("theBuffer"))
        .def("GetUtf16",
             (char16_t * (NCollection_UtfIterator<Type>::*)( char16_t *  ) const) &NCollection_UtfIterator<Type>::GetUtf16,
             R"#(Fill the UTF-16 buffer within current Unicode symbol. Use method AdvanceUtf16() to allocate buffer with enough size.)#" ,py::arg("theBuffer"))
        .def("GetUtf32",
             (char32_t * (NCollection_UtfIterator<Type>::*)( char32_t *  ) const) &NCollection_UtfIterator<Type>::GetUtf32,
             R"#(Fill the UTF-32 buffer within current Unicode symbol. Use method AdvanceUtf32() to allocate buffer with enough size.)#" ,py::arg("theBuffer"))
    ;
};

template <typename TheItemType>
void preregister_template_NCollection_Array2(py::object &m, const char *name){
    py::class_<NCollection_Array2<TheItemType> , shared_ptr<NCollection_Array2<TheItemType>> , NCollection_Array1<TheItemType> >(m,name,R"#(Purpose: The class Array2 represents bi-dimensional arrays of fixed size known at run time. The ranges of indices are user defined.)#");
}

template <typename TheItemType>
void register_template_NCollection_Array2(py::object &m, const char *name){
    static_cast<py::class_<NCollection_Array2<TheItemType> , shared_ptr<NCollection_Array2<TheItemType>> , NCollection_Array1<TheItemType> >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const int, const int, const int, const int >() ,py::arg("theRowLower"), py::arg("theRowUpper"), py::arg("theColLower"), py::arg("theColUpper") )
        .def(py::init<  const NCollection_Array2<TheItemType> & >() ,py::arg("theOther") )
        .def(py::init<  const TheItemType &, const int, const int, const int, const int >() ,py::arg("theBegin"), py::arg("theRowLower"), py::arg("theRowUpper"), py::arg("theColLower"), py::arg("theColUpper") )
        .def(py::init<  const size_t, const size_t >() ,py::arg("theNbRows"), py::arg("theNbCols") )
        .def(py::init< typename NCollection_Array2<TheItemType>::pointer, const size_t, const size_t >() ,py::arg("theBegin"), py::arg("theNbRows"), py::arg("theNbCols") )
        .def("Size",
             (size_t (NCollection_Array2<TheItemType>::*)() const) &NCollection_Array2<TheItemType>::Size,
             R"#(Size (number of items).)#" )
        .def("Length",
             (int (NCollection_Array2<TheItemType>::*)() const) &NCollection_Array2<TheItemType>::Length,
             R"#(Length (legacy int-returning API).)#" )
        .def("NbRows",
             (int (NCollection_Array2<TheItemType>::*)() const) &NCollection_Array2<TheItemType>::NbRows,
             R"#(Returns number of rows)#" )
        .def("NbColumns",
             (int (NCollection_Array2<TheItemType>::*)() const) &NCollection_Array2<TheItemType>::NbColumns,
             R"#(Returns number of columns)#" )
        .def("RowLength",
             (int (NCollection_Array2<TheItemType>::*)() const) &NCollection_Array2<TheItemType>::RowLength,
             R"#(Returns length of the row, i.e. number of columns)#" )
        .def("ColLength",
             (int (NCollection_Array2<TheItemType>::*)() const) &NCollection_Array2<TheItemType>::ColLength,
             R"#(Returns length of the column, i.e. number of rows)#" )
        .def("LowerRow",
             (int (NCollection_Array2<TheItemType>::*)() const) &NCollection_Array2<TheItemType>::LowerRow,
             R"#(LowerRow)#" )
        .def("UpperRow",
             (int (NCollection_Array2<TheItemType>::*)() const) &NCollection_Array2<TheItemType>::UpperRow,
             R"#(UpperRow)#" )
        .def("LowerCol",
             (int (NCollection_Array2<TheItemType>::*)() const) &NCollection_Array2<TheItemType>::LowerCol,
             R"#(LowerCol)#" )
        .def("UpperCol",
             (int (NCollection_Array2<TheItemType>::*)() const) &NCollection_Array2<TheItemType>::UpperCol,
             R"#(UpperCol)#" )
        .def("UpdateLowerRow",
             (void (NCollection_Array2<TheItemType>::*)(  const int  ) ) &NCollection_Array2<TheItemType>::UpdateLowerRow,
             R"#(Updates lower row)#" ,py::arg("theLowerRow"))
        .def("UpdateLowerCol",
             (void (NCollection_Array2<TheItemType>::*)(  const int  ) ) &NCollection_Array2<TheItemType>::UpdateLowerCol,
             R"#(Updates lower column)#" ,py::arg("theLowerCol"))
        .def("UpdateUpperRow",
             (void (NCollection_Array2<TheItemType>::*)(  const int  ) ) &NCollection_Array2<TheItemType>::UpdateUpperRow,
             R"#(Updates upper row)#" ,py::arg("theUpperRow"))
        .def("UpdateUpperCol",
             (void (NCollection_Array2<TheItemType>::*)(  const int  ) ) &NCollection_Array2<TheItemType>::UpdateUpperCol,
             R"#(Updates upper column)#" ,py::arg("theUpperCol"))
        .def("Assign",
             (NCollection_Array2<TheItemType> & (NCollection_Array2<TheItemType>::*)(  const NCollection_Array2<TheItemType> &  ) ) &NCollection_Array2<TheItemType>::Assign,
             R"#(Replaces this array by a copy of theOther array. Row and column bounds are copied from theOther.)#" ,py::arg("theOther"))
        .def("CopyValues",
             (NCollection_Array2<TheItemType> & (NCollection_Array2<TheItemType>::*)(  const NCollection_Array2<TheItemType> &  ) ) &NCollection_Array2<TheItemType>::CopyValues,
             R"#(Copies values from theOther array without changing this array bounds. This array should be pre-allocated and have the same dimensions as theOther; otherwise exception Standard_DimensionMismatch is thrown.)#" ,py::arg("theOther"))
        .def("Move",
             (NCollection_Array2<TheItemType> & (NCollection_Array2<TheItemType>::*)( NCollection_Array2<TheItemType> &  ) ) &NCollection_Array2<TheItemType>::Move,
             R"#(Move assignment. This array will borrow all the data from theOther. The moved object will be left uninitialized and should not be used anymore.)#" ,py::arg("theOther"))
        .def("Value",
             (typename NCollection_Array2<TheItemType>::const_reference (NCollection_Array2<TheItemType>::*)(  const int ,   const int  ) const) &NCollection_Array2<TheItemType>::Value,
             R"#(Constant value access)#" ,py::arg("theRow"), py::arg("theCol"))
        .def("ChangeValue",
             (typename NCollection_Array2<TheItemType>::reference (NCollection_Array2<TheItemType>::*)(  const int ,   const int  ) ) &NCollection_Array2<TheItemType>::ChangeValue,
             R"#(Variable value access)#" ,py::arg("theRow"), py::arg("theCol"))
        .def("SetValue",
             (void (NCollection_Array2<TheItemType>::*)(  const int ,   const int ,   const TheItemType &  ) ) &NCollection_Array2<TheItemType>::SetValue,
             R"#(SetValue)#" ,py::arg("theRow"), py::arg("theCol"), py::arg("theItem"))
        .def("At",
             (typename NCollection_Array2<TheItemType>::const_reference (NCollection_Array2<TheItemType>::*)(  const size_t ,   const size_t  ) const) &NCollection_Array2<TheItemType>::At,
             R"#(0-based checked access independent of LowerRow()/LowerCol().)#" ,py::arg("theRow"), py::arg("theCol"))
        .def("ChangeAt",
             (typename NCollection_Array2<TheItemType>::reference (NCollection_Array2<TheItemType>::*)(  const size_t ,   const size_t  ) ) &NCollection_Array2<TheItemType>::ChangeAt,
             R"#(0-based checked mutable access independent of LowerRow()/LowerCol().)#" ,py::arg("theRow"), py::arg("theCol"))
        .def("Resize",
             (void (NCollection_Array2<TheItemType>::*)( int ,  int ,  int ,  int ,  bool  ) ) &NCollection_Array2<TheItemType>::Resize,
             R"#(Resizes the array to specified bounds. When theToCopyData is false, the array is re-allocated without preserving data. When theToCopyData is true, copies elements in linear (row-major) order. No re-allocation is done if dimensions are unchanged.)#" ,py::arg("theRowLower"), py::arg("theRowUpper"), py::arg("theColLower"), py::arg("theColUpper"), py::arg("theToCopyData"))
        .def("ResizeWithTrim",
             (void (NCollection_Array2<TheItemType>::*)( int ,  int ,  int ,  int ,  bool  ) ) &NCollection_Array2<TheItemType>::ResizeWithTrim,
             R"#(Resizes the array preserving 2D element layout. When theToCopyData is false, the array is re-allocated without preserving data. When theToCopyData is true, copies min(oldNbRows,newNbRows) x min(oldNbCols,newNbCols) elements from the top-left corner of the old array to the top-left corner of the new, preserving relative (row, col) offsets from lower bounds. Trimming or growing as needed. No re-allocation is done if dimensions are unchanged.)#" ,py::arg("theRowLower"), py::arg("theRowUpper"), py::arg("theColLower"), py::arg("theColUpper"), py::arg("theToCopyData"))
        .def("Resize",
             (void (NCollection_Array2<TheItemType>::*)(  const size_t ,   const size_t ,   const bool  ) ) &NCollection_Array2<TheItemType>::Resize,
             R"#(Zero-based Resize: resizes to theNbRows x theNbCols, keeping lower bounds unchanged. No re-allocation is done if dimensions are unchanged.)#" ,py::arg("theNbRows"), py::arg("theNbCols"), py::arg("theToCopyData"))
        .def("ResizeWithTrim",
             (void (NCollection_Array2<TheItemType>::*)(  const size_t ,   const size_t ,   const bool  ) ) &NCollection_Array2<TheItemType>::ResizeWithTrim,
             R"#(Zero-based ResizeWithTrim: resizes preserving 2D layout, keeping lower bounds unchanged. No re-allocation is done if dimensions are unchanged.)#" ,py::arg("theNbRows"), py::arg("theNbCols"), py::arg("theToCopyData"))
        .def_static("BeginPosition_s",
                    (int (*)( int ,  int ,  int ,  int  ) ) &NCollection_Array2<TheItemType>::BeginPosition,
                    R"#()#" ,py::arg("theRowLower"), py::arg("arg1"), py::arg("theColLower"), py::arg("theColUpper"))
        .def_static("LastPosition_s",
                    (int (*)( int ,  int ,  int ,  int  ) ) &NCollection_Array2<TheItemType>::LastPosition,
                    R"#()#" ,py::arg("theRowLower"), py::arg("theRowUpper"), py::arg("theColLower"), py::arg("theColUpper"))
        .def("__len__",[](const NCollection_Array2<TheItemType> &self)
             { return self.Size(); }
             )
    ;
};

template <typename TheItemType>
void preregister_template_NCollection_TListIterator(py::object &m, const char *name){
    py::class_<NCollection_TListIterator<TheItemType> , shared_ptr<NCollection_TListIterator<TheItemType>> , NCollection_BaseList::Iterator >(m,name,R"#(Purpose: This Iterator class iterates on BaseList of TListNode and is instantiated in List/Set/Queue/Stack Remark: TListIterator is internal class)#");
}

template <typename TheItemType>
void register_template_NCollection_TListIterator(py::object &m, const char *name){
    static_cast<py::class_<NCollection_TListIterator<TheItemType> , shared_ptr<NCollection_TListIterator<TheItemType>> , NCollection_BaseList::Iterator >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const NCollection_BaseList & >() ,py::arg("theList") )
        .def("More",
             (bool (NCollection_TListIterator<TheItemType>::*)() const) &NCollection_TListIterator<TheItemType>::More,
             R"#(Check end)#" )
        .def("Next",
             (void (NCollection_TListIterator<TheItemType>::*)() ) &NCollection_TListIterator<TheItemType>::Next,
             R"#(Make step)#" )
        .def("Value",
             ( const TheItemType & (NCollection_TListIterator<TheItemType>::*)() const) &NCollection_TListIterator<TheItemType>::Value,
             R"#(Constant Value access)#" )
        .def("Value",
             (TheItemType & (NCollection_TListIterator<TheItemType>::*)() ) &NCollection_TListIterator<TheItemType>::Value,
             R"#(Non-const Value access)#" )
        .def("ChangeValue",
             (TheItemType & (NCollection_TListIterator<TheItemType>::*)() const) &NCollection_TListIterator<TheItemType>::ChangeValue,
             R"#(Non-const Value access)#" )
    ;
};

template <typename Container>
void preregister_template_NCollection_Iterator(py::object &m, const char *name){
    py::class_<NCollection_Iterator<Container> , shared_ptr<NCollection_Iterator<Container>> >(m,name,R"#(Helper class that allows to use NCollection iterators as STL iterators. NCollection iterator can be extended to STL iterator of any category by adding necessary methods: STL forward iterator requires IsEqual method, STL bidirectional iterator requires Previous method, and STL random access iterator requires Offset and Differ methods. See NCollection_DynamicArray as example of declaring custom STL iterators.)#");
}

template <typename Container>
void register_template_NCollection_Iterator(py::object &m, const char *name){
    static_cast<py::class_<NCollection_Iterator<Container> , shared_ptr<NCollection_Iterator<Container>> >>(m.attr(name))
        .def(py::init<  >()  )
        .def(py::init<  const NCollection_Iterator<Container> & >() ,py::arg("theOther") )
        .def(py::init<  const Container & >() ,py::arg("theList") )
        .def(py::init<  const Container &, const typename Container::iterator & >() ,py::arg("theList"), py::arg("theOther") )
        .def("Init",
             (void (NCollection_Iterator<Container>::*)( Container &  ) ) &NCollection_Iterator<Container>::Init,
             R"#()#" ,py::arg("theList"))
        .def("Init",
             (void (NCollection_Iterator<Container>::*)(  const Container &  ) ) &NCollection_Iterator<Container>::Init,
             R"#()#" ,py::arg("theList"))
        .def("More",
             (bool (NCollection_Iterator<Container>::*)() const) &NCollection_Iterator<Container>::More,
             R"#()#" )
        .def("Initialize",
             (void (NCollection_Iterator<Container>::*)( Container &  ) ) &NCollection_Iterator<Container>::Initialize,
             R"#()#" ,py::arg("theList"))
        .def("Initialize",
             (void (NCollection_Iterator<Container>::*)(  const Container &  ) ) &NCollection_Iterator<Container>::Initialize,
             R"#()#" ,py::arg("theList"))
        .def("ValueIter",
             ( const typename Container::iterator & (NCollection_Iterator<Container>::*)() const) &NCollection_Iterator<Container>::ValueIter,
             R"#()#" )
        .def("ChangeValueIter",
             (typename Container::iterator & (NCollection_Iterator<Container>::*)() ) &NCollection_Iterator<Container>::ChangeValueIter,
             R"#()#" )
        .def("EndIter",
             ( const typename Container::iterator & (NCollection_Iterator<Container>::*)() const) &NCollection_Iterator<Container>::EndIter,
             R"#()#" )
        .def("ChangeEndIter",
             (typename Container::iterator & (NCollection_Iterator<Container>::*)() ) &NCollection_Iterator<Container>::ChangeEndIter,
             R"#()#" )
        .def("Next",
             (void (NCollection_Iterator<Container>::*)() ) &NCollection_Iterator<Container>::Next,
             R"#()#" )
        .def("Value",
             ( const typename Container::const_reference (NCollection_Iterator<Container>::*)() const) &NCollection_Iterator<Container>::Value,
             R"#()#" )
        .def("ChangeValue",
             ( const typename Container::reference (NCollection_Iterator<Container>::*)() ) &NCollection_Iterator<Container>::ChangeValue,
             R"#()#" )
    ;
};


// user-defined post
template <typename T>
void preregister_template_NCollection_Vector(py::object &m, const char *name){
    preregister_template_NCollection_DynamicArray<T>(m, name);
};

template <typename T>
void register_template_NCollection_Vector(py::object &m, const char *name){
    register_template_NCollection_DynamicArray<T>(m, name);
};
        

