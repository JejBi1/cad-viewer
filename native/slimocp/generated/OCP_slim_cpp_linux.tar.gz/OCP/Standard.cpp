
// std lib related includes
#include <tuple>

// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// Standard Handle
#include <Standard_Handle.hxx>


// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_Persistent.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Standard_Type.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <Standard.hxx>
#include <Standard_AbortiveTransaction.hxx>
#include <Standard_ArrayStreamBuffer.hxx>
#include <Standard_Assert.hxx>
#include <Standard_Atomic.hxx>
#include <Standard_Boolean.hxx>
#include <Standard_Byte.hxx>
#include <Standard_Character.hxx>
#include <Standard_CLocaleSentry.hxx>
#include <Standard_Condition.hxx>
#include <Standard_ConstructionError.hxx>
#include <Standard_CString.hxx>
#include <Standard_CStringHasher.hxx>
#include <Standard_DefineAlloc.hxx>
#include <Standard_DefineException.hxx>
#include <Standard_DefineHandle.hxx>
#include <Standard_DimensionError.hxx>
#include <Standard_DimensionMismatch.hxx>
#include <Standard_DivideByZero.hxx>
#include <Standard_DomainError.hxx>
#include <Standard_Dump.hxx>
#include <Standard_ErrorHandler.hxx>
#include <Standard_ExtCharacter.hxx>
#include <Standard_Failure.hxx>
#include <Standard_GUID.hxx>
#include <Standard_HashUtils.hxx>
#include <Standard_ImmutableObject.hxx>
#include <Standard_Integer.hxx>
#include <Standard_IStream.hxx>
#include <Standard_LicenseError.hxx>
#include <Standard_LicenseNotFound.hxx>
#include <Standard_Macro.hxx>
#include <Standard_MMgrOpt.hxx>
#include <Standard_MMgrRoot.hxx>
#include <Standard_MultiplyDefined.hxx>
#include <Standard_Mutex.hxx>
#include <Standard_NegativeValue.hxx>
#include <Standard_NoMoreObject.hxx>
#include <Standard_NoSuchObject.hxx>
#include <Standard_NotImplemented.hxx>
#include <Standard_NullObject.hxx>
#include <Standard_NullValue.hxx>
#include <Standard_NumericError.hxx>
#include <Standard_OStream.hxx>
#include <Standard_OutOfMemory.hxx>
#include <Standard_OutOfRange.hxx>
#include <Standard_Overflow.hxx>
#include <Standard_PByte.hxx>
#include <Standard_PCharacter.hxx>
#include <Standard_Persistent.hxx>
#include <Standard_PExtCharacter.hxx>
#include <Standard_ProgramError.hxx>
#include <Standard_RangeError.hxx>
#include <Standard_ReadBuffer.hxx>
#include <Standard_ReadLineBuffer.hxx>
#include <Standard_Real.hxx>
#include <Standard_ShortReal.hxx>
#include <Standard_SStream.hxx>
#include <Standard_Std.hxx>
#include <Standard_ThreadId.hxx>
#include <Standard_Time.hxx>
#include <Standard_Transient.hxx>
#include <Standard_Type.hxx>
#include <Standard_TypeDef.hxx>
#include <Standard_TypeMismatch.hxx>
#include <Standard_Underflow.hxx>
#include <Standard_UUID.hxx>
#include <Standard_Version.hxx>
#include <Standard_VersionInfo.hxx>
#include <Standard_WarningDisableFunctionCast.hxx>
#include <Standard_WarningsDisable.hxx>
#include <Standard_WarningsRestore.hxx>

// template related includes


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module

// Module definiiton
void register_Standard(py::module &main_module) {


py::module m = static_cast<py::module>(main_module.attr("Standard"));
py::object klass;

// get namespaces as submodules
auto occ = static_cast<py::module>(m.attr("occ"));

//Python trampoline classes
    class Py_Standard_MMgrRoot : public Standard_MMgrRoot{
    public:
        using Standard_MMgrRoot::Standard_MMgrRoot;


        // public pure virtual
        void * Allocate( const size_t theSize) override { using return_type = void *;
    PYBIND11_OVERLOAD_PURE(return_type,Standard_MMgrRoot,Allocate,theSize) };
        void * Reallocate(void * thePtr, const size_t theSize) override { using return_type = void *;
    PYBIND11_OVERLOAD_PURE(return_type,Standard_MMgrRoot,Reallocate,thePtr,theSize) };
        void Free(void * thePtr) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Standard_MMgrRoot,Free,thePtr) };


        // protected pure virtual


        // private pure virtual

    };

// classes

    // Class Standard from ./opencascade/Standard.hxx
    klass = m.attr("Standard");

    // default constructor
    register_default_constructor<Standard , shared_ptr<Standard>>(m,"Standard");

    // nested enums
        py::enum_<Standard::AllocatorType>(klass, "AllocatorType_e", R"#(Enumiration of possible allocator types)#")
            .value("NATIVE", Standard::AllocatorType::NATIVE)
            .value("OPT", Standard::AllocatorType::OPT)
            .value("TBB", Standard::AllocatorType::TBB)
            .value("JEMALLOC", Standard::AllocatorType::JEMALLOC);

    static_cast<py::class_<Standard , shared_ptr<Standard>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("GetAllocatorType_s",
                    (Standard::AllocatorType (*)() ) static_cast<Standard::AllocatorType (*)() >(&Standard::GetAllocatorType),
                    R"#(Returns default allocator type)#" 
          )
        .def_static("Allocate_s",
                    (void * (*)(  const size_t  ) ) static_cast<void * (*)(  const size_t  ) >(&Standard::Allocate),
                    R"#(Allocates memory blocks theSize - bytes to allocate)#"  , py::arg("theSize")
          )
        .def_static("AllocateOptimal_s",
                    (void * (*)(  const size_t  ) ) static_cast<void * (*)(  const size_t  ) >(&Standard::AllocateOptimal),
                    R"#(Allocates memory blocks theSize - bytes to allocate)#"  , py::arg("theSize")
          )
        .def_static("Free_s",
                    (void (*)( void * const   ) ) static_cast<void (*)( void * const   ) >(&Standard::Free),
                    R"#(Deallocates memory blocks)#"  , py::arg("thePtr")
          )
        .def_static("Reallocate_s",
                    (void * (*)( void * const  ,   const size_t  ) ) static_cast<void * (*)( void * const  ,   const size_t  ) >(&Standard::Reallocate),
                    R"#(Reallocates memory blocks theStorage - previously allocated memory block theNewSize - new size in bytes)#"  , py::arg("theStorage"),  py::arg("theNewSize")
          )
        .def_static("AllocateAligned_s",
                    (void * (*)(  const size_t ,   const size_t  ) ) static_cast<void * (*)(  const size_t ,   const size_t  ) >(&Standard::AllocateAligned),
                    R"#(Allocates aligned memory blocks. Should be used with CPU instructions which require specific alignment. For example: SSE requires 16 bytes, AVX requires 32 bytes.)#"  , py::arg("theSize"),  py::arg("theAlign")
          )
        .def_static("FreeAligned_s",
                    (void (*)( void * const   ) ) static_cast<void (*)( void * const   ) >(&Standard::FreeAligned),
                    R"#(Deallocates memory blocks)#"  , py::arg("thePtrAligned")
          )
        .def_static("Purge_s",
                    (int (*)() ) static_cast<int (*)() >(&Standard::Purge),
                    R"#(Deallocates the storage retained on the free list and clears the list. Returns non-zero if some memory has been actually freed.)#" 
          )
        .def_static("StackTrace_s",
                    (bool (*)( char * ,   const int ,   const int ,  void * ,   const int  ) ) static_cast<bool (*)( char * ,   const int ,   const int ,  void * ,   const int  ) >(&Standard::StackTrace),
                    R"#(Appends backtrace to a message buffer. Stack information might be incomplete in case of stripped binaries. Implementation details: - Not implemented for Android, iOS, QNX and UWP platforms. - On non-Windows platform, this function is a wrapper to backtrace() system call. - On Windows (Win32) platform, the function loads DbgHelp.dll dynamically, and no stack will be provided if this or companion libraries (SymSrv.dll, SrcSrv.dll, etc.) will not be found; .pdb symbols should be provided on Windows platform to retrieve a meaningful stack; only x86_64 CPU architecture is currently implemented.)#"  , py::arg("theBuffer"),  py::arg("theBufferSize"),  py::arg("theNbTraces"),  py::arg("theContext")=static_cast<void *>(nullptr),  py::arg("theNbTopSkip")=static_cast< const int>(0)
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Standard_ArrayStreamBuffer from ./opencascade/Standard_ArrayStreamBuffer.hxx
    klass = m.attr("Standard_ArrayStreamBuffer");


    // nested enums

    static_cast<py::class_<Standard_ArrayStreamBuffer , shared_ptr<Standard_ArrayStreamBuffer>  >>(klass)
    // constructors
        .def(py::init<  const char *, const size_t >()  , py::arg("theBegin"),  py::arg("theSize") )
    // custom constructors
    // methods
        .def("Init",
             (void (Standard_ArrayStreamBuffer::*)(  const char * ,   const size_t  ) ) static_cast<void (Standard_ArrayStreamBuffer::*)(  const char * ,   const size_t  ) >(&Standard_ArrayStreamBuffer::Init),
             R"#((Re)-initialize the stream. Passed pointer is stored as is (memory is NOT copied nor released with destructor).)#"  , py::arg("theBegin"),  py::arg("theSize")
          )
        .def("xsgetn",
             (std::streamsize (Standard_ArrayStreamBuffer::*)( char * ,  std::streamsize  ) ) static_cast<std::streamsize (Standard_ArrayStreamBuffer::*)( char * ,  std::streamsize  ) >(&Standard_ArrayStreamBuffer::xsgetn),
             R"#(Read a bunch of bytes at once.)#"  , py::arg("thePtr"),  py::arg("theCount")
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Standard_CLocaleSentry from ./opencascade/Standard_CLocaleSentry.hxx
    klass = m.attr("Standard_CLocaleSentry");


    // nested enums

    static_cast<py::class_<Standard_CLocaleSentry , shared_ptr<Standard_CLocaleSentry>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Standard_CStringHasher from ./opencascade/Standard_CStringHasher.hxx
    klass = m.attr("Standard_CStringHasher");

    // default constructor
    register_default_constructor<Standard_CStringHasher , shared_ptr<Standard_CStringHasher>>(m,"Standard_CStringHasher");

    // nested enums

    static_cast<py::class_<Standard_CStringHasher , shared_ptr<Standard_CStringHasher>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
        .def("__call__",
             (size_t (Standard_CStringHasher::*)(  const char * const   ) const) static_cast<size_t (Standard_CStringHasher::*)(  const char * const   ) const>(&Standard_CStringHasher::operator()),
             py::is_operator(),
             R"#()#"  , py::arg("theString")
          )
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Standard_Condition from ./opencascade/Standard_Condition.hxx
    klass = m.attr("Standard_Condition");


    // nested enums

    static_cast<py::class_<Standard_Condition , shared_ptr<Standard_Condition>  >>(klass)
    // constructors
        .def(py::init< bool >()  , py::arg("theIsSet")=static_cast<bool>(false) )
    // custom constructors
    // methods
        .def("Set",
             (void (Standard_Condition::*)() ) static_cast<void (Standard_Condition::*)() >(&Standard_Condition::Set),
             R"#(Set event into signaling state.)#" 
          )
        .def("Reset",
             (void (Standard_Condition::*)() ) static_cast<void (Standard_Condition::*)() >(&Standard_Condition::Reset),
             R"#(Reset event (unset signaling state))#" 
          )
        .def("Wait",
             (void (Standard_Condition::*)() ) static_cast<void (Standard_Condition::*)() >(&Standard_Condition::Wait),
             R"#(Wait for Event (infinity).)#" 
          )
        .def("Wait",
             (bool (Standard_Condition::*)( int  ) ) static_cast<bool (Standard_Condition::*)( int  ) >(&Standard_Condition::Wait),
             R"#(Wait for signal requested time.)#"  , py::arg("theTimeMilliseconds")
          )
        .def("Check",
             (bool (Standard_Condition::*)() ) static_cast<bool (Standard_Condition::*)() >(&Standard_Condition::Check),
             R"#(Do not wait for signal - just test it state.)#" 
          )
        .def("CheckReset",
             (bool (Standard_Condition::*)() ) static_cast<bool (Standard_Condition::*)() >(&Standard_Condition::CheckReset),
             R"#(Method perform two steps at-once - reset the event object and returns true if it was in signaling state.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Standard_Dump from ./opencascade/Standard_Dump.hxx
    klass = m.attr("Standard_Dump");

    // default constructor
    register_default_constructor<Standard_Dump , shared_ptr<Standard_Dump>>(m,"Standard_Dump");

    // nested enums

    static_cast<py::class_<Standard_Dump , shared_ptr<Standard_Dump>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Text_s",
                    (TCollection_AsciiString (*)(  const Standard_SStream &  ) ) static_cast<TCollection_AsciiString (*)(  const Standard_SStream &  ) >(&Standard_Dump::Text),
                    R"#(Converts stream value to string value. The result is original stream value.)#"  , py::arg("theStream")
          )
        .def_static("FormatJson_s",
                    (TCollection_AsciiString (*)(  const Standard_SStream & ,   const int  ) ) static_cast<TCollection_AsciiString (*)(  const Standard_SStream & ,   const int  ) >(&Standard_Dump::FormatJson),
                    R"#(Converts stream value to string value. Improves the text presentation with the following cases: - for '{' append after '' and indent to the next value, increment current indent value - for '}' append '' and current indent before it, decrement indent value - for ',' append after '' and indent to the next value. If the current symbol is in massive container [], do nothing Covers result with opened and closed brackets on the top level, if it has no symbols there.)#"  , py::arg("theStream"),  py::arg("theIndent")=static_cast< const int>(3)
          )
        .def_static("SplitJson_s",
                    (bool (*)(  const TCollection_AsciiString & ,  NCollection_IndexedDataMap<TCollection_AsciiString, Standard_DumpValue> &  ) ) static_cast<bool (*)(  const TCollection_AsciiString & ,  NCollection_IndexedDataMap<TCollection_AsciiString, Standard_DumpValue> &  ) >(&Standard_Dump::SplitJson),
                    R"#(Converts stream into map of values.)#"  , py::arg("theStreamStr"),  py::arg("theKeyToValues")
          )
        .def_static("HierarchicalValueIndices_s",
                    (NCollection_List<int> (*)(  const NCollection_IndexedDataMap<TCollection_AsciiString, TCollection_AsciiString> &  ) ) static_cast<NCollection_List<int> (*)(  const NCollection_IndexedDataMap<TCollection_AsciiString, TCollection_AsciiString> &  ) >(&Standard_Dump::HierarchicalValueIndices),
                    R"#(Returns container of indices in values, that has hierarchical value)#"  , py::arg("theValues")
          )
        .def_static("HasChildKey_s",
                    (bool (*)(  const TCollection_AsciiString &  ) ) static_cast<bool (*)(  const TCollection_AsciiString &  ) >(&Standard_Dump::HasChildKey),
                    R"#(Returns true if the value has bracket key)#"  , py::arg("theSourceValue")
          )
        .def_static("JsonKeyToString_s",
                    ( const char * (*)(  const Standard_JsonKey  ) ) static_cast< const char * (*)(  const Standard_JsonKey  ) >(&Standard_Dump::JsonKeyToString),
                    R"#(Returns key value for enum type)#"  , py::arg("theKey")
          )
        .def_static("JsonKeyLength_s",
                    (int (*)(  const Standard_JsonKey  ) ) static_cast<int (*)(  const Standard_JsonKey  ) >(&Standard_Dump::JsonKeyLength),
                    R"#(Returns length value for enum type)#"  , py::arg("theKey")
          )
        .def_static("AddValuesSeparator_s",
                    (void (*)( Standard_OStream &  ) ) static_cast<void (*)( Standard_OStream &  ) >(&Standard_Dump::AddValuesSeparator),
                    R"#()#"  , py::arg("theOStream")
          )
        .def_static("GetPointerPrefix_s",
                    (TCollection_AsciiString (*)() ) static_cast<TCollection_AsciiString (*)() >(&Standard_Dump::GetPointerPrefix),
                    R"#(Returns default prefix added for each pointer info string if short presentation of pointer used)#" 
          )
        .def_static("GetPointerInfo_s",
                    (TCollection_AsciiString (*)(  const handle<Standard_Transient> & ,   const bool  ) ) static_cast<TCollection_AsciiString (*)(  const handle<Standard_Transient> & ,   const bool  ) >(&Standard_Dump::GetPointerInfo),
                    R"#(Convert handle pointer to address of the pointer. If the handle is NULL, the result is an empty string.)#"  , py::arg("thePointer"),  py::arg("isShortInfo")=static_cast< const bool>(true)
          )
        .def_static("GetPointerInfo_s",
                    (TCollection_AsciiString (*)(  const void * ,   const bool  ) ) static_cast<TCollection_AsciiString (*)(  const void * ,   const bool  ) >(&Standard_Dump::GetPointerInfo),
                    R"#(Convert pointer to address of the pointer. If the handle is NULL, the result is an empty string.)#"  , py::arg("thePointer"),  py::arg("isShortInfo")=static_cast< const bool>(true)
          )
        .def_static("DumpKeyToClass_s",
                    (void (*)( Standard_OStream & ,   const TCollection_AsciiString & ,   const TCollection_AsciiString &  ) ) static_cast<void (*)( Standard_OStream & ,   const TCollection_AsciiString & ,   const TCollection_AsciiString &  ) >(&Standard_Dump::DumpKeyToClass),
                    R"#(Append into output value: "Name": { Field })#"  , py::arg("theOStream"),  py::arg("theKey"),  py::arg("theField")
          )
        .def_static("ProcessStreamName_s",
                    (bool (*)(  const TCollection_AsciiString & ,   const TCollection_AsciiString & ,  int &  ) ) static_cast<bool (*)(  const TCollection_AsciiString & ,   const TCollection_AsciiString & ,  int &  ) >(&Standard_Dump::ProcessStreamName),
                    R"#(Check whether the parameter name is equal to the name in the stream at position)#"  , py::arg("theStreamStr"),  py::arg("theName"),  py::arg("theStreamPos")
          )
        .def_static("ProcessFieldName_s",
                    (bool (*)(  const TCollection_AsciiString & ,   const TCollection_AsciiString & ,  int &  ) ) static_cast<bool (*)(  const TCollection_AsciiString & ,   const TCollection_AsciiString & ,  int &  ) >(&Standard_Dump::ProcessFieldName),
                    R"#(Check whether the field name is equal to the name in the stream at position)#"  , py::arg("theStreamStr"),  py::arg("theName"),  py::arg("theStreamPos")
          )
        .def_static("InitValue_s",
                    (bool (*)(  const TCollection_AsciiString & ,  int & ,  TCollection_AsciiString &  ) ) static_cast<bool (*)(  const TCollection_AsciiString & ,  int & ,  TCollection_AsciiString &  ) >(&Standard_Dump::InitValue),
                    R"#(Returns real value)#"  , py::arg("theStreamStr"),  py::arg("theStreamPos"),  py::arg("theValue")
          )
        .def_static("DumpFieldToName_s",
                    (TCollection_AsciiString (*)(  const TCollection_AsciiString &  ) ) static_cast<TCollection_AsciiString (*)(  const TCollection_AsciiString &  ) >(&Standard_Dump::DumpFieldToName),
                    R"#(Convert field name into dump text value, removes "&" and "my" prefixes An example, for field myValue, theName is Value, for &myCLass, the name is Class)#"  , py::arg("theField")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Standard_DumpValue from ./opencascade/Standard_Dump.hxx
    klass = m.attr("Standard_DumpValue");


    // nested enums

    static_cast<py::class_<Standard_DumpValue , shared_ptr<Standard_DumpValue>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const TCollection_AsciiString &, const int >()  , py::arg("theValue"),  py::arg("theStartPos") )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
        .def_readwrite("myValue", &Standard_DumpValue::myValue)
        .def_readwrite("myStartPosition", &Standard_DumpValue::myStartPosition)
    // methods returning by ref wrapped as properties
;

    // Class Standard_ErrorHandler from ./opencascade/Standard_ErrorHandler.hxx
    klass = m.attr("Standard_ErrorHandler");


    // nested enums

    static_cast<py::class_<Standard_ErrorHandler , shared_ptr<Standard_ErrorHandler>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Destroy",
             (void (Standard_ErrorHandler::*)() ) static_cast<void (Standard_ErrorHandler::*)() >(&Standard_ErrorHandler::Destroy),
             R"#(Unlinks and checks if there is a raised exception.)#" 
          )
        .def("Raise",
             (void (Standard_ErrorHandler::*)() ) static_cast<void (Standard_ErrorHandler::*)() >(&Standard_ErrorHandler::Raise),
             R"#(Throws C++ exception if exception object set, otherwise prints error and terminates program.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("IsInTryBlock_s",
                    (bool (*)() ) static_cast<bool (*)() >(&Standard_ErrorHandler::IsInTryBlock),
                    R"#(Test if the code is currently running in a try block)#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Error",
             ( const typename Standard_ErrorHandler::SignalException & (Standard_ErrorHandler::*)() const) static_cast< const typename Standard_ErrorHandler::SignalException & (Standard_ErrorHandler::*)() const>(&Standard_ErrorHandler::Error),
             R"#(Returns the current Error variant.)#"
             
         )
;

    // Class Standard_GUID from ./opencascade/Standard_GUID.hxx
    klass = m.attr("Standard_GUID");


    // nested enums

    static_cast<py::class_<Standard_GUID , shared_ptr<Standard_GUID>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const Standard_GUID & >()  , py::arg("theGuid") )
        .def(py::init<  const Standard_UUID & >()  , py::arg("theUUID") )
        .def(py::init<  const char * const  >()  , py::arg("aGuid") )
        .def(py::init<  const char16_t * const  >()  , py::arg("aGuid") )
        .def(py::init<  const int, const char16_t, const char16_t, const char16_t, const uint8_t, const uint8_t, const uint8_t, const uint8_t, const uint8_t, const uint8_t >()  , py::arg("a32b"),  py::arg("a16b1"),  py::arg("a16b2"),  py::arg("a16b3"),  py::arg("a8b1"),  py::arg("a8b2"),  py::arg("a8b3"),  py::arg("a8b4"),  py::arg("a8b5"),  py::arg("a8b6") )
    // custom constructors
    // methods
        .def("ToCString",
             (void (Standard_GUID::*)(  const Standard_PCharacter  ) const) static_cast<void (Standard_GUID::*)(  const Standard_PCharacter  ) const>(&Standard_GUID::ToCString),
             R"#(translate the GUID into ascii string the aStrGuid is allocated by user. the guid have the following format:)#"  , py::arg("aStrGuid")
          )
        .def("ToExtString",
             (void (Standard_GUID::*)(  const Standard_PExtCharacter  ) const) static_cast<void (Standard_GUID::*)(  const Standard_PExtCharacter  ) const>(&Standard_GUID::ToExtString),
             R"#(translate the GUID into unicode string the aStrGuid is allocated by user. the guid have the following format:)#"  , py::arg("aStrGuid")
          )
        .def("ToUUID",
             (Standard_UUID (Standard_GUID::*)() const) static_cast<Standard_UUID (Standard_GUID::*)() const>(&Standard_GUID::ToUUID),
             R"#(Converts to Standard_UUID.)#" 
          )
        .def("IsSame",
             (bool (Standard_GUID::*)(  const Standard_GUID &  ) const) static_cast<bool (Standard_GUID::*)(  const Standard_GUID &  ) const>(&Standard_GUID::IsSame),
             R"#(Returns true if this GUID is equal to uid.)#"  , py::arg("uid")
          )
        .def("IsNotSame",
             (bool (Standard_GUID::*)(  const Standard_GUID &  ) const) static_cast<bool (Standard_GUID::*)(  const Standard_GUID &  ) const>(&Standard_GUID::IsNotSame),
             R"#(Returns true if this GUID is not equal to uid.)#"  , py::arg("uid")
          )
        .def("Assign",
             (void (Standard_GUID::*)(  const Standard_GUID &  ) ) static_cast<void (Standard_GUID::*)(  const Standard_GUID &  ) >(&Standard_GUID::Assign),
             R"#(Assigns uid to this GUID.)#"  , py::arg("uid")
          )
        .def("Assign",
             (void (Standard_GUID::*)(  const Standard_UUID &  ) ) static_cast<void (Standard_GUID::*)(  const Standard_UUID &  ) >(&Standard_GUID::Assign),
             R"#(Assigns uid to this GUID.)#"  , py::arg("uid")
          )
        .def("ShallowDump",
             (void (Standard_GUID::*)( Standard_OStream &  ) const) static_cast<void (Standard_GUID::*)( Standard_OStream &  ) const>(&Standard_GUID::ShallowDump),
             R"#(Display the GUID with the following format:)#"  , py::arg("aStream")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("CheckGUIDFormat_s",
                    (bool (*)(  const char * const   ) ) static_cast<bool (*)(  const char * const   ) >(&Standard_GUID::CheckGUIDFormat),
                    R"#(Check the format of a GUID string. It checks the size, the position of the '-' and the correct size of fields.)#"  , py::arg("aGuid")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Standard_MMgrRoot from ./opencascade/Standard_MMgrRoot.hxx
    klass = m.attr("Standard_MMgrRoot");


    // nested enums

    static_cast<py::class_<Standard_MMgrRoot , shared_ptr<Standard_MMgrRoot> ,Py_Standard_MMgrRoot >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("Allocate",
             (void * (Standard_MMgrRoot::*)(  const size_t  ) ) static_cast<void * (Standard_MMgrRoot::*)(  const size_t  ) >(&Standard_MMgrRoot::Allocate),
             R"#(Allocate specified number of bytes. The actually allocated space should be rounded up to double word size (4 bytes), as this is expected by implementation of some classes in OCC (e.g. TCollection_AsciiString))#"  , py::arg("theSize")
          )
        .def("Reallocate",
             (void * (Standard_MMgrRoot::*)( void * ,   const size_t  ) ) static_cast<void * (Standard_MMgrRoot::*)( void * ,   const size_t  ) >(&Standard_MMgrRoot::Reallocate),
             R"#(Reallocate previously allocated memory to contain at least theSize bytes. In case of success, new pointer is returned.)#"  , py::arg("thePtr"),  py::arg("theSize")
          )
        .def("Free",
             (void (Standard_MMgrRoot::*)( void *  ) ) static_cast<void (Standard_MMgrRoot::*)( void *  ) >(&Standard_MMgrRoot::Free),
             R"#(Frees previously allocated memory at specified address.)#"  , py::arg("thePtr")
          )
        .def("Purge",
             (int (Standard_MMgrRoot::*)( bool  ) ) static_cast<int (Standard_MMgrRoot::*)( bool  ) >(&Standard_MMgrRoot::Purge),
             R"#(Purge internally cached unused memory blocks (if any) by releasing them to the operating system. Must return non-zero if some memory has been actually released, or zero otherwise.)#"  , py::arg("isDestroyed")=static_cast<bool>(false)
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Standard_Mutex from ./opencascade/Standard_Mutex.hxx
    klass = m.attr("Standard_Mutex");


    // nested enums

    static_cast<py::class_<Standard_Mutex , shared_ptr<Standard_Mutex>  >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
        .def("Lock",
             (void (Standard_Mutex::*)() ) static_cast<void (Standard_Mutex::*)() >(&Standard_Mutex::Lock),
             R"#(Method to lock the mutex; waits until the mutex is released by other threads, locks it and then returns)#" 
          )
        .def("TryLock",
             (bool (Standard_Mutex::*)() ) static_cast<bool (Standard_Mutex::*)() >(&Standard_Mutex::TryLock),
             R"#(Method to test the mutex; if the mutex is not hold by other thread, locks it and returns True; otherwise returns False without waiting mutex to be released.)#" 
          )
        .def("Unlock",
             (void (Standard_Mutex::*)() ) static_cast<void (Standard_Mutex::*)() >(&Standard_Mutex::Unlock),
             R"#(Method to unlock the mutex; releases it to other users)#" 
          )
        .def("Unlock",
             (void (Standard_Mutex::*)() ) static_cast<void (Standard_Mutex::*)() >(&Standard_Mutex::Unlock),
             R"#(Method to unlock the mutex; releases it to other users)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Standard_ReadBuffer from ./opencascade/Standard_ReadBuffer.hxx
    klass = m.attr("Standard_ReadBuffer");


    // nested enums

    static_cast<py::class_<Standard_ReadBuffer , shared_ptr<Standard_ReadBuffer>  >>(klass)
    // constructors
        .def(py::init< int64_t,size_t,bool >()  , py::arg("theDataLen"),  py::arg("theChunkLen"),  py::arg("theIsPartialPayload")=static_cast<bool>(false) )
    // custom constructors
    // methods
        .def("Init",
             (void (Standard_ReadBuffer::*)( int64_t ,  size_t ,  bool  ) ) static_cast<void (Standard_ReadBuffer::*)( int64_t ,  size_t ,  bool  ) >(&Standard_ReadBuffer::Init),
             R"#(Initialize the buffer.)#"  , py::arg("theDataLen"),  py::arg("theChunkLen"),  py::arg("theIsPartialPayload")=static_cast<bool>(false)
          )
        .def("IsDone",
             (bool (Standard_ReadBuffer::*)() const) static_cast<bool (Standard_ReadBuffer::*)() const>(&Standard_ReadBuffer::IsDone),
             R"#(Return TRUE if amount of read bytes is equal to requested length of entire data.)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Standard_ReadLineBuffer from ./opencascade/Standard_ReadLineBuffer.hxx
    klass = m.attr("Standard_ReadLineBuffer");


    // nested enums

    static_cast<py::class_<Standard_ReadLineBuffer , shared_ptr<Standard_ReadLineBuffer>  >>(klass)
    // constructors
        .def(py::init< size_t >()  , py::arg("theMaxBufferSizeBytes") )
    // custom constructors
    // methods
        .def("Clear",
             (void (Standard_ReadLineBuffer::*)() ) static_cast<void (Standard_ReadLineBuffer::*)() >(&Standard_ReadLineBuffer::Clear),
             R"#(Clear buffer and cached values.)#" 
          )
        .def("IsMultilineMode",
             (bool (Standard_ReadLineBuffer::*)() const) static_cast<bool (Standard_ReadLineBuffer::*)() const>(&Standard_ReadLineBuffer::IsMultilineMode),
             R"#(Returns TRUE when the Multiline Mode is on; FALSE by default. Multiline modes joins several lines in file having \ at the end of line:)#" 
          )
        .def("ToPutGapInMultiline",
             (bool (Standard_ReadLineBuffer::*)() const) static_cast<bool (Standard_ReadLineBuffer::*)() const>(&Standard_ReadLineBuffer::ToPutGapInMultiline),
             R"#(Put gap space while merging lines within multiline syntax, so that the following sample: Will become "1/2/3 4/5/6" when flag is TRUE, and "1/2/35/5/6" otherwise.)#" 
          )
        .def("SetMultilineMode",
             (void (Standard_ReadLineBuffer::*)( bool ,  bool  ) ) static_cast<void (Standard_ReadLineBuffer::*)( bool ,  bool  ) >(&Standard_ReadLineBuffer::SetMultilineMode),
             R"#(Sets or unsets the multi-line mode.)#"  , py::arg("theMultilineMode"),  py::arg("theToPutGap")=static_cast<bool>(true)
          )
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Standard_Static_Assert<true> from ./opencascade/Standard_Assert.hxx
    klass = m.attr("Standard_Static_Assert_true");

    // default constructor
    register_default_constructor<Standard_Static_Assert<true> , shared_ptr<Standard_Static_Assert<true>>>(m,"Standard_Static_Assert_true");

    // nested enums

    static_cast<py::class_<Standard_Static_Assert<true> , shared_ptr<Standard_Static_Assert<true>>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("assert_ok_s",
                    (void (*)() ) static_cast<void (*)() >(&Standard_Static_Assert<true>::assert_ok),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Standard_Transient from ./opencascade/Standard_Transient.hxx
    klass = m.attr("Standard_Transient");


    // nested enums

    static_cast<py::class_<Standard_Transient ,opencascade::handle<Standard_Transient>  >>(klass)
    // constructors
        .def(py::init<  >()  )
        .def(py::init<  const Standard_Transient & >()  , py::arg("arg0") )
    // custom constructors
    // methods
        .def("IsInstance",
             (bool (Standard_Transient::*)(  const handle<Standard_Type> &  ) const) static_cast<bool (Standard_Transient::*)(  const handle<Standard_Type> &  ) const>(&Standard_Transient::IsInstance),
             R"#(Returns a true value if this is an instance of Type.)#"  , py::arg("theType")
          )
        .def("IsInstance",
             (bool (Standard_Transient::*)(  const char * const   ) const) static_cast<bool (Standard_Transient::*)(  const char * const   ) const>(&Standard_Transient::IsInstance),
             R"#(Returns a true value if this is an instance of TypeName.)#"  , py::arg("theTypeName")
          )
        .def("IsKind",
             (bool (Standard_Transient::*)(  const handle<Standard_Type> &  ) const) static_cast<bool (Standard_Transient::*)(  const handle<Standard_Type> &  ) const>(&Standard_Transient::IsKind),
             R"#(Returns true if this is an instance of Type or an instance of any class that inherits from Type. Note that multiple inheritance is not supported by OCCT RTTI mechanism.)#"  , py::arg("theType")
          )
        .def("IsKind",
             (bool (Standard_Transient::*)(  const char * const   ) const) static_cast<bool (Standard_Transient::*)(  const char * const   ) const>(&Standard_Transient::IsKind),
             R"#(Returns true if this is an instance of TypeName or an instance of any class that inherits from TypeName. Note that multiple inheritance is not supported by OCCT RTTI mechanism.)#"  , py::arg("theTypeName")
          )
        .def("This",
             (Standard_Transient * (Standard_Transient::*)() const) static_cast<Standard_Transient * (Standard_Transient::*)() const>(&Standard_Transient::This),
             R"#(Returns non-const pointer to this object (like const_cast). For protection against creating handle to objects allocated in stack or call from constructor, it will raise exception Standard_ProgramError if reference counter is zero.)#" 
          )
        .def("GetRefCount",
             (int (Standard_Transient::*)() const) static_cast<int (Standard_Transient::*)() const>(&Standard_Transient::GetRefCount),
             R"#(Get the reference counter of this object)#" 
          )
        .def("IncrementRefCounter",
             (void (Standard_Transient::*)() ) static_cast<void (Standard_Transient::*)() >(&Standard_Transient::IncrementRefCounter),
             R"#(Increments the reference counter of this object. Uses relaxed memory ordering since incrementing only requires atomicity, not synchronization with other memory operations.)#" 
          )
        .def("DecrementRefCounter",
             (int (Standard_Transient::*)() ) static_cast<int (Standard_Transient::*)() >(&Standard_Transient::DecrementRefCounter),
             R"#(Decrements the reference counter of this object; returns the decremented value. Uses release ordering for the decrement to ensure all writes to the object are visible before the count reaches zero. An acquire fence is added only when the count reaches zero, ensuring proper synchronization before deletion. This is more efficient than using acq_rel for every decrement.)#" 
          )
        .def("Delete",
             (void (Standard_Transient::*)() const) static_cast<void (Standard_Transient::*)() const>(&Standard_Transient::Delete),
             R"#(Memory deallocator for transient classes)#" 
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&Standard_Transient::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&Standard_Transient::get_type_descriptor),
                    R"#(Returns type descriptor of Standard_Transient class)#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (Standard_Transient::*)() const) static_cast< const handle<Standard_Type> & (Standard_Transient::*)() const>(&Standard_Transient::DynamicType),
             R"#(Returns a type descriptor about this object.)#"
             
         )
;

    // Class Standard_UUID from ./opencascade/Standard_UUID.hxx
    klass = m.attr("Standard_UUID");

    // default constructor
    register_default_constructor<Standard_UUID , shared_ptr<Standard_UUID>>(m,"Standard_UUID");

    // nested enums

    static_cast<py::class_<Standard_UUID , shared_ptr<Standard_UUID>  >>(klass)
    // constructors
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Standard_MMgrOpt from ./opencascade/Standard_MMgrOpt.hxx
    klass = m.attr("Standard_MMgrOpt");


    // nested enums

    static_cast<py::class_<Standard_MMgrOpt , shared_ptr<Standard_MMgrOpt>  , Standard_MMgrRoot >>(klass)
    // constructors
        .def(py::init<  const bool, const bool, const size_t, const int, const size_t >()  , py::arg("aClear")=static_cast< const bool>(true),  py::arg("aMMap")=static_cast< const bool>(true),  py::arg("aCellSize")=static_cast< const size_t>(200),  py::arg("aNbPages")=static_cast< const int>(10000),  py::arg("aThreshold")=static_cast< const size_t>(40000) )
    // custom constructors
    // methods
        .def("Allocate",
             (void * (Standard_MMgrOpt::*)(  const size_t  ) ) static_cast<void * (Standard_MMgrOpt::*)(  const size_t  ) >(&Standard_MMgrOpt::Allocate),
             R"#(Allocate aSize bytes; see class description above)#"  , py::arg("aSize")
          )
        .def("Reallocate",
             (void * (Standard_MMgrOpt::*)( void * ,   const size_t  ) ) static_cast<void * (Standard_MMgrOpt::*)( void * ,   const size_t  ) >(&Standard_MMgrOpt::Reallocate),
             R"#(Reallocate previously allocated aPtr to a new size; new address is returned. In case that aPtr is null, the function behaves exactly as Allocate.)#"  , py::arg("thePtr"),  py::arg("theSize")
          )
        .def("Free",
             (void (Standard_MMgrOpt::*)( void *  ) ) static_cast<void (Standard_MMgrOpt::*)( void *  ) >(&Standard_MMgrOpt::Free),
             R"#(Free previously allocated block. Note that block can not all blocks are released to the OS by this method (see class description))#"  , py::arg("thePtr")
          )
        .def("Purge",
             (int (Standard_MMgrOpt::*)( bool  ) ) static_cast<int (Standard_MMgrOpt::*)( bool  ) >(&Standard_MMgrOpt::Purge),
             R"#(Release medium-sized blocks of memory in free lists to the system. Returns number of actually freed blocks)#"  , py::arg("isDestroyed")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("SetCallBackFunction_s",
                    (void (*)( Standard_MMgrOpt::TPCallBackFunc  ) ) static_cast<void (*)( Standard_MMgrOpt::TPCallBackFunc  ) >(&Standard_MMgrOpt::SetCallBackFunction),
                    R"#(Set the callback function. You may pass 0 there to turn off the callback. The callback function, if set, will be automatically called from within Allocate and Free methods.)#"  , py::arg("pFunc")
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
;

    // Class Standard_Persistent from ./opencascade/Standard_Persistent.hxx
    klass = m.attr("Standard_Persistent");


    // nested enums

    static_cast<py::class_<Standard_Persistent ,opencascade::handle<Standard_Persistent>  , Standard_Transient >>(klass)
    // constructors
        .def(py::init<  >()  )
    // custom constructors
    // methods
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&Standard_Persistent::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&Standard_Persistent::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("DynamicType",
             ( const handle<Standard_Type> & (Standard_Persistent::*)() const) static_cast< const handle<Standard_Type> & (Standard_Persistent::*)() const>(&Standard_Persistent::DynamicType),
             R"#()#"
             
         )
       .def_property("TypeNum",
                     [](Standard_Persistent& self){return self.TypeNum();} ,
                     [](Standard_Persistent& self, int  val){self.TypeNum() = val;},                      R"#()#"
         )
;

    // Class Standard_Type from ./opencascade/Standard_Type.hxx
    klass = m.attr("Standard_Type");


    // nested enums

    static_cast<py::class_<Standard_Type ,opencascade::handle<Standard_Type>  , Standard_Transient >>(klass)
    // constructors
    // custom constructors
    // methods
        .def("SystemName",
             ( const char * (Standard_Type::*)() const) static_cast< const char * (Standard_Type::*)() const>(&Standard_Type::SystemName),
             R"#(Returns the system type name of the class (typeinfo.name))#" 
          )
        .def("Name",
             ( const char * (Standard_Type::*)() const) static_cast< const char * (Standard_Type::*)() const>(&Standard_Type::Name),
             R"#(Returns the given name of the class type (get_type_name))#" 
          )
        .def("Size",
             (size_t (Standard_Type::*)() const) static_cast<size_t (Standard_Type::*)() const>(&Standard_Type::Size),
             R"#(Returns the size of the class instance in bytes)#" 
          )
        .def("SubType",
             (bool (Standard_Type::*)(  const handle<Standard_Type> &  ) const) static_cast<bool (Standard_Type::*)(  const handle<Standard_Type> &  ) const>(&Standard_Type::SubType),
             R"#(Returns True if this type is the same as theOther, or inherits from theOther. Note that multiple inheritance is not supported.)#"  , py::arg("theOther")
          )
        .def("SubType",
             (bool (Standard_Type::*)(  const char * const   ) const) static_cast<bool (Standard_Type::*)(  const char * const   ) const>(&Standard_Type::SubType),
             R"#(Returns True if this type is the same as theOther, or inherits from theOther. Note that multiple inheritance is not supported.)#"  , py::arg("theOther")
          )
        .def("Print",
             (void (Standard_Type::*)( Standard_OStream &  ) const) static_cast<void (Standard_Type::*)( Standard_OStream &  ) const>(&Standard_Type::Print),
             R"#(Prints type (address of descriptor + name) to a stream)#"  , py::arg("theStream")
          )
    // methods using call by reference i.s.o. return
    // static methods
        .def_static("Register_s",
                    (Standard_Type * (*)(  const std::type_info & ,   const char * ,  size_t ,   const handle<Standard_Type> &  ) ) static_cast<Standard_Type * (*)(  const std::type_info & ,   const char * ,  size_t ,   const handle<Standard_Type> &  ) >(&Standard_Type::Register),
                    R"#(Register a type; returns either new or existing descriptor.)#"  , py::arg("theInfo"),  py::arg("theName"),  py::arg("theSize"),  py::arg("theParent")
          )
        .def_static("get_type_name_s",
                    ( const char * (*)() ) static_cast< const char * (*)() >(&Standard_Type::get_type_name),
                    R"#()#" 
          )
        .def_static("get_type_descriptor_s",
                    ( const handle<Standard_Type> & (*)() ) static_cast< const handle<Standard_Type> & (*)() >(&Standard_Type::get_type_descriptor),
                    R"#()#" 
          )
    // static methods using call by reference i.s.o. return
    // operators
    // additional methods and static methods
    // properties
    // methods returning by ref wrapped as properties
       .def("Parent",
             ( const handle<Standard_Type> & (Standard_Type::*)() const) static_cast< const handle<Standard_Type> & (Standard_Type::*)() const>(&Standard_Type::Parent),
             R"#(Returns descriptor of the base class in the hierarchy)#"
             
         )
       .def("DynamicType",
             ( const handle<Standard_Type> & (Standard_Type::*)() const) static_cast< const handle<Standard_Type> & (Standard_Type::*)() const>(&Standard_Type::DynamicType),
             R"#()#"
             
         )
;

// functions
auto mocc = static_cast<py::module>(m.attr("occ"));

// ./opencascade/Standard.hxx
// ./opencascade/Standard_AbortiveTransaction.hxx
// ./opencascade/Standard_ArrayStreamBuffer.hxx
// ./opencascade/Standard_Assert.hxx
    m.def("Standard_ASSERT_DO_NOTHING",
          (void (*)())  static_cast<void (*)()>(&Standard_ASSERT_DO_NOTHING),
          R"#(This header file defines a set of ASSERT macros intended for use in algorithms for debugging purposes and as a tool to organise checks for abnormal situations in the uniform way.)#" 
          );
// ./opencascade/Standard_Atomic.hxx
    m.def("Standard_Atomic_Increment",
          (int (*)( volatile int *  ))  static_cast<int (*)( volatile int *  )>(&Standard_Atomic_Increment),
          R"#(Increments atomically integer variable pointed by theValue and returns resulting incremented value.)#"  , py::arg("theValue")
          );
    m.def("Standard_Atomic_Decrement",
          (int (*)( volatile int *  ))  static_cast<int (*)( volatile int *  )>(&Standard_Atomic_Decrement),
          R"#(Decrements atomically integer variable pointed by theValue and returns resulting decremented value.)#"  , py::arg("theValue")
          );
    m.def("Standard_Atomic_CompareAndSwap",
          (bool (*)( volatile int * ,  int ,  int  ))  static_cast<bool (*)( volatile int * ,  int ,  int  )>(&Standard_Atomic_CompareAndSwap),
          R"#(Perform an atomic compare and swap. That is, if the current value of *theValue is theOldValue, then write theNewValue into *theValue.)#"  , py::arg("theValue"),  py::arg("theOldValue"),  py::arg("theNewValue")
          );
    m.def("Standard_Atomic_Increment",
          (int (*)( volatile int *  ))  static_cast<int (*)( volatile int *  )>(&Standard_Atomic_Increment),
          R"#(Increments atomically integer variable pointed by theValue and returns resulting incremented value.)#"  , py::arg("theValue")
          );
    m.def("Standard_Atomic_Decrement",
          (int (*)( volatile int *  ))  static_cast<int (*)( volatile int *  )>(&Standard_Atomic_Decrement),
          R"#(Decrements atomically integer variable pointed by theValue and returns resulting decremented value.)#"  , py::arg("theValue")
          );
    m.def("Standard_Atomic_CompareAndSwap",
          (bool (*)( volatile int * ,  int ,  int  ))  static_cast<bool (*)( volatile int * ,  int ,  int  )>(&Standard_Atomic_CompareAndSwap),
          R"#(Perform an atomic compare and swap. That is, if the current value of *theValue is theOldValue, then write theNewValue into *theValue.)#"  , py::arg("theValue"),  py::arg("theOldValue"),  py::arg("theNewValue")
          );
// ./opencascade/Standard_Boolean.hxx
// ./opencascade/Standard_Byte.hxx
// ./opencascade/Standard_CLocaleSentry.hxx
// ./opencascade/Standard_CString.hxx
    m.def("IsEqual",
          (bool (*)(  const char * const  ,   const char * const   ))  static_cast<bool (*)(  const char * const  ,   const char * const   )>(&IsEqual),
          R"#(Returns Standard_True if two strings are equal)#"  , py::arg("theOne"),  py::arg("theTwo")
          );
// ./opencascade/Standard_CStringHasher.hxx
// ./opencascade/Standard_Character.hxx
    m.def("IsEqual",
          (bool (*)(  const char ,   const char  ))  static_cast<bool (*)(  const char ,   const char  )>(&IsEqual),
          R"#()#"  , py::arg("One"),  py::arg("Two")
          );
    m.def("IsAlphabetic",
          (bool (*)(  const char  ))  static_cast<bool (*)(  const char  )>(&IsAlphabetic),
          R"#()#"  , py::arg("me")
          );
    m.def("IsDigit",
          (bool (*)(  const char  ))  static_cast<bool (*)(  const char  )>(&IsDigit),
          R"#()#"  , py::arg("me")
          );
    m.def("IsXDigit",
          (bool (*)(  const char  ))  static_cast<bool (*)(  const char  )>(&IsXDigit),
          R"#()#"  , py::arg("me")
          );
    m.def("IsAlphanumeric",
          (bool (*)(  const char  ))  static_cast<bool (*)(  const char  )>(&IsAlphanumeric),
          R"#()#"  , py::arg("me")
          );
    m.def("IsControl",
          (bool (*)(  const char  ))  static_cast<bool (*)(  const char  )>(&IsControl),
          R"#()#"  , py::arg("me")
          );
    m.def("IsGraphic",
          (bool (*)(  const char  ))  static_cast<bool (*)(  const char  )>(&IsGraphic),
          R"#()#"  , py::arg("me")
          );
    m.def("IsLowerCase",
          (bool (*)(  const char  ))  static_cast<bool (*)(  const char  )>(&IsLowerCase),
          R"#()#"  , py::arg("me")
          );
    m.def("IsPrintable",
          (bool (*)(  const char  ))  static_cast<bool (*)(  const char  )>(&IsPrintable),
          R"#()#"  , py::arg("me")
          );
    m.def("IsPunctuation",
          (bool (*)(  const char  ))  static_cast<bool (*)(  const char  )>(&IsPunctuation),
          R"#()#"  , py::arg("me")
          );
    m.def("IsSpace",
          (bool (*)(  const char  ))  static_cast<bool (*)(  const char  )>(&IsSpace),
          R"#()#"  , py::arg("me")
          );
    m.def("IsUpperCase",
          (bool (*)(  const char  ))  static_cast<bool (*)(  const char  )>(&IsUpperCase),
          R"#()#"  , py::arg("me")
          );
    m.def("LowerCase",
          (char (*)(  const char  ))  static_cast<char (*)(  const char  )>(&LowerCase),
          R"#()#"  , py::arg("me")
          );
    m.def("UpperCase",
          (char (*)(  const char  ))  static_cast<char (*)(  const char  )>(&UpperCase),
          R"#()#"  , py::arg("me")
          );
// ./opencascade/Standard_Condition.hxx
// ./opencascade/Standard_ConstructionError.hxx
// ./opencascade/Standard_DefineAlloc.hxx
// ./opencascade/Standard_DefineException.hxx
// ./opencascade/Standard_DefineHandle.hxx
// ./opencascade/Standard_DimensionError.hxx
// ./opencascade/Standard_DimensionMismatch.hxx
// ./opencascade/Standard_DivideByZero.hxx
// ./opencascade/Standard_DomainError.hxx
// ./opencascade/Standard_Dump.hxx
// ./opencascade/Standard_ErrorHandler.hxx
// ./opencascade/Standard_ExtCharacter.hxx
    m.def("ToExtCharacter",
          (char16_t (*)(  const char  ))  static_cast<char16_t (*)(  const char  )>(&ToExtCharacter),
          R"#()#"  , py::arg("achar")
          );
    m.def("ToCharacter",
          (char (*)(  const char16_t  ))  static_cast<char (*)(  const char16_t  )>(&ToCharacter),
          R"#()#"  , py::arg("achar")
          );
    m.def("IsAnAscii",
          (bool (*)(  const char16_t  ))  static_cast<bool (*)(  const char16_t  )>(&IsAnAscii),
          R"#()#"  , py::arg("achar")
          );
    m.def("IsEqual",
          (bool (*)(  const char16_t ,   const char16_t  ))  static_cast<bool (*)(  const char16_t ,   const char16_t  )>(&IsEqual),
          R"#()#"  , py::arg("One"),  py::arg("Two")
          );
// ./opencascade/Standard_Failure.hxx
// ./opencascade/Standard_GUID.hxx
// ./opencascade/Standard_HashUtils.hxx
// ./opencascade/Standard_IStream.hxx
// ./opencascade/Standard_ImmutableObject.hxx
// ./opencascade/Standard_Integer.hxx
    m.def("Abs",
          (int (*)(  const int  ))  static_cast<int (*)(  const int  )>(&Abs),
          R"#(Returns the absolute value of a int Value. Equivalent to std::abs.)#"  , py::arg("theValue")
          );
    m.def("IsEven",
          (bool (*)(  const int  ))  static_cast<bool (*)(  const int  )>(&IsEven),
          R"#(Returns true if theValue is even.)#"  , py::arg("theValue")
          );
    m.def("IsOdd",
          (bool (*)(  const int  ))  static_cast<bool (*)(  const int  )>(&IsOdd),
          R"#(Returns true if theValue is odd.)#"  , py::arg("theValue")
          );
    m.def("Max",
          (int (*)(  const int ,   const int  ))  static_cast<int (*)(  const int ,   const int  )>(&Max),
          R"#(Returns the maximum value of two integers. Equivalent to std::max.)#"  , py::arg("theValue1"),  py::arg("theValue2")
          );
    m.def("Min",
          (int (*)(  const int ,   const int  ))  static_cast<int (*)(  const int ,   const int  )>(&Min),
          R"#(Returns the minimum value of two integers. Equivalent to std::min.)#"  , py::arg("theValue1"),  py::arg("theValue2")
          );
    m.def("Modulus",
          (int (*)(  const int ,   const int  ))  static_cast<int (*)(  const int ,   const int  )>(&Modulus),
          R"#(Returns the modulus of theValue by theDivisor.)#"  , py::arg("theValue"),  py::arg("theDivisor")
          );
    m.def("Square",
          (int (*)(  const int  ))  static_cast<int (*)(  const int  )>(&Square),
          R"#(Returns the square of a int theValue. Note that behavior is undefined in case of overflow.)#"  , py::arg("theValue")
          );
    m.def("IntegerFirst",
          (int (*)())  static_cast<int (*)()>(&IntegerFirst),
          R"#(Returns the minimum value of an integer.)#" 
          );
    m.def("IntegerLast",
          (int (*)())  static_cast<int (*)()>(&IntegerLast),
          R"#(Returns the maximum value of an integer.)#" 
          );
    m.def("IntegerSize",
          (int (*)())  static_cast<int (*)()>(&IntegerSize),
          R"#(Returns the size in bits of an integer.)#" 
          );
// ./opencascade/Standard_LicenseError.hxx
// ./opencascade/Standard_LicenseNotFound.hxx
// ./opencascade/Standard_MMgrOpt.hxx
// ./opencascade/Standard_MMgrRoot.hxx
// ./opencascade/Standard_Macro.hxx
// ./opencascade/Standard_MultiplyDefined.hxx
// ./opencascade/Standard_Mutex.hxx
// ./opencascade/Standard_NegativeValue.hxx
// ./opencascade/Standard_NoMoreObject.hxx
// ./opencascade/Standard_NoSuchObject.hxx
// ./opencascade/Standard_NotImplemented.hxx
// ./opencascade/Standard_NullObject.hxx
// ./opencascade/Standard_NullValue.hxx
// ./opencascade/Standard_NumericError.hxx
// ./opencascade/Standard_OStream.hxx
// ./opencascade/Standard_OutOfMemory.hxx
// ./opencascade/Standard_OutOfRange.hxx
// ./opencascade/Standard_Overflow.hxx
// ./opencascade/Standard_PByte.hxx
// ./opencascade/Standard_PCharacter.hxx
// ./opencascade/Standard_PExtCharacter.hxx
// ./opencascade/Standard_Persistent.hxx
// ./opencascade/Standard_ProgramError.hxx
// ./opencascade/Standard_RangeError.hxx
// ./opencascade/Standard_ReadBuffer.hxx
// ./opencascade/Standard_ReadLineBuffer.hxx
// ./opencascade/Standard_Real.hxx
    m.def("ACos",
          (double (*)(  const double  ))  static_cast<double (*)(  const double  )>(&ACos),
          R"#(Returns the value of the arc cosine of a theValue.)#"  , py::arg("theValue")
          );
    m.def("ACosApprox",
          (double (*)(  const double  ))  static_cast<double (*)(  const double  )>(&ACosApprox),
          R"#(Returns the approximate value of the arc cosine theValue. The max error is about 1 degree near Value=0. NOTE: Avoid using this function in new code, it presumably slower then std::acos.)#"  , py::arg("theValue")
          );
    m.def("ASin",
          (double (*)(  const double  ))  static_cast<double (*)(  const double  )>(&ASin),
          R"#(Returns the value of the arc sine of a theValue.)#"  , py::arg("theValue")
          );
    m.def("ATan2",
          (double (*)(  const double ,   const double  ))  static_cast<double (*)(  const double ,   const double  )>(&ATan2),
          R"#(Computes the arc tangent of theX divided by theY using the signs of both arguments to determine the quadrant of the return value.)#"  , py::arg("theX"),  py::arg("theY")
          );
    m.def("ATanh",
          (double (*)(  const double  ))  static_cast<double (*)(  const double  )>(&ATanh),
          R"#(Returns the value of the hyperbolic arc tangent of theValue.)#"  , py::arg("theValue")
          );
    m.def("ACosh",
          (double (*)(  const double  ))  static_cast<double (*)(  const double  )>(&ACosh),
          R"#(Returns the value of the hyperbolic arc cosine of theValue.)#"  , py::arg("theValue")
          );
    m.def("Cosh",
          (double (*)(  const double  ))  static_cast<double (*)(  const double  )>(&Cosh),
          R"#(Returns the hyperbolic cosine of a double theValue.)#"  , py::arg("theValue")
          );
    m.def("Sinh",
          (double (*)(  const double  ))  static_cast<double (*)(  const double  )>(&Sinh),
          R"#(Returns the hyperbolic sine of a double theValue.)#"  , py::arg("theValue")
          );
    m.def("Log",
          (double (*)(  const double  ))  static_cast<double (*)(  const double  )>(&Log),
          R"#(Computes the natural (base-e) logarithm of number theValue.)#"  , py::arg("theValue")
          );
    m.def("Sqrt",
          (double (*)(  const double  ))  static_cast<double (*)(  const double  )>(&Sqrt),
          R"#(Returns the square root of a double theValue.)#"  , py::arg("theValue")
          );
    m.def("NextAfter",
          (double (*)(  const double ,   const double  ))  static_cast<double (*)(  const double ,   const double  )>(&NextAfter),
          R"#(Returns the next representable value of a double theValue in the direction of theDirection. Equivalent to std::nextafter.)#"  , py::arg("theValue"),  py::arg("theDirection")
          );
    m.def("Sign",
          (double (*)(  const double ,   const double  ))  static_cast<double (*)(  const double ,   const double  )>(&Sign),
          R"#(Composes a floating point value with the magnitude of theMagnitude and the sign of theSign. Equivalent to std::copysign.)#"  , py::arg("theMagnitude"),  py::arg("theSign")
          );
    m.def("RealSmall",
          (double (*)())  static_cast<double (*)()>(&RealSmall),
          R"#(Returns the minimum positive double value greater than zero.)#" 
          );
    m.def("Abs",
          (double (*)(  const double  ))  static_cast<double (*)(  const double  )>(&Abs),
          R"#(Returns the absolute value of a double Value. Equivalent to std::abs.)#"  , py::arg("theValue")
          );
    m.def("IsEqual",
          (bool (*)(  const double ,   const double  ))  static_cast<bool (*)(  const double ,   const double  )>(&IsEqual),
          R"#(Returns Standard_True if two doubles are equal within the precision defined by RealSmall().)#"  , py::arg("theValue1"),  py::arg("theValue2")
          );
    m.def("RealDigits",
          (int (*)())  static_cast<int (*)()>(&RealDigits),
          R"#(Returns the number of digits of precision in a double.)#" 
          );
    m.def("RealEpsilon",
          (double (*)())  static_cast<double (*)()>(&RealEpsilon),
          R"#(Returns the minimum positive double such that 1.0 + RealEpsilon() != 1.0.)#" 
          );
    m.def("RealFirst",
          (double (*)())  static_cast<double (*)()>(&RealFirst),
          R"#(Returns the minimum value of a double.)#" 
          );
    m.def("RealFirst10Exp",
          (int (*)())  static_cast<int (*)()>(&RealFirst10Exp),
          R"#(Returns the minimum value of exponent(base 10) of a double.)#" 
          );
    m.def("RealLast",
          (double (*)())  static_cast<double (*)()>(&RealLast),
          R"#(Returns the maximum value of a double.)#" 
          );
    m.def("RealLast10Exp",
          (int (*)())  static_cast<int (*)()>(&RealLast10Exp),
          R"#(Returns the maximum value of exponent(base 10) of a double.)#" 
          );
    m.def("RealMantissa",
          (int (*)())  static_cast<int (*)()>(&RealMantissa),
          R"#(Returns the size in bits of the mantissa part of a double.)#" 
          );
    m.def("RealRadix",
          (int (*)())  static_cast<int (*)()>(&RealRadix),
          R"#(Returns the radix of a double.)#" 
          );
    m.def("RealSize",
          (int (*)())  static_cast<int (*)()>(&RealSize),
          R"#(Returns the size in bits of a double.)#" 
          );
    m.def("IntToReal",
          (double (*)(  const int  ))  static_cast<double (*)(  const int  )>(&IntToReal),
          R"#(Converts a int theValue to a double.)#"  , py::arg("theValue")
          );
    m.def("ATan",
          (double (*)(  const double  ))  static_cast<double (*)(  const double  )>(&ATan),
          R"#(Returns the value of the arc tangent of a double theValue.)#"  , py::arg("theValue")
          );
    m.def("Ceiling",
          (double (*)(  const double  ))  static_cast<double (*)(  const double  )>(&Ceiling),
          R"#(Returns the next integer greater than or equal to a double theValue.)#"  , py::arg("theValue")
          );
    m.def("Cos",
          (double (*)(  const double  ))  static_cast<double (*)(  const double  )>(&Cos),
          R"#(Returns the cosine of a double theValue. Equivalent to std::cos.)#"  , py::arg("theValue")
          );
    m.def("Epsilon",
          (double (*)(  const double  ))  static_cast<double (*)(  const double  )>(&Epsilon),
          R"#(The function returns absolute value of difference between theValue and other nearest value of double type. Nearest value is chosen in direction of infinity the same sign as theValue. If theValue is 0 then returns minimal positive value of double type.)#"  , py::arg("theValue")
          );
    m.def("Exp",
          (double (*)(  const double  ))  static_cast<double (*)(  const double  )>(&Exp),
          R"#(Returns the exponential of a double theValue. Equivalent to std::exp.)#"  , py::arg("theValue")
          );
    m.def("Floor",
          (double (*)(  const double  ))  static_cast<double (*)(  const double  )>(&Floor),
          R"#(Returns the nearest integer less than or equal to a double theValue. Equivalent to std::floor.)#"  , py::arg("theValue")
          );
    m.def("IntegerPart",
          (double (*)(  const double  ))  static_cast<double (*)(  const double  )>(&IntegerPart),
          R"#(Returns the integer part of a double theValue. Equivalent to std::trunc.)#"  , py::arg("theValue")
          );
    m.def("Log10",
          (double (*)(  const double  ))  static_cast<double (*)(  const double  )>(&Log10),
          R"#(Returns the logarithm to base 10 of a double theValue. Equivalent to std::log10.)#"  , py::arg("theValue")
          );
    m.def("Max",
          (double (*)(  const double ,   const double  ))  static_cast<double (*)(  const double ,   const double  )>(&Max),
          R"#(Returns the maximum value of two doubles. Equivalent to std::max.)#"  , py::arg("theValue1"),  py::arg("theValue2")
          );
    m.def("Min",
          (double (*)(  const double ,   const double  ))  static_cast<double (*)(  const double ,   const double  )>(&Min),
          R"#(Returns the minimum value of two doubles. Equivalent to std::min.)#"  , py::arg("theValue1"),  py::arg("theValue2")
          );
    m.def("Pow",
          (double (*)(  const double ,   const double  ))  static_cast<double (*)(  const double ,   const double  )>(&Pow),
          R"#(Returns a double theValue raised to the power of thePower.)#"  , py::arg("theValue"),  py::arg("thePower")
          );
    m.def("RealPart",
          (double (*)(  const double  ))  static_cast<double (*)(  const double  )>(&RealPart),
          R"#(Returns the fractional part of a double theValue. Always non-negative.)#"  , py::arg("theValue")
          );
    m.def("RealToInt",
          (int (*)(  const double  ))  static_cast<int (*)(  const double  )>(&RealToInt),
          R"#(Converts a double theValue to the nearest valid int. If input value is out of valid range for int, minimal or maximal possible int is returned.)#"  , py::arg("theValue")
          );
    m.def("RealToShortReal",
          (float (*)(  const double  ))  static_cast<float (*)(  const double  )>(&RealToShortReal),
          R"#(Converts a double theValue to the nearest valid float. If input value is out of valid range for float, minimal or maximal possible float is returned.)#"  , py::arg("theValue")
          );
    m.def("Round",
          (double (*)(  const double  ))  static_cast<double (*)(  const double  )>(&Round),
          R"#(Returns the nearest integer of a double theValue. Equivalent to std::round.)#"  , py::arg("theValue")
          );
    m.def("Sin",
          (double (*)(  const double  ))  static_cast<double (*)(  const double  )>(&Sin),
          R"#(Returns the sine of a double theValue. Equivalent to std::sin.)#"  , py::arg("theValue")
          );
    m.def("ASinh",
          (double (*)(  const double  ))  static_cast<double (*)(  const double  )>(&ASinh),
          R"#(Returns the hyperbolic arc sine of a double theValue. Equivalent to std::asinh.)#"  , py::arg("theValue")
          );
    m.def("Square",
          (double (*)(  const double  ))  static_cast<double (*)(  const double  )>(&Square),
          R"#(Returns the square of a double theValue.)#"  , py::arg("theValue")
          );
    m.def("Tan",
          (double (*)(  const double  ))  static_cast<double (*)(  const double  )>(&Tan),
          R"#(Returns the tangent of a double theValue. Equivalent to std::tan.)#"  , py::arg("theValue")
          );
    m.def("Tanh",
          (double (*)(  const double  ))  static_cast<double (*)(  const double  )>(&Tanh),
          R"#(Returns the hyperbolic tangent of a double theValue. Equivalent to std::tanh.)#"  , py::arg("theValue")
          );
// ./opencascade/Standard_SStream.hxx
// ./opencascade/Standard_ShortReal.hxx
    m.def("ShortRealSmall",
          (float (*)())  static_cast<float (*)()>(&ShortRealSmall),
          R"#(Returns the minimum positive float value.)#" 
          );
    m.def("Abs",
          (float (*)(  const float  ))  static_cast<float (*)(  const float  )>(&Abs),
          R"#(Returns the absolute value of a float Value. Equivalent to std::abs.)#"  , py::arg("theValue")
          );
    m.def("ShortRealDigits",
          (int (*)())  static_cast<int (*)()>(&ShortRealDigits),
          R"#(Returns the number of digits of precision in a float.)#" 
          );
    m.def("ShortRealEpsilon",
          (float (*)())  static_cast<float (*)()>(&ShortRealEpsilon),
          R"#(Returns the minimum positive float such that 1.0f + ShortRealEpsilon() != 1.0f.)#" 
          );
    m.def("ShortRealFirst",
          (float (*)())  static_cast<float (*)()>(&ShortRealFirst),
          R"#(Returns the minimum negative value of a float.)#" 
          );
    m.def("ShortRealFirst10Exp",
          (int (*)())  static_cast<int (*)()>(&ShortRealFirst10Exp),
          R"#(Returns the minimum value of exponent(base 10) of a float.)#" 
          );
    m.def("ShortRealLast",
          (float (*)())  static_cast<float (*)()>(&ShortRealLast),
          R"#(Returns the maximum value of a float.)#" 
          );
    m.def("ShortRealLast10Exp",
          (int (*)())  static_cast<int (*)()>(&ShortRealLast10Exp),
          R"#(Returns the maximum value of exponent(base 10) of a float.)#" 
          );
    m.def("ShortRealMantissa",
          (int (*)())  static_cast<int (*)()>(&ShortRealMantissa),
          R"#(Returns the mantissa (number of bits in the significand) of a float.)#" 
          );
    m.def("ShortRealRadix",
          (int (*)())  static_cast<int (*)()>(&ShortRealRadix),
          R"#(Returns the radix (base) of a float.)#" 
          );
    m.def("ShortRealSize",
          (int (*)())  static_cast<int (*)()>(&ShortRealSize),
          R"#(Returns the size in bits of a float.)#" 
          );
    m.def("Max",
          (float (*)(  const float ,   const float  ))  static_cast<float (*)(  const float ,   const float  )>(&Max),
          R"#(Returns the maximum value of two floats. Equivalent to std::max.)#"  , py::arg("theValue1"),  py::arg("theValue2")
          );
    m.def("Min",
          (float (*)(  const float ,   const float  ))  static_cast<float (*)(  const float ,   const float  )>(&Min),
          R"#(Returns the minimum value of two floats. Equivalent to std::min.)#"  , py::arg("theValue1"),  py::arg("theValue2")
          );
// ./opencascade/Standard_Std.hxx
// ./opencascade/Standard_ThreadId.hxx
// ./opencascade/Standard_Time.hxx
// ./opencascade/Standard_Transient.hxx
// ./opencascade/Standard_Type.hxx
// ./opencascade/Standard_TypeDef.hxx
// ./opencascade/Standard_TypeMismatch.hxx
// ./opencascade/Standard_UUID.hxx
// ./opencascade/Standard_Underflow.hxx
// ./opencascade/Standard_Version.hxx
// ./opencascade/Standard_VersionInfo.hxx
// ./opencascade/Standard_WarningDisableFunctionCast.hxx
// ./opencascade/Standard_WarningsDisable.hxx
// ./opencascade/Standard_WarningsRestore.hxx

// Additional functions


// operators

// register typdefs

// register user-defined template specializations


// exceptions
register_occ_exception<Standard_Failure>(m, "Standard_Failure");
register_occ_exception<Standard_AbortiveTransaction>(m, "Standard_AbortiveTransaction");
register_occ_exception<Standard_DomainError>(m, "Standard_DomainError");
register_occ_exception<Standard_LicenseError>(m, "Standard_LicenseError");
register_occ_exception<Standard_NumericError>(m, "Standard_NumericError");
register_occ_exception<Standard_ProgramError>(m, "Standard_ProgramError");
register_occ_exception<Standard_ConstructionError>(m, "Standard_ConstructionError");
register_occ_exception<Standard_DimensionError>(m, "Standard_DimensionError");
register_occ_exception<Standard_DivideByZero>(m, "Standard_DivideByZero");
register_occ_exception<Standard_ImmutableObject>(m, "Standard_ImmutableObject");
register_occ_exception<Standard_LicenseNotFound>(m, "Standard_LicenseNotFound");
register_occ_exception<Standard_MultiplyDefined>(m, "Standard_MultiplyDefined");
register_occ_exception<Standard_NoMoreObject>(m, "Standard_NoMoreObject");
register_occ_exception<Standard_NoSuchObject>(m, "Standard_NoSuchObject");
register_occ_exception<Standard_NotImplemented>(m, "Standard_NotImplemented");
register_occ_exception<Standard_NullObject>(m, "Standard_NullObject");
register_occ_exception<Standard_OutOfMemory>(m, "Standard_OutOfMemory");
register_occ_exception<Standard_Overflow>(m, "Standard_Overflow");
register_occ_exception<Standard_RangeError>(m, "Standard_RangeError");
register_occ_exception<Standard_TypeMismatch>(m, "Standard_TypeMismatch");
register_occ_exception<Standard_Underflow>(m, "Standard_Underflow");
register_occ_exception<Standard_DimensionMismatch>(m, "Standard_DimensionMismatch");
register_occ_exception<Standard_NegativeValue>(m, "Standard_NegativeValue");
register_occ_exception<Standard_NullValue>(m, "Standard_NullValue");
register_occ_exception<Standard_OutOfRange>(m, "Standard_OutOfRange");

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
