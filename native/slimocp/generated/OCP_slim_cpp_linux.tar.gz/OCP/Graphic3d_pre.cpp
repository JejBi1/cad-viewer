
// pybind 11 related includes
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;


// Standard Handle
#include <Standard_Handle.hxx>

// user-defined inclusion per module before includes

// includes to resolve forward declarations
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_PBRMaterial.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_CStructure.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_Camera.hxx>
#include <Graphic3d_CStructure.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_GraphicDriver.hxx>
#include <Graphic3d_StructureManager.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Aspect_NeutralWindow.hxx>
#include <Aspect_XRSession.hxx>
#include <Graphic3d_Layer.hxx>
#include <Graphic3d_StructureManager.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_Camera.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_CView.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_CView.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Aspect_DisplayConnection.hxx>
#include <Aspect_Window.hxx>
#include <Graphic3d_CView.hxx>
#include <Graphic3d_Layer.hxx>
#include <Graphic3d_StructureManager.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Aspect_DisplayConnection.hxx>
#include <Graphic3d_GraphicDriver.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_Structure.hxx>
#include <Graphic3d_ArrayOfPrimitives.hxx>
#include <Graphic3d_Text.hxx>
#include <Graphic3d_TransformPers.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_CullingTool.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Image_PixMap.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_ShaderProgram.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_LightSet.hxx>
#include <Graphic3d_ShaderProgram.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_StructureManager.hxx>
#include <Graphic3d_DataStructureManager.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Graphic3d_GraphicDriver.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Image_CompressedPixMap.hxx>
#include <Image_SupportedFormats.hxx>
#include <Graphic3d_TextureParams.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>
#include <Adaptor2d_Curve2d.hxx>
#include <Adaptor3d_Curve.hxx>
#include <Adaptor3d_Surface.hxx>

// module includes
#include <Graphic3d_AlphaMode.hxx>
#include <Graphic3d_ArrayFlags.hxx>
#include <Graphic3d_ArrayOfPoints.hxx>
#include <Graphic3d_ArrayOfPolygons.hxx>
#include <Graphic3d_ArrayOfPolylines.hxx>
#include <Graphic3d_ArrayOfPrimitives.hxx>
#include <Graphic3d_ArrayOfQuadrangles.hxx>
#include <Graphic3d_ArrayOfQuadrangleStrips.hxx>
#include <Graphic3d_ArrayOfSegments.hxx>
#include <Graphic3d_ArrayOfTriangleFans.hxx>
#include <Graphic3d_ArrayOfTriangles.hxx>
#include <Graphic3d_ArrayOfTriangleStrips.hxx>
#include <Graphic3d_AspectFillArea3d.hxx>
#include <Graphic3d_AspectLine3d.hxx>
#include <Graphic3d_AspectMarker3d.hxx>
#include <Graphic3d_Aspects.hxx>
#include <Graphic3d_AspectText3d.hxx>
#include <Graphic3d_AttribBuffer.hxx>
#include <Graphic3d_BndBox3d.hxx>
#include <Graphic3d_BndBox4d.hxx>
#include <Graphic3d_BndBox4f.hxx>
#include <Graphic3d_BoundBuffer.hxx>
#include <Graphic3d_BSDF.hxx>
#include <Graphic3d_Buffer.hxx>
#include <Graphic3d_BufferRange.hxx>
#include <Graphic3d_BufferType.hxx>
#include <Graphic3d_BvhCStructureSet.hxx>
#include <Graphic3d_BvhCStructureSetTrsfPers.hxx>
#include <Graphic3d_Camera.hxx>
#include <Graphic3d_CameraTile.hxx>
#include <Graphic3d_CappingFlags.hxx>
#include <Graphic3d_CLight.hxx>
#include <Graphic3d_ClipPlane.hxx>
#include <Graphic3d_CStructure.hxx>
#include <Graphic3d_CubeMap.hxx>
#include <Graphic3d_CubeMapOrder.hxx>
#include <Graphic3d_CubeMapPacked.hxx>
#include <Graphic3d_CubeMapSeparate.hxx>
#include <Graphic3d_CubeMapSide.hxx>
#include <Graphic3d_CullingTool.hxx>
#include <Graphic3d_CView.hxx>
#include <Graphic3d_DataStructureManager.hxx>
#include <Graphic3d_DiagnosticInfo.hxx>
#include <Graphic3d_DisplayPriority.hxx>
#include <Graphic3d_Flipper.hxx>
#include <Graphic3d_FrameStats.hxx>
#include <Graphic3d_FrameStatsCounter.hxx>
#include <Graphic3d_FrameStatsData.hxx>
#include <Graphic3d_FrameStatsTimer.hxx>
#include <Graphic3d_GraduatedTrihedron.hxx>
#include <Graphic3d_GraphicDriver.hxx>
#include <Graphic3d_GraphicDriverFactory.hxx>
#include <Graphic3d_Group.hxx>
#include <Graphic3d_GroupAspect.hxx>
#include <Graphic3d_GroupDefinitionError.hxx>
#include <Graphic3d_HatchStyle.hxx>
#include <Graphic3d_HorizontalTextAlignment.hxx>
#include <Graphic3d_IndexBuffer.hxx>
#include <Graphic3d_Layer.hxx>
#include <Graphic3d_LevelOfTextureAnisotropy.hxx>
#include <Graphic3d_LightSet.hxx>
#include <Graphic3d_MarkerImage.hxx>
#include <Graphic3d_MaterialAspect.hxx>
#include <Graphic3d_MaterialDefinitionError.hxx>
#include <Graphic3d_MediaTexture.hxx>
#include <Graphic3d_MediaTextureSet.hxx>
#include <Graphic3d_MutableIndexBuffer.hxx>
#include <Graphic3d_NameOfMaterial.hxx>
#include <Graphic3d_NameOfTexture1D.hxx>
#include <Graphic3d_NameOfTexture2D.hxx>
#include <Graphic3d_NameOfTextureEnv.hxx>
#include <Graphic3d_NameOfTexturePlane.hxx>
#include <Graphic3d_PBRMaterial.hxx>
#include <Graphic3d_PolygonOffset.hxx>
#include <Graphic3d_PresentationAttributes.hxx>
#include <Graphic3d_PriorityDefinitionError.hxx>
#include <Graphic3d_RenderingMode.hxx>
#include <Graphic3d_RenderingParams.hxx>
#include <Graphic3d_RenderTransparentMethod.hxx>
#include <Graphic3d_SequenceOfHClipPlane.hxx>
#include <Graphic3d_ShaderAttribute.hxx>
#include <Graphic3d_ShaderFlags.hxx>
#include <Graphic3d_ShaderManager.hxx>
#include <Graphic3d_ShaderObject.hxx>
#include <Graphic3d_ShaderProgram.hxx>
#include <Graphic3d_ShaderVariable.hxx>
#include <Graphic3d_StereoMode.hxx>
#include <Graphic3d_Structure.hxx>
#include <Graphic3d_StructureDefinitionError.hxx>
#include <Graphic3d_StructureManager.hxx>
#include <Graphic3d_Text.hxx>
#include <Graphic3d_TextPath.hxx>
#include <Graphic3d_Texture1D.hxx>
#include <Graphic3d_Texture1Dmanual.hxx>
#include <Graphic3d_Texture1Dsegment.hxx>
#include <Graphic3d_Texture2D.hxx>
#include <Graphic3d_Texture2Dplane.hxx>
#include <Graphic3d_Texture3D.hxx>
#include <Graphic3d_TextureEnv.hxx>
#include <Graphic3d_TextureMap.hxx>
#include <Graphic3d_TextureParams.hxx>
#include <Graphic3d_TextureRoot.hxx>
#include <Graphic3d_TextureSet.hxx>
#include <Graphic3d_TextureSetBits.hxx>
#include <Graphic3d_TextureUnit.hxx>
#include <Graphic3d_ToneMappingMethod.hxx>
#include <Graphic3d_TransformPers.hxx>
#include <Graphic3d_TransformPersScaledAbove.hxx>
#include <Graphic3d_TransformUtils.hxx>
#include <Graphic3d_TransModeFlags.hxx>
#include <Graphic3d_TypeOfAnswer.hxx>
#include <Graphic3d_TypeOfBackfacingModel.hxx>
#include <Graphic3d_TypeOfBackground.hxx>
#include <Graphic3d_TypeOfConnection.hxx>
#include <Graphic3d_TypeOfLightSource.hxx>
#include <Graphic3d_TypeOfLimit.hxx>
#include <Graphic3d_TypeOfMaterial.hxx>
#include <Graphic3d_TypeOfPrimitiveArray.hxx>
#include <Graphic3d_TypeOfReflection.hxx>
#include <Graphic3d_TypeOfShaderObject.hxx>
#include <Graphic3d_TypeOfShadingModel.hxx>
#include <Graphic3d_TypeOfStructure.hxx>
#include <Graphic3d_TypeOfTexture.hxx>
#include <Graphic3d_TypeOfTextureFilter.hxx>
#include <Graphic3d_TypeOfTextureMode.hxx>
#include <Graphic3d_TypeOfVisualization.hxx>
#include <Graphic3d_Vertex.hxx>
#include <Graphic3d_VerticalTextAlignment.hxx>
#include <Graphic3d_ViewAffinity.hxx>
#include <Graphic3d_WorldViewProjState.hxx>
#include <Graphic3d_ZLayerId.hxx>
#include <Graphic3d_ZLayerSettings.hxx>

// template related includes

#include "Graphic3d_tmpl.hxx"

#include "Graphic3d_tmpl.hxx"

#include "Graphic3d_tmpl.hxx"

#include "Graphic3d_tmpl.hxx"

#include "Graphic3d_tmpl.hxx"

#include "Graphic3d_tmpl.hxx"

#include "Graphic3d_tmpl.hxx"

#include "Graphic3d_tmpl.hxx"

#include "Graphic3d_tmpl.hxx"

#include "Graphic3d_tmpl.hxx"


// user-defined pre
#include "OCP_specific.inc"

// user-defined inclusion per module
#include <Media_PlayerContext.hxx>
struct NSOpenGLContext {};

// Module definiiton
void register_Graphic3d_enums(py::module &main_module) {


py::module m = main_module.def_submodule("Graphic3d", R"#()#");

// add namespaces as submodules

// user-defined inclusion per module in the body

// enums
    py::enum_<Graphic3d_NameOfTexture1D>(m, "Graphic3d_NameOfTexture1D",R"#(Types of standard textures.)#")
        .value("Graphic3d_NOT_1D_ELEVATION",Graphic3d_NameOfTexture1D::Graphic3d_NOT_1D_ELEVATION)
        .value("Graphic3d_NOT_1D_UNKNOWN",Graphic3d_NameOfTexture1D::Graphic3d_NOT_1D_UNKNOWN).export_values();
    m.attr("Graphic3d_ArrayFlags_None") = py::cast(int(Graphic3d_ArrayFlags_None));
    m.attr("Graphic3d_ArrayFlags_VertexNormal") = py::cast(int(Graphic3d_ArrayFlags_VertexNormal));
    m.attr("Graphic3d_ArrayFlags_VertexColor") = py::cast(int(Graphic3d_ArrayFlags_VertexColor));
    m.attr("Graphic3d_ArrayFlags_VertexTexel") = py::cast(int(Graphic3d_ArrayFlags_VertexTexel));
    m.attr("Graphic3d_ArrayFlags_BoundColor") = py::cast(int(Graphic3d_ArrayFlags_BoundColor));
    m.attr("Graphic3d_ArrayFlags_AttribsMutable") = py::cast(int(Graphic3d_ArrayFlags_AttribsMutable));
    m.attr("Graphic3d_ArrayFlags_AttribsDeinterleaved") = py::cast(int(Graphic3d_ArrayFlags_AttribsDeinterleaved));
    m.attr("Graphic3d_ArrayFlags_IndexesMutable") = py::cast(int(Graphic3d_ArrayFlags_IndexesMutable));
    py::enum_<Graphic3d_ToneMappingMethod>(m, "Graphic3d_ToneMappingMethod",R"#(Enumerates tone mapping methods.)#")
        .value("Graphic3d_ToneMappingMethod_Disabled",Graphic3d_ToneMappingMethod::Graphic3d_ToneMappingMethod_Disabled)
        .value("Graphic3d_ToneMappingMethod_Filmic",Graphic3d_ToneMappingMethod::Graphic3d_ToneMappingMethod_Filmic).export_values();
    py::enum_<Graphic3d_VerticalTextAlignment>(m, "Graphic3d_VerticalTextAlignment",R"#(Defines the vertical position of the text relative to its anchor.)#")
        .value("Graphic3d_VTA_BOTTOM",Graphic3d_VerticalTextAlignment::Graphic3d_VTA_BOTTOM)
        .value("Graphic3d_VTA_CENTER",Graphic3d_VerticalTextAlignment::Graphic3d_VTA_CENTER)
        .value("Graphic3d_VTA_TOP",Graphic3d_VerticalTextAlignment::Graphic3d_VTA_TOP)
        .value("Graphic3d_VTA_TOPFIRSTLINE",Graphic3d_VerticalTextAlignment::Graphic3d_VTA_TOPFIRSTLINE).export_values();
    py::enum_<Graphic3d_TypeOfAnswer>(m, "Graphic3d_TypeOfAnswer",R"#(The answer of the method AcceptDisplay AcceptDisplay means is it possible to display the specified structure in the specified view ? TOA_YES yes TOA_NO no TOA_COMPUTE yes but we have to compute the representation)#")
        .value("Graphic3d_TOA_YES",Graphic3d_TypeOfAnswer::Graphic3d_TOA_YES)
        .value("Graphic3d_TOA_NO",Graphic3d_TypeOfAnswer::Graphic3d_TOA_NO)
        .value("Graphic3d_TOA_COMPUTE",Graphic3d_TypeOfAnswer::Graphic3d_TOA_COMPUTE).export_values();
    py::enum_<Graphic3d_FrameStatsTimer>(m, "Graphic3d_FrameStatsTimer",R"#(Timers for collecting frame performance statistics.)#")
        .value("Graphic3d_FrameStatsTimer_ElapsedFrame",Graphic3d_FrameStatsTimer::Graphic3d_FrameStatsTimer_ElapsedFrame)
        .value("Graphic3d_FrameStatsTimer_CpuFrame",Graphic3d_FrameStatsTimer::Graphic3d_FrameStatsTimer_CpuFrame)
        .value("Graphic3d_FrameStatsTimer_CpuCulling",Graphic3d_FrameStatsTimer::Graphic3d_FrameStatsTimer_CpuCulling)
        .value("Graphic3d_FrameStatsTimer_CpuPicking",Graphic3d_FrameStatsTimer::Graphic3d_FrameStatsTimer_CpuPicking)
        .value("Graphic3d_FrameStatsTimer_CpuDynamics",Graphic3d_FrameStatsTimer::Graphic3d_FrameStatsTimer_CpuDynamics).export_values();
    m.attr("Graphic3d_FrameStatsTimer_NB") = py::cast(int(Graphic3d_FrameStatsTimer_NB));
    py::enum_<Graphic3d_TypeOfLimit>(m, "Graphic3d_TypeOfLimit",R"#(Type of graphic resource limit.)#")
        .value("Graphic3d_TypeOfLimit_MaxNbLights",Graphic3d_TypeOfLimit::Graphic3d_TypeOfLimit_MaxNbLights)
        .value("Graphic3d_TypeOfLimit_MaxNbClipPlanes",Graphic3d_TypeOfLimit::Graphic3d_TypeOfLimit_MaxNbClipPlanes)
        .value("Graphic3d_TypeOfLimit_MaxNbViews",Graphic3d_TypeOfLimit::Graphic3d_TypeOfLimit_MaxNbViews)
        .value("Graphic3d_TypeOfLimit_MaxTextureSize",Graphic3d_TypeOfLimit::Graphic3d_TypeOfLimit_MaxTextureSize)
        .value("Graphic3d_TypeOfLimit_MaxViewDumpSizeX",Graphic3d_TypeOfLimit::Graphic3d_TypeOfLimit_MaxViewDumpSizeX)
        .value("Graphic3d_TypeOfLimit_MaxViewDumpSizeY",Graphic3d_TypeOfLimit::Graphic3d_TypeOfLimit_MaxViewDumpSizeY)
        .value("Graphic3d_TypeOfLimit_MaxCombinedTextureUnits",Graphic3d_TypeOfLimit::Graphic3d_TypeOfLimit_MaxCombinedTextureUnits)
        .value("Graphic3d_TypeOfLimit_MaxMsaa",Graphic3d_TypeOfLimit::Graphic3d_TypeOfLimit_MaxMsaa)
        .value("Graphic3d_TypeOfLimit_HasPBR",Graphic3d_TypeOfLimit::Graphic3d_TypeOfLimit_HasPBR)
        .value("Graphic3d_TypeOfLimit_HasRayTracing",Graphic3d_TypeOfLimit::Graphic3d_TypeOfLimit_HasRayTracing)
        .value("Graphic3d_TypeOfLimit_HasRayTracingTextures",Graphic3d_TypeOfLimit::Graphic3d_TypeOfLimit_HasRayTracingTextures)
        .value("Graphic3d_TypeOfLimit_HasRayTracingAdaptiveSampling",Graphic3d_TypeOfLimit::Graphic3d_TypeOfLimit_HasRayTracingAdaptiveSampling)
        .value("Graphic3d_TypeOfLimit_HasRayTracingAdaptiveSamplingAtomic",Graphic3d_TypeOfLimit::Graphic3d_TypeOfLimit_HasRayTracingAdaptiveSamplingAtomic)
        .value("Graphic3d_TypeOfLimit_HasSRGB",Graphic3d_TypeOfLimit::Graphic3d_TypeOfLimit_HasSRGB)
        .value("Graphic3d_TypeOfLimit_HasBlendedOit",Graphic3d_TypeOfLimit::Graphic3d_TypeOfLimit_HasBlendedOit)
        .value("Graphic3d_TypeOfLimit_HasBlendedOitMsaa",Graphic3d_TypeOfLimit::Graphic3d_TypeOfLimit_HasBlendedOitMsaa)
        .value("Graphic3d_TypeOfLimit_HasFlatShading",Graphic3d_TypeOfLimit::Graphic3d_TypeOfLimit_HasFlatShading)
        .value("Graphic3d_TypeOfLimit_HasMeshEdges",Graphic3d_TypeOfLimit::Graphic3d_TypeOfLimit_HasMeshEdges)
        .value("Graphic3d_TypeOfLimit_IsWorkaroundFBO",Graphic3d_TypeOfLimit::Graphic3d_TypeOfLimit_IsWorkaroundFBO)
        .value("Graphic3d_TypeOfLimit_NB",Graphic3d_TypeOfLimit::Graphic3d_TypeOfLimit_NB).export_values();
    py::enum_<Graphic3d_TypeOfStructure>(m, "Graphic3d_TypeOfStructure",R"#(Structural attribute indicating if it can be displayed in wireframe, shadow mode, or both.)#")
        .value("Graphic3d_TOS_WIREFRAME",Graphic3d_TypeOfStructure::Graphic3d_TOS_WIREFRAME)
        .value("Graphic3d_TOS_SHADING",Graphic3d_TypeOfStructure::Graphic3d_TOS_SHADING)
        .value("Graphic3d_TOS_COMPUTED",Graphic3d_TypeOfStructure::Graphic3d_TOS_COMPUTED)
        .value("Graphic3d_TOS_ALL",Graphic3d_TypeOfStructure::Graphic3d_TOS_ALL).export_values();
    py::enum_<Graphic3d_DisplayPriority>(m, "Graphic3d_DisplayPriority",R"#(Structure priority - range (do not change this range!). Values are between 0 and 10, with 5 used by default. A structure of priority 10 is displayed the last and appears over the others (considering depth test).)#")
        .value("Graphic3d_DisplayPriority_INVALID",Graphic3d_DisplayPriority::Graphic3d_DisplayPriority_INVALID)
        .value("Graphic3d_DisplayPriority_Bottom",Graphic3d_DisplayPriority::Graphic3d_DisplayPriority_Bottom)
        .value("Graphic3d_DisplayPriority_AlmostBottom",Graphic3d_DisplayPriority::Graphic3d_DisplayPriority_AlmostBottom)
        .value("Graphic3d_DisplayPriority_Below2",Graphic3d_DisplayPriority::Graphic3d_DisplayPriority_Below2)
        .value("Graphic3d_DisplayPriority_Below1",Graphic3d_DisplayPriority::Graphic3d_DisplayPriority_Below1)
        .value("Graphic3d_DisplayPriority_Below",Graphic3d_DisplayPriority::Graphic3d_DisplayPriority_Below)
        .value("Graphic3d_DisplayPriority_Normal",Graphic3d_DisplayPriority::Graphic3d_DisplayPriority_Normal)
        .value("Graphic3d_DisplayPriority_Above",Graphic3d_DisplayPriority::Graphic3d_DisplayPriority_Above)
        .value("Graphic3d_DisplayPriority_Above1",Graphic3d_DisplayPriority::Graphic3d_DisplayPriority_Above1)
        .value("Graphic3d_DisplayPriority_Above2",Graphic3d_DisplayPriority::Graphic3d_DisplayPriority_Above2)
        .value("Graphic3d_DisplayPriority_Highlight",Graphic3d_DisplayPriority::Graphic3d_DisplayPriority_Highlight)
        .value("Graphic3d_DisplayPriority_Topmost",Graphic3d_DisplayPriority::Graphic3d_DisplayPriority_Topmost).export_values();
    m.attr("Graphic3d_DisplayPriority_NB") = py::cast(int(Graphic3d_DisplayPriority_NB));
    py::enum_<Graphic3d_TextPath>(m, "Graphic3d_TextPath",R"#(Direction in which text is displayed.)#")
        .value("Graphic3d_TP_UP",Graphic3d_TextPath::Graphic3d_TP_UP)
        .value("Graphic3d_TP_DOWN",Graphic3d_TextPath::Graphic3d_TP_DOWN)
        .value("Graphic3d_TP_LEFT",Graphic3d_TextPath::Graphic3d_TP_LEFT)
        .value("Graphic3d_TP_RIGHT",Graphic3d_TextPath::Graphic3d_TP_RIGHT).export_values();
    py::enum_<Graphic3d_FrameStatsCounter>(m, "Graphic3d_FrameStatsCounter",R"#(Stats counter.)#")
        .value("Graphic3d_FrameStatsCounter_NbLayers",Graphic3d_FrameStatsCounter::Graphic3d_FrameStatsCounter_NbLayers)
        .value("Graphic3d_FrameStatsCounter_NbStructs",Graphic3d_FrameStatsCounter::Graphic3d_FrameStatsCounter_NbStructs)
        .value("Graphic3d_FrameStatsCounter_EstimatedBytesGeom",Graphic3d_FrameStatsCounter::Graphic3d_FrameStatsCounter_EstimatedBytesGeom)
        .value("Graphic3d_FrameStatsCounter_EstimatedBytesFbos",Graphic3d_FrameStatsCounter::Graphic3d_FrameStatsCounter_EstimatedBytesFbos)
        .value("Graphic3d_FrameStatsCounter_EstimatedBytesTextures",Graphic3d_FrameStatsCounter::Graphic3d_FrameStatsCounter_EstimatedBytesTextures)
        .value("Graphic3d_FrameStatsCounter_NbLayersNotCulled",Graphic3d_FrameStatsCounter::Graphic3d_FrameStatsCounter_NbLayersNotCulled)
        .value("Graphic3d_FrameStatsCounter_NbStructsNotCulled",Graphic3d_FrameStatsCounter::Graphic3d_FrameStatsCounter_NbStructsNotCulled)
        .value("Graphic3d_FrameStatsCounter_NbGroupsNotCulled",Graphic3d_FrameStatsCounter::Graphic3d_FrameStatsCounter_NbGroupsNotCulled)
        .value("Graphic3d_FrameStatsCounter_NbElemsNotCulled",Graphic3d_FrameStatsCounter::Graphic3d_FrameStatsCounter_NbElemsNotCulled)
        .value("Graphic3d_FrameStatsCounter_NbElemsFillNotCulled",Graphic3d_FrameStatsCounter::Graphic3d_FrameStatsCounter_NbElemsFillNotCulled)
        .value("Graphic3d_FrameStatsCounter_NbElemsLineNotCulled",Graphic3d_FrameStatsCounter::Graphic3d_FrameStatsCounter_NbElemsLineNotCulled)
        .value("Graphic3d_FrameStatsCounter_NbElemsPointNotCulled",Graphic3d_FrameStatsCounter::Graphic3d_FrameStatsCounter_NbElemsPointNotCulled)
        .value("Graphic3d_FrameStatsCounter_NbElemsTextNotCulled",Graphic3d_FrameStatsCounter::Graphic3d_FrameStatsCounter_NbElemsTextNotCulled)
        .value("Graphic3d_FrameStatsCounter_NbTrianglesNotCulled",Graphic3d_FrameStatsCounter::Graphic3d_FrameStatsCounter_NbTrianglesNotCulled)
        .value("Graphic3d_FrameStatsCounter_NbLinesNotCulled",Graphic3d_FrameStatsCounter::Graphic3d_FrameStatsCounter_NbLinesNotCulled)
        .value("Graphic3d_FrameStatsCounter_NbPointsNotCulled",Graphic3d_FrameStatsCounter::Graphic3d_FrameStatsCounter_NbPointsNotCulled)
        .value("Graphic3d_FrameStatsCounter_NbLayersImmediate",Graphic3d_FrameStatsCounter::Graphic3d_FrameStatsCounter_NbLayersImmediate)
        .value("Graphic3d_FrameStatsCounter_NbStructsImmediate",Graphic3d_FrameStatsCounter::Graphic3d_FrameStatsCounter_NbStructsImmediate)
        .value("Graphic3d_FrameStatsCounter_NbGroupsImmediate",Graphic3d_FrameStatsCounter::Graphic3d_FrameStatsCounter_NbGroupsImmediate)
        .value("Graphic3d_FrameStatsCounter_NbElemsImmediate",Graphic3d_FrameStatsCounter::Graphic3d_FrameStatsCounter_NbElemsImmediate)
        .value("Graphic3d_FrameStatsCounter_NbElemsFillImmediate",Graphic3d_FrameStatsCounter::Graphic3d_FrameStatsCounter_NbElemsFillImmediate)
        .value("Graphic3d_FrameStatsCounter_NbElemsLineImmediate",Graphic3d_FrameStatsCounter::Graphic3d_FrameStatsCounter_NbElemsLineImmediate)
        .value("Graphic3d_FrameStatsCounter_NbElemsPointImmediate",Graphic3d_FrameStatsCounter::Graphic3d_FrameStatsCounter_NbElemsPointImmediate)
        .value("Graphic3d_FrameStatsCounter_NbElemsTextImmediate",Graphic3d_FrameStatsCounter::Graphic3d_FrameStatsCounter_NbElemsTextImmediate)
        .value("Graphic3d_FrameStatsCounter_NbTrianglesImmediate",Graphic3d_FrameStatsCounter::Graphic3d_FrameStatsCounter_NbTrianglesImmediate)
        .value("Graphic3d_FrameStatsCounter_NbLinesImmediate",Graphic3d_FrameStatsCounter::Graphic3d_FrameStatsCounter_NbLinesImmediate)
        .value("Graphic3d_FrameStatsCounter_NbPointsImmediate",Graphic3d_FrameStatsCounter::Graphic3d_FrameStatsCounter_NbPointsImmediate).export_values();
    m.attr("Graphic3d_FrameStatsCounter_NB") = py::cast(int(Graphic3d_FrameStatsCounter_NB));
    m.attr("Graphic3d_FrameStatsCounter_SCENE_LOWER") = py::cast(int(Graphic3d_FrameStatsCounter_SCENE_LOWER));
    m.attr("Graphic3d_FrameStatsCounter_SCENE_UPPER") = py::cast(int(Graphic3d_FrameStatsCounter_SCENE_UPPER));
    m.attr("Graphic3d_FrameStatsCounter_RENDERED_LOWER") = py::cast(int(Graphic3d_FrameStatsCounter_RENDERED_LOWER));
    m.attr("Graphic3d_FrameStatsCounter_RENDERED_UPPER") = py::cast(int(Graphic3d_FrameStatsCounter_RENDERED_UPPER));
    m.attr("Graphic3d_FrameStatsCounter_IMMEDIATE_LOWER") = py::cast(int(Graphic3d_FrameStatsCounter_IMMEDIATE_LOWER));
    m.attr("Graphic3d_FrameStatsCounter_IMMEDIATE_UPPER") = py::cast(int(Graphic3d_FrameStatsCounter_IMMEDIATE_UPPER));
    py::enum_<Graphic3d_NameOfTexture2D>(m, "Graphic3d_NameOfTexture2D",R"#(Types of standard textures.)#")
        .value("Graphic3d_NOT_2D_MATRA",Graphic3d_NameOfTexture2D::Graphic3d_NOT_2D_MATRA)
        .value("Graphic3d_NOT_2D_ALIENSKIN",Graphic3d_NameOfTexture2D::Graphic3d_NOT_2D_ALIENSKIN)
        .value("Graphic3d_NOT_2D_BLUE_ROCK",Graphic3d_NameOfTexture2D::Graphic3d_NOT_2D_BLUE_ROCK)
        .value("Graphic3d_NOT_2D_BLUEWHITE_PAPER",Graphic3d_NameOfTexture2D::Graphic3d_NOT_2D_BLUEWHITE_PAPER)
        .value("Graphic3d_NOT_2D_BRUSHED",Graphic3d_NameOfTexture2D::Graphic3d_NOT_2D_BRUSHED)
        .value("Graphic3d_NOT_2D_BUBBLES",Graphic3d_NameOfTexture2D::Graphic3d_NOT_2D_BUBBLES)
        .value("Graphic3d_NOT_2D_BUMP",Graphic3d_NameOfTexture2D::Graphic3d_NOT_2D_BUMP)
        .value("Graphic3d_NOT_2D_CAST",Graphic3d_NameOfTexture2D::Graphic3d_NOT_2D_CAST)
        .value("Graphic3d_NOT_2D_CHIPBD",Graphic3d_NameOfTexture2D::Graphic3d_NOT_2D_CHIPBD)
        .value("Graphic3d_NOT_2D_CLOUDS",Graphic3d_NameOfTexture2D::Graphic3d_NOT_2D_CLOUDS)
        .value("Graphic3d_NOT_2D_FLESH",Graphic3d_NameOfTexture2D::Graphic3d_NOT_2D_FLESH)
        .value("Graphic3d_NOT_2D_FLOOR",Graphic3d_NameOfTexture2D::Graphic3d_NOT_2D_FLOOR)
        .value("Graphic3d_NOT_2D_GALVNISD",Graphic3d_NameOfTexture2D::Graphic3d_NOT_2D_GALVNISD)
        .value("Graphic3d_NOT_2D_GRASS",Graphic3d_NameOfTexture2D::Graphic3d_NOT_2D_GRASS)
        .value("Graphic3d_NOT_2D_ALUMINUM",Graphic3d_NameOfTexture2D::Graphic3d_NOT_2D_ALUMINUM)
        .value("Graphic3d_NOT_2D_ROCK",Graphic3d_NameOfTexture2D::Graphic3d_NOT_2D_ROCK)
        .value("Graphic3d_NOT_2D_KNURL",Graphic3d_NameOfTexture2D::Graphic3d_NOT_2D_KNURL)
        .value("Graphic3d_NOT_2D_MAPLE",Graphic3d_NameOfTexture2D::Graphic3d_NOT_2D_MAPLE)
        .value("Graphic3d_NOT_2D_MARBLE",Graphic3d_NameOfTexture2D::Graphic3d_NOT_2D_MARBLE)
        .value("Graphic3d_NOT_2D_MOTTLED",Graphic3d_NameOfTexture2D::Graphic3d_NOT_2D_MOTTLED)
        .value("Graphic3d_NOT_2D_RAIN",Graphic3d_NameOfTexture2D::Graphic3d_NOT_2D_RAIN)
        .value("Graphic3d_NOT_2D_CHESS",Graphic3d_NameOfTexture2D::Graphic3d_NOT_2D_CHESS)
        .value("Graphic3d_NOT_2D_UNKNOWN",Graphic3d_NameOfTexture2D::Graphic3d_NOT_2D_UNKNOWN).export_values();
    py::enum_<Graphic3d_TypeOfTextureMode>(m, "Graphic3d_TypeOfTextureMode",R"#(Type of the texture projection.)#")
        .value("Graphic3d_TOTM_OBJECT",Graphic3d_TypeOfTextureMode::Graphic3d_TOTM_OBJECT)
        .value("Graphic3d_TOTM_SPHERE",Graphic3d_TypeOfTextureMode::Graphic3d_TOTM_SPHERE)
        .value("Graphic3d_TOTM_EYE",Graphic3d_TypeOfTextureMode::Graphic3d_TOTM_EYE)
        .value("Graphic3d_TOTM_MANUAL",Graphic3d_TypeOfTextureMode::Graphic3d_TOTM_MANUAL)
        .value("Graphic3d_TOTM_SPRITE",Graphic3d_TypeOfTextureMode::Graphic3d_TOTM_SPRITE).export_values();
    py::enum_<Graphic3d_TypeOfVisualization>(m, "Graphic3d_TypeOfVisualization",R"#(Modes of visualisation of objects in a view)#")
        .value("Graphic3d_TOV_WIREFRAME",Graphic3d_TypeOfVisualization::Graphic3d_TOV_WIREFRAME)
        .value("Graphic3d_TOV_SHADING",Graphic3d_TypeOfVisualization::Graphic3d_TOV_SHADING).export_values();
    py::enum_<Graphic3d_TypeOfLightSource>(m, "Graphic3d_TypeOfLightSource",R"#(Definition of all the type of light source.)#")
        .value("Graphic3d_TypeOfLightSource_Ambient",Graphic3d_TypeOfLightSource::Graphic3d_TypeOfLightSource_Ambient)
        .value("Graphic3d_TypeOfLightSource_Directional",Graphic3d_TypeOfLightSource::Graphic3d_TypeOfLightSource_Directional)
        .value("Graphic3d_TypeOfLightSource_Positional",Graphic3d_TypeOfLightSource::Graphic3d_TypeOfLightSource_Positional)
        .value("Graphic3d_TypeOfLightSource_Spot",Graphic3d_TypeOfLightSource::Graphic3d_TypeOfLightSource_Spot)
        .value("Graphic3d_TOLS_AMBIENT",Graphic3d_TypeOfLightSource::Graphic3d_TOLS_AMBIENT)
        .value("Graphic3d_TOLS_DIRECTIONAL",Graphic3d_TypeOfLightSource::Graphic3d_TOLS_DIRECTIONAL)
        .value("Graphic3d_TOLS_POSITIONAL",Graphic3d_TypeOfLightSource::Graphic3d_TOLS_POSITIONAL)
        .value("Graphic3d_TOLS_SPOT",Graphic3d_TypeOfLightSource::Graphic3d_TOLS_SPOT)
        .value("V3d_AMBIENT",Graphic3d_TypeOfLightSource::V3d_AMBIENT)
        .value("V3d_DIRECTIONAL",Graphic3d_TypeOfLightSource::V3d_DIRECTIONAL)
        .value("V3d_POSITIONAL",Graphic3d_TypeOfLightSource::V3d_POSITIONAL)
        .value("V3d_SPOT",Graphic3d_TypeOfLightSource::V3d_SPOT).export_values();
    m.attr("Graphic3d_TypeOfLightSource_NB") = py::cast(int(Graphic3d_TypeOfLightSource_NB));
    m.attr("Graphic3d_ZLayerId_UNKNOWN") = py::cast(int(Graphic3d_ZLayerId_UNKNOWN));
    m.attr("Graphic3d_ZLayerId_Default") = py::cast(int(Graphic3d_ZLayerId_Default));
    m.attr("Graphic3d_ZLayerId_Top") = py::cast(int(Graphic3d_ZLayerId_Top));
    m.attr("Graphic3d_ZLayerId_Topmost") = py::cast(int(Graphic3d_ZLayerId_Topmost));
    m.attr("Graphic3d_ZLayerId_TopOSD") = py::cast(int(Graphic3d_ZLayerId_TopOSD));
    m.attr("Graphic3d_ZLayerId_BotOSD") = py::cast(int(Graphic3d_ZLayerId_BotOSD));
    py::enum_<Graphic3d_ShaderFlags>(m, "Graphic3d_ShaderFlags",R"#(Standard GLSL program combination bits.)#")
        .value("Graphic3d_ShaderFlags_VertColor",Graphic3d_ShaderFlags::Graphic3d_ShaderFlags_VertColor)
        .value("Graphic3d_ShaderFlags_TextureRGB",Graphic3d_ShaderFlags::Graphic3d_ShaderFlags_TextureRGB)
        .value("Graphic3d_ShaderFlags_TextureEnv",Graphic3d_ShaderFlags::Graphic3d_ShaderFlags_TextureEnv)
        .value("Graphic3d_ShaderFlags_TextureNormal",Graphic3d_ShaderFlags::Graphic3d_ShaderFlags_TextureNormal)
        .value("Graphic3d_ShaderFlags_PointSimple",Graphic3d_ShaderFlags::Graphic3d_ShaderFlags_PointSimple)
        .value("Graphic3d_ShaderFlags_PointSprite",Graphic3d_ShaderFlags::Graphic3d_ShaderFlags_PointSprite)
        .value("Graphic3d_ShaderFlags_PointSpriteA",Graphic3d_ShaderFlags::Graphic3d_ShaderFlags_PointSpriteA)
        .value("Graphic3d_ShaderFlags_StippleLine",Graphic3d_ShaderFlags::Graphic3d_ShaderFlags_StippleLine)
        .value("Graphic3d_ShaderFlags_ClipPlanes1",Graphic3d_ShaderFlags::Graphic3d_ShaderFlags_ClipPlanes1)
        .value("Graphic3d_ShaderFlags_ClipPlanes2",Graphic3d_ShaderFlags::Graphic3d_ShaderFlags_ClipPlanes2)
        .value("Graphic3d_ShaderFlags_ClipPlanesN",Graphic3d_ShaderFlags::Graphic3d_ShaderFlags_ClipPlanesN)
        .value("Graphic3d_ShaderFlags_ClipChains",Graphic3d_ShaderFlags::Graphic3d_ShaderFlags_ClipChains)
        .value("Graphic3d_ShaderFlags_MeshEdges",Graphic3d_ShaderFlags::Graphic3d_ShaderFlags_MeshEdges)
        .value("Graphic3d_ShaderFlags_AlphaTest",Graphic3d_ShaderFlags::Graphic3d_ShaderFlags_AlphaTest)
        .value("Graphic3d_ShaderFlags_WriteOit",Graphic3d_ShaderFlags::Graphic3d_ShaderFlags_WriteOit)
        .value("Graphic3d_ShaderFlags_OitDepthPeeling",Graphic3d_ShaderFlags::Graphic3d_ShaderFlags_OitDepthPeeling)
        .value("Graphic3d_ShaderFlags_VertColorFrontOnly",Graphic3d_ShaderFlags::Graphic3d_ShaderFlags_VertColorFrontOnly)
        .value("Graphic3d_ShaderFlags_NB",Graphic3d_ShaderFlags::Graphic3d_ShaderFlags_NB)
        .value("Graphic3d_ShaderFlags_IsPoint",Graphic3d_ShaderFlags::Graphic3d_ShaderFlags_IsPoint)
        .value("Graphic3d_ShaderFlags_HasTextures",Graphic3d_ShaderFlags::Graphic3d_ShaderFlags_HasTextures)
        .value("Graphic3d_ShaderFlags_NeedsGeomShader",Graphic3d_ShaderFlags::Graphic3d_ShaderFlags_NeedsGeomShader).export_values();
    py::enum_<Graphic3d_TypeOfAttribute>(m, "Graphic3d_TypeOfAttribute",R"#(Type of attribute in Vertex Buffer)#")
        .value("Graphic3d_TOA_POS",Graphic3d_TypeOfAttribute::Graphic3d_TOA_POS)
        .value("Graphic3d_TOA_NORM",Graphic3d_TypeOfAttribute::Graphic3d_TOA_NORM)
        .value("Graphic3d_TOA_UV",Graphic3d_TypeOfAttribute::Graphic3d_TOA_UV)
        .value("Graphic3d_TOA_COLOR",Graphic3d_TypeOfAttribute::Graphic3d_TOA_COLOR)
        .value("Graphic3d_TOA_CUSTOM",Graphic3d_TypeOfAttribute::Graphic3d_TOA_CUSTOM).export_values();
    py::enum_<Graphic3d_TypeOfData>(m, "Graphic3d_TypeOfData",R"#(Type of the element in Vertex or Index Buffer)#")
        .value("Graphic3d_TOD_USHORT",Graphic3d_TypeOfData::Graphic3d_TOD_USHORT)
        .value("Graphic3d_TOD_UINT",Graphic3d_TypeOfData::Graphic3d_TOD_UINT)
        .value("Graphic3d_TOD_VEC2",Graphic3d_TypeOfData::Graphic3d_TOD_VEC2)
        .value("Graphic3d_TOD_VEC3",Graphic3d_TypeOfData::Graphic3d_TOD_VEC3)
        .value("Graphic3d_TOD_VEC4",Graphic3d_TypeOfData::Graphic3d_TOD_VEC4)
        .value("Graphic3d_TOD_VEC4UB",Graphic3d_TypeOfData::Graphic3d_TOD_VEC4UB)
        .value("Graphic3d_TOD_FLOAT",Graphic3d_TypeOfData::Graphic3d_TOD_FLOAT).export_values();
    py::enum_<Graphic3d_TypeOfShaderObject>(m, "Graphic3d_TypeOfShaderObject",R"#(Type of the shader object.)#")
        .value("Graphic3d_TOS_VERTEX",Graphic3d_TypeOfShaderObject::Graphic3d_TOS_VERTEX)
        .value("Graphic3d_TOS_TESS_CONTROL",Graphic3d_TypeOfShaderObject::Graphic3d_TOS_TESS_CONTROL)
        .value("Graphic3d_TOS_TESS_EVALUATION",Graphic3d_TypeOfShaderObject::Graphic3d_TOS_TESS_EVALUATION)
        .value("Graphic3d_TOS_GEOMETRY",Graphic3d_TypeOfShaderObject::Graphic3d_TOS_GEOMETRY)
        .value("Graphic3d_TOS_FRAGMENT",Graphic3d_TypeOfShaderObject::Graphic3d_TOS_FRAGMENT)
        .value("Graphic3d_TOS_COMPUTE",Graphic3d_TypeOfShaderObject::Graphic3d_TOS_COMPUTE).export_values();
    py::enum_<Graphic3d_TypeOfShadingModel>(m, "Graphic3d_TypeOfShadingModel",R"#(Definition of the color shading model.)#")
        .value("Graphic3d_TypeOfShadingModel_DEFAULT",Graphic3d_TypeOfShadingModel::Graphic3d_TypeOfShadingModel_DEFAULT)
        .value("Graphic3d_TypeOfShadingModel_Unlit",Graphic3d_TypeOfShadingModel::Graphic3d_TypeOfShadingModel_Unlit)
        .value("Graphic3d_TypeOfShadingModel_PhongFacet",Graphic3d_TypeOfShadingModel::Graphic3d_TypeOfShadingModel_PhongFacet)
        .value("Graphic3d_TypeOfShadingModel_Gouraud",Graphic3d_TypeOfShadingModel::Graphic3d_TypeOfShadingModel_Gouraud)
        .value("Graphic3d_TypeOfShadingModel_Phong",Graphic3d_TypeOfShadingModel::Graphic3d_TypeOfShadingModel_Phong)
        .value("Graphic3d_TypeOfShadingModel_Pbr",Graphic3d_TypeOfShadingModel::Graphic3d_TypeOfShadingModel_Pbr)
        .value("Graphic3d_TypeOfShadingModel_PbrFacet",Graphic3d_TypeOfShadingModel::Graphic3d_TypeOfShadingModel_PbrFacet)
        .value("Graphic3d_TOSM_DEFAULT",Graphic3d_TypeOfShadingModel::Graphic3d_TOSM_DEFAULT)
        .value("Graphic3d_TOSM_UNLIT",Graphic3d_TypeOfShadingModel::Graphic3d_TOSM_UNLIT)
        .value("Graphic3d_TOSM_FACET",Graphic3d_TypeOfShadingModel::Graphic3d_TOSM_FACET)
        .value("Graphic3d_TOSM_VERTEX",Graphic3d_TypeOfShadingModel::Graphic3d_TOSM_VERTEX)
        .value("Graphic3d_TOSM_FRAGMENT",Graphic3d_TypeOfShadingModel::Graphic3d_TOSM_FRAGMENT)
        .value("Graphic3d_TOSM_PBR",Graphic3d_TypeOfShadingModel::Graphic3d_TOSM_PBR)
        .value("Graphic3d_TOSM_PBR_FACET",Graphic3d_TypeOfShadingModel::Graphic3d_TOSM_PBR_FACET)
        .value("Graphic3d_TOSM_NONE",Graphic3d_TypeOfShadingModel::Graphic3d_TOSM_NONE)
        .value("V3d_COLOR",Graphic3d_TypeOfShadingModel::V3d_COLOR)
        .value("V3d_FLAT",Graphic3d_TypeOfShadingModel::V3d_FLAT)
        .value("V3d_GOURAUD",Graphic3d_TypeOfShadingModel::V3d_GOURAUD)
        .value("V3d_PHONG",Graphic3d_TypeOfShadingModel::V3d_PHONG).export_values();
    m.attr("Graphic3d_TypeOfShadingModel_NB") = py::cast(int(Graphic3d_TypeOfShadingModel_NB));
    py::enum_<Graphic3d_RenderTransparentMethod>(m, "Graphic3d_RenderTransparentMethod",R"#(Enumerates transparency rendering methods supported by rasterization mode.)#")
        .value("Graphic3d_RTM_BLEND_UNORDERED",Graphic3d_RenderTransparentMethod::Graphic3d_RTM_BLEND_UNORDERED)
        .value("Graphic3d_RTM_BLEND_OIT",Graphic3d_RenderTransparentMethod::Graphic3d_RTM_BLEND_OIT)
        .value("Graphic3d_RTM_DEPTH_PEELING_OIT",Graphic3d_RenderTransparentMethod::Graphic3d_RTM_DEPTH_PEELING_OIT).export_values();
    py::enum_<Graphic3d_TypeOfReflection>(m, "Graphic3d_TypeOfReflection",R"#(Nature of the reflection of a material.)#")
        .value("Graphic3d_TOR_AMBIENT",Graphic3d_TypeOfReflection::Graphic3d_TOR_AMBIENT)
        .value("Graphic3d_TOR_DIFFUSE",Graphic3d_TypeOfReflection::Graphic3d_TOR_DIFFUSE)
        .value("Graphic3d_TOR_SPECULAR",Graphic3d_TypeOfReflection::Graphic3d_TOR_SPECULAR)
        .value("Graphic3d_TOR_EMISSION",Graphic3d_TypeOfReflection::Graphic3d_TOR_EMISSION).export_values();
    m.attr("Graphic3d_TypeOfReflection_NB") = py::cast(int(Graphic3d_TypeOfReflection_NB));
    py::enum_<Graphic3d_NameOfMaterial>(m, "Graphic3d_NameOfMaterial",R"#(List of named materials (predefined presets). Each preset defines either physical (having natural color) or generic (mutable color) material ()#")
        .value("Graphic3d_NameOfMaterial_Brass",Graphic3d_NameOfMaterial::Graphic3d_NameOfMaterial_Brass)
        .value("Graphic3d_NameOfMaterial_Bronze",Graphic3d_NameOfMaterial::Graphic3d_NameOfMaterial_Bronze)
        .value("Graphic3d_NameOfMaterial_Copper",Graphic3d_NameOfMaterial::Graphic3d_NameOfMaterial_Copper)
        .value("Graphic3d_NameOfMaterial_Gold",Graphic3d_NameOfMaterial::Graphic3d_NameOfMaterial_Gold)
        .value("Graphic3d_NameOfMaterial_Pewter",Graphic3d_NameOfMaterial::Graphic3d_NameOfMaterial_Pewter)
        .value("Graphic3d_NameOfMaterial_Plastered",Graphic3d_NameOfMaterial::Graphic3d_NameOfMaterial_Plastered)
        .value("Graphic3d_NameOfMaterial_Plastified",Graphic3d_NameOfMaterial::Graphic3d_NameOfMaterial_Plastified)
        .value("Graphic3d_NameOfMaterial_Silver",Graphic3d_NameOfMaterial::Graphic3d_NameOfMaterial_Silver)
        .value("Graphic3d_NameOfMaterial_Steel",Graphic3d_NameOfMaterial::Graphic3d_NameOfMaterial_Steel)
        .value("Graphic3d_NameOfMaterial_Stone",Graphic3d_NameOfMaterial::Graphic3d_NameOfMaterial_Stone)
        .value("Graphic3d_NameOfMaterial_ShinyPlastified",Graphic3d_NameOfMaterial::Graphic3d_NameOfMaterial_ShinyPlastified)
        .value("Graphic3d_NameOfMaterial_Satin",Graphic3d_NameOfMaterial::Graphic3d_NameOfMaterial_Satin)
        .value("Graphic3d_NameOfMaterial_Metalized",Graphic3d_NameOfMaterial::Graphic3d_NameOfMaterial_Metalized)
        .value("Graphic3d_NameOfMaterial_Ionized",Graphic3d_NameOfMaterial::Graphic3d_NameOfMaterial_Ionized)
        .value("Graphic3d_NameOfMaterial_Chrome",Graphic3d_NameOfMaterial::Graphic3d_NameOfMaterial_Chrome)
        .value("Graphic3d_NameOfMaterial_Aluminum",Graphic3d_NameOfMaterial::Graphic3d_NameOfMaterial_Aluminum)
        .value("Graphic3d_NameOfMaterial_Obsidian",Graphic3d_NameOfMaterial::Graphic3d_NameOfMaterial_Obsidian)
        .value("Graphic3d_NameOfMaterial_Neon",Graphic3d_NameOfMaterial::Graphic3d_NameOfMaterial_Neon)
        .value("Graphic3d_NameOfMaterial_Jade",Graphic3d_NameOfMaterial::Graphic3d_NameOfMaterial_Jade)
        .value("Graphic3d_NameOfMaterial_Charcoal",Graphic3d_NameOfMaterial::Graphic3d_NameOfMaterial_Charcoal)
        .value("Graphic3d_NameOfMaterial_Water",Graphic3d_NameOfMaterial::Graphic3d_NameOfMaterial_Water)
        .value("Graphic3d_NameOfMaterial_Glass",Graphic3d_NameOfMaterial::Graphic3d_NameOfMaterial_Glass)
        .value("Graphic3d_NameOfMaterial_Diamond",Graphic3d_NameOfMaterial::Graphic3d_NameOfMaterial_Diamond)
        .value("Graphic3d_NameOfMaterial_Transparent",Graphic3d_NameOfMaterial::Graphic3d_NameOfMaterial_Transparent)
        .value("Graphic3d_NameOfMaterial_DEFAULT",Graphic3d_NameOfMaterial::Graphic3d_NameOfMaterial_DEFAULT)
        .value("Graphic3d_NameOfMaterial_UserDefined",Graphic3d_NameOfMaterial::Graphic3d_NameOfMaterial_UserDefined)
        .value("Graphic3d_NOM_BRASS",Graphic3d_NameOfMaterial::Graphic3d_NOM_BRASS)
        .value("Graphic3d_NOM_BRONZE",Graphic3d_NameOfMaterial::Graphic3d_NOM_BRONZE)
        .value("Graphic3d_NOM_COPPER",Graphic3d_NameOfMaterial::Graphic3d_NOM_COPPER)
        .value("Graphic3d_NOM_GOLD",Graphic3d_NameOfMaterial::Graphic3d_NOM_GOLD)
        .value("Graphic3d_NOM_PEWTER",Graphic3d_NameOfMaterial::Graphic3d_NOM_PEWTER)
        .value("Graphic3d_NOM_PLASTER",Graphic3d_NameOfMaterial::Graphic3d_NOM_PLASTER)
        .value("Graphic3d_NOM_PLASTIC",Graphic3d_NameOfMaterial::Graphic3d_NOM_PLASTIC)
        .value("Graphic3d_NOM_SILVER",Graphic3d_NameOfMaterial::Graphic3d_NOM_SILVER)
        .value("Graphic3d_NOM_STEEL",Graphic3d_NameOfMaterial::Graphic3d_NOM_STEEL)
        .value("Graphic3d_NOM_STONE",Graphic3d_NameOfMaterial::Graphic3d_NOM_STONE)
        .value("Graphic3d_NOM_SHINY_PLASTIC",Graphic3d_NameOfMaterial::Graphic3d_NOM_SHINY_PLASTIC)
        .value("Graphic3d_NOM_SATIN",Graphic3d_NameOfMaterial::Graphic3d_NOM_SATIN)
        .value("Graphic3d_NOM_METALIZED",Graphic3d_NameOfMaterial::Graphic3d_NOM_METALIZED)
        .value("Graphic3d_NOM_NEON_GNC",Graphic3d_NameOfMaterial::Graphic3d_NOM_NEON_GNC)
        .value("Graphic3d_NOM_CHROME",Graphic3d_NameOfMaterial::Graphic3d_NOM_CHROME)
        .value("Graphic3d_NOM_ALUMINIUM",Graphic3d_NameOfMaterial::Graphic3d_NOM_ALUMINIUM)
        .value("Graphic3d_NOM_OBSIDIAN",Graphic3d_NameOfMaterial::Graphic3d_NOM_OBSIDIAN)
        .value("Graphic3d_NOM_NEON_PHC",Graphic3d_NameOfMaterial::Graphic3d_NOM_NEON_PHC)
        .value("Graphic3d_NOM_JADE",Graphic3d_NameOfMaterial::Graphic3d_NOM_JADE)
        .value("Graphic3d_NOM_CHARCOAL",Graphic3d_NameOfMaterial::Graphic3d_NOM_CHARCOAL)
        .value("Graphic3d_NOM_WATER",Graphic3d_NameOfMaterial::Graphic3d_NOM_WATER)
        .value("Graphic3d_NOM_GLASS",Graphic3d_NameOfMaterial::Graphic3d_NOM_GLASS)
        .value("Graphic3d_NOM_DIAMOND",Graphic3d_NameOfMaterial::Graphic3d_NOM_DIAMOND)
        .value("Graphic3d_NOM_TRANSPARENT",Graphic3d_NameOfMaterial::Graphic3d_NOM_TRANSPARENT)
        .value("Graphic3d_NOM_DEFAULT",Graphic3d_NameOfMaterial::Graphic3d_NOM_DEFAULT)
        .value("Graphic3d_NOM_UserDefined",Graphic3d_NameOfMaterial::Graphic3d_NOM_UserDefined).export_values();
    py::enum_<Graphic3d_TextureUnit>(m, "Graphic3d_TextureUnit",R"#(Texture unit.)#")
        .value("Graphic3d_TextureUnit_0",Graphic3d_TextureUnit::Graphic3d_TextureUnit_0)
        .value("Graphic3d_TextureUnit_1",Graphic3d_TextureUnit::Graphic3d_TextureUnit_1)
        .value("Graphic3d_TextureUnit_2",Graphic3d_TextureUnit::Graphic3d_TextureUnit_2)
        .value("Graphic3d_TextureUnit_3",Graphic3d_TextureUnit::Graphic3d_TextureUnit_3)
        .value("Graphic3d_TextureUnit_4",Graphic3d_TextureUnit::Graphic3d_TextureUnit_4)
        .value("Graphic3d_TextureUnit_5",Graphic3d_TextureUnit::Graphic3d_TextureUnit_5)
        .value("Graphic3d_TextureUnit_6",Graphic3d_TextureUnit::Graphic3d_TextureUnit_6)
        .value("Graphic3d_TextureUnit_7",Graphic3d_TextureUnit::Graphic3d_TextureUnit_7)
        .value("Graphic3d_TextureUnit_8",Graphic3d_TextureUnit::Graphic3d_TextureUnit_8)
        .value("Graphic3d_TextureUnit_9",Graphic3d_TextureUnit::Graphic3d_TextureUnit_9)
        .value("Graphic3d_TextureUnit_10",Graphic3d_TextureUnit::Graphic3d_TextureUnit_10)
        .value("Graphic3d_TextureUnit_11",Graphic3d_TextureUnit::Graphic3d_TextureUnit_11)
        .value("Graphic3d_TextureUnit_12",Graphic3d_TextureUnit::Graphic3d_TextureUnit_12)
        .value("Graphic3d_TextureUnit_13",Graphic3d_TextureUnit::Graphic3d_TextureUnit_13)
        .value("Graphic3d_TextureUnit_14",Graphic3d_TextureUnit::Graphic3d_TextureUnit_14)
        .value("Graphic3d_TextureUnit_15",Graphic3d_TextureUnit::Graphic3d_TextureUnit_15)
        .value("Graphic3d_TextureUnit_BaseColor",Graphic3d_TextureUnit::Graphic3d_TextureUnit_BaseColor)
        .value("Graphic3d_TextureUnit_Emissive",Graphic3d_TextureUnit::Graphic3d_TextureUnit_Emissive)
        .value("Graphic3d_TextureUnit_Occlusion",Graphic3d_TextureUnit::Graphic3d_TextureUnit_Occlusion)
        .value("Graphic3d_TextureUnit_Normal",Graphic3d_TextureUnit::Graphic3d_TextureUnit_Normal)
        .value("Graphic3d_TextureUnit_MetallicRoughness",Graphic3d_TextureUnit::Graphic3d_TextureUnit_MetallicRoughness)
        .value("Graphic3d_TextureUnit_EnvMap",Graphic3d_TextureUnit::Graphic3d_TextureUnit_EnvMap)
        .value("Graphic3d_TextureUnit_PointSprite",Graphic3d_TextureUnit::Graphic3d_TextureUnit_PointSprite)
        .value("Graphic3d_TextureUnit_DepthPeelingDepth",Graphic3d_TextureUnit::Graphic3d_TextureUnit_DepthPeelingDepth)
        .value("Graphic3d_TextureUnit_DepthPeelingFrontColor",Graphic3d_TextureUnit::Graphic3d_TextureUnit_DepthPeelingFrontColor)
        .value("Graphic3d_TextureUnit_ShadowMap",Graphic3d_TextureUnit::Graphic3d_TextureUnit_ShadowMap)
        .value("Graphic3d_TextureUnit_PbrEnvironmentLUT",Graphic3d_TextureUnit::Graphic3d_TextureUnit_PbrEnvironmentLUT)
        .value("Graphic3d_TextureUnit_PbrIblDiffuseSH",Graphic3d_TextureUnit::Graphic3d_TextureUnit_PbrIblDiffuseSH)
        .value("Graphic3d_TextureUnit_PbrIblSpecular",Graphic3d_TextureUnit::Graphic3d_TextureUnit_PbrIblSpecular).export_values();
    m.attr("Graphic3d_TextureUnit_NB") = py::cast(int(Graphic3d_TextureUnit_NB));
    py::enum_<Graphic3d_TypeOfMaterial>(m, "Graphic3d_TypeOfMaterial",R"#(Types of materials specifies if a material can change color.)#")
        .value("Graphic3d_MATERIAL_ASPECT",Graphic3d_TypeOfMaterial::Graphic3d_MATERIAL_ASPECT)
        .value("Graphic3d_MATERIAL_PHYSIC",Graphic3d_TypeOfMaterial::Graphic3d_MATERIAL_PHYSIC).export_values();
    py::enum_<Graphic3d_RenderingMode>(m, "Graphic3d_RenderingMode",R"#(Describes rendering modes. - RM_RASTERIZATION: enables OpenGL rasterization mode; - RM_RAYTRACING: enables GPU ray-tracing mode.)#")
        .value("Graphic3d_RM_RASTERIZATION",Graphic3d_RenderingMode::Graphic3d_RM_RASTERIZATION)
        .value("Graphic3d_RM_RAYTRACING",Graphic3d_RenderingMode::Graphic3d_RM_RAYTRACING).export_values();
    py::enum_<Graphic3d_CubeMapSide>(m, "Graphic3d_CubeMapSide",R"#(Sides of cubemap in order of OpenGL rules)#")
        .value("Graphic3d_CMS_POS_X",Graphic3d_CubeMapSide::Graphic3d_CMS_POS_X)
        .value("Graphic3d_CMS_NEG_X",Graphic3d_CubeMapSide::Graphic3d_CMS_NEG_X)
        .value("Graphic3d_CMS_POS_Y",Graphic3d_CubeMapSide::Graphic3d_CMS_POS_Y)
        .value("Graphic3d_CMS_NEG_Y",Graphic3d_CubeMapSide::Graphic3d_CMS_NEG_Y)
        .value("Graphic3d_CMS_POS_Z",Graphic3d_CubeMapSide::Graphic3d_CMS_POS_Z)
        .value("Graphic3d_CMS_NEG_Z",Graphic3d_CubeMapSide::Graphic3d_CMS_NEG_Z).export_values();
    py::enum_<Graphic3d_GroupAspect>(m, "Graphic3d_GroupAspect",R"#(Identifies primitives aspects defined per group. - ASPECT_LINE: aspect for line primitives; - ASPECT_TEXT: aspect for text primitives; - ASPECT_MARKER: aspect for marker primitives; - ASPECT_FILL_AREA: aspect for face primitives.)#")
        .value("Graphic3d_ASPECT_LINE",Graphic3d_GroupAspect::Graphic3d_ASPECT_LINE)
        .value("Graphic3d_ASPECT_TEXT",Graphic3d_GroupAspect::Graphic3d_ASPECT_TEXT)
        .value("Graphic3d_ASPECT_MARKER",Graphic3d_GroupAspect::Graphic3d_ASPECT_MARKER)
        .value("Graphic3d_ASPECT_FILL_AREA",Graphic3d_GroupAspect::Graphic3d_ASPECT_FILL_AREA).export_values();
    py::enum_<Graphic3d_StereoMode>(m, "Graphic3d_StereoMode",R"#(This enumeration defines the list of stereoscopic output modes.)#")
        .value("Graphic3d_StereoMode_QuadBuffer",Graphic3d_StereoMode::Graphic3d_StereoMode_QuadBuffer)
        .value("Graphic3d_StereoMode_Anaglyph",Graphic3d_StereoMode::Graphic3d_StereoMode_Anaglyph)
        .value("Graphic3d_StereoMode_RowInterlaced",Graphic3d_StereoMode::Graphic3d_StereoMode_RowInterlaced)
        .value("Graphic3d_StereoMode_ColumnInterlaced",Graphic3d_StereoMode::Graphic3d_StereoMode_ColumnInterlaced)
        .value("Graphic3d_StereoMode_ChessBoard",Graphic3d_StereoMode::Graphic3d_StereoMode_ChessBoard)
        .value("Graphic3d_StereoMode_SideBySide",Graphic3d_StereoMode::Graphic3d_StereoMode_SideBySide)
        .value("Graphic3d_StereoMode_OverUnder",Graphic3d_StereoMode::Graphic3d_StereoMode_OverUnder)
        .value("Graphic3d_StereoMode_SoftPageFlip",Graphic3d_StereoMode::Graphic3d_StereoMode_SoftPageFlip)
        .value("Graphic3d_StereoMode_OpenVR",Graphic3d_StereoMode::Graphic3d_StereoMode_OpenVR).export_values();
    m.attr("Graphic3d_StereoMode_NB") = py::cast(int(Graphic3d_StereoMode_NB));
    py::enum_<Graphic3d_AlphaMode>(m, "Graphic3d_AlphaMode",R"#(Defines how alpha value of base color / texture should be treated.)#")
        .value("Graphic3d_AlphaMode_Opaque",Graphic3d_AlphaMode::Graphic3d_AlphaMode_Opaque)
        .value("Graphic3d_AlphaMode_Mask",Graphic3d_AlphaMode::Graphic3d_AlphaMode_Mask)
        .value("Graphic3d_AlphaMode_Blend",Graphic3d_AlphaMode::Graphic3d_AlphaMode_Blend)
        .value("Graphic3d_AlphaMode_MaskBlend",Graphic3d_AlphaMode::Graphic3d_AlphaMode_MaskBlend)
        .value("Graphic3d_AlphaMode_BlendAuto",Graphic3d_AlphaMode::Graphic3d_AlphaMode_BlendAuto).export_values();
    py::enum_<Graphic3d_TypeOfBackfacingModel>(m, "Graphic3d_TypeOfBackfacingModel",R"#(Modes of display of back faces in the view.)#")
        .value("Graphic3d_TypeOfBackfacingModel_Auto",Graphic3d_TypeOfBackfacingModel::Graphic3d_TypeOfBackfacingModel_Auto)
        .value("Graphic3d_TypeOfBackfacingModel_DoubleSided",Graphic3d_TypeOfBackfacingModel::Graphic3d_TypeOfBackfacingModel_DoubleSided)
        .value("Graphic3d_TypeOfBackfacingModel_BackCulled",Graphic3d_TypeOfBackfacingModel::Graphic3d_TypeOfBackfacingModel_BackCulled)
        .value("Graphic3d_TypeOfBackfacingModel_FrontCulled",Graphic3d_TypeOfBackfacingModel::Graphic3d_TypeOfBackfacingModel_FrontCulled)
        .value("Graphic3d_TOBM_AUTOMATIC",Graphic3d_TypeOfBackfacingModel::Graphic3d_TOBM_AUTOMATIC)
        .value("Graphic3d_TOBM_FORCE",Graphic3d_TypeOfBackfacingModel::Graphic3d_TOBM_FORCE)
        .value("Graphic3d_TOBM_DISABLE",Graphic3d_TypeOfBackfacingModel::Graphic3d_TOBM_DISABLE)
        .value("V3d_TOBM_AUTOMATIC",Graphic3d_TypeOfBackfacingModel::V3d_TOBM_AUTOMATIC)
        .value("V3d_TOBM_ALWAYS_DISPLAYED",Graphic3d_TypeOfBackfacingModel::V3d_TOBM_ALWAYS_DISPLAYED)
        .value("V3d_TOBM_NEVER_DISPLAYED",Graphic3d_TypeOfBackfacingModel::V3d_TOBM_NEVER_DISPLAYED).export_values();
    py::enum_<Graphic3d_TextureSetBits>(m, "Graphic3d_TextureSetBits",R"#(Standard texture units combination bits.)#")
        .value("Graphic3d_TextureSetBits_NONE",Graphic3d_TextureSetBits::Graphic3d_TextureSetBits_NONE)
        .value("Graphic3d_TextureSetBits_BaseColor",Graphic3d_TextureSetBits::Graphic3d_TextureSetBits_BaseColor)
        .value("Graphic3d_TextureSetBits_Emissive",Graphic3d_TextureSetBits::Graphic3d_TextureSetBits_Emissive)
        .value("Graphic3d_TextureSetBits_Occlusion",Graphic3d_TextureSetBits::Graphic3d_TextureSetBits_Occlusion)
        .value("Graphic3d_TextureSetBits_Normal",Graphic3d_TextureSetBits::Graphic3d_TextureSetBits_Normal)
        .value("Graphic3d_TextureSetBits_MetallicRoughness",Graphic3d_TextureSetBits::Graphic3d_TextureSetBits_MetallicRoughness).export_values();
    py::enum_<Graphic3d_TypeOfConnection>(m, "Graphic3d_TypeOfConnection",R"#(To manage the connections between the structures.)#")
        .value("Graphic3d_TOC_ANCESTOR",Graphic3d_TypeOfConnection::Graphic3d_TOC_ANCESTOR)
        .value("Graphic3d_TOC_DESCENDANT",Graphic3d_TypeOfConnection::Graphic3d_TOC_DESCENDANT).export_values();
    py::enum_<Graphic3d_DiagnosticInfo>(m, "Graphic3d_DiagnosticInfo",R"#(Diagnostic info categories bit flags.)#")
        .value("Graphic3d_DiagnosticInfo_Device",Graphic3d_DiagnosticInfo::Graphic3d_DiagnosticInfo_Device)
        .value("Graphic3d_DiagnosticInfo_FrameBuffer",Graphic3d_DiagnosticInfo::Graphic3d_DiagnosticInfo_FrameBuffer)
        .value("Graphic3d_DiagnosticInfo_Limits",Graphic3d_DiagnosticInfo::Graphic3d_DiagnosticInfo_Limits)
        .value("Graphic3d_DiagnosticInfo_Memory",Graphic3d_DiagnosticInfo::Graphic3d_DiagnosticInfo_Memory)
        .value("Graphic3d_DiagnosticInfo_NativePlatform",Graphic3d_DiagnosticInfo::Graphic3d_DiagnosticInfo_NativePlatform)
        .value("Graphic3d_DiagnosticInfo_Extensions",Graphic3d_DiagnosticInfo::Graphic3d_DiagnosticInfo_Extensions)
        .value("Graphic3d_DiagnosticInfo_Short",Graphic3d_DiagnosticInfo::Graphic3d_DiagnosticInfo_Short)
        .value("Graphic3d_DiagnosticInfo_Basic",Graphic3d_DiagnosticInfo::Graphic3d_DiagnosticInfo_Basic)
        .value("Graphic3d_DiagnosticInfo_Complete",Graphic3d_DiagnosticInfo::Graphic3d_DiagnosticInfo_Complete).export_values();
    py::enum_<Graphic3d_TransModeFlags>(m, "Graphic3d_TransModeFlags",R"#(Transform Persistence Mode defining whether to lock in object position, rotation and / or zooming relative to camera position.)#")
        .value("Graphic3d_TMF_None",Graphic3d_TransModeFlags::Graphic3d_TMF_None)
        .value("Graphic3d_TMF_ZoomPers",Graphic3d_TransModeFlags::Graphic3d_TMF_ZoomPers)
        .value("Graphic3d_TMF_RotatePers",Graphic3d_TransModeFlags::Graphic3d_TMF_RotatePers)
        .value("Graphic3d_TMF_TriedronPers",Graphic3d_TransModeFlags::Graphic3d_TMF_TriedronPers)
        .value("Graphic3d_TMF_2d",Graphic3d_TransModeFlags::Graphic3d_TMF_2d)
        .value("Graphic3d_TMF_CameraPers",Graphic3d_TransModeFlags::Graphic3d_TMF_CameraPers)
        .value("Graphic3d_TMF_OrthoPers",Graphic3d_TransModeFlags::Graphic3d_TMF_OrthoPers)
        .value("Graphic3d_TMF_AxialScalePers",Graphic3d_TransModeFlags::Graphic3d_TMF_AxialScalePers)
        .value("Graphic3d_TMF_ZoomRotatePers",Graphic3d_TransModeFlags::Graphic3d_TMF_ZoomRotatePers)
        .value("Graphic3d_TMF_AxialZoomPers",Graphic3d_TransModeFlags::Graphic3d_TMF_AxialZoomPers).export_values();
    py::enum_<Graphic3d_LevelOfTextureAnisotropy>(m, "Graphic3d_LevelOfTextureAnisotropy",R"#(Level of anisotropy filter. Notice that actual quality depends on hardware capabilities!)#")
        .value("Graphic3d_LOTA_OFF",Graphic3d_LevelOfTextureAnisotropy::Graphic3d_LOTA_OFF)
        .value("Graphic3d_LOTA_FAST",Graphic3d_LevelOfTextureAnisotropy::Graphic3d_LOTA_FAST)
        .value("Graphic3d_LOTA_MIDDLE",Graphic3d_LevelOfTextureAnisotropy::Graphic3d_LOTA_MIDDLE)
        .value("Graphic3d_LOTA_QUALITY",Graphic3d_LevelOfTextureAnisotropy::Graphic3d_LOTA_QUALITY).export_values();
    py::enum_<Graphic3d_ClipState>(m, "Graphic3d_ClipState",R"#(Clipping state.)#")
        .value("Graphic3d_ClipState_Out",Graphic3d_ClipState::Graphic3d_ClipState_Out)
        .value("Graphic3d_ClipState_In",Graphic3d_ClipState::Graphic3d_ClipState_In)
        .value("Graphic3d_ClipState_On",Graphic3d_ClipState::Graphic3d_ClipState_On).export_values();
    py::enum_<Graphic3d_HorizontalTextAlignment>(m, "Graphic3d_HorizontalTextAlignment",R"#(Defines the horizontal position of the text relative to its anchor.)#")
        .value("Graphic3d_HTA_LEFT",Graphic3d_HorizontalTextAlignment::Graphic3d_HTA_LEFT)
        .value("Graphic3d_HTA_CENTER",Graphic3d_HorizontalTextAlignment::Graphic3d_HTA_CENTER)
        .value("Graphic3d_HTA_RIGHT",Graphic3d_HorizontalTextAlignment::Graphic3d_HTA_RIGHT).export_values();
    py::enum_<Graphic3d_NameOfTextureEnv>(m, "Graphic3d_NameOfTextureEnv",R"#(Types of standard textures.)#")
        .value("Graphic3d_NOT_ENV_CLOUDS",Graphic3d_NameOfTextureEnv::Graphic3d_NOT_ENV_CLOUDS)
        .value("Graphic3d_NOT_ENV_CV",Graphic3d_NameOfTextureEnv::Graphic3d_NOT_ENV_CV)
        .value("Graphic3d_NOT_ENV_MEDIT",Graphic3d_NameOfTextureEnv::Graphic3d_NOT_ENV_MEDIT)
        .value("Graphic3d_NOT_ENV_PEARL",Graphic3d_NameOfTextureEnv::Graphic3d_NOT_ENV_PEARL)
        .value("Graphic3d_NOT_ENV_SKY1",Graphic3d_NameOfTextureEnv::Graphic3d_NOT_ENV_SKY1)
        .value("Graphic3d_NOT_ENV_SKY2",Graphic3d_NameOfTextureEnv::Graphic3d_NOT_ENV_SKY2)
        .value("Graphic3d_NOT_ENV_LINES",Graphic3d_NameOfTextureEnv::Graphic3d_NOT_ENV_LINES)
        .value("Graphic3d_NOT_ENV_ROAD",Graphic3d_NameOfTextureEnv::Graphic3d_NOT_ENV_ROAD)
        .value("Graphic3d_NOT_ENV_UNKNOWN",Graphic3d_NameOfTextureEnv::Graphic3d_NOT_ENV_UNKNOWN).export_values();
    py::enum_<Graphic3d_NameOfTexturePlane>(m, "Graphic3d_NameOfTexturePlane",R"#(Type of the texture projection plane for both S and T texture coordinate.)#")
        .value("Graphic3d_NOTP_XY",Graphic3d_NameOfTexturePlane::Graphic3d_NOTP_XY)
        .value("Graphic3d_NOTP_YZ",Graphic3d_NameOfTexturePlane::Graphic3d_NOTP_YZ)
        .value("Graphic3d_NOTP_ZX",Graphic3d_NameOfTexturePlane::Graphic3d_NOTP_ZX)
        .value("Graphic3d_NOTP_UNKNOWN",Graphic3d_NameOfTexturePlane::Graphic3d_NOTP_UNKNOWN).export_values();
    py::enum_<Graphic3d_GlslExtension>(m, "Graphic3d_GlslExtension",R"#(GLSL syntax extensions.)#")
        .value("Graphic3d_GlslExtension_GL_OES_standard_derivatives",Graphic3d_GlslExtension::Graphic3d_GlslExtension_GL_OES_standard_derivatives)
        .value("Graphic3d_GlslExtension_GL_EXT_shader_texture_lod",Graphic3d_GlslExtension::Graphic3d_GlslExtension_GL_EXT_shader_texture_lod)
        .value("Graphic3d_GlslExtension_GL_EXT_frag_depth",Graphic3d_GlslExtension::Graphic3d_GlslExtension_GL_EXT_frag_depth)
        .value("Graphic3d_GlslExtension_GL_EXT_gpu_shader4",Graphic3d_GlslExtension::Graphic3d_GlslExtension_GL_EXT_gpu_shader4).export_values();
    m.attr("Graphic3d_GlslExtension_NB") = py::cast(int(Graphic3d_GlslExtension_NB));
    py::enum_<Graphic3d_TypeOfPrimitiveArray>(m, "Graphic3d_TypeOfPrimitiveArray",R"#(The type of primitive array in a group in a structure.)#")
        .value("Graphic3d_TOPA_UNDEFINED",Graphic3d_TypeOfPrimitiveArray::Graphic3d_TOPA_UNDEFINED)
        .value("Graphic3d_TOPA_POINTS",Graphic3d_TypeOfPrimitiveArray::Graphic3d_TOPA_POINTS)
        .value("Graphic3d_TOPA_SEGMENTS",Graphic3d_TypeOfPrimitiveArray::Graphic3d_TOPA_SEGMENTS)
        .value("Graphic3d_TOPA_POLYLINES",Graphic3d_TypeOfPrimitiveArray::Graphic3d_TOPA_POLYLINES)
        .value("Graphic3d_TOPA_TRIANGLES",Graphic3d_TypeOfPrimitiveArray::Graphic3d_TOPA_TRIANGLES)
        .value("Graphic3d_TOPA_TRIANGLESTRIPS",Graphic3d_TypeOfPrimitiveArray::Graphic3d_TOPA_TRIANGLESTRIPS)
        .value("Graphic3d_TOPA_TRIANGLEFANS",Graphic3d_TypeOfPrimitiveArray::Graphic3d_TOPA_TRIANGLEFANS)
        .value("Graphic3d_TOPA_LINES_ADJACENCY",Graphic3d_TypeOfPrimitiveArray::Graphic3d_TOPA_LINES_ADJACENCY)
        .value("Graphic3d_TOPA_LINE_STRIP_ADJACENCY",Graphic3d_TypeOfPrimitiveArray::Graphic3d_TOPA_LINE_STRIP_ADJACENCY)
        .value("Graphic3d_TOPA_TRIANGLES_ADJACENCY",Graphic3d_TypeOfPrimitiveArray::Graphic3d_TOPA_TRIANGLES_ADJACENCY)
        .value("Graphic3d_TOPA_TRIANGLE_STRIP_ADJACENCY",Graphic3d_TypeOfPrimitiveArray::Graphic3d_TOPA_TRIANGLE_STRIP_ADJACENCY)
        .value("Graphic3d_TOPA_QUADRANGLES",Graphic3d_TypeOfPrimitiveArray::Graphic3d_TOPA_QUADRANGLES)
        .value("Graphic3d_TOPA_QUADRANGLESTRIPS",Graphic3d_TypeOfPrimitiveArray::Graphic3d_TOPA_QUADRANGLESTRIPS)
        .value("Graphic3d_TOPA_POLYGONS",Graphic3d_TypeOfPrimitiveArray::Graphic3d_TOPA_POLYGONS).export_values();
    py::enum_<Graphic3d_TypeOfTexture>(m, "Graphic3d_TypeOfTexture",R"#(Type of the texture file format.)#")
        .value("Graphic3d_TypeOfTexture_1D",Graphic3d_TypeOfTexture::Graphic3d_TypeOfTexture_1D)
        .value("Graphic3d_TypeOfTexture_2D",Graphic3d_TypeOfTexture::Graphic3d_TypeOfTexture_2D)
        .value("Graphic3d_TypeOfTexture_3D",Graphic3d_TypeOfTexture::Graphic3d_TypeOfTexture_3D)
        .value("Graphic3d_TypeOfTexture_CUBEMAP",Graphic3d_TypeOfTexture::Graphic3d_TypeOfTexture_CUBEMAP)
        .value("Graphic3d_TOT_2D_MIPMAP",Graphic3d_TypeOfTexture::Graphic3d_TOT_2D_MIPMAP)
        .value("Graphic3d_TOT_1D",Graphic3d_TypeOfTexture::Graphic3d_TOT_1D)
        .value("Graphic3d_TOT_2D",Graphic3d_TypeOfTexture::Graphic3d_TOT_2D)
        .value("Graphic3d_TOT_CUBEMAP",Graphic3d_TypeOfTexture::Graphic3d_TOT_CUBEMAP).export_values();
    py::enum_<Graphic3d_TypeOfBackground>(m, "Graphic3d_TypeOfBackground",R"#(Describes type of view background.)#")
        .value("Graphic3d_TOB_NONE",Graphic3d_TypeOfBackground::Graphic3d_TOB_NONE)
        .value("Graphic3d_TOB_GRADIENT",Graphic3d_TypeOfBackground::Graphic3d_TOB_GRADIENT)
        .value("Graphic3d_TOB_TEXTURE",Graphic3d_TypeOfBackground::Graphic3d_TOB_TEXTURE)
        .value("Graphic3d_TOB_CUBEMAP",Graphic3d_TypeOfBackground::Graphic3d_TOB_CUBEMAP).export_values();
    m.attr("Graphic3d_TypeOfBackground_NB") = py::cast(int(Graphic3d_TypeOfBackground_NB));
    py::enum_<Graphic3d_BufferType>(m, "Graphic3d_BufferType",R"#(Define buffers available for dump)#")
        .value("Graphic3d_BT_RGB",Graphic3d_BufferType::Graphic3d_BT_RGB)
        .value("Graphic3d_BT_RGBA",Graphic3d_BufferType::Graphic3d_BT_RGBA)
        .value("Graphic3d_BT_Depth",Graphic3d_BufferType::Graphic3d_BT_Depth)
        .value("Graphic3d_BT_RGB_RayTraceHdrLeft",Graphic3d_BufferType::Graphic3d_BT_RGB_RayTraceHdrLeft)
        .value("Graphic3d_BT_Red",Graphic3d_BufferType::Graphic3d_BT_Red)
        .value("Graphic3d_BT_ShadowMap",Graphic3d_BufferType::Graphic3d_BT_ShadowMap).export_values();
    py::enum_<Graphic3d_FresnelModel>(m, "Graphic3d_FresnelModel",R"#(Type of the Fresnel model.)#")
        .value("Graphic3d_FM_SCHLICK",Graphic3d_FresnelModel::Graphic3d_FM_SCHLICK)
        .value("Graphic3d_FM_CONSTANT",Graphic3d_FresnelModel::Graphic3d_FM_CONSTANT)
        .value("Graphic3d_FM_CONDUCTOR",Graphic3d_FresnelModel::Graphic3d_FM_CONDUCTOR)
        .value("Graphic3d_FM_DIELECTRIC",Graphic3d_FresnelModel::Graphic3d_FM_DIELECTRIC).export_values();
    py::enum_<Graphic3d_TypeOfTextureFilter>(m, "Graphic3d_TypeOfTextureFilter",R"#(Type of the texture filter. Notice that for textures without mipmaps linear interpolation will be used instead of TOTF_BILINEAR and TOTF_TRILINEAR.)#")
        .value("Graphic3d_TOTF_NEAREST",Graphic3d_TypeOfTextureFilter::Graphic3d_TOTF_NEAREST)
        .value("Graphic3d_TOTF_BILINEAR",Graphic3d_TypeOfTextureFilter::Graphic3d_TOTF_BILINEAR)
        .value("Graphic3d_TOTF_TRILINEAR",Graphic3d_TypeOfTextureFilter::Graphic3d_TOTF_TRILINEAR).export_values();
    py::enum_<Graphic3d_CappingFlags>(m, "Graphic3d_CappingFlags",R"#(Enumeration of capping flags.)#")
        .value("Graphic3d_CappingFlags_None",Graphic3d_CappingFlags::Graphic3d_CappingFlags_None)
        .value("Graphic3d_CappingFlags_ObjectMaterial",Graphic3d_CappingFlags::Graphic3d_CappingFlags_ObjectMaterial)
        .value("Graphic3d_CappingFlags_ObjectTexture",Graphic3d_CappingFlags::Graphic3d_CappingFlags_ObjectTexture)
        .value("Graphic3d_CappingFlags_ObjectShader",Graphic3d_CappingFlags::Graphic3d_CappingFlags_ObjectShader)
        .value("Graphic3d_CappingFlags_ObjectAspect",Graphic3d_CappingFlags::Graphic3d_CappingFlags_ObjectAspect).export_values();

//Python trampoline classes
    class Py_Graphic3d_CStructure : public Graphic3d_CStructure{
    public:
        using Graphic3d_CStructure::Graphic3d_CStructure;


        // public pure virtual
        void OnVisibilityChanged() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CStructure,OnVisibilityChanged,) };
        void Clear() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CStructure,Clear,) };
        void Connect(Graphic3d_CStructure & theStructure) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CStructure,Connect,theStructure) };
        void Disconnect(Graphic3d_CStructure & theStructure) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CStructure,Disconnect,theStructure) };
        void GraphicHighlight( const handle<Graphic3d_PresentationAttributes> & theStyle) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CStructure,GraphicHighlight,theStyle) };
        void GraphicUnhighlight() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CStructure,GraphicUnhighlight,) };
        handle<Graphic3d_CStructure> ShadowLink( const handle<Graphic3d_StructureManager> & theManager) const  override { using return_type = handle<Graphic3d_CStructure>;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CStructure,ShadowLink,theManager) };
        handle<Graphic3d_Group> NewGroup( const handle<Graphic3d_Structure> & theStruct) override { using return_type = handle<Graphic3d_Group>;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CStructure,NewGroup,theStruct) };
        void RemoveGroup( const handle<Graphic3d_Group> & theGroup) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CStructure,RemoveGroup,theGroup) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_Graphic3d_DataStructureManager : public Graphic3d_DataStructureManager{
    public:
        using Graphic3d_DataStructureManager::Graphic3d_DataStructureManager;


        // public pure virtual


        // protected pure virtual
         const handle<Graphic3d_Camera> & Camera() const  override { using return_type =  const handle<Graphic3d_Camera> &;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_DataStructureManager,Camera,) };


        // private pure virtual

    };
    class Py_Graphic3d_FrameStats : public Graphic3d_FrameStats{
    public:
        using Graphic3d_FrameStats::Graphic3d_FrameStats;


        // public pure virtual


        // protected pure virtual
        void updateStatistics( const handle<Graphic3d_CView> & theView,bool theIsImmediateOnly) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_FrameStats,updateStatistics,theView,theIsImmediateOnly) };


        // private pure virtual

    };
    class Py_Graphic3d_GraphicDriver : public Graphic3d_GraphicDriver{
    public:
        using Graphic3d_GraphicDriver::Graphic3d_GraphicDriver;


        // public pure virtual
        int InquireLimit( const Graphic3d_TypeOfLimit theType) const  override { using return_type = int;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_GraphicDriver,InquireLimit,theType) };
        handle<Graphic3d_CStructure> CreateStructure( const handle<Graphic3d_StructureManager> & theManager) override { using return_type = handle<Graphic3d_CStructure>;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_GraphicDriver,CreateStructure,theManager) };
        handle<Graphic3d_CView> CreateView( const handle<Graphic3d_StructureManager> & theMgr) override { using return_type = handle<Graphic3d_CView>;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_GraphicDriver,CreateView,theMgr) };
        void RemoveView( const handle<Graphic3d_CView> & theView) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_GraphicDriver,RemoveView,theView) };
        void EnableVBO( const bool status) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_GraphicDriver,EnableVBO,status) };
        bool IsVerticalSync() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_GraphicDriver,IsVerticalSync,) };
        void SetVerticalSync(bool theToEnable) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_GraphicDriver,SetVerticalSync,theToEnable) };
        bool MemoryInfo(size_t & theFreeBytes,TCollection_AsciiString & theInfo) const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_GraphicDriver,MemoryInfo,theFreeBytes,theInfo) };
        float DefaultTextHeight() const  override { using return_type = float;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_GraphicDriver,DefaultTextHeight,) };
        void InsertLayerBefore( const Graphic3d_ZLayerId theNewLayerId, const Graphic3d_ZLayerSettings & theSettings, const Graphic3d_ZLayerId theLayerAfter) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_GraphicDriver,InsertLayerBefore,theNewLayerId,theSettings,theLayerAfter) };
        void InsertLayerAfter( const Graphic3d_ZLayerId theNewLayerId, const Graphic3d_ZLayerSettings & theSettings, const Graphic3d_ZLayerId theLayerBefore) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_GraphicDriver,InsertLayerAfter,theNewLayerId,theSettings,theLayerBefore) };
        void RemoveZLayer( const Graphic3d_ZLayerId theLayerId) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_GraphicDriver,RemoveZLayer,theLayerId) };
        void SetZLayerSettings( const Graphic3d_ZLayerId theLayerId, const Graphic3d_ZLayerSettings & theSettings) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_GraphicDriver,SetZLayerSettings,theLayerId,theSettings) };
        bool ViewExists( const handle<Aspect_Window> & theWindow,handle<Graphic3d_CView> & theView) override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_GraphicDriver,ViewExists,theWindow,theView) };
        void RemoveStructure(handle<Graphic3d_CStructure> & theCStructure) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_GraphicDriver,RemoveStructure,theCStructure) };
        void TextSize( const handle<Graphic3d_CView> & theView, const char * const  theText, const float theHeight,float & theWidth,float & theAscent,float & theDescent) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_GraphicDriver,TextSize,theView,theText,theHeight,theWidth,theAscent,theDescent) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_Graphic3d_GraphicDriverFactory : public Graphic3d_GraphicDriverFactory{
    public:
        using Graphic3d_GraphicDriverFactory::Graphic3d_GraphicDriverFactory;


        // public pure virtual
        handle<Graphic3d_GraphicDriver> CreateDriver( const handle<Aspect_DisplayConnection> & theDisp) override { using return_type = handle<Graphic3d_GraphicDriver>;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_GraphicDriverFactory,CreateDriver,theDisp) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_Graphic3d_Group : public Graphic3d_Group{
    public:
        using Graphic3d_Group::Graphic3d_Group;


        // public pure virtual
        handle<Graphic3d_Aspects> Aspects() const  override { using return_type = handle<Graphic3d_Aspects>;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_Group,Aspects,) };
        void SetGroupPrimitivesAspect( const handle<Graphic3d_Aspects> & theAspect) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_Group,SetGroupPrimitivesAspect,theAspect) };
        void SetPrimitivesAspect( const handle<Graphic3d_Aspects> & theAspect) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_Group,SetPrimitivesAspect,theAspect) };
        void SynchronizeAspects() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_Group,SynchronizeAspects,) };
        void ReplaceAspects( const NCollection_DataMap<handle<Graphic3d_Aspects>, handle<Graphic3d_Aspects>> & theMap) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_Group,ReplaceAspects,theMap) };
        void SetStencilTestOptions( const bool theIsEnabled) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_Group,SetStencilTestOptions,theIsEnabled) };
        void SetFlippingOptions( const bool theIsEnabled, const gp_Ax2 & theRefPlane) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_Group,SetFlippingOptions,theIsEnabled,theRefPlane) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_Graphic3d_ValueInterface : public Graphic3d_ValueInterface{
    public:
        using Graphic3d_ValueInterface::Graphic3d_ValueInterface;


        // public pure virtual
        size_t TypeID() const  override { using return_type = size_t;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_ValueInterface,TypeID,) };


        // protected pure virtual


        // private pure virtual

    };
    class Py_Graphic3d_CView : public Graphic3d_CView{
    public:
        using Graphic3d_CView::Graphic3d_CView;


        // public pure virtual
        void Redraw() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,Redraw,) };
        void RedrawImmediate() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,RedrawImmediate,) };
        void Invalidate() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,Invalidate,) };
        bool IsInvalidated() override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,IsInvalidated,) };
        void Resized() override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,Resized,) };
        bool SetImmediateModeDrawToFront( const bool theDrawToFrontBuffer) override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,SetImmediateModeDrawToFront,theDrawToFrontBuffer) };
        void SetWindow( const handle<Graphic3d_CView> & theParentVIew, const handle<Aspect_Window> & theWindow, const Aspect_RenderingContext theContext) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,SetWindow,theParentVIew,theWindow,theContext) };
        handle<Aspect_Window> Window() const  override { using return_type = handle<Aspect_Window>;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,Window,) };
        bool IsDefined() const  override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,IsDefined,) };
        bool BufferDump(Image_PixMap & theImage, const Graphic3d_BufferType & theBufferType) override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,BufferDump,theImage,theBufferType) };
        bool ShadowMapDump(Image_PixMap & theImage, const TCollection_AsciiString & theLightName) override { using return_type = bool;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,ShadowMapDump,theImage,theLightName) };
        void InvalidateBVHData( const Graphic3d_ZLayerId theLayerId) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,InvalidateBVHData,theLayerId) };
        void InsertLayerBefore( const Graphic3d_ZLayerId theNewLayerId, const Graphic3d_ZLayerSettings & theSettings, const Graphic3d_ZLayerId theLayerAfter) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,InsertLayerBefore,theNewLayerId,theSettings,theLayerAfter) };
        void InsertLayerAfter( const Graphic3d_ZLayerId theNewLayerId, const Graphic3d_ZLayerSettings & theSettings, const Graphic3d_ZLayerId theLayerBefore) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,InsertLayerAfter,theNewLayerId,theSettings,theLayerBefore) };
        int ZLayerMax() const  override { using return_type = int;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,ZLayerMax,) };
         const NCollection_List<handle<Graphic3d_Layer>> & Layers() const  override { using return_type =  const NCollection_List<handle<Graphic3d_Layer>> &;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,Layers,) };
        handle<Graphic3d_Layer> Layer( const Graphic3d_ZLayerId theLayerId) const  override { using return_type = handle<Graphic3d_Layer>;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,Layer,theLayerId) };
        void RemoveZLayer( const Graphic3d_ZLayerId theLayerId) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,RemoveZLayer,theLayerId) };
        void SetZLayerSettings( const Graphic3d_ZLayerId theLayerId, const Graphic3d_ZLayerSettings & theSettings) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,SetZLayerSettings,theLayerId,theSettings) };
        handle<Standard_Transient> FBO() const  override { using return_type = handle<Standard_Transient>;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,FBO,) };
        void SetFBO( const handle<Standard_Transient> & theFbo) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,SetFBO,theFbo) };
        handle<Standard_Transient> FBOCreate( const int theWidth, const int theHeight) override { using return_type = handle<Standard_Transient>;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,FBOCreate,theWidth,theHeight) };
        void FBOChangeViewport( const handle<Standard_Transient> & theFbo, const int theWidth, const int theHeight) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,FBOChangeViewport,theFbo,theWidth,theHeight) };
        Aspect_GradientBackground GradientBackground() const  override { using return_type = Aspect_GradientBackground;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,GradientBackground,) };
        void SetGradientBackground( const Aspect_GradientBackground & theBackground) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,SetGradientBackground,theBackground) };
        void SetBackgroundImage( const handle<Graphic3d_TextureMap> & theTextureMap,bool theToUpdatePBREnv) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,SetBackgroundImage,theTextureMap,theToUpdatePBREnv) };
        Aspect_FillMethod BackgroundImageStyle() const  override { using return_type = Aspect_FillMethod;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,BackgroundImageStyle,) };
        void SetBackgroundImageStyle( const Aspect_FillMethod theFillStyle) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,SetBackgroundImageStyle,theFillStyle) };
        void SetImageBasedLighting(bool theToEnableIBL) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,SetImageBasedLighting,theToEnableIBL) };
        void SetTextureEnv( const handle<Graphic3d_TextureEnv> & theTextureEnv) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,SetTextureEnv,theTextureEnv) };
         const handle<Graphic3d_LightSet> & Lights() const  override { using return_type =  const handle<Graphic3d_LightSet> &;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,Lights,) };
        void SetLights( const handle<Graphic3d_LightSet> & theLights) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,SetLights,theLights) };
         const handle<Graphic3d_SequenceOfHClipPlane> & ClipPlanes() const  override { using return_type =  const handle<Graphic3d_SequenceOfHClipPlane> &;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,ClipPlanes,) };
        void SetClipPlanes( const handle<Graphic3d_SequenceOfHClipPlane> & thePlanes) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,SetClipPlanes,thePlanes) };
        void DiagnosticInformation(NCollection_IndexedDataMap<TCollection_AsciiString, TCollection_AsciiString> & theDict,Graphic3d_DiagnosticInfo theFlags) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,DiagnosticInformation,theDict,theFlags) };
        TCollection_AsciiString StatisticInformation() const  override { using return_type = TCollection_AsciiString;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,StatisticInformation,) };
        void StatisticInformation(NCollection_IndexedDataMap<TCollection_AsciiString, TCollection_AsciiString> & theDict) const  override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,StatisticInformation,theDict) };
        void FBORelease(handle<Standard_Transient> & theFbo) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,FBORelease,theFbo) };
        void FBOGetDimensions( const handle<Standard_Transient> & theFbo,int & theWidth,int & theHeight,int & theWidthMax,int & theHeightMax) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,FBOGetDimensions,theFbo,theWidth,theHeight,theWidthMax,theHeightMax) };


        // protected pure virtual

         const handle<Graphic3d_Camera> & Camera() const  override { using return_type =  const handle<Graphic3d_Camera> &;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_DataStructureManager,Camera,) };

        // private pure virtual
        void displayStructure( const handle<Graphic3d_CStructure> & theStructure, const Graphic3d_DisplayPriority thePriority) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,displayStructure,theStructure,thePriority) };
        void eraseStructure( const handle<Graphic3d_CStructure> & theStructure) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,eraseStructure,theStructure) };
        void changeZLayer( const handle<Graphic3d_CStructure> & theCStructure, const Graphic3d_ZLayerId theNewLayerId) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,changeZLayer,theCStructure,theNewLayerId) };
        void changePriority( const handle<Graphic3d_CStructure> & theCStructure, const Graphic3d_DisplayPriority theNewPriority) override { using return_type = void;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CView,changePriority,theCStructure,theNewPriority) };

    };
    class Py_Graphic3d_CubeMap : public Graphic3d_CubeMap{
    public:
        using Graphic3d_CubeMap::Graphic3d_CubeMap;


        // public pure virtual
        handle<Image_CompressedPixMap> CompressedValue( const handle<Image_SupportedFormats> & theSupported) override { using return_type = handle<Image_CompressedPixMap>;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CubeMap,CompressedValue,theSupported) };
        handle<Image_PixMap> Value( const handle<Image_SupportedFormats> & theSupported) override { using return_type = handle<Image_PixMap>;
    PYBIND11_OVERLOAD_PURE(return_type,Graphic3d_CubeMap,Value,theSupported) };


        // protected pure virtual


        // private pure virtual

    };

// pre-register typdefs+classes (topologically sorted)
    py::class_<Graphic3d_Attribute , shared_ptr<Graphic3d_Attribute>  >(
      m,
      "Graphic3d_Attribute",R"#(Vertex attribute definition.)#"
    );
    py::class_<Graphic3d_BSDF , shared_ptr<Graphic3d_BSDF>  >(
      m,
      "Graphic3d_BSDF",R"#(Describes material's BSDF (Bidirectional Scattering Distribution Function) used for physically-based rendering (in path tracing engine). BSDF is represented as weighted mixture of basic BRDFs/BTDFs (Bidirectional Reflectance (Transmittance) Distribution Functions).)#"
    );
    py::class_<Graphic3d_BufferRange , shared_ptr<Graphic3d_BufferRange>  >(
      m,
      "Graphic3d_BufferRange",R"#(Range of values defined as Start + Length pair.)#"
    );
    py::class_<Graphic3d_CameraTile , shared_ptr<Graphic3d_CameraTile>  >(
      m,
      "Graphic3d_CameraTile",R"#(Class defines the area (Tile) inside a view.)#"
    );
    py::class_<Graphic3d_CubeMapOrder , shared_ptr<Graphic3d_CubeMapOrder>  >(
      m,
      "Graphic3d_CubeMapOrder",R"#(Graphic3d_CubeMapOrder maps sides of cubemap on tiles in packed cubemap image to support different tiles order in such images. Also it can be considered as permutation of numbers from 0 to 5. It stores permutation in one integer as convolution.)#"
    );
    py::class_<Graphic3d_CullingTool , shared_ptr<Graphic3d_CullingTool>  >(
      m,
      "Graphic3d_CullingTool",R"#(Graphic3d_CullingTool class provides a possibility to store parameters of view volume, such as its vertices and equations, and contains methods detecting if given AABB overlaps view volume.)#"
    );
    py::class_<Graphic3d_FrameStatsData , shared_ptr<Graphic3d_FrameStatsData>  >(
      m,
      "Graphic3d_FrameStatsData",R"#(Data frame definition.)#"
    );
    py::class_<Graphic3d_Fresnel , shared_ptr<Graphic3d_Fresnel>  >(
      m,
      "Graphic3d_Fresnel",R"#(Describes Fresnel reflectance parameters.)#"
    );
    py::class_<Graphic3d_GraduatedTrihedron , shared_ptr<Graphic3d_GraduatedTrihedron>  >(
      m,
      "Graphic3d_GraduatedTrihedron",R"#(Defines the class of a graduated trihedron. It contains main style parameters for implementation of graduated trihedron)#"
    );
    py::class_<Graphic3d_MaterialAspect , shared_ptr<Graphic3d_MaterialAspect>  >(
      m,
      "Graphic3d_MaterialAspect",R"#(This class allows the definition of the type of a surface. Aspect attributes of a 3d face. Keywords: Material, FillArea, Shininess, Ambient, Color, Diffuse, Specular, Transparency, Emissive, ReflectionMode, BackFace, FrontFace, Reflection, Absorption)#"
    );
    py::class_<Graphic3d_PBRMaterial , shared_ptr<Graphic3d_PBRMaterial>  >(
      m,
      "Graphic3d_PBRMaterial",R"#(Class implementing Metallic-Roughness physically based material definition)#"
    );
    py::class_<Graphic3d_PolygonOffset , shared_ptr<Graphic3d_PolygonOffset>  >(
      m,
      "Graphic3d_PolygonOffset",R"#(Polygon offset parameters.)#"
    );
    py::class_<Graphic3d_RenderingParams , shared_ptr<Graphic3d_RenderingParams>  >(
      m,
      "Graphic3d_RenderingParams",R"#(Helper class to store rendering parameters.)#"
    );
    py::class_<Graphic3d_UniformValueTypeID<NCollection_Mat3<float>> , shared_ptr<Graphic3d_UniformValueTypeID<NCollection_Mat3<float>>>  >(
      m,
      "Graphic3d_UniformValueTypeID_NCollection_Mat3_float",R"#()#"
    );
    py::class_<Graphic3d_UniformValueTypeID<NCollection_Mat4<float>> , shared_ptr<Graphic3d_UniformValueTypeID<NCollection_Mat4<float>>>  >(
      m,
      "Graphic3d_UniformValueTypeID_NCollection_Mat4_float",R"#()#"
    );
    py::class_<Graphic3d_UniformValueTypeID<NCollection_Vec2<float>> , shared_ptr<Graphic3d_UniformValueTypeID<NCollection_Vec2<float>>>  >(
      m,
      "Graphic3d_UniformValueTypeID_NCollection_Vec2_float",R"#()#"
    );
    py::class_<Graphic3d_UniformValueTypeID<NCollection_Vec2<int>> , shared_ptr<Graphic3d_UniformValueTypeID<NCollection_Vec2<int>>>  >(
      m,
      "Graphic3d_UniformValueTypeID_NCollection_Vec2_int",R"#()#"
    );
    py::class_<Graphic3d_UniformValueTypeID<NCollection_Vec3<float>> , shared_ptr<Graphic3d_UniformValueTypeID<NCollection_Vec3<float>>>  >(
      m,
      "Graphic3d_UniformValueTypeID_NCollection_Vec3_float",R"#()#"
    );
    py::class_<Graphic3d_UniformValueTypeID<NCollection_Vec3<int>> , shared_ptr<Graphic3d_UniformValueTypeID<NCollection_Vec3<int>>>  >(
      m,
      "Graphic3d_UniformValueTypeID_NCollection_Vec3_int",R"#()#"
    );
    py::class_<Graphic3d_UniformValueTypeID<NCollection_Vec4<float>> , shared_ptr<Graphic3d_UniformValueTypeID<NCollection_Vec4<float>>>  >(
      m,
      "Graphic3d_UniformValueTypeID_NCollection_Vec4_float",R"#()#"
    );
    py::class_<Graphic3d_UniformValueTypeID<NCollection_Vec4<int>> , shared_ptr<Graphic3d_UniformValueTypeID<NCollection_Vec4<int>>>  >(
      m,
      "Graphic3d_UniformValueTypeID_NCollection_Vec4_int",R"#()#"
    );
    py::class_<Graphic3d_UniformValueTypeID<float> , shared_ptr<Graphic3d_UniformValueTypeID<float>>  >(
      m,
      "Graphic3d_UniformValueTypeID_float",R"#()#"
    );
    py::class_<Graphic3d_UniformValueTypeID<int> , shared_ptr<Graphic3d_UniformValueTypeID<int>>  >(
      m,
      "Graphic3d_UniformValueTypeID_int",R"#()#"
    );
    py::class_<Graphic3d_ValidatedCubeMapOrder , shared_ptr<Graphic3d_ValidatedCubeMapOrder>  >(
      m,
      "Graphic3d_ValidatedCubeMapOrder",R"#(Graphic3d_ValidatedCubeMapOrder contains completely valid order object. The only way to create this class except copy constructor is 'Validated' method of Graphic3d_CubeMapOrder. This class can initialize Graphic3d_CubeMapOrder. It is supposed to be used in case of necessity of completely valid order (in function argument as example). It helps to automate order's valid checks.Graphic3d_ValidatedCubeMapOrder contains completely valid order object. The only way to create this class except copy constructor is 'Validated' method of Graphic3d_CubeMapOrder. This class can initialize Graphic3d_CubeMapOrder. It is supposed to be used in case of necessity of completely valid order (in function argument as example). It helps to automate order's valid checks.)#"
    );
    py::class_<Graphic3d_ValueInterface , shared_ptr<Graphic3d_ValueInterface> ,Py_Graphic3d_ValueInterface >(
      m,
      "Graphic3d_ValueInterface",R"#(Interface for generic variable value.)#"
    );
    py::class_<Graphic3d_Vertex , shared_ptr<Graphic3d_Vertex>  >(
      m,
      "Graphic3d_Vertex",R"#(This class represents a graphical 3D point.)#"
    );
    py::class_<Graphic3d_WorldViewProjState , shared_ptr<Graphic3d_WorldViewProjState>  >(
      m,
      "Graphic3d_WorldViewProjState",R"#(Helper class for keeping reference on world-view-projection state. Helpful for synchronizing state of WVP dependent data structures.)#"
    );
    py::class_<Graphic3d_ZLayerSettings , shared_ptr<Graphic3d_ZLayerSettings>  >(
      m,
      "Graphic3d_ZLayerSettings",R"#(Structure defines list of ZLayer properties.)#"
    );
    py::class_<Graphic3d_ArrayOfPrimitives ,opencascade::handle<Graphic3d_ArrayOfPrimitives>  , Standard_Transient >(
      m,
      "Graphic3d_ArrayOfPrimitives",R"#(This class furnish services to defined and fill an array of primitives which can be passed directly to graphics rendering API.)#"
    );
    py::class_<Graphic3d_Aspects ,opencascade::handle<Graphic3d_Aspects>  , Standard_Transient >(
      m,
      "Graphic3d_Aspects",R"#(This class defines graphic attributes.)#"
    );
    py::class_<Graphic3d_BoundBuffer ,opencascade::handle<Graphic3d_BoundBuffer>  , NCollection_Buffer >(
      m,
      "Graphic3d_BoundBuffer",R"#(Bounds buffer.)#"
    );
    py::class_<Graphic3d_Buffer ,opencascade::handle<Graphic3d_Buffer>  , NCollection_Buffer >(
      m,
      "Graphic3d_Buffer",R"#(Buffer of vertex attributes.)#"
    );
    py::class_<Graphic3d_CLight ,opencascade::handle<Graphic3d_CLight>  , Standard_Transient >(
      m,
      "Graphic3d_CLight",R"#(Generic light source definition. This class defines arbitrary light source - see Graphic3d_TypeOfLightSource enumeration. Some parameters are applicable only to particular light type; calling methods unrelated to current type will throw an exception.)#"
    );
    py::class_<Graphic3d_CStructure ,opencascade::handle<Graphic3d_CStructure> ,Py_Graphic3d_CStructure , Standard_Transient >(
      m,
      "Graphic3d_CStructure",R"#(Low-level graphic structure interface)#"
    );
    py::class_<Graphic3d_Camera ,opencascade::handle<Graphic3d_Camera>  , Standard_Transient >(
      m,
      "Graphic3d_Camera",R"#(Camera class provides object-oriented approach to setting up projection and orientation properties of 3D view.)#"
    );
    py::class_<Graphic3d_ClipPlane ,opencascade::handle<Graphic3d_ClipPlane>  , Standard_Transient >(
      m,
      "Graphic3d_ClipPlane",R"#(Container for properties describing either a Clipping halfspace (single Clipping Plane), or a chain of Clipping Planes defining logical AND (conjunction) operation. The plane equation is specified in "world" coordinate system.)#"
    );
    py::class_<Graphic3d_DataStructureManager ,opencascade::handle<Graphic3d_DataStructureManager> ,Py_Graphic3d_DataStructureManager , Standard_Transient >(
      m,
      "Graphic3d_DataStructureManager",R"#(This class allows the definition of a manager to which the graphic objects are associated. It allows them to be globally manipulated. It defines the global attributes.)#"
    );
    py::class_<Graphic3d_Flipper ,opencascade::handle<Graphic3d_Flipper>  , Standard_Transient >(
      m,
      "Graphic3d_Flipper",R"#(CPU-side analogue of OpenGl_Flipper used by the selection pipeline. Describes a reference coordinate system used at draw time to mirror group contents so that they remain upright relative to the camera. The same logic is used here to compute the flipping matrix applied to bounding boxes and sensitive frustums, so that selection matches the rendered geometry.)#"
    );
    py::class_<Graphic3d_FrameStats ,opencascade::handle<Graphic3d_FrameStats> ,Py_Graphic3d_FrameStats , Standard_Transient >(
      m,
      "Graphic3d_FrameStats",R"#(Class storing the frame statistics.)#"
    );
    py::class_<Graphic3d_FrameStatsDataTmp , shared_ptr<Graphic3d_FrameStatsDataTmp>  , Graphic3d_FrameStatsData >(
      m,
      "Graphic3d_FrameStatsDataTmp",R"#(Temporary data frame definition.)#"
    );
    py::class_<Graphic3d_GraphicDriver ,opencascade::handle<Graphic3d_GraphicDriver> ,Py_Graphic3d_GraphicDriver , Standard_Transient >(
      m,
      "Graphic3d_GraphicDriver",R"#(This class allows the definition of a graphic driver for 3d interface (currently only OpenGl driver is used).)#"
    );
    py::class_<Graphic3d_GraphicDriverFactory ,opencascade::handle<Graphic3d_GraphicDriverFactory> ,Py_Graphic3d_GraphicDriverFactory , Standard_Transient >(
      m,
      "Graphic3d_GraphicDriverFactory",R"#(This class for creation of Graphic3d_GraphicDriver.This class for creation of Graphic3d_GraphicDriver.)#"
    );
    py::class_<Graphic3d_Group ,opencascade::handle<Graphic3d_Group> ,Py_Graphic3d_Group , Standard_Transient >(
      m,
      "Graphic3d_Group",R"#(This class allows the definition of groups of primitives inside of graphic objects (presentations). A group contains the primitives and attributes for which the range is limited to this group. The primitives of a group can be globally suppressed.)#"
    );
    py::class_<Graphic3d_HatchStyle ,opencascade::handle<Graphic3d_HatchStyle>  , Standard_Transient >(
      m,
      "Graphic3d_HatchStyle",R"#(A class that provides an API to use standard OCCT hatch styles defined in Aspect_HatchStyle enum or to create custom styles from a user-defined bitmap)#"
    );
    py::class_<Graphic3d_Layer ,opencascade::handle<Graphic3d_Layer>  , Standard_Transient >(
      m,
      "Graphic3d_Layer",R"#(Presentations list sorted within priorities.)#"
    );
    py::class_<Graphic3d_LightSet ,opencascade::handle<Graphic3d_LightSet>  , Standard_Transient >(
      m,
      "Graphic3d_LightSet",R"#(Class defining the set of light sources.)#"
    );
    py::class_<Graphic3d_MarkerImage ,opencascade::handle<Graphic3d_MarkerImage>  , Standard_Transient >(
      m,
      "Graphic3d_MarkerImage",R"#(This class is used to store bitmaps and images for markers rendering. It can convert bitmap texture stored in NCollection_HArray1<uint8_t> to Image_PixMap and vice versa.)#"
    );
    py::class_<Graphic3d_PresentationAttributes ,opencascade::handle<Graphic3d_PresentationAttributes>  , Standard_Transient >(
      m,
      "Graphic3d_PresentationAttributes",R"#(Class defines presentation properties.)#"
    );
    py::class_<Graphic3d_SequenceOfHClipPlane ,opencascade::handle<Graphic3d_SequenceOfHClipPlane>  , Standard_Transient >(
      m,
      "Graphic3d_SequenceOfHClipPlane",R"#(Class defines a Clipping Volume as a logical OR (disjunction) operation between Graphic3d_ClipPlane in sequence. Each Graphic3d_ClipPlane represents either a single Plane clipping a halfspace (direction is specified by normal), or a sub-chain of planes defining a logical AND (conjunction) operation. Therefore, this collection allows defining a Clipping Volume through the limited set of Boolean operations between clipping Planes.)#"
    );
    py::class_<Graphic3d_ShaderAttribute ,opencascade::handle<Graphic3d_ShaderAttribute>  , Standard_Transient >(
      m,
      "Graphic3d_ShaderAttribute",R"#(Describes custom vertex shader attribute.)#"
    );
    py::class_<Graphic3d_ShaderManager ,opencascade::handle<Graphic3d_ShaderManager>  , Standard_Transient >(
      m,
      "Graphic3d_ShaderManager",R"#(This class is responsible for generation of shader programs.)#"
    );
    py::class_<Graphic3d_ShaderObject ,opencascade::handle<Graphic3d_ShaderObject>  , Standard_Transient >(
      m,
      "Graphic3d_ShaderObject",R"#(This class is responsible for managing shader objects.)#"
    );
    py::class_<Graphic3d_ShaderProgram ,opencascade::handle<Graphic3d_ShaderProgram>  , Standard_Transient >(
      m,
      "Graphic3d_ShaderProgram",R"#(This class is responsible for managing shader programs.)#"
    );
    py::class_<Graphic3d_ShaderVariable ,opencascade::handle<Graphic3d_ShaderVariable>  , Standard_Transient >(
      m,
      "Graphic3d_ShaderVariable",R"#(Describes custom uniform shader variable.)#"
    );
    py::class_<Graphic3d_Structure ,opencascade::handle<Graphic3d_Structure>  , Standard_Transient >(
      m,
      "Graphic3d_Structure",R"#(This class allows the definition a graphic object. This graphic structure can be displayed, erased, or highlighted. This graphic structure can be connected with another graphic structure.This class allows the definition a graphic object. This graphic structure can be displayed, erased, or highlighted. This graphic structure can be connected with another graphic structure.)#"
    );
    py::class_<Graphic3d_StructureManager ,opencascade::handle<Graphic3d_StructureManager>  , Standard_Transient >(
      m,
      "Graphic3d_StructureManager",R"#(This class allows the definition of a manager to which the graphic objects are associated. It allows them to be globally manipulated. It defines the global attributes. Keywords: Structure, Structure Manager, Update Mode, Destroy, Highlight, Visible)#"
    );
    py::class_<Graphic3d_Text ,opencascade::handle<Graphic3d_Text>  , Standard_Transient >(
      m,
      "Graphic3d_Text",R"#(This class allows the definition of a text object for display. The text might be defined in one of ways, using: - text value and position, - text value, orientation and the state whether the text uses position as point of attach. - text formatter. Formatter contains text, height and alignment parameter.)#"
    );
    py::class_<Graphic3d_TextureParams ,opencascade::handle<Graphic3d_TextureParams>  , Standard_Transient >(
      m,
      "Graphic3d_TextureParams",R"#(This class describes texture parameters.)#"
    );
    py::class_<Graphic3d_TextureRoot ,opencascade::handle<Graphic3d_TextureRoot>  , Standard_Transient >(
      m,
      "Graphic3d_TextureRoot",R"#(This is the texture root class enable the dialog with the GraphicDriver allows the loading of texture.)#"
    );
    py::class_<Graphic3d_TextureSet ,opencascade::handle<Graphic3d_TextureSet>  , Standard_Transient >(
      m,
      "Graphic3d_TextureSet",R"#(Class holding array of textures to be mapped as a set. Textures should be defined in ascending order of texture units within the set.)#"
    );
    py::class_<Graphic3d_TransformPers ,opencascade::handle<Graphic3d_TransformPers>  , Standard_Transient >(
      m,
      "Graphic3d_TransformPers",R"#(Transformation Persistence definition.)#"
    );
    preregister_template_Graphic3d_UniformValue<float>(m,"Graphic3d_UniformFloat");
    preregister_template_Graphic3d_UniformValue<int>(m,"Graphic3d_UniformInt");
    preregister_template_Graphic3d_UniformValue<NCollection_Mat3<float>>(m,"Graphic3d_UniformMat3");
    preregister_template_Graphic3d_UniformValue<NCollection_Mat4<float>>(m,"Graphic3d_UniformMat4");
    preregister_template_Graphic3d_UniformValue<NCollection_Vec2<float>>(m,"Graphic3d_UniformVec2");
    preregister_template_Graphic3d_UniformValue<NCollection_Vec2<int>>(m,"Graphic3d_UniformVec2i");
    preregister_template_Graphic3d_UniformValue<NCollection_Vec3<float>>(m,"Graphic3d_UniformVec3");
    preregister_template_Graphic3d_UniformValue<NCollection_Vec3<int>>(m,"Graphic3d_UniformVec3i");
    preregister_template_Graphic3d_UniformValue<NCollection_Vec4<float>>(m,"Graphic3d_UniformVec4");
    preregister_template_Graphic3d_UniformValue<NCollection_Vec4<int>>(m,"Graphic3d_UniformVec4i");
    py::class_<Graphic3d_ViewAffinity ,opencascade::handle<Graphic3d_ViewAffinity>  , Standard_Transient >(
      m,
      "Graphic3d_ViewAffinity",R"#(Structure display state.)#"
    );
    py::class_<Graphic3d_ArrayOfPoints ,opencascade::handle<Graphic3d_ArrayOfPoints>  , Graphic3d_ArrayOfPrimitives >(
      m,
      "Graphic3d_ArrayOfPoints",R"#(Contains points array definition.)#"
    );
    py::class_<Graphic3d_ArrayOfPolygons ,opencascade::handle<Graphic3d_ArrayOfPolygons>  , Graphic3d_ArrayOfPrimitives >(
      m,
      "Graphic3d_ArrayOfPolygons",R"#(Contains polygons array definition. WARNING! Polygon primitives might be unsupported by graphics library. Triangulation should be used instead of quads for better compatibility.)#"
    );
    py::class_<Graphic3d_ArrayOfPolylines ,opencascade::handle<Graphic3d_ArrayOfPolylines>  , Graphic3d_ArrayOfPrimitives >(
      m,
      "Graphic3d_ArrayOfPolylines",R"#(Contains polylines array definition.)#"
    );
    py::class_<Graphic3d_ArrayOfQuadrangleStrips ,opencascade::handle<Graphic3d_ArrayOfQuadrangleStrips>  , Graphic3d_ArrayOfPrimitives >(
      m,
      "Graphic3d_ArrayOfQuadrangleStrips",R"#(Contains quadrangles strip array definition. WARNING! Quadrangle primitives might be unsupported by graphics library. Triangulation should be used instead of quads for better compatibility.)#"
    );
    py::class_<Graphic3d_ArrayOfQuadrangles ,opencascade::handle<Graphic3d_ArrayOfQuadrangles>  , Graphic3d_ArrayOfPrimitives >(
      m,
      "Graphic3d_ArrayOfQuadrangles",R"#(Contains quadrangles array definition. WARNING! Quadrangle primitives might be unsupported by graphics library. Triangulation should be used instead of quads for better compatibility.)#"
    );
    py::class_<Graphic3d_ArrayOfSegments ,opencascade::handle<Graphic3d_ArrayOfSegments>  , Graphic3d_ArrayOfPrimitives >(
      m,
      "Graphic3d_ArrayOfSegments",R"#(Contains segments array definition.)#"
    );
    py::class_<Graphic3d_ArrayOfTriangleFans ,opencascade::handle<Graphic3d_ArrayOfTriangleFans>  , Graphic3d_ArrayOfPrimitives >(
      m,
      "Graphic3d_ArrayOfTriangleFans",R"#(Contains triangles fan array definition)#"
    );
    py::class_<Graphic3d_ArrayOfTriangleStrips ,opencascade::handle<Graphic3d_ArrayOfTriangleStrips>  , Graphic3d_ArrayOfPrimitives >(
      m,
      "Graphic3d_ArrayOfTriangleStrips",R"#(Contains triangles strip array definition.)#"
    );
    py::class_<Graphic3d_ArrayOfTriangles ,opencascade::handle<Graphic3d_ArrayOfTriangles>  , Graphic3d_ArrayOfPrimitives >(
      m,
      "Graphic3d_ArrayOfTriangles",R"#(Contains triangles array definition)#"
    );
    py::class_<Graphic3d_AspectFillArea3d ,opencascade::handle<Graphic3d_AspectFillArea3d>  , Graphic3d_Aspects >(
      m,
      "Graphic3d_AspectFillArea3d",R"#(This class defines graphic attributes for opaque 3d primitives (polygons, triangles, quadrilaterals).)#"
    );
    py::class_<Graphic3d_AspectLine3d ,opencascade::handle<Graphic3d_AspectLine3d>  , Graphic3d_Aspects >(
      m,
      "Graphic3d_AspectLine3d",R"#(Creates and updates a group of attributes for 3d line primitives. This group contains the color, the type of line, and its thickness.)#"
    );
    py::class_<Graphic3d_AspectMarker3d ,opencascade::handle<Graphic3d_AspectMarker3d>  , Graphic3d_Aspects >(
      m,
      "Graphic3d_AspectMarker3d",R"#(Creates and updates an attribute group for marker type primitives. This group contains the type of marker, its color, and its scale factor.)#"
    );
    py::class_<Graphic3d_AspectText3d ,opencascade::handle<Graphic3d_AspectText3d>  , Graphic3d_Aspects >(
      m,
      "Graphic3d_AspectText3d",R"#(Creates and updates a group of attributes for text primitives.)#"
    );
    py::class_<Graphic3d_AttribBuffer ,opencascade::handle<Graphic3d_AttribBuffer>  , Graphic3d_Buffer >(
      m,
      "Graphic3d_AttribBuffer",R"#(Buffer of vertex attributes. This class is intended for advanced usage allowing invalidation of entire buffer content or its sub-part.)#"
    );
    py::class_<Graphic3d_CView ,opencascade::handle<Graphic3d_CView> ,Py_Graphic3d_CView , Graphic3d_DataStructureManager >(
      m,
      "Graphic3d_CView",R"#(Base class of a graphical view that carries out rendering process for a concrete implementation of graphical driver. Provides virtual interfaces for redrawing its contents, management of displayed structures and render settings. The source code of the class itself implements functionality related to management of computed (HLR or "view-dependent") structures.Base class of a graphical view that carries out rendering process for a concrete implementation of graphical driver. Provides virtual interfaces for redrawing its contents, management of displayed structures and render settings. The source code of the class itself implements functionality related to management of computed (HLR or "view-dependent") structures.)#"
    );
    py::class_<Graphic3d_IndexBuffer ,opencascade::handle<Graphic3d_IndexBuffer>  , Graphic3d_Buffer >(
      m,
      "Graphic3d_IndexBuffer",R"#(Index buffer.)#"
    );
    py::class_<Graphic3d_MediaTextureSet ,opencascade::handle<Graphic3d_MediaTextureSet>  , Graphic3d_TextureSet >(
      m,
      "Graphic3d_MediaTextureSet",R"#(Texture adapter for Media_Frame.)#"
    );
    py::class_<Graphic3d_TextureEnv ,opencascade::handle<Graphic3d_TextureEnv>  , Graphic3d_TextureRoot >(
      m,
      "Graphic3d_TextureEnv",R"#(This class provides environment texture.)#"
    );
    py::class_<Graphic3d_TextureMap ,opencascade::handle<Graphic3d_TextureMap>  , Graphic3d_TextureRoot >(
      m,
      "Graphic3d_TextureMap",R"#(This is an abstract class for managing texture applicable on polygons.)#"
    );
    py::class_<Graphic3d_TransformPersScaledAbove ,opencascade::handle<Graphic3d_TransformPersScaledAbove>  , Graphic3d_TransformPers >(
      m,
      "Graphic3d_TransformPersScaledAbove",R"#(Transformation Zoom persistence with the above boundary of scale. This persistence works only when the camera scale value is below the scale value of this persistence. Otherwise, no persistence is applied.)#"
    );
    py::class_<Graphic3d_CubeMap ,opencascade::handle<Graphic3d_CubeMap> ,Py_Graphic3d_CubeMap , Graphic3d_TextureMap >(
      m,
      "Graphic3d_CubeMap",R"#(Base class for cubemaps. It is iterator over cubemap sides.)#"
    );
    py::class_<Graphic3d_MutableIndexBuffer ,opencascade::handle<Graphic3d_MutableIndexBuffer>  , Graphic3d_IndexBuffer >(
      m,
      "Graphic3d_MutableIndexBuffer",R"#(Mutable index buffer.)#"
    );
    py::class_<Graphic3d_Texture1D ,opencascade::handle<Graphic3d_Texture1D>  , Graphic3d_TextureMap >(
      m,
      "Graphic3d_Texture1D",R"#(This is an abstract class for managing 1D textures.)#"
    );
    py::class_<Graphic3d_Texture2D ,opencascade::handle<Graphic3d_Texture2D>  , Graphic3d_TextureMap >(
      m,
      "Graphic3d_Texture2D",R"#(This abstract class for managing 2D textures)#"
    );
    py::class_<Graphic3d_Texture3D ,opencascade::handle<Graphic3d_Texture3D>  , Graphic3d_TextureMap >(
      m,
      "Graphic3d_Texture3D",R"#(This abstract class for managing 3D textures.)#"
    );
    py::class_<Graphic3d_CubeMapPacked ,opencascade::handle<Graphic3d_CubeMapPacked>  , Graphic3d_CubeMap >(
      m,
      "Graphic3d_CubeMapPacked",R"#(Class is intended to process cubemap packed into single image plane.)#"
    );
    py::class_<Graphic3d_CubeMapSeparate ,opencascade::handle<Graphic3d_CubeMapSeparate>  , Graphic3d_CubeMap >(
      m,
      "Graphic3d_CubeMapSeparate",R"#(Class to manage cubemap located in six different images.)#"
    );
    py::class_<Graphic3d_MediaTexture ,opencascade::handle<Graphic3d_MediaTexture>  , Graphic3d_Texture2D >(
      m,
      "Graphic3d_MediaTexture",R"#(Texture adapter for Media_Frame.)#"
    );
    py::class_<Graphic3d_Texture1Dmanual ,opencascade::handle<Graphic3d_Texture1Dmanual>  , Graphic3d_Texture1D >(
      m,
      "Graphic3d_Texture1Dmanual",R"#(This class provides the implementation of a manual 1D texture. you MUST provide texture coordinates on your facets if you want to see your texture.)#"
    );
    py::class_<Graphic3d_Texture1Dsegment ,opencascade::handle<Graphic3d_Texture1Dsegment>  , Graphic3d_Texture1D >(
      m,
      "Graphic3d_Texture1Dsegment",R"#(This class provides the implementation of a 1D texture applicable along a segment. You might use the SetSegment() method to set the way the texture is "stretched" on facets.)#"
    );
    py::class_<Graphic3d_Texture2Dplane ,opencascade::handle<Graphic3d_Texture2Dplane>  , Graphic3d_Texture2D >(
      m,
      "Graphic3d_Texture2Dplane",R"#(This class allows the management of a 2D texture defined from a plane equation Use the SetXXX() methods for positioning the texture as you want.)#"
    );

// preregister user-defined template specializations

// user-defined post-inclusion per module in the body

};

// user-defined post-inclusion per module

// user-defined post
